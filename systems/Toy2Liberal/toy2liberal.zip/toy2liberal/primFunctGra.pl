primitiveFunct(openWish,1,1,(':'(char,[]) -> io(channel)),io(channel)).
primitiveFunct(writeWish,2,2,(channel -> ':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(readWish,1,1,(channel -> io(':'(char,[]))),io(':'(char,[]))).
primitiveFunct(closeWish,1,1,(channel -> io(unit)),io(unit)).

primitiveFunct(newVar,1,1,(A -> io(varmut(A))),io(varmut(A))).
primitiveFunct(newVar1,1,1,(A -> A),A).
primitiveFunct(newVar2,1,1,(A -> A),A).
primitiveFunct(readVar,1,1,(varmut(A) -> io(A)),io(A)).
primitiveFunct(writeVar,2,2,(A -> varmut(A) -> io(unit)),io(unit)).
primitiveFunct(writeVar1,1,1,(A -> A),A).


primitiveFunct(strToint,1,1,(':'(char,[]) -> '$num'(int)),'$num'(int)).
primitiveFunct(getNumber,2,2,(':'(char,[]) -> '$num'(int) -> '$num'(int)),'$num'(int)).
primitiveFunct(intTostr,1,1,('$num'(int) -> ':'(char,[])),':'(char,[])).
primitiveFunct(getString,2,2,('$num'(int) -> ':'(char,[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkShowErrors,0,0,bool,bool).
primitiveFunct(tkRef2Label,1,1,(tkRefType -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkRef2Wtype,1,1,(tkRefType -> ':'(char,[])),':'(char,[])).
primitiveFunct(tk2tcl,3,3,(channel -> ':'(char,[]) -> tkWidget(A) -> (':'(char,[]),':'((':'(char,[]),channel -> A),[]))),(':'(char,[]),':'((':'(char,[]),channel -> A),[]))).
primitiveFunct(tkConfCollection2tcl,2,2,(':'(char,[]) -> tkConfCollection -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkConf2tcl,4,4,(':'(char,[]) -> channel -> ':'(char,[]) -> tkConfItem(_) -> ':'(char,[])),':'(char,[])).
primitiveFunct(setlistelems,2,2,(':'(':'(char,[]),[]) -> ':'(char,[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkMenu2tcl,2,2,(':'(char,[]) -> ':'(tkMenuItem(_),[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(setmenuelems,2,2,(':'(tkMenuItem(_),[]) -> '$num'(int) -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkConfs2handler,2,2,(':'(char,[]) -> ':'(tkConfItem(A),[]) -> ':'((':'(char,[]),channel -> A),[])),':'((':'(char,[]),channel -> A),[])).
primitiveFunct(tkMenu2handler,3,3,(':'(char,[]) -> ':'(tkMenuItem(_),[]) -> '$num'(int) -> ':'((':'(char,[]),channel -> A),[])),':'((':'(char,[]),channel -> A),[])).
primitiveFunct(tkConfs2tcl,4,4,(':'(char,[]) -> channel -> ':'(char,[]) -> ':'(tkConfItem(A),[]) -> ':'((':'(char,[]),channel -> A),[])),':'((':'(char,[]),channel -> A),[])).
primitiveFunct(tkcitems2tcl,2,2,(':'(char,[]) -> ':'(tkCanvasItem,[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkcitem,2,2,(':'(char,[]) -> tkCanvasItem -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkShowCoords,1,1,(':'((int,itn),[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkLabel2Refname,1,1,(':'(char,[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(aux,1,1,(char -> char),char).
primitiveFunct(tkRefname2Label,1,1,(':'(char,[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(aux1,1,1,(char -> char),char).
primitiveFunct(tks2tcl,4,4,(channel -> ':'(char,[]) -> '$num'(int) -> ':'(tkWidget(A),[]) -> (':'(char,[]),':'((':'(char,[]),channel -> A),[]))),(':'(char,[]),':'((':'(char,[]),channel -> A),[]))).
primitiveFunct(tkslabels,3,3,(':'(char,[]) -> '$num'(int) -> ':'(tkWidget(_),[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkmain2tcl,2,2,(channel -> tkWidget(A) -> (':'(char,[]),':'((':'(char,[]),channel -> A),[]))),(':'(char,[]),':'((':'(char,[]),channel -> A),[]))).
primitiveFunct(forkWish,2,2,(':'(char,[]) -> ':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(runWidget,2,2,(':'(char,[]) -> tkWidget(io(unit)) -> io(unit)),io(unit)).
primitiveFunct(aux4,1,1,(A -> io(unit)),io(unit)).
primitiveFunct(runWidgetInit,3,3,(':'(char,[]) -> tkWidget(io(unit)) -> (channel -> io(unit)) -> io(unit)),io(unit)).
primitiveFunct(runWidgetPassive,2,2,(':'(char,[]) -> tkWidget(_) -> io(channel)),io(channel)).
primitiveFunct(initSchedule,5,5,((A -> A -> A) -> A -> tkWidget(A) -> channel -> (channel -> A) -> A),A).
primitiveFunct(tkSchedule,4,4,((A -> A -> A) -> A -> ':'((':'(char,[]),channel -> A),[]) -> channel -> A),A).
primitiveFunct(aux2,5,5,((A -> A -> A) -> A -> ':'((':'(char,[]),channel -> A),[]) -> channel -> ':'(char,[]) -> A),A).
primitiveFunct(tkTerminateWish,2,2,(A -> channel -> A),A).
primitiveFunct(tkSelectEvent,4,4,(A -> ':'(char,[]) -> ':'((':'(char,[]),channel -> A),[]) -> channel -> A),A).
primitiveFunct(tkGetVar,3,3,(':'(char,[]) -> channel -> ':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(tkGetVarMsg,3,3,(':'(char,[]) -> channel -> ':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(aux3,4,4,(':'(char,[]) -> channel -> ':'(char,[]) -> ':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(tkGetVarValue,3,3,('$num'(int) -> ':'(char,[]) -> channel -> io(':'(char,[]))),io(':'(char,[]))).
primitiveFunct(tkParseInt,2,2,(':'(char,[]) -> '$num'(int) -> '$num'(int)),'$num'(int)).
primitiveFunct(checkWishConsistency,2,2,(channel -> channel -> bool),bool).
primitiveFunct(escape_tcl,1,1,(':'(char,[]) -> ':'(char,[])),':'(char,[])).
primitiveFunct(tkVoid,1,1,(channel -> io(unit)),io(unit)).
primitiveFunct(tkExit,1,1,(channel -> io(unit)),io(unit)).
primitiveFunct(tkGetValue,2,2,(tkRefType -> channel -> io(':'(char,[]))),io(':'(char,[]))).
primitiveFunct(tkSetValue,3,3,(tkRefType -> ':'(char,[]) -> channel -> io(unit)),io(unit)).
primitiveFunct(tkUpdate,3,3,((':'(char,[]) -> ':'(char,[])) -> tkRefType -> channel -> io(unit)),io(unit)).
primitiveFunct(tkConfig,3,3,(tkRefType -> tkConfItem(_) -> channel -> io(unit)),io(unit)).
primitiveFunct(tkFocus,2,2,(tkRefType -> channel -> io(unit)),io(unit)).
primitiveFunct(tkAddCanvas,3,3,(tkRefType -> ':'(tkCanvasItem,[]) -> channel -> io(unit)),io(unit)).




