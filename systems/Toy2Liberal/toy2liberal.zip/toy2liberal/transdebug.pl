%---------------------------------------------------------------------------%
% transdebug.pl
%---------------------------------------------------------------------------%
/*
- Author: mercedes

- Description: Transforma un programa ya compilado en otro que se utiliza
               para la depuracion. El fichero elegido para la transformacion
               es el fichero File.tmp.out generado tras el analisis sintactico.
               El fichero de salida es File.debug.tmp.out.

- Modules which import it:

- Imported modules:
    >

- Modified:
  15-12-04 Added information about constrains in the computation tree
  30-05-05 Added a fourth parameter to startDebuggingProcess. It represents
           the output of the constraint store obtained after the computation
           (Cout)
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(transdebug,[startDebuggingProcess/4]).

:- load_files(tools,[if(changed),imports([concatLsts/2,append/3,
                                           member/2,endFile/1,member_relax/2,
                                           unionLsts/3])]).

:- load_files(initToy,[if(changed),imports([throwConstraints/1,
                                            convertGoalToExecutableCode/5])]).

:- load_files(pVal,[if(changed),imports([nextVarName/1,searchDollar/3,
                     prologStringToToyString/3,
                     atomToString/3,putName/2])]).

:- load_files(newout,[if(changed),imports([primitive/3,cdata/4,fun/4,ftype/4])]).

:- load_files(compil,[if(changed),imports([variables/3, writeSection/2])]).

:- load_files(errortoy,[if(changed),imports([isVariable/1,name_of_variable/2])]).

:- load_files(dyn,[if(changed),imports([assertdebugando/0,retractdebugando/0,
                    retractlatestNameVar/1,
                    retractalllatestNameVar/0,
                    assertlatestNameVar/1,createRunTimeStatistics/0,
                    assertDDTFlag/0, retractDDTFlag/0,ddtFlag/0,
                                        incDebugCounter/0,getDebugCounter/1,resetDebugCounter/0, 
                                        removeDebugCounter/0, getNAnswer/1,resetNAnswer/0])]).

:- load_files(process,[if(changed),imports([generateCode/2])]).

:- load_files(goals,[if(changed),imports([writeSolution/3,writeStatistics/0])]).

:- load_files(navigating,[if(changed),imports([navigateText/2,graphicalInterface/2,getOracleAnswer/1 ])]).

:- load_files(primitivCod,[if(changed),imports(['$getConstraintStore'/4])]).

:- use_module(library(system)).  % file_exists


/*****************************************************************************/
/*              TRADUCCION DE OBJETIVOS                  */
/*****************************************************************************/


%-----------------------------------------------------------------------------%
% startDebuggingProcess(+Goal,+Vars,+FileStr,*Cout)
% Este predicado lanza el proceso de depuracion a requerimiento del usuario,
% enfadado ante una respuesta que no le ha gustado nada.
% Se hace en 3 pasos:
%   1) Se transforma el programa y el objetivo a formato depuracion
%   2) Se lanza el objetivo transformado, que nos devuelve un arbolito.
%   3) Se navega el arbolito, buscando un nodo cr�tico.
%-----------------------------------------------------------------------------%
startDebuggingProcess(Goal,VarsGoal,FileStr,Cout) :-
        % useGraphicalInterface(Answer),
    Answer = 121,
       (
    (Answer ==121; Answer==98), % yes
        assertDDTFlag,
        createComputationTree(Goal,FileStr,Tree,Store,Cout),
        retractDDTFlag ,
             % write(Tree),nl,
        %nl,
            %writeStatistics,
        %nl,

            graphicalInterface(Tree,Store),
        restoreFile(FileStr)
    ;
     (Answer == 110; Answer==78), % no
            createComputationTree(Goal,VarsGoal,FileStr,Tree,Store,Cout),
        %writeSolution([('yo',Tree)],[],_),
        %nl,
            %writeStatistics,
        %nl,
        navigateText(Tree,Store),
        restoreFile(FileStr)
    ;
      (Answer == 97; Answer==65) % abort
      ),
     !,
     resetNAnswer.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% rafa 10/07/05: VarsGoal is no longer needed
createComputationTree(Goal,FileStr,V,Store,Cout1) :-
    !,
    deleteVars,
    prepareDebug(FileStr,Goal, GoalT,T),
    % el objetivo aun no esta: transformarlo en codigo ejecutable
    % y cambiar sus variables por los de la respuesta (las no inst. quedan libres).
    prepareDebugGoal(GoalT,VarsGoalExe,GoalExe,GoalTree,Cout),

        createRunTimeStatistics,
    % rafa: ahora al lanzar el objetivo nos aseguramos de que las var. libres siguen si�ndolo
    throwGoal(GoalExe,VarsGoalExe),


        % now we can establish de names of the goals
        storeGoalVars(VarsGoalExe), % rafa 10/07/05: VarsGoal is changed by VarsGoalExe        

        % comparamos el almacen del c�mputo original con el obtenido
        % equalSets(Cout1,Cout),

    % prepare the constraintStore
        getVars(VarsGoal,LVars), % Prolog vars without the names
    '$getConstraintStore'(LVars,Store,Cout,_),

        % obtain the tree
        throwConstraints(GoalTree),
    name_of_variable(T,NameT),
    member_relax((NameT,V),VarsGoalExe).

         
       
% getVars(+A,-B). Functionally: B=map first A
getVars([],[]):-!.
getVars([(N,V)|Xs],Vs) :- getVars(Xs,Vs),member(V,Vs),!.
getVars([(N,V)|Xs],[V|Vs]) :- !,getVars(Xs,Vs).

%%%%%%%%%%%%%%%% store the variables of the goal in order to use their original names
%%%%%%%%%%%%%%%% when generating variable names in pVal
storeGoalVars([]).
storeGoalVars([(N,V)|Xs]) :-
        var(V),
        name(N,Name),
        \+ (Name=="$$T"), % this variable represents the CT; it is not part of the original goal
        !,
        putName(V,Name),
        storeGoalVars(Xs).
storeGoalVars([(_N,_V)|Xs]) :-
        !,
        storeGoalVars(Xs).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
equalSets(A,B) :- included(A,B),included(B,A).

included([],_) :- !.
included([A|Xs],L) :- !, member(A,L),included(Xs,L).

%%%%%%%%%%%%%%%%%%%%%%%%%%%
deleteVars :-
      % Rafa 07-11-04 Esto estaba en create Computation Goal pero creo que es mejor aqu�
      % Hacemos retract de las variables introducidas en el pVal.
     (
        retractalllatestNameVar
      ;
        true
     ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% throwGoal(+G,+Vars)
% throws G ensuring that no "non-debugging" variable of Vars in instantiated.
% The "debugging" variables are assumed to have a name starting with "$"
throwGoal(G,Vars) :-
      getNAnswer(N),
      resetDebugCounter,
      !,
      throwConstraints(G),
      incDebugCounter,
      getDebugCounter(M),
      M>=N,
      removeDebugCounter.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

restoreFile(FileStr) :-
        !,
        % volvemos a cargar el programa original para continuar con Toy
    append(FileStr,".pl",FileNameStr),
    name(FileName,FileNameStr),
%   write(' Reloading '),
%   write(FileName), nl, nl,
    open('err.txt',write,H), prolog_flag(user_error,N,H),
%   load_files(FileName),
    load_files(FileName,[if(changed)]),
    prolog_flag(user_error,M,N),
    close(H),
    nl.


% Graphical Interface
useGraphicalInterface(Answer) :-
    !,
        nl,
    write('Use graphical interface?  ([y]es / [n]ot) / [a]bort)  '),
        getOracleAnswer(Answer),
    nl.



%-----------------------------------------------------------------------------%
% prepareDebugGoal(+Goal,-VarsGoalExe,-GoalTran,-GoalTree,-Cout)
% El objetivo nos viene de mala manera: tiene las variables sin instanciar,
% esta en formato que queda tras la traduccion del analisis sintactico, y
% tenemos que cambiarlo, lo que se hace en 4 pasos:
%     1) Se transforma al formato de depuracion (con returnResult y esas cosas).
%     2) Se traduce el objetivo a un objetivo ejecutable.
%     3) Se cambian las variables que estan instanciadas en la lista Vars por
%         sus valores, que corresponden a los de la respuesta 'chunga'.
%     4) Las variables no instanciadas se sustituyen por constantes
% Depues de eso ya se puede lanzar el objetivo modificado
%  Rafa 15-12-04: A�ado Cout como valor de salida
%  05-06-2005: Ahora el objetivo transformado se devuelve en dos partes, GoalTran y GoalTree
%              GoalTran contiene el objetivo sin la evaluacion del �rbol.
%               GoalTree contiene la igualdad estricta que generar� el �rbol
%-----------------------------------------------------------------------------          
 
prepareDebugGoal(where(Goal,Where),VarsGoalExe,GoalExe,GoalTree,Cout) :-
    !,
    % Rafa 15-12-04: _Cout is the final store, but we are interested in the 
        % store before the tree es evaluated   
    convertGoalToExecutableCode(Goal,Where,GoalExe1,VarsGoalExe,_Cout),
        % replace the last equal 
        replaceLastEqual(GoalExe1,GoalExe,GoalTree,Cout).
    % Las sustituciones de variable por variable en la respuesta computada a�n no han sido aplicadas
    % lo hacemos
    % Rafa 06/06/05 ya no hace falta transformVariables(Vars,VarsGoalExe).
         

% el �ltimo se cambia dependiendo del navegador que se vaya a utilizar
replaceLastEqual([equal(L,R,A,B)],[],Output,A) :-
    (ddtFlag,
     Output = [equalDebug(L,R,A,B)]
    ;
        Output = ['$topDown'(L,R,A,B)]
       % Output = [equal(L,R,A,B)]
    ),
    !.
replaceLastEqual([X,Y|Rest],[X|NewRest], End,Cout) :-  replaceLastEqual([Y|Rest], NewRest, End,Cout).


/*
%----------------------------------------------------------------------------%
% instantiateGoal(+Goal,+VarsGoal,+Vars,-NewVarsGoal,-GoalT)
% Goal es el objetivo (en formato .tmp.out) y Vars es la respuesta que se quiere
% depurar. Instanciamos Goal con Vars.
% - VarsGoal son las variables del objetivo.
% - Vars es lo mismo pero como la examinamos recursivamente tiene la parte de
%   VarsGoal que nos falta por tratar.
% - NewVarsGoal es VarsGoal + las nuevas variables generadas en la respuesta
%----------------------------------------------------------------------------%
instantiateGoal(Goal,VarsGoal,[],VarsGoal,Goal) :-
    !.

instantiateGoal(Goal,VarsGoal,[(Var,Value)|Xs],NewVarsGoal, GoalT) :-
    (
     var(Value),
     %  no hace falta sustituir; esto se hace mas adelante
     instantiateGoal(Goal,VarsGoal,Xs,NewVarsGoal,GoalT)
    ;
     exeToTmp(Value,VarsGoal,NewVarsGoal1,ValueTmp),
     substituteVar(Var,ValueTmp,Goal,GoalT1),
     instantiateGoal(GoalT1,NewVarsGoal1,Xs,NewVarsGoal,GoalT)
    ),
    !.


%----------------------------------------------------------------------------%
% includeNewVariable(+Var,+VarsGoal,-NewVarsGoal,-NewVar)
% incluye la variable en la lista de variables si no estaba ya
% para eso le da un nombre nuevo.
% Tambien devuelve la nueva variable en formato tmp en 'NewVar'
%----------------------------------------------------------------------------%
includeNewVariable(Value,VarsGoal,NewVarsGoal,'$var'(VarName)):-
    (
     % si esta no cambiamos nada
         lookForVar(Value,VarsGoal,VarName),
         NewVarsGoal=VarsGoal
        ;
         % es una var. nueva; la incluimos
         nextVarName(Var1),
     name(VarName,Var1),
     % guardamos el nuevo nombre en la B.D. borrando el antiguo
     (
      retractlatestNameVar(_)
     ;
      true
     ),
     assertlatestNameVar(Var1),
     NewVarsGoal = [(VarName,Value)|VarsGoal]
    ),
    !.



%----------------------------------------------------------------------------%
% lookForVar(+Value,-VarsGoal,-VarName)
% tiene exito si existe una pareja de la forma (_,Value) en VarsGoal.
% Value tiene que coincidir exactamente (==)
%----------------------------------------------------------------------------%
lookForVar(Value,[(NameVar,ValueVar)|R],NameVarOut):-
    (
     Value == ValueVar,
     NameVarOut = NameVar
    ;
     lookForVar(Value,R,NameVarOut)
    ),
    !.




substituteVar(Var,ValueTmp,Goal,GoalT) :-
        % si es variable 2 posiblidades:
    isVariable(Goal),
    (
     % es la que estamos buscando (se sustituye por su valor en la respuesta)
     name_of_variable(Goal,Var),
     GoalT = ValueTmp
    ;
     % es otra variable (se deja igual)
     GoalT = Goal
    ),
    !.

substituteVar(Var,ValueTmp,Goal,Goal) :-
    atom(Goal),
    !.

substituteVar(Var,ValueTmp,Goal,GoalT) :-
    !,
    % nos descomponemos
    Goal =.. [Name|Args],
    substituteVarArgs(Var,ValueTmp,Args,ArgsT),
    % nos recomponemos
    GoalT =.. [Name|ArgsT].

substituteVarArgs(Var,ValueTmp,[],[]) :-
    !.

substituteVarArgs(Var,ValueTmp,[H|R],[HT|RT]) :-
    !,
    substituteVar(Var,ValueTmp,H,HT),
    substituteVarArgs(Var,ValueTmp,R,RT).




%-----------------------------------------------------------------------------%
% exeToTmp(Value,VarsGoal,NewVarsGoal,ValueTmp)
% Para hacer la sustitucion de la respuesta en el objetivo tenemos que tener
% en cuenta que el  objetivo esta en formato tmp.out, mientras que los valores
% de la respuesta estan en formato Toy ejecutable.
% Aqui se convierte el valor Toy ejecutable en formato tmp.out
%-----------------------------------------------------------------------------%

% los numeros tal cual: suponemos que no existen enteros en ejecucion (!).
exeToTmp(N,VarsGoal,VarsGoal,'$float'(N)):-
    float(N),
    !.


% una variable nueva
exeToTmp(Var,VarsGoal,NewVarsGoal,NewVar):-
    var(Var),
    !,
    includeNewVariable(Var,VarsGoal,NewVarsGoal,NewVar).


% var
exeToTmp('$var'(V),VarsGoal,VarsGoal,'$var'(V)):-!.


%char
exeToTmp('$char'(C),VarsGoal,VarsGoal,'$char'(C)):-!.


exeToTmp(Exp,VarsGoal,NewVarsGoal,ExpT):-
    Exp=..[Name|ArgsExp],
    (
        Name= '$eqFun',
        Name1= '=='

    ;
        Name= '$notEqFun',
        Name1= '/='
    ;
        Name1=Name
    ),
    exeToTmpArgs(ArgsExp,VarsGoal,NewVarsGoal,ArgsExpT),
    ExpT=..[Name1|ArgsExpT].


exeToTmpArgs([],VarsGoal,VarsGoal,[]):-
    !.
exeToTmpArgs([ArgExp|Rest],VarsGoal,NewVarsGoal,[ArgExpT|Rr]):-
    !,
    exeToTmp(ArgExp,VarsGoal,NewVarsGoal1,ArgExpT),
    exeToTmpArgs(Rest,NewVarsGoal1,NewVarsGoal,Rr).



*/

transformVariables(_Vars,[]) :-
    !.

transformVariables(Vars,[(Var,Value)|R]) :-
    (
     member_relax((Var,Value1),Vars),
     updateVar(Var,Value1,Value)
    ;
     true
    ),
    % 04/01/01
        transformVariables(Vars,R),
    !.


updateVar(NameVar,Value1,Value2):-
    (
     var(Value1),

/* Rafa 17-11-04 --> Las variables libres ya no se sustituyen por constantes
     name(NameVar,NameVar1),
     prologStringToToyString(varToString,NameVar1,NameVar2),
% rafa: 01-08-01
% cambio la transformaci�n de variables, poniendo delante una  constructora
     Value1=pValVar(NameVar2),
*/
         Value2=Value1
    ;
     true % ya esta cambiada la variable por el valor en el objetivo
    ),
    !.




%----------------------------------------------------------------------------%
% prepareDebug(+FileNameStr,+Goal,-GoalT,-T)
% - FileNameStr: Nombre, como cadena de caracteres, del fichero fuente,
%                sin incluir la extension.
% - Goal       : Objetivo que se esta depurando. Tiene forma de condicion con
%                where. El formato debe ser where(Cond,Where), donde 'Cond'
%        y 'Where' tienen el formato como en los fichero .tmp.out.
% - GoalT      : Objetivo traducido para la depuracion
% - T          : Variable que aparece en GoalT y que representa el arbol de
%                prueba del objetivo.
% Descripcion  : La preparacion para la depuracion consta de dos partes:
%         1) Traduccion del objetivo.
%                 2) Traduccion del programa fuente.
%                La fase 1) se realiza cada vez que se desea depurar, pero la
%                fase 2) solo es necesaria si esta transformacion no fue hecha
%        anteriormente o el programa fuente ha sido modificado.
%----------------------------------------------------------------------------%
prepareDebug(FileNameStr,Goal,GoalT,T) :-
        !,
        % cargamos el .tmp.out en memoria si no esta ya
    append(FileNameStr,".tmp.out", FileTmpStr),
    name(FileTmp,FileTmpStr),
    open('err.txt',write,H), prolog_flag(user_error,N,H),

        (file_exists(FileTmp),
     load_files(FileTmp,[if(changed)]),
     prolog_flag(user_error,M,N),close(H),
     % 1) traducimos el objetivo
     createDebugGoal(Goal,GoalT,T),
     % 2) Traducimos el programa, si es necesario
     createDebugFile(FileNameStr)
         ;
          nl,write('Nothing to debug'),nl,nl
         ),
    !.


%----------------------------------------------------------------------------%
% createDebugGoal(+where(Goal,Where),-where(GoalT,WhereT),-T)
% transformamos un objetivo where(Goal,Where), en un objetivo para la
% depuracion. Parte de este objetivo incluye el calculo del proof tree T,
% que devolvemos aparte
%----------------------------------------------------------------------------%
createDebugGoal(where(Condition,Where),where(ConditionT,WhereT),T) :-
    !,
    transformRule(rule('$$main',true,Condition,Where,0),0,_,
                  rule('$$main',Body,Condition1,WhereT,0)),
    createDebugCondition(Body,Condition1,ConditionT,T).


%----------------------------------------------------------------------------%
% createDebugCondition(Body,Condition1,ConditionT,T)
% Annade el cuerpo como ultima condicion, condicion de la forma Body==(true,T)
%----------------------------------------------------------------------------%
createDebugCondition(Body,Condition1,ConditionT,'$var'('$$T')):-
    !,
    append(Condition1,[Body=='$$tup'((true,'$var'('$$T')))],ConditionT).




%----------------------------------------------------------------------------%
% createDebugFile(+FileNameStr)
% Hace la transformacion de programas para la depuracion.
% Transforma el FileNameStr.tmp.out en el FileNameStr.debug.pl, pasando por un
% fichero intermedio FileNameStr.debug.tmp.out
% Si el fichero FileNameStr.debug.pl ya existe, solo lo carga
%----------------------------------------------------------------------------%

createDebugFile(FileNameStr) :-
    append(FileNameStr,".debug.pl",FileDebugStr),
    name(FileDebug,FileDebugStr),
    (
     % creamos el fichero si no existe
     file_exists(FileDebug)
    ;
     transformTmpOut(FileNameStr),
     transformDebugTmpOut(FileNameStr)
    ),
       
    open('err.txt',write,H), prolog_flag(user_error,N,H),
    % load_files(FileDebug,[if(changed)]),
    load_files(FileDebug),
    prolog_flag(user_error,M,N),close(H),
    !.



%----------------------------------------------------------------------------%
% transformDebugTmpOut(+FileNameStr)
% Transforma un fichero  FileName.debug.tmp.out en el fichero FileName.debug.pl.
% El codigo se genera saltandonos la inferencia de tipos.
%----------------------------------------------------------------------------%
transformDebugTmpOut(FileNameStr) :-
    !,
    % creamos los nombres de los ficheros fuente y destino
    append(FileNameStr,".debug.pl",FileDebugStr),
    name(FileDebug,FileDebugStr),
        open(FileDebug,write,HDebug), % abrimos para escritura el fichero de salida
    transformDebugTmpOutHandle(HDebug,FileNameStr),
    close(HDebug).



transformDebugTmpOutHandle(HDebug,FileNameStr) :-
    !,
    assertdebugando,
    generateCode(HDebug,FileNameStr),
    retractdebugando.




%----------------------------------------------------------------------------%
% transformTmpOut(+FileNameStr)
% Transforma un fichero  FileName.tmp.out en el fichero FileName.debug.tmp.out,
% incluyendo la inf. para la depuracion. Se supone que FileName esta cargado
% en memoria.
%----------------------------------------------------------------------------%
transformTmpOut(FileNameStr) :-
    !,
    % creamos los nombres de los ficheros fuente y destino
    append(FileNameStr,".tmp.out", FileTmpStr),
    append(FileNameStr,".debug.tmp.out",FileDebugStr),
    name(FileTmp,FileTmpStr),
    name(FileDebug,FileDebugStr),
    open(FileTmp,read,HTmp),    % abrimos para lectura el fichero de entrada
        open(FileDebug,write,HDebug), % abrimos para escritura el fichero de salida
    transformTmpOut(HTmp,HDebug),
    % introducimos la informacion auxiliar necesaria:
    includeAdditionalClauses(HDebug),
    close(HTmp),
    close(HDebug),
    open('err.txt',write,H), prolog_flag(user_error,N,H),
    load_files(FileDebug,[if(changed)]),
    prolog_flag(user_error,M,N), close(H).

transformTmpOut(HTmp,HDebug) :-
        % tratamos cada una de las clausulas del fichero de entrada
    read(HTmp,Clause),
    % asegurarse de que no es fin de fichero
        \+ endFile(Clause),
        !,
    transformClause(Clause,ListClauses),
    % una clausula se transforma en una lista de clausulas; escribir todas
    writeSection(HDebug,ListClauses),
    % la siguiente, por favor
    transformTmpOut(HTmp,HDebug).

transformTmpOut(HTmp,HDebug) :-
    !.



%----------------------------------------------------------------------------%
% includeAdditionalClauses(+HDebug)
% Incluye en el fichero FileName.debug.tmp.out, la inf. adicional necesaria
% para la depuracion. Esta informacion se obtiene del fichero .tmp.out resultante
% de traducir el siguiente programa:
%
%    //////////////////////////////////////////
%
% type fun = [char]
% type body = [char]
% type ruleNum = [char]
% type args = [pVal]
% type result = pVal
% type conds = [pVal]
%
% data cTree = cTreeNode fun args result body conds ruleNum [(pVal,cTree)]
%                  | cTreeVoid
%
% cTreeReturnResult Fun ArgsInst Res BodyInst CondsInst RuleNum Cts =
%   (Res, cTreeNode Fun ArgsInst (dVal Res) BodyInst CondsInst RuleNum Cts)
%
%
% cTreeClean [] = []
% cTreeClean [(P,X)|Xs] = if P==pValBottom
%                   then cTreeClean Xs
%                   else if X==cTreeVoid
%                        then cTreeClean Xs
%                        else [X| cTreeClean Xs]
%
%
% concat [] = []
% concat [[]|Rx] = concat Rx
% concat [[X|Xs]|Rx] = [X|concat [Xs|Rx]]
%   ///////////////////////////////////////////
%
%----------------------------------------------------------------------------%
includeAdditionalClauses(HDebug) :-
    !,
        % tipo cTree
%   writeSection(HDebug,
% cdata('cTreeNode',7,(char:[]->pVal:[]->pVal->char:[]->pVal:[]->char:[]->'$$tuple'((pVal,'cTree')):[]->'cTree'),0)
%        ),
%   writeSection(HDebug,  cdata('cTreeVoid',0,'cTree',0) ),

    % funcion cTreeReturnResult
    writeSection(HDebug, depends('cTreeReturnResult',pVal) ),
    writeSection(HDebug,
             fun('cTreeReturnResult',7,[rule('cTreeReturnResult'('$var'('Fun'),'$var'('ArgsInst'),'$var'('Res'),'$var'('BodyInst'),'$var'('CondsInst'),'$var'('RuleNum'),'$var'('Cts')),'$$tup'(('$var'('Res'),'cTreeNode'('$var'('Fun'),'$var'('ArgsInst'),dVal('$var'('Res')),'$var'('BodyInst'),'$var'('CondsInst'),'$var'('RuleNum'),'$var'('Cts')))),[],[],0)],0)
            ),
    % funcion cTreeClean
    writeSection(HDebug, depends('cTreeClean',if_then_else) ),
    writeSection(HDebug, depends('cTreeClean',==) ),
    writeSection(HDebug, depends('cTreeClean','cTreeClean') ),


    writeSection(HDebug,
            fun('cTreeClean',1,[rule('cTreeClean'([]),[],[],[],10),rule('cTreeClean'('$$tup'(('$var'('Result'),'$var'('T'))):'$var'('R')),if_then_else('$var'('Result')==pValBottom,'cTreeClean'('$var'('R')),if_then_else('$var'('T')=='cTreeVoid','cTreeClean'('$var'('R')),'$var'('T'):'cTreeClean'('$var'('R')))),[],[],11)],10)
                 ),
    writeSection(HDebug, depends('$concat','$concat') ),
    writeSection(HDebug,
            fun('$concat',1,[rule('$concat'([]),[],[],[],22),rule('$concat'([]:'$var'('Rx')),'$concat'('$var'('Rx')),[],[],23),rule('$concat'(('$var'('X'):'$var'('Xs')):'$var'('Rx')),'$var'('X'):'$concat'('$var'('Xs'):'$var'('Rx')),[],[],24)],22)
                 ).






%----------------------------------------------------------------------------%
% transformClause(+Clause, -List)
% Tratamiento de una clausula del fichero .tmp.out
%----------------------------------------------------------------------------%
transformClause(Clause,List):-
    (
     Clause = cdata(_,_,_,_),
     transformCdata(Clause,List)
    ;
     Clause = infix(_,_,_,_),
     transformInfix(Clause,List)
    ;
     Clause = ftype(_,_,_,_),
     transformFtype(Clause,List)
    ;
     Clause = depends(_,_),
     transformDepends(Clause,List)
    ;
     Clause = primitive(_,_,_),
     transformPrimitive(Clause,List)
    ;
     Clause = fun(_,_,_,_),
     transformFun(Clause,List)
    ;
     List = [Clause]
    ),
    !.



%----------------------------------------------------------------------------%
% transformCdata(+cdata(Name,Arity,Type,Line), -List)
% Tratamiento de una clausula cdata del fichero .tmp.out
%----------------------------------------------------------------------------%
transformCdata(cdata(Name,Arity,Type,Line),List):-
    !,
    createAuxConsts(Name,Arity,Arity,Name,ListFuns),
    append(ListFuns,[cdata(Name,Arity,Type,Line)],List).





%----------------------------------------------------------------------------%
% createAuxConsts(+Name,+Arity,+Number,+LastNameFun,-ListFuns)
% Crea las funciones auxiliares para Name. Las funciones auxiliares son:
% NameFun$1,NameFun$2,...,NameFun$Number
%----------------------------------------------------------------------------%
createAuxConsts(NameFun,Arity,Number,LastFunIn,[DependClause, FunAux| More]) :-
    Number > 0,
    !,
    createAuxConst(NameFun,Arity,Number,LastFunIn,LastFunOut,FunAux,DependClause),
    Number2 is Number-1,
    createAuxConsts(NameFun,Arity,Number2,LastFunOut,More).

createAuxConsts(_NameFun,_Arity,_Number,LastFunIn,[]) :-
    !.


createAuxConst(NameFun,Arity,Number,LastFunIn,NameAux,FunAux, DependClause) :-
    !,
    generateNameFunAux(NameFun,Number, NameAux),
    generateArgsFunAux(Number,ListVars),
    generateBodyFunAux(LastFunIn,ListVars,BodyAux),
    (
     NameFun==LastFunIn,
     DependClause = []
    ;
     generateDependFunAux(LastFunIn,NameAux,DependClause)
    ),
    % construimos la cabeza de la regla
    HeadRule =.. [NameAux|ListVars],
    Rule = rule(HeadRule,BodyAux,[],[],0),
    FunAux = fun(NameAux, Number, [Rule], 0).











%----------------------------------------------------------------------------%
% transformInfix(+infix(Name,Asoc,Priority,Line), -List)
% Tratamiento de una clausula infix del fichero .tmp.out
%----------------------------------------------------------------------------%
transformInfix(infix(Name,Asoc,Prior,Line),[infix(Name,Asoc,Prior,Line)]):-
    !.



%----------------------------------------------------------------------------%
% transformFtype(+ftype(Name,Arity,Type,Line), -List)
% Tratamiento de una clausula ftype del fichero .tmp.out
%----------------------------------------------------------------------------%
transformFtype(ftype(Name,Arity,Type,Line),[]):-
    !.


%----------------------------------------------------------------------------%
% transformDepends(+depends(NameFun1,NameFun2), -List)
% Tratamiento de una clausula depends del fichero .tmp.out
%----------------------------------------------------------------------------%
transformDepends(depends(NameFun1,NameFun2),[]):-
    !.



%----------------------------------------------------------------------------%
% transformPrimitive(+primitive(Name,Type,Line), -List)
% Tratamiento de una clausula primitive del fichero .tmp.out
%----------------------------------------------------------------------------%
transformPrimitive(primitive(Name,Type,Line), List):-
    !,
    ftype(Name,Arity,_Type,_Line),
    createAuxFuns(Name,Arity,Arity,Name,ListFuns),
    append(ListFuns,[primitive(Name,Type,Line)],List).






%----------------------------------------------------------------------------%
% transformFun(+fun(NameFun,Arity,ListRules,Line), -List)
% Tratamiento de una clausula fun del fichero .tmp.out
%----------------------------------------------------------------------------%
transformFun(fun(NameFun,Arity,ListRules,Line), List) :-
    !,
    Number is Arity-1,
    createAuxFuns(NameFun,Arity,Number,NameFun,ListFuns),
    transformRules(ListRules,1,NewClauses,ListRules2),
    concatLsts([ListFuns,NewClauses,
           [depends(NameFun,'cTreeReturnResult'),depends(NameFun,dVal)],
           [fun(NameFun,Arity,ListRules2,Line)]],
           List).


%----------------------------------------------------------------------------%
% createAuxFuns(+NameFun,+Arity,+Number,+LastNameFun,-ListFuns)
% Crea las funciones auxiliares para NameFun. Las funciones auxiliares son:
% NameFun$1,NameFun$2,...,NameFun$Number
%----------------------------------------------------------------------------%

createAuxFuns(NameFun,Arity,Number,LastFunIn,[DependClause,FunAux| More]) :-
    Number > 0,
    !,
    createAuxFun(NameFun,Arity,Number,LastFunIn,LastFunOut,FunAux,DependClause),
    Number2 is Number-1,
    createAuxFuns(NameFun,Arity,Number2,LastFunOut,More).



createAuxFun(NameFun,Arity,Number,LastFunIn,NameAux,FunAux, DependClause) :-
    generateNameFunAux(NameFun,Number, NameAux),
    generateArgsFunAux(Number,ListVars),
    generateBodyFunAux(LastFunIn,ListVars,BodyAux),
    generateDependFunAux(LastFunIn,NameAux,DependClause),
    % construimos la cabeza de la regla
    HeadRule =.. [NameAux|ListVars],
    Rule = rule(HeadRule,BodyAux,[],[],0),
    FunAux = fun(NameAux, Number, [Rule], 0),
    % para que la siguiente vez la primera variable sea la 'A'
    (
     retractlatestNameVar(_)
    ;
     true
    ),
    !.



createAuxFuns(_NameFun,_Arity,_Number,LastFunIn,[]) :-
    !.



%----------------------------------------------------------------------------%
% generateNameFunAux(+NameFun,+Number,-NameAux)
% Genera el nombre de la funcion auxiliar. Si el nombre de la funcion es
% NameFun, entonces el nombre de la funcion auxiliar es NameFun$Number
%----------------------------------------------------------------------------%
generateNameFunAux(NameFun,Number, NameAux):-
    !,
    name(NameFun,NameFun1),
    name(Number,Number1),
    concatLsts([NameFun1,[36],Number1],NameAux1),   % 36 --> $
    name(NameAux,NameAux1).


%----------------------------------------------------------------------------%
% generateArgsFunAux(+Number,-ListVars)
% Genera los argumentos de las funciones auxiliares. Habra tantos argumentos
% como indique Number, y estos argumentos seran variables nuevas
%----------------------------------------------------------------------------%
generateArgsFunAux(0,[]):- !.
generateArgsFunAux(Number,['$var'(Var)|ListVars]):-
    !,
    nextVarName(Var1),
    name(Var,Var1),
    Number2 is Number-1,
    % guardamos el nuevo nombre en la B.D. borrando el antiguo
    (
     retractlatestNameVar(_)
    ;
     true
    ),
    assertlatestNameVar(Var1),
    generateArgsFunAux(Number2,ListVars).


%----------------------------------------------------------------------------%
% generateBodyFunAux(+NameFun,+ListVars,-BodyAux)
% Genera el cuerpo de las funciones auxiliares. Las funciones auxiliares para
% f de aridad n son:
% f$1 X1 = (f$2 X1,'cTreeVoid')
% ....
% f$n-1 X1 ... Xn-1 = (f X1 ... Xn-1,'cTreeVoid')
%----------------------------------------------------------------------------%
generateBodyFunAux(LastFunIn,ListVars,BodyAux):-
    !,
    Body =.. [LastFunIn|ListVars],
    BodyAux =.. ['$$tup'|[(Body,'cTreeVoid')]].


%----------------------------------------------------------------------------%
% generateDependFunAux(+NameFun1,+NameFun2,DependClause)
% genera la nueva clausula depends que se obtiene debido a la nueva dependencia
% que se obtiene entre las funciones auxiliares
%----------------------------------------------------------------------------%
generateDependFunAux(NameFun1,NameFun2,DependClause):-
    !,
    DependClause = depends(NameFun2,NameFun1).



%----------------------------------------------------------------------------%
% transformRules(+ListRules,+RuleNumber,-NewClauses,-ListRules2)
% Transforma las reglas de la funcion para que devuelvan el arbol de la
% depuracion (ListRules2). Ademas genera nuevas clausulas auxiliares
% (NewClauses).
%----------------------------------------------------------------------------%
transformRules([],_N,[],[]) :-
    !.

transformRules([Rule|ResRules],RuleNumber,NewClauses,[Rule1|ListRules2]):-
    !,
    transformRule(Rule,RuleNumber,NewClauses1,Rule1),
    NewRuleNumber is RuleNumber+1,
    transformRules(ResRules,NewRuleNumber,NewClauses2,ListRules2),
    unionLsts([NewClauses1,NewClauses2],[],NewClauses).


transformRule(Rule,RuleNumber,NewClauses,RuleOut):-
    !,
    transformStep1(Rule,NewClauses,RuleOut1),
    transformStep2(RuleOut1,RuleNumber,RuleOut2),
    createInstanceWheres(Rule,NewWhereDecls),
    wheresMix(NewWhereDecls,RuleOut2,RuleOut).


wheresMix(ListWhere,rule(Head,Body,Condition,Where,Line),
               rule(Head,Body,Condition,WhereOut,Line)):-
    !,
    concatLsts([ListWhere,Where],WhereOut).

createInstanceWheres(rule(Head,Body,Condition,Where,Line),
             ['='('$var'('$Args'),Args2,0),
% Ojo             '='('$var'('$Body'),RhsBodySimplifyed,0),
              '='('$var'('$Body'),[],0),
% Ojo             '='('$var'('$Conds'),ConcatRhsCondsSimplifyed,0)]) :-
              '='('$var'('$Conds'),[],0)]) :-

    !,
    Head =.. [F|LArgs],
% rafa 05-02-03 La  variable Args2 no se usaba..la vuelvo a introducir
    createArg2(LArgs,Args2),
%   createInstanceList(LArgs,RhsArgs),
    atomToString(varToPVal,Body,RhsBody),
    createInstanceList(Condition,RhsConds),
        % 24-03-02 rafa
%        simplifyConcat('$concat'(RhsArgs),ConcatRhsArgsSimplifyed),
        simplifyConcat(RhsBody,RhsBodySimplifyed),
        simplifyConcat('$concat'(RhsConds),ConcatRhsCondsSimplifyed).



% ------- 24-03-02 rafa -------------

simplifyConcat('$concat'([]),[]):-!.
simplifyConcat('$concat'(A:[]),B) :- simplifyConcat(A,B).
simplifyConcat('$concat'(X:Xs),LOut):-
        simplifyList((X:Xs),L),
        ( X:Xs = L,
          LOut = '$concat'(X:Xs)
         ;
          % if something was simplied
         simplifyConcat('$concat'(L),LOut)
        ),
        !.
% otherwise nothing can be simplified
simplifyConcat(Other,Other):-!.

simplifyList([],[]):-!.
simplifyList(X:Xs,LOut):-
   !,
   simplifyConcat(X,X2),
   simplifyConcat(Xs,Xs2),
   joinList(X2:Xs2,LOut).


joinList(('$char'(A):[]):[], ('$char'(A):[]):[]) :-!.


joinList(('$char'(34):[]):('$char'(34):[]):R,LOut) :-
        !,
        joinList(R,LOut).

joinList(('$char'(A):[]):('$char'(34):[]):R,LOut) :-
        !,
        joinList(('$char'(A):[]):R,LOut).

joinList(('$char'(34):[]):('$char'(B):[]):R,LOut) :-
        !,
        joinList(('$char'(B):[]):R,LOut).

joinList(('$char'(A):[]):('$char'(B):[]):R,LOut) :-
        joinList(('$char'(B):[]):R,Rs),
         Rs = ('$char'(B):L):R2,
         LOut = ('$char'(A):'$char'(B):L):R2,
        !.

joinList(X:Xs,X2:Xs2) :-
        !,
        simplifyConcat(X,X2),
        joinList(Xs,Xs2).

joinList(A,A) :- !.

%------------------------------------



createInstanceList([],[]):-
    !.

% Depu 28/11/00 la lista de salida debe ser una lista Toy
createInstanceList([One|Rest],':'(OneOut,RestOut)):-
    atomToString(varToPVal,One,OneOut),
    createInstanceList(Rest,RestOut1),
    (
     RestOut1 == [],
     RestOut = RestOut1
    ;
     % si hay mas argumentos insertamos un blanco
     RestOut = ':'('$char'(32):[],RestOut1)
    ),
    !.


% /////////////////////////////////////////////////////////////////////////////
% /////////////////////////////////////////////////////////////////////////////
% /                                       /
% /       PASO 1: sustituir aplicaciones por funciones auxiliares         /
% /                                       /
% /////////////////////////////////////////////////////////////////////////////
% /////////////////////////////////////////////////////////////////////////////

%----------------------------------------------------------------------------%
% transformStep1(+Rule,-NewClauses,-RuleOut)
% El primer paso de la transformacion:
%       - cambiamos los nombres de las funciones , primitivas, constructoras
%      por funciones auxiliares.
%   - Generamos los depends.
%----------------------------------------------------------------------------%
transformStep1(rule(Head,Body,Condition,Where,Line),NewClauses,
           rule(Head1,Body1,Condition1,Where1,Line)) :-
    !,
    Head =.. [NameFun|Args],
    transformStep1Head(NameFun,Args,NewClauses1,Head1),
    transformStep1Body(NameFun,Body,NewClauses2,Body1),
    transformStep1Condition(NameFun,Condition,NewClauses3,Condition1),
    transformStep1Where(NameFun,Where,NewClauses4,Where1),
    unionLsts([NewClauses1,NewClauses2,NewClauses3,NewClauses4],[],NewClauses).



% Head

transformStep1Head(NameFun,Args,NewClauses,Head1):-
    !,
    transformStep1Terms(NameFun,Args,NewClauses,ArgsOut),
    Head1 =.. [NameFun|ArgsOut].



transformStep1Terms(_NameFun,[],[],[]):-
    !.

transformStep1Terms(NameFun,[Term|Rest],NewClauses,[TermOut|RestOut]):-
    !,
    transformStep1Term(NameFun,Term,NewClauses1,TermOut),
    transformStep1Terms(NameFun,Rest,NewClauses2,RestOut),
    unionLsts([NewClauses1, NewClauses2],[], NewClauses).




transformStep1Term(NameFun,'$apply'(A,B),NewClauses,'$apply'(AOut,BOut)) :-
    !,
    transformStep1Term(NameFun,A,NewClauses1, AOut),
    transformStep1Term(NameFun,B,NewClauses2, BOut),
    unionLsts([NewClauses1,NewClauses2],[],NewClauses).

transformStep1Term(_NameFun,'$var'(A),[],'$var'(A)) :-
    !.

transformStep1Term(_NameFun,'$int'(A),[],'$int'(A)):-
    !.

transformStep1Term(_NameFun,'$float'(A),[],'$float'(A)):-
    !.

transformStep1Term(_NameFun,'$char'(A),[],'$char'(A)):-
    !.

transformStep1Term(NameFun,'$$tup'((A,B)),NewClauses,'$$tup'((AOut,BOut))):-
    !,
    transformStep1Terms(NameFun,[A,B],NewClauses,[AOut,BOut]).

transformStep1Term(NameFun,App,NewClauses,AppOut) :-
    !,
    App =.. [NameApp|Args],
    transformStep1Terms(NameFun,Args,NewClauses1,ArgsOut),
    length(Args,N),
    transformStep1App(NameFun,NameApp,N,NewClauses2,NameAppOut),
    AppOut =.. [NameAppOut|ArgsOut],
    unionLsts([NewClauses1,NewClauses2],[],NewClauses).


transformStep1App(NameFun,NameApp,N,NewClauses,NameAppOut):-
    !,
    % distinguimos casos
    (
     % si es primitiva
     primitive(NameApp, _Type, _Line),
     % sacamos su aridad de la clausula ftype:
     % Ojo: Suponemos que la aridad de tipo (del ftype) es la de programa
     % Si no tenemos un problema.
     ftype(NameApp,Arity,_Type,_Line),
     transformStep1Prim(NameFun,NameApp,Arity,N,NewClauses,NameAppOut)
    ;
     % si es constructora
     cdata(NameApp,Arity,_Type,_Line),
     transformStep1Const(NameApp,Arity,N,NameAppOut),
     NewClauses = []
    ;
     % si es funcion
     fun(NameApp,Arity,_Rules,_Line),
     transformStep1Fun(NameFun,NameApp, Arity,N,NewClauses,NameAppOut)
    ).


transformStep1Prim(NameFun,NameApp,Arity,N,[depends(NameFun,NameAppOut)],NameAppOut):-
     !,
      % el nombre nuevo depende del numero de argumentos
     (
      N < Arity,
      N2 is N+1,
      generateNameFunAux(NameApp,N2,NameAppOut)
     ;
      generateNameFunAux(NameApp,Arity,NameAppOut)
     ).



transformStep1Const(NameApp,Arity,N,NameAppOut):-
    !,
    (
     N < Arity,
     N2 is N+1,
     generateNameFunAux(NameApp,N2,NameAppOut)
    ;
     NameAppOut = NameApp
    ).


transformStep1Fun(NameFun,NameApp, Arity,N,[depends(NameFun,NameAppOut)],NameAppOut):-
    !,
    (
     Arity1 is Arity-1,
     N < Arity1,
     N2 is N+1,
     generateNameFunAux(NameApp,N2,NameAppOut)
    ;
     NameAppOut = NameApp
    ).



% Body

transformStep1Body(NameFun,Body,NewClauses,BodyOut):-
    !,
    transformStep1Term(NameFun,Body,NewClauses,BodyOut).



% Condition

transformStep1Condition(_NameFun,[],[],[]):-
    !.

transformStep1Condition(NameFun,[Condition],NewClauses,[ConditionOut]):-
    !,
    transformStep1AtomCondition(NameFun,Condition,NewClauses,ConditionOut).

transformStep1Condition(NameFun,[Condition|RestCondition],NewClauses,[ConditionOut|RestOut]):-
    !,
    transformStep1AtomCondition(NameFun,Condition,NewClauses1,ConditionOut),
    transformStep1Condition(NameFun,RestCondition,NewClauses2,RestOut),
    unionLsts([NewClauses1,NewClauses2],[],NewClauses).



transformStep1AtomCondition(NameFun,Cond,NewClauses,CondOut):-
    !,
    Cond =.. [Name|Args],
    transformStep1Terms(NameFun,Args,NewClauses1,ArgsOut),
    % rafa 24-11-03 he incluido las dos siguientes l�neas.
    % si hay problemas eliminarlas y cambiar en la tercera 'NameAppOut' por 'Name',
    % y en la �ltima eliminar NewClauses2 de la lista
%   length(Args,N),
%   transformStep1App(NameFun,Name,N,NewClauses2,NameAppOut),
    CondOut =.. [Name|ArgsOut],
    unionLsts([[depends(NameFun,Name)],NewClauses1],[],NewClauses).




% Where

transformStep1Where(_NameFun,[],[],[]):-
    !.

transformStep1Where(NameFun,[Where|RestWhere],NewClauses,[WhereOut|RestWhereOut]):-
    !,
    transformStep1AtomWhere(NameFun,Where,NewClauses1,WhereOut),
    transformStep1Where(NameFun,RestWhere,NewClauses2,RestWhereOut),
    unionLsts([NewClauses1,NewClauses2],[],NewClauses).

transformStep1AtomWhere(NameFun,Where,NewClauses,WhereOut):-
    !,
    Where =.. ['='|[Arg1,Arg2,Line]],
    transformStep1Terms(NameFun,[Arg1,Arg2],NewClauses,[Arg1Out,Arg2Out]),
    WhereOut =.. ['='|[Arg1Out,Arg2Out,Line]].



% /////////////////////////////////////////////////////////////////////////////
% /////////////////////////////////////////////////////////////////////////////
% /                                       /
% /         PASO 2: where y returnResult                  /
% /                                       /
% /////////////////////////////////////////////////////////////////////////////
% /////////////////////////////////////////////////////////////////////////////

%----------------------------------------------------------------------------%
% transformStep2(+RuleIn,+RuleNumber,-RuleOut)
% Segundo paso de la transformacion de una regla: introduccion de where:
%   - Cambiar cada aplicacion e de la forma
%         '$apply'(F,G), f(r1...,rn), p(s1,...,sm) por una variable R
%         annadiendo where (R,T) = e.
%   - Introducir la llamada a la funcion auxiliar returnResult
%----------------------------------------------------------------------------%

transformStep2(rule(Head,Body,Cond,Where,Lin),RuleNumber,
               rule(Head,BodyOut,CondOut,WhereOut,Lin)):-
    !,
    % recopilamos las variables para asi asegurarnos que las que
        % se introduzcan en los where sean nuevas en la regla
    variables(rule(Head,Body,Cond,Where,Lin), [], VarsRule),
    transformStep2Wheres(Where,1,NumberIn1,VarsRule,VarsIn1,
                 NewWhere,WhereWhere,ListTreesWhere),
    transformStep2Conds(Cond,NumberIn1,NumberIn2,VarsIn1,VarsIn2,
                CondOut,WhereCond,ListTreesCond),
    transformStep2Body(Body,NumberIn2,NumberIn3,VarsIn2,VarsIn3,
               BodyOut1,WhereBody,ListTreesBody),
    concatLsts([WhereWhere,NewWhere,WhereCond,WhereBody],WhereOut),
    concatLsts([ListTreesWhere,ListTreesCond,ListTreesBody],ListTrees),
    createBody(Head,BodyOut1,RuleNumber,ListTrees,BodyOut).





transformStep2Wheres([],NumberIn,NumberIn,VarsRule,VarsRule,[],[],[]):-
    !.

transformStep2Wheres([Where|RestWhere],NumberIn,NumberOut,VarsRule,VarsOut,
                      [NewWhere|NewRestWhere],WhereWhere,ListTreesWhere):-
    !,
    transformStep2Where(Where,NumberIn,NumberIn1,VarsRule,VarsRuleIn1,
                        NewWhere,WhereWhere1,ListTreesWhere1),
    transformStep2Wheres(RestWhere,NumberIn1,NumberOut,VarsRuleIn1,VarsOut,
                        NewRestWhere,WhereWhere2,ListTreesWhere2),
    append(ListTreesWhere1,ListTreesWhere2,ListTreesWhere),
    append(WhereWhere1,WhereWhere2,WhereWhere).

transformStep2Where('='(Lhs,Rhs,Line),NumberIn,NumberOut,VarsRule,VarsRuleOut,
                        '='(LhsOut,RhsOut,Line),WhereWhere,ListTreesWhere) :-
    !,
    transformStep2Terms([Lhs,Rhs],NumberIn,NumberOut,VarsRule,VarsRuleOut,
                        [LhsOut,RhsOut],WhereWhere,ListTreesWhere).


transformStep2Terms([],Number,Number,Vars,Vars,[],[],[]) :-
    !.

transformStep2Terms([Term|RestTerm],NumberIn,NumberOut,VarsRule,VarsRuleOut,
                        [TermOut|RestTermOut],WhereWhere,ListTreesWhere):-

    !,
    transformStep2Term(Term,NumberIn,NumberIn1,VarsRule,VarsRuleIn1,
                        TermOut,WhereWhere1,ListTreesWhere1),
        transformStep2Terms(RestTerm,NumberIn1,NumberOut,VarsRuleIn1,VarsRuleOut,
                        RestTermOut,WhereWhere2,ListTreesWhere2),
    append(ListTreesWhere1,ListTreesWhere2,ListTreesWhere),
    append(WhereWhere1,WhereWhere2,WhereWhere).


transformStep2Term('$apply'(A,B),NumberIn,NumberOut,VarsRule,VarsRuleOut,
                        R,WhereWhere,ListTreesWhere)  :-

    !,
    transformStep2Terms([A,B],NumberIn,NumberIn1,VarsRule,VarsRuleIn1,
                [AOut,BOut],WhereWhere1,ListTreesWhere1),
    newVarsWhere(NumberIn1,NumberOut,VarsRuleIn1,VarsRuleOut,R,T),
    append(WhereWhere1,['='('$$tup'((R,T)),'$apply'(AOut,BOut),0)],WhereWhere),
        % rafa 30-01-00  se a�ade el arbol acompa�ado del dVal de su resultado
    append(ListTreesWhere1,['$$tup'((dVal(R),T))],ListTreesWhere).


transformStep2Term('$var'(A),NumberIn,NumberIn,VarsRule,VarsRule,
               '$var'(A),[],[])  :-

    !.

transformStep2Term('$int'(A),NumberIn,NumberIn,VarsRule,VarsRule,
               '$int'(A),[],[])  :-

    !.

transformStep2Term('$float'(A),NumberIn,NumberIn,VarsRule,VarsRule,
               '$float'(A),[],[])  :-

    !.

transformStep2Term('$char'(A),NumberIn,NumberIn,VarsRule,VarsRule,
               '$char'(A),[],[])  :-

    !.

transformStep2Term('$$tup'((A,B)),NumberIn,NumberOut,VarsRule,VarsRuleOut,
               '$$tup'((AOut,BOut)),WhereWhere,ListTreesWhere)
:-
    !,
    transformStep2Terms([A,B],NumberIn,NumberOut,VarsRule,VarsRuleOut,
                [AOut,BOut],WhereWhere,ListTreesWhere).



transformStep2Term(App,NumberIn,NumberOut,VarsRule,VarsRuleOut,
               AppOut,WhereWhere,ListTreesWhere)  :-

    !,
    App =.. [Name|Args],
    transformStep2Terms(Args,NumberIn,NumberIn1,VarsRule,VarsRuleIn1,
                ArgsOut,WhereWhere1,ListTreesWhere1),
    transformStep2App(Name,ArgsOut,NumberIn1,NumberOut,
              VarsRuleIn1,VarsRuleOut,AppOut,
              WhereWhere2,ListTreesWhere2),
    append(WhereWhere1,WhereWhere2,WhereWhere),
    append(ListTreesWhere1,ListTreesWhere2,ListTreesWhere).



transformStep2App(Name,Args,NumberIn,NumberIn,VarsRuleIn,VarsRuleIn,App,[],[]):-
        % los cdata que quedan tras el paso 1 no introducen where
    cdata(Name,_,_,_),
    !,
    App =.. [Name|Args].

transformStep2App(Name,Args,NumberIn,NumberOut,VarsRuleIn,VarsRuleOut,AppOut,
                  WhereWhere,ListTreesWhere):-
    fun(Name,Arity,_Rules,_Line),
    App =.. [Name|Args],
    length(Args,N),
    (
         % si es una funcion aplicada a todos sus argumentos,
         % introducir un where
     N == Arity,
     newVarsWhere(NumberIn,NumberOut,VarsRuleIn,VarsRuleOut,R,T),
     WhereWhere = ['='('$$tup'((R,T)),App,0)],
     AppOut = R,
     % Depu 24/11/00 mercedes
     % Aniadimos en la lista de arboles el dVal del resultado. Hace falta
     % porque quitaremos los arboles cuyo resultado no haya sido evaluado,
     % es decir, dVal(R) = "_".
     ListTreesWhere = ['$$tup'((dVal(R),T))]
    ;
         % si esta aplicada a menos argumentos dejarla tal cual
         % (sus argumentos ya fueron transformados antes de llegar aqui)
     AppOut = App,
     NumberOut = NumberIn,
     VarsRuleOut = VarsRuleIn,
     WhereWhere = [],
     ListTreesWhere = []
    ),
    !.

% si no es constructora ni funcion, es una funcion auxiliar proveniente de
% una constructora, una funcion o una primitiva
transformStep2App(Name,Args,NumberIn,NumberOut,VarsRuleIn,VarsRuleOut,AppOut,
                  WhereWhere,ListTreesWhere):-
    App =.. [Name|Args],
    name(Name,Str),
    dollarPrefix(Str,String),
    searchDollar(String,[],String1),
    name(Name1,String1),
    (
         % la unica funcion auxiliar que da lugar a un where es la de una
         % primitiva actuando sobre todos sus argumentos
     primitive(Name1,_,_),
     ftype(Name1,Arity,_,_),
     name(Arity,ArityS),
     append(X,ArityS,String),   % es la prim auxiliar Name1$Arity
     newVarsWhere(NumberIn,NumberOut,VarsRuleIn,VarsRuleOut,R,T),
     WhereWhere = ['='('$$tup'((R,T)),App,0)],
     AppOut = R,
     % Depu 24/11/00 mercedes
     % Aniadimos en la lista de arboles el dVal del resultado. Hace falta
     % porque quitaremos los arboles cuyo resultado no haya sido evaluado,
     % es decir, dVal R = "_".
     ListTreesWhere = ['$$tup'((dVal(R),T))]
    ;
     AppOut = App,
     NumberOut = NumberIn,
     VarsRuleOut = VarsRuleIn,
     WhereWhere = [],
     ListTreesWhere = []
    ),
    !.



dollarPrefix([36|Xs],String):-
    !,
    dollarPrefix(Xs,String).

dollarPrefix(String,String):-
    !.

newVarsWhere(NumberIn,NumberOut,VarsRuleIn,VarsRuleOut,R,T):-
    name(NumberIn, NumberStr),
    append("Result",NumberStr, RNameStr),
    name(RName,RNameStr),
    name_of_variable(R1,RName),
    append("Tree",NumberStr,TNameStr),
    name(TName,TNameStr),
    name_of_variable(T1,TName),
    N1 is NumberIn+1,
    (
     member(R1,VarsRuleIn),
     newVarsWhere(N1,NumberOut,VarsRuleIn,VarsRuleOut,R,T)
    ;
     member(T1,VarsRuleIn),
     newVarsWhere(N1,NumberOut,VarsRuleIn,VarsRuleOut,R,T)
    ;
     % variables nuevas
     R = R1,
     T = T1,
     VarsRuleOut = [R,T|VarsRuleIn],
     NumberOut = N1
    ),
    !.


transformStep2Conds([],NumberIn,NumberIn,VarsIn ,VarsIn,[],[],[]):-
    !.

transformStep2Conds([Cond|RCond],NumberIn,NumberOut,VarsIn ,VarsOut,
                [CondOut|RCondOut],WhereCond,ListTreesCond) :-
    !,
    transformStep2Cond(Cond,NumberIn,NumberIn1,VarsIn ,VarsIn1,
                CondOut,WhereCond1,ListTreesCond1),
    transformStep2Conds(RCond,NumberIn1,NumberOut,VarsIn1 ,VarsOut,
                RCondOut,WhereCond2,ListTreesCond2),
    append(WhereCond1,WhereCond2,WhereCond),
    append(ListTreesCond1,ListTreesCond2,ListTreesCond).


transformStep2Cond(Cond,NumberIn,NumberOut,VarsIn ,VarsOut,
                CondOut,WhereCond,ListTreesCond):-
    !,
    transformStep2Terms([Cond],NumberIn,NumberOut,VarsIn,VarsOut,
                        [CondOut],WhereCond,ListTreesCond).



%   Cond =.. [Name|Args],
%   transformStep2Terms(Args,NumberIn,NumberOut,VarsIn,VarsOut,
%                       ArgsOut,WhereCond,ListTreesCond),
%   CondOut=..[Name|ArgsOut].



transformStep2Body(Body,NumberIn,NumberOut,VarsIn,VarsOut,
               BodyOut,WhereBody,ListTreesBody):-
    !,
    transformStep2Term(Body,NumberIn,NumberOut,VarsIn,VarsOut,BodyOut,
               WhereBody,ListTreesBody).



createBody(Head,Body,RuleNumber,ListTrees,BodyOut):-
    Head =.. [Name|Args],
    name(Name,ArgName),
    includechar(ArgName,Arg1),
    % 28/11/00 mercedotas: se incluye la instancia de los argumentos
    % en lugar del la lista de los dVal de los argumentos
        % 09/08/01 rafa quito el comentario de la siguiente linea
    % 05/02/03 lo pongo porque ahora se hace en otro sitio
    % createArg2(Args,Arg2),
    name(RuleNumber,ArgRuleNumber),
    includechar(ArgRuleNumber,Arg4),
    % 25/10/00
    % la lista de arboles debe ser una lista Toy, transformarla
    prologListToToyList(ListTrees,ToyListTrees),
        % 09/08/01 rafa: Cambio '$var'('$Args') por Args2
        % 05/02/03 ahora '$var'('$Args') vuelve atener el  valor que deb�a y lo vuelvo a poner
    BodyOut =.. ['cTreeReturnResult'|[Arg1,'$var'('$Args') ,Body,'$var'('$Body'),'$var'('$Conds'),Arg4,'cTreeClean'(ToyListTrees)]].


%----------------------------------------------------------------------------%
% prologListToToyList(PrologList, ToyList)
% convierte una lista de caracteres Prolog en una cadena de caracteres Toy,
%----------------------------------------------------------------------------%
prologListToToyList([], []):-
    !.

prologListToToyList([X|Xs], ':'(X, Xs2)) :-
    !,
    prologListToToyList(Xs, Xs2).



includechar([],[]):- !.
includechar([X|Xs],'$char'(X):NXs):-
    !,
    includechar(Xs,NXs).


% 28/11/00 mercedotas


createArg2([],[]):- !.
createArg2([T|R],dVal(T):ROut):-
    !,
    createArg2(R,ROut).
