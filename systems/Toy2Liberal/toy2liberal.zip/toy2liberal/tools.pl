%-----------------------------------------------------------------------------%
% tools.pl
%-----------------------------------------------------------------------------%
/*
- Author: Mercedes

- Description: This module contains the general predicates.

- Modules which import it: codfun, compil, connected, dds, errortoy, goals, inferrer,
  initToy, procesa, token, toy, transfun y transob.
  
- Modules imported into it: not one.

- Modified:
    26/10/99 mercedes (modules).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(tools,[append/3,concatLsts/2,islist/1,inhead/3,reverse/2,concatenation/2,
          smooth/2,insertAtTheEnd/3,substituteArg/4,insertLst/3,member/2,
          member_relax/2,eliminateWhites/2,eliminateExtremes/2,take_n_elements/6,
          joinLists/2,mixLists/3,searchInList/3,
%F010204
          load_files_from_root/2, complete_root_filename/2,
          root_path/1, include_path/1,

          openFile/4,closeFile/1,
          existFile/2,extractNameExtension/3,endFile/2,
         % my_abolish/1,
          endFile/1,writeText/1,searchVar/3,closeHollow/1,
          lookandput/4,unionLsts/3,tupToArgs/2,
%R05052004
          deleteElement/3,
%R25062005
%B
          copyFile/2,appendFile/2
%E          
          ]).

%F010204
:- use_module(library(system)).

:- prolog_flag(single_var_warnings,_,off).


/*****************************************************************************/
/*                    PREDICATES ABOUT LISTS                                 */
/*****************************************************************************/


%-----------------------------------------------------------------------------%
% append(?L1,?L2,?L3) where L1, L2, L3 are lists of elementsof the same type.
% L3 is the result of the concatenation of L1 and L2.  
%-----------------------------------------------------------------------------%

append([A|B],C,[A|D]):- append(B,C,D).
append([],X,X).


%-----------------------------------------------------------------------------%
% concatLsts(+ListIn,-ListOut) where ListIn is a list of lists of elements
% and listOut is a list of elements. ListOut is the result of smoothing ListIn.
%-----------------------------------------------------------------------------%

concatLsts([],[]).
concatLsts([[]|R],S):-concatLsts(R,S).
concatLsts([[C|R1]|R2],[C|S]):-concatLsts([R1|R2],S).


%-----------------------------------------------------------------------------%
% unionLsts(+ListIn,-ListOut) where ListIn is a list of lists of elements
% and listOut is a list of elements. ListOut is the union of the lists ListIn.
%-----------------------------------------------------------------------------%

unionLsts([],R,R) :-
    !.
    
unionLsts([[]|R],LIn,S):-
    !,
    unionLsts(R,LIn,S).
    
unionLsts([[C|R1]|R2],LIn,S):-
        member(C,LIn),
        !,
    unionLsts([R1|R2],LIn,S).

unionLsts([[C|R1]|R2],LIn,S):-
    !,
    unionLsts([R1|R2],[C|LIn],S).





%-----------------------------------------------------------------------------%
% islist(+L): says if L is a list or not.
%-----------------------------------------------------------------------------%

islist([]) :- !.
islist([_|_]).


%-----------------------------------------------------------------------------%
% inhead(+N,+List,-NewList) where:
% +N: element which we want to insert in the head of the list.
% +List: list of lists of elements
% -NewList: is the list List with N in the head of each sublist.
%-----------------------------------------------------------------------------%

inhead(_,[],[]).
inhead(N,[L|R],[NL|NR]):-inheadLst(N,L,NL),inhead(N,R,NR).
inheadLst(N,[],[N]).
inheadLst(N,[E|R],[N,E|R]).


%-----------------------------------------------------------------------------%
% reverse(+Lin,-Lout)
% If we reverse Lin then we obtain Lout.
%-----------------------------------------------------------------------------%

reverse(X,Y) :- rev(X,[],Y).
rev([C|R],L,Y) :- rev(R,[C|L],Y).
rev([],K,K).


%-----------------------------------------------------------------------------%
% concatenation(+L1,-L2): this predicate catchs the elements of each list of L1
% and leaves it in L2
%-----------------------------------------------------------------------------%

concatenation([[]|B], C):- !,concatenation(B,C).
concatenation([A],    A):- !.
concatenation([[A|B]|C],[A|D]):- !,concatenation([B|C],D).


%-----------------------------------------------------------------------------%
% smooth(+Lin,-Lout): If we smooth Lin then we obtain Lout. Lin and Lout are 
% lists of lists.
%-----------------------------------------------------------------------------%

smooth([],[]).
smooth([[C]|L],[C|L1]):-smooth(L,L1).


%-----------------------------------------------------------------------------%
% inasertAtTheEnd(+Elem,+List,-List): this predicate insert an element at the 
% end of a list.
%-----------------------------------------------------------------------------%

insertAtTheEnd(Rule,[],[Rule]).
insertAtTheEnd(Rule,[L|R],[L|R1]):-insertAtTheEnd(Rule,R,R1).


%-----------------------------------------------------------------------------%
% substituteArg(+Pos,+List,+Nelem,-Nlist): this predicate substitutes en the list
% List, the element which occupyes the position Pos for the new element Nelem,
% and returns the new list Nlist.
%-----------------------------------------------------------------------------%

substituteArg(1,[_|R],Narg,[Narg|R]).
substituteArg(N,[Ar|R],Narg,[Ar|R1]):-N1 is N-1,substituteArg(N1,R,Narg,R1).


%-----------------------------------------------------------------------------%
% insertLst(+Elem,+List,-NList): If the element Elem doesn't appear in the list
% List then this predicate inserts Elem in List, else it doesn't modifie the
% list.
%-----------------------------------------------------------------------------%

insertLst(Var,[],[Var]).
insertLst(Var,[V|R],[V|R1]):-
    (V==Var,!,R1=R;
    insertLst(Var,R,R1)).


%-----------------------------------------------------------------------------%
% member(+Elem,+List): says if Elem is in List.
%-----------------------------------------------------------------------------%

member(G,[F|L]):-(G==F,!;member(G,L)).

%-----------------------------------------------------------------------------%
% deleteElement(+Elem,+ListIn,-ListOut): remove all the occurrences of Elem 
% in ListIn. The result is ListOut.
%-----------------------------------------------------------------------------%
deleteElement(_Elem, [], []):-
    !.

deleteElement(Elem,[X|Xs],ListOut) :-
    ( 
     Elem==X, 
     deleteElement(Elem,Xs,ListOut)
    ;
     deleteElement(Elem,Xs,ListOut1),
     ListOut = [X|ListOut1]
    ),
    !.
     

%-----------------------------------------------------------------------------%
% member_relax : like member but using '=' instead of '=='
% it gives just an answer (or zero)
%-----------------------------------------------------------------------------%

member_relax(X,[X|_T]) :- !.
member_relax(X,[_H|T]) :- member_relax(X,T). 


%-----------------------------------------------------------------------------%
% eliminateWhites (+List,-Newlist) : this predicate eliminates the char 32 of
% the list List.
%-----------------------------------------------------------------------------%
    
eliminateWhites([32|R],RR):-!,eliminateWhites(R,RR).
eliminateWhites(R,R).


%-----------------------------------------------------------------------------%
% eliminateExtremes(+List,-NList): this predicate eliminates the first and
% the latest element of List
%-----------------------------------------------------------------------------%

eliminateExtremes([],[]):-!.
eliminateExtremes([H|T],S):- eliminateLatest(T,S).


%-----------------------------------------------------------------------------%
% eliminateLatest(+List,-NList): this predicate eliminates the latest element of
% List.
%-----------------------------------------------------------------------------%

eliminateLatest([],[]) :-!. 
eliminateLatest([_H],[]):-!.
eliminateLatest([H|T],[H|S]) :- eliminateLatest(T,S).


% ----------------------------------------------------------------------------%
% take_n_elements(+N,+List,-NList,-Rest,-Just,-Exceed): this predicates 
% divides the list List in two patrs. The fist NList with N elements and the
% second Rest with the rest of elements. If N>length(Lista) then Just= false,
% Exceed=false, NList=List and Rest=[]. If N=length(Lista) then Just=true,
% Exceed=false, NList=List and Rest=[].
% ----------------------------------------------------------------------------%

take_n_elements(0,[],[],[],true,false)         :- !.
take_n_elements(N,[],[],[],false,false)        :- N>0,!.
take_n_elements(0,Lista,[],Lista,false,true)   :- !.
take_n_elements(N,[H|T],[H|T2],R,Just,Exceed) :- !,
                                                   N2 is N-1,
                                take_n_elements(N2,T,T2,R,Just,Exceed).


% ----------------------------------------------------------------------------%
% joinLists(+A,?B)
% A y B are two lists with hollow at the end. We include in B all the elements
% of A which don't member to B.
% ----------------------------------------------------------------------------%

joinLists(ListIn,ListOut) :-
   % we close the hollow of the ListIn and call to joinLists2
   ListIn2 = ListIn,
   closeHollow(ListIn2),
   joinLists2(ListIn2,ListOut).

closeHollow([]):- !.
closeHollow([_|R]) :-
        !,
        closeHollow(R).

% ----------------------------------------------------------------------------%
% joinLists2(+A,?B)
% A is a closed list and B is a list with hollow at the end.
% We include in B all the elements of A which don't member to B (B will be a
% list with hollow at the end).
% ----------------------------------------------------------------------------%

joinLists2([],ListOut):-!.
joinLists2([H|T],ListOut) :-
        lookandput(H,true,_,ListOut),
        joinLists2(T,ListOut).


% ----------------------------------------------------------------------------%
% lookandput(+Elem,+Include,-Was,?Table)
% Elem   : Elem which we have to search or insert in the Table.
% Include: if we we have to include the element then Include=true else 
%          Include=false 
% Was : if the element was in the Table then Was=true esle Was=false.
% Table  : Table with hollow at the end 
% ----------------------------------------------------------------------------%

lookandput(_,false,false,[First|Rest]) :-
        var(First),   % We have arrived to the hollow
        !.
lookandput(Elem,true,false,[First|Rest]) :-
        var(First),   % We have arrived to the hollow; we have to include it
        !,
        First=Elem.
% We haven't arrived to the hollow (ojo al orden de las clausulas)
lookandput(Elem,_,true,[Elem|R]) :- !.
lookandput(Elem,Include,Is,[_|R]) :-
        !,
        lookandput(Elem,Include,Is,R).


% ----------------------------------------------------------------------------%
% mixLists(+l1,+l2,-LOut):l1 and l2 are two lists of the same length:
% l1 = [a1,a2,...,an], l2 = [b1,b2,...,bn] 
% lOut is a list of the form: LOut = [(a1,b1),(a2,b2),...,(an,bn)]
% ----------------------------------------------------------------------------%

mixLists([],[],[]).  
mixLists([C1|R1],[C2|R2],[(C1,C2)|ROut]):-
        mixLists(R1,R2,ROut).


% ----------------------------------------------------------------------------%
% searchInList(+Element,+List,-Was): this predicates searchs the element in the
% list. If the element is in the list then Was=true else Was=false.
% ----------------------------------------------------------------------------%

searchInList(_Element,[],false) :- !.
searchInList(Element,[Element|_R],true) :- !.
searchInList(Element,[_C|R],Was) :- !, searchInList(Element,R,Was).


% ----------------------------------------------------------------------------%
% searchVar(+Name,+ListVarsIn/-ListVarsOut,-Var)
% The list of variables has elements of the form (Name,Var) where Var is the
% translation of the variable Name.
% This predicate search the pair (Name,_) in ListVarsIn. If it finds a pair of
% this form then it doesn't modified the list and returns in Var the second
% argument of (Name,_), else it introduces in the list of variables a new pair
% of the form (Name,V) and returns in Var is_not(V).
% ----------------------------------------------------------------------------%

searchVar(Name,[]/[(Name,V)],is_not(V)):-!.
searchVar(Name,[(Name,V)|R]/[(Name,V)|R],V):-!.
searchVar(Name,[P|R]/[P|R1],V):-
    searchVar(Name,R/R1,V).




tupToArgs((Arg,RestTup),[Arg|Args]):-
    !,
    tupToArgs(RestTup,Args).

tupToArgs(Arg,[Arg]):-
    !.



/*****************************************************************************/
/*                    PREDICATES ABOUT FILES                                 */
/*****************************************************************************/


%R200605
%B
%-----------------------------------------------------------------------------%
% copyFile(+FileIn,+FileOut): copies FileIn over FileOut 
%-----------------------------------------------------------------------------%
copyFile(FileIn,FileOut) :-
	!,
	open(FileIn,read,Hin),
	open(FileOut,write,Hout),
	copyBytes(Hin,Hout),
	close(Hin),
	close(Hout).

%-----------------------------------------------------------------------------%
% appendFile(+FileIn,+FileOut): appends FileIn at the end of FileOut 
%-----------------------------------------------------------------------------%
appendFile(FileIn,FileOut) :-
	!,
	open(FileIn,read,Hin),
	open(FileOut,append,Hout),
	copyBytes(Hin,Hout),
	close(Hin),
	close(Hout).
	
copyBytes(Hin,Hout) :- 	
   get_code(Hin,C),
   (C== -1
    ;
    put_code(Hout,C),
    copyBytes(Hin,Hout)
    ),!.
%E

%-----------------------------------------------------------------------------%
% load_files_from_root(+File,+Options): this predicate loads files from the root 
% distribution directory. It detects the running operating system and 
% behaves consequently
%-----------------------------------------------------------------------------%

%F010204
load_files_from_root(File,Options) :-
      complete_root_filename(File,CompleteFile),
      load_files(CompleteFile,Options).

%-----------------------------------------------------------------------------%
% complete_root_filename(+File,-CompleteRootFileName): this predicate 
% gives the complete filename for a file in the root distribution directory
%-----------------------------------------------------------------------------%
complete_root_filename(File,CompleteRootFileName) :-
        toy:toydir(D),   name(D,ToyDir),
        name(File, FileS), append(ToyDir, FileS, FS), name(CompleteRootFileName,FS),!.

      /* OldVersion
complete_root_filename(File,CompleteRootFileName) :-
      environ('TOYDIR',E), name(E,ES),
      (toy:os(unix) ->
       DirectorySeparator="/"
    ;
       DirectorySeparator="\\"
      ), 
      append(ES,DirectorySeparator,TS),
      name(File, FileS), append(TS, FileS, FS), name(CompleteRootFileName,FS).
*/

%F010204
%-----------------------------------------------------------------------------%
% root_path(-Path):  gives the complete path for the root distribution 
% directory (including the final backslash)
%-----------------------------------------------------------------------------%
root_path(RootPath) :-
        toy:toydir(RootPath).
        
/* Old version        
        environ('TOYDIR',E),
        name(E,ES),
        (toy:os(unix) ->
         append(ES,"/",PS)
        ;
         append(ES,"\\",PS)
        ),
        name(RootPath,PS).
*/

%F010204
%-----------------------------------------------------------------------------%
% include_path(-Path):  gives the complete path for the include distribution 
% directory (including the final backslash)
%-----------------------------------------------------------------------------%
%F020304 Cambio Include por include
include_path(IncludePath) :-
        toy:toydir(D),   name(D,ToyDir),
        append(ToyDir,"include/",PS),
        name(IncludePath,PS),
        !.

/* Old Version
include_path(IncludePath) :-
        environ('TOYDIR',E),
        name(E,ES),
        (toy:os(unix) ->
         append(ES,"/include/",PS)
        ;
         append(ES,"\\include\\",PS)
        ),
        name(IncludePath,PS).
*/

%-----------------------------------------------------------------------------%
% openFile(+File,+Ext,+Mode,+Handle): this predicate open th file File.Ext in
% mode Mode where Mode can be: reading or writing
%-----------------------------------------------------------------------------%

openFile(File,Ext,Mode,Handle):-
    name(File,N),
    append(N,Ext,N1),
    name(F,N1),
    nofileerrors,
    open(F,Mode,Handle),
    !,
    fileerrors.

openFile(File,Ext,_,_):-
    fileerrors,
    nl,
    write('Error: Cannot find file '''),
    write(File),
    name(N,Ext),
    write(N),
    write('''.'),
    nl,
    fail.


%-----------------------------------------------------------------------------%
% closeFile(+Handle)
%-----------------------------------------------------------------------------%

closeFile(Handle):-
    close(Handle).


%-----------------------------------------------------------------------------%
% existFile(+File,+Ext): this predicates says if the file File.Ext exists or not
%-----------------------------------------------------------------------------%

existFile(File,Ext):-
    !,
    openFile(File,Ext,read,Handle),
    close(Handle).




%-----------------------------------------------------------------------------%
% extractNameExtension(+F,-Name,-Extension): this predicates obtains the physical
% name and the extension of the file F (F is the name of the file. F is an atom
% which has been introduced through the keyboard for the user). Extension=.toy
% by default.
%-----------------------------------------------------------------------------%

extractNameExtension(F,Name,Extension) :-
    name(F,File),
    % search '.' or '/' or nothing
    reverse(File,FileRev),
    extractNameExtension2(FileRev,Name,[],Extension).


%-----------------------------------------------------------------------------%
% extractNameExtension2(+F,-Name,+ExtIn,-ExtOut): 
% igual que el anterior, solo que parte del nombre como cadena e invertido
%-----------------------------------------------------------------------------%

% si llegamos hasta el punto, hemos terminado de leer la extension
extractNameExtension2([P|L], LS,ExtI,[P|ExtI]) :-
    P == 46, % '.'
    !,
    reverse(L,LS).

% si llegamos hasta el '/', hemos terminado: no tiene extension
extractNameExtension2([P|L], NameS,ExtI,".toy") :-
    P == 47, % /
    !,
    reverse([P|L],S),
    append(S,ExtI,NameS).

% seguimos mirando. Suponemos que estamos leyendo la extension
extractNameExtension2([P|L],NameS,ExtI,ExtS) :-
    extractNameExtension2(L,NameS,[P|ExtI],ExtS).

% si la recorremos entera sin encontrar '.' ni '/' es que no trae extension
extractNameExtension2([], ExtI,ExtI,".toy").


%-----------------------------------------------------------------------------%
% endFile(+Handle,+C): this predicates says if the character C is the character
% end of file.
%-----------------------------------------------------------------------------%

endFile(H,C) :- (C=26;C= -1;
                 C=end_of_file; 
                 current_input(H),(C=13;C=10)),!.


%-----------------------------------------------------------------------------%
% endFile(+C): this predicates says if the character C is the character
% end of file.
%-----------------------------------------------------------------------------%

endFile(C) :- (C=26 ; C= -1 ; C=end_of_file),!.



/*****************************************************************************/
/*               PREDICATES ABOUT WRITING ON THE SCREEN                      */
/*****************************************************************************/


%-----------------------------------------------------------------------------%
% writeText(+Text): this predicate writes the chain Text on the screen.
%-----------------------------------------------------------------------------%

writeText([]).
writeText([H|T]) :- put(H), writeText(T).
