
primitiveFunct(openFile,2,2,(':'(char,[]) -> ioMode -> io(handle)),io(handle)).

primitiveFunct(closeFile,1,1,(handle -> io(unit)),io(unit)).

primitiveFunct(end_of_file,1,1,(handle -> io(bool)),io(bool)).

primitiveFunct(getCharFile,1,1,(handle -> io(char)),io(char)).

primitiveFunct(putCharFile,2,2,(handle -> char -> io(unit)),io(unit)).

primitiveFunct(putStrFile,2,2,(handle -> ':'(char,[]) -> io(unit)),io(unit)).

primitiveFunct(putStrLnFile,2,2,(handle -> ':'(char,[]) -> io(unit)),io(unit)).

primitiveFunct(getLineFile,1,1,(handle -> io(':'(char,[]))),io(':'(char,[]))).

primitiveFunct(contin1,2,2,(handle -> char -> io(':'(char,[]))),io(':'(char,[]))).

primitiveFunct(contin2,2,2,(char -> ':'(char,[]) -> io(':'(char,[]))),io(':'(char,[]))).



