% CVS: $Id:
% Foreign resource declarations for library(chr).
/* [PM] 3.9 Moved it all back into chr.pl

% These have been lifted out of chr.pl since chr.pl uses
% syntax extensions not understood by splfr.

:- dynamic foreign/2, foreign_file/2.		%  < 3#5
%
foreign( global_term_ref,   global_term_ref(+integer,[-term])).
foreign( global_term_ref_0, global_term_ref_0([-term])).
foreign( global_term_ref_1, global_term_ref_1([-term])).
foreign_file( 'chr.o', [global_term_ref,global_term_ref_0,global_term_ref_1]).

:- dynamic foreign/3, foreign_resource/2.	% >= 3#5
%
foreign( global_term_ref,   c, global_term_ref(+integer,[-term])).
foreign( global_term_ref_0, c, global_term_ref_0([-term])).
foreign( global_term_ref_1, c, global_term_ref_1([-term])).
%
foreign_resource( chr,
	[
	    global_term_ref,
	    global_term_ref_0,
	    global_term_ref_1
	]).
*/