/* Copyright (C) 1991-1993 Swedish Institute of Computer Science */

% Purpose: Persistent term storage facility.
% Authors: Hans Nilsson, Mats Carlsson

:- module(db, [
	db_open/3, db_open/4,
	current_db/4,
	db_close/0, db_close/1,
	set_default_db/1, get_default_db/1,
	db_store/2, db_store/3,
	db_fetch/2, db_fetch/3,
	db_findall/2, db_findall/3,
	db_erase/1, db_erase/2,
	db_canonical/1, db_canonical/2,
	db_buffering/2, db_buffering/3
   ]).

:- use_module(fastrw, library(fastrw), [
	fast_read/2,
	fast_write/2,
	fast_buf_read/2,
	fast_buf_write/3
   ]).


:- dynamic '$db'/4, '$default_db'/1.

%----------------------------------------------------------------
db_open(Name, Mode, Spec, DBref) :-
	ErrGoal = db_open(Name,Mode,Spec,DBref),
	DBref = '$db'(DB),
	(   '$db'(_, Name, _, _) ->
	    db_error(permission_error(ErrGoal,
				      open,
				      database,
				      Name,
				      'already open'))
	;   \+valid_mode(Mode) ->
	    db_error(domain_error(ErrGoal,2,one_of([read,update]),Mode))
	;   \+valid_spec(Spec) ->
	    db_error(domain_error(ErrGoal,3,'database spec',Spec))
	;   open_db(Name, Mode, 0, DB) ->
	    db_open_cont(Spec, DB, Mode, ErrGoal),
	    assertz('$db'(DB,Name,Mode,Spec))
	;   db_error(existence_error(ErrGoal,1,database,Name,'cannot open'))
	).

db_open(Name, Mode, DBref) :-
	ErrGoal = db_open(Name,Mode,DBref),
	DBref = '$db'(DB),
	(   '$db'(_, Name, _, _) ->
	    db_error(permission_error(ErrGoal,
				      open,
				      database,
				      Name,
				      'already open'))
	;   \+valid_mode(Mode) ->
	    db_error(domain_error(ErrGoal,2,one_of([read,update]),Mode))
	;   open_db(Name, Mode, RC, DB),
	    ok_RC(RC, DB, ErrGoal),
	    db_open_cont(Spec, DB, Mode, ErrGoal),
	    assertz('$db'(DB,Name,Mode,Spec))
	).


db_open_cont(Spec, DB, _Mode, ErrGoal) :-
	system_fetch(DB, StoredSpec), !,
	(   StoredSpec = Spec -> true
	;   close_db(DB, RC),
	    ok_RC(RC, DB, ErrGoal),
	    db_error(permission_error(ErrGoal,
				      open,
				      database,
				      '$db'(DB),
				      'incompatible spec'))
	).
db_open_cont(Spec, DB, _Mode, _ErrGoal) :-	% creating a new DB
	(var(Spec) -> Spec = on(on); true),
	system_store(DB, Spec).

%----------------------------------------------------------------
valid_mode(-) :- !, fail.
valid_mode(update).
valid_mode(read).

%----------------------------------------------------------------
valid_spec(S) :- var(S), !.
valid_spec(S) :- S \== off, is_spec(S).

is_spec(S) :- nonvar(S), S =.. [H|L], onoff(H), is_spec_l(L).

is_spec_l([]).
is_spec_l([H|T]) :- is_spec(H), is_spec_l(T).

onoff(on).
onoff(off).

%----------------------------------------------------------------
system_fetch(DB, Term) :-
	db_spec_file(DB, SpecFile),
	prolog_flag(fileerrors, Old, off),
	(   open(SpecFile, read, S) -> 
	    fast_read(S, Term),
	    close(S)
	;   true
	),
	prolog_flag(fileerrors, _, Old),
	nonvar(S).

system_store(DB, Term) :-
	db_spec_file(DB, SpecFile),
	open(SpecFile, write, S),
	fast_write(S, Term),
	close(S).

db_spec_file(DB, SpecFile) :-
	db_data(DB, Name, _),
	atom_codes(Name, S1),
	concat(S1, "/spec", S2),
	atom_codes(SpecFile, S2).

% avoid append/3 for compatibility
concat([], S, S).
concat([A|L1], L2, [A|L3]) :- concat(L1, L2, L3).

%----------------------------------------------------------------
db_close :-
	get_default_db(DB),
	db_close(DB).

db_close(DB) :-
	ErrGoal = db_close(DB),
	db_ref(DB, DBr, _Mode, _Spec, ErrGoal),
	retract('$db'(DBr,_,_,_)),
	close_db(DBr, RC),
	ok_RC(RC, DB, ErrGoal),
	retractall('$default_db'(_)).

%----------------------------------------------------------------
set_default_db('$db'(DB)) :-
	integer(DB), !,
	set_default_db(DB, _Name).
set_default_db(Name) :-
	atom(Name),
	set_default_db(_DB, Name).

set_default_db(DB, Name) :-
	'$db'(DB, Name, _Mode, _Spec),
	retractall('$default_db'(_)),
	assert('$default_db'(DB)).

%----------------------------------------------------------------
get_default_db('$db'(DB)) :-
	'$default_db'(DB).

%----------------------------------------------------------------
current_db(Name, Mode, Spec, '$db'(DB)) :-
	'$db'(DB, Name, Mode, Spec).

%----------------------------------------------------------------
db_store(Term, TermRef) :-
	'$default_db'(DB),
	db_store('$db'(DB), Term, TermRef).

db_store(DBref, Term, TermRef) :-
	ErrGoal = db_store(DBref, Term, TermRef),
	db_ref(DBref, DB, Mode, Spec, ErrGoal),
	(   Mode = update ->
	    TermRef = '$db_term'(R1,R2),
	    fast_buf_write(Term, Size, BufAddr),
	    findall(Key, key(insert,Spec,Term,Key), Keys0),
	    sort(Keys0, Keys),
	    length(Keys, NumKeys),		% must know # keys
	    start_store(DB, Size, BufAddr, NumKeys, RCss),
	    ok_RC(RCss, DB, ErrGoal),
	    store_keys(Keys, DB, ErrGoal),
	    end_store(DB, R1, R2, RCes),
	    ok_RC(RCes, DB, ErrGoal)
	;   db_error(permission_error(ErrGoal,store,database,DBref,read_only))
	).


store_keys([], _DB, _ErrGoal).
store_keys([Key|Keys], DB, ErrGoal) :-
	store_key(DB, Key, RC),
	ok_RC(RC, DB, ErrGoal),		
	store_keys(Keys, DB, ErrGoal).

%----------------------------------------------------------------
db_fetch(Term, TermRef) :-
	'$default_db'(DB),
	db_fetch('$db'(DB), Term, TermRef).

db_fetch(DBref, Term, TermRef) :-
	ErrGoal = db_fetch(DBref,Term,TermRef),
	db_ref(DBref, DB, _Mode, Spec, ErrGoal),
	(   var(TermRef) ->			% search for the term
	    findall(Key, key(fetch,Spec,Term,Key), Keys),
						% the key order is significant!
	    db_fetch(DB, Keys, Term, TermRef, [], [], ErrGoal)
	;   term_ref(TermRef, R1, R2, ErrGoal),	% direct pointer
	    fetch_this_db(DB, R1, R2, 1, RC),
	    ok_RC(RC, DB, ErrGoal),
	    ref_to_pointer(DB, R1, R2, Ptr),
	    pointer_to_buffer(DB, Ptr, BufAddr),
	    fast_buf_read(Term, BufAddr)
	).


% Find a record indexed on one of the Keys.
db_fetch(DB, [Key|Keys], Term, TermRef, KeysDone, PtrsDone, ErrGoal) :-
	\+ord_contains(KeysDone, Key),
	fetch_first_db(DB, Key, R10, R20, 1, RC), !,
	ok_RC(RC, DB, ErrGoal),
	ref_to_pointer(DB, R10, R20, Ptr),
	db_fetch(DB, Term, R10, R20, Ptr, TermRef, PtrsDone, PtrsDone, ErrGoal,
	         cont(Key,Keys,KeysDone)).
db_fetch(DB, [Key|Keys], Term, TermRef, KeysDone0, PtrsDone, ErrGoal) :-
	sort([Key|KeysDone0], KeysDone),
	db_fetch(DB, Keys, Term, TermRef, KeysDone, PtrsDone, ErrGoal).

% Find a record indexed on a particular key.
db_fetch(DB, Term, R1, R2, Ptr, TermRef, Acc0, _Acc, _ErrGoal, _Cont) :-
	\+ord_contains(Acc0, Ptr),
	TermRef = '$db_term'(R1,R2),
	pointer_to_buffer(DB, Ptr, BufAddr),
	fast_buf_read(Term, BufAddr).
db_fetch(DB, Term, R10, R20, Ptr0, TermRef, Acc0, Acc, ErrGoal, Cont) :-
	fetch_next_db(DB, R10, R11, R20, R21, 1, RC), !,
	ok_RC(RC, DB, ErrGoal),
	ref_to_pointer(DB, R11, R21, Ptr),
	db_fetch(DB, Term, R11, R21, Ptr, TermRef, Acc0, [Ptr0|Acc], ErrGoal,
	         Cont).
db_fetch(DB, Term, _, _, Ptr, TermRef, _, Acc1, ErrGoal, cont(Key,Keys,KeysDone0)) :-
	Keys \== [],
	sort([Key|KeysDone0], KeysDone),
	sort([Ptr|Acc1], Acc),
	db_fetch(DB, Keys, Term, TermRef, KeysDone, Acc, ErrGoal).

ord_contains([X|_], X).
ord_contains([X|Xs], Y) :- X < Y, ord_contains(Xs, Y).

%----------------------------------------------------------------
db_findall(Term, TermList) :-
	'$default_db'(DB),
	db_findall('$db'(DB), Term, TermList).

db_findall(DBref, Term, TermList) :-
	ErrGoal = db_findall(DBref,Term,TermList),
	db_ref(DBref, DB, _Mode, Spec, ErrGoal),
	findall(Ptr, fetch_one(DB,Spec,Term,Ptr,ErrGoal), L1),
	sort(L1, L2),
	ptrs_to_terms(L2, TermList, Term, DB).

fetch_one(DB, Spec, Term, Ptr, ErrGoal) :-
	key(fetch, Spec, Term, Key),
	fetch_first_db(DB, Key, R1, R2, 1, RC),
	ok_RC(RC, DB, ErrGoal),
	fetch_one1(DB, R1, R2, Ptr, ErrGoal).

fetch_one1(DB, R10, R20, Ptr, _ErrGoal) :-
	ref_to_pointer(DB, R10, R20, Ptr).
fetch_one1(DB, R10, R20, Ptr, ErrGoal) :-
	fetch_next_db(DB, R10, R11, R20, R21, 1, RC),
	ok_RC(RC, DB, ErrGoal),
	fetch_one1(DB, R11, R21, Ptr, ErrGoal).

ptrs_to_terms([], [], _, _).
ptrs_to_terms([Ptr|Ptrs], Terms0, Term0, DB) :-
	pointer_to_buffer(DB, Ptr, BufAddr),
	fast_buf_read(Term, BufAddr),
	(   \+(Term = Term0) -> Terms0 = Terms
	;   Terms0 = [Term|Terms]
	),
	ptrs_to_terms(Ptrs, Terms, Term0, DB).


%----------------------------------------------------------------
db_erase(TermRef) :-
	'$default_db'(DB),
	db_erase('$db'(DB), TermRef).

db_erase(DBref, TermRef) :-
	ErrGoal = db_erase(DBref,TermRef),
	db_ref(DBref, DB, Mode, _Spec, ErrGoal),
	term_ref(TermRef, R1, R2, ErrGoal),
	db_erase(Mode, R1, R2, DB, ErrGoal).

db_erase(update, R1, R2, DB, ErrGoal) :-
	delete_db(DB, R1, R2, RC, 1),
	ok_RC(RC, DB, ErrGoal).
db_erase(read, _R1, _R2, DB, ErrGoal) :-
	db_error(permission_error(ErrGoal,erase,database,'$db'(DB),read_only)).

%----------------------------------------------------------------
db_canonical(TermRef, Canonical) :-
	'$default_db'(DB),
	db_canonical(DB, TermRef, Canonical).

db_canonical(DB, TermRef, Canonical) :-
	term_ref(TermRef, R1, R2, db_canonical(DB,TermRef,Canonical)),
	ref_to_pointer(DB, R1, R2, Canonical).
	
	
%----------------------------------------------------------------
db_buffering(Old, New) :-
	'$default_db'(DB),
	db_buffering('$db'(DB), Old, New).

db_buffering(DBref, Old, New) :-
	ErrGoal = db_buffering(DBref,Old,New),
	db_ref(DBref, DB, _Mode, _Spec, ErrGoal),
	db_flag(DB, 0, 1, 1, OldI),
	(   valid_flag(Old, OldI),
	    valid_flag(New, NewI) -> true
	;   db_error(domain_error(ErrGoal,3,one_of([off,on]),New))
	),
	db_flag(DB, 1, 1, NewI, OldI).
	

valid_flag(-, 2) :- !, fail.
valid_flag(off, 1).
valid_flag(on, 0).

%----------------------------------------------------------------
db_print('$db'(DB)) :-
	'$db'(DB, _Name, _Mode, _Spec),
	print_db1(DB).

db_print('$db'(DB), N) :-
	atom(N),
	'$db'(DB, _Name, _Mode, _Spec),
	print_db2(DB, N).

db_print('$db'(DB), N, M) :-
	atom(N),
	atom(M),
	'$db'(DB, _Name, _Mode, _Spec),
	print_db3(DB, N, M).

%----------------------------------------------------------------
ok_RC(0, _DB, _Goal) :- !.
ok_RC(Code, DB, Goal) :-
	last_message_db(Code, Msg),
	db_error(permission_error(Goal,access,database,'$DB'(DB),Msg)).

%----------------------------------------------------------------
term_ref(Ref, R1, R2, ErrGoal) :-
	(   Ref = '$db_term'(R1,R2),
	    integer(R1), integer(R2) -> true
	;   functor(ErrGoal, _, A),
	    db_error(domain_error(ErrGoal,A,'term reference',Ref))
	).
	

%----------------------------------------------------------------
db_ref(DBref, DB, Mode, Spec, ErrGoal) :-
	(   DBref = '$db'(DB),
	    integer(DB) ->
	    (   '$db'(DB, _Name, Mode, Spec) -> true
	    ;   db_error(permission_error(ErrGoal,access,database,DBref,
		                          'not open'))
	    )
	;   db_error(domain_error(ErrGoal,1,'database reference',DBref))
	).


%----------------------------------------------------------------
% Might come in handy for portability.
db_error(Excp) :- raise_exception(Excp).


%----------------------------------------------------------------
%
% key(+Type, +Spec, +Term0, -Key)
%
% Type = insert  or  fetch
% Spec = on | off | on(Spec...) | off(Spec(...)
%----------------------------------------------------------------
key(Type, Spec, Term0, Key) :-
	ix_relevant(Spec, Type, Term0, RelevantList, []),
	db_term_hash(RelevantList, Key).

%----------------------------------------------------------------
% How to code variables:
%----------------------------------------------------------------
templates(insert, -16'1227F5A,  16'89B161).	% $VAR, $ANY
templates(fetch,   16'89B161,  -16'1227F5A).	% $ANY, $VAR

%----------------------------------------------------------------
% ix_relevant(+Spec, +Mode, +Term) --> -List
%
% List is a list of parts of Term which are relevant according to
% Spec. Variables are substituted by VarTmpl.
%
% Generates on backtracking lists which are generalizations of Term,
% so that a given query will find all matching tuples that are
% less, equally, or more specific than the query.
% 
% A non-variable term at an indexable position translates to
% the principal functor and generalizes to $ANY ($VAR) 
% if Mode is insert (fetch).  $ANY and $VAR are actually random integers
% defined in templates/3.
% 
% If Mode is insert, a variable at an indexable position translates
% to $VAR and generalizes to $ANY.
% 
% If Mode is fetch, a variable at an indexable position translates
% to $ANY and is not generalized.
% 
% For example, Spec=on(on), Mode=insert:
% 
% p(a) => [p,1,a], [p,1,$ANY], [$ANY]
% p(_) => [p,1,$VAR], [p,1,$ANY], [$ANY]
% 
% Spec=on(on), Mode=fetch:
% 
% p(a) => [p,1,a], [p,1,$VAR], [$VAR]
% p(_) => [p,1,$ANY], [$VAR]
% 
% The key idea is that if a query Q matches a tuple T,
% the respective sets of index lists should intersect.
%----------------------------------------------------------------
ix_relevant(off, _, _) --> !.
ix_relevant(on, Mode, T) --> {var(T)}, !, ix_var(Mode).
ix_relevant(on, Mode, T) --> !, ix([], Mode, T, []).
ix_relevant(Spec, Mode, T) -->
	(   {var(T)} -> ix_var(Mode)
	;   {T =.. [_|TL]},
	    {Spec =.. [_|SL]},			% off(...) treated like on(...)
	    ix(SL, Mode, T, TL)
	).

ix(Ss, Mode, T, Ts) --> [T],
	{atomic(T)},
	ix_tail(Ss, Mode, Ts).
ix(Ss, Mode, T, Ts) --> [F,N],
	{functor(T, F, N), N>0},
	ix_tail(Ss, Mode, Ts).
ix(_, Mode, _, _) --> [GT],			% Generalize on backtracking
	{templates(Mode, _VT, GT)}.

ix_tail([S|Ss], Mode, [T|Ts]) --> !,
	ix_relevant(S, Mode, T),
	ix_tail(Ss, Mode, Ts).
ix_tail(_SpecL, _Mode, _TermL) --> [].

ix_var(Mode) --> [VT],
	{templates(Mode, VT, _GT)}.
ix_var(insert) --> [GT],			% Generalize on backtracking
	{templates(insert, _VT, GT)}.


/*================================================================*/

:- dynamic foreign/2, foreign_resource/2.
% Administration
foreign(open_db, open_db(+string, +string, -integer, [-address])).
%                                                      struct db_node **

foreign(close_db, close_db(+address, -integer)).
%                           struct db_node *

foreign(last_message_db, last_message_db(+integer, [-string])).

% Fetching
foreign(fetch_first_db, fetch_first_db(+address, % struct db_node *
	                               +integer,
				       -integer, % struct p_bucket **
				       -integer,
				       [-integer], -integer)).

foreign(fetch_next_db, fetch_next_db(+address, % struct db_node *
				     +integer, % struct p_bucket *
				     -integer, % struct p_bucket **
				     +integer, -integer,
				     [-integer], -integer)).

foreign(fetch_this_db, fetch_this_db(+address, % struct db_node *
				     +integer, % struct p_bucket *
	                             +integer, [-integer], -integer)).

foreign(ref_to_pointer, ref_to_pointer(+address, % struct db_node *
                                       +integer, % struct p_bucket *
				       +integer, % offset
				       -integer)). % char ** (virtual)

foreign(cp_to_buffer, pointer_to_buffer(+address, % struct db_node *
                                        +integer, % char * (virtual)
					[-address])). % char ** (malloc'ed)


% Storing
foreign(start_store, start_store(+address, % struct db_node *
                                 +integer,
				 +address, % char *
				 +integer, -integer)).

foreign(store_key, store_key(+address, % struct db_node *
	                     +integer, -integer)).

foreign(end_store, end_store(+address, % struct db_node *
                             -integer, % struct p_bucket **
			     -integer, -integer)).

% Deleting
foreign(delete_db, delete_db(+address, % struct db_node *
	                     +integer, % struct p_bucket *
			     +integer, -integer, [-integer])).

% Statistics etc.
foreign(db_clear_statistics, db_clear_statistics).

foreign(db_get_statistics, db_get_statistics(+address, % struct db_node *
                                             +integer, -string, [-float])).

foreign(db_num_c_buckets, db_num_c_buckets(+address, % struct db_node *
                                           +integer, -integer, [-integer])).

foreign(db_num_free_areas, db_num_free_areas(+address, % struct db_node *
                                             +integer, -integer, [-integer])).

foreign(sleep_db, sleep_db(+integer)).

foreign(print_db1, print_db1(+address)). % struct db_node *

foreign(print_db2, print_db2(+address, % struct db_node *
                             +string)).

foreign(print_db3, print_db3(+address, % struct db_node *
	                     +string, +string)).

foreign(db_data, db_data(+address, % struct db_node *
	                 -string, -string)).

foreign(db_term_hash, db_term_hash(+term, [-integer])).

foreign(db_flag, db_flag(+address, % struct db_node *
			 +integer, +integer, +integer, [-integer])).

% qpc needs an explicit function list
foreign_resource(db,
	[
	    init(db_init),
	    open_db,close_db,
	    last_message_db,
	    fetch_first_db,fetch_next_db,fetch_this_db,
	    ref_to_pointer,cp_to_buffer,
	    start_store,store_key,end_store,delete_db,
	    db_clear_statistics,db_get_statistics,db_num_c_buckets,
	    db_num_free_areas,sleep_db,
	    print_db1,print_db2,print_db3,db_data,db_term_hash,db_flag
	]).

:- load_foreign_resource(library(system(db))).


