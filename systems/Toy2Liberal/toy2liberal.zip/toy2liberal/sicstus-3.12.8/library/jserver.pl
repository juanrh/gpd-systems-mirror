%%% -------------------------------------------------------------------
%%% Author:         Jesper Eskilson <jojo@sics.se>
%%% Description:    Prolog-server for Jasper
%%% CVS:            $Id: jserver.pl,v 1.1 1999/09/03 13:59:54 jojo Exp $
%%% Copyright (c) 1999, SICS
%%% -------------------------------------------------------------------

:- module(jserver,[
		   jasper_server/1,
		   jasper_server/0		  
		  ]).

:- use_module([library(sockets),
	       library(charsio),
	       library(lists),
	       library(system),
	       library(assoc)]).
	     
:- dynamic jserver/1.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Auxilliary predicates

backlog(20).

host_ipnr(IPnr) :-
	current_host(Name),
	hostname_address(Name,IPnr), !.
% Assume loopback interface if current_host/1 fails.
host_ipnr('127.0.0.1').

magic(magic1007).


/* register_java/1: informs the Prolog server where the Java server is
located.

Pid:           Pid of Java process if the Prolog process has exec:d
               its own Java process.
JavaStdXXX:    Streams to communicate with the Java server process.
JavaCommand:   Command used to exec the Java server process.
Machine,Port:  Machine/Port where the Java server is located.
*/

register_java([pid(Pid),
	       streams(JavaIn,JavaOut,JavaErr),
	       command(JavaCommand),
	       machine(Machine,Port)|_Rest]) :-
	unregister_java,
	format('Registering Java server: ~w~n',[[pid(Pid),
						 streams(JavaIn,JavaOut,JavaErr),
						 command(JavaCommand),
						 machine(Machine,Port)|_Rest]]),
	asserta(jserver([pid(Pid),
			 streams(JavaIn,JavaOut,JavaErr),
			 command(JavaCommand),
			 machine(Machine,Port)])).
unregister_java :-
	retractall(jserver(_)).

/* Open a server-socket on the given port. Tries to resolve Host,
HostAddr and binds Socket to the created socket. */
open_local_server_socket(HostAddr,Port,Socket) :-
	host_ipnr(HostAddr),
	socket('AF_INET',Socket),
	socket_bind(Socket,'AF_INET'(HostAddr,Port)),
	backlog(BackLogSize),
	socket_listen(Socket,BackLogSize).

init_server(State,Port) :-
	open_local_server_socket(Host,Port,Socket),
	format(user_error,'Opened server socket on port ~w.~n',[Port]),
	initial_termrefs(TermRefs),
	State = pserver([machine(Host,Port),
			  socket(Socket),
			  termrefs(TermRefs),  % The active termrefs
			  qid(_Qid),           % Id of current query
			  pid(_Pid,_Functor),  % Current predicate ID w/ functor
			  jserver(_ServerInfo),% Location of the Java server
			  socket_stream(_Stream), % Bidirectional socket stream
			  command(_Command),   % Last read command
			  result(_Result),     % Result from last command
			  vars(_Vars)          % Command variable names for the last command
 			  |_]).	               % Keep the tail unbound to enable
				               % future extensions.

%%% Access predicates
get_machine(pserver([machine(Host,Port)|_]),Host,Port).
get_socket(pserver([_,socket(Socket)|_]),Socket).
get_termrefs(pserver([_,_,termrefs(TermRefs)|_]),TermRefs).
get_qid(pserver([_,_,_,qid(Qid)|_]),Qid).
get_pid(pserver([_,_,_,_,pid(Pid,Functor)|_]),Pid,Functor).
get_jserver(pserver([_,_,_,_,_,JavaServer|_]),JavaServer).
get_stream(pserver([_,_,_,_,_,_,socket_stream(Stream)|_]),Stream).

set_termrefs(State,TermRefs,NewState) :-
	set_field(State,termrefs(_),termrefs(TermRefs),NewState).

set_field(pserver(ServerInfo),OldValue,NewValue,pserver(NewServerInfo)) :-
	set_field0(ServerInfo,OldValue,NewValue,NewServerInfo).
set_field0([],_,_,[]) :- !.
set_field0([OldValue|Rest],OldValue,NewValue,[NewValue|NewRest]) :- !,
	set_field0(Rest,OldValue,NewValue,NewRest).
set_field0([Value|Rest],OldValue,NewValue,[Value|NewRest]) :- 
	Value \== OldValue, !,
	set_field0(Rest,OldValue,NewValue,NewRest).

%%% sformat/3; writes to the client at the other end of the server's socket.
sformat(State,Format,Args) :-
	get_stream(State,Stream),
	format(user_error,'<to client>~n',[]),
	format(user_error,Format,Args),
	flush_output,
	format(user_error,'</to client>~n',[]),
	format(Stream,Format,Args),
	flush_output(Stream).

identify(State) :-
	get_machine(State,Host,Port),
	sformat(State,'prologserver/magic1007~n~w~n~w~n',
	       [Host,Port]).


/* jasper_server/1: Starts a Prolog server on the given port. */
jasper_server(Port) :-
	init_server(State,Port),
	call_cleanup(server(State),server_cleanup(State)).

jasper_server :-
	init_server(State,_Port),
	call_cleanup(session(State),server_cleanup(State)).
	
server_cleanup(State) :-
	format(user_error,'Server terminating. Cleaning up.~n',[]),
	unregister_java,
	get_socket(State,Socket),
	socket_close(Socket).

/* wait_for_connection/2: basically a wrapper for socket_accept/3. */
wait_for_connection(State,NewState) :-
	get_socket(State,Socket),
	get_machine(State,_Host,Port),
	format(user_error,'Waiting for connection on port ~w.~n',[Port]),
	socket_accept(Socket,_Client,Stream),
	set_field(State,socket_stream(_),socket_stream(Stream),NewState),
	identify(NewState).

/* wait_for_command/3: Calls read_term/3, encapsulated in a
on_exception/3. If successful, Term is unified with the term read in
and Variables is unified with the X in variable_names(X) (see the
documentation of read_term/3). If an exception was raised, it is
unified with Exception, and Command is unified with
readexcp(Exception).  */
wait_for_command(State,NewState,Command) :-
	get_stream(State,Stream),
	on_exception(Exception,
		     read_term(Stream,Command,
			       [variable_names(Variables)]),
		     Command = readexcp(Exception)),
	set_field(State,command(_),command(Command),S0),
	set_field(S0,vars(_),vars(Variables),NewState).

server(State) :-
	wait_for_connection(State,NewState),
	session(NewState).

session(State) :-
	wait_for_command(State,NewState,Command),
	( session(Command,NewState) ->
	    true
	;   format('No such command.~n',[])
	).

%%% For now, we only have generic 'put' and 'get' operations. 
session('SP_put'(Value,Ref),State) :-
	get_termrefs(State,T),
	put_term(T,Ref,Value,T0),
	set_termrefs(State,T0,NewState),
	reply(NewState,ok),
	session(NewState).

session('SP_get'(Ref),State) :-
	get_termrefs(State,T),
	get_term(T,Ref,Result),
	reply(State,Result),
	session(State).

session('SP_new_term_ref',State) :-
	get_termrefs(State,T),
	push_term(T,Result,[],T0),
	set_termrefs(State,T0,NewState),
	reply(NewState,Result),
	session(NewState).

session('SP_query'(Goal),State) :-
	prolog_flag(typein_module,Module,Module),
	on_exception(Exception,
		     ( call(Module:Goal) ->
			 Result = true(Goal)
		     ;	 Result = false
		     ),
		     ( Result = exception(Exception))),
	reply(State,Result),
	session(State).


%%% reply/2-3, send a reply back to the client.
reply(State,Result) :-
	sformat(State,"Result = ~w~n",[Result]).


/* start_slave/0: Starts a slave-server. The difference between a
slave-server is that it prints its address on standard output and then
waits for one connections to be made, and then exits. This server type
is intended to be used if the Prolog executable is spawned by the
client itself. */
start_slave :-
	init_server(Server),
	get_machine(Server,Host,Port),
	get_socket(Server,Socket),
	format(user_error,'Opened slave server socket on port ~w.~n',[Host,Port]),
	socket_accept(Socket,_Client,Stream),
	identify(Stream,Host,Port),
	session_loop(Server),
	close(Stream).




/* This predicate is not tail-recursive. The stack-usage is
proportional to the number of variables printed.  */
format_queryvars([],"").
format_queryvars([Name=Var|Rest],Reply) :-
	( var(Var) ->
	    format_to_chars('~a~n<var>~n',[Name],Reply0)
	;   format_to_chars('~a~n~w~n',[Name,Var],Reply0)
	),
	format_queryvars(Rest,Reply1),
	append(Reply0,Reply1,Reply).

do_command(readexcp(Exception),Response,true,_) :-
	format_to_chars('exception~n~w~n',[Exception],Response).
do_command(quit,"",false,_).
do_command(end_of_file,"",false,_).
do_command(metacall(Goal),Response,true,QueryVars) :-
	do_metacall(Goal,Result),
	( Result = true ->
	    %% Prints:
	    %% yes
	    %% <Goal>
	    %% <X1>
	    %% <Val1>
	    %% ...
	    %% <Xn>
	    %% <Valn>
	    %% eov
	    %%
	    %% -- If a variable is unbound, "<var>" will be printed instead.
	    format_queryvars(QueryVars,Response0),
	    format_to_chars('yes~n~w~n~seov~n',[Goal,Response0],Response)
	;   Result = false ->
	    format_to_chars('no~n',[],Response)
	;   Result = exception(Exception) ->
	    %% Prints:
	    %% exception
	    %% <ExceptionTerm>
	    format_to_chars('exception~n~w~n',[Exception],Response)
	).

do_metacall(Goal,Result) :-
	prolog_flag(typein_module,Module,Module),
	on_exception(Exception,
		     ( call(Module:Goal) ->
			 Result = true
		     ;	 Result = false
		     ),
		     ( Result = exception(Exception))).	

do_command(X,Result,true) :-
	format_to_chars('Command parse-error: unknown command ~w',[X],Result).


/*

Prolog -> Java interface.

*/

jformat(Stream,Format,Args) :-
	format(user_error,'<to java-cbhandler>~n',[]),
	format(user_error,Format,Args),	flush_output,
	format(user_error,'</to java-cbhandler>~n',[]),
	format(Stream,Format,Args), flush_output(Stream).

get_jvm(jserver(ServerInfo)) :-
	jserver(ServerInfo).

connect_jvm(jserver([_,_,_,machine(Machine,Port)]),Socket,Stream) :-
	socket('AF_INET',Socket),
	socket_connect(Socket,'AF_INET'(Machine,Port),Stream).

%% start_java(+Machine,+Port,+JavaCommand,-JavaServer)
start_java(Machine,Port,JavaCommand,jserver(ServerInfo)) :-
	exec(JavaCommand,[pipe(JavaStdin),
			  pipe(JavaStdout),
			  pipe(JavaStderr)],Pid),
	ServerInfo = [pid(Pid),
		      streams(JavaStdin,JavaStdout,JavaStderr),
		      command(JavaCommand),
		      machine(Machine,Port)],
	register_java(ServerInfo).
	

/*

In order to identify a method in a Java-class, one much specify the
type of each parameter. This is done in the argument-list, by enclosing
each argument with a term describing the type.

Primitive Java type          Prolog term (example)
int                          int(42)
boolean                      boolean(true)
byte                         byte(42)
char                         char(42)
short                        short(42)
long                         long(42)
float                        float(42.0)
double                       double(42.0)

For normal classes, use the term 'object(Class,ObjRef)', where 'Class'
is the fully qualified class name (ex: "java.lang.String"), and
'ObjRef' is the object reference for the object to be passed.

*/

valid_java_primtype(int) :- !.
valid_java_primtype(boolean) :- !.
valid_java_primtype(byte) :- !.
valid_java_primtype(char) :- !.
valid_java_primtype(short) :- !.
valid_java_primtype(long) :- !.
valid_java_primtype(float) :- !.
valid_java_primtype(double) :- !.
valid_java_primtype(X) :-
	Goal = valid_java_primtype(X),
	ArgNo = 1,
	TypeName = oneof([int,boolean,byte,char,short,long,float,double]),
	raise_exception(type_error(Goal,ArgNo,TypeName,X)).

parse_argspec('$object'(Class,Value),object,Class,Value).
parse_argspec(Term,primitive,Type,Value) :-
	Term =.. [Type,Value],
	valid_java_primtype(Type).

send_args([],_).
send_args([Arg|Args],Stream) :-
	parse_argspec(Arg,Type,Class,Value),
	jformat(Stream,'~w~n~w~n~w~n',[Type,Class,Value]),
	send_args(Args,Stream).

% exported
call_java(JVM,Class,Method,Args,ReturnValue) :-
	call_java(JVM,[],Class,Method,Args,ReturnValue).

% exported
call_java(JVM,Object,Class,Method,Args,ReturnValue) :-
	connect_jvm(JVM,_Socket,Stream),
	jformat(Stream,'begin call~n~w~n~w~n~w~n',
		[Object,Class,Method]),
	length(Args,NumArgs),
	jformat(Stream,'~w~n',[NumArgs]),
	send_args(Args,Stream),
	jformat(Stream,'end call~n',[]),
	wait_for_result(Stream,Term),
	convert_return_value(Term,ReturnValue).

convert_return_value(returned(_,Value),Value).

wait_for_result(Stream,Term) :-
	safe_read_term(Stream,Term,_,_),
	( Term = returned(Class,Value) ->
	    true
	;   raise_exception(jasper_error(['expected',returned(_,_),found,Term],
					 wait_for_result(Stream,returned(Class,Value))))
	).




/* Data-structure for mapping term-refs to terms (i.e. a fli-stack in
Prolog). Uses library(assoc). */

test_termrefs :-
	initial_termrefs(X),
	push_term(X,_,foo(bar),X0),
	push_term(X0,_,[list,elements],X1),
	push_term(X1,_,atom,X2),
%	assoc_to_list(X2,List),
%	write(List),nl.
	get_term(X2,2,T1),
	write(T1),nl.

initial_termrefs(T) :-
	empty_assoc(Tempty),
	put_assoc(0,Tempty,empty,T).

push_term(T,Ref,Term,TNew) :-
	max_assoc(T,Ref0,_),
	Ref is Ref0 + 1,
	put_assoc(Ref,T,Term,TNew).
get_term(T,Ref,Term) :-
	get_assoc(Ref,T,Term).
put_term(T,Ref,Term,T0) :-
	put_assoc(Ref,T,Term,T0).

