

user:portray_message(warning,_):- write('').

:- module(plgenerated,[sourceFileNameStr/1,hnf_susp/5,constr/4,funct/5,infix/3,'$$apply'/5,'$flip'/6,'$p' /3]).

:- dynamic $== /5, $/= /5.

/*  AF0503
:- load_files('$TOYDIR/toycomm',[if(changed)]).

:- load_files('$TOYDIR/primFunct',[if(changed)]).

:- load_files('$TOYDIR/primitivCod',[if(changed)]).
*/

%F010204
:- load_files(tools,[if(changed),imports([complete_root_filename/2])]).

:- complete_root_filename(toycomm,F),load_files(F,[if(changed)]).

:- complete_root_filename(primFunct,F),load_files(F,[if(changed)]).

:- complete_root_filename(primitivCod,F),load_files(F,[if(changed)]).




% nombre del fichero fuente
sourceFileNameStr('cflpr').


/**************    CODE FOR FUNCTIONS    **************/


% p
'$p'(true, _A, _B):-
        $>(_C, '$$susp'( $+,  [ _D, 1.0 ], _E, _F ), true, _A, _G),
        $>=(_D, 1.0, true, _G, _B).
/***********   CONSTRUCTORS AND FUNCTIONS   ***********/

constr(',', 2, ->(_A, ->(_B, ','(_A, _B))), ','(_A, _B)).
constr('$$tup', 1, ->(','(_A, _B), '$$tuple'(','(_A, _B))), '$$tuple'(','(_A, _B))).
constr([], 0, :(_A, []), :(_A, [])).
constr(:, 2, ->(_A, ->(:(_A, []), :(_A, []))), :(_A, [])).
constr('$char', 1, ->(_A, char), char).
constr('$io', 1, ->(_A, '$io'(_A)), '$io'(_A)).
constr('$stream', 1, handle, handle).
constr(readMode, 0, ioMode, ioMode).
constr(writeMode, 0, ioMode, ioMode).
constr(appendMode, 0, ioMode, ioMode).
constr('$channel', 2, channel, channel).
constr('$varmut', 1, varmut, varmut).
constr('$pValBottom', 0, pVal, pVal).
constr('$pValChar', 1, ->(char, pVal), pVal).
constr('$pValNum', 1, ->(:(char, []), pVal), pVal).
constr('$pValVar', 1, ->(:(char, []), pVal), pVal).
constr('$pValApp', 2, ->(:(char, []), ->(:(pVal, []), pVal)), pVal).
constr(true, 0, bool, bool).
constr(false, 0, bool, bool).

funct(uminus, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(abs, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(sqrt, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(ln, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(exp, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(coth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acoth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(evalfd, 2, 2, ->(:(char, []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(+, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(-, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(*, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(min, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(max, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(/, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(float))), '$num'(float)).
funct(**, 2, 2, ->('$num'(_A), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(log, 2, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(^, 2, 2, ->('$num'(_A), ->('$num'(int), '$num'(_A))), '$num'(_A)).
funct(div, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(mod, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(gcd, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(round, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(trunc, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(floor, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(ceiling, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(toReal, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(<, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(<=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(==, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(/=, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(ord, 1, 1, ->(char, '$num'(int)), '$num'(int)).
funct(chr, 1, 1, ->('$num'(int), char), char).
funct(putChar, 1, 1, ->(char, io(unit)), io(unit)).
funct(done, 0, 0, io(unit), io(unit)).
funct(getChar, 0, 0, io(char), io(char)).
funct(return, 1, 1, ->(_A, io(_A)), io(_A)).
funct(>>, 2, 2, ->(io(_A), ->(io(_B), io(_B))), io(_B)).
funct(>>=, 2, 2, ->(io(_A), ->(->(_A, io(_B)), io(_B))), io(_B)).
funct(putStr, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(putStrLn, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(getLine, 0, 0, io(:(char, [])), io(:(char, []))).
funct(cont1, 1, 1, ->(char, io(:(char, []))), io(:(char, []))).
funct(cont2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).
funct(writeFile, 2, 2, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(readFile, 1, 1, ->(:(char, []), io(:(char, []))), io(:(char, []))).
funct(readFileContents, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(dVal, 1, 1, ->(_A, pVal), pVal).
funct(dValToString, 1, 1, ->(_A, :(char, [])), :(char, [])).
funct(selectWhereVariableXi, 4, 4, ->(_A, ->('$num'(int), ->('$num'(int), ->(_B, _C)))), _C).
funct(if_then_else, 3, 3, ->(bool, ->(_A, ->(_A, _A))), _A).
funct(if_then, 2, 2, ->(bool, ->(_A, _A)), _A).
funct(flip, 3, 3, ->(->(_A, ->(_B, _C)), ->(_B, ->(_A, _C))), _C).

funct('$apply', 2, 2, ->(->(->(_A, _B), _A), _B), _B).
funct('$eqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct('$notEqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct(p, 0, _A, bool, bool).

/************    CODE FOR FUNCIONS HNF    ************/

hnf_susp('$uminus', '.'(_A, []), _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
hnf_susp('$abs', '.'(_A, []), _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
hnf_susp('$sqrt', '.'(_A, []), _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
hnf_susp('$ln', '.'(_A, []), _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
hnf_susp('$exp', '.'(_A, []), _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
hnf_susp('$sin', '.'(_A, []), _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
hnf_susp('$cos', '.'(_A, []), _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
hnf_susp('$tan', '.'(_A, []), _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
hnf_susp('$cot', '.'(_A, []), _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
hnf_susp('$asin', '.'(_A, []), _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
hnf_susp('$acos', '.'(_A, []), _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
hnf_susp('$atan', '.'(_A, []), _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
hnf_susp('$acot', '.'(_A, []), _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
hnf_susp('$sinh', '.'(_A, []), _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
hnf_susp('$cosh', '.'(_A, []), _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
hnf_susp('$tanh', '.'(_A, []), _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
hnf_susp('$coth', '.'(_A, []), _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
hnf_susp('$asinh', '.'(_A, []), _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
hnf_susp('$acosh', '.'(_A, []), _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
hnf_susp('$atanh', '.'(_A, []), _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
hnf_susp('$acoth', '.'(_A, []), _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
hnf_susp('$evalfd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
hnf_susp($+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
hnf_susp($-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
hnf_susp($*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
hnf_susp('$min', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
hnf_susp('$max', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
hnf_susp($/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
hnf_susp($**, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
hnf_susp('$log', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
hnf_susp($^, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
hnf_susp('$div', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
hnf_susp('$mod', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
hnf_susp('$gcd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
hnf_susp('$round', '.'(_A, []), _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
hnf_susp('$trunc', '.'(_A, []), _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
hnf_susp('$floor', '.'(_A, []), _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
hnf_susp('$ceiling', '.'(_A, []), _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
hnf_susp('$toReal', '.'(_A, []), _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
hnf_susp($<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
hnf_susp($<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
hnf_susp($>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
hnf_susp($>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
hnf_susp($==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
hnf_susp($/=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
hnf_susp('$ord', '.'(_A, []), _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
hnf_susp('$chr', '.'(_A, []), _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
hnf_susp('$putChar', '.'(_A, []), _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
hnf_susp('$done', [], _A, _B, _C):-
        '$done'(_A, _B, _C).
hnf_susp('$getChar', [], _A, _B, _C):-
        '$getChar'(_A, _B, _C).
hnf_susp('$return', '.'(_A, []), _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
hnf_susp($>>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
hnf_susp($>>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
hnf_susp('$putStr', '.'(_A, []), _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
hnf_susp('$putStrLn', '.'(_A, []), _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
hnf_susp('$getLine', [], _A, _B, _C):-
        '$getLine'(_A, _B, _C).
hnf_susp('$cont1', '.'(_A, []), _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
hnf_susp('$cont2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
hnf_susp('$writeFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
hnf_susp('$readFile', '.'(_A, []), _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
hnf_susp('$readFileContents', '.'(_A, []), _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
hnf_susp('$dVal', '.'(_A, []), _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
hnf_susp('$dValToString', '.'(_A, []), _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
hnf_susp('$selectWhereVariableXi', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$if_then_else', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
hnf_susp('$if_then', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
hnf_susp('$flip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$$apply', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$apply'(_A, _B, _C, _D, _E).
hnf_susp('$$eqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
hnf_susp('$$notEqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
hnf_susp('$p', [], _A, _B, _C):-
        '$p'(_A, _B, _C).




/***************     CODE FOR APPLY     ***************/

'$$apply'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$$applyHnf'(_F, _B, _C, _G, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        var(_A),
        !,
        '$$apply_1_var'(_A, _B, _C, _D, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        '$$apply_1'(_A, _B, _C, _D, _E).

% constructors

'$$apply_1'(:, _A, :(_A), _B, _B).
'$$apply_1_var'(_A, _B, :(_B), _C, _D):-
        unifyHnfs(_A, :, _C, _D).

'$$apply_1'(:(_A), _B, :(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, :(_C, _B), _D, _E):-
        unifyHnfs(_A, :(_C), _D, _E).

'$$apply_1'('$io', _A, '$io'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$io'(_B), _C, _D):-
        unifyHnfs(_A, '$io', _C, _D).

'$$apply_1'('$stream', _A, '$stream'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$stream'(_B), _C, _D):-
        unifyHnfs(_A, '$stream', _C, _D).

'$$apply_1'('$channel', _A, '$channel'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$channel'(_B), _C, _D):-
        unifyHnfs(_A, '$channel', _C, _D).

'$$apply_1'('$channel'(_A), _B, '$channel'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$channel'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$channel'(_C), _D, _E).

'$$apply_1'('$varmut', _A, '$varmut'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$varmut'(_B), _C, _D):-
        unifyHnfs(_A, '$varmut', _C, _D).

'$$apply_1'('$pValChar', _A, '$pValChar'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$pValChar'(_B), _C, _D):-
        unifyHnfs(_A, '$pValChar', _C, _D).

'$$apply_1'('$pValNum', _A, '$pValNum'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$pValNum'(_B), _C, _D):-
        unifyHnfs(_A, '$pValNum', _C, _D).

'$$apply_1'('$pValVar', _A, '$pValVar'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$pValVar'(_B), _C, _D):-
        unifyHnfs(_A, '$pValVar', _C, _D).

'$$apply_1'('$pValApp', _A, '$pValApp'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$pValApp'(_B), _C, _D):-
        unifyHnfs(_A, '$pValApp', _C, _D).

'$$apply_1'('$pValApp'(_A), _B, '$pValApp'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$pValApp'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$pValApp'(_C), _D, _E).

% parcial aplictions of funs

'$$apply_1'('$eqFun', _A, '$eqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$eqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$eqFun', _C, _D).

'$$apply_1'('$notEqFun', _A, '$notEqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$notEqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$notEqFun', _C, _D).

% parcial aplictions of prims

'$$apply_1'(evalfd, _A, evalfd(_A), _B, _B).
'$$apply_1_var'(_A, _B, evalfd(_B), _C, _D):-
        unifyHnfs(_A, evalfd, _C, _D).

'$$apply_1'(+, _A, +(_A), _B, _B).
'$$apply_1_var'(_A, _B, +(_B), _C, _D):-
        unifyHnfs(_A, +, _C, _D).

'$$apply_1'(-, _A, -(_A), _B, _B).
'$$apply_1_var'(_A, _B, -(_B), _C, _D):-
        unifyHnfs(_A, -, _C, _D).

'$$apply_1'(*, _A, *(_A), _B, _B).
'$$apply_1_var'(_A, _B, *(_B), _C, _D):-
        unifyHnfs(_A, *, _C, _D).

'$$apply_1'(min, _A, min(_A), _B, _B).
'$$apply_1_var'(_A, _B, min(_B), _C, _D):-
        unifyHnfs(_A, min, _C, _D).

'$$apply_1'(max, _A, max(_A), _B, _B).
'$$apply_1_var'(_A, _B, max(_B), _C, _D):-
        unifyHnfs(_A, max, _C, _D).

'$$apply_1'(/, _A, /(_A), _B, _B).
'$$apply_1_var'(_A, _B, /(_B), _C, _D):-
        unifyHnfs(_A, /, _C, _D).

'$$apply_1'(**, _A, **(_A), _B, _B).
'$$apply_1_var'(_A, _B, **(_B), _C, _D):-
        unifyHnfs(_A, **, _C, _D).

'$$apply_1'(log, _A, log(_A), _B, _B).
'$$apply_1_var'(_A, _B, log(_B), _C, _D):-
        unifyHnfs(_A, log, _C, _D).

'$$apply_1'(^, _A, ^(_A), _B, _B).
'$$apply_1_var'(_A, _B, ^(_B), _C, _D):-
        unifyHnfs(_A, ^, _C, _D).

'$$apply_1'(div, _A, div(_A), _B, _B).
'$$apply_1_var'(_A, _B, div(_B), _C, _D):-
        unifyHnfs(_A, div, _C, _D).

'$$apply_1'(mod, _A, mod(_A), _B, _B).
'$$apply_1_var'(_A, _B, mod(_B), _C, _D):-
        unifyHnfs(_A, mod, _C, _D).

'$$apply_1'(gcd, _A, gcd(_A), _B, _B).
'$$apply_1_var'(_A, _B, gcd(_B), _C, _D):-
        unifyHnfs(_A, gcd, _C, _D).

'$$apply_1'(<, _A, <(_A), _B, _B).
'$$apply_1_var'(_A, _B, <(_B), _C, _D):-
        unifyHnfs(_A, <, _C, _D).

'$$apply_1'(<=, _A, <=(_A), _B, _B).
'$$apply_1_var'(_A, _B, <=(_B), _C, _D):-
        unifyHnfs(_A, <=, _C, _D).

'$$apply_1'(>, _A, >(_A), _B, _B).
'$$apply_1_var'(_A, _B, >(_B), _C, _D):-
        unifyHnfs(_A, >, _C, _D).

'$$apply_1'(>=, _A, >=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >=(_B), _C, _D):-
        unifyHnfs(_A, >=, _C, _D).

'$$apply_1'(==, _A, ==(_A), _B, _B).
'$$apply_1_var'(_A, _B, ==(_B), _C, _D):-
        unifyHnfs(_A, ==, _C, _D).

'$$apply_1'(/=, _A, /=(_A), _B, _B).
'$$apply_1_var'(_A, _B, /=(_B), _C, _D):-
        unifyHnfs(_A, /=, _C, _D).

'$$apply_1'(>>, _A, >>(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>(_B), _C, _D):-
        unifyHnfs(_A, >>, _C, _D).

'$$apply_1'(>>=, _A, >>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>=(_B), _C, _D):-
        unifyHnfs(_A, >>=, _C, _D).

'$$apply_1'(cont2, _A, cont2(_A), _B, _B).
'$$apply_1_var'(_A, _B, cont2(_B), _C, _D):-
        unifyHnfs(_A, cont2, _C, _D).

'$$apply_1'(writeFile, _A, writeFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeFile(_B), _C, _D):-
        unifyHnfs(_A, writeFile, _C, _D).

'$$apply_1'(selectWhereVariableXi, _A, selectWhereVariableXi(_A), _B, _B).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_B), _C, _D):-
        unifyHnfs(_A, selectWhereVariableXi, _C, _D).

'$$apply_1'(selectWhereVariableXi(_A), _B, selectWhereVariableXi(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _B), _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_C), _D, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B), _C, selectWhereVariableXi(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, selectWhereVariableXi(_C, _D), _E, _F).

'$$apply_1'(if_then_else, _A, if_then_else(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then_else(_B), _C, _D):-
        unifyHnfs(_A, if_then_else, _C, _D).

'$$apply_1'(if_then_else(_A), _B, if_then_else(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, if_then_else(_C, _B), _D, _E):-
        unifyHnfs(_A, if_then_else(_C), _D, _E).

'$$apply_1'(if_then, _A, if_then(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then(_B), _C, _D):-
        unifyHnfs(_A, if_then, _C, _D).

'$$apply_1'(flip, _A, flip(_A), _B, _B).
'$$apply_1_var'(_A, _B, flip(_B), _C, _D):-
        unifyHnfs(_A, flip, _C, _D).

'$$apply_1'(flip(_A), _B, flip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, flip(_C, _B), _D, _E):-
        unifyHnfs(_A, flip(_C), _D, _E).

% functions

'$$apply_1'('$eqFun'(_A), _B, _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$eqFun'(_F), _D, _G),
        '$$eqFun'(_F, _B, _C, _G, _E).

'$$apply_1'('$notEqFun'(_A), _B, _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$notEqFun'(_F), _D, _G),
        '$$notEqFun'(_F, _B, _C, _G, _E).

% primitives

'$$apply_1'(uminus, _A, _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uminus, _D, _F),
        '$uminus'(_B, _C, _F, _E).

'$$apply_1'(abs, _A, _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, abs, _D, _F),
        '$abs'(_B, _C, _F, _E).

'$$apply_1'(sqrt, _A, _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sqrt, _D, _F),
        '$sqrt'(_B, _C, _F, _E).

'$$apply_1'(ln, _A, _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ln, _D, _F),
        '$ln'(_B, _C, _F, _E).

'$$apply_1'(exp, _A, _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exp, _D, _F),
        '$exp'(_B, _C, _F, _E).

'$$apply_1'(sin, _A, _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sin, _D, _F),
        '$sin'(_B, _C, _F, _E).

'$$apply_1'(cos, _A, _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cos, _D, _F),
        '$cos'(_B, _C, _F, _E).

'$$apply_1'(tan, _A, _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tan, _D, _F),
        '$tan'(_B, _C, _F, _E).

'$$apply_1'(cot, _A, _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cot, _D, _F),
        '$cot'(_B, _C, _F, _E).

'$$apply_1'(asin, _A, _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asin, _D, _F),
        '$asin'(_B, _C, _F, _E).

'$$apply_1'(acos, _A, _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acos, _D, _F),
        '$acos'(_B, _C, _F, _E).

'$$apply_1'(atan, _A, _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atan, _D, _F),
        '$atan'(_B, _C, _F, _E).

'$$apply_1'(acot, _A, _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acot, _D, _F),
        '$acot'(_B, _C, _F, _E).

'$$apply_1'(sinh, _A, _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sinh, _D, _F),
        '$sinh'(_B, _C, _F, _E).

'$$apply_1'(cosh, _A, _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cosh, _D, _F),
        '$cosh'(_B, _C, _F, _E).

'$$apply_1'(tanh, _A, _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tanh, _D, _F),
        '$tanh'(_B, _C, _F, _E).

'$$apply_1'(coth, _A, _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, coth, _D, _F),
        '$coth'(_B, _C, _F, _E).

'$$apply_1'(asinh, _A, _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asinh, _D, _F),
        '$asinh'(_B, _C, _F, _E).

'$$apply_1'(acosh, _A, _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acosh, _D, _F),
        '$acosh'(_B, _C, _F, _E).

'$$apply_1'(atanh, _A, _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atanh, _D, _F),
        '$atanh'(_B, _C, _F, _E).

'$$apply_1'(acoth, _A, _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acoth, _D, _F),
        '$acoth'(_B, _C, _F, _E).

'$$apply_1'(evalfd(_A), _B, _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, evalfd(_F), _D, _G),
        '$evalfd'(_F, _B, _C, _G, _E).

'$$apply_1'(+(_A), _B, _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, +(_F), _D, _G),
        $+(_F, _B, _C, _G, _E).

'$$apply_1'(-(_A), _B, _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, -(_F), _D, _G),
        $-(_F, _B, _C, _G, _E).

'$$apply_1'(*(_A), _B, _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, *(_F), _D, _G),
        $*(_F, _B, _C, _G, _E).

'$$apply_1'(min(_A), _B, _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, min(_F), _D, _G),
        '$min'(_F, _B, _C, _G, _E).

'$$apply_1'(max(_A), _B, _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, max(_F), _D, _G),
        '$max'(_F, _B, _C, _G, _E).

'$$apply_1'(/(_A), _B, _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /(_F), _D, _G),
        $/(_F, _B, _C, _G, _E).

'$$apply_1'(**(_A), _B, _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, **(_F), _D, _G),
        $**(_F, _B, _C, _G, _E).

'$$apply_1'(log(_A), _B, _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, log(_F), _D, _G),
        '$log'(_F, _B, _C, _G, _E).

'$$apply_1'(^(_A), _B, _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ^(_F), _D, _G),
        $^(_F, _B, _C, _G, _E).

'$$apply_1'(div(_A), _B, _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, div(_F), _D, _G),
        '$div'(_F, _B, _C, _G, _E).

'$$apply_1'(mod(_A), _B, _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mod(_F), _D, _G),
        '$mod'(_F, _B, _C, _G, _E).

'$$apply_1'(gcd(_A), _B, _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, gcd(_F), _D, _G),
        '$gcd'(_F, _B, _C, _G, _E).

'$$apply_1'(round, _A, _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, round, _D, _F),
        '$round'(_B, _C, _F, _E).

'$$apply_1'(trunc, _A, _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trunc, _D, _F),
        '$trunc'(_B, _C, _F, _E).

'$$apply_1'(floor, _A, _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, floor, _D, _F),
        '$floor'(_B, _C, _F, _E).

'$$apply_1'(ceiling, _A, _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ceiling, _D, _F),
        '$ceiling'(_B, _C, _F, _E).

'$$apply_1'(toReal, _A, _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, toReal, _D, _F),
        '$toReal'(_B, _C, _F, _E).

'$$apply_1'(<(_A), _B, _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <(_F), _D, _G),
        $<(_F, _B, _C, _G, _E).

'$$apply_1'(<=(_A), _B, _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <=(_F), _D, _G),
        $<=(_F, _B, _C, _G, _E).

'$$apply_1'(>(_A), _B, _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >(_F), _D, _G),
        $>(_F, _B, _C, _G, _E).

'$$apply_1'(>=(_A), _B, _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >=(_F), _D, _G),
        $>=(_F, _B, _C, _G, _E).

'$$apply_1'(==(_A), _B, _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ==(_F), _D, _G),
        $==(_F, _B, _C, _G, _E).

'$$apply_1'(/=(_A), _B, _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /=(_F), _D, _G),
        $/=(_F, _B, _C, _G, _E).

'$$apply_1'(ord, _A, _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ord, _D, _F),
        '$ord'(_B, _C, _F, _E).

'$$apply_1'(chr, _A, _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, chr, _D, _F),
        '$chr'(_B, _C, _F, _E).

'$$apply_1'(putChar, _A, _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putChar, _D, _F),
        '$putChar'(_B, _C, _F, _E).

'$$apply_1'(return, _A, _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, return, _D, _F),
        '$return'(_B, _C, _F, _E).

'$$apply_1'(>>(_A), _B, _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>(_F), _D, _G),
        $>>(_F, _B, _C, _G, _E).

'$$apply_1'(>>=(_A), _B, _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>=(_F), _D, _G),
        $>>=(_F, _B, _C, _G, _E).

'$$apply_1'(putStr, _A, _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStr, _D, _F),
        '$putStr'(_B, _C, _F, _E).

'$$apply_1'(putStrLn, _A, _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLn, _D, _F),
        '$putStrLn'(_B, _C, _F, _E).

'$$apply_1'(cont1, _A, _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont1, _D, _F),
        '$cont1'(_B, _C, _F, _E).

'$$apply_1'(cont2(_A), _B, _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont2(_F), _D, _G),
        '$cont2'(_F, _B, _C, _G, _E).

'$$apply_1'(writeFile(_A), _B, _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeFile(_F), _D, _G),
        '$writeFile'(_F, _B, _C, _G, _E).

'$$apply_1'(readFile, _A, _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFile, _D, _F),
        '$readFile'(_B, _C, _F, _E).

'$$apply_1'(readFileContents, _A, _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFileContents, _D, _F),
        '$readFileContents'(_B, _C, _F, _E).

'$$apply_1'(dVal, _A, _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dVal, _D, _F),
        '$dVal'(_B, _C, _F, _E).

'$$apply_1'(dValToString, _A, _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dValToString, _D, _F),
        '$dValToString'(_B, _C, _F, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B, _C), _D, _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_F, _G, _H), _D, _I),
        '$selectWhereVariableXi'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(if_then_else(_A, _B), _C, _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then_else(_F, _G), _D, _H),
        '$if_then_else'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(if_then(_A), _B, _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then(_F), _D, _G),
        '$if_then'(_F, _B, _C, _G, _E).

'$$apply_1'(flip(_A, _B), _C, _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, flip(_F, _G), _D, _H),
        '$flip'(_F, _G, _B, _C, _H, _E).


/************   CODE FOR INFIX OPERATORS   ************/

infix(^, noasoc, 98).
infix(**, noasoc, 98).
infix(/, left, 90).
infix(*, right, 90).
infix(+, left, 50).
infix(-, left, 50).
infix(<, noasoc, 30).
infix(<=, noasoc, 30).
infix(>, noasoc, 30).
infix(>=, noasoc, 30).
infix(==, noasoc, 10).
infix(/=, noasoc, 10).
infix(>>, left, 11).
infix(>>=, left, 11).



'$flip'(F, A1, A2, H, Cin, Cout):-         '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).
