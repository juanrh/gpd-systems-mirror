%-----------------------------------------------------------------------------%
% dyn.pl
%-----------------------------------------------------------------------------%
/*
- Author: Mercedes

- Description: this module contains the dynamic predicates.

- Modules which they import it:  compil, connected, errortoy, goals, inferrer,
  initToy, process, token, toy.

- Modules imported into it: not one.


- Modified:
    26/11/99 mercedes (Introduction of the real constraints. We have 
               introduced the predicate: assertclpr_active).
    26/01/00 mercedes (ya no se usa pathToy para saber el path donde estan
               los fuentes de TOY, sino que se usa la variable
               de entorno: TOYDIR, por tanto se ha eliminado todo
               lo relativo a pathToy).
%%::B AF
    17/12/01 fernando (Introduction of the finite domain constraints. We have 
                           introduced the predicate: assertcflpfd_active).
%%::E

%%::B Sonia
    20/6/06 Sonia (Introduzco el predicado assertproj_active para activar las proyecciones).
%%::E

*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(dyn,[typeError/0,asserttypeError/0,
          development_version/0,assertdevelopment_version/0,functiontype/2,
          assertfunctiontype/2,lexicon_error/2,assertlexicon_error/2,
          biggest_sintactic_error/3,assertbiggest_sintactic_error/3,
          depFun/2,assertdepFun/2,asserttables/1,assertfile/3,file/3,
          retractfile/3,retracttables/1,retractbiggest_sintactic_error/3,
          retractlexicon_error/2,retractalltypeError/0,my_abolish/1,
          assertio_active/0,retractio_active/0,io_active/0,
          assertiographic_active/0,retractiographic_active/0,iographic_active/0,
          clpr_active/0,assertclpr_active/0,
%%::B
          cflpfd_active/0,assertcflpfd_active/0,
%%::E
%%::B Sonia
          proj_active/0,assertproj_active/0,
          tolerance_active/1,asserttolerance_active/1,
%%::E Sonia
          assertamap/2,retractmap/2,map/2,varmut/2,assertavarmut/2,
          retractvarmut/2,retractallvarmut/2,
          contvar/1,assertacontvar/1,retractcontvar/1,retractallcontvar/1,
          latestNameVar/1,assertlatestNameVar/1,retractlatestNameVar/1,
          retractalllatestNameVar/0,
          retractdebugando/0,assertdebugando/0, debugando/0,
%%:: rafa 04-05-2004          
%%::B
       runTimeStatisticsLevel/1, initialRunTimeStatistics/0,initialRunTimeStatistics/0,
          assertRunTimeStatisticsLevel/1,getRunTimeStatisticsLevel/1,
          createRunTimeStatistics/0, hnfRunTimeStatistics/0,finalRunTimeStatistics/11,
      putLastCommand/1, getLastCommand/1,retractDDTFlag/0,assertDDTFlag/0, 
      ddtFlag/0,nAnswer/1,incNAnswer/0,getNAnswer/1,resetNAnswer/0,removeNAnswer/0,
          debugCounter/1,incDebugCounter/0,getDebugCounter/1,resetDebugCounter/0, 
          removeDebugCounter/0,
%%::E
      
%%:: rafa 03-07-05  
      setTot/1, getTot/1,
%::E

%%:: yoli 25-01-06  
      setCut/1, getCut/1
%::E

      ]).
      


:- dynamic development_version/0.

:- dynamic functiontype/2, typeError/0.

:- dynamic lexicon_error/2.

:- dynamic biggest_sintactic_error/3.

:- dynamic depFun/2.

:- dynamic clpr_active/0.

%%::B
:- dynamic cflpfd_active/0.
%%::E

%%::B Sonia
:- dynamic proj_active/0.
:- dynamic tolerance_active/1.
%%::E Sonia

% 11/05/00 mercedes
% Se necesita para la entrada/salida

:- dynamic file/3.

% 12/05/00 mercedes
% Se necesita para introducir la libreria de e/s de ficheros
:- dynamic io_active/0.


% 29/05/00 mercedes
% Se necesita para introducir la libreria de e/s grafica
:- dynamic iographic_active/0.

% 13/06/00 mercedes
% Se necesita para introducir las listas intensionales
:- dynamic map/2.


% 14/09/00 mercedes
% Para las variables mutables
:- dynamic varmut/2.

:- dynamic contvar/1.


% Depu 11/10/00 mercedes
:- dynamic latestNameVar/1.
% Fin Depu

% Depu 05/06/05 rafa
:- dynamic nAnswer/1.
:- dynamic debugCounter/1.
:- dynamic tot/1.
% Fin Depu

% 24/01/06 yoli
:- dynamic cut/1.
%

% Depu 25/10/00 mercedes
:- dynamic debugando/0.
% Fin Depu

% Statistics 8/02/03 rafa
:- dynamic initialRunTimeStatistics/10.
:- dynamic maxRunTimeStatistics/10.
:- dynamic runTimeStatisticsLevel/1.
% Fin Statistics


% lastCommand  23/11/02 rafa
:- dynamic lastCommand/1.
% Fin lastCommand


% ddtFlag 29/09/03 rafa
:- dynamic ddtFlag/0.


asserttypeError:- assert(typeError).

assertdevelopment_version:- assert(development_version).

assertfunctiontype(Name,Type):- assert(functiontype(Name,Type)).

assertlexicon_error(Code,Line):- assert(lexicon_error(Code,Line)).

assertbiggest_sintactic_error(Depth,Exp,Find):-
    assert(biggest_sintactic_error(Depth,Exp,Find)).

assertdepFun(F,G):- assert(depFun(F,G)).

asserttables(Tables):- assert(Tables).


% 11/05/00 mercedes
% Se necesita para la entrada/salida

assertfile(Name,Mode,Handle):- assert(file(Name,Mode,Handle)).

retractfile(N,M,Handle):- retract(file(N,M,Handle)).

retracttables(Tables):- retract(Tables).

retractbiggest_sintactic_error(Depth,Exp,Find):-
    retract(biggest_sintactic_error(Depth,Exp,Find)).
    
retractlexicon_error(Code,Line):- retract(lexicon_error(Code,Line)).

retractalltypeError:- retractall(typeError).

assertclpr_active:- assert(clpr_active).

%%::B
assertcflpfd_active:- assert(cflpfd_active).
%%::E

%%::B Sonia
assertproj_active:- assert(proj_active).
asserttolerance_active(X):- my_abolish(tolerance_active/1), assert(tolerance_active(X)).
%%::E Sonia

%:: rafa 03/07/05 controlling totality constraints
%::B
setTot(X) :- my_abolish(tot/1), assert(tot(X)).
getTot(X) :- tot(X).  
%::E


%:: yoli 24/01/06 controlling dynamic cut optimization
%::B
setCut(X) :- my_abolish(cut/1), assert(cut(X)).
getCut(X) :- cut(X).  
%::E

% 12/05/00 mercedes
% Se necesita para la libreria de e/s de ficheros

assertio_active:- assert(io_active).

retractio_active:- retract(io_active).


% 29/05/00 mercedes
% Se necesita para la libreria de e/s grafica

assertiographic_active:- assert(iographic_active).

retractiographic_active:- retract(iographic_active).


% 13/06/00 mercedes
% Se necesita para introducir las listas intensionales

assertamap(F,C):- asserta(map(F,C)).

retractmap(F,C):- retract(map(F,C)).


% 14/09/00 mercedes
% Para las variables mutables

assertavarmut(N,V):- asserta(varmut(N,V)).

retractvarmut(N,V):- retract(varmut(N,V)).

retractallvarmut(N,V):- retractall(varmut(N,V)).

assertacontvar(N):- asserta(contvar(N)).

retractcontvar(N):- retract(contvar(N)).

retractallcontvar(N):- retractall(contvar(N)).



% Depu 11/10/00 mercedes
assertlatestNameVar(Name):- assert(latestNameVar(Name)).
retractlatestNameVar(N):- retract(latestNameVar(N)).
retractalllatestNameVar:- my_abolish(latestNameVar/1).
% Fin Depu

% Depu  rafa  17-11-04. 

resetNAnswer  :- removeNAnswer, assert(nAnswer(0)).
incNAnswer    :- retract(nAnswer(N)),!, M is N+1, assert(nAnswer(M)).
incNAnswer    :-  assert(nAnswer(1)).
getNAnswer(N) :- retract(nAnswer(N)),!, assert(nAnswer(N)).
getNAnswer(0) :- assert(nAnswer(0)).
removeNAnswer :- my_abolish(nAnswer/1).

resetDebugCounter  :- removeDebugCounter, assert(debugCounter(0)).
incDebugCounter    :- retract(debugCounter(N)),!, M is N+1, assert(debugCounter(M)).
incDebugCounter    :- assert(debugCounter(1)).
getDebugCounter(N) :- retract(debugCounter(N)),!, assert(debugCounter(N)).
getDebugCounter(0) :- !, assert(debugCounter(0)).
removeDebugCounter :- my_abolish(debugCounter/1).


% Fin Depu

% Depu 25/10/00 mercedes 
assertdebugando :- assert(debugando).

retractdebugando :- retract(debugando).

% Fin Depu

% DDT 23/09/03 rafa
assertDDTFlag :- assert(ddtFlag).

retractDDTFlag :- retract(ddtFlag).
% Fin DDT



% lastCommand 23/11/02 rafa %%%%%%%%%%%%%%%%%%%%%%%%%
putLastCommand("/!") :- !, true. 
putLastCommand(X) :- removeLastCommand,  assert(lastCommand(X)).
getLastCommand(X) :- retract(lastCommand(X)),  assert(lastCommand(X)).
removeLastCommand :- my_abolish(lastCommand/1).

% Fin lastCommand  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% runTimeStatistics 08/02/03 rafa %%%%%%%%%%%%%%%%%%%%%%%%%
% There are 3 levels: 0 ->no statistics; 1->runtime; 2-> full statistics
assertRunTimeStatisticsLevel(X)   :- retractRunTimeStatisticsLevel,assert(runTimeStatisticsLevel(X)).
retractRunTimeStatisticsLevel       :- my_abolish(runTimeStatisticsLevel/1).
getRunTimeStatisticsLevel(X)    :- runTimeStatisticsLevel(X).

assertInitialRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10) :-
                    assert(initialRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10)).
retractInitialRunTimeStatistics         :- my_abolish(initialRunTimeStatistics/10).
getRetractInitialRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10)  :-
                    retract(initialRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10)).


assertMaxRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10) :-
                    assert(maxRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10)).
retractMaxRunTimeStatistics         :- my_abolish(maxRunTimeStatistics/10).
getRetractMaxRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10)  :-
                    !,
                    retract(maxRunTimeStatistics(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10)).


% createStatistics
createRunTimeStatistics :- 
                       getRunTimeStatisticsLevel(N),
                       my_abolish(maxRunTimeStatistics/10),
                       my_abolish(initialRunTimeStatistics/10),
                       gc,
                       N > 2,
                       !,
                       trimcore,
                                           garbage_collect,
                       garbage_collect_atoms,
                       % nogc,
                           initiateStatistics.

createRunTimeStatistics :- getRunTimeStatisticsLevel(2),
                       !,
                       initiateStatistics.

createRunTimeStatistics :- getRunTimeStatisticsLevel(1),
                       !,
                                           statistics(runtime,_).
createRunTimeStatistics :- getRunTimeStatisticsLevel(0),
                       !.
initiateStatistics :-
                                           statistics(runtime,_),
                       getCurrentStatistics(Gs,Ls,T,C,M,P,SS,A,W),
                                           assertMaxRunTimeStatistics(0,Gs,Ls,T,C,M,P,SS,A,W),
                       assertInitialRunTimeStatistics(0,Gs,Ls,T,C,M,P,SS,A,W).

% hnfRunTimeStatistics
% it is called after any hnf to change the statistics
hnfRunTimeStatistics :- getRunTimeStatisticsLevel(N),
                    N >=2,
                    getCurrentStatistics(Gs,Ls,T,C,M,P,SS,A,W),
                    getRetractMaxRunTimeStatistics(MHC,MGs,MLs,MT,MC,MM,MP,MSS,MA,MW),
                    !,
                    NHC is MHC+1,
                    max(Gs,MGs,NGs),
                    max(Ls,MLs,NLs),
                    max(T,MT,NT),
                    max(C,MC,NC),
                    max(M,MM,NM),
                    max(P,MP,NP),
                    max(SS,MSS,NSS),
                    max(A,MA,NA),
                    max(W,MW,NW),
                    assertMaxRunTimeStatistics(NHC,NGs,NLs,NT,NC,NM,NP,NSS,NA,NW).

hnfRunTimeStatistics :- !.

% returns the final statistics
finalRunTimeStatistics(Runtime,Hnfs,GlobalStack,LocalStack,
                                    Trails,Choices,Memory,Program,StackShifts,Atoms,Walltime) :-
                                     getRunTimeStatisticsLevel(N),
                     N>=2,
                     getRetractMaxRunTimeStatistics(MHnfs,MGs,MLs,MT,MC,MM,MP,MSS,MA,MW),
                                     getRetractInitialRunTimeStatistics(IHnfs,IGs,ILs,IT,IC,IM,IP,ISS,IA,IW),
                     !,
                     statistics(runtime,[_,Runtime]),
                     Hnfs is MHnfs - IHnfs,
                     GlobalStack is MGs-IGs,
                     LocalStack is MLs - ILs,
                     Trails is MT - IT,
                     Choices is MC - IC,
                     Memory is MM - IM,
                     Program is MP-IP,
                     StackShifts is MSS-ISS,
                     Atoms is MA -IA,
                     Walltime is MW-IW,
                     gc.


% in this case, only the runtime will be meaningfull
finalRunTimeStatistics(Runtime,0,0,0,0,0,0,0,0,0,0) :-
                        !,
                        statistics(runtime,[_,Runtime]),
                    gc.



getCurrentStatistics(Gs,Ls,T,C,M,P,SS,A,W) :-
                       !,
                       statistics(global_stack,[Gs,_]),
                       statistics(local_stack,[Ls,_]),
                       statistics(trail,[T,_]),
                       statistics(choice,[C,_]),
                       statistics(memory,[M,_]),
                       statistics(program,[P,_]),
                       statistics(stack_shifts,[SS,_,_]),
                       statistics(atoms,[A,_,_]),
                       statistics(walltime,[W,_]).
max(A,B,A) :- A>=B,!.
max(A,B,B) :- !.

% Fin  runtTimeStatistics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------------------------------%
% my_abolish(+Name/+Ar) where Name/Ar: name and arity of the term that we want
%                      to eliminate of the data base.
% This predicate is used to delete the term Name of the data base. If the term
% is in the data base then this predicate delete it, else this predicate don't
% show an error message (abolish would show an error message in this case).
%-----------------------------------------------------------------------------%

my_abolish(Name/Arity):-
    functor(Term,Name,Arity),
    retractall(Term).
    
%   call(Term),
%   !,
%   abolish(Name/Arity).


my_abolish(_).
