

user:portray_message(warning,_):- write('').

:- module(plgenerated,[sourceFileNameStr/1,hnf_susp/5,constr/4,funct/5,infix/3,'$$apply'/5,'$flip'/6,'$init_fd' /3,'$write' /4,'$nl' /3,$#== /5,$#/== /5,'$domain' /6,'$subset' /5,'$inset' /5,'$setcomplement' /5,'$intersect' /5,'$belongs' /5,'$labeling' /5,'$indomain' /4,'$fdminimize' /5,'$fdmaximize' /5,$#= /5,$#\= /5,$#< /5,$#<= /5,$#> /5,$#>= /5,$#+ /5,$#- /5,$#* /5,$#/ /5,$#& /5,'$sum' /6,'$scalar_product' /7,'$all_different' /4,'$all_different\'' /5,'$assignment' /5,'$circuit' /4,'$circuit\'' /5,'$count' /7,'$element' /6,'$exactly' /6,'$serialized' /5,'$serialized\'' /6,'$cumulative' /7,'$cumulative\'' /8,$#\/ /5,$#<=> /5,$#=> /5,'$fd_var' /4,'$fd_min' /4,'$fd_max' /4,'$fd_size' /4,'$fd_set' /4,'$fd_dom' /4,'$fd_degree' /4,'$fd_neighbors' /4,'$fd_closure' /4,'$inf' /3,'$sup' /3,'$is_fdset' /4,'$empty_fdset' /4,'$fdset_parts' /6,'$fdset_split' /4,'$empty_interval' /5,'$fdset_to_interval' /4,'$interval_to_fdset' /5,'$fdset_singleton' /5,'$fdset_min' /4,'$fdset_max' /4,'$fdset_size' /4,'$list_to_fdset' /4,'$fdset_to_list' /4,'$range_to_fdset' /4,'$fdset_to_range' /4,'$fdset_add_element' /5,'$fdset_del_element' /5,'$fdset_intersection' /5,'$fdset_subtract' /5,'$fdset_union' /5,'$fdset_complement' /4,'$fdsets_intersection' /4,'$fdsets_union' /4,'$fdset_equal' /5,'$fdset_subset' /5,'$fdset_disjoint' /5,'$fdset_intersect' /5,'$fdset_member' /5,'$fdset_belongs' /5,'$isin' /5,'$minimum' /4,'$fd_statistics' /3,'$fd_statistics\'' /4,'$fd_global' /6,'$end_fd' /3,'$and' /5,'$or' /5,$/\ /5,$\/ /5,'$not' /4,'$andL' /3,'$orL' /3,'$orL\'' /3,'$any' /4,'$any\'' /4,'$all' /4,'$undefined' /3,'$def' /4,'$not_undef' /4,'$nf' /4,'$hnf' /4,'$strict' /5,'$strict\'' /5,'$map' /5,$. /6,$++ /5,'$!!' /5,'$iterate' /5,'$repeat' /4,'$copy' /5,'$filter' /5,'$foldl' /6,'$foldl1' /5,'$foldl\'' /6,'$scanl' /6,'$scanl1' /5,'$scanl\'' /6,'$foldr' /6,'$foldr1' /5,'$scanr' /6,'$auxForScanr' /6,'$scanr1' /5,'$take' /5,'$drop' /5,'$splitAt' /5,'$auxForSplitAt' /5,'$takeWhile' /5,'$takeUntil' /5,'$dropWhile' /5,'$span' /5,'$auxForSpan' /5,'$break' /4,'$zipWith' /6,'$zip' /5,'$mkpair' /5,'$unzip' /4,'$auxForUnzip' /6,'$until' /6,'$until\'' /5,'$const' /5,'$id' /4,$// /5,'$curry' /6,'$uncurry' /5,'$fst' /4,'$snd' /4,'$fst3' /4,'$snd3' /4,'$thd3' /4,'$subtract' /3,'$even' /4,'$odd' /3,'$lcm' /5,'$head' /4,'$last' /4,'$tail' /4,'$init' /4,'$nub' /4,'$length' /4,'$size' /3,'$reverse' /3,'$member' /3,'$notMember' /3,'$concat' /3,'$transpose' /3,'$auxForTranspose' /5,$\\ /3,'$del' /5,'$incidencias' /3,'$unasemana' /3,'$unmes' /3,'$dosmeses' /3,'$tresmeses' /3,'$cuatromeses' /3,'$cincomeses' /3,'$seismeses' /3,'$ochomeses' /3,'$diezmeses' /3,'$anio' /3,'$laborable' /3,'$festivo' /3,'$especial' /3,'$no' /3,'$t1' /3,'$t2' /3,'$t3' /3,'$t4' /3,'$t5' /3,'$t6' /3,'$bj' /3,'$vc' /3,'$grupo_activo' /4,'$incrementar' /5,'$crear_incidencias' /6,'$proc_incidencia' /5,'$inicio' /4,'$incidencias_dia' /5,'$proc_vacaciones' /5,'$vacaciones_dia' /5,'$proc_bajas' /5,'$bajas_dia' /5,'$crear_grupos' /5,'$solicitaNoche' /5,'$puedeNoche' /4,'$t13trabaja_noche' /5,'$j1' /3,'$j2' /3,'$j3' /3,'$j4' /3,'$crear_plan_jornadas' /6,'$crear_trabajo' /4,'$crear_planificacion' /5,'$borrar_uno' /4,'$quitar_primeros' /4,'$prim' /4,'$primeros' /4,'$listas_vacias' /4,'$transponer' /4,'$crear_fila' /4,'$crear_tabla' /5,'$anotar_en_trabajador' /5,'$anotar_una' /5,'$anotar_incidencias' /5,'$procesar_jornadas' /9,'$contar' /5,'$empaquetar' /5,'$proyectar' /4,'$anotar_trab' /4,'$anotar_desc' /4,'$descansar' /7,'$trabajar' /7,'$grupo' /4,'$procesar_tipo_dia' /7,'$procesar_dia' /10,'$procesar_trabajo' /10,'$trab_comodin' /7,'$trabajar_comodin' /7,'$proc_t6' /4,'$sin_t6' /4,'$no_t6' /4,'$valido_laborables' /4,'$valido_festivos' /4,'$extrayendo' /7,'$extraer_turnos' /6,'$sacar_laborables' /4,'$extraer_laborables' /4,'$sacar_festivos' /4,'$extraer_festivos' /4,'$rotar_turnos_laborables' /4,'$rotar_turnos_festivos' /4,'$imponer_rotaciones' /6,'$rango_jornadas' /4,'$establecer_dominios' /4,'$etiquetar' /5,'$extraer' /4,'$etiquetar\'' /5,'$m0_0' /4,'$m1_24' /4,'$m2_14' /4,'$m3_14' /4,'$m4_17' /4,'$m5_13' /4,'$m6_6' /4,'$m7_6' /4,'$m8_0' /4,'$duracion\'' /4,'$duracion' /4,'$horasTrabajador' /4,'$trabajoMes' /6,'$hm' /8,'$horasMesTrabajador' /8,'$horasCadaMes' /7,'$horasCadaAnio' /6,'$obtenerMes' /4,'$calcularMesUltimo' /4,'$numeroMes' /5,'$horasMes' /6,'$horasAnio' /4,'$planificar' /6,'$sig_laborable' /4,'$sig_festivo' /4,'$extrayendo2' /7,'$extraer_turnos2' /6,'$escribir_lab' /5,'$escribir_laborables' /5,'$escribir_fes' /5,'$escribir_festivos' /5,'$establecer_des' /6,'$establecer_descanso' /5,'$primera_sol' /6,'$apuntar' /5,'$actividad_comodin' /8,'$primera_sol_act' /8,'$reapuntar' /4,'$planificar_una' /5,'$j2esj1' /4,'$inizio' /5,'$resto' /5,'$generar_lista' /5,'$intentar' /5,'$mi_busqueda' /5,'$esNocturno' /4,'$elemento' /5,'$deXhastaY' /5,'$div\'' /5,'$sustituir' /6,'$ultimo' /4,'$n_menos_1' /4,'$invertir' /4,'$card' /4,'$eliminar' /5,'$ini' /4,'$iniln' /4]).

:- dynamic $== /5, $/= /5.

:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed)]).

:- tools:complete_root_filename(primFunct,F),load_files(F,[if(changed)]).

:- tools:complete_root_filename(primitivCodClpr,F),load_files(F,[if(changed)]).






:- use_module(library(clpfd)).

% nombre del fichero fuente
sourceFileNameStr('timetabling').


/**************    CODE FOR FUNCTIONS    **************/


% init_f
% and
'$and'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$and_1'(_F, _B, _C, _G, _E).
'$and'(_A, _B, false, _C, _D):-
        hnf(_B, false, _C, _D).
'$and_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$and_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _E),
        hnf(_B, true, _E, _D).

% or
'$or'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$or_1'(_F, _B, _C, _G, _E).
'$or'(_A, _B, true, _C, _D):-
        hnf(_B, true, _C, _D).
'$or_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$or_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _E),
        hnf(_B, false, _E, _D).

% /\
$/\(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$/\\_1'(_F, _B, _C, _G, _E).
'$/\\_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$/\\_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, true, _D, _F),
        hnf(_B, _C, _F, _E).

% \/
$\/(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$\\/_1'(_F, _B, _C, _G, _E).
'$\\/_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$\\/_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, false, _D, _F),
        hnf(_B, _C, _F, _E).

% not
'$not'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$not_1'(_E, _B, _F, _D).
'$not_1'(_A, false, _B, _C):-
        unifyHnfs(_A, true, _B, _C).
'$not_1'(_A, true, _B, _C):-
        unifyHnfs(_A, false, _B, _C).

% andL
'$andL'(foldr(/\, true), _A, _A).

% orL
'$orL'(foldr(or, false), _A, _A).

% 'orL\''
'$orL\''(foldr(\/, false), _A, _A).

% any
'$any'(_A, '.'('$$susp'( '$orL',  [], _B, _C ), map(_A)), _D, _D).

% 'any\''
'$any\''(_A, '.'('$$susp'( '$orL\'',  [], _B, _C ), map(_A)), _D, _D).

% all
'$all'(_A, '.'('$$susp'( '$andL',  [], _B, _C ), map(_A)), _D, _D).

% undefined
'$undefined'(_A, _B, _C):-
        '$if_then'(false, '$$susp'( '$undefined',  [], _D, _E ), _A, _B, _C).

% def
'$def'(_A, true, _B, _C):-
        '$$eqFun'(_A, _D, true, _B, _C).

% not_undef
'$not_undef'(_A, true, _B, _C):-
        '$$notEqFun'(_A, _D, true, _B, _C).

% nf
'$nf'(_A, _B, _C, _D):-
        equal(_A, _E, _C, _F),
        hnf(_E, _B, _F, _D).

% hnf
'$hnf'(_A, _B, _C, _D):-
        notEqual(_A, _E, _C, _F),
        hnf(_A, _B, _F, _D).

% strict
'$strict'(_A, _B, _C, _D, _E):-
        equal(_B, _F, _D, _G),
        '$$apply'(_A, _F, _C, _G, _E).

% 'strict\''
'$strict\''(_A, _B, _C, _D, _E):-
        notEqual(_B, _F, _D, _G),
        '$$apply'(_A, _B, _C, _G, _E).

% map
'$map'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$map_2'(_A, _F, _C, _G, _E).
'$map_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$map_2'(_A, _B, :('$$susp'( '$$apply', [ _A, _C ], _D, _E ), '$$susp'( '$map', [ _A, _F ], _G, _H )), _I, _J):-
        unifyHnfs(_B, :(_C, _F), _I, _J).

% '.'
$.(_A, _B, _C, _D, _E, _F):-
        '$$apply'(_A, '$$susp'( '$$apply', [ _B, _C ], _G, _H ), _D, _E, _F).

% ++
$++(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$++_1'(_F, _B, _C, _G, _E).
'$++_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, _C, _F, _E).
'$++_1'(_A, _B, :(_C, '$$susp'( $++, [ _D, _B ], _E, _F )), _G, _H):-
        unifyHnfs(_A, :(_C, _D), _G, _H).

% '!!'
'$!!'(_A, _B, _C, _D, _E):-
        hnf(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _B, 0 ], _I, _J ), _F, '$$susp'( '$!!', [ _G, '$$susp'( $-, [ _B, 1 ], _K, _L ) ], _M, _N ), _C, _H, _E).

% iterate
'$iterate'(_A, _B, :(_B, '$$susp'( '$iterate', [ _A, '$$susp'( '$$apply', [ _A, _B ], _C, _D ) ], _E, _F )), _G, _G).

% repeat
'$repeat'(_A, :(_A, '$$susp'( '$repeat', [ _A ], _B, _C )), _D, _D).

% copy
'$copy'(_A, _B, _C, _D, _E):-
        '$take'(_A, '$$susp'( '$repeat', [ _B ], _F, _G ), _C, _D, _E).

% filter
'$filter'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$filter_2'(_A, _F, _C, _G, _E).
'$filter_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$filter_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), :(_F, '$$susp'( '$filter', [ _A, _G ], _K, _L )), '$$susp'( '$filter', [ _A, _G ], _M, _N ), _C, _H, _E).

% foldl
'$foldl'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldl_3'(_A, _B, _G, _D, _H, _F).
'$foldl_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldl_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$foldl'(_A, '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _J, _K ), _G ], _L, _M ), _H, _D, _I, _F).

% foldl1
'$foldl1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        '$foldl'(_A, _F, _G, _C, _H, _E).

% 'foldl\''
'$foldl\''(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldl\'_3'(_A, _B, _G, _D, _H, _F).
'$foldl\'_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldl\'_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$strict', [ 'foldl\''(_A), '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _J, _K ), _G ], _L, _M ) ], _N, _O ), _H, _D, _I, _F).

% scanl
'$scanl'(_A, _B, _C, :(_D, _E), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$scanl_3'(_A, _B, _H, :(_D, _E), _I, _G).
'$scanl_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanl_3'(_A, _B, _C, :(_B, '$$susp'( '$scanl', [ _A, '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _D, _E ), _F ], _G, _H ), _I ], _J, _K )), _L, _M):-
        unifyHnfs(_C, :(_F, _I), _L, _M).

% scanl1
'$scanl1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        '$scanl'(_A, _F, _G, _C, _H, _E).

% 'scanl\''
'$scanl\''(_A, _B, _C, :(_D, _E), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$scanl\'_3'(_A, _B, _H, :(_D, _E), _I, _G).
'$scanl\'_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanl\'_3'(_A, _B, _C, :(_B, '$$susp'( '$$apply', [ '$$susp'( '$strict', [ 'scanl\''(_A), '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _D, _E ), _F ], _G, _H ) ], _I, _J ), _K ], _L, _M )), _N, _O):-
        unifyHnfs(_C, :(_F, _K), _N, _O).

% foldr
'$foldr'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldr_3'(_A, _B, _G, _D, _H, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$$apply', [ _A, _G ], _J, _K ), '$$susp'( '$foldr', [ _A, _B, _H ], _L, _M ), _D, _I, _F).

% foldr1
'$foldr1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        hnf(_G, _I, _H, _J),
        '$foldr1_2_2.2_:'(_A, _F, _I, _C, _J, _E).
'$foldr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$$apply', [ _A, _B ], _J, _K ), '$$susp'( '$foldr1', [ _A, :(_G, _H) ], _L, _M ), _D, _I, _F).

% scanr
'$scanr'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$scanr_3'(_A, _B, _G, _D, _H, _F).
'$scanr_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$auxForScanr'(_A, _G, '$$susp'( '$scanr', [ _A, _B, _H ], _J, _K ), _D, _I, _F).

% auxForScanr
'$auxForScanr'(_A, _B, _C, :('$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _D, _E ), '$$susp'( '$head', [ _C ], _F, _G ) ], _H, _I ), _C), _J, _J).

% scanr1
'$scanr1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        hnf(_G, _I, _H, _J),
        '$scanr1_2_2.2_:'(_A, _F, _I, _C, _J, _E).
'$scanr1_2_2.2_:'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$auxForScanr'(_A, _B, '$$susp'( '$scanr1', [ _A, :(_G, _H) ], _J, _K ), _D, _I, _F).

% take
'$take'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$take_2'(_A, _F, _C, _G, _E).
'$take_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$take_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, 0 ], _I, _J ), [], :(_F, '$$susp'( '$take', [ '$$susp'( $-, [ _A, 1 ], _K, _L ), _G ], _M, _N )), _C, _H, _E).

% drop
'$drop'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$drop_2'(_A, _F, _C, _G, _E).
'$drop_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$drop_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, 0 ], _I, _J ), :(_F, _G), '$$susp'( '$drop', [ '$$susp'( $-, [ _A, 1 ], _K, _L ), _G ], _M, _N ), _C, _H, _E).

% splitAt
'$splitAt'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$splitAt_2'(_A, _F, _C, _G, _E).
'$splitAt_2'(_A, _B, '$$tup'(','([], [])), _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$splitAt_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, 0 ], _I, _J ), '$$tup'(','([], :(_F, _G))), '$$susp'( '$auxForSplitAt', [ _F, '$$susp'( '$splitAt', [ '$$susp'( $-, [ _A, 1 ], _K, _L ), _G ], _M, _N ) ], _O, _P ), _C, _H, _E).

% auxForSplitAt
'$auxForSplitAt'(_A, _B, '$$tup'(','(:(_A, _C), _D)), _E, _F):-
        hnf(_B, '$$tup'(_G), _E, _H),
        hnf(_G, ','(_C, _D), _H, _F).

% takeWhile
'$takeWhile'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$takeWhile_2'(_A, _F, _C, _G, _E).
'$takeWhile_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$takeWhile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), :(_F, '$$susp'( '$takeWhile', [ _A, _G ], _K, _L )), [], _C, _H, _E).

% takeUntil
'$takeUntil'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$takeUntil_2'(_A, _F, _C, _G, _E).
'$takeUntil_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$takeUntil_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), :(_F, []), :(_F, '$$susp'( '$takeUntil', [ _A, _G ], _K, _L )), _C, _H, _E).

% dropWhile
'$dropWhile'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$dropWhile_2'(_A, _F, _C, _G, _E).
'$dropWhile_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$dropWhile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), '$$susp'( '$dropWhile', [ _A, _G ], _K, _L ), :(_F, _G), _C, _H, _E).

% span
'$span'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$span_2'(_A, _F, _C, _G, _E).
'$span_2'(_A, _B, '$$tup'(','([], [])), _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$span_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), '$$susp'( '$auxForSpan', [ _F, '$$susp'( '$span', [ _A, _G ], _K, _L ) ], _M, _N ), '$$tup'(','([], :(_F, _G))), _C, _H, _E).

% auxForSpan
'$auxForSpan'(_A, _B, '$$tup'(','(:(_A, _C), _D)), _E, _F):-
        hnf(_B, '$$tup'(_G), _E, _H),
        hnf(_G, ','(_C, _D), _H, _F).

% break
'$break'(_A, span('.'(not, _A)), _B, _B).

% zipWith
'$zipWith'(_A, _B, _C, _D, _E, _F):-
        hnf(_B, _G, _E, _H),
        '$zipWith_2'(_A, _G, _C, _D, _H, _F).
'$zipWith_2'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_B, [], _D, _E).
'$zipWith_2'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, :(_G, _H), _E, _I),
        hnf(_C, _J, _I, _K),
        '$zipWith_2_3_:'(_A, _G, _H, _J, _D, _K, _F).
'$zipWith_2_3_:'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_D, [], _E, _F).
'$zipWith_2_3_:'(_A, _B, _C, _D, :('$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _E, _F ), _G ], _H, _I ), '$$susp'( '$zipWith', [ _A, _C, _J ], _K, _L )), _M, _N):-
        unifyHnfs(_D, :(_G, _J), _M, _N).

% zip
'$zip'(_A, _B, _C, _D, _E):-
        '$zipWith'(mkpair, _A, _B, _C, _D, _E).

% mkpair
'$mkpair'(_A, _B, '$$tup'(','(_A, _B)), _C, _C).

% unzip
'$unzip'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$unzip_1'(_E, _B, _F, _D).
'$unzip_1'(_A, '$$tup'(','([], [])), _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$unzip_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        '$auxForUnzip'(_J, _K, '$$susp'( '$unzip', [ _F ], _M, _N ), _B, _L, _D).

% auxForUnzip
'$auxForUnzip'(_A, _B, _C, '$$tup'(','(:(_A, _D), :(_B, _E))), _F, _G):-
        hnf(_C, '$$tup'(_H), _F, _I),
        hnf(_H, ','(_D, _E), _I, _G).

% until
'$until'(_A, _B, _C, _D, _E, _F):-
        '$if_then_else'('$$susp'( '$$apply', [ _A, _C ], _G, _H ), _C, '$$susp'( '$until', [ _A, _B, '$$susp'( '$$apply', [ _B, _C ], _I, _J ) ], _K, _L ), _D, _E, _F).

% 'until\''
'$until\''(_A, _B, '.'(takeUntil(_A), iterate(_B)), _C, _C).

% const
'$const'(_A, _B, _C, _D, _E):-
        hnf(_A, _C, _D, _E).

% id
'$id'(_A, _B, _C, _D):-
        hnf(_A, _B, _C, _D).

% //
$//(_A, _B, _C, _D, _E):-
        hnf(_A, _C, _D, _E).
$//(_A, _B, _C, _D, _E):-
        hnf(_B, _C, _D, _E).

% curry
'$curry'(_A, _B, _C, _D, _E, _F):-
        '$$apply'(_A, '$$tup'(','(_B, _C)), _D, _E, _F).

% uncurry
'$uncurry'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        '$$apply'('$$susp'( '$$apply', [ _A, _H ], _K, _L ), _I, _C, _J, _E).

% fst
'$fst'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_G, _B, _I, _D).

% snd
'$snd'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, _B, _I, _D).

% fst3
'$fst3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_G, _B, _L, _D).

% snd3
'$snd3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_J, _B, _L, _D).

% thd3
'$thd3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_K, _B, _L, _D).

% subtract
'$subtract'(flip(-), _A, _A).

% even
'$even'(_A, _B, _C, _D):-
        '$$eqFun'('$$susp'( '$mod', [ _A, 2 ], _E, _F ), 0, _B, _C, _D).

% odd
'$odd'('.'(not, even), _A, _A).

% lcm
'$lcm'(_A, _B, _C, _D, _E):-
        '$if_then_else'('$$susp'( $\/, [ '$$susp'( '$$eqFun', [ _A, 0 ], _F, _G ), '$$susp'( '$$eqFun', [ _B, 0 ], _H, _I ) ], _J, _K ), 0, '$$susp'( '$abs', [ '$$susp'( $*, [ '$$susp'( '$div', [ _A, '$$susp'( '$gcd', [ _A, _B ], _L, _M ) ], _N, _O ), _B ], _P, _Q ) ], _R, _S ), _C, _D, _E).

% head
'$head'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_E, _B, _G, _D).

% last
'$last'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$last_1_1.2_:'(_E, _H, _B, _I, _D).
'$last_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, [], _D, _F),
        hnf(_A, _C, _F, _E).
'$last_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$last'(:(_F, _G), _C, _H, _E).

% tail
'$tail'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _B, _G, _D).

% init
'$init'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$init_1_1.2_:'(_E, _H, _B, _I, _D).
'$init_1_1.2_:'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$init_1_1.2_:'(_A, _B, :(_A, '$$susp'( '$init', [ :(_C, _D) ], _E, _F )), _G, _H):-
        unifyHnfs(_B, :(_C, _D), _G, _H).

% nub
'$nub'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$nub_1'(_E, _B, _F, _D).
'$nub_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$nub_1'(_A, :(_B, '$$susp'( '$nub', [ '$$susp'( '$filter', [ '$notEqFun'(_B), _C ], _D, _E ) ], _F, _G )), _H, _I):-
        unifyHnfs(_A, :(_B, _C), _H, _I).

% length
'$length'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$length_1'(_E, _B, _F, _D).
'$length_1'(_A, 0, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$length_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $+(1, '$$susp'( '$length', [ _F ], _H, _I ), _B, _G, _D).

% size
'$size'('.'(length, nub), _A, _A).

% reverse
'$reverse'(foldl(flip(:), []), _A, _A).

% member
'$member'('.'('any\'', '$eqFun'), _A, _A).

% notMember
'$notMember'('.'(all, '$notEqFun'), _A, _A).

% concat
'$concat'(foldr(++, []), _A, _A).

% transpose
'$transpose'(foldr(auxForTranspose, []), _A, _A).

% auxForTranspose
'$auxForTranspose'(_A, _B, _C, _D, _E):-
        '$zipWith'(:, _A, '$$susp'( $++, [ _B, '$$susp'( '$repeat', [ [] ], _F, _G ) ], _H, _I ), _C, _D, _E).

% \\
$\\(foldl(del), _A, _A).

% del
'$del'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$del_1'(_F, _B, _C, _G, _E).
'$del_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$del_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _F, _B ], _I, _J ), _G, '$$susp'( '$del', [ :(_F, _G), _B ], _K, _L ), _C, _H, _E).

% incidencias
'$incidencias'(:('$$tup'(','(1, ','('$$susp'( '$vc',  [], _A, _B ), ','(1, 4)))), :('$$tup'(','(4, ','('$$susp'( '$bj',  [], _C, _D ), ','(1, 5)))), :('$$tup'(','(5, ','('$$susp'( '$vc',  [], _E, _F ), ','(6, 6)))), :('$$tup'(','(7, ','('$$susp'( '$bj',  [], _G, _H ), ','(2, 2)))), :('$$tup'(','(8, ','('$$susp'( '$bj',  [], _I, _J ), ','(5, 5)))), []))))), _K, _K).

% unasemana
'$unasemana'(:('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _A, _B )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _M, _N )))), []))))))), _O, _O).

% unmes
'$unmes'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), []))))))))))))))))))))))))))))))), _KB, _KB).

% dosmeses
'$dosmeses'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _OD, _OD).

% tresmeses
'$tresmeses'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), :('$$tup'(','(3, ','(1, '$$susp'( '$laborable',  [], _OD, _PD )))), :('$$tup'(','(3, ','(2, '$$susp'( '$laborable',  [], _QD, _RD )))), :('$$tup'(','(3, ','(3, '$$susp'( '$festivo',  [], _SD, _TD )))), :('$$tup'(','(3, ','(4, '$$susp'( '$festivo',  [], _UD, _VD )))), :('$$tup'(','(3, ','(5, '$$susp'( '$laborable',  [], _WD, _XD )))), :('$$tup'(','(3, ','(6, '$$susp'( '$laborable',  [], _YD, _ZD )))), :('$$tup'(','(3, ','(7, '$$susp'( '$laborable',  [], _AE, _BE )))), :('$$tup'(','(3, ','(8, '$$susp'( '$laborable',  [], _CE, _DE )))), :('$$tup'(','(3, ','(9, '$$susp'( '$laborable',  [], _EE, _FE )))), :('$$tup'(','(3, ','(10, '$$susp'( '$festivo',  [], _GE, _HE )))), :('$$tup'(','(3, ','(11, '$$susp'( '$festivo',  [], _IE, _JE )))), :('$$tup'(','(3, ','(12, '$$susp'( '$laborable',  [], _KE, _LE )))), :('$$tup'(','(3, ','(13, '$$susp'( '$laborable',  [], _ME, _NE )))), :('$$tup'(','(3, ','(14, '$$susp'( '$laborable',  [], _OE, _PE )))), :('$$tup'(','(3, ','(15, '$$susp'( '$laborable',  [], _QE, _RE )))), :('$$tup'(','(3, ','(16, '$$susp'( '$laborable',  [], _SE, _TE )))), :('$$tup'(','(3, ','(17, '$$susp'( '$festivo',  [], _UE, _VE )))), :('$$tup'(','(3, ','(18, '$$susp'( '$festivo',  [], _WE, _XE )))), :('$$tup'(','(3, ','(19, '$$susp'( '$laborable',  [], _YE, _ZE )))), :('$$tup'(','(3, ','(20, '$$susp'( '$laborable',  [], _AF, _BF )))), :('$$tup'(','(3, ','(21, '$$susp'( '$laborable',  [], _CF, _DF )))), :('$$tup'(','(3, ','(22, '$$susp'( '$laborable',  [], _EF, _FF )))), :('$$tup'(','(3, ','(23, '$$susp'( '$laborable',  [], _GF, _HF )))), :('$$tup'(','(3, ','(24, '$$susp'( '$festivo',  [], _IF, _JF )))), :('$$tup'(','(3, ','(25, '$$susp'( '$festivo',  [], _KF, _LF )))), :('$$tup'(','(3, ','(26, '$$susp'( '$laborable',  [], _MF, _NF )))), :('$$tup'(','(3, ','(27, '$$susp'( '$laborable',  [], _OF, _PF )))), :('$$tup'(','(3, ','(28, '$$susp'( '$laborable',  [], _QF, _RF )))), :('$$tup'(','(3, ','(29, '$$susp'( '$laborable',  [], _SF, _TF )))), :('$$tup'(','(3, ','(30, '$$susp'( '$laborable',  [], _UF, _VF )))), :('$$tup'(','(3, ','(31, '$$susp'( '$festivo',  [], _WF, _XF )))), [])))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _YF, _YF).

% cuatromeses
'$cuatromeses'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), :('$$tup'(','(3, ','(1, '$$susp'( '$laborable',  [], _OD, _PD )))), :('$$tup'(','(3, ','(2, '$$susp'( '$laborable',  [], _QD, _RD )))), :('$$tup'(','(3, ','(3, '$$susp'( '$festivo',  [], _SD, _TD )))), :('$$tup'(','(3, ','(4, '$$susp'( '$festivo',  [], _UD, _VD )))), :('$$tup'(','(3, ','(5, '$$susp'( '$laborable',  [], _WD, _XD )))), :('$$tup'(','(3, ','(6, '$$susp'( '$laborable',  [], _YD, _ZD )))), :('$$tup'(','(3, ','(7, '$$susp'( '$laborable',  [], _AE, _BE )))), :('$$tup'(','(3, ','(8, '$$susp'( '$laborable',  [], _CE, _DE )))), :('$$tup'(','(3, ','(9, '$$susp'( '$laborable',  [], _EE, _FE )))), :('$$tup'(','(3, ','(10, '$$susp'( '$festivo',  [], _GE, _HE )))), :('$$tup'(','(3, ','(11, '$$susp'( '$festivo',  [], _IE, _JE )))), :('$$tup'(','(3, ','(12, '$$susp'( '$laborable',  [], _KE, _LE )))), :('$$tup'(','(3, ','(13, '$$susp'( '$laborable',  [], _ME, _NE )))), :('$$tup'(','(3, ','(14, '$$susp'( '$laborable',  [], _OE, _PE )))), :('$$tup'(','(3, ','(15, '$$susp'( '$laborable',  [], _QE, _RE )))), :('$$tup'(','(3, ','(16, '$$susp'( '$laborable',  [], _SE, _TE )))), :('$$tup'(','(3, ','(17, '$$susp'( '$festivo',  [], _UE, _VE )))), :('$$tup'(','(3, ','(18, '$$susp'( '$festivo',  [], _WE, _XE )))), :('$$tup'(','(3, ','(19, '$$susp'( '$laborable',  [], _YE, _ZE )))), :('$$tup'(','(3, ','(20, '$$susp'( '$laborable',  [], _AF, _BF )))), :('$$tup'(','(3, ','(21, '$$susp'( '$laborable',  [], _CF, _DF )))), :('$$tup'(','(3, ','(22, '$$susp'( '$laborable',  [], _EF, _FF )))), :('$$tup'(','(3, ','(23, '$$susp'( '$laborable',  [], _GF, _HF )))), :('$$tup'(','(3, ','(24, '$$susp'( '$festivo',  [], _IF, _JF )))), :('$$tup'(','(3, ','(25, '$$susp'( '$festivo',  [], _KF, _LF )))), :('$$tup'(','(3, ','(26, '$$susp'( '$laborable',  [], _MF, _NF )))), :('$$tup'(','(3, ','(27, '$$susp'( '$laborable',  [], _OF, _PF )))), :('$$tup'(','(3, ','(28, '$$susp'( '$laborable',  [], _QF, _RF )))), :('$$tup'(','(3, ','(29, '$$susp'( '$laborable',  [], _SF, _TF )))), :('$$tup'(','(3, ','(30, '$$susp'( '$laborable',  [], _UF, _VF )))), :('$$tup'(','(3, ','(31, '$$susp'( '$festivo',  [], _WF, _XF )))), :('$$tup'(','(4, ','(1, '$$susp'( '$festivo',  [], _YF, _ZF )))), :('$$tup'(','(4, ','(2, '$$susp'( '$laborable',  [], _AG, _BG )))), :('$$tup'(','(4, ','(3, '$$susp'( '$laborable',  [], _CG, _DG )))), :('$$tup'(','(4, ','(4, '$$susp'( '$laborable',  [], _EG, _FG )))), :('$$tup'(','(4, ','(5, '$$susp'( '$laborable',  [], _GG, _HG )))), :('$$tup'(','(4, ','(6, '$$susp'( '$festivo',  [], _IG, _JG )))), :('$$tup'(','(4, ','(7, '$$susp'( '$festivo',  [], _KG, _LG )))), :('$$tup'(','(4, ','(8, '$$susp'( '$laborable',  [], _MG, _NG )))), :('$$tup'(','(4, ','(9, '$$susp'( '$laborable',  [], _OG, _PG )))), :('$$tup'(','(4, ','(10, '$$susp'( '$laborable',  [], _QG, _RG )))), :('$$tup'(','(4, ','(11, '$$susp'( '$laborable',  [], _SG, _TG )))), :('$$tup'(','(4, ','(12, '$$susp'( '$laborable',  [], _UG, _VG )))), :('$$tup'(','(4, ','(13, '$$susp'( '$festivo',  [], _WG, _XG )))), :('$$tup'(','(4, ','(14, '$$susp'( '$festivo',  [], _YG, _ZG )))), :('$$tup'(','(4, ','(15, '$$susp'( '$laborable',  [], _AH, _BH )))), :('$$tup'(','(4, ','(16, '$$susp'( '$laborable',  [], _CH, _DH )))), :('$$tup'(','(4, ','(17, '$$susp'( '$laborable',  [], _EH, _FH )))), :('$$tup'(','(4, ','(18, '$$susp'( '$laborable',  [], _GH, _HH )))), :('$$tup'(','(4, ','(19, '$$susp'( '$laborable',  [], _IH, _JH )))), :('$$tup'(','(4, ','(20, '$$susp'( '$festivo',  [], _KH, _LH )))), :('$$tup'(','(4, ','(21, '$$susp'( '$festivo',  [], _MH, _NH )))), :('$$tup'(','(4, ','(22, '$$susp'( '$laborable',  [], _OH, _PH )))), :('$$tup'(','(4, ','(23, '$$susp'( '$laborable',  [], _QH, _RH )))), :('$$tup'(','(4, ','(24, '$$susp'( '$laborable',  [], _SH, _TH )))), :('$$tup'(','(4, ','(25, '$$susp'( '$laborable',  [], _UH, _VH )))), :('$$tup'(','(4, ','(26, '$$susp'( '$laborable',  [], _WH, _XH )))), :('$$tup'(','(4, ','(27, '$$susp'( '$festivo',  [], _YH, _ZH )))), :('$$tup'(','(4, ','(28, '$$susp'( '$festivo',  [], _AI, _BI )))), :('$$tup'(','(4, ','(29, '$$susp'( '$laborable',  [], _CI, _DI )))), :('$$tup'(','(4, ','(30, '$$susp'( '$laborable',  [], _EI, _FI )))), [])))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _GI, _GI).

% cincomeses
'$cincomeses'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), :('$$tup'(','(3, ','(1, '$$susp'( '$laborable',  [], _OD, _PD )))), :('$$tup'(','(3, ','(2, '$$susp'( '$laborable',  [], _QD, _RD )))), :('$$tup'(','(3, ','(3, '$$susp'( '$festivo',  [], _SD, _TD )))), :('$$tup'(','(3, ','(4, '$$susp'( '$festivo',  [], _UD, _VD )))), :('$$tup'(','(3, ','(5, '$$susp'( '$laborable',  [], _WD, _XD )))), :('$$tup'(','(3, ','(6, '$$susp'( '$laborable',  [], _YD, _ZD )))), :('$$tup'(','(3, ','(7, '$$susp'( '$laborable',  [], _AE, _BE )))), :('$$tup'(','(3, ','(8, '$$susp'( '$laborable',  [], _CE, _DE )))), :('$$tup'(','(3, ','(9, '$$susp'( '$laborable',  [], _EE, _FE )))), :('$$tup'(','(3, ','(10, '$$susp'( '$festivo',  [], _GE, _HE )))), :('$$tup'(','(3, ','(11, '$$susp'( '$festivo',  [], _IE, _JE )))), :('$$tup'(','(3, ','(12, '$$susp'( '$laborable',  [], _KE, _LE )))), :('$$tup'(','(3, ','(13, '$$susp'( '$laborable',  [], _ME, _NE )))), :('$$tup'(','(3, ','(14, '$$susp'( '$laborable',  [], _OE, _PE )))), :('$$tup'(','(3, ','(15, '$$susp'( '$laborable',  [], _QE, _RE )))), :('$$tup'(','(3, ','(16, '$$susp'( '$laborable',  [], _SE, _TE )))), :('$$tup'(','(3, ','(17, '$$susp'( '$festivo',  [], _UE, _VE )))), :('$$tup'(','(3, ','(18, '$$susp'( '$festivo',  [], _WE, _XE )))), :('$$tup'(','(3, ','(19, '$$susp'( '$laborable',  [], _YE, _ZE )))), :('$$tup'(','(3, ','(20, '$$susp'( '$laborable',  [], _AF, _BF )))), :('$$tup'(','(3, ','(21, '$$susp'( '$laborable',  [], _CF, _DF )))), :('$$tup'(','(3, ','(22, '$$susp'( '$laborable',  [], _EF, _FF )))), :('$$tup'(','(3, ','(23, '$$susp'( '$laborable',  [], _GF, _HF )))), :('$$tup'(','(3, ','(24, '$$susp'( '$festivo',  [], _IF, _JF )))), :('$$tup'(','(3, ','(25, '$$susp'( '$festivo',  [], _KF, _LF )))), :('$$tup'(','(3, ','(26, '$$susp'( '$laborable',  [], _MF, _NF )))), :('$$tup'(','(3, ','(27, '$$susp'( '$laborable',  [], _OF, _PF )))), :('$$tup'(','(3, ','(28, '$$susp'( '$laborable',  [], _QF, _RF )))), :('$$tup'(','(3, ','(29, '$$susp'( '$laborable',  [], _SF, _TF )))), :('$$tup'(','(3, ','(30, '$$susp'( '$laborable',  [], _UF, _VF )))), :('$$tup'(','(3, ','(31, '$$susp'( '$festivo',  [], _WF, _XF )))), :('$$tup'(','(4, ','(1, '$$susp'( '$festivo',  [], _YF, _ZF )))), :('$$tup'(','(4, ','(2, '$$susp'( '$laborable',  [], _AG, _BG )))), :('$$tup'(','(4, ','(3, '$$susp'( '$laborable',  [], _CG, _DG )))), :('$$tup'(','(4, ','(4, '$$susp'( '$laborable',  [], _EG, _FG )))), :('$$tup'(','(4, ','(5, '$$susp'( '$laborable',  [], _GG, _HG )))), :('$$tup'(','(4, ','(6, '$$susp'( '$festivo',  [], _IG, _JG )))), :('$$tup'(','(4, ','(7, '$$susp'( '$festivo',  [], _KG, _LG )))), :('$$tup'(','(4, ','(8, '$$susp'( '$laborable',  [], _MG, _NG )))), :('$$tup'(','(4, ','(9, '$$susp'( '$laborable',  [], _OG, _PG )))), :('$$tup'(','(4, ','(10, '$$susp'( '$laborable',  [], _QG, _RG )))), :('$$tup'(','(4, ','(11, '$$susp'( '$laborable',  [], _SG, _TG )))), :('$$tup'(','(4, ','(12, '$$susp'( '$laborable',  [], _UG, _VG )))), :('$$tup'(','(4, ','(13, '$$susp'( '$festivo',  [], _WG, _XG )))), :('$$tup'(','(4, ','(14, '$$susp'( '$festivo',  [], _YG, _ZG )))), :('$$tup'(','(4, ','(15, '$$susp'( '$laborable',  [], _AH, _BH )))), :('$$tup'(','(4, ','(16, '$$susp'( '$laborable',  [], _CH, _DH )))), :('$$tup'(','(4, ','(17, '$$susp'( '$laborable',  [], _EH, _FH )))), :('$$tup'(','(4, ','(18, '$$susp'( '$laborable',  [], _GH, _HH )))), :('$$tup'(','(4, ','(19, '$$susp'( '$laborable',  [], _IH, _JH )))), :('$$tup'(','(4, ','(20, '$$susp'( '$festivo',  [], _KH, _LH )))), :('$$tup'(','(4, ','(21, '$$susp'( '$festivo',  [], _MH, _NH )))), :('$$tup'(','(4, ','(22, '$$susp'( '$laborable',  [], _OH, _PH )))), :('$$tup'(','(4, ','(23, '$$susp'( '$laborable',  [], _QH, _RH )))), :('$$tup'(','(4, ','(24, '$$susp'( '$laborable',  [], _SH, _TH )))), :('$$tup'(','(4, ','(25, '$$susp'( '$laborable',  [], _UH, _VH )))), :('$$tup'(','(4, ','(26, '$$susp'( '$laborable',  [], _WH, _XH )))), :('$$tup'(','(4, ','(27, '$$susp'( '$festivo',  [], _YH, _ZH )))), :('$$tup'(','(4, ','(28, '$$susp'( '$festivo',  [], _AI, _BI )))), :('$$tup'(','(4, ','(29, '$$susp'( '$laborable',  [], _CI, _DI )))), :('$$tup'(','(4, ','(30, '$$susp'( '$laborable',  [], _EI, _FI )))), :('$$tup'(','(5, ','(1, '$$susp'( '$laborable',  [], _GI, _HI )))), :('$$tup'(','(5, ','(2, '$$susp'( '$laborable',  [], _II, _JI )))), :('$$tup'(','(5, ','(3, '$$susp'( '$laborable',  [], _KI, _LI )))), :('$$tup'(','(5, ','(4, '$$susp'( '$festivo',  [], _MI, _NI )))), :('$$tup'(','(5, ','(5, '$$susp'( '$festivo',  [], _OI, _PI )))), :('$$tup'(','(5, ','(6, '$$susp'( '$laborable',  [], _QI, _RI )))), :('$$tup'(','(5, ','(7, '$$susp'( '$laborable',  [], _SI, _TI )))), :('$$tup'(','(5, ','(8, '$$susp'( '$laborable',  [], _UI, _VI )))), :('$$tup'(','(5, ','(9, '$$susp'( '$laborable',  [], _WI, _XI )))), :('$$tup'(','(5, ','(10, '$$susp'( '$laborable',  [], _YI, _ZI )))), :('$$tup'(','(5, ','(11, '$$susp'( '$festivo',  [], _AJ, _BJ )))), :('$$tup'(','(5, ','(12, '$$susp'( '$festivo',  [], _CJ, _DJ )))), :('$$tup'(','(5, ','(13, '$$susp'( '$laborable',  [], _EJ, _FJ )))), :('$$tup'(','(5, ','(14, '$$susp'( '$laborable',  [], _GJ, _HJ )))), :('$$tup'(','(5, ','(15, '$$susp'( '$laborable',  [], _IJ, _JJ )))), :('$$tup'(','(5, ','(16, '$$susp'( '$laborable',  [], _KJ, _LJ )))), :('$$tup'(','(5, ','(17, '$$susp'( '$laborable',  [], _MJ, _NJ )))), :('$$tup'(','(5, ','(18, '$$susp'( '$festivo',  [], _OJ, _PJ )))), :('$$tup'(','(5, ','(19, '$$susp'( '$festivo',  [], _QJ, _RJ )))), :('$$tup'(','(5, ','(20, '$$susp'( '$laborable',  [], _SJ, _TJ )))), :('$$tup'(','(5, ','(21, '$$susp'( '$laborable',  [], _UJ, _VJ )))), :('$$tup'(','(5, ','(22, '$$susp'( '$laborable',  [], _WJ, _XJ )))), :('$$tup'(','(5, ','(23, '$$susp'( '$laborable',  [], _YJ, _ZJ )))), :('$$tup'(','(5, ','(24, '$$susp'( '$laborable',  [], _AK, _BK )))), :('$$tup'(','(5, ','(25, '$$susp'( '$festivo',  [], _CK, _DK )))), :('$$tup'(','(5, ','(26, '$$susp'( '$festivo',  [], _EK, _FK )))), :('$$tup'(','(5, ','(27, '$$susp'( '$laborable',  [], _GK, _HK )))), :('$$tup'(','(5, ','(28, '$$susp'( '$laborable',  [], _IK, _JK )))), :('$$tup'(','(5, ','(29, '$$susp'( '$laborable',  [], _KK, _LK )))), :('$$tup'(','(5, ','(30, '$$susp'( '$laborable',  [], _MK, _NK )))), :('$$tup'(','(5, ','(31, '$$susp'( '$laborable',  [], _OK, _PK )))), []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _QK, _QK).

% seismeses
'$seismeses'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), :('$$tup'(','(3, ','(1, '$$susp'( '$laborable',  [], _OD, _PD )))), :('$$tup'(','(3, ','(2, '$$susp'( '$laborable',  [], _QD, _RD )))), :('$$tup'(','(3, ','(3, '$$susp'( '$festivo',  [], _SD, _TD )))), :('$$tup'(','(3, ','(4, '$$susp'( '$festivo',  [], _UD, _VD )))), :('$$tup'(','(3, ','(5, '$$susp'( '$laborable',  [], _WD, _XD )))), :('$$tup'(','(3, ','(6, '$$susp'( '$laborable',  [], _YD, _ZD )))), :('$$tup'(','(3, ','(7, '$$susp'( '$laborable',  [], _AE, _BE )))), :('$$tup'(','(3, ','(8, '$$susp'( '$laborable',  [], _CE, _DE )))), :('$$tup'(','(3, ','(9, '$$susp'( '$laborable',  [], _EE, _FE )))), :('$$tup'(','(3, ','(10, '$$susp'( '$festivo',  [], _GE, _HE )))), :('$$tup'(','(3, ','(11, '$$susp'( '$festivo',  [], _IE, _JE )))), :('$$tup'(','(3, ','(12, '$$susp'( '$laborable',  [], _KE, _LE )))), :('$$tup'(','(3, ','(13, '$$susp'( '$laborable',  [], _ME, _NE )))), :('$$tup'(','(3, ','(14, '$$susp'( '$laborable',  [], _OE, _PE )))), :('$$tup'(','(3, ','(15, '$$susp'( '$laborable',  [], _QE, _RE )))), :('$$tup'(','(3, ','(16, '$$susp'( '$laborable',  [], _SE, _TE )))), :('$$tup'(','(3, ','(17, '$$susp'( '$festivo',  [], _UE, _VE )))), :('$$tup'(','(3, ','(18, '$$susp'( '$festivo',  [], _WE, _XE )))), :('$$tup'(','(3, ','(19, '$$susp'( '$laborable',  [], _YE, _ZE )))), :('$$tup'(','(3, ','(20, '$$susp'( '$laborable',  [], _AF, _BF )))), :('$$tup'(','(3, ','(21, '$$susp'( '$laborable',  [], _CF, _DF )))), :('$$tup'(','(3, ','(22, '$$susp'( '$laborable',  [], _EF, _FF )))), :('$$tup'(','(3, ','(23, '$$susp'( '$laborable',  [], _GF, _HF )))), :('$$tup'(','(3, ','(24, '$$susp'( '$festivo',  [], _IF, _JF )))), :('$$tup'(','(3, ','(25, '$$susp'( '$festivo',  [], _KF, _LF )))), :('$$tup'(','(3, ','(26, '$$susp'( '$laborable',  [], _MF, _NF )))), :('$$tup'(','(3, ','(27, '$$susp'( '$laborable',  [], _OF, _PF )))), :('$$tup'(','(3, ','(28, '$$susp'( '$laborable',  [], _QF, _RF )))), :('$$tup'(','(3, ','(29, '$$susp'( '$laborable',  [], _SF, _TF )))), :('$$tup'(','(3, ','(30, '$$susp'( '$laborable',  [], _UF, _VF )))), :('$$tup'(','(3, ','(31, '$$susp'( '$festivo',  [], _WF, _XF )))), :('$$tup'(','(4, ','(1, '$$susp'( '$festivo',  [], _YF, _ZF )))), :('$$tup'(','(4, ','(2, '$$susp'( '$laborable',  [], _AG, _BG )))), :('$$tup'(','(4, ','(3, '$$susp'( '$laborable',  [], _CG, _DG )))), :('$$tup'(','(4, ','(4, '$$susp'( '$laborable',  [], _EG, _FG )))), :('$$tup'(','(4, ','(5, '$$susp'( '$laborable',  [], _GG, _HG )))), :('$$tup'(','(4, ','(6, '$$susp'( '$festivo',  [], _IG, _JG )))), :('$$tup'(','(4, ','(7, '$$susp'( '$festivo',  [], _KG, _LG )))), :('$$tup'(','(4, ','(8, '$$susp'( '$laborable',  [], _MG, _NG )))), :('$$tup'(','(4, ','(9, '$$susp'( '$laborable',  [], _OG, _PG )))), :('$$tup'(','(4, ','(10, '$$susp'( '$laborable',  [], _QG, _RG )))), :('$$tup'(','(4, ','(11, '$$susp'( '$laborable',  [], _SG, _TG )))), :('$$tup'(','(4, ','(12, '$$susp'( '$laborable',  [], _UG, _VG )))), :('$$tup'(','(4, ','(13, '$$susp'( '$festivo',  [], _WG, _XG )))), :('$$tup'(','(4, ','(14, '$$susp'( '$festivo',  [], _YG, _ZG )))), :('$$tup'(','(4, ','(15, '$$susp'( '$laborable',  [], _AH, _BH )))), :('$$tup'(','(4, ','(16, '$$susp'( '$laborable',  [], _CH, _DH )))), :('$$tup'(','(4, ','(17, '$$susp'( '$laborable',  [], _EH, _FH )))), :('$$tup'(','(4, ','(18, '$$susp'( '$laborable',  [], _GH, _HH )))), :('$$tup'(','(4, ','(19, '$$susp'( '$laborable',  [], _IH, _JH )))), :('$$tup'(','(4, ','(20, '$$susp'( '$festivo',  [], _KH, _LH )))), :('$$tup'(','(4, ','(21, '$$susp'( '$festivo',  [], _MH, _NH )))), :('$$tup'(','(4, ','(22, '$$susp'( '$laborable',  [], _OH, _PH )))), :('$$tup'(','(4, ','(23, '$$susp'( '$laborable',  [], _QH, _RH )))), :('$$tup'(','(4, ','(24, '$$susp'( '$laborable',  [], _SH, _TH )))), :('$$tup'(','(4, ','(25, '$$susp'( '$laborable',  [], _UH, _VH )))), :('$$tup'(','(4, ','(26, '$$susp'( '$laborable',  [], _WH, _XH )))), :('$$tup'(','(4, ','(27, '$$susp'( '$festivo',  [], _YH, _ZH )))), :('$$tup'(','(4, ','(28, '$$susp'( '$festivo',  [], _AI, _BI )))), :('$$tup'(','(4, ','(29, '$$susp'( '$laborable',  [], _CI, _DI )))), :('$$tup'(','(4, ','(30, '$$susp'( '$laborable',  [], _EI, _FI )))), :('$$tup'(','(5, ','(1, '$$susp'( '$laborable',  [], _GI, _HI )))), :('$$tup'(','(5, ','(2, '$$susp'( '$laborable',  [], _II, _JI )))), :('$$tup'(','(5, ','(3, '$$susp'( '$laborable',  [], _KI, _LI )))), :('$$tup'(','(5, ','(4, '$$susp'( '$festivo',  [], _MI, _NI )))), :('$$tup'(','(5, ','(5, '$$susp'( '$festivo',  [], _OI, _PI )))), :('$$tup'(','(5, ','(6, '$$susp'( '$laborable',  [], _QI, _RI )))), :('$$tup'(','(5, ','(7, '$$susp'( '$laborable',  [], _SI, _TI )))), :('$$tup'(','(5, ','(8, '$$susp'( '$laborable',  [], _UI, _VI )))), :('$$tup'(','(5, ','(9, '$$susp'( '$laborable',  [], _WI, _XI )))), :('$$tup'(','(5, ','(10, '$$susp'( '$laborable',  [], _YI, _ZI )))), :('$$tup'(','(5, ','(11, '$$susp'( '$festivo',  [], _AJ, _BJ )))), :('$$tup'(','(5, ','(12, '$$susp'( '$festivo',  [], _CJ, _DJ )))), :('$$tup'(','(5, ','(13, '$$susp'( '$laborable',  [], _EJ, _FJ )))), :('$$tup'(','(5, ','(14, '$$susp'( '$laborable',  [], _GJ, _HJ )))), :('$$tup'(','(5, ','(15, '$$susp'( '$laborable',  [], _IJ, _JJ )))), :('$$tup'(','(5, ','(16, '$$susp'( '$laborable',  [], _KJ, _LJ )))), :('$$tup'(','(5, ','(17, '$$susp'( '$laborable',  [], _MJ, _NJ )))), :('$$tup'(','(5, ','(18, '$$susp'( '$festivo',  [], _OJ, _PJ )))), :('$$tup'(','(5, ','(19, '$$susp'( '$festivo',  [], _QJ, _RJ )))), :('$$tup'(','(5, ','(20, '$$susp'( '$laborable',  [], _SJ, _TJ )))), :('$$tup'(','(5, ','(21, '$$susp'( '$laborable',  [], _UJ, _VJ )))), :('$$tup'(','(5, ','(22, '$$susp'( '$laborable',  [], _WJ, _XJ )))), :('$$tup'(','(5, ','(23, '$$susp'( '$laborable',  [], _YJ, _ZJ )))), :('$$tup'(','(5, ','(24, '$$susp'( '$laborable',  [], _AK, _BK )))), :('$$tup'(','(5, ','(25, '$$susp'( '$festivo',  [], _CK, _DK )))), :('$$tup'(','(5, ','(26, '$$susp'( '$festivo',  [], _EK, _FK )))), :('$$tup'(','(5, ','(27, '$$susp'( '$laborable',  [], _GK, _HK )))), :('$$tup'(','(5, ','(28, '$$susp'( '$laborable',  [], _IK, _JK )))), :('$$tup'(','(5, ','(29, '$$susp'( '$laborable',  [], _KK, _LK )))), :('$$tup'(','(5, ','(30, '$$susp'( '$laborable',  [], _MK, _NK )))), :('$$tup'(','(5, ','(31, '$$susp'( '$laborable',  [], _OK, _PK )))), :('$$tup'(','(6, ','(1, '$$susp'( '$festivo',  [], _QK, _RK )))), :('$$tup'(','(6, ','(2, '$$susp'( '$festivo',  [], _SK, _TK )))), :('$$tup'(','(6, ','(3, '$$susp'( '$laborable',  [], _UK, _VK )))), :('$$tup'(','(6, ','(4, '$$susp'( '$laborable',  [], _WK, _XK )))), :('$$tup'(','(6, ','(5, '$$susp'( '$laborable',  [], _YK, _ZK )))), :('$$tup'(','(6, ','(6, '$$susp'( '$laborable',  [], _AL, _BL )))), :('$$tup'(','(6, ','(7, '$$susp'( '$festivo',  [], _CL, _DL )))), :('$$tup'(','(6, ','(8, '$$susp'( '$festivo',  [], _EL, _FL )))), :('$$tup'(','(6, ','(9, '$$susp'( '$laborable',  [], _GL, _HL )))), :('$$tup'(','(6, ','(10, '$$susp'( '$laborable',  [], _IL, _JL )))), :('$$tup'(','(6, ','(11, '$$susp'( '$laborable',  [], _KL, _LL )))), :('$$tup'(','(6, ','(12, '$$susp'( '$laborable',  [], _ML, _NL )))), :('$$tup'(','(6, ','(13, '$$susp'( '$laborable',  [], _OL, _PL )))), :('$$tup'(','(6, ','(14, '$$susp'( '$festivo',  [], _QL, _RL )))), :('$$tup'(','(6, ','(15, '$$susp'( '$festivo',  [], _SL, _TL )))), :('$$tup'(','(6, ','(16, '$$susp'( '$laborable',  [], _UL, _VL )))), :('$$tup'(','(6, ','(17, '$$susp'( '$laborable',  [], _WL, _XL )))), :('$$tup'(','(6, ','(18, '$$susp'( '$laborable',  [], _YL, _ZL )))), :('$$tup'(','(6, ','(19, '$$susp'( '$laborable',  [], _AM, _BM )))), :('$$tup'(','(6, ','(20, '$$susp'( '$laborable',  [], _CM, _DM )))), :('$$tup'(','(6, ','(21, '$$susp'( '$festivo',  [], _EM, _FM )))), :('$$tup'(','(6, ','(22, '$$susp'( '$festivo',  [], _GM, _HM )))), :('$$tup'(','(6, ','(23, '$$susp'( '$laborable',  [], _IM, _JM )))), :('$$tup'(','(6, ','(24, '$$susp'( '$laborable',  [], _KM, _LM )))), :('$$tup'(','(6, ','(25, '$$susp'( '$laborable',  [], _MM, _NM )))), :('$$tup'(','(6, ','(26, '$$susp'( '$laborable',  [], _OM, _PM )))), :('$$tup'(','(6, ','(27, '$$susp'( '$laborable',  [], _QM, _RM )))), :('$$tup'(','(6, ','(28, '$$susp'( '$festivo',  [], _SM, _TM )))), :('$$tup'(','(6, ','(29, '$$susp'( '$festivo',  [], _UM, _VM )))), :('$$tup'(','(6, ','(30, '$$susp'( '$laborable',  [], _WM, _XM )))), []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _YM, _YM).

% ochomeses
'$ochomeses'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), :('$$tup'(','(3, ','(1, '$$susp'( '$laborable',  [], _OD, _PD )))), :('$$tup'(','(3, ','(2, '$$susp'( '$laborable',  [], _QD, _RD )))), :('$$tup'(','(3, ','(3, '$$susp'( '$festivo',  [], _SD, _TD )))), :('$$tup'(','(3, ','(4, '$$susp'( '$festivo',  [], _UD, _VD )))), :('$$tup'(','(3, ','(5, '$$susp'( '$laborable',  [], _WD, _XD )))), :('$$tup'(','(3, ','(6, '$$susp'( '$laborable',  [], _YD, _ZD )))), :('$$tup'(','(3, ','(7, '$$susp'( '$laborable',  [], _AE, _BE )))), :('$$tup'(','(3, ','(8, '$$susp'( '$laborable',  [], _CE, _DE )))), :('$$tup'(','(3, ','(9, '$$susp'( '$laborable',  [], _EE, _FE )))), :('$$tup'(','(3, ','(10, '$$susp'( '$festivo',  [], _GE, _HE )))), :('$$tup'(','(3, ','(11, '$$susp'( '$festivo',  [], _IE, _JE )))), :('$$tup'(','(3, ','(12, '$$susp'( '$laborable',  [], _KE, _LE )))), :('$$tup'(','(3, ','(13, '$$susp'( '$laborable',  [], _ME, _NE )))), :('$$tup'(','(3, ','(14, '$$susp'( '$laborable',  [], _OE, _PE )))), :('$$tup'(','(3, ','(15, '$$susp'( '$laborable',  [], _QE, _RE )))), :('$$tup'(','(3, ','(16, '$$susp'( '$laborable',  [], _SE, _TE )))), :('$$tup'(','(3, ','(17, '$$susp'( '$festivo',  [], _UE, _VE )))), :('$$tup'(','(3, ','(18, '$$susp'( '$festivo',  [], _WE, _XE )))), :('$$tup'(','(3, ','(19, '$$susp'( '$laborable',  [], _YE, _ZE )))), :('$$tup'(','(3, ','(20, '$$susp'( '$laborable',  [], _AF, _BF )))), :('$$tup'(','(3, ','(21, '$$susp'( '$laborable',  [], _CF, _DF )))), :('$$tup'(','(3, ','(22, '$$susp'( '$laborable',  [], _EF, _FF )))), :('$$tup'(','(3, ','(23, '$$susp'( '$laborable',  [], _GF, _HF )))), :('$$tup'(','(3, ','(24, '$$susp'( '$festivo',  [], _IF, _JF )))), :('$$tup'(','(3, ','(25, '$$susp'( '$festivo',  [], _KF, _LF )))), :('$$tup'(','(3, ','(26, '$$susp'( '$laborable',  [], _MF, _NF )))), :('$$tup'(','(3, ','(27, '$$susp'( '$laborable',  [], _OF, _PF )))), :('$$tup'(','(3, ','(28, '$$susp'( '$laborable',  [], _QF, _RF )))), :('$$tup'(','(3, ','(29, '$$susp'( '$laborable',  [], _SF, _TF )))), :('$$tup'(','(3, ','(30, '$$susp'( '$laborable',  [], _UF, _VF )))), :('$$tup'(','(3, ','(31, '$$susp'( '$festivo',  [], _WF, _XF )))), :('$$tup'(','(4, ','(1, '$$susp'( '$festivo',  [], _YF, _ZF )))), :('$$tup'(','(4, ','(2, '$$susp'( '$laborable',  [], _AG, _BG )))), :('$$tup'(','(4, ','(3, '$$susp'( '$laborable',  [], _CG, _DG )))), :('$$tup'(','(4, ','(4, '$$susp'( '$laborable',  [], _EG, _FG )))), :('$$tup'(','(4, ','(5, '$$susp'( '$laborable',  [], _GG, _HG )))), :('$$tup'(','(4, ','(6, '$$susp'( '$festivo',  [], _IG, _JG )))), :('$$tup'(','(4, ','(7, '$$susp'( '$festivo',  [], _KG, _LG )))), :('$$tup'(','(4, ','(8, '$$susp'( '$laborable',  [], _MG, _NG )))), :('$$tup'(','(4, ','(9, '$$susp'( '$laborable',  [], _OG, _PG )))), :('$$tup'(','(4, ','(10, '$$susp'( '$laborable',  [], _QG, _RG )))), :('$$tup'(','(4, ','(11, '$$susp'( '$laborable',  [], _SG, _TG )))), :('$$tup'(','(4, ','(12, '$$susp'( '$laborable',  [], _UG, _VG )))), :('$$tup'(','(4, ','(13, '$$susp'( '$festivo',  [], _WG, _XG )))), :('$$tup'(','(4, ','(14, '$$susp'( '$festivo',  [], _YG, _ZG )))), :('$$tup'(','(4, ','(15, '$$susp'( '$laborable',  [], _AH, _BH )))), :('$$tup'(','(4, ','(16, '$$susp'( '$laborable',  [], _CH, _DH )))), :('$$tup'(','(4, ','(17, '$$susp'( '$laborable',  [], _EH, _FH )))), :('$$tup'(','(4, ','(18, '$$susp'( '$laborable',  [], _GH, _HH )))), :('$$tup'(','(4, ','(19, '$$susp'( '$laborable',  [], _IH, _JH )))), :('$$tup'(','(4, ','(20, '$$susp'( '$festivo',  [], _KH, _LH )))), :('$$tup'(','(4, ','(21, '$$susp'( '$festivo',  [], _MH, _NH )))), :('$$tup'(','(4, ','(22, '$$susp'( '$laborable',  [], _OH, _PH )))), :('$$tup'(','(4, ','(23, '$$susp'( '$laborable',  [], _QH, _RH )))), :('$$tup'(','(4, ','(24, '$$susp'( '$laborable',  [], _SH, _TH )))), :('$$tup'(','(4, ','(25, '$$susp'( '$laborable',  [], _UH, _VH )))), :('$$tup'(','(4, ','(26, '$$susp'( '$laborable',  [], _WH, _XH )))), :('$$tup'(','(4, ','(27, '$$susp'( '$festivo',  [], _YH, _ZH )))), :('$$tup'(','(4, ','(28, '$$susp'( '$festivo',  [], _AI, _BI )))), :('$$tup'(','(4, ','(29, '$$susp'( '$laborable',  [], _CI, _DI )))), :('$$tup'(','(4, ','(30, '$$susp'( '$laborable',  [], _EI, _FI )))), :('$$tup'(','(5, ','(1, '$$susp'( '$laborable',  [], _GI, _HI )))), :('$$tup'(','(5, ','(2, '$$susp'( '$laborable',  [], _II, _JI )))), :('$$tup'(','(5, ','(3, '$$susp'( '$laborable',  [], _KI, _LI )))), :('$$tup'(','(5, ','(4, '$$susp'( '$festivo',  [], _MI, _NI )))), :('$$tup'(','(5, ','(5, '$$susp'( '$festivo',  [], _OI, _PI )))), :('$$tup'(','(5, ','(6, '$$susp'( '$laborable',  [], _QI, _RI )))), :('$$tup'(','(5, ','(7, '$$susp'( '$laborable',  [], _SI, _TI )))), :('$$tup'(','(5, ','(8, '$$susp'( '$laborable',  [], _UI, _VI )))), :('$$tup'(','(5, ','(9, '$$susp'( '$laborable',  [], _WI, _XI )))), :('$$tup'(','(5, ','(10, '$$susp'( '$laborable',  [], _YI, _ZI )))), :('$$tup'(','(5, ','(11, '$$susp'( '$festivo',  [], _AJ, _BJ )))), :('$$tup'(','(5, ','(12, '$$susp'( '$festivo',  [], _CJ, _DJ )))), :('$$tup'(','(5, ','(13, '$$susp'( '$laborable',  [], _EJ, _FJ )))), :('$$tup'(','(5, ','(14, '$$susp'( '$laborable',  [], _GJ, _HJ )))), :('$$tup'(','(5, ','(15, '$$susp'( '$laborable',  [], _IJ, _JJ )))), :('$$tup'(','(5, ','(16, '$$susp'( '$laborable',  [], _KJ, _LJ )))), :('$$tup'(','(5, ','(17, '$$susp'( '$laborable',  [], _MJ, _NJ )))), :('$$tup'(','(5, ','(18, '$$susp'( '$festivo',  [], _OJ, _PJ )))), :('$$tup'(','(5, ','(19, '$$susp'( '$festivo',  [], _QJ, _RJ )))), :('$$tup'(','(5, ','(20, '$$susp'( '$laborable',  [], _SJ, _TJ )))), :('$$tup'(','(5, ','(21, '$$susp'( '$laborable',  [], _UJ, _VJ )))), :('$$tup'(','(5, ','(22, '$$susp'( '$laborable',  [], _WJ, _XJ )))), :('$$tup'(','(5, ','(23, '$$susp'( '$laborable',  [], _YJ, _ZJ )))), :('$$tup'(','(5, ','(24, '$$susp'( '$laborable',  [], _AK, _BK )))), :('$$tup'(','(5, ','(25, '$$susp'( '$festivo',  [], _CK, _DK )))), :('$$tup'(','(5, ','(26, '$$susp'( '$festivo',  [], _EK, _FK )))), :('$$tup'(','(5, ','(27, '$$susp'( '$laborable',  [], _GK, _HK )))), :('$$tup'(','(5, ','(28, '$$susp'( '$laborable',  [], _IK, _JK )))), :('$$tup'(','(5, ','(29, '$$susp'( '$laborable',  [], _KK, _LK )))), :('$$tup'(','(5, ','(30, '$$susp'( '$laborable',  [], _MK, _NK )))), :('$$tup'(','(5, ','(31, '$$susp'( '$laborable',  [], _OK, _PK )))), :('$$tup'(','(6, ','(1, '$$susp'( '$festivo',  [], _QK, _RK )))), :('$$tup'(','(6, ','(2, '$$susp'( '$festivo',  [], _SK, _TK )))), :('$$tup'(','(6, ','(3, '$$susp'( '$laborable',  [], _UK, _VK )))), :('$$tup'(','(6, ','(4, '$$susp'( '$laborable',  [], _WK, _XK )))), :('$$tup'(','(6, ','(5, '$$susp'( '$laborable',  [], _YK, _ZK )))), :('$$tup'(','(6, ','(6, '$$susp'( '$laborable',  [], _AL, _BL )))), :('$$tup'(','(6, ','(7, '$$susp'( '$festivo',  [], _CL, _DL )))), :('$$tup'(','(6, ','(8, '$$susp'( '$festivo',  [], _EL, _FL )))), :('$$tup'(','(6, ','(9, '$$susp'( '$laborable',  [], _GL, _HL )))), :('$$tup'(','(6, ','(10, '$$susp'( '$laborable',  [], _IL, _JL )))), :('$$tup'(','(6, ','(11, '$$susp'( '$laborable',  [], _KL, _LL )))), :('$$tup'(','(6, ','(12, '$$susp'( '$laborable',  [], _ML, _NL )))), :('$$tup'(','(6, ','(13, '$$susp'( '$laborable',  [], _OL, _PL )))), :('$$tup'(','(6, ','(14, '$$susp'( '$festivo',  [], _QL, _RL )))), :('$$tup'(','(6, ','(15, '$$susp'( '$festivo',  [], _SL, _TL )))), :('$$tup'(','(6, ','(16, '$$susp'( '$laborable',  [], _UL, _VL )))), :('$$tup'(','(6, ','(17, '$$susp'( '$laborable',  [], _WL, _XL )))), :('$$tup'(','(6, ','(18, '$$susp'( '$laborable',  [], _YL, _ZL )))), :('$$tup'(','(6, ','(19, '$$susp'( '$laborable',  [], _AM, _BM )))), :('$$tup'(','(6, ','(20, '$$susp'( '$laborable',  [], _CM, _DM )))), :('$$tup'(','(6, ','(21, '$$susp'( '$festivo',  [], _EM, _FM )))), :('$$tup'(','(6, ','(22, '$$susp'( '$festivo',  [], _GM, _HM )))), :('$$tup'(','(6, ','(23, '$$susp'( '$laborable',  [], _IM, _JM )))), :('$$tup'(','(6, ','(24, '$$susp'( '$laborable',  [], _KM, _LM )))), :('$$tup'(','(6, ','(25, '$$susp'( '$laborable',  [], _MM, _NM )))), :('$$tup'(','(6, ','(26, '$$susp'( '$laborable',  [], _OM, _PM )))), :('$$tup'(','(6, ','(27, '$$susp'( '$laborable',  [], _QM, _RM )))), :('$$tup'(','(6, ','(28, '$$susp'( '$festivo',  [], _SM, _TM )))), :('$$tup'(','(6, ','(29, '$$susp'( '$festivo',  [], _UM, _VM )))), :('$$tup'(','(6, ','(30, '$$susp'( '$laborable',  [], _WM, _XM )))), :('$$tup'(','(7, ','(1, '$$susp'( '$laborable',  [], _YM, _ZM )))), :('$$tup'(','(7, ','(2, '$$susp'( '$laborable',  [], _AN, _BN )))), :('$$tup'(','(7, ','(3, '$$susp'( '$laborable',  [], _CN, _DN )))), :('$$tup'(','(7, ','(4, '$$susp'( '$laborable',  [], _EN, _FN )))), :('$$tup'(','(7, ','(5, '$$susp'( '$festivo',  [], _GN, _HN )))), :('$$tup'(','(7, ','(6, '$$susp'( '$festivo',  [], _IN, _JN )))), :('$$tup'(','(7, ','(7, '$$susp'( '$laborable',  [], _KN, _LN )))), :('$$tup'(','(7, ','(8, '$$susp'( '$laborable',  [], _MN, _NN )))), :('$$tup'(','(7, ','(9, '$$susp'( '$laborable',  [], _ON, _PN )))), :('$$tup'(','(7, ','(10, '$$susp'( '$laborable',  [], _QN, _RN )))), :('$$tup'(','(7, ','(11, '$$susp'( '$laborable',  [], _SN, _TN )))), :('$$tup'(','(7, ','(12, '$$susp'( '$festivo',  [], _UN, _VN )))), :('$$tup'(','(7, ','(13, '$$susp'( '$festivo',  [], _WN, _XN )))), :('$$tup'(','(7, ','(14, '$$susp'( '$laborable',  [], _YN, _ZN )))), :('$$tup'(','(7, ','(15, '$$susp'( '$laborable',  [], _AO, _BO )))), :('$$tup'(','(7, ','(16, '$$susp'( '$laborable',  [], _CO, _DO )))), :('$$tup'(','(7, ','(17, '$$susp'( '$laborable',  [], _EO, _FO )))), :('$$tup'(','(7, ','(18, '$$susp'( '$laborable',  [], _GO, _HO )))), :('$$tup'(','(7, ','(19, '$$susp'( '$festivo',  [], _IO, _JO )))), :('$$tup'(','(7, ','(20, '$$susp'( '$festivo',  [], _KO, _LO )))), :('$$tup'(','(7, ','(21, '$$susp'( '$laborable',  [], _MO, _NO )))), :('$$tup'(','(7, ','(22, '$$susp'( '$laborable',  [], _OO, _PO )))), :('$$tup'(','(7, ','(23, '$$susp'( '$laborable',  [], _QO, _RO )))), :('$$tup'(','(7, ','(24, '$$susp'( '$laborable',  [], _SO, _TO )))), :('$$tup'(','(7, ','(25, '$$susp'( '$laborable',  [], _UO, _VO )))), :('$$tup'(','(7, ','(26, '$$susp'( '$festivo',  [], _WO, _XO )))), :('$$tup'(','(7, ','(27, '$$susp'( '$festivo',  [], _YO, _ZO )))), :('$$tup'(','(7, ','(28, '$$susp'( '$laborable',  [], _AP, _BP )))), :('$$tup'(','(7, ','(29, '$$susp'( '$laborable',  [], _CP, _DP )))), :('$$tup'(','(7, ','(30, '$$susp'( '$laborable',  [], _EP, _FP )))), :('$$tup'(','(7, ','(31, '$$susp'( '$laborable',  [], _GP, _HP )))), :('$$tup'(','(8, ','(1, '$$susp'( '$laborable',  [], _IP, _JP )))), :('$$tup'(','(8, ','(2, '$$susp'( '$festivo',  [], _KP, _LP )))), :('$$tup'(','(8, ','(3, '$$susp'( '$laborable',  [], _MP, _NP )))), :('$$tup'(','(8, ','(4, '$$susp'( '$laborable',  [], _OP, _PP )))), :('$$tup'(','(8, ','(5, '$$susp'( '$laborable',  [], _QP, _RP )))), :('$$tup'(','(8, ','(6, '$$susp'( '$laborable',  [], _SP, _TP )))), :('$$tup'(','(8, ','(7, '$$susp'( '$festivo',  [], _UP, _VP )))), :('$$tup'(','(8, ','(8, '$$susp'( '$festivo',  [], _WP, _XP )))), :('$$tup'(','(8, ','(9, '$$susp'( '$laborable',  [], _YP, _ZP )))), :('$$tup'(','(8, ','(10, '$$susp'( '$laborable',  [], _AQ, _BQ )))), :('$$tup'(','(8, ','(11, '$$susp'( '$laborable',  [], _CQ, _DQ )))), :('$$tup'(','(8, ','(12, '$$susp'( '$laborable',  [], _EQ, _FQ )))), :('$$tup'(','(8, ','(13, '$$susp'( '$laborable',  [], _GQ, _HQ )))), :('$$tup'(','(8, ','(14, '$$susp'( '$festivo',  [], _IQ, _JQ )))), :('$$tup'(','(8, ','(15, '$$susp'( '$festivo',  [], _KQ, _LQ )))), :('$$tup'(','(8, ','(16, '$$susp'( '$laborable',  [], _MQ, _NQ )))), :('$$tup'(','(8, ','(17, '$$susp'( '$laborable',  [], _OQ, _PQ )))), :('$$tup'(','(8, ','(18, '$$susp'( '$laborable',  [], _QQ, _RQ )))), :('$$tup'(','(8, ','(19, '$$susp'( '$laborable',  [], _SQ, _TQ )))), :('$$tup'(','(8, ','(20, '$$susp'( '$laborable',  [], _UQ, _VQ )))), :('$$tup'(','(8, ','(21, '$$susp'( '$festivo',  [], _WQ, _XQ )))), :('$$tup'(','(8, ','(22, '$$susp'( '$festivo',  [], _YQ, _ZQ )))), :('$$tup'(','(8, ','(23, '$$susp'( '$laborable',  [], _AR, _BR )))), :('$$tup'(','(8, ','(24, '$$susp'( '$laborable',  [], _CR, _DR )))), :('$$tup'(','(8, ','(25, '$$susp'( '$laborable',  [], _ER, _FR )))), :('$$tup'(','(8, ','(26, '$$susp'( '$laborable',  [], _GR, _HR )))), :('$$tup'(','(8, ','(27, '$$susp'( '$laborable',  [], _IR, _JR )))), :('$$tup'(','(8, ','(28, '$$susp'( '$festivo',  [], _KR, _LR )))), :('$$tup'(','(8, ','(29, '$$susp'( '$festivo',  [], _MR, _NR )))), :('$$tup'(','(8, ','(30, '$$susp'( '$laborable',  [], _OR, _PR )))), :('$$tup'(','(8, ','(31, '$$susp'( '$laborable',  [], _QR, _RR )))), []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _SR, _SR).

% diezmeses
'$diezmeses'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), :('$$tup'(','(3, ','(1, '$$susp'( '$laborable',  [], _OD, _PD )))), :('$$tup'(','(3, ','(2, '$$susp'( '$laborable',  [], _QD, _RD )))), :('$$tup'(','(3, ','(3, '$$susp'( '$festivo',  [], _SD, _TD )))), :('$$tup'(','(3, ','(4, '$$susp'( '$festivo',  [], _UD, _VD )))), :('$$tup'(','(3, ','(5, '$$susp'( '$laborable',  [], _WD, _XD )))), :('$$tup'(','(3, ','(6, '$$susp'( '$laborable',  [], _YD, _ZD )))), :('$$tup'(','(3, ','(7, '$$susp'( '$laborable',  [], _AE, _BE )))), :('$$tup'(','(3, ','(8, '$$susp'( '$laborable',  [], _CE, _DE )))), :('$$tup'(','(3, ','(9, '$$susp'( '$laborable',  [], _EE, _FE )))), :('$$tup'(','(3, ','(10, '$$susp'( '$festivo',  [], _GE, _HE )))), :('$$tup'(','(3, ','(11, '$$susp'( '$festivo',  [], _IE, _JE )))), :('$$tup'(','(3, ','(12, '$$susp'( '$laborable',  [], _KE, _LE )))), :('$$tup'(','(3, ','(13, '$$susp'( '$laborable',  [], _ME, _NE )))), :('$$tup'(','(3, ','(14, '$$susp'( '$laborable',  [], _OE, _PE )))), :('$$tup'(','(3, ','(15, '$$susp'( '$laborable',  [], _QE, _RE )))), :('$$tup'(','(3, ','(16, '$$susp'( '$laborable',  [], _SE, _TE )))), :('$$tup'(','(3, ','(17, '$$susp'( '$festivo',  [], _UE, _VE )))), :('$$tup'(','(3, ','(18, '$$susp'( '$festivo',  [], _WE, _XE )))), :('$$tup'(','(3, ','(19, '$$susp'( '$laborable',  [], _YE, _ZE )))), :('$$tup'(','(3, ','(20, '$$susp'( '$laborable',  [], _AF, _BF )))), :('$$tup'(','(3, ','(21, '$$susp'( '$laborable',  [], _CF, _DF )))), :('$$tup'(','(3, ','(22, '$$susp'( '$laborable',  [], _EF, _FF )))), :('$$tup'(','(3, ','(23, '$$susp'( '$laborable',  [], _GF, _HF )))), :('$$tup'(','(3, ','(24, '$$susp'( '$festivo',  [], _IF, _JF )))), :('$$tup'(','(3, ','(25, '$$susp'( '$festivo',  [], _KF, _LF )))), :('$$tup'(','(3, ','(26, '$$susp'( '$laborable',  [], _MF, _NF )))), :('$$tup'(','(3, ','(27, '$$susp'( '$laborable',  [], _OF, _PF )))), :('$$tup'(','(3, ','(28, '$$susp'( '$laborable',  [], _QF, _RF )))), :('$$tup'(','(3, ','(29, '$$susp'( '$laborable',  [], _SF, _TF )))), :('$$tup'(','(3, ','(30, '$$susp'( '$laborable',  [], _UF, _VF )))), :('$$tup'(','(3, ','(31, '$$susp'( '$festivo',  [], _WF, _XF )))), :('$$tup'(','(4, ','(1, '$$susp'( '$festivo',  [], _YF, _ZF )))), :('$$tup'(','(4, ','(2, '$$susp'( '$laborable',  [], _AG, _BG )))), :('$$tup'(','(4, ','(3, '$$susp'( '$laborable',  [], _CG, _DG )))), :('$$tup'(','(4, ','(4, '$$susp'( '$laborable',  [], _EG, _FG )))), :('$$tup'(','(4, ','(5, '$$susp'( '$laborable',  [], _GG, _HG )))), :('$$tup'(','(4, ','(6, '$$susp'( '$festivo',  [], _IG, _JG )))), :('$$tup'(','(4, ','(7, '$$susp'( '$festivo',  [], _KG, _LG )))), :('$$tup'(','(4, ','(8, '$$susp'( '$laborable',  [], _MG, _NG )))), :('$$tup'(','(4, ','(9, '$$susp'( '$laborable',  [], _OG, _PG )))), :('$$tup'(','(4, ','(10, '$$susp'( '$laborable',  [], _QG, _RG )))), :('$$tup'(','(4, ','(11, '$$susp'( '$laborable',  [], _SG, _TG )))), :('$$tup'(','(4, ','(12, '$$susp'( '$laborable',  [], _UG, _VG )))), :('$$tup'(','(4, ','(13, '$$susp'( '$festivo',  [], _WG, _XG )))), :('$$tup'(','(4, ','(14, '$$susp'( '$festivo',  [], _YG, _ZG )))), :('$$tup'(','(4, ','(15, '$$susp'( '$laborable',  [], _AH, _BH )))), :('$$tup'(','(4, ','(16, '$$susp'( '$laborable',  [], _CH, _DH )))), :('$$tup'(','(4, ','(17, '$$susp'( '$laborable',  [], _EH, _FH )))), :('$$tup'(','(4, ','(18, '$$susp'( '$laborable',  [], _GH, _HH )))), :('$$tup'(','(4, ','(19, '$$susp'( '$laborable',  [], _IH, _JH )))), :('$$tup'(','(4, ','(20, '$$susp'( '$festivo',  [], _KH, _LH )))), :('$$tup'(','(4, ','(21, '$$susp'( '$festivo',  [], _MH, _NH )))), :('$$tup'(','(4, ','(22, '$$susp'( '$laborable',  [], _OH, _PH )))), :('$$tup'(','(4, ','(23, '$$susp'( '$laborable',  [], _QH, _RH )))), :('$$tup'(','(4, ','(24, '$$susp'( '$laborable',  [], _SH, _TH )))), :('$$tup'(','(4, ','(25, '$$susp'( '$laborable',  [], _UH, _VH )))), :('$$tup'(','(4, ','(26, '$$susp'( '$laborable',  [], _WH, _XH )))), :('$$tup'(','(4, ','(27, '$$susp'( '$festivo',  [], _YH, _ZH )))), :('$$tup'(','(4, ','(28, '$$susp'( '$festivo',  [], _AI, _BI )))), :('$$tup'(','(4, ','(29, '$$susp'( '$laborable',  [], _CI, _DI )))), :('$$tup'(','(4, ','(30, '$$susp'( '$laborable',  [], _EI, _FI )))), :('$$tup'(','(5, ','(1, '$$susp'( '$laborable',  [], _GI, _HI )))), :('$$tup'(','(5, ','(2, '$$susp'( '$laborable',  [], _II, _JI )))), :('$$tup'(','(5, ','(3, '$$susp'( '$laborable',  [], _KI, _LI )))), :('$$tup'(','(5, ','(4, '$$susp'( '$festivo',  [], _MI, _NI )))), :('$$tup'(','(5, ','(5, '$$susp'( '$festivo',  [], _OI, _PI )))), :('$$tup'(','(5, ','(6, '$$susp'( '$laborable',  [], _QI, _RI )))), :('$$tup'(','(5, ','(7, '$$susp'( '$laborable',  [], _SI, _TI )))), :('$$tup'(','(5, ','(8, '$$susp'( '$laborable',  [], _UI, _VI )))), :('$$tup'(','(5, ','(9, '$$susp'( '$laborable',  [], _WI, _XI )))), :('$$tup'(','(5, ','(10, '$$susp'( '$laborable',  [], _YI, _ZI )))), :('$$tup'(','(5, ','(11, '$$susp'( '$festivo',  [], _AJ, _BJ )))), :('$$tup'(','(5, ','(12, '$$susp'( '$festivo',  [], _CJ, _DJ )))), :('$$tup'(','(5, ','(13, '$$susp'( '$laborable',  [], _EJ, _FJ )))), :('$$tup'(','(5, ','(14, '$$susp'( '$laborable',  [], _GJ, _HJ )))), :('$$tup'(','(5, ','(15, '$$susp'( '$laborable',  [], _IJ, _JJ )))), :('$$tup'(','(5, ','(16, '$$susp'( '$laborable',  [], _KJ, _LJ )))), :('$$tup'(','(5, ','(17, '$$susp'( '$laborable',  [], _MJ, _NJ )))), :('$$tup'(','(5, ','(18, '$$susp'( '$festivo',  [], _OJ, _PJ )))), :('$$tup'(','(5, ','(19, '$$susp'( '$festivo',  [], _QJ, _RJ )))), :('$$tup'(','(5, ','(20, '$$susp'( '$laborable',  [], _SJ, _TJ )))), :('$$tup'(','(5, ','(21, '$$susp'( '$laborable',  [], _UJ, _VJ )))), :('$$tup'(','(5, ','(22, '$$susp'( '$laborable',  [], _WJ, _XJ )))), :('$$tup'(','(5, ','(23, '$$susp'( '$laborable',  [], _YJ, _ZJ )))), :('$$tup'(','(5, ','(24, '$$susp'( '$laborable',  [], _AK, _BK )))), :('$$tup'(','(5, ','(25, '$$susp'( '$festivo',  [], _CK, _DK )))), :('$$tup'(','(5, ','(26, '$$susp'( '$festivo',  [], _EK, _FK )))), :('$$tup'(','(5, ','(27, '$$susp'( '$laborable',  [], _GK, _HK )))), :('$$tup'(','(5, ','(28, '$$susp'( '$laborable',  [], _IK, _JK )))), :('$$tup'(','(5, ','(29, '$$susp'( '$laborable',  [], _KK, _LK )))), :('$$tup'(','(5, ','(30, '$$susp'( '$laborable',  [], _MK, _NK )))), :('$$tup'(','(5, ','(31, '$$susp'( '$laborable',  [], _OK, _PK )))), :('$$tup'(','(6, ','(1, '$$susp'( '$festivo',  [], _QK, _RK )))), :('$$tup'(','(6, ','(2, '$$susp'( '$festivo',  [], _SK, _TK )))), :('$$tup'(','(6, ','(3, '$$susp'( '$laborable',  [], _UK, _VK )))), :('$$tup'(','(6, ','(4, '$$susp'( '$laborable',  [], _WK, _XK )))), :('$$tup'(','(6, ','(5, '$$susp'( '$laborable',  [], _YK, _ZK )))), :('$$tup'(','(6, ','(6, '$$susp'( '$laborable',  [], _AL, _BL )))), :('$$tup'(','(6, ','(7, '$$susp'( '$festivo',  [], _CL, _DL )))), :('$$tup'(','(6, ','(8, '$$susp'( '$festivo',  [], _EL, _FL )))), :('$$tup'(','(6, ','(9, '$$susp'( '$laborable',  [], _GL, _HL )))), :('$$tup'(','(6, ','(10, '$$susp'( '$laborable',  [], _IL, _JL )))), :('$$tup'(','(6, ','(11, '$$susp'( '$laborable',  [], _KL, _LL )))), :('$$tup'(','(6, ','(12, '$$susp'( '$laborable',  [], _ML, _NL )))), :('$$tup'(','(6, ','(13, '$$susp'( '$laborable',  [], _OL, _PL )))), :('$$tup'(','(6, ','(14, '$$susp'( '$festivo',  [], _QL, _RL )))), :('$$tup'(','(6, ','(15, '$$susp'( '$festivo',  [], _SL, _TL )))), :('$$tup'(','(6, ','(16, '$$susp'( '$laborable',  [], _UL, _VL )))), :('$$tup'(','(6, ','(17, '$$susp'( '$laborable',  [], _WL, _XL )))), :('$$tup'(','(6, ','(18, '$$susp'( '$laborable',  [], _YL, _ZL )))), :('$$tup'(','(6, ','(19, '$$susp'( '$laborable',  [], _AM, _BM )))), :('$$tup'(','(6, ','(20, '$$susp'( '$laborable',  [], _CM, _DM )))), :('$$tup'(','(6, ','(21, '$$susp'( '$festivo',  [], _EM, _FM )))), :('$$tup'(','(6, ','(22, '$$susp'( '$festivo',  [], _GM, _HM )))), :('$$tup'(','(6, ','(23, '$$susp'( '$laborable',  [], _IM, _JM )))), :('$$tup'(','(6, ','(24, '$$susp'( '$laborable',  [], _KM, _LM )))), :('$$tup'(','(6, ','(25, '$$susp'( '$laborable',  [], _MM, _NM )))), :('$$tup'(','(6, ','(26, '$$susp'( '$laborable',  [], _OM, _PM )))), :('$$tup'(','(6, ','(27, '$$susp'( '$laborable',  [], _QM, _RM )))), :('$$tup'(','(6, ','(28, '$$susp'( '$festivo',  [], _SM, _TM )))), :('$$tup'(','(6, ','(29, '$$susp'( '$festivo',  [], _UM, _VM )))), :('$$tup'(','(6, ','(30, '$$susp'( '$laborable',  [], _WM, _XM )))), :('$$tup'(','(7, ','(1, '$$susp'( '$laborable',  [], _YM, _ZM )))), :('$$tup'(','(7, ','(2, '$$susp'( '$laborable',  [], _AN, _BN )))), :('$$tup'(','(7, ','(3, '$$susp'( '$laborable',  [], _CN, _DN )))), :('$$tup'(','(7, ','(4, '$$susp'( '$laborable',  [], _EN, _FN )))), :('$$tup'(','(7, ','(5, '$$susp'( '$festivo',  [], _GN, _HN )))), :('$$tup'(','(7, ','(6, '$$susp'( '$festivo',  [], _IN, _JN )))), :('$$tup'(','(7, ','(7, '$$susp'( '$laborable',  [], _KN, _LN )))), :('$$tup'(','(7, ','(8, '$$susp'( '$laborable',  [], _MN, _NN )))), :('$$tup'(','(7, ','(9, '$$susp'( '$laborable',  [], _ON, _PN )))), :('$$tup'(','(7, ','(10, '$$susp'( '$laborable',  [], _QN, _RN )))), :('$$tup'(','(7, ','(11, '$$susp'( '$laborable',  [], _SN, _TN )))), :('$$tup'(','(7, ','(12, '$$susp'( '$festivo',  [], _UN, _VN )))), :('$$tup'(','(7, ','(13, '$$susp'( '$festivo',  [], _WN, _XN )))), :('$$tup'(','(7, ','(14, '$$susp'( '$laborable',  [], _YN, _ZN )))), :('$$tup'(','(7, ','(15, '$$susp'( '$laborable',  [], _AO, _BO )))), :('$$tup'(','(7, ','(16, '$$susp'( '$laborable',  [], _CO, _DO )))), :('$$tup'(','(7, ','(17, '$$susp'( '$laborable',  [], _EO, _FO )))), :('$$tup'(','(7, ','(18, '$$susp'( '$laborable',  [], _GO, _HO )))), :('$$tup'(','(7, ','(19, '$$susp'( '$festivo',  [], _IO, _JO )))), :('$$tup'(','(7, ','(20, '$$susp'( '$festivo',  [], _KO, _LO )))), :('$$tup'(','(7, ','(21, '$$susp'( '$laborable',  [], _MO, _NO )))), :('$$tup'(','(7, ','(22, '$$susp'( '$laborable',  [], _OO, _PO )))), :('$$tup'(','(7, ','(23, '$$susp'( '$laborable',  [], _QO, _RO )))), :('$$tup'(','(7, ','(24, '$$susp'( '$laborable',  [], _SO, _TO )))), :('$$tup'(','(7, ','(25, '$$susp'( '$laborable',  [], _UO, _VO )))), :('$$tup'(','(7, ','(26, '$$susp'( '$festivo',  [], _WO, _XO )))), :('$$tup'(','(7, ','(27, '$$susp'( '$festivo',  [], _YO, _ZO )))), :('$$tup'(','(7, ','(28, '$$susp'( '$laborable',  [], _AP, _BP )))), :('$$tup'(','(7, ','(29, '$$susp'( '$laborable',  [], _CP, _DP )))), :('$$tup'(','(7, ','(30, '$$susp'( '$laborable',  [], _EP, _FP )))), :('$$tup'(','(7, ','(31, '$$susp'( '$laborable',  [], _GP, _HP )))), :('$$tup'(','(8, ','(1, '$$susp'( '$laborable',  [], _IP, _JP )))), :('$$tup'(','(8, ','(2, '$$susp'( '$festivo',  [], _KP, _LP )))), :('$$tup'(','(8, ','(3, '$$susp'( '$laborable',  [], _MP, _NP )))), :('$$tup'(','(8, ','(4, '$$susp'( '$laborable',  [], _OP, _PP )))), :('$$tup'(','(8, ','(5, '$$susp'( '$laborable',  [], _QP, _RP )))), :('$$tup'(','(8, ','(6, '$$susp'( '$laborable',  [], _SP, _TP )))), :('$$tup'(','(8, ','(7, '$$susp'( '$festivo',  [], _UP, _VP )))), :('$$tup'(','(8, ','(8, '$$susp'( '$festivo',  [], _WP, _XP )))), :('$$tup'(','(8, ','(9, '$$susp'( '$laborable',  [], _YP, _ZP )))), :('$$tup'(','(8, ','(10, '$$susp'( '$laborable',  [], _AQ, _BQ )))), :('$$tup'(','(8, ','(11, '$$susp'( '$laborable',  [], _CQ, _DQ )))), :('$$tup'(','(8, ','(12, '$$susp'( '$laborable',  [], _EQ, _FQ )))), :('$$tup'(','(8, ','(13, '$$susp'( '$laborable',  [], _GQ, _HQ )))), :('$$tup'(','(8, ','(14, '$$susp'( '$festivo',  [], _IQ, _JQ )))), :('$$tup'(','(8, ','(15, '$$susp'( '$festivo',  [], _KQ, _LQ )))), :('$$tup'(','(8, ','(16, '$$susp'( '$laborable',  [], _MQ, _NQ )))), :('$$tup'(','(8, ','(17, '$$susp'( '$laborable',  [], _OQ, _PQ )))), :('$$tup'(','(8, ','(18, '$$susp'( '$laborable',  [], _QQ, _RQ )))), :('$$tup'(','(8, ','(19, '$$susp'( '$laborable',  [], _SQ, _TQ )))), :('$$tup'(','(8, ','(20, '$$susp'( '$laborable',  [], _UQ, _VQ )))), :('$$tup'(','(8, ','(21, '$$susp'( '$festivo',  [], _WQ, _XQ )))), :('$$tup'(','(8, ','(22, '$$susp'( '$festivo',  [], _YQ, _ZQ )))), :('$$tup'(','(8, ','(23, '$$susp'( '$laborable',  [], _AR, _BR )))), :('$$tup'(','(8, ','(24, '$$susp'( '$laborable',  [], _CR, _DR )))), :('$$tup'(','(8, ','(25, '$$susp'( '$laborable',  [], _ER, _FR )))), :('$$tup'(','(8, ','(26, '$$susp'( '$laborable',  [], _GR, _HR )))), :('$$tup'(','(8, ','(27, '$$susp'( '$laborable',  [], _IR, _JR )))), :('$$tup'(','(8, ','(28, '$$susp'( '$festivo',  [], _KR, _LR )))), :('$$tup'(','(8, ','(29, '$$susp'( '$festivo',  [], _MR, _NR )))), :('$$tup'(','(8, ','(30, '$$susp'( '$laborable',  [], _OR, _PR )))), :('$$tup'(','(8, ','(31, '$$susp'( '$laborable',  [], _QR, _RR )))), :('$$tup'(','(9, ','(1, '$$susp'( '$laborable',  [], _SR, _TR )))), :('$$tup'(','(9, ','(2, '$$susp'( '$laborable',  [], _UR, _VR )))), :('$$tup'(','(9, ','(3, '$$susp'( '$laborable',  [], _WR, _XR )))), :('$$tup'(','(9, ','(4, '$$susp'( '$festivo',  [], _YR, _ZR )))), :('$$tup'(','(9, ','(5, '$$susp'( '$festivo',  [], _AS, _BS )))), :('$$tup'(','(9, ','(6, '$$susp'( '$laborable',  [], _CS, _DS )))), :('$$tup'(','(9, ','(7, '$$susp'( '$laborable',  [], _ES, _FS )))), :('$$tup'(','(9, ','(8, '$$susp'( '$laborable',  [], _GS, _HS )))), :('$$tup'(','(9, ','(9, '$$susp'( '$laborable',  [], _IS, _JS )))), :('$$tup'(','(9, ','(10, '$$susp'( '$laborable',  [], _KS, _LS )))), :('$$tup'(','(9, ','(11, '$$susp'( '$festivo',  [], _MS, _NS )))), :('$$tup'(','(9, ','(12, '$$susp'( '$festivo',  [], _OS, _PS )))), :('$$tup'(','(9, ','(13, '$$susp'( '$laborable',  [], _QS, _RS )))), :('$$tup'(','(9, ','(14, '$$susp'( '$laborable',  [], _SS, _TS )))), :('$$tup'(','(9, ','(15, '$$susp'( '$laborable',  [], _US, _VS )))), :('$$tup'(','(9, ','(16, '$$susp'( '$laborable',  [], _WS, _XS )))), :('$$tup'(','(9, ','(17, '$$susp'( '$laborable',  [], _YS, _ZS )))), :('$$tup'(','(9, ','(18, '$$susp'( '$festivo',  [], _AT, _BT )))), :('$$tup'(','(9, ','(19, '$$susp'( '$festivo',  [], _CT, _DT )))), :('$$tup'(','(9, ','(20, '$$susp'( '$laborable',  [], _ET, _FT )))), :('$$tup'(','(9, ','(21, '$$susp'( '$laborable',  [], _GT, _HT )))), :('$$tup'(','(9, ','(22, '$$susp'( '$laborable',  [], _IT, _JT )))), :('$$tup'(','(9, ','(23, '$$susp'( '$laborable',  [], _KT, _LT )))), :('$$tup'(','(9, ','(24, '$$susp'( '$laborable',  [], _MT, _NT )))), :('$$tup'(','(9, ','(25, '$$susp'( '$festivo',  [], _OT, _PT )))), :('$$tup'(','(9, ','(26, '$$susp'( '$festivo',  [], _QT, _RT )))), :('$$tup'(','(9, ','(27, '$$susp'( '$laborable',  [], _ST, _TT )))), :('$$tup'(','(9, ','(28, '$$susp'( '$laborable',  [], _UT, _VT )))), :('$$tup'(','(9, ','(29, '$$susp'( '$laborable',  [], _WT, _XT )))), :('$$tup'(','(9, ','(30, '$$susp'( '$laborable',  [], _YT, _ZT )))), :('$$tup'(','(10, ','(1, '$$susp'( '$festivo',  [], _AU, _BU )))), :('$$tup'(','(10, ','(2, '$$susp'( '$laborable',  [], _CU, _DU )))), :('$$tup'(','(10, ','(3, '$$susp'( '$laborable',  [], _EU, _FU )))), :('$$tup'(','(10, ','(4, '$$susp'( '$laborable',  [], _GU, _HU )))), :('$$tup'(','(10, ','(5, '$$susp'( '$laborable',  [], _IU, _JU )))), :('$$tup'(','(10, ','(6, '$$susp'( '$festivo',  [], _KU, _LU )))), :('$$tup'(','(10, ','(7, '$$susp'( '$festivo',  [], _MU, _NU )))), :('$$tup'(','(10, ','(8, '$$susp'( '$laborable',  [], _OU, _PU )))), :('$$tup'(','(10, ','(9, '$$susp'( '$laborable',  [], _QU, _RU )))), :('$$tup'(','(10, ','(10, '$$susp'( '$laborable',  [], _SU, _TU )))), :('$$tup'(','(10, ','(11, '$$susp'( '$laborable',  [], _UU, _VU )))), :('$$tup'(','(10, ','(12, '$$susp'( '$laborable',  [], _WU, _XU )))), :('$$tup'(','(10, ','(13, '$$susp'( '$festivo',  [], _YU, _ZU )))), :('$$tup'(','(10, ','(14, '$$susp'( '$festivo',  [], _AV, _BV )))), :('$$tup'(','(10, ','(15, '$$susp'( '$laborable',  [], _CV, _DV )))), :('$$tup'(','(10, ','(16, '$$susp'( '$laborable',  [], _EV, _FV )))), :('$$tup'(','(10, ','(17, '$$susp'( '$laborable',  [], _GV, _HV )))), :('$$tup'(','(10, ','(18, '$$susp'( '$laborable',  [], _IV, _JV )))), :('$$tup'(','(10, ','(19, '$$susp'( '$laborable',  [], _KV, _LV )))), :('$$tup'(','(10, ','(20, '$$susp'( '$festivo',  [], _MV, _NV )))), :('$$tup'(','(10, ','(21, '$$susp'( '$festivo',  [], _OV, _PV )))), :('$$tup'(','(10, ','(22, '$$susp'( '$laborable',  [], _QV, _RV )))), :('$$tup'(','(10, ','(23, '$$susp'( '$laborable',  [], _SV, _TV )))), :('$$tup'(','(10, ','(24, '$$susp'( '$laborable',  [], _UV, _VV )))), :('$$tup'(','(10, ','(25, '$$susp'( '$laborable',  [], _WV, _XV )))), :('$$tup'(','(10, ','(26, '$$susp'( '$laborable',  [], _YV, _ZV )))), :('$$tup'(','(10, ','(27, '$$susp'( '$festivo',  [], _AW, _BW )))), :('$$tup'(','(10, ','(28, '$$susp'( '$festivo',  [], _CW, _DW )))), :('$$tup'(','(10, ','(29, '$$susp'( '$laborable',  [], _EW, _FW )))), :('$$tup'(','(10, ','(30, '$$susp'( '$laborable',  [], _GW, _HW )))), :('$$tup'(','(10, ','(31, '$$susp'( '$laborable',  [], _IW, _JW )))), [])))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _KW, _KW).

% anio
'$anio'(:('$$tup'(','(1, ','(1, '$$susp'( '$festivo',  [], _A, _B )))), :('$$tup'(','(1, ','(2, '$$susp'( '$laborable',  [], _C, _D )))), :('$$tup'(','(1, ','(3, '$$susp'( '$laborable',  [], _E, _F )))), :('$$tup'(','(1, ','(4, '$$susp'( '$laborable',  [], _G, _H )))), :('$$tup'(','(1, ','(5, '$$susp'( '$laborable',  [], _I, _J )))), :('$$tup'(','(1, ','(6, '$$susp'( '$festivo',  [], _K, _L )))), :('$$tup'(','(1, ','(7, '$$susp'( '$festivo',  [], _M, _N )))), :('$$tup'(','(1, ','(8, '$$susp'( '$laborable',  [], _O, _P )))), :('$$tup'(','(1, ','(9, '$$susp'( '$laborable',  [], _Q, _R )))), :('$$tup'(','(1, ','(10, '$$susp'( '$laborable',  [], _S, _T )))), :('$$tup'(','(1, ','(11, '$$susp'( '$laborable',  [], _U, _V )))), :('$$tup'(','(1, ','(12, '$$susp'( '$laborable',  [], _W, _X )))), :('$$tup'(','(1, ','(13, '$$susp'( '$festivo',  [], _Y, _Z )))), :('$$tup'(','(1, ','(14, '$$susp'( '$festivo',  [], _AA, _BA )))), :('$$tup'(','(1, ','(15, '$$susp'( '$laborable',  [], _CA, _DA )))), :('$$tup'(','(1, ','(16, '$$susp'( '$laborable',  [], _EA, _FA )))), :('$$tup'(','(1, ','(17, '$$susp'( '$laborable',  [], _GA, _HA )))), :('$$tup'(','(1, ','(18, '$$susp'( '$laborable',  [], _IA, _JA )))), :('$$tup'(','(1, ','(19, '$$susp'( '$laborable',  [], _KA, _LA )))), :('$$tup'(','(1, ','(20, '$$susp'( '$festivo',  [], _MA, _NA )))), :('$$tup'(','(1, ','(21, '$$susp'( '$festivo',  [], _OA, _PA )))), :('$$tup'(','(1, ','(22, '$$susp'( '$laborable',  [], _QA, _RA )))), :('$$tup'(','(1, ','(23, '$$susp'( '$laborable',  [], _SA, _TA )))), :('$$tup'(','(1, ','(24, '$$susp'( '$laborable',  [], _UA, _VA )))), :('$$tup'(','(1, ','(25, '$$susp'( '$laborable',  [], _WA, _XA )))), :('$$tup'(','(1, ','(26, '$$susp'( '$laborable',  [], _YA, _ZA )))), :('$$tup'(','(1, ','(27, '$$susp'( '$festivo',  [], _AB, _BB )))), :('$$tup'(','(1, ','(28, '$$susp'( '$festivo',  [], _CB, _DB )))), :('$$tup'(','(1, ','(29, '$$susp'( '$laborable',  [], _EB, _FB )))), :('$$tup'(','(1, ','(30, '$$susp'( '$laborable',  [], _GB, _HB )))), :('$$tup'(','(1, ','(31, '$$susp'( '$laborable',  [], _IB, _JB )))), :('$$tup'(','(2, ','(1, '$$susp'( '$laborable',  [], _KB, _LB )))), :('$$tup'(','(2, ','(2, '$$susp'( '$laborable',  [], _MB, _NB )))), :('$$tup'(','(2, ','(3, '$$susp'( '$festivo',  [], _OB, _PB )))), :('$$tup'(','(2, ','(4, '$$susp'( '$festivo',  [], _QB, _RB )))), :('$$tup'(','(2, ','(5, '$$susp'( '$laborable',  [], _SB, _TB )))), :('$$tup'(','(2, ','(6, '$$susp'( '$laborable',  [], _UB, _VB )))), :('$$tup'(','(2, ','(7, '$$susp'( '$laborable',  [], _WB, _XB )))), :('$$tup'(','(2, ','(8, '$$susp'( '$laborable',  [], _YB, _ZB )))), :('$$tup'(','(2, ','(9, '$$susp'( '$laborable',  [], _AC, _BC )))), :('$$tup'(','(2, ','(10, '$$susp'( '$festivo',  [], _CC, _DC )))), :('$$tup'(','(2, ','(11, '$$susp'( '$festivo',  [], _EC, _FC )))), :('$$tup'(','(2, ','(12, '$$susp'( '$laborable',  [], _GC, _HC )))), :('$$tup'(','(2, ','(13, '$$susp'( '$laborable',  [], _IC, _JC )))), :('$$tup'(','(2, ','(14, '$$susp'( '$laborable',  [], _KC, _LC )))), :('$$tup'(','(2, ','(15, '$$susp'( '$laborable',  [], _MC, _NC )))), :('$$tup'(','(2, ','(16, '$$susp'( '$laborable',  [], _OC, _PC )))), :('$$tup'(','(2, ','(17, '$$susp'( '$festivo',  [], _QC, _RC )))), :('$$tup'(','(2, ','(18, '$$susp'( '$festivo',  [], _SC, _TC )))), :('$$tup'(','(2, ','(19, '$$susp'( '$laborable',  [], _UC, _VC )))), :('$$tup'(','(2, ','(20, '$$susp'( '$laborable',  [], _WC, _XC )))), :('$$tup'(','(2, ','(21, '$$susp'( '$laborable',  [], _YC, _ZC )))), :('$$tup'(','(2, ','(22, '$$susp'( '$laborable',  [], _AD, _BD )))), :('$$tup'(','(2, ','(23, '$$susp'( '$laborable',  [], _CD, _DD )))), :('$$tup'(','(2, ','(24, '$$susp'( '$festivo',  [], _ED, _FD )))), :('$$tup'(','(2, ','(25, '$$susp'( '$festivo',  [], _GD, _HD )))), :('$$tup'(','(2, ','(26, '$$susp'( '$laborable',  [], _ID, _JD )))), :('$$tup'(','(2, ','(27, '$$susp'( '$laborable',  [], _KD, _LD )))), :('$$tup'(','(2, ','(28, '$$susp'( '$laborable',  [], _MD, _ND )))), :('$$tup'(','(3, ','(1, '$$susp'( '$laborable',  [], _OD, _PD )))), :('$$tup'(','(3, ','(2, '$$susp'( '$laborable',  [], _QD, _RD )))), :('$$tup'(','(3, ','(3, '$$susp'( '$festivo',  [], _SD, _TD )))), :('$$tup'(','(3, ','(4, '$$susp'( '$festivo',  [], _UD, _VD )))), :('$$tup'(','(3, ','(5, '$$susp'( '$laborable',  [], _WD, _XD )))), :('$$tup'(','(3, ','(6, '$$susp'( '$laborable',  [], _YD, _ZD )))), :('$$tup'(','(3, ','(7, '$$susp'( '$laborable',  [], _AE, _BE )))), :('$$tup'(','(3, ','(8, '$$susp'( '$laborable',  [], _CE, _DE )))), :('$$tup'(','(3, ','(9, '$$susp'( '$laborable',  [], _EE, _FE )))), :('$$tup'(','(3, ','(10, '$$susp'( '$festivo',  [], _GE, _HE )))), :('$$tup'(','(3, ','(11, '$$susp'( '$festivo',  [], _IE, _JE )))), :('$$tup'(','(3, ','(12, '$$susp'( '$laborable',  [], _KE, _LE )))), :('$$tup'(','(3, ','(13, '$$susp'( '$laborable',  [], _ME, _NE )))), :('$$tup'(','(3, ','(14, '$$susp'( '$laborable',  [], _OE, _PE )))), :('$$tup'(','(3, ','(15, '$$susp'( '$laborable',  [], _QE, _RE )))), :('$$tup'(','(3, ','(16, '$$susp'( '$laborable',  [], _SE, _TE )))), :('$$tup'(','(3, ','(17, '$$susp'( '$festivo',  [], _UE, _VE )))), :('$$tup'(','(3, ','(18, '$$susp'( '$festivo',  [], _WE, _XE )))), :('$$tup'(','(3, ','(19, '$$susp'( '$laborable',  [], _YE, _ZE )))), :('$$tup'(','(3, ','(20, '$$susp'( '$laborable',  [], _AF, _BF )))), :('$$tup'(','(3, ','(21, '$$susp'( '$laborable',  [], _CF, _DF )))), :('$$tup'(','(3, ','(22, '$$susp'( '$laborable',  [], _EF, _FF )))), :('$$tup'(','(3, ','(23, '$$susp'( '$laborable',  [], _GF, _HF )))), :('$$tup'(','(3, ','(24, '$$susp'( '$festivo',  [], _IF, _JF )))), :('$$tup'(','(3, ','(25, '$$susp'( '$festivo',  [], _KF, _LF )))), :('$$tup'(','(3, ','(26, '$$susp'( '$laborable',  [], _MF, _NF )))), :('$$tup'(','(3, ','(27, '$$susp'( '$laborable',  [], _OF, _PF )))), :('$$tup'(','(3, ','(28, '$$susp'( '$laborable',  [], _QF, _RF )))), :('$$tup'(','(3, ','(29, '$$susp'( '$laborable',  [], _SF, _TF )))), :('$$tup'(','(3, ','(30, '$$susp'( '$laborable',  [], _UF, _VF )))), :('$$tup'(','(3, ','(31, '$$susp'( '$festivo',  [], _WF, _XF )))), :('$$tup'(','(4, ','(1, '$$susp'( '$festivo',  [], _YF, _ZF )))), :('$$tup'(','(4, ','(2, '$$susp'( '$laborable',  [], _AG, _BG )))), :('$$tup'(','(4, ','(3, '$$susp'( '$laborable',  [], _CG, _DG )))), :('$$tup'(','(4, ','(4, '$$susp'( '$laborable',  [], _EG, _FG )))), :('$$tup'(','(4, ','(5, '$$susp'( '$laborable',  [], _GG, _HG )))), :('$$tup'(','(4, ','(6, '$$susp'( '$festivo',  [], _IG, _JG )))), :('$$tup'(','(4, ','(7, '$$susp'( '$festivo',  [], _KG, _LG )))), :('$$tup'(','(4, ','(8, '$$susp'( '$laborable',  [], _MG, _NG )))), :('$$tup'(','(4, ','(9, '$$susp'( '$laborable',  [], _OG, _PG )))), :('$$tup'(','(4, ','(10, '$$susp'( '$laborable',  [], _QG, _RG )))), :('$$tup'(','(4, ','(11, '$$susp'( '$laborable',  [], _SG, _TG )))), :('$$tup'(','(4, ','(12, '$$susp'( '$laborable',  [], _UG, _VG )))), :('$$tup'(','(4, ','(13, '$$susp'( '$festivo',  [], _WG, _XG )))), :('$$tup'(','(4, ','(14, '$$susp'( '$festivo',  [], _YG, _ZG )))), :('$$tup'(','(4, ','(15, '$$susp'( '$laborable',  [], _AH, _BH )))), :('$$tup'(','(4, ','(16, '$$susp'( '$laborable',  [], _CH, _DH )))), :('$$tup'(','(4, ','(17, '$$susp'( '$laborable',  [], _EH, _FH )))), :('$$tup'(','(4, ','(18, '$$susp'( '$laborable',  [], _GH, _HH )))), :('$$tup'(','(4, ','(19, '$$susp'( '$laborable',  [], _IH, _JH )))), :('$$tup'(','(4, ','(20, '$$susp'( '$festivo',  [], _KH, _LH )))), :('$$tup'(','(4, ','(21, '$$susp'( '$festivo',  [], _MH, _NH )))), :('$$tup'(','(4, ','(22, '$$susp'( '$laborable',  [], _OH, _PH )))), :('$$tup'(','(4, ','(23, '$$susp'( '$laborable',  [], _QH, _RH )))), :('$$tup'(','(4, ','(24, '$$susp'( '$laborable',  [], _SH, _TH )))), :('$$tup'(','(4, ','(25, '$$susp'( '$laborable',  [], _UH, _VH )))), :('$$tup'(','(4, ','(26, '$$susp'( '$laborable',  [], _WH, _XH )))), :('$$tup'(','(4, ','(27, '$$susp'( '$festivo',  [], _YH, _ZH )))), :('$$tup'(','(4, ','(28, '$$susp'( '$festivo',  [], _AI, _BI )))), :('$$tup'(','(4, ','(29, '$$susp'( '$laborable',  [], _CI, _DI )))), :('$$tup'(','(4, ','(30, '$$susp'( '$laborable',  [], _EI, _FI )))), :('$$tup'(','(5, ','(1, '$$susp'( '$laborable',  [], _GI, _HI )))), :('$$tup'(','(5, ','(2, '$$susp'( '$laborable',  [], _II, _JI )))), :('$$tup'(','(5, ','(3, '$$susp'( '$laborable',  [], _KI, _LI )))), :('$$tup'(','(5, ','(4, '$$susp'( '$festivo',  [], _MI, _NI )))), :('$$tup'(','(5, ','(5, '$$susp'( '$festivo',  [], _OI, _PI )))), :('$$tup'(','(5, ','(6, '$$susp'( '$laborable',  [], _QI, _RI )))), :('$$tup'(','(5, ','(7, '$$susp'( '$laborable',  [], _SI, _TI )))), :('$$tup'(','(5, ','(8, '$$susp'( '$laborable',  [], _UI, _VI )))), :('$$tup'(','(5, ','(9, '$$susp'( '$laborable',  [], _WI, _XI )))), :('$$tup'(','(5, ','(10, '$$susp'( '$laborable',  [], _YI, _ZI )))), :('$$tup'(','(5, ','(11, '$$susp'( '$festivo',  [], _AJ, _BJ )))), :('$$tup'(','(5, ','(12, '$$susp'( '$festivo',  [], _CJ, _DJ )))), :('$$tup'(','(5, ','(13, '$$susp'( '$laborable',  [], _EJ, _FJ )))), :('$$tup'(','(5, ','(14, '$$susp'( '$laborable',  [], _GJ, _HJ )))), :('$$tup'(','(5, ','(15, '$$susp'( '$laborable',  [], _IJ, _JJ )))), :('$$tup'(','(5, ','(16, '$$susp'( '$laborable',  [], _KJ, _LJ )))), :('$$tup'(','(5, ','(17, '$$susp'( '$laborable',  [], _MJ, _NJ )))), :('$$tup'(','(5, ','(18, '$$susp'( '$festivo',  [], _OJ, _PJ )))), :('$$tup'(','(5, ','(19, '$$susp'( '$festivo',  [], _QJ, _RJ )))), :('$$tup'(','(5, ','(20, '$$susp'( '$laborable',  [], _SJ, _TJ )))), :('$$tup'(','(5, ','(21, '$$susp'( '$laborable',  [], _UJ, _VJ )))), :('$$tup'(','(5, ','(22, '$$susp'( '$laborable',  [], _WJ, _XJ )))), :('$$tup'(','(5, ','(23, '$$susp'( '$laborable',  [], _YJ, _ZJ )))), :('$$tup'(','(5, ','(24, '$$susp'( '$laborable',  [], _AK, _BK )))), :('$$tup'(','(5, ','(25, '$$susp'( '$festivo',  [], _CK, _DK )))), :('$$tup'(','(5, ','(26, '$$susp'( '$festivo',  [], _EK, _FK )))), :('$$tup'(','(5, ','(27, '$$susp'( '$laborable',  [], _GK, _HK )))), :('$$tup'(','(5, ','(28, '$$susp'( '$laborable',  [], _IK, _JK )))), :('$$tup'(','(5, ','(29, '$$susp'( '$laborable',  [], _KK, _LK )))), :('$$tup'(','(5, ','(30, '$$susp'( '$laborable',  [], _MK, _NK )))), :('$$tup'(','(5, ','(31, '$$susp'( '$laborable',  [], _OK, _PK )))), :('$$tup'(','(6, ','(1, '$$susp'( '$festivo',  [], _QK, _RK )))), :('$$tup'(','(6, ','(2, '$$susp'( '$festivo',  [], _SK, _TK )))), :('$$tup'(','(6, ','(3, '$$susp'( '$laborable',  [], _UK, _VK )))), :('$$tup'(','(6, ','(4, '$$susp'( '$laborable',  [], _WK, _XK )))), :('$$tup'(','(6, ','(5, '$$susp'( '$laborable',  [], _YK, _ZK )))), :('$$tup'(','(6, ','(6, '$$susp'( '$laborable',  [], _AL, _BL )))), :('$$tup'(','(6, ','(7, '$$susp'( '$festivo',  [], _CL, _DL )))), :('$$tup'(','(6, ','(8, '$$susp'( '$festivo',  [], _EL, _FL )))), :('$$tup'(','(6, ','(9, '$$susp'( '$laborable',  [], _GL, _HL )))), :('$$tup'(','(6, ','(10, '$$susp'( '$laborable',  [], _IL, _JL )))), :('$$tup'(','(6, ','(11, '$$susp'( '$laborable',  [], _KL, _LL )))), :('$$tup'(','(6, ','(12, '$$susp'( '$laborable',  [], _ML, _NL )))), :('$$tup'(','(6, ','(13, '$$susp'( '$laborable',  [], _OL, _PL )))), :('$$tup'(','(6, ','(14, '$$susp'( '$festivo',  [], _QL, _RL )))), :('$$tup'(','(6, ','(15, '$$susp'( '$festivo',  [], _SL, _TL )))), :('$$tup'(','(6, ','(16, '$$susp'( '$laborable',  [], _UL, _VL )))), :('$$tup'(','(6, ','(17, '$$susp'( '$laborable',  [], _WL, _XL )))), :('$$tup'(','(6, ','(18, '$$susp'( '$laborable',  [], _YL, _ZL )))), :('$$tup'(','(6, ','(19, '$$susp'( '$laborable',  [], _AM, _BM )))), :('$$tup'(','(6, ','(20, '$$susp'( '$laborable',  [], _CM, _DM )))), :('$$tup'(','(6, ','(21, '$$susp'( '$festivo',  [], _EM, _FM )))), :('$$tup'(','(6, ','(22, '$$susp'( '$festivo',  [], _GM, _HM )))), :('$$tup'(','(6, ','(23, '$$susp'( '$laborable',  [], _IM, _JM )))), :('$$tup'(','(6, ','(24, '$$susp'( '$laborable',  [], _KM, _LM )))), :('$$tup'(','(6, ','(25, '$$susp'( '$laborable',  [], _MM, _NM )))), :('$$tup'(','(6, ','(26, '$$susp'( '$laborable',  [], _OM, _PM )))), :('$$tup'(','(6, ','(27, '$$susp'( '$laborable',  [], _QM, _RM )))), :('$$tup'(','(6, ','(28, '$$susp'( '$festivo',  [], _SM, _TM )))), :('$$tup'(','(6, ','(29, '$$susp'( '$festivo',  [], _UM, _VM )))), :('$$tup'(','(6, ','(30, '$$susp'( '$laborable',  [], _WM, _XM )))), :('$$tup'(','(7, ','(1, '$$susp'( '$laborable',  [], _YM, _ZM )))), :('$$tup'(','(7, ','(2, '$$susp'( '$laborable',  [], _AN, _BN )))), :('$$tup'(','(7, ','(3, '$$susp'( '$laborable',  [], _CN, _DN )))), :('$$tup'(','(7, ','(4, '$$susp'( '$laborable',  [], _EN, _FN )))), :('$$tup'(','(7, ','(5, '$$susp'( '$festivo',  [], _GN, _HN )))), :('$$tup'(','(7, ','(6, '$$susp'( '$festivo',  [], _IN, _JN )))), :('$$tup'(','(7, ','(7, '$$susp'( '$laborable',  [], _KN, _LN )))), :('$$tup'(','(7, ','(8, '$$susp'( '$laborable',  [], _MN, _NN )))), :('$$tup'(','(7, ','(9, '$$susp'( '$laborable',  [], _ON, _PN )))), :('$$tup'(','(7, ','(10, '$$susp'( '$laborable',  [], _QN, _RN )))), :('$$tup'(','(7, ','(11, '$$susp'( '$laborable',  [], _SN, _TN )))), :('$$tup'(','(7, ','(12, '$$susp'( '$festivo',  [], _UN, _VN )))), :('$$tup'(','(7, ','(13, '$$susp'( '$festivo',  [], _WN, _XN )))), :('$$tup'(','(7, ','(14, '$$susp'( '$laborable',  [], _YN, _ZN )))), :('$$tup'(','(7, ','(15, '$$susp'( '$laborable',  [], _AO, _BO )))), :('$$tup'(','(7, ','(16, '$$susp'( '$laborable',  [], _CO, _DO )))), :('$$tup'(','(7, ','(17, '$$susp'( '$laborable',  [], _EO, _FO )))), :('$$tup'(','(7, ','(18, '$$susp'( '$laborable',  [], _GO, _HO )))), :('$$tup'(','(7, ','(19, '$$susp'( '$festivo',  [], _IO, _JO )))), :('$$tup'(','(7, ','(20, '$$susp'( '$festivo',  [], _KO, _LO )))), :('$$tup'(','(7, ','(21, '$$susp'( '$laborable',  [], _MO, _NO )))), :('$$tup'(','(7, ','(22, '$$susp'( '$laborable',  [], _OO, _PO )))), :('$$tup'(','(7, ','(23, '$$susp'( '$laborable',  [], _QO, _RO )))), :('$$tup'(','(7, ','(24, '$$susp'( '$laborable',  [], _SO, _TO )))), :('$$tup'(','(7, ','(25, '$$susp'( '$laborable',  [], _UO, _VO )))), :('$$tup'(','(7, ','(26, '$$susp'( '$festivo',  [], _WO, _XO )))), :('$$tup'(','(7, ','(27, '$$susp'( '$festivo',  [], _YO, _ZO )))), :('$$tup'(','(7, ','(28, '$$susp'( '$laborable',  [], _AP, _BP )))), :('$$tup'(','(7, ','(29, '$$susp'( '$laborable',  [], _CP, _DP )))), :('$$tup'(','(7, ','(30, '$$susp'( '$laborable',  [], _EP, _FP )))), :('$$tup'(','(7, ','(31, '$$susp'( '$laborable',  [], _GP, _HP )))), :('$$tup'(','(8, ','(1, '$$susp'( '$laborable',  [], _IP, _JP )))), :('$$tup'(','(8, ','(2, '$$susp'( '$festivo',  [], _KP, _LP )))), :('$$tup'(','(8, ','(3, '$$susp'( '$laborable',  [], _MP, _NP )))), :('$$tup'(','(8, ','(4, '$$susp'( '$laborable',  [], _OP, _PP )))), :('$$tup'(','(8, ','(5, '$$susp'( '$laborable',  [], _QP, _RP )))), :('$$tup'(','(8, ','(6, '$$susp'( '$laborable',  [], _SP, _TP )))), :('$$tup'(','(8, ','(7, '$$susp'( '$festivo',  [], _UP, _VP )))), :('$$tup'(','(8, ','(8, '$$susp'( '$festivo',  [], _WP, _XP )))), :('$$tup'(','(8, ','(9, '$$susp'( '$laborable',  [], _YP, _ZP )))), :('$$tup'(','(8, ','(10, '$$susp'( '$laborable',  [], _AQ, _BQ )))), :('$$tup'(','(8, ','(11, '$$susp'( '$laborable',  [], _CQ, _DQ )))), :('$$tup'(','(8, ','(12, '$$susp'( '$laborable',  [], _EQ, _FQ )))), :('$$tup'(','(8, ','(13, '$$susp'( '$laborable',  [], _GQ, _HQ )))), :('$$tup'(','(8, ','(14, '$$susp'( '$festivo',  [], _IQ, _JQ )))), :('$$tup'(','(8, ','(15, '$$susp'( '$festivo',  [], _KQ, _LQ )))), :('$$tup'(','(8, ','(16, '$$susp'( '$laborable',  [], _MQ, _NQ )))), :('$$tup'(','(8, ','(17, '$$susp'( '$laborable',  [], _OQ, _PQ )))), :('$$tup'(','(8, ','(18, '$$susp'( '$laborable',  [], _QQ, _RQ )))), :('$$tup'(','(8, ','(19, '$$susp'( '$laborable',  [], _SQ, _TQ )))), :('$$tup'(','(8, ','(20, '$$susp'( '$laborable',  [], _UQ, _VQ )))), :('$$tup'(','(8, ','(21, '$$susp'( '$festivo',  [], _WQ, _XQ )))), :('$$tup'(','(8, ','(22, '$$susp'( '$festivo',  [], _YQ, _ZQ )))), :('$$tup'(','(8, ','(23, '$$susp'( '$laborable',  [], _AR, _BR )))), :('$$tup'(','(8, ','(24, '$$susp'( '$laborable',  [], _CR, _DR )))), :('$$tup'(','(8, ','(25, '$$susp'( '$laborable',  [], _ER, _FR )))), :('$$tup'(','(8, ','(26, '$$susp'( '$laborable',  [], _GR, _HR )))), :('$$tup'(','(8, ','(27, '$$susp'( '$laborable',  [], _IR, _JR )))), :('$$tup'(','(8, ','(28, '$$susp'( '$festivo',  [], _KR, _LR )))), :('$$tup'(','(8, ','(29, '$$susp'( '$festivo',  [], _MR, _NR )))), :('$$tup'(','(8, ','(30, '$$susp'( '$laborable',  [], _OR, _PR )))), :('$$tup'(','(8, ','(31, '$$susp'( '$laborable',  [], _QR, _RR )))), :('$$tup'(','(9, ','(1, '$$susp'( '$laborable',  [], _SR, _TR )))), :('$$tup'(','(9, ','(2, '$$susp'( '$laborable',  [], _UR, _VR )))), :('$$tup'(','(9, ','(3, '$$susp'( '$laborable',  [], _WR, _XR )))), :('$$tup'(','(9, ','(4, '$$susp'( '$festivo',  [], _YR, _ZR )))), :('$$tup'(','(9, ','(5, '$$susp'( '$festivo',  [], _AS, _BS )))), :('$$tup'(','(9, ','(6, '$$susp'( '$laborable',  [], _CS, _DS )))), :('$$tup'(','(9, ','(7, '$$susp'( '$laborable',  [], _ES, _FS )))), :('$$tup'(','(9, ','(8, '$$susp'( '$laborable',  [], _GS, _HS )))), :('$$tup'(','(9, ','(9, '$$susp'( '$laborable',  [], _IS, _JS )))), :('$$tup'(','(9, ','(10, '$$susp'( '$laborable',  [], _KS, _LS )))), :('$$tup'(','(9, ','(11, '$$susp'( '$festivo',  [], _MS, _NS )))), :('$$tup'(','(9, ','(12, '$$susp'( '$festivo',  [], _OS, _PS )))), :('$$tup'(','(9, ','(13, '$$susp'( '$laborable',  [], _QS, _RS )))), :('$$tup'(','(9, ','(14, '$$susp'( '$laborable',  [], _SS, _TS )))), :('$$tup'(','(9, ','(15, '$$susp'( '$laborable',  [], _US, _VS )))), :('$$tup'(','(9, ','(16, '$$susp'( '$laborable',  [], _WS, _XS )))), :('$$tup'(','(9, ','(17, '$$susp'( '$laborable',  [], _YS, _ZS )))), :('$$tup'(','(9, ','(18, '$$susp'( '$festivo',  [], _AT, _BT )))), :('$$tup'(','(9, ','(19, '$$susp'( '$festivo',  [], _CT, _DT )))), :('$$tup'(','(9, ','(20, '$$susp'( '$laborable',  [], _ET, _FT )))), :('$$tup'(','(9, ','(21, '$$susp'( '$laborable',  [], _GT, _HT )))), :('$$tup'(','(9, ','(22, '$$susp'( '$laborable',  [], _IT, _JT )))), :('$$tup'(','(9, ','(23, '$$susp'( '$laborable',  [], _KT, _LT )))), :('$$tup'(','(9, ','(24, '$$susp'( '$laborable',  [], _MT, _NT )))), :('$$tup'(','(9, ','(25, '$$susp'( '$festivo',  [], _OT, _PT )))), :('$$tup'(','(9, ','(26, '$$susp'( '$festivo',  [], _QT, _RT )))), :('$$tup'(','(9, ','(27, '$$susp'( '$laborable',  [], _ST, _TT )))), :('$$tup'(','(9, ','(28, '$$susp'( '$laborable',  [], _UT, _VT )))), :('$$tup'(','(9, ','(29, '$$susp'( '$laborable',  [], _WT, _XT )))), :('$$tup'(','(9, ','(30, '$$susp'( '$laborable',  [], _YT, _ZT )))), :('$$tup'(','(10, ','(1, '$$susp'( '$festivo',  [], _AU, _BU )))), :('$$tup'(','(10, ','(2, '$$susp'( '$laborable',  [], _CU, _DU )))), :('$$tup'(','(10, ','(3, '$$susp'( '$laborable',  [], _EU, _FU )))), :('$$tup'(','(10, ','(4, '$$susp'( '$laborable',  [], _GU, _HU )))), :('$$tup'(','(10, ','(5, '$$susp'( '$laborable',  [], _IU, _JU )))), :('$$tup'(','(10, ','(6, '$$susp'( '$festivo',  [], _KU, _LU )))), :('$$tup'(','(10, ','(7, '$$susp'( '$festivo',  [], _MU, _NU )))), :('$$tup'(','(10, ','(8, '$$susp'( '$laborable',  [], _OU, _PU )))), :('$$tup'(','(10, ','(9, '$$susp'( '$laborable',  [], _QU, _RU )))), :('$$tup'(','(10, ','(10, '$$susp'( '$laborable',  [], _SU, _TU )))), :('$$tup'(','(10, ','(11, '$$susp'( '$laborable',  [], _UU, _VU )))), :('$$tup'(','(10, ','(12, '$$susp'( '$laborable',  [], _WU, _XU )))), :('$$tup'(','(10, ','(13, '$$susp'( '$festivo',  [], _YU, _ZU )))), :('$$tup'(','(10, ','(14, '$$susp'( '$festivo',  [], _AV, _BV )))), :('$$tup'(','(10, ','(15, '$$susp'( '$laborable',  [], _CV, _DV )))), :('$$tup'(','(10, ','(16, '$$susp'( '$laborable',  [], _EV, _FV )))), :('$$tup'(','(10, ','(17, '$$susp'( '$laborable',  [], _GV, _HV )))), :('$$tup'(','(10, ','(18, '$$susp'( '$laborable',  [], _IV, _JV )))), :('$$tup'(','(10, ','(19, '$$susp'( '$laborable',  [], _KV, _LV )))), :('$$tup'(','(10, ','(20, '$$susp'( '$festivo',  [], _MV, _NV )))), :('$$tup'(','(10, ','(21, '$$susp'( '$festivo',  [], _OV, _PV )))), :('$$tup'(','(10, ','(22, '$$susp'( '$laborable',  [], _QV, _RV )))), :('$$tup'(','(10, ','(23, '$$susp'( '$laborable',  [], _SV, _TV )))), :('$$tup'(','(10, ','(24, '$$susp'( '$laborable',  [], _UV, _VV )))), :('$$tup'(','(10, ','(25, '$$susp'( '$laborable',  [], _WV, _XV )))), :('$$tup'(','(10, ','(26, '$$susp'( '$laborable',  [], _YV, _ZV )))), :('$$tup'(','(10, ','(27, '$$susp'( '$festivo',  [], _AW, _BW )))), :('$$tup'(','(10, ','(28, '$$susp'( '$festivo',  [], _CW, _DW )))), :('$$tup'(','(10, ','(29, '$$susp'( '$laborable',  [], _EW, _FW )))), :('$$tup'(','(10, ','(30, '$$susp'( '$laborable',  [], _GW, _HW )))), :('$$tup'(','(10, ','(31, '$$susp'( '$laborable',  [], _IW, _JW )))), :('$$tup'(','(11, ','(1, '$$susp'( '$laborable',  [], _KW, _LW )))), :('$$tup'(','(11, ','(2, '$$susp'( '$laborable',  [], _MW, _NW )))), :('$$tup'(','(11, ','(3, '$$susp'( '$festivo',  [], _OW, _PW )))), :('$$tup'(','(11, ','(4, '$$susp'( '$festivo',  [], _QW, _RW )))), :('$$tup'(','(11, ','(5, '$$susp'( '$laborable',  [], _SW, _TW )))), :('$$tup'(','(11, ','(6, '$$susp'( '$laborable',  [], _UW, _VW )))), :('$$tup'(','(11, ','(7, '$$susp'( '$laborable',  [], _WW, _XW )))), :('$$tup'(','(11, ','(8, '$$susp'( '$laborable',  [], _YW, _ZW )))), :('$$tup'(','(11, ','(9, '$$susp'( '$laborable',  [], _AX, _BX )))), :('$$tup'(','(11, ','(10, '$$susp'( '$festivo',  [], _CX, _DX )))), :('$$tup'(','(11, ','(11, '$$susp'( '$festivo',  [], _EX, _FX )))), :('$$tup'(','(11, ','(12, '$$susp'( '$laborable',  [], _GX, _HX )))), :('$$tup'(','(11, ','(13, '$$susp'( '$laborable',  [], _IX, _JX )))), :('$$tup'(','(11, ','(14, '$$susp'( '$laborable',  [], _KX, _LX )))), :('$$tup'(','(11, ','(15, '$$susp'( '$laborable',  [], _MX, _NX )))), :('$$tup'(','(11, ','(16, '$$susp'( '$laborable',  [], _OX, _PX )))), :('$$tup'(','(11, ','(17, '$$susp'( '$festivo',  [], _QX, _RX )))), :('$$tup'(','(11, ','(18, '$$susp'( '$festivo',  [], _SX, _TX )))), :('$$tup'(','(11, ','(19, '$$susp'( '$laborable',  [], _UX, _VX )))), :('$$tup'(','(11, ','(20, '$$susp'( '$laborable',  [], _WX, _XX )))), :('$$tup'(','(11, ','(21, '$$susp'( '$laborable',  [], _YX, _ZX )))), :('$$tup'(','(11, ','(22, '$$susp'( '$laborable',  [], _AY, _BY )))), :('$$tup'(','(11, ','(23, '$$susp'( '$laborable',  [], _CY, _DY )))), :('$$tup'(','(11, ','(24, '$$susp'( '$festivo',  [], _EY, _FY )))), :('$$tup'(','(11, ','(25, '$$susp'( '$festivo',  [], _GY, _HY )))), :('$$tup'(','(11, ','(26, '$$susp'( '$laborable',  [], _IY, _JY )))), :('$$tup'(','(11, ','(27, '$$susp'( '$laborable',  [], _KY, _LY )))), :('$$tup'(','(11, ','(28, '$$susp'( '$laborable',  [], _MY, _NY )))), :('$$tup'(','(11, ','(29, '$$susp'( '$laborable',  [], _OY, _PY )))), :('$$tup'(','(11, ','(30, '$$susp'( '$festivo',  [], _QY, _RY )))), :('$$tup'(','(12, ','(1, '$$susp'( '$festivo',  [], _SY, _TY )))), :('$$tup'(','(12, ','(2, '$$susp'( '$laborable',  [], _UY, _VY )))), :('$$tup'(','(12, ','(3, '$$susp'( '$laborable',  [], _WY, _XY )))), :('$$tup'(','(12, ','(4, '$$susp'( '$laborable',  [], _YY, _ZY )))), :('$$tup'(','(12, ','(5, '$$susp'( '$laborable',  [], _AZ, _BZ )))), :('$$tup'(','(12, ','(6, '$$susp'( '$festivo',  [], _CZ, _DZ )))), :('$$tup'(','(12, ','(7, '$$susp'( '$festivo',  [], _EZ, _FZ )))), :('$$tup'(','(12, ','(8, '$$susp'( '$laborable',  [], _GZ, _HZ )))), :('$$tup'(','(12, ','(9, '$$susp'( '$laborable',  [], _IZ, _JZ )))), :('$$tup'(','(12, ','(10, '$$susp'( '$laborable',  [], _KZ, _LZ )))), :('$$tup'(','(12, ','(11, '$$susp'( '$laborable',  [], _MZ, _NZ )))), :('$$tup'(','(12, ','(12, '$$susp'( '$laborable',  [], _OZ, _PZ )))), :('$$tup'(','(12, ','(13, '$$susp'( '$festivo',  [], _QZ, _RZ )))), :('$$tup'(','(12, ','(14, '$$susp'( '$festivo',  [], _SZ, _TZ )))), :('$$tup'(','(12, ','(15, '$$susp'( '$laborable',  [], _UZ, _VZ )))), :('$$tup'(','(12, ','(16, '$$susp'( '$laborable',  [], _WZ, _XZ )))), :('$$tup'(','(12, ','(17, '$$susp'( '$laborable',  [], _YZ, _ZZ )))), :('$$tup'(','(12, ','(18, '$$susp'( '$laborable',  [], _AAA, _BAA )))), :('$$tup'(','(12, ','(19, '$$susp'( '$laborable',  [], _CAA, _DAA )))), :('$$tup'(','(12, ','(20, '$$susp'( '$festivo',  [], _EAA, _FAA )))), :('$$tup'(','(12, ','(21, '$$susp'( '$festivo',  [], _GAA, _HAA )))), :('$$tup'(','(12, ','(22, '$$susp'( '$laborable',  [], _IAA, _JAA )))), :('$$tup'(','(12, ','(23, '$$susp'( '$laborable',  [], _KAA, _LAA )))), :('$$tup'(','(12, ','(24, '$$susp'( '$laborable',  [], _MAA, _NAA )))), :('$$tup'(','(12, ','(25, '$$susp'( '$laborable',  [], _OAA, _PAA )))), :('$$tup'(','(12, ','(26, '$$susp'( '$laborable',  [], _QAA, _RAA )))), :('$$tup'(','(12, ','(27, '$$susp'( '$festivo',  [], _SAA, _TAA )))), :('$$tup'(','(12, ','(28, '$$susp'( '$festivo',  [], _UAA, _VAA )))), :('$$tup'(','(12, ','(29, '$$susp'( '$laborable',  [], _WAA, _XAA )))), :('$$tup'(','(12, ','(30, '$$susp'( '$laborable',  [], _YAA, _ZAA )))), :('$$tup'(','(12, ','(31, '$$susp'( '$laborable',  [], _ABA, _BBA )))), []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), _CBA, _CBA).

% laborable
'$laborable'(0, _A, _A).

% festivo
'$festivo'(1, _A, _A).

% especial
'$especial'(2, _A, _A).

% no
'$no'(0, _A, _A).

% t1
'$t1'(1, _A, _A).

% t2
'$t2'(2, _A, _A).

% t3
'$t3'(3, _A, _A).

% t4
'$t4'(4, _A, _A).

% t5
'$t5'(5, _A, _A).

% t6
'$t6'(6, _A, _A).

% bj
'$bj'(7, _A, _A).

% vc
'$vc'(8, _A, _A).

% grupo_activo
'$grupo_activo'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( $<=, [ _A, 4 ], _E, _F ), _A, '$$susp'( '$grupo_activo', [ '$$susp'( $-, [ _A, 4 ], _G, _H ) ], _I, _J ), _B, _C, _D).

% incrementar
'$incrementar'(_A, _B, _C, _D, _E):-
        hnf(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _B, 1 ], _I, _J ), '$$susp'( $++, [ :('$$susp'( $+, [ _F, 1 ], _K, _L ), []), _G ], _M, _N ), '$$susp'( $++, [ :(_F, []), '$$susp'( '$incrementar', [ _G, '$$susp'( $-, [ _B, 1 ], _O, _P ) ], _Q, _R ) ], _S, _T ), _C, _H, _E).

% crear_incidencias
'$crear_incidencias'(_A, _B, _C, _D, _E, _F):-
        hnf(_B, _G, _E, _H),
        '$crear_incidencias_2'(_A, _G, _C, _D, _H, _F).
'$crear_incidencias_2'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_B, [], _D, _E).
'$crear_incidencias_2'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, :(_G, _H), _E, _I),
        '$if_then_else'('$$susp'( '$$eqFun', [ '$$susp'( '$elemento', [ _A, _C ], _J, _K ), '$$susp'( '$grupo_activo', [ _G ], _L, _M ) ], _N, _O ), '$$susp'( $++, [ :(_G, []), '$$susp'( '$crear_incidencias', [ _A, _H, _C ], _P, _Q ) ], _R, _S ), '$$susp'( '$crear_incidencias', [ _A, _H, _C ], _T, _U ), _D, _I, _F).

% proc_incidencia
'$proc_incidencia'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        hnf(_I, ','(_K, _L), _J, _M),
        hnf(_L, ','(_N, _O), _M, _P),
        =(_Q, '$$susp'( '$crear_incidencias', [ _H, '$$susp'( '$deXhastaY', [ _N, _O ], _R, _S ), '$$susp'( '$crear_grupos', [ 12, 3 ], _T, _U ) ], _V, _W )),
        '$foldl'(incrementar, _A, _Q, _C, _P, _E).

% inicio
'$inicio'(_A, [], _B, _C):-
        hnf(_A, 0, _B, _C).
'$inicio'(_A, _B, _C, _D):-
        $>(_A, 0, true, _C, _E),
        $++(:(0, []), '$$susp'( '$inicio', [ '$$susp'( $-, [ _A, 1 ], _F, _G ) ], _H, _I ), _B, _E, _D).

% incidencias_dia
'$incidencias_dia'(_A, _B, _C, _D, _E):-
        '$foldl'(proc_incidencia, _B, _A, _C, _D, _E).

% proc_vacaciones
'$proc_vacaciones'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        hnf(_I, ','(_K, _L), _J, _M),
        hnf(_L, ','(_N, _O), _M, _P),
        '$if_then_else'('$$susp'( '$$eqFun', [ _K, '$$susp'( '$vc',  [], _Q, _R ) ], _S, _T ), '$$susp'( '$foldl', [ incrementar, _A, '$$susp'( '$crear_incidencias', [ _H, '$$susp'( '$deXhastaY', [ _N, _O ], _U, _V ), '$$susp'( '$crear_grupos', [ 12, 3 ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ), _A, _C, _P, _E).

% vacaciones_dia
'$vacaciones_dia'(_A, _B, _C, _D, _E):-
        '$foldl'(proc_vacaciones, _B, _A, _C, _D, _E).

% proc_bajas
'$proc_bajas'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        hnf(_I, ','(_K, _L), _J, _M),
        hnf(_L, ','(_N, _O), _M, _P),
        '$if_then_else'('$$susp'( '$$eqFun', [ _K, '$$susp'( '$bj',  [], _Q, _R ) ], _S, _T ), '$$susp'( '$foldl', [ incrementar, _A, '$$susp'( '$crear_incidencias', [ _H, '$$susp'( '$deXhastaY', [ _N, _O ], _U, _V ), '$$susp'( '$crear_grupos', [ 12, 3 ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ), _A, _C, _P, _E).

% bajas_dia
'$bajas_dia'(_A, _B, _C, _D, _E):-
        '$foldl'(proc_bajas, _B, _A, _C, _D, _E).

% crear_grupos
'$crear_grupos'(_A, _B, [], _C, _D):-
        hnf(_A, 0, _C, _D).
'$crear_grupos'(_A, _B, _C, _D, _E):-
        $>(_A, 0, true, _D, _F),
        $++('$$susp'( '$crear_grupos', [ '$$susp'( $-, [ _A, 1 ], _G, _H ), _B ], _I, _J ), :('$$susp'( $+, [ '$$susp'( '$div\'', [ '$$susp'( $-, [ _A, 1 ], _K, _L ), _B ], _M, _N ), 1 ], _O, _P ), []), _C, _F, _E).

% solicitaNoche
'$solicitaNoche'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$solicitaNoche_1'(_F, _B, _C, _G, _E).
'$solicitaNoche_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _E),
        hnf(_B, [], _E, _D).
'$solicitaNoche_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        hnf(_F, '$$tup'(_I), _H, _J),
        hnf(_I, ','(_K, _L), _J, _M),
        hnf(_L, ','(_N, _O), _M, _P),
        hnf(_B, _Q, _P, _R),
        '$solicitaNoche_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,'(_K, _N, _O, _G, _Q, _C, _R, _E).
'$solicitaNoche_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_E, :(_I, _J), _G, _K),
        $>(_I, 0, true, _K, _L),
        equal(_C, '$$susp'( '$laborable',  [], _M, _N ), _L, _O),
        $++(:(true, []), '$$susp'( '$solicitaNoche', [ _D, _J ], _P, _Q ), _F, _O, _H).
'$solicitaNoche_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_E, :(_I, _J), _G, _K),
        equal(_I, 0, _K, _L),
        $++(:(false, []), '$$susp'( '$solicitaNoche', [ _D, _J ], _M, _N ), _F, _L, _H).
'$solicitaNoche_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_E, :(_I, _J), _G, _K),
        $>(_I, 0, true, _K, _L),
        equal(_C, '$$susp'( '$festivo',  [], _M, _N ), _L, _O),
        $++(:(false, []), '$$susp'( '$solicitaNoche', [ _D, _J ], _P, _Q ), _F, _O, _H).

% puedeNoche
'$puedeNoche'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$puedeNoche_1'(_E, _B, _F, _D).
'$puedeNoche_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$puedeNoche_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$puedeNoche_1_1.2_:'(_E, _H, _B, _I, _D).
'$puedeNoche_1_1.2_:'(_A, _B, :(_A, []), _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$puedeNoche_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        hnf(_G, _I, _H, _J),
        '$puedeNoche_1_1.2_:_1.2.2_:'(_A, _F, _I, _C, _J, _E).
'$puedeNoche_1_1.2_:_1.2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, false ], _H, _I ), :(false, :(_B, [])), :(true, :(false, [])), _D, _G, _F).
'$puedeNoche_1_1.2_:_1.2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, false ], _J, _K ), '$$susp'( $++, [ :(false, []), '$$susp'( '$puedeNoche', [ :(_B, :(_G, _H)) ], _L, _M ) ], _N, _O ), '$$susp'( $++, [ :(true, :(false, :(false, []))), '$$susp'( '$puedeNoche', [ _H ], _P, _Q ) ], _R, _S ), _D, _I, _F).

% t13trabaja_noche
'$t13trabaja_noche'(_A, _B, _C, _D, _E):-
        '$puedeNoche'('$$susp'( '$solicitaNoche', [ _A, _B ], _F, _G ), _C, _D, _E).

% j1
'$j1'(1, _A, _A).

% j2
'$j2'(2, _A, _A).

% j3
'$j3'(3, _A, _A).

% j4
'$j4'(4, _A, _A).

% crear_plan_jornadas
'$crear_plan_jornadas'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, _G, _E, _H),
        '$crear_plan_jornadas_1'(_G, _B, _C, _D, _H, _F).
'$crear_plan_jornadas_1'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, [], _F, _G),
        hnf(_C, [], _G, _E).
'$crear_plan_jornadas_1'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, :(_G, _H), _E, _I),
        hnf(_G, '$$tup'(_J), _I, _K),
        hnf(_J, ','(_L, _M), _K, _N),
        hnf(_M, ','(_O, _P), _N, _Q),
        hnf(_B, :(_R, _S), _Q, _T),
        hnf(_C, _U, _T, _V),
        '$crear_plan_jornadas_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,_3_:'(_L, _O, _P, _H, _R, _S, _U, _D, _V, _F).
'$crear_plan_jornadas_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,_3_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_G, :(_K, _L), _I, _M),
        equal(_C, '$$susp'( '$festivo',  [], _N, _O ), _M, _P),
        $++(:('$$susp'( '$j3',  [], _Q, _R ), []), '$$susp'( '$crear_plan_jornadas', [ _D, _F, _L ], _S, _T ), _H, _P, _J).
'$crear_plan_jornadas_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,_3_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_G, :(_K, _L), _I, _M),
        equal(_C, '$$susp'( '$laborable',  [], _N, _O ), _M, _P),
        $>(_E, 0, true, _P, _Q),
        equal(_K, true, _Q, _R),
        $++(:('$$susp'( '$j1',  [], _S, _T ), []), '$$susp'( '$crear_plan_jornadas', [ _D, _F, _L ], _U, _V ), _H, _R, _J).
'$crear_plan_jornadas_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,_3_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_G, :(_K, _L), _I, _M),
        equal(_C, '$$susp'( '$laborable',  [], _N, _O ), _M, _P),
        $>(_E, 0, true, _P, _Q),
        equal(_K, false, _Q, _R),
        $++(:('$$susp'( '$j2',  [], _S, _T ), []), '$$susp'( '$crear_plan_jornadas', [ _D, _F, _L ], _U, _V ), _H, _R, _J).
'$crear_plan_jornadas_1_1.1_:_1.1.1_$$tup_1.1.1.2_,_2_,_3_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_G, :(_K, _L), _I, _M),
        equal(_C, '$$susp'( '$laborable',  [], _N, _O ), _M, _P),
        equal(_E, 0, _P, _Q),
        $++(:('$$susp'( '$j1',  [], _R, _S ), []), '$$susp'( '$crear_plan_jornadas', [ _D, _F, _L ], _T, _U ), _H, _Q, _J).

% crear_trabajo
'$crear_trabajo'(_A, [], _B, _C):-
        hnf(_A, 0, _B, _C).
'$crear_trabajo'(_A, _B, _C, _D):-
        $>(_A, 0, true, _C, _E),
        $++(:(_F, []), '$$susp'( '$crear_trabajo', [ '$$susp'( $-, [ _A, 1 ], _G, _H ) ], _I, _J ), _B, _E, _D).

% crear_planificacion
'$crear_planificacion'(_A, _B, [], _C, _D):-
        hnf(_A, 0, _C, _D).
'$crear_planificacion'(_A, _B, _C, _D, _E):-
        $>(_A, 0, true, _D, _F),
        $++(:('$$susp'( '$crear_trabajo', [ _B ], _G, _H ), []), '$$susp'( '$crear_planificacion', [ '$$susp'( $-, [ _A, 1 ], _I, _J ), _B ], _K, _L ), _C, _F, _E).

% borrar_uno
'$borrar_uno'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _B, _G, _D).

% quitar_primeros
'$quitar_primeros'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$quitar_primeros_1'(_E, _B, _F, _D).
'$quitar_primeros_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$quitar_primeros_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $++(:('$$susp'( '$borrar_uno', [ _E ], _H, _I ), []), '$$susp'( '$quitar_primeros', [ _F ], _J, _K ), _B, _G, _D).

% prim
'$prim'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_E, _B, _G, _D).

% primeros
'$primeros'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$primeros_1'(_E, _B, _F, _D).
'$primeros_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$primeros_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $++(:('$$susp'( '$prim', [ _E ], _H, _I ), []), '$$susp'( '$primeros', [ _F ], _J, _K ), _B, _G, _D).

% listas_vacias
'$listas_vacias'(_A, true, _B, _C):-
        hnf(_A, _D, _B, _E),
        '$listas_vacias_1'(_D, true, _E, _C).
'$listas_vacias_1'(_A, true, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$listas_vacias_1'(_A, true, _B, _C):-
        unifyHnfs(_A, :(_D, _E), _B, _F),
        equal(_D, [], _F, _G),
        '$listas_vacias'(_E, true, _G, _C).

% transponer
'$transponer'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        notEqual(_E, [], _G, _H),
        $++(:('$$susp'( '$primeros', [ :(_E, _F) ], _I, _J ), []), '$$susp'( '$transponer', [ '$$susp'( '$quitar_primeros', [ :(_E, _F) ], _K, _L ) ], _M, _N ), _B, _H, _D).
'$transponer'(_A, [], _B, _C):-
        '$listas_vacias'(_A, true, _B, _C).

% crear_fila
'$crear_fila'(_A, [], _B, _C):-
        hnf(_A, 0, _B, _C).
'$crear_fila'(_A, _B, _C, _D):-
        $>(_A, 0, true, _C, _E),
        $++(:(0, []), '$$susp'( '$crear_fila', [ '$$susp'( $-, [ _A, 1 ], _F, _G ) ], _H, _I ), _B, _E, _D).

% crear_tabla
'$crear_tabla'(_A, _B, [], _C, _D):-
        hnf(_A, 0, _C, _D).
'$crear_tabla'(_A, _B, _C, _D, _E):-
        $>(_A, 0, true, _D, _F),
        $++(:('$$susp'( '$crear_fila', [ _B ], _G, _H ), []), '$$susp'( '$crear_tabla', [ '$$susp'( $-, [ _A, 1 ], _I, _J ), _B ], _K, _L ), _C, _F, _E).

% anotar_en_trabajador
'$anotar_en_trabajador'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        hnf(_I, ','(_K, _L), _J, _M),
        hnf(_L, _N, _M, _O),
        '$anotar_en_trabajador_2_2.1_$$tup_2.1.2_,_2.1.2.2_,'(_A, _H, _K, _N, _C, _O, _E).
'$anotar_en_trabajador_2_2.1_$$tup_2.1.2_,_2.1.2.2_,'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, ','(_H, _I), _F, _J),
        hnf(_A, _K, _J, _L),
        '$anotar_en_trabajador_2_2.1_$$tup_2.1.2_,_2.1.2.2_,_1_,'(_K, _B, _C, _H, _I, _E, _L, _G).
'$anotar_en_trabajador_2_2.1_$$tup_2.1.2_,_2.1.2.2_,'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, ','(_H, _I), _F, _J),
        $<(_I, _H, true, _J, _K),
        hnf(_A, _E, _K, _G).
'$anotar_en_trabajador_2_2.1_$$tup_2.1.2_,_2.1.2.2_,_1_,'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, :(_I, _J), _G, _K),
        $>=(_E, _D, true, _K, _L),
        equal(_D, 1, _L, _M),
        $++(:(_C, []), '$$susp'( '$anotar_en_trabajador', [ _J, '$$tup'(','(_B, ','(_C, ','(_D, '$$susp'( $-, [ _E, 1 ], _N, _O ))))) ], _P, _Q ), _F, _M, _H).
'$anotar_en_trabajador_2_2.1_$$tup_2.1.2_,_2.1.2.2_,_1_,'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, :(_I, _J), _G, _K),
        $>=(_E, _D, true, _K, _L),
        notEqual(_D, 1, _L, _M),
        $++(:(_I, []), '$$susp'( '$anotar_en_trabajador', [ _J, '$$tup'(','(_B, ','(_C, ','('$$susp'( $-, [ _D, 1 ], _N, _O ), '$$susp'( $-, [ _E, 1 ], _P, _Q ))))) ], _R, _S ), _F, _M, _H).

% anotar_una
'$anotar_una'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        hnf(_I, ','(_K, _L), _J, _M),
        hnf(_L, ','(_N, _O), _M, _P),
        =(_Q, '$$susp'( '$anotar_en_trabajador', [ '$$susp'( '$elemento', [ _H, _A ], _R, _S ), '$$tup'(','(_H, ','(_K, ','(_N, _O)))) ], _T, _U )),
        '$sustituir'(_A, _H, _Q, _C, _P, _E).

% anotar_incidencias
'$anotar_incidencias'(_A, _B, _C, _D, _E):-
        '$foldl'(anotar_una, _A, _B, _C, _D, _E).

% procesar_jornadas
'$procesar_jornadas'(_A, _B, _C, _D, _E, _F, true, _G, _H):-
        hnf(_A, _I, _G, _J),
        '$procesar_jornadas_1'(_I, _B, _C, _D, _E, _F, true, _J, _H).
'$procesar_jornadas_1'(_A, _B, _C, _D, _E, _F, true, _G, _H):-
        unifyHnfs(_A, [], _G, _I),
        hnf(_B, [], _I, _J),
        hnf(_C, [], _J, _K),
        hnf(_D, [], _K, _H).
'$procesar_jornadas_1'(_A, _B, _C, _D, _E, _F, true, _G, _H):-
        unifyHnfs(_A, :(_I, _J), _G, _K),
        hnf(_B, :(_L, _M), _K, _N),
        hnf(_C, :(_O, _P), _N, _Q),
        hnf(_O, '$$tup'(_R), _Q, _S),
        hnf(_R, ','(_T, _U), _S, _V),
        hnf(_U, ','(_W, _X), _V, _Y),
        hnf(_D, _Z, _Y, _AA),
        '$procesar_jornadas_1_2_:_3_:_3.1_:_3.1.1_$$tup_3.1.1.2_,_4_,'(_I, _J, _L, _M, _T, _W, _X, _P, _Z, _E, _F, true, _AA, _H).
'$procesar_jornadas_1_2_:_3_:_3.1_:_3.1.1_$$tup_3.1.1.2_,_4_,'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, true, _L, _M):-
        unifyHnfs(_I, :(_N, _O), _L, _P),
        $#=(_A, '$$susp'( '$j3',  [], _Q, _R ), true, _P, _S),
        equal(_G, '$$susp'( '$festivo',  [], _T, _U ), _S, _V),
        '$procesar_jornadas'(_B, _D, _H, _O, _K, _C, true, _V, _M).
'$procesar_jornadas_1_2_:_3_:_3.1_:_3.1.1_$$tup_3.1.1.2_,_4_,'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, true, _L, _M):-
        unifyHnfs(_I, :(_N, _O), _L, _P),
        $#=(_A, '$$susp'( '$j2',  [], _Q, _R ), true, _P, _S),
        equal(_G, '$$susp'( '$laborable',  [], _T, _U ), _S, _V),
        $>(_N, 0, true, _V, _W),
        '$esNocturno'(_J, true, _W, _X),
        '$procesar_jornadas'(_B, _D, _H, _O, _K, _A, true, _X, _M).
'$procesar_jornadas_1_2_:_3_:_3.1_:_3.1.1_$$tup_3.1.1.2_,_4_,'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, true, _L, _M):-
        unifyHnfs(_I, :(_N, _O), _L, _P),
        $#=(_A, '$$susp'( '$j2',  [], _Q, _R ), true, _P, _S),
        equal(_G, '$$susp'( '$laborable',  [], _T, _U ), _S, _V),
        $>(_N, 0, true, _V, _W),
        '$esNocturno'(_J, false, _W, _X),
        '$esNocturno'(_K, true, _X, _Y),
        '$procesar_jornadas'(_B, _D, _H, _O, _K, _C, true, _Y, _M).
'$procesar_jornadas_1_2_:_3_:_3.1_:_3.1.1_$$tup_3.1.1.2_,_4_,'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, true, _L, _M):-
        unifyHnfs(_I, :(_N, _O), _L, _P),
        $#=(_A, '$$susp'( '$j1',  [], _Q, _R ), true, _P, _S),
        equal(_G, '$$susp'( '$laborable',  [], _T, _U ), _S, _V),
        equal(_N, 0, _V, _W),
        '$procesar_jornadas'(_B, _D, _H, _O, _K, _C, true, _W, _M).
'$procesar_jornadas_1_2_:_3_:_3.1_:_3.1.1_$$tup_3.1.1.2_,_4_,'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, true, _L, _M):-
        unifyHnfs(_I, :(_N, _O), _L, _P),
        $#=(_A, '$$susp'( '$j1',  [], _Q, _R ), true, _P, _S),
        equal(_G, '$$susp'( '$laborable',  [], _T, _U ), _S, _V),
        $>(_N, 0, true, _V, _W),
        '$esNocturno'(_J, false, _W, _X),
        '$esNocturno'(_K, false, _X, _Y),
        '$procesar_jornadas'(_B, _D, _H, _O, _K, _C, true, _Y, _M).
'$procesar_jornadas_1_2_:_3_:_3.1_:_3.1.1_$$tup_3.1.1.2_,_4_,'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, true, _L, _M):-
        unifyHnfs(_I, :(_N, _O), _L, _P),
        $#=(_A, '$$susp'( '$j4',  [], _Q, _R ), true, _P, _S),
        equal(_G, '$$susp'( '$especial',  [], _T, _U ), _S, _V),
        '$procesar_jornadas'(_B, _D, _H, _O, _K, _C, true, _V, _M).

% contar
'$contar'(_A, _B, _C, _D, _E):-
        '$exactly'(_A, _B, _F, true, _D, _G),
        hnf(_F, _C, _G, _E).

% empaquetar
'$empaquetar'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$empaquetar_1'(_F, _B, _C, _G, _E).
'$empaquetar_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _E),
        hnf(_B, [], _E, _D).
'$empaquetar_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        hnf(_B, :(_I, _J), _H, _K),
        $++(:('$$tup'(','(_F, _I)), []), '$$susp'( '$empaquetar', [ _G, _J ], _L, _M ), _C, _K, _E).

% proyectar
'$proyectar'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$proyectar_1'(_E, _B, _F, _D).
'$proyectar_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$proyectar_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        $++(:(_J, []), '$$susp'( '$proyectar', [ _F ], _M, _N ), _B, _L, _D).

% anotar_trab
'$anotar_trab'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$anotar_trab_1'(_E, _B, _F, _D).
'$anotar_trab_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$anotar_trab_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, _J, _I, _K),
        '$anotar_trab_1_1.1_:_1.1.1_$$tup'(_J, _F, _B, _K, _D).
'$anotar_trab_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        equal(_G, 0, _H, _I),
        $++(:(_F, []), '$$susp'( '$anotar_trab', [ _B ], _J, _K ), _C, _I, _E).
'$anotar_trab_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        notEqual(_G, 0, _H, _I),
        $++(:(_G, []), '$$susp'( '$anotar_trab', [ _B ], _J, _K ), _C, _I, _E).

% anotar_desc
'$anotar_desc'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$anotar_desc_1'(_E, _B, _F, _D).
'$anotar_desc_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$anotar_desc_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, _J, _I, _K),
        '$anotar_desc_1_1.1_:_1.1.1_$$tup'(_J, _F, _B, _K, _D).
'$anotar_desc_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        equal(_G, 0, _H, _I),
        $++(:(0, []), '$$susp'( '$anotar_desc', [ _B ], _J, _K ), _C, _I, _E).
'$anotar_desc_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        notEqual(_G, 0, _H, _I),
        $++(:(_G, []), '$$susp'( '$anotar_desc', [ _B ], _J, _K ), _C, _I, _E).

% descansar
'$descansar'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_A, _H, _F, _I),
        '$descansar_1'(_H, _B, _C, _D, _E, _I, _G).
'$descansar_1'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_A, [], _E, _F).
'$descansar_1'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_A, :(_H, _I), _F, _J),
        '$if_then_else'('$$susp'( '$$eqFun', [ '$$susp'( '$grupo', [ _B ], _K, _L ), '$$susp'( '$grupo_activo', [ _C ], _M, _N ) ], _O, _P ), '$$susp'( '$descansar', [ _I, '$$susp'( $+, [ _B, 1 ], _Q, _R ), _C, _D ], _S, _T ), '$$susp'( $++, [ :(_H, []), '$$susp'( '$descansar', [ _I, '$$susp'( $+, [ _B, 1 ], _U, _V ), _C, _D ], _W, _X ) ], _Y, _Z ), _E, _J, _G).

% trabajar
'$trabajar'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_A, _H, _F, _I),
        '$trabajar_1'(_H, _B, _C, _D, _E, _I, _G).
'$trabajar_1'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_A, [], _E, _F).
'$trabajar_1'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_A, :(_H, _I), _F, _J),
        '$if_then_else'('$$susp'( '$$eqFun', [ '$$susp'( '$grupo', [ _B ], _K, _L ), '$$susp'( '$grupo_activo', [ _C ], _M, _N ) ], _O, _P ), '$$susp'( $++, [ :(_H, []), '$$susp'( '$trabajar', [ _I, '$$susp'( $+, [ _B, 1 ], _Q, _R ), _C, _D ], _S, _T ) ], _U, _V ), '$$susp'( '$trabajar', [ _I, '$$susp'( $+, [ _B, 1 ], _W, _X ), _C, _D ], _Y, _Z ), _E, _J, _G).

% grupo
'$grupo'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$grupo_1'(_E, _B, _F, _D).
'$grupo_1'(_A, 1, _B, _C):-
        unifyHnfs(_A, 1, _B, _C).
'$grupo_1'(_A, 1, _B, _C):-
        unifyHnfs(_A, 2, _B, _C).
'$grupo_1'(_A, 1, _B, _C):-
        unifyHnfs(_A, 3, _B, _C).
'$grupo_1'(_A, 2, _B, _C):-
        unifyHnfs(_A, 4, _B, _C).
'$grupo_1'(_A, 2, _B, _C):-
        unifyHnfs(_A, 5, _B, _C).
'$grupo_1'(_A, 2, _B, _C):-
        unifyHnfs(_A, 6, _B, _C).
'$grupo_1'(_A, 3, _B, _C):-
        unifyHnfs(_A, 7, _B, _C).
'$grupo_1'(_A, 3, _B, _C):-
        unifyHnfs(_A, 8, _B, _C).
'$grupo_1'(_A, 3, _B, _C):-
        unifyHnfs(_A, 9, _B, _C).
'$grupo_1'(_A, 4, _B, _C):-
        unifyHnfs(_A, 10, _B, _C).
'$grupo_1'(_A, 4, _B, _C):-
        unifyHnfs(_A, 11, _B, _C).
'$grupo_1'(_A, 4, _B, _C):-
        unifyHnfs(_A, 12, _B, _C).

% procesar_tipo_dia
'$procesar_tipo_dia'(_A, _B, _C, _D, _E, _F, _G):-
        $#=(_B, '$$susp'( '$j1',  [], _H, _I ), true, _F, _J),
        equal('$$susp'( '$contar', [ '$$susp'( '$t1',  [], _K, _L ), _A ], _M, _N ), 1, _J, _O),
        equal('$$susp'( '$contar', [ '$$susp'( '$t2',  [], _P, _Q ), _A ], _R, _S ), 1, _O, _T),
        equal('$$susp'( '$contar', [ '$$susp'( '$t3',  [], _U, _V ), _A ], _W, _X ), 1, _T, _Y),
        equal('$$susp'( '$contar', [ '$$susp'( '$t4',  [], _Z, _AA ), _A ], _BA, _CA ), 0, _Y, _DA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t5',  [], _EA, _FA ), _A ], _GA, _HA ), 0, _DA, _IA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t6',  [], _JA, _KA ), _A ], _LA, _MA ), 1, _IA, _NA),
        equal('$$susp'( '$contar', [ '$$susp'( '$bj',  [], _OA, _PA ), _A ], _QA, _RA ), _D, _NA, _SA),
        equal('$$susp'( '$contar', [ '$$susp'( '$vc',  [], _TA, _UA ), _A ], _VA, _WA ), _C, _SA, _XA),
        hnf(_A, _E, _XA, _G).
'$procesar_tipo_dia'(_A, _B, _C, _D, _E, _F, _G):-
        $#=(_B, '$$susp'( '$j3',  [], _H, _I ), true, _F, _J),
        equal('$$susp'( '$contar', [ '$$susp'( '$t1',  [], _K, _L ), _A ], _M, _N ), 2, _J, _O),
        equal('$$susp'( '$contar', [ '$$susp'( '$t2',  [], _P, _Q ), _A ], _R, _S ), 0, _O, _T),
        equal('$$susp'( '$contar', [ '$$susp'( '$t3',  [], _U, _V ), _A ], _W, _X ), 0, _T, _Y),
        equal('$$susp'( '$contar', [ '$$susp'( '$t4',  [], _Z, _AA ), _A ], _BA, _CA ), 0, _Y, _DA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t5',  [], _EA, _FA ), _A ], _GA, _HA ), 0, _DA, _IA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t6',  [], _JA, _KA ), _A ], _LA, _MA ), 0, _IA, _NA),
        equal('$$susp'( '$contar', [ '$$susp'( '$bj',  [], _OA, _PA ), _A ], _QA, _RA ), _D, _NA, _SA),
        equal('$$susp'( '$contar', [ '$$susp'( '$vc',  [], _TA, _UA ), _A ], _VA, _WA ), _C, _SA, _XA),
        hnf(_A, _E, _XA, _G).
'$procesar_tipo_dia'(_A, _B, _C, _D, _E, _F, _G):-
        $#=(_B, '$$susp'( '$j4',  [], _H, _I ), true, _F, _J),
        equal('$$susp'( '$contar', [ '$$susp'( '$t1',  [], _K, _L ), _A ], _M, _N ), 0, _J, _O),
        equal('$$susp'( '$contar', [ '$$susp'( '$t2',  [], _P, _Q ), _A ], _R, _S ), 0, _O, _T),
        equal('$$susp'( '$contar', [ '$$susp'( '$t3',  [], _U, _V ), _A ], _W, _X ), 0, _T, _Y),
        equal('$$susp'( '$contar', [ '$$susp'( '$t4',  [], _Z, _AA ), _A ], _BA, _CA ), 0, _Y, _DA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t5',  [], _EA, _FA ), _A ], _GA, _HA ), 2, _DA, _IA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t6',  [], _JA, _KA ), _A ], _LA, _MA ), 0, _IA, _NA),
        equal('$$susp'( '$contar', [ '$$susp'( '$bj',  [], _OA, _PA ), _A ], _QA, _RA ), _D, _NA, _SA),
        equal('$$susp'( '$contar', [ '$$susp'( '$vc',  [], _TA, _UA ), _A ], _VA, _WA ), _C, _SA, _XA),
        hnf(_A, _E, _XA, _G).
'$procesar_tipo_dia'(_A, _B, _C, _D, _E, _F, _G):-
        $#=(_B, '$$susp'( '$j2',  [], _H, _I ), true, _F, _J),
        equal('$$susp'( '$contar', [ '$$susp'( '$t1',  [], _K, _L ), _A ], _M, _N ), 1, _J, _O),
        equal('$$susp'( '$contar', [ '$$susp'( '$t2',  [], _P, _Q ), _A ], _R, _S ), 0, _O, _T),
        equal('$$susp'( '$contar', [ '$$susp'( '$t3',  [], _U, _V ), _A ], _W, _X ), 0, _T, _Y),
        equal('$$susp'( '$contar', [ '$$susp'( '$t4',  [], _Z, _AA ), _A ], _BA, _CA ), 1, _Y, _DA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t5',  [], _EA, _FA ), _A ], _GA, _HA ), 0, _DA, _IA),
        equal('$$susp'( '$contar', [ '$$susp'( '$t6',  [], _JA, _KA ), _A ], _LA, _MA ), 0, _IA, _NA),
        equal('$$susp'( '$contar', [ '$$susp'( '$bj',  [], _OA, _PA ), _A ], _QA, _RA ), _D, _NA, _SA),
        equal('$$susp'( '$contar', [ '$$susp'( '$vc',  [], _TA, _UA ), _A ], _VA, _WA ), _C, _SA, _XA),
        hnf(_A, _E, _XA, _G).

% procesar_dia
'$procesar_dia'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        equalnf(_K, '$$susp'( '$empaquetar', [ _B, _A ], _L, _M ), _I, _N),
        equalnf(_O, '$$susp'( '$ultimo', [ _K ], _P, _Q ), _N, _R),
        equalnf(_S, '$$susp'( '$n_menos_1', [ _K ], _T, _U ), _R, _V),
        equalnf(_W, '$$susp'( $++, [ '$$susp'( '$trabajar', [ _S, 1, _C, _D ], _X, _Y ), :(_O, []) ], _Z, _AA ), _V, _BA),
        equalnf(_CA, '$$susp'( '$anotar_trab', [ _W ], _DA, _EA ), _BA, _FA),
        equal('$$susp'( '$proyectar', [ _W ], _GA, _HA ), '$$susp'( '$procesar_tipo_dia', [ _CA, _E, _F, _G ], _IA, _JA ), _FA, _KA),
        equalnf(_LA, '$$susp'( '$descansar', [ _S, 1, _C, _D ], _MA, _NA ), _KA, _OA),
        equal('$$susp'( '$proyectar', [ _LA ], _PA, _QA ), '$$susp'( '$anotar_desc', [ _LA ], _RA, _SA ), _OA, _TA),
        hnf(_B, _H, _TA, _J).

% procesar_trabajo
'$procesar_trabajo'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        hnf(_A, _K, _I, _L),
        '$procesar_trabajo_1'(_K, _B, _C, _D, _E, _F, _G, _H, _L, _J).
'$procesar_trabajo_1'(_A, _B, _C, _D, _E, _F, _G, [], _H, _I):-
        unifyHnfs(_A, [], _H, _J),
        hnf(_B, [], _J, _I).
'$procesar_trabajo_1'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_A, :(_K, _L), _I, _M),
        hnf(_B, :(_N, _O), _M, _P),
        hnf(_E, :(_Q, _R), _P, _S),
        hnf(_F, :(_T, _U), _S, _V),
        hnf(_G, :(_W, _X), _V, _Y),
        $++(:('$$susp'( '$procesar_dia', [ _K, _N, _C, _D, _Q, _T, _W ], _Z, _AA ), []), '$$susp'( '$procesar_trabajo', [ _L, _O, '$$susp'( $+, [ _C, 1 ], _BA, _CA ), _D, _R, _U, _X ], _DA, _EA ), _H, _Y, _J).

% trab_comodin
'$trab_comodin'(_A, _B, _C, _D, _E, _F, _G):-
        equal(_B, '$$susp'( '$laborable',  [], _H, _I ), _F, _J),
        equal(_D, 0, _J, _K),
        $#=(_A, '$$susp'( '$t6',  [], _L, _M ), true, _K, _N),
        hnf(_A, _E, _N, _G).
'$trab_comodin'(_A, _B, _C, _D, _E, _F, _G):-
        equal(_B, '$$susp'( '$laborable',  [], _H, _I ), _F, _J),
        $>(_D, 0, true, _J, _K),
        $#=(_C, '$$susp'( '$j1',  [], _L, _M ), true, _K, _N),
        $#\=(_A, '$$susp'( '$t6',  [], _O, _P ), true, _N, _Q),
        hnf(_A, _E, _Q, _G).
'$trab_comodin'(_A, _B, _C, _D, _E, _F, _G):-
        equal(_B, '$$susp'( '$laborable',  [], _H, _I ), _F, _J),
        $>(_D, 0, true, _J, _K),
        $#=(_C, '$$susp'( '$j2',  [], _L, _M ), true, _K, _N),
        $#=(_A, '$$susp'( '$no',  [], _O, _P ), true, _N, _Q),
        hnf(_A, _E, _Q, _G).
'$trab_comodin'(_A, _B, _C, _D, _E, _F, _G):-
        equal(_B, '$$susp'( '$festivo',  [], _H, _I ), _F, _J),
        $#=(_A, '$$susp'( '$no',  [], _K, _L ), true, _J, _M),
        hnf(_A, _E, _M, _G).
'$trab_comodin'(_A, _B, _C, _D, _E, _F, _G):-
        equal(_B, '$$susp'( '$especial',  [], _H, _I ), _F, _J),
        $#=(_A, '$$susp'( '$no',  [], _K, _L ), true, _J, _M),
        hnf(_A, _E, _M, _G).

% trabajar_comodin
'$trabajar_comodin'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_A, _H, _F, _I),
        '$trabajar_comodin_1'(_H, _B, _C, _D, _E, _I, _G).
'$trabajar_comodin_1'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_A, [], _E, _G),
        hnf(_B, [], _G, _H),
        hnf(_C, [], _H, _I),
        hnf(_D, [], _I, _F).
'$trabajar_comodin_1'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_A, :(_H, _I), _F, _J),
        hnf(_B, :(_K, _L), _J, _M),
        hnf(_K, '$$tup'(_N), _M, _O),
        hnf(_N, ','(_P, _Q), _O, _R),
        hnf(_Q, ','(_S, _T), _R, _U),
        hnf(_C, :(_V, _W), _U, _X),
        hnf(_D, :(_Y, _Z), _X, _AA),
        $++(:('$$susp'( '$trab_comodin', [ _H, _T, _V, _Y ], _BA, _CA ), []), '$$susp'( '$trabajar_comodin', [ _I, _L, _W, _Z ], _DA, _EA ), _E, _AA, _G).

% proc_t6
'$proc_t6'(_A, _B, _C, _D):-
        $#\=(_A, '$$susp'( '$t6',  [], _E, _F ), true, _C, _G),
        hnf(_A, _B, _G, _D).

% sin_t6
'$sin_t6'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$sin_t6_1'(_E, _B, _F, _D).
'$sin_t6_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$sin_t6_1'(_A, :('$$susp'( '$proc_t6', [ _B ], _C, _D ), '$$susp'( '$sin_t6', [ _E ], _F, _G )), _H, _I):-
        unifyHnfs(_A, :(_B, _E), _H, _I).

% no_t6
'$no_t6'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$no_t6_1'(_E, _B, _F, _D).
'$no_t6_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$no_t6_1'(_A, :('$$susp'( '$sin_t6', [ _B ], _C, _D ), '$$susp'( '$no_t6', [ _E ], _F, _G )), _H, _I):-
        unifyHnfs(_A, :(_B, _E), _H, _I).

% valido_laborables
'$valido_laborables'(_A, true, _B, _C):-
        hnf(_A, _D, _B, _E),
        '$valido_laborables_1'(_D, true, _E, _C).
'$valido_laborables_1'(_A, true, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$valido_laborables_1'(_A, true, _B, _C):-
        unifyHnfs(_A, :(_D, _E), _B, _F),
        hnf(_E, _G, _F, _H),
        '$valido_laborables_1_1.2_:'(_D, _G, true, _H, _C).
'$valido_laborables_1_1.2_:'(_A, _B, true, _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$valido_laborables_1_1.2_:'(_A, _B, true, _C, _D):-
        unifyHnfs(_B, :(_E, _F), _C, _G),
        $#\=(_E, _A, true, _G, _H),
        '$valido_laborables'(:(_E, _F), true, _H, _D).

% valido_festivos
'$valido_festivos'(_A, true, _B, _C):-
        hnf(_A, _D, _B, _E),
        '$valido_festivos_1'(_D, true, _E, _C).
'$valido_festivos_1'(_A, true, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$valido_festivos_1'(_A, true, _B, _C):-
        unifyHnfs(_A, :(_D, _E), _B, _F),
        hnf(_E, _G, _F, _H),
        '$valido_festivos_1_1.2_:'(_D, _G, true, _H, _C).
'$valido_festivos_1_1.2_:'(_A, _B, true, _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$valido_festivos_1_1.2_:'(_A, _B, true, _C, _D):-
        unifyHnfs(_B, :(_E, _F), _C, _G),
        $#=(_A, '$$susp'( '$no',  [], _H, _I ), true, _G, _J),
        $#=(_E, '$$susp'( '$t1',  [], _K, _L ), true, _J, _M),
        '$valido_festivos'(:(_E, _F), true, _M, _D).
'$valido_festivos_1_1.2_:'(_A, _B, true, _C, _D):-
        unifyHnfs(_B, :(_E, _F), _C, _G),
        $#\=(_A, '$$susp'( '$no',  [], _H, _I ), true, _G, _J),
        '$valido_festivos'(:(_E, _F), true, _J, _D).

% extrayendo
'$extrayendo'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_A, _H, _F, _I),
        '$extrayendo_1'(_H, _B, _C, _D, _E, _I, _G).
'$extrayendo_1'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_A, [], _E, _G),
        hnf(_B, [], _G, _F).
'$extrayendo_1'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_A, :(_H, _I), _F, _J),
        hnf(_B, _K, _J, _L),
        '$extrayendo_1_2_:'(_H, _I, _K, _C, _D, _E, _L, _G).
'$extrayendo_1_2_:'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_C, :(_I, _J), _G, _K),
        $#=(_I, '$$susp'( '$j2',  [], _L, _M ), true, _K, _N),
        '$extrayendo'(_B, _J, '$$susp'( $+, [ _D, 1 ], _O, _P ), _E, _F, _N, _H).
'$extrayendo_1_2_:'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_C, :(_I, _J), _G, _K),
        $#\=(_I, '$$susp'( '$j2',  [], _L, _M ), true, _K, _N),
        equal(_E, '$$susp'( '$grupo_activo', [ _D ], _O, _P ), _N, _Q),
        $++(:('$$tup'(','(_A, _I)), []), '$$susp'( '$extrayendo', [ _B, _J, '$$susp'( $+, [ _D, 1 ], _R, _S ), _E ], _T, _U ), _F, _Q, _H).
'$extrayendo_1_2_:'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_C, :(_I, _J), _G, _K),
        $#\=(_I, '$$susp'( '$j2',  [], _L, _M ), true, _K, _N),
        notEqual(_E, '$$susp'( '$grupo_activo', [ _D ], _O, _P ), _N, _Q),
        '$extrayendo'(_B, _J, '$$susp'( $+, [ _D, 1 ], _R, _S ), _E, _F, _Q, _H).

% extraer_turnos
'$extraer_turnos'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, _G, _E, _H),
        '$extraer_turnos_1'(_G, _B, _C, _D, _H, _F).
'$extraer_turnos_1'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_A, [], _D, _E).
'$extraer_turnos_1'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, :(_G, _H), _E, _I),
        hnf(_C, :(_J, _K), _I, _L),
        $++(:('$$susp'( '$extrayendo', [ _G, _B, 1, _J ], _M, _N ), []), '$$susp'( '$extraer_turnos', [ _H, _B, _K ], _O, _P ), _D, _L, _F).

% sacar_laborables
'$sacar_laborables'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$sacar_laborables_1'(_E, _B, _F, _D).
'$sacar_laborables_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$sacar_laborables_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, _J, _I, _K),
        '$sacar_laborables_1_1.1_:_1.1.1_$$tup'(_J, _F, _B, _K, _D).
'$sacar_laborables_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        $#=(_G, '$$susp'( '$j1',  [], _I, _J ), true, _H, _K),
        $++(:(_F, []), '$$susp'( '$sacar_laborables', [ _B ], _L, _M ), _C, _K, _E).
'$sacar_laborables_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        $#\=(_G, '$$susp'( '$j1',  [], _I, _J ), true, _H, _K),
        '$sacar_laborables'(_B, _C, _K, _E).

% extraer_laborables
'$extraer_laborables'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$extraer_laborables_1'(_E, _B, _F, _D).
'$extraer_laborables_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$extraer_laborables_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $++(:('$$susp'( '$sacar_laborables', [ _E ], _H, _I ), []), '$$susp'( '$extraer_laborables', [ _F ], _J, _K ), _B, _G, _D).

% sacar_festivos
'$sacar_festivos'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$sacar_festivos_1'(_E, _B, _F, _D).
'$sacar_festivos_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$sacar_festivos_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, _J, _I, _K),
        '$sacar_festivos_1_1.1_:_1.1.1_$$tup'(_J, _F, _B, _K, _D).
'$sacar_festivos_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        $#=(_G, '$$susp'( '$j3',  [], _I, _J ), true, _H, _K),
        $++(:(_F, []), '$$susp'( '$sacar_festivos', [ _B ], _L, _M ), _C, _K, _E).
'$sacar_festivos_1_1.1_:_1.1.1_$$tup'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ','(_F, _G), _D, _H),
        $#\=(_G, '$$susp'( '$j3',  [], _I, _J ), true, _H, _K),
        '$sacar_festivos'(_B, _C, _K, _E).

% extraer_festivos
'$extraer_festivos'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$extraer_festivos_1'(_E, _B, _F, _D).
'$extraer_festivos_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$extraer_festivos_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $++(:('$$susp'( '$sacar_festivos', [ _E ], _H, _I ), []), '$$susp'( '$extraer_festivos', [ _F ], _J, _K ), _B, _G, _D).

% rotar_turnos_laborables
'$rotar_turnos_laborables'(_A, true, _B, _C):-
        hnf(_A, _D, _B, _E),
        '$rotar_turnos_laborables_1'(_D, true, _E, _C).
'$rotar_turnos_laborables_1'(_A, true, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$rotar_turnos_laborables_1'(_A, true, _B, _C):-
        unifyHnfs(_A, :(_D, _E), _B, _F),
        '$valido_laborables'(_D, true, _F, _G),
        '$rotar_turnos_laborables'(_E, true, _G, _C).

% rotar_turnos_festivos
'$rotar_turnos_festivos'(_A, true, _B, _C):-
        hnf(_A, _D, _B, _E),
        '$rotar_turnos_festivos_1'(_D, true, _E, _C).
'$rotar_turnos_festivos_1'(_A, true, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$rotar_turnos_festivos_1'(_A, true, _B, _C):-
        unifyHnfs(_A, :(_D, _E), _B, _F),
        '$valido_festivos'(_D, true, _F, _G),
        '$rotar_turnos_festivos'(_E, true, _G, _C).

% imponer_rotaciones
'$imponer_rotaciones'(_A, _B, _C, _D, _E, _F):-
        =(_G, '$$susp'( '$extraer_turnos', [ _C, _A, _B ], _H, _I )),
        '$rotar_turnos_laborables'('$$susp'( '$extraer_laborables', [ _G ], _J, _K ), true, _E, _L),
        '$rotar_turnos_festivos'('$$susp'( '$extraer_festivos', [ _G ], _M, _N ), true, _L, _O),
        hnf(_C, _D, _O, _F).

% rango_jornadas
'$rango_jornadas'(_A, true, _B, _C):-
        '$domain'(_A, 1, 4, true, _B, _C).

% establecer_dominios
'$establecer_dominios'(_A, true, _B, _C):-
        hnf(_A, _D, _B, _E),
        '$establecer_dominios_1'(_D, true, _E, _C).
'$establecer_dominios_1'(_A, true, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$establecer_dominios_1'(_A, true, _B, _C):-
        unifyHnfs(_A, :(_D, _E), _B, _F),
        '$domain'(_D, 0, 8, true, _F, _G),
        '$establecer_dominios'(_E, true, _G, _C).

% etiquetar
'$etiquetar'(_A, _B, true, _C, _D):-
        equalnf(_E, '$$susp'( '$extraer', [ _A ], _F, _G ), _C, _H),
        '$labeling'(_B, _E, true, _H, _D).

% extraer
'$extraer'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$extraer_1'(_E, _B, _F, _D).
'$extraer_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$extraer_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $++(_E, '$$susp'( '$extraer', [ _F ], _H, _I ), _B, _G, _D).

% 'etiquetar\''
'$etiquetar\''(_A, _B, true, _C, _D):-
        equalnf(_E, '$$susp'( '$extraer', [ _A ], _F, _G ), _C, _H),
        equalnf(_I, '$$susp'( '$extraer', [ _B ], _J, _K ), _H, _L),
        '$mi_busqueda'(_E, _I, true, _L, _D).

% m0_0
'$m0_0'(_A, 0, _B, _B).

% m1_24
'$m1_24'(_A, _B, _C, _D):-
        $#/('$$susp'( $#*, [ 24, '$$susp'( $#*, [ _A, '$$susp'( $#*, [ '$$susp'( $#-, [ 2, _A ], _E, _F ), '$$susp'( $#*, [ '$$susp'( $#-, [ 3, _A ], _G, _H ), '$$susp'( $#*, [ '$$susp'( $#-, [ 4, _A ], _I, _J ), '$$susp'( $#*, [ '$$susp'( $#-, [ 5, _A ], _K, _L ), '$$susp'( $#*, [ '$$susp'( $#-, [ 6, _A ], _M, _N ), '$$susp'( $#*, [ '$$susp'( $#-, [ 7, _A ], _O, _P ), '$$susp'( $#-, [ 8, _A ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ), 5040, _B, _C, _D).

% m2_14
'$m2_14'(_A, _B, _C, _D):-
        $#/('$$susp'( $#*, [ 14, '$$susp'( $#*, [ _A, '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 1 ], _E, _F ), '$$susp'( $#*, [ '$$susp'( $#-, [ 3, _A ], _G, _H ), '$$susp'( $#*, [ '$$susp'( $#-, [ 4, _A ], _I, _J ), '$$susp'( $#*, [ '$$susp'( $#-, [ 5, _A ], _K, _L ), '$$susp'( $#*, [ '$$susp'( $#-, [ 6, _A ], _M, _N ), '$$susp'( $#*, [ '$$susp'( $#-, [ 7, _A ], _O, _P ), '$$susp'( $#-, [ 8, _A ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ), 1440, _B, _C, _D).

% m3_14
'$m3_14'(_A, _B, _C, _D):-
        $#/('$$susp'( $#*, [ 14, '$$susp'( $#*, [ _A, '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 1 ], _E, _F ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 2 ], _G, _H ), '$$susp'( $#*, [ '$$susp'( $#-, [ 4, _A ], _I, _J ), '$$susp'( $#*, [ '$$susp'( $#-, [ 5, _A ], _K, _L ), '$$susp'( $#*, [ '$$susp'( $#-, [ 6, _A ], _M, _N ), '$$susp'( $#*, [ '$$susp'( $#-, [ 7, _A ], _O, _P ), '$$susp'( $#-, [ 8, _A ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ), 720, _B, _C, _D).

% m4_17
'$m4_17'(_A, _B, _C, _D):-
        $#/('$$susp'( $#*, [ 17, '$$susp'( $#*, [ _A, '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 1 ], _E, _F ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 2 ], _G, _H ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 3 ], _I, _J ), '$$susp'( $#*, [ '$$susp'( $#-, [ 5, _A ], _K, _L ), '$$susp'( $#*, [ '$$susp'( $#-, [ 6, _A ], _M, _N ), '$$susp'( $#*, [ '$$susp'( $#-, [ 7, _A ], _O, _P ), '$$susp'( $#-, [ 8, _A ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ), 576, _B, _C, _D).

% m5_13
'$m5_13'(_A, _B, _C, _D):-
        $#/('$$susp'( $#*, [ 13, '$$susp'( $#*, [ _A, '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 1 ], _E, _F ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 2 ], _G, _H ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 3 ], _I, _J ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 4 ], _K, _L ), '$$susp'( $#*, [ '$$susp'( $#-, [ 6, _A ], _M, _N ), '$$susp'( $#*, [ '$$susp'( $#-, [ 7, _A ], _O, _P ), '$$susp'( $#-, [ 8, _A ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ), 720, _B, _C, _D).

% m6_6
'$m6_6'(_A, _B, _C, _D):-
        $#/('$$susp'( $#*, [ 6, '$$susp'( $#*, [ _A, '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 1 ], _E, _F ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 2 ], _G, _H ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 3 ], _I, _J ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 4 ], _K, _L ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 5 ], _M, _N ), '$$susp'( $#*, [ '$$susp'( $#-, [ 7, _A ], _O, _P ), '$$susp'( $#-, [ 8, _A ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ), 1440, _B, _C, _D).

% m7_6
'$m7_6'(_A, _B, _C, _D):-
        $#/('$$susp'( $#*, [ 6, '$$susp'( $#*, [ _A, '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 1 ], _E, _F ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 2 ], _G, _H ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 3 ], _I, _J ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 4 ], _K, _L ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 5 ], _M, _N ), '$$susp'( $#*, [ '$$susp'( $#-, [ _A, 6 ], _O, _P ), '$$susp'( $#-, [ 8, _A ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ), 5040, _B, _C, _D).

% m8_0
'$m8_0'(_A, 0, _B, _B).

% 'duracion\''
'$duracion\''(_A, _B, _C, _D):-
        $#+('$$susp'( $#+, [ '$$susp'( $#+, [ '$$susp'( $#+, [ '$$susp'( $#+, [ '$$susp'( $#+, [ '$$susp'( $#+, [ '$$susp'( $#+, [ '$$susp'( '$m0_0', [ _A ], _E, _F ), '$$susp'( '$m1_24', [ _A ], _G, _H ) ], _I, _J ), '$$susp'( '$m2_14', [ _A ], _K, _L ) ], _M, _N ), '$$susp'( '$m3_14', [ _A ], _O, _P ) ], _Q, _R ), '$$susp'( '$m4_17', [ _A ], _S, _T ) ], _U, _V ), '$$susp'( '$m5_13', [ _A ], _W, _X ) ], _Y, _Z ), '$$susp'( '$m6_6', [ _A ], _AA, _BA ) ], _CA, _DA ), '$$susp'( '$m7_6', [ _A ], _EA, _FA ) ], _GA, _HA ), '$$susp'( '$m8_0', [ _A ], _IA, _JA ), _B, _C, _D).

% duracion
'$duracion'(_A, _B, _C, _D):-
        $#\/('$$susp'( $#\/, [ '$$susp'( $#\/, [ '$$susp'( $#\/, [ '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 1 ], _E, _F ), '$$susp'( $#=, [ _G, 24 ], _H, _I ) ], _J, _K ), '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 2 ], _L, _M ), '$$susp'( $#=, [ _G, 14 ], _N, _O ) ], _P, _Q ) ], _R, _S ), '$$susp'( $#\/, [ '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 3 ], _T, _U ), '$$susp'( $#=, [ _G, 14 ], _V, _W ) ], _X, _Y ), '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 4 ], _Z, _AA ), '$$susp'( $#=, [ _G, 17 ], _BA, _CA ) ], _DA, _EA ) ], _FA, _GA ) ], _HA, _IA ), '$$susp'( $#\/, [ '$$susp'( $#\/, [ '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 5 ], _JA, _KA ), '$$susp'( $#=, [ _G, 13 ], _LA, _MA ) ], _NA, _OA ), '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 6 ], _PA, _QA ), '$$susp'( $#=, [ _G, 6 ], _RA, _SA ) ], _TA, _UA ) ], _VA, _WA ), '$$susp'( $#\/, [ '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 7 ], _XA, _YA ), '$$susp'( $#=, [ _G, 6 ], _ZA, _AB ) ], _BB, _CB ), '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 8 ], _DB, _EB ), '$$susp'( $#=, [ _G, 0 ], _FB, _GB ) ], _HB, _IB ) ], _JB, _KB ) ], _LB, _MB ) ], _NB, _OB ), '$$susp'( $#=>, [ '$$susp'( $#=, [ _A, 0 ], _PB, _QB ), '$$susp'( $#=, [ _G, 0 ], _RB, _SB ) ], _TB, _UB ), true, _C, _VB),
        hnf(_G, _B, _VB, _D).

% horasTrabajador
'$horasTrabajador'(_A, _B, _C, _D):-
        '$foldl'(#+, 0, '$$susp'( '$map', [ duracion, _A ], _E, _F ), _B, _C, _D).

% trabajoMes
'$trabajoMes'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, _G, _E, _H),
        '$trabajoMes_1'(_G, _B, _C, _D, _H, _F).
'$trabajoMes_1'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, [], _F, _E).
'$trabajoMes_1'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, :(_G, _H), _E, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$$tup'(_M), _L, _N),
        hnf(_M, ','(_O, _P), _N, _Q),
        hnf(_P, ','(_R, _S), _Q, _T),
        '$if_then_else'('$$susp'( '$$eqFun', [ _O, _C ], _U, _V ), '$$susp'( $++, [ :(_G, []), '$$susp'( '$trabajoMes', [ _H, _K, _C ], _W, _X ) ], _Y, _Z ), '$$susp'( '$trabajoMes', [ _H, _K, _C ], _AA, _BA ), _D, _T, _F).

% hm
'$hm'(_A, _B, _C, _D, _E, true, _F, _G):-
        =(_H, '$$susp'( '$horasTrabajador', [ '$$susp'( '$trabajoMes', [ _A, _B, _E ], _I, _J ) ], _K, _L )),
        $#>(_H, '$$susp'( $-, [ _C, _D ], _M, _N ), true, _F, _O),
        $#<(_H, '$$susp'( $+, [ _C, _D ], _P, _Q ), true, _O, _G).

% horasMesTrabajador
'$horasMesTrabajador'(_A, _B, _C, _D, _E, true, _F, _G):-
        hnf(_C, _H, _F, _I),
        '$horasMesTrabajador_3'(_A, _B, _H, _D, _E, true, _I, _G).
'$horasMesTrabajador_3'(_A, _B, _C, _D, _E, true, _F, _G):-
        unifyHnfs(_C, [], _F, _G).
'$horasMesTrabajador_3'(_A, _B, _C, _D, _E, true, _F, _G):-
        unifyHnfs(_C, :(_H, _I), _F, _J),
        '$hm'(_A, _B, _H, _E, _D, true, _J, _K),
        '$horasMesTrabajador'(_A, _B, _I, '$$susp'( $+, [ _D, 1 ], _L, _M ), _E, true, _K, _G).

% horasCadaMes
'$horasCadaMes'(_A, _B, _C, _D, true, _E, _F):-
        hnf(_A, _G, _E, _H),
        '$horasCadaMes_1'(_G, _B, _C, _D, true, _H, _F).
'$horasCadaMes_1'(_A, _B, _C, _D, true, _E, _F):-
        unifyHnfs(_A, [], _E, _F).
'$horasCadaMes_1'(_A, _B, _C, _D, true, _E, _F):-
        unifyHnfs(_A, :(_G, _H), _E, _I),
        '$horasMesTrabajador'(_G, _B, _C, 1, _D, true, _I, _J),
        '$horasCadaMes'(_H, _B, _C, _D, true, _J, _F).

% horasCadaAnio
'$horasCadaAnio'(_A, _B, _C, true, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$horasCadaAnio_1'(_F, _B, _C, true, _G, _E).
'$horasCadaAnio_1'(_A, _B, _C, true, _D, _E):-
        unifyHnfs(_A, [], _D, _E).
'$horasCadaAnio_1'(_A, _B, _C, true, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        $#>('$$susp'( '$horasTrabajador', [ _F ], _I, _J ), '$$susp'( $-, [ _B, _C ], _K, _L ), true, _H, _M),
        $#<('$$susp'( '$horasTrabajador', [ _F ], _N, _O ), '$$susp'( $+, [ _B, _C ], _P, _Q ), true, _M, _R),
        '$horasCadaAnio'(_G, _B, _C, true, _R, _E).

% obtenerMes
'$obtenerMes'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_K, ','(_M, _N), _L, _O),
        hnf(_J, _B, _O, _D).

% calcularMesUltimo
'$calcularMesUltimo'(_A, _B, _C, _D):-
        '$obtenerMes'('$$susp'( '$invertir', [ _A ], _E, _F ), _B, _C, _D).

% numeroMes
'$numeroMes'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$numeroMes_1'(_F, _B, _C, _G, _E).
'$numeroMes_1'(_A, _B, 0, _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$numeroMes_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        hnf(_F, '$$tup'(_I), _H, _J),
        hnf(_I, ','(_K, _L), _J, _M),
        hnf(_L, ','(_N, _O), _M, _P),
        '$if_then_else'('$$susp'( '$$eqFun', [ _B, _K ], _Q, _R ), '$$susp'( '$if_then_else', [ '$$susp'( '$$eqFun', [ _O, '$$susp'( '$laborable',  [], _S, _T ) ], _U, _V ), '$$susp'( $+, [ 6, '$$susp'( '$numeroMes', [ _G, _B ], _W, _X ) ], _Y, _Z ), '$$susp'( '$numeroMes', [ _G, _B ], _AA, _BA ) ], _CA, _DA ), '$$susp'( '$numeroMes', [ _G, _B ], _EA, _FA ), _C, _P, _E).

% horasMes
'$horasMes'(_A, _B, _C, [], _D, _E):-
        equal(_B, '$$susp'( $+, [ _C, 1 ], _F, _G ), _D, _E).
'$horasMes'(_A, _B, _C, _D, _E, _F):-
        $<(_B, '$$susp'( $+, [ _C, 1 ], _G, _H ), true, _E, _I),
        $++(:('$$susp'( '$numeroMes', [ _A, _B ], _J, _K ), []), '$$susp'( '$horasMes', [ _A, '$$susp'( $+, [ _B, 1 ], _L, _M ), _C ], _N, _O ), _D, _I, _F).

% horasAnio
'$horasAnio'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$horasAnio_1'(_E, _B, _F, _D).
'$horasAnio_1'(_A, 0, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$horasAnio_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_K, ','(_M, _N), _L, _O),
        '$if_then_else'('$$susp'( '$$eqFun', [ _N, '$$susp'( '$laborable',  [], _P, _Q ) ], _R, _S ), '$$susp'( $+, [ 6, '$$susp'( '$horasAnio', [ _F ], _T, _U ) ], _V, _W ), '$$susp'( '$horasAnio', [ _F ], _X, _Y ), _B, _O, _D).

% planificar
'$planificar'(_A, _B, _C, _D, _E, _F):-
        =(_G, '$$susp'( '$horasMes', [ _A, 1, '$$susp'( '$calcularMesUltimo', [ _A ], _H, _I ) ], _J, _K )),
        =(_L, '$$susp'( '$card', [ _A ], _M, _N )),
        =(_O, '$$susp'( '$crear_grupos', [ 12, 3 ], _P, _Q )),
        =(_R, '$$susp'( '$incidencias_dia', [ _B, '$$susp'( '$inicio', [ _L ], _S, _T ) ], _U, _V )),
        =(_W, '$$susp'( '$vacaciones_dia', [ _B, '$$susp'( '$inicio', [ _L ], _X, _Y ) ], _Z, _AA )),
        =(_BA, '$$susp'( '$bajas_dia', [ _B, '$$susp'( '$inicio', [ _L ], _CA, _DA ) ], _EA, _FA )),
        =(_GA, '$$susp'( '$t13trabaja_noche', [ _A, _R ], _HA, _IA )),
        =(_JA, '$$susp'( '$crear_plan_jornadas', [ _A, _R, _GA ], _KA, _LA )),
        =(_MA, '$$susp'( '$anotar_incidencias', [ '$$susp'( '$crear_tabla', [ 13, _L ], _NA, _OA ), _B ], _PA, _QA )),
        '$ini'(:('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(101), :('$char'(115), :('$char'(116), :('$char'(114), :('$char'(117), :('$char'(99), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(97), :('$char'(115), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))))))))))), true, _E, _RA),
        equal(_SA, '$$susp'( '$crear_planificacion', [ 13, _L ], _TA, _UA ), _RA, _VA),
        equal(_WA, '$$susp'( '$crear_trabajo', [ _L ], _XA, _YA ), _VA, _ZA),
        equal(_AB, '$$susp'( '$transponer', [ _SA ], _BB, _CB ), _ZA, _DB),
        equal(_EB, '$$susp'( '$n_menos_1', [ _SA ], _FB, _GB ), _DB, _HB),
        equal(_IB, '$$susp'( '$elemento', [ 13, _SA ], _JB, _KB ), _HB, _LB),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _LB, _MB),
        '$ini'(:('$char'(97), :('$char'(110), :('$char'(111), :('$char'(116), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(105), :('$char'(110), :('$char'(99), :('$char'(105), :('$char'(100), :('$char'(101), :('$char'(110), :('$char'(99), :('$char'(105), :('$char'(97), :('$char'(115), :('$char'(46), :('$char'(46), :('$char'(46), []))))))))))))))))))))))), true, _MB, _NB),
        equal(_MA, '$$susp'( '$anotar_incidencias', [ '$$susp'( '$crear_tabla', [ 13, _L ], _OB, _PB ), _B ], _QB, _RB ), _NB, _SB),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _SB, _TB),
        '$establecer_dominios'(_SA, true, _TB, _UB),
        '$rango_jornadas'(_WA, true, _UB, _VB),
        '$ini'(:('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(101), :('$char'(115), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(106), :('$char'(111), :('$char'(114), :('$char'(110), :('$char'(97), :('$char'(100), :('$char'(97), :('$char'(115), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))))))))))), true, _VB, _WB),
        '$procesar_jornadas'(_WA, _IB, _A, _R, '$$susp'( '$no',  [], _XB, _YB ), '$$susp'( '$no',  [], _ZB, _AC ), true, _WB, _BC),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _BC, _CC),
        '$ini'(:('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(101), :('$char'(115), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(111), :('$char'(100), :('$char'(105), :('$char'(110), :('$char'(46), :('$char'(46), :('$char'(46), []))))))))))))))))))))), true, _CC, _DC),
        equal(_IB, '$$susp'( '$trabajar_comodin', [ _IB, _A, _WA, _R ], _EC, _FC ), _DC, _GC),
        '$ini'(:('$char'(79), :('$char'(75), :('$char'(49), []))), true, _GC, _HC),
        '$nl'(true, _HC, _IC),
        '$write'(_EB, true, _IC, _JC),
        equal(_EB, '$$susp'( '$no_t6', [ _EB ], _KC, _LC ), _JC, _MC),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _MC, _NC),
        '$ini'(:('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(101), :('$char'(115), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(116), :('$char'(114), :('$char'(97), :('$char'(98), :('$char'(97), :('$char'(106), :('$char'(111), :('$char'(46), :('$char'(46), :('$char'(46), []))))))))))))))))))))), true, _NC, _OC),
        equal(_AB, '$$susp'( '$procesar_trabajo', [ '$$susp'( '$transponer', [ _MA ], _PC, _QC ), _AB, 1, _O, _WA, _W, _BA ], _RC, _SC ), _OC, _TC),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _TC, _UC),
        '$ini'(:('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(101), :('$char'(115), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(114), :('$char'(111), :('$char'(116), :('$char'(97), :('$char'(99), :('$char'(105), :('$char'(111), :('$char'(110), :('$char'(101), :('$char'(115), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))))))))))))), true, _UC, _VC),
        equal(_SA, '$$susp'( $++, [ '$$susp'( '$imponer_rotaciones', [ _WA, _O, _EB ], _WC, _XC ), :(_IB, []) ], _YC, _ZC ), _VC, _AD),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _AD, _BD),
        '$ini'(:('$char'(108), :('$char'(105), :('$char'(109), :('$char'(105), :('$char'(116), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(97), :('$char'(115), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))))))), true, _BD, _CD),
        equal(_DD, 50, _CD, _ED),
        equal(_FD, '$$susp'( '$horasMes', [ _A, 1, '$$susp'( '$calcularMesUltimo', [ _A ], _GD, _HD ) ], _ID, _JD ), _ED, _KD),
        '$horasCadaMes'(_SA, _A, _FD, _DD, true, _KD, _LD),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _LD, _MD),
        '$ini'(:('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(101), :('$char'(115), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(112), :('$char'(114), :('$char'(105), :('$char'(109), :('$char'(101), :('$char'(114), :('$char'(97), :('$char'(32), :('$char'(115), :('$char'(111), :('$char'(108), :('$char'(117), :('$char'(99), :('$char'(105), :('$char'(111), :('$char'(110), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))))))))))))))))))), true, _MD, _ND),
        equal(_OD, '$$susp'( '$transponer', [ '$$susp'( '$primera_sol_act', [ '$$susp'( '$transponer', [ '$$susp'( '$n_menos_1', [ _MA ], _PD, _QD ) ], _RD, _SD ), '$$susp'( '$transponer', [ '$$susp'( '$primera_sol', [ '$$susp'( '$crear_planificacion', [ 12, _L ], _TD, _UD ), '$$susp'( '$j2esj1', [ _JA ], _VD, _WD ), _O ], _XD, _YD ) ], _ZD, _AE ), 1, _O, _JA ], _BE, _CE ) ], _DE, _EE ), _ND, _FE),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(33), :('$char'(33), :('$char'(33), []))))), true, _FE, _GE),
        '$ini'(:('$char'(101), :('$char'(116), :('$char'(105), :('$char'(113), :('$char'(117), :('$char'(101), :('$char'(116), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))), true, _GE, _HE),
        '$etiquetar\''(_SA, _OD, true, _HE, _IE),
        '$iniln'(:('$char'(111), :('$char'(107), :('$char'(32), :('$char'(101), :('$char'(116), :('$char'(105), :('$char'(113), :('$char'(117), :('$char'(101), :('$char'(116), :('$char'(97), :('$char'(100), :('$char'(111), :('$char'(33), :('$char'(33), :('$char'(33), [])))))))))))))))), true, _IE, _JE),
        hnf(_SA, _D, _JE, _F).

% sig_laborable
'$sig_laborable'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$sig_laborable_1'(_E, _B, _F, _D).
'$sig_laborable_1'(_A, 2, _B, _C):-
        unifyHnfs(_A, 1, _B, _C).
'$sig_laborable_1'(_A, 3, _B, _C):-
        unifyHnfs(_A, 2, _B, _C).
'$sig_laborable_1'(_A, 1, _B, _C):-
        unifyHnfs(_A, 3, _B, _C).

% sig_festivo
'$sig_festivo'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$sig_festivo_1'(_E, _B, _F, _D).
'$sig_festivo_1'(_A, 9, _B, _C):-
        unifyHnfs(_A, 1, _B, _C).
'$sig_festivo_1'(_A, 0, _B, _C):-
        unifyHnfs(_A, 9, _B, _C).
'$sig_festivo_1'(_A, 1, _B, _C):-
        unifyHnfs(_A, 0, _B, _C).

% extrayendo2
'$extrayendo2'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_A, _H, _F, _I),
        '$extrayendo2_1'(_H, _B, _C, _D, _E, _I, _G).
'$extrayendo2_1'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_A, [], _E, _G),
        hnf(_B, [], _G, _F).
'$extrayendo2_1'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_A, :(_H, _I), _F, _J),
        hnf(_B, :(_K, _L), _J, _M),
        '$if_then_else'('$$susp'( '$$eqFun', [ _K, '$$susp'( '$j2',  [], _N, _O ) ], _P, _Q ), '$$susp'( '$extrayendo2', [ _I, _L, '$$susp'( $+, [ _C, 1 ], _R, _S ), _D ], _T, _U ), '$$susp'( '$if_then_else', [ '$$susp'( '$$eqFun', [ _D, '$$susp'( '$grupo_activo', [ _C ], _V, _W ) ], _X, _Y ), '$$susp'( $++, [ :('$$tup'(','(_H, _K)), []), '$$susp'( '$extrayendo2', [ _I, _L, '$$susp'( $+, [ _C, 1 ], _Z, _AA ), _D ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$extrayendo2', [ _I, _L, '$$susp'( $+, [ _C, 1 ], _FA, _GA ), _D ], _HA, _IA ) ], _JA, _KA ), _E, _M, _G).

% extraer_turnos2
'$extraer_turnos2'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, _G, _E, _H),
        '$extraer_turnos2_1'(_G, _B, _C, _D, _H, _F).
'$extraer_turnos2_1'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_A, [], _D, _E).
'$extraer_turnos2_1'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, :(_G, _H), _E, _I),
        hnf(_C, :(_J, _K), _I, _L),
        $++(:('$$susp'( '$extrayendo2', [ _G, _B, 1, _J ], _M, _N ), []), '$$susp'( '$extraer_turnos2', [ _H, _B, _K ], _O, _P ), _D, _L, _F).

% escribir_lab
'$escribir_lab'(_A, _B, true, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$escribir_lab_1'(_E, _B, true, _F, _D).
'$escribir_lab_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$escribir_lab_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        equal(_E, _B, _G, _H),
        '$escribir_lab'(_F, '$$susp'( '$sig_laborable', [ _B ], _I, _J ), true, _H, _D).

% escribir_laborables
'$escribir_laborables'(_A, _B, true, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$escribir_laborables_1'(_E, _B, true, _F, _D).
'$escribir_laborables_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$escribir_laborables_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        '$escribir_lab'(_E, _B, true, _G, _H),
        '$escribir_laborables'(_F, '$$susp'( '$sig_laborable', [ _B ], _I, _J ), true, _H, _D).

% escribir_fes
'$escribir_fes'(_A, _B, true, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$escribir_fes_1'(_E, _B, true, _F, _D).
'$escribir_fes_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$escribir_fes_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        equal(_E, _B, _G, _H),
        '$escribir_fes'(_F, '$$susp'( '$sig_festivo', [ _B ], _I, _J ), true, _H, _D).

% escribir_festivos
'$escribir_festivos'(_A, _B, true, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$escribir_festivos_1'(_E, _B, true, _F, _D).
'$escribir_festivos_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$escribir_festivos_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        '$escribir_fes'(_E, _B, true, _G, _H),
        '$escribir_festivos'(_F, '$$susp'( '$sig_festivo', [ _B ], _I, _J ), true, _H, _D).

% establecer_des
'$establecer_des'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, _G, _E, _H),
        '$establecer_des_1'(_G, _B, _C, _D, _H, _F).
'$establecer_des_1'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_A, [], _D, _E).
'$establecer_des_1'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, :(_G, _H), _E, _I),
        '$if_then_else'('$$susp'( '$$notEqFun', [ _B, '$$susp'( '$grupo_activo', [ _C ], _J, _K ) ], _L, _M ), '$$susp'( $++, [ :(0, []), '$$susp'( '$establecer_des', [ _H, _B, '$$susp'( $+, [ _C, 1 ], _N, _O ) ], _P, _Q ) ], _R, _S ), '$$susp'( $++, [ :(_G, []), '$$susp'( '$establecer_des', [ _H, _B, '$$susp'( $+, [ _C, 1 ], _T, _U ) ], _V, _W ) ], _X, _Y ), _D, _I, _F).

% establecer_descanso
'$establecer_descanso'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$establecer_descanso_1'(_F, _B, _C, _G, _E).
'$establecer_descanso_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$establecer_descanso_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        hnf(_B, :(_I, _J), _H, _K),
        $++(:('$$susp'( '$establecer_des', [ _F, _I, 1 ], _L, _M ), []), '$$susp'( '$establecer_descanso', [ _G, _J ], _N, _O ), _C, _K, _E).

% primera_sol
'$primera_sol'(_A, _B, _C, _D, _E, _F):-
        equal(_A, '$$susp'( '$establecer_descanso', [ _A, _C ], _G, _H ), _E, _I),
        equalnf(_J, '$$susp'( '$extraer_turnos2', [ _A, _B, _C ], _K, _L ), _I, _M),
        equalnf(_N, '$$susp'( '$extraer_laborables', [ _J ], _O, _P ), _M, _Q),
        equalnf(_R, '$$susp'( '$extraer_festivos', [ _J ], _S, _T ), _Q, _U),
        '$escribir_laborables'(_N, 1, true, _U, _V),
        '$escribir_festivos'(_R, 1, true, _V, _W),
        hnf(_A, _D, _W, _F).

% apuntar
'$apuntar'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$apuntar_1'(_F, _B, _C, _G, _E).
'$apuntar_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _E),
        hnf(_B, [], _E, _D).
'$apuntar_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        hnf(_B, :(_I, _J), _H, _K),
        '$if_then_else'('$$susp'( '$$notEqFun', [ _I, 0 ], _L, _M ), '$$susp'( $++, [ :(_I, []), '$$susp'( '$apuntar', [ _G, _J ], _N, _O ) ], _P, _Q ), '$$susp'( '$if_then_else', [ '$$susp'( '$$eqFun', [ _F, 9 ], _R, _S ), '$$susp'( $++, [ :(1, []), '$$susp'( '$apuntar', [ _G, _J ], _T, _U ) ], _V, _W ), '$$susp'( $++, [ :(_F, []), '$$susp'( '$apuntar', [ _G, _J ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ), _C, _K, _E).

% actividad_comodin
'$actividad_comodin'(_A, _B, _C, _D, _E, _F, _G, _H):-
        hnf(_A, _I, _G, _J),
        '$actividad_comodin_1'(_I, _B, _C, _D, _E, _F, _J, _H).
'$actividad_comodin_1'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, [], _G, _I),
        hnf(_B, [], _I, _J),
        hnf(_D, _K, _J, _L),
        '$actividad_comodin_1_2_4'(_C, _K, _E, _F, _L, _H).
'$actividad_comodin_1'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, :(_I, _J), _G, _K),
        hnf(_B, :(_L, _M), _K, _N),
        hnf(_D, _O, _N, _P),
        '$actividad_comodin_1_2_:_4_:'(_I, _J, _L, _M, _C, _O, _E, _F, _P, _H).
'$actividad_comodin_1_2_4'(_A, _B, _C, 0, _D, _E):-
        unifyHnfs(_B, [], _D, _F),
        equal(_C, 3, _F, _E).
'$actividad_comodin_1_2_4'(_A, _B, _C, 6, _D, _E):-
        unifyHnfs(_B, [], _D, _F),
        notEqual(_C, 3, _F, _E).
'$actividad_comodin_1_2_:_4_:'(_A, _B, _C, _D, _E, _F, _G, 0, _H, _I):-
        unifyHnfs(_F, :(_J, _K), _H, _L),
        equal(_G, 3, _L, _I).
'$actividad_comodin_1_2_:_4_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_F, :(_K, _L), _I, _M),
        notEqual(_G, 3, _M, _N),
        equal(_C, 0, _N, _O),
        '$actividad_comodin'(_B, _D, _E, _L, _G, _H, _O, _J).
'$actividad_comodin_1_2_:_4_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_F, :(_K, _L), _I, _M),
        notEqual(_G, 3, _M, _N),
        notEqual(_C, 0, _N, _O),
        notEqual(_K, '$$susp'( '$grupo_activo', [ _E ], _P, _Q ), _O, _R),
        '$actividad_comodin'(_B, _D, _E, _L, _G, _H, _R, _J).
'$actividad_comodin_1_2_:_4_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_F, :(_K, _L), _I, _M),
        notEqual(_G, 3, _M, _N),
        notEqual(_C, 0, _N, _O),
        equal(_K, '$$susp'( '$grupo_activo', [ _E ], _P, _Q ), _O, _R),
        hnf(_A, _H, _R, _J).

% primera_sol_act
'$primera_sol_act'(_A, _B, _C, _D, _E, _F, _G, _H):-
        hnf(_A, _I, _G, _J),
        '$primera_sol_act_1'(_I, _B, _C, _D, _E, _F, _J, _H).
'$primera_sol_act_1'(_A, _B, _C, _D, _E, [], _F, _G):-
        unifyHnfs(_A, [], _F, _H),
        hnf(_B, [], _H, _G).
'$primera_sol_act_1'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, :(_I, _J), _G, _K),
        hnf(_B, :(_L, _M), _K, _N),
        hnf(_E, _O, _N, _P),
        '$primera_sol_act_1_2_:_5_:'(_I, _J, _L, _M, _C, _D, _O, _F, _P, _H).
'$primera_sol_act_1_2_:_5_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_G, :(_K, _L), _I, _M),
        notEqual(_K, '$$susp'( '$j2',  [], _N, _O ), _M, _P),
        $++(:('$$susp'( $++, [ '$$susp'( '$apuntar', [ _A, _C ], _Q, _R ), :('$$susp'( '$actividad_comodin', [ _A, _C, _E, _F, _K ], _S, _T ), []) ], _U, _V ), []), '$$susp'( '$primera_sol_act', [ _B, _D, '$$susp'( $+, [ _E, 1 ], _W, _X ), _F, _L ], _Y, _Z ), _H, _P, _J).
'$primera_sol_act_1_2_:_5_:'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J):-
        unifyHnfs(_G, :(_K, _L), _I, _M),
        equal(_K, '$$susp'( '$j2',  [], _N, _O ), _M, _P),
        $++(:('$$susp'( $++, [ '$$susp'( '$reapuntar', [ '$$susp'( '$apuntar', [ _A, _C ], _Q, _R ) ], _S, _T ), :('$$susp'( '$no',  [], _U, _V ), []) ], _W, _X ), []), '$$susp'( '$primera_sol_act', [ _B, _D, '$$susp'( $+, [ _E, 1 ], _Y, _Z ), _F, _L ], _AA, _BA ), _H, _P, _J).

% reapuntar
'$reapuntar'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$reapuntar_1'(_E, _B, _F, _D).
'$reapuntar_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$reapuntar_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        '$if_then_else'('$$susp'( '$$eqFun', [ _E, '$$susp'( '$t2',  [], _H, _I ) ], _J, _K ), '$$susp'( $++, [ :('$$susp'( '$t4',  [], _L, _M ), []), _F ], _N, _O ), '$$susp'( '$if_then_else', [ '$$susp'( '$$eqFun', [ _E, '$$susp'( '$t3',  [], _P, _Q ) ], _R, _S ), '$$susp'( $++, [ :('$$susp'( '$t4',  [], _T, _U ), []), _F ], _V, _W ), '$$susp'( $++, [ :(_E, []), '$$susp'( '$reapuntar', [ _F ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ), _B, _G, _D).

% planificar_una
'$planificar_una'(_A, _B, _C, _D, _E):-
        '$ini'(:('$char'(103), :('$char'(101), :('$char'(110), :('$char'(101), :('$char'(114), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(101), :('$char'(115), :('$char'(116), :('$char'(114), :('$char'(117), :('$char'(99), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(97), :('$char'(115), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))))))))))))), true, _D, _F),
        equal(_G, '$$susp'( '$card', [ _A ], _H, _I ), _F, _J),
        equal(_K, '$$susp'( '$crear_grupos', [ 12, 3 ], _L, _M ), _J, _N),
        equal(_O, '$$susp'( '$incidencias_dia', [ _B, '$$susp'( '$inicio', [ _G ], _P, _Q ) ], _R, _S ), _N, _T),
        equal(_U, '$$susp'( '$vacaciones_dia', [ _B, '$$susp'( '$inicio', [ _G ], _V, _W ) ], _X, _Y ), _T, _Z),
        equal(_AA, '$$susp'( '$bajas_dia', [ _B, '$$susp'( '$inicio', [ _G ], _BA, _CA ) ], _DA, _EA ), _Z, _FA),
        equal(_GA, '$$susp'( '$t13trabaja_noche', [ _A, _O ], _HA, _IA ), _FA, _JA),
        equal(_KA, '$$susp'( '$crear_plan_jornadas', [ _A, _O, _GA ], _LA, _MA ), _JA, _NA),
        equal(_OA, '$$susp'( '$crear_planificacion', [ 12, _G ], _PA, _QA ), _NA, _RA),
        '$iniln'(:('$char'(111), :('$char'(107), [])), true, _RA, _SA),
        '$ini'(:('$char'(103), :('$char'(101), :('$char'(110), :('$char'(101), :('$char'(114), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(115), :('$char'(111), :('$char'(108), :('$char'(117), :('$char'(99), :('$char'(105), :('$char'(111), :('$char'(110), :('$char'(46), :('$char'(46), :('$char'(46), []))))))))))))))))))))), true, _SA, _TA),
        equal(_UA, '$$susp'( '$anotar_incidencias', [ '$$susp'( '$crear_tabla', [ 13, _G ], _VA, _WA ), _B ], _XA, _YA ), _TA, _ZA),
        equal(_AB, '$$susp'( '$transponer', [ '$$susp'( '$n_menos_1', [ _UA ], _BB, _CB ) ], _DB, _EB ), _ZA, _FB),
        equal(_GB, '$$susp'( '$transponer', [ '$$susp'( '$primera_sol', [ _OA, '$$susp'( '$j2esj1', [ _KA ], _HB, _IB ), _K ], _JB, _KB ) ], _LB, _MB ), _FB, _NB),
        equal(_OB, '$$susp'( '$transponer', [ '$$susp'( '$primera_sol_act', [ _GB, _AB, 1, _K, _KA ], _PB, _QB ) ], _RB, _SB ), _NB, _TB),
        hnf(_OB, _C, _TB, _E).

% j2esj1
'$j2esj1'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$j2esj1_1'(_E, _B, _F, _D).
'$j2esj1_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$j2esj1_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        equal(_E, '$$susp'( '$j2',  [], _H, _I ), _G, _J),
        $++(:('$$susp'( '$j1',  [], _K, _L ), []), '$$susp'( '$j2esj1', [ _F ], _M, _N ), _B, _J, _D).
'$j2esj1_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        notEqual(_E, '$$susp'( '$j2',  [], _H, _I ), _G, _J),
        $++(:(_E, []), '$$susp'( '$j2esj1', [ _F ], _K, _L ), _B, _J, _D).

% inizio
'$inizio'(_A, _B, _C, _D, _E):-
        '$ini'(:('$char'(103), :('$char'(101), :('$char'(110), :('$char'(101), :('$char'(114), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(101), :('$char'(115), :('$char'(116), :('$char'(114), :('$char'(117), :('$char'(99), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(97), :('$char'(115), :('$char'(46), :('$char'(46), :('$char'(46), [])))))))))))))))))))))))), true, _D, _F),
        equal(_G, '$$susp'( '$card', [ _A ], _H, _I ), _F, _J),
        equal(_K, '$$susp'( '$crear_grupos', [ 12, 3 ], _L, _M ), _J, _N),
        equal(_O, '$$susp'( '$incidencias_dia', [ _B, '$$susp'( '$inicio', [ _G ], _P, _Q ) ], _R, _S ), _N, _T),
        equal(_U, '$$susp'( '$vacaciones_dia', [ _B, '$$susp'( '$inicio', [ _G ], _V, _W ) ], _X, _Y ), _T, _Z),
        equal(_AA, '$$susp'( '$bajas_dia', [ _B, '$$susp'( '$inicio', [ _G ], _BA, _CA ) ], _DA, _EA ), _Z, _FA),
        equal(_GA, '$$susp'( '$t13trabaja_noche', [ _A, _O ], _HA, _IA ), _FA, _JA),
        equal(_KA, '$$susp'( '$crear_plan_jornadas', [ _A, _O, _GA ], _LA, _MA ), _JA, _NA),
        equal(_OA, '$$susp'( '$crear_planificacion', [ 12, _G ], _PA, _QA ), _NA, _RA),
        '$iniln'(:('$char'(111), :('$char'(107), [])), true, _RA, _SA),
        '$ini'(:('$char'(103), :('$char'(101), :('$char'(110), :('$char'(101), :('$char'(114), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(111), :('$char'(32), :('$char'(115), :('$char'(111), :('$char'(108), :('$char'(117), :('$char'(99), :('$char'(105), :('$char'(111), :('$char'(110), :('$char'(46), :('$char'(46), :('$char'(46), []))))))))))))))))))))), true, _SA, _TA),
        equal(_UA, '$$susp'( '$anotar_incidencias', [ '$$susp'( '$crear_tabla', [ 13, _G ], _VA, _WA ), _B ], _XA, _YA ), _TA, _ZA),
        equal(_AB, '$$susp'( '$transponer', [ '$$susp'( '$n_menos_1', [ _UA ], _BB, _CB ) ], _DB, _EB ), _ZA, _FB),
        hnf(_GB, _C, _FB, _E).

% resto
'$resto'(_A, _B, _C, _D, _E):-
        '$eliminar'(_B, '$$susp'( '$deXhastaY', [ '$$susp'( '$fd_min', [ _A ], _F, _G ), '$$susp'( '$fd_max', [ _A ], _H, _I ) ], _J, _K ), _C, _D, _E).

% generar_lista
'$generar_lista'(_A, _B, _C, _D, _E):-
        $++(:(_B, []), '$$susp'( '$resto', [ _A, _B ], _F, _G ), _C, _D, _E).

% intentar
'$intentar'(_A, _B, true, _C, _D):-
        hnf(_B, _E, _C, _F),
        '$intentar_2'(_A, _E, true, _F, _D).
'$intentar_2'(_A, _B, true, _C, _D):-
        unifyHnfs(_B, :(_E, _F), _C, _G),
        equal(_A, _E, _G, _D).
'$intentar_2'(_A, _B, true, _C, _D):-
        unifyHnfs(_B, :(_E, _F), _C, _G),
        '$intentar'(_A, _F, true, _G, _D).

% mi_busqueda
'$mi_busqueda'(_A, _B, true, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$mi_busqueda_1'(_E, _B, true, _F, _D).
'$mi_busqueda_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, [], _C, _E),
        hnf(_B, [], _E, _D).
'$mi_busqueda_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_B, :(_H, _I), _G, _J),
        '$intentar'(_E, '$$susp'( '$generar_lista', [ _E, _H ], _K, _L ), true, _J, _M),
        '$mi_busqueda'(_F, _I, true, _M, _D).

% esNocturno
'$esNocturno'(_A, true, _B, _C):-
        $#\=(_A, '$$susp'( '$t2',  [], _D, _E ), true, _B, _F),
        $#\=(_A, '$$susp'( '$t5',  [], _G, _H ), true, _F, _I),
        $#\=(_A, '$$susp'( '$t6',  [], _J, _K ), true, _I, _L),
        $#\=(_A, '$$susp'( '$bj',  [], _M, _N ), true, _L, _O),
        $#\=(_A, '$$susp'( '$vc',  [], _P, _Q ), true, _O, _R),
        $#\=(_A, '$$susp'( '$no',  [], _S, _T ), true, _R, _C).
'$esNocturno'(_A, false, _B, _C):-
        $#\=(_A, '$$susp'( '$t1',  [], _D, _E ), true, _B, _F),
        $#\=(_A, '$$susp'( '$t3',  [], _G, _H ), true, _F, _I),
        $#\=(_A, '$$susp'( '$t4',  [], _J, _K ), true, _I, _C).

% elemento
'$elemento'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        $>(_A, 0, true, _H, _I),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, 1 ], _J, _K ), _F, '$$susp'( '$elemento', [ '$$susp'( $-, [ _A, 1 ], _L, _M ), _G ], _N, _O ), _C, _I, _E).

% deXhastaY
'$deXhastaY'(_A, _B, :(_A, []), _C, _D):-
        equal(_A, _B, _C, _D).
'$deXhastaY'(_A, _B, _C, _D, _E):-
        $<(_A, _B, true, _D, _F),
        $++(:(_A, []), '$$susp'( '$deXhastaY', [ '$$susp'( $+, [ _A, 1 ], _G, _H ), _B ], _I, _J ), _C, _F, _E).

% 'div\''
'$div\''(_A, _B, _C, _D, _E):-
        '$if_then_else'('$$susp'( $>=, [ _A, _B ], _F, _G ), '$$susp'( $+, [ 1, '$$susp'( '$div\'', [ '$$susp'( $-, [ _A, _B ], _H, _I ), _B ], _J, _K ) ], _L, _M ), 0, _C, _D, _E).

% sustituir
'$sustituir'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, :(_G, _H), _E, _I),
        $>(_B, 0, true, _I, _J),
        '$if_then_else'('$$susp'( '$$eqFun', [ _B, 1 ], _K, _L ), '$$susp'( $++, [ :(_C, []), _H ], _M, _N ), '$$susp'( $++, [ :(_G, []), '$$susp'( '$sustituir', [ _H, '$$susp'( $-, [ _B, 1 ], _O, _P ), _C ], _Q, _R ) ], _S, _T ), _D, _J, _F).

% ultimo
'$ultimo'(_A, _B, _C, _D):-
        equalnf(_E, '$$susp'( '$elemento', [ '$$susp'( '$card', [ _A ], _F, _G ), _A ], _H, _I ), _C, _J),
        hnf(_E, _B, _J, _D).

% n_menos_1
'$n_menos_1'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$n_menos_1_1_1.2_:'(_E, _H, _B, _I, _D).
'$n_menos_1_1_1.2_:'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$n_menos_1_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        $++(:(_A, []), '$$susp'( '$n_menos_1', [ :(_F, _G) ], _I, _J ), _C, _H, _E).

% invertir
'$invertir'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$invertir_1'(_E, _B, _F, _D).
'$invertir_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$invertir_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $++('$$susp'( '$invertir', [ _F ], _H, _I ), :(_E, []), _B, _G, _D).

% card
'$card'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$card_1'(_E, _B, _F, _D).
'$card_1'(_A, 0, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$card_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $+(1, '$$susp'( '$card', [ _F ], _H, _I ), _B, _G, _D).

% eliminar
'$eliminar'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$eliminar_2'(_A, _F, _C, _G, _E).
'$eliminar_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$eliminar_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, _F ], _I, _J ), _G, '$$susp'( $++, [ :(_F, []), '$$susp'( '$eliminar', [ _A, _G ], _K, _L ) ], _M, _N ), _C, _H, _E).

% ini
'$ini'(_A, true, _B, _C):-
        equalnf(_D, '$$susp'( '$putStr', [ _A ], _E, _F ), _B, _C).

% iniln
'$iniln'(_A, true, _B, _C):-
        equalnf(_D, '$$susp'( '$putStrLn', [ _A ], _E, _F ), _B, _C).


/***********   CODE FOR DINAMIC CUT         ***********/

/*Lista de funciones deterministas indicadas por el usuario */

annotate(deterministic('$if_then_else')).


/*Lista de funciones deterministas por programa *************/

annotate(deterministic('$init_fd')).
annotate(deterministic('$write')).
annotate(deterministic('$nl')).
annotate(deterministic($#==)).
annotate(deterministic($#/==)).
annotate(deterministic('$domain')).
annotate(deterministic('$subset')).
annotate(deterministic('$inset')).
annotate(deterministic('$setcomplement')).
annotate(deterministic('$intersect')).
annotate(deterministic('$belongs')).
annotate(deterministic('$labeling')).
annotate(deterministic('$indomain')).
annotate(deterministic('$fdminimize')).
annotate(deterministic('$fdmaximize')).
annotate(deterministic($#=)).
annotate(deterministic($#\=)).
annotate(deterministic($#<)).
annotate(deterministic($#<=)).
annotate(deterministic($#>)).
annotate(deterministic($#>=)).
annotate(deterministic($#+)).
annotate(deterministic($#-)).
annotate(deterministic($#*)).
annotate(deterministic($#/)).
annotate(deterministic($#&)).
annotate(deterministic('$sum')).
annotate(deterministic('$scalar_product')).
annotate(deterministic('$all_different')).
annotate(deterministic('$all_different\'')).
annotate(deterministic('$assignment')).
annotate(deterministic('$circuit')).
annotate(deterministic('$circuit\'')).
annotate(deterministic('$count')).
annotate(deterministic('$element')).
annotate(deterministic('$exactly')).
annotate(deterministic('$serialized')).
annotate(deterministic('$serialized\'')).
annotate(deterministic('$cumulative')).
annotate(deterministic('$cumulative\'')).
annotate(deterministic($#\/)).
annotate(deterministic($#<=>)).
annotate(deterministic($#=>)).
annotate(deterministic('$fd_var')).
annotate(deterministic('$fd_min')).
annotate(deterministic('$fd_max')).
annotate(deterministic('$fd_size')).
annotate(deterministic('$fd_set')).
annotate(deterministic('$fd_dom')).
annotate(deterministic('$fd_degree')).
annotate(deterministic('$fd_neighbors')).
annotate(deterministic('$fd_closure')).
annotate(deterministic('$inf')).
annotate(deterministic('$sup')).
annotate(deterministic('$is_fdset')).
annotate(deterministic('$empty_fdset')).
annotate(deterministic('$fdset_parts')).
annotate(deterministic('$fdset_split')).
annotate(deterministic('$empty_interval')).
annotate(deterministic('$fdset_to_interval')).
annotate(deterministic('$interval_to_fdset')).
annotate(deterministic('$fdset_singleton')).
annotate(deterministic('$fdset_min')).
annotate(deterministic('$fdset_max')).
annotate(deterministic('$fdset_size')).
annotate(deterministic('$list_to_fdset')).
annotate(deterministic('$fdset_to_list')).
annotate(deterministic('$range_to_fdset')).
annotate(deterministic('$fdset_to_range')).
annotate(deterministic('$fdset_add_element')).
annotate(deterministic('$fdset_del_element')).
annotate(deterministic('$fdset_intersection')).
annotate(deterministic('$fdset_subtract')).
annotate(deterministic('$fdset_union')).
annotate(deterministic('$fdset_complement')).
annotate(deterministic('$fdsets_intersection')).
annotate(deterministic('$fdsets_union')).
annotate(deterministic('$fdset_equal')).
annotate(deterministic('$fdset_subset')).
annotate(deterministic('$fdset_disjoint')).
annotate(deterministic('$fdset_intersect')).
annotate(deterministic('$fdset_member')).
annotate(deterministic('$fdset_belongs')).
annotate(deterministic('$isin')).
annotate(deterministic('$minimum')).
annotate(deterministic('$fd_statistics')).
annotate(deterministic('$fd_statistics\'')).
annotate(deterministic('$fd_global')).
annotate(deterministic('$end_fd')).
annotate(deterministic('$and')).
annotate(deterministic('$or')).
annotate(deterministic($/\)).
annotate(deterministic($\/)).
annotate(deterministic('$not')).
annotate(deterministic('$andL')).
annotate(deterministic('$orL')).
annotate(deterministic('$orL\'')).
annotate(deterministic('$any')).
annotate(deterministic('$any\'')).
annotate(deterministic('$all')).
annotate(deterministic('$undefined')).
annotate(deterministic('$def')).
annotate(deterministic('$not_undef')).
annotate(deterministic('$nf')).
annotate(deterministic('$hnf')).
annotate(deterministic('$strict')).
annotate(deterministic('$strict\'')).
annotate(deterministic('$map')).
annotate(deterministic($.)).
annotate(deterministic($++)).
annotate(deterministic('$!!')).
annotate(deterministic('$iterate')).
annotate(deterministic('$repeat')).
annotate(deterministic('$copy')).
annotate(deterministic('$filter')).
annotate(deterministic('$foldl')).
annotate(deterministic('$foldl1')).
annotate(deterministic('$foldl\'')).
annotate(deterministic('$scanl')).
annotate(deterministic('$scanl1')).
annotate(deterministic('$scanl\'')).
annotate(deterministic('$foldr')).
annotate(deterministic('$foldr1')).
annotate(deterministic('$scanr')).
annotate(deterministic('$auxForScanr')).
annotate(deterministic('$scanr1')).
annotate(deterministic('$take')).
annotate(deterministic('$drop')).
annotate(deterministic('$splitAt')).
annotate(deterministic('$auxForSplitAt')).
annotate(deterministic('$takeWhile')).
annotate(deterministic('$takeUntil')).
annotate(deterministic('$dropWhile')).
annotate(deterministic('$span')).
annotate(deterministic('$auxForSpan')).
annotate(deterministic('$break')).
annotate(deterministic('$zipWith')).
annotate(deterministic('$zip')).
annotate(deterministic('$mkpair')).
annotate(deterministic('$unzip')).
annotate(deterministic('$auxForUnzip')).
annotate(deterministic('$until')).
annotate(deterministic('$until\'')).
annotate(deterministic('$const')).
annotate(deterministic('$id')).
annotate(deterministic('$curry')).
annotate(deterministic('$uncurry')).
annotate(deterministic('$fst')).
annotate(deterministic('$snd')).
annotate(deterministic('$fst3')).
annotate(deterministic('$snd3')).
annotate(deterministic('$thd3')).
annotate(deterministic('$subtract')).
annotate(deterministic('$even')).
annotate(deterministic('$odd')).
annotate(deterministic('$lcm')).
annotate(deterministic('$head')).
annotate(deterministic('$last')).
annotate(deterministic('$tail')).
annotate(deterministic('$init')).
annotate(deterministic('$nub')).
annotate(deterministic('$length')).
annotate(deterministic('$size')).
annotate(deterministic('$reverse')).
annotate(deterministic('$member')).
annotate(deterministic('$notMember')).
annotate(deterministic('$concat')).
annotate(deterministic('$transpose')).
annotate(deterministic('$auxForTranspose')).
annotate(deterministic($\\)).
annotate(deterministic('$del')).
annotate(deterministic('$incidencias')).
annotate(deterministic('$unasemana')).
annotate(deterministic('$unmes')).
annotate(deterministic('$dosmeses')).
annotate(deterministic('$tresmeses')).
annotate(deterministic('$cuatromeses')).
annotate(deterministic('$cincomeses')).
annotate(deterministic('$seismeses')).
annotate(deterministic('$ochomeses')).
annotate(deterministic('$diezmeses')).
annotate(deterministic('$anio')).
annotate(deterministic('$laborable')).
annotate(deterministic('$festivo')).
annotate(deterministic('$especial')).
annotate(deterministic('$no')).
annotate(deterministic('$t1')).
annotate(deterministic('$t2')).
annotate(deterministic('$t3')).
annotate(deterministic('$t4')).
annotate(deterministic('$t5')).
annotate(deterministic('$t6')).
annotate(deterministic('$bj')).
annotate(deterministic('$vc')).
annotate(deterministic('$grupo_activo')).
annotate(deterministic('$incrementar')).
annotate(deterministic('$crear_incidencias')).
annotate(deterministic('$inicio')).
annotate(deterministic('$crear_grupos')).
annotate(deterministic('$solicitaNoche')).
annotate(deterministic('$puedeNoche')).
annotate(deterministic('$t13trabaja_noche')).
annotate(deterministic('$j1')).
annotate(deterministic('$j2')).
annotate(deterministic('$j3')).
annotate(deterministic('$j4')).
annotate(deterministic('$crear_plan_jornadas')).
annotate(deterministic('$crear_trabajo')).
annotate(deterministic('$crear_planificacion')).
annotate(deterministic('$borrar_uno')).
annotate(deterministic('$quitar_primeros')).
annotate(deterministic('$prim')).
annotate(deterministic('$primeros')).
annotate(deterministic('$listas_vacias')).
annotate(deterministic('$transponer')).
annotate(deterministic('$crear_fila')).
annotate(deterministic('$crear_tabla')).
annotate(deterministic('$anotar_en_trabajador')).
annotate(deterministic('$anotar_una')).
annotate(deterministic('$anotar_incidencias')).
annotate(deterministic('$contar')).
annotate(deterministic('$empaquetar')).
annotate(deterministic('$proyectar')).
annotate(deterministic('$anotar_trab')).
annotate(deterministic('$anotar_desc')).
annotate(deterministic('$descansar')).
annotate(deterministic('$trabajar')).
annotate(deterministic('$grupo')).
annotate(deterministic('$procesar_tipo_dia')).
annotate(deterministic('$procesar_dia')).
annotate(deterministic('$procesar_trabajo')).
annotate(deterministic('$trab_comodin')).
annotate(deterministic('$trabajar_comodin')).
annotate(deterministic('$proc_t6')).
annotate(deterministic('$sin_t6')).
annotate(deterministic('$no_t6')).
annotate(deterministic('$valido_laborables')).
annotate(deterministic('$valido_festivos')).
annotate(deterministic('$extrayendo')).
annotate(deterministic('$extraer_turnos')).
annotate(deterministic('$sacar_laborables')).
annotate(deterministic('$extraer_laborables')).
annotate(deterministic('$sacar_festivos')).
annotate(deterministic('$extraer_festivos')).
annotate(deterministic('$rotar_turnos_laborables')).
annotate(deterministic('$rotar_turnos_festivos')).
annotate(deterministic('$imponer_rotaciones')).
annotate(deterministic('$rango_jornadas')).
annotate(deterministic('$establecer_dominios')).
annotate(deterministic('$etiquetar')).
annotate(deterministic('$extraer')).
annotate(deterministic('$m0_0')).
annotate(deterministic('$m1_24')).
annotate(deterministic('$m2_14')).
annotate(deterministic('$m3_14')).
annotate(deterministic('$m4_17')).
annotate(deterministic('$m5_13')).
annotate(deterministic('$m6_6')).
annotate(deterministic('$m7_6')).
annotate(deterministic('$m8_0')).
annotate(deterministic('$duracion\'')).
annotate(deterministic('$duracion')).
annotate(deterministic('$horasTrabajador')).
annotate(deterministic('$trabajoMes')).
annotate(deterministic('$hm')).
annotate(deterministic('$horasMesTrabajador')).
annotate(deterministic('$horasCadaMes')).
annotate(deterministic('$horasCadaAnio')).
annotate(deterministic('$obtenerMes')).
annotate(deterministic('$calcularMesUltimo')).
annotate(deterministic('$numeroMes')).
annotate(deterministic('$horasAnio')).
annotate(deterministic('$sig_laborable')).
annotate(deterministic('$sig_festivo')).
annotate(deterministic('$extrayendo2')).
annotate(deterministic('$extraer_turnos2')).
annotate(deterministic('$escribir_lab')).
annotate(deterministic('$escribir_laborables')).
annotate(deterministic('$escribir_fes')).
annotate(deterministic('$escribir_festivos')).
annotate(deterministic('$establecer_des')).
annotate(deterministic('$establecer_descanso')).
annotate(deterministic('$primera_sol')).
annotate(deterministic('$apuntar')).
annotate(deterministic('$actividad_comodin')).
annotate(deterministic('$primera_sol_act')).
annotate(deterministic('$reapuntar')).
annotate(deterministic('$j2esj1')).
annotate(deterministic('$intentar')).
annotate(deterministic('$elemento')).
annotate(deterministic('$div\'')).
annotate(deterministic('$sustituir')).
annotate(deterministic('$ultimo')).
annotate(deterministic('$n_menos_1')).
annotate(deterministic('$invertir')).
annotate(deterministic('$card')).
annotate(deterministic('$eliminar')).
annotate(deterministic('$ini')).
annotate(deterministic('$iniln')).


% varList(+List,-ListVars): ListVars is a list with all the variables from
% terms in List  that can avoid the cut if they are bound
% Each variable occurrs only once in ListVars.
varList(ListTerms,ListVars) :- varList(ListTerms,[],ListVars),!.

% varList(+List,+LI, -LO): Analagous to varList/2 but with LI
% the list of variables accumulated at the moment.
varList([],ListVars,ListVars) :- !.
varList([X|Xs],LI,LO) :- varListTerm(X,LI,LO1),
                         varList(Xs,LO1,LO).
% varListTerm(+Term,+LI,-LO) : Analogous to varList/3 but for a single term
varListTerm(T,L,L)       :- atomic(T),!.
varListTerm(V,LI,LI)     :- var(V), varInList(V,LI),!.
varListTerm(V,LI,[V|LI]) :- var(V),!.

% evaluated suspension: check the result
varListTerm('$$susp'(_F,_Args,R,S),LI,LO) :- \+var(S),
                                             !,
                                             varListTerm(R,LI,LO).

% non-evaluated suspension: collect the variables of the arguments, and
% the variable determining if it is evaluated if it is non-deterministic
varListTerm('$$susp'(F,Args,_R,S),LI,LO) :- varList(Args,LI,LO1),
                                           (
                                             \+annotate(deterministic(F)),
                                             \+varInList(S,LO1),
                                             LO=[S|LO1]
                                               ;
                                             LO = LO1
                                           ),
                                           !.
% rest of the possibilities
varListTerm(Term,LI,LO):- Term =.. [F|Args],
varListTerm(F,LI,LO1),
varList(Args,LO1,LO).

% varInList(+V,+L)
% Checks if the var V occurrs in the list L
varInList(V,[R|_L]) :- V==R,!.
varInList(V,[_R|L]) :- varInList(V,L).
% checkVarList(L): Checks if the input list contains different variables
checkVarList([]) :- !.
checkVarList([X|Xs]) :- var(X), \+varInList(X,Xs), checkVarList(Xs).


/***********   CONSTRUCTORS AND FUNCTIONS   ***********/

constr(',', 2, ->(_A, ->(_B, ','(_A, _B))), ','(_A, _B)).
constr('$$tup', 1, ->(','(_A, _B), '$$tuple'(','(_A, _B))), '$$tuple'(','(_A, _B))).
constr([], 0, :(_A, []), :(_A, [])).
constr(:, 2, ->(_A, ->(:(_A, []), :(_A, []))), :(_A, [])).
constr('$char', 1, ->(_A, char), char).
constr('$io', 1, ->(_A, '$io'(_A)), '$io'(_A)).
constr('$stream', 1, handle, handle).
constr(readMode, 0, ioMode, ioMode).
constr(writeMode, 0, ioMode, ioMode).
constr(appendMode, 0, ioMode, ioMode).
constr('$channel', 2, channel, channel).
constr('$varmut', 1, varmut, varmut).
constr(pValBottom, 0, pVal, pVal).
constr(pValChar, 1, ->(char, pVal), pVal).
constr(pValNum, 1, ->(:(char, []), pVal), pVal).
constr(pValVar, 1, ->(:(char, []), pVal), pVal).
constr(pValApp, 2, ->(:(char, []), ->(:(pVal, []), pVal)), pVal).
constr(constraint, 1, ->(:(atomicConstraint, []), constraint), constraint).
constr(atomicConstraint, 3, ->(:(char, []), ->(:(pVal, []), ->(pVal, atomicConstraint))), atomicConstraint).
constr(cTreeNode, 7, ->(:(char, []), ->(:(pVal, []), ->(pVal, ->(:(char, []), ->(:(pVal, []), ->(:(char, []), ->(:('$$tuple'(','(pVal, cTree)), []), cTree))))))), cTree).
constr(cTreeVoid, 0, cTree, cTree).
constr(ff, 0, labelingType, labelingType).
constr(ffc, 0, labelingType, labelingType).
constr(leftmost, 0, labelingType, labelingType).
constr(mini, 0, labelingType, labelingType).
constr(maxi, 0, labelingType, labelingType).
constr(step, 0, labelingType, labelingType).
constr(enum, 0, labelingType, labelingType).
constr(bisect, 0, labelingType, labelingType).
constr(up, 0, labelingType, labelingType).
constr(down, 0, labelingType, labelingType).
constr(each, 0, labelingType, labelingType).
constr(toMinimize, 1, ->('$num'(int), labelingType), labelingType).
constr(toMaximize, 1, ->('$num'(int), labelingType), labelingType).
constr(assumptions, 1, ->('$num'(int), labelingType), labelingType).
constr(value, 0, reasoning, reasoning).
constr(domains, 0, reasoning, reasoning).
constr(range, 0, reasoning, reasoning).
constr(on, 1, ->(reasoning, allDiffOptions), allDiffOptions).
constr(complete, 1, ->(bool, allDiffOptions), allDiffOptions).
constr(d, 1, ->('$$tuple'(','('$num'(int), ','('$num'(int), liftedInt))), typeprecedence), typeprecedence).
constr(superior, 0, liftedInt, liftedInt).
constr(lift, 1, ->('$num'(int), liftedInt), liftedInt).
constr(precedences, 1, ->(:(typeprecedence, []), serialOptions), serialOptions).
constr(path_consistency, 1, ->(bool, serialOptions), serialOptions).
constr(static_sets, 1, ->(bool, serialOptions), serialOptions).
constr(edge_finder, 1, ->(bool, serialOptions), serialOptions).
constr(decomposition, 1, ->(bool, serialOptions), serialOptions).
constr(cte, 2, ->('$num'(int), ->('$num'(int), range)), range).
constr(uni, 2, ->(range, ->(range, range)), range).
constr(inter, 2, ->(range, ->(range, range)), range).
constr(compl, 1, ->(range, range), range).
constr(interval, 2, ->('$num'(int), ->('$num'(int), fdinterval)), fdinterval).
constr(resumptions, 0, statistics, statistics).
constr(entailments, 0, statistics, statistics).
constr(prunings, 0, statistics, statistics).
constr(backtracks, 0, statistics, statistics).
constr(constraints, 0, statistics, statistics).
constr(domm, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(minn, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(maxx, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(minmax, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(vall, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(true, 0, bool, bool).
constr(false, 0, bool, bool).

funct(uminus, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(abs, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(sqrt, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(ln, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(exp, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(coth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acoth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(evalfd, 2, 2, ->(:(char, []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(+, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(-, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(*, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(min, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(max, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(/, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(float))), '$num'(float)).
funct(**, 2, 2, ->('$num'(_A), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(log, 2, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(^, 2, 2, ->('$num'(_A), ->('$num'(int), '$num'(_A))), '$num'(_A)).
funct(div, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(mod, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(gcd, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(round, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(trunc, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(floor, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(ceiling, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(toReal, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(<, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(<=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(==, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(/=, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(ord, 1, 1, ->(char, '$num'(int)), '$num'(int)).
funct(chr, 1, 1, ->('$num'(int), char), char).
funct(putChar, 1, 1, ->(char, io(unit)), io(unit)).
funct(done, 0, 0, io(unit), io(unit)).
funct(getChar, 0, 0, io(char), io(char)).
funct(return, 1, 1, ->(_A, io(_A)), io(_A)).
funct(>>, 2, 2, ->(io(_A), ->(io(_B), io(_B))), io(_B)).
funct(>>=, 2, 2, ->(io(_A), ->(->(_A, io(_B)), io(_B))), io(_B)).
funct(putStr, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(putStrLn, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(getLine, 0, 0, io(:(char, [])), io(:(char, []))).
funct(cont1, 1, 1, ->(char, io(:(char, []))), io(:(char, []))).
funct(cont2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).
funct(writeFile, 2, 2, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(readFile, 1, 1, ->(:(char, []), io(:(char, []))), io(:(char, []))).
funct(readFileContents, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(dVal, 1, 1, ->(_A, pVal), pVal).
funct(dValToString, 1, 1, ->(_A, :(char, [])), :(char, [])).
funct(getConstraintStore, 1, 1, ->(:(_A, []), constraint), constraint).
funct(selectWhereVariableXi, 4, 4, ->(_A, ->('$num'(int), ->('$num'(int), ->(_B, _C)))), _C).
funct(fails, 1, 1, ->(_A, bool), bool).
funct(once, 1, 1, ->(_A, _A), _A).
funct(collect, 1, 1, ->(_A, :(_A, [])), :(_A, [])).
funct(collectN, 2, 2, ->('$num'(int), ->(_A, :(_A, []))), :(_A, [])).
funct(if_then_else, 3, 3, ->(bool, ->(_A, ->(_A, _A))), _A).
funct(if_then, 2, 2, ->(bool, ->(_A, _A)), _A).
funct(flip, 3, 3, ->(->(_A, ->(_B, _C)), ->(_B, ->(_A, _C))), _C).
funct(minimize, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(maximize, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(bb_minimize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).
funct(bb_maximize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).

funct('$apply', 2, 2, ->(->(->(_A, _B), _A), _B), _B).
funct('$eqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct('$notEqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct(init_fd, 0, 0, '$num'(int), '$num'(int)).
funct(write, 1, 1, ->(_A, bool), bool).
funct(nl, 0, 0, bool, bool).
funct(#==, 2, 2, ->('$num'(int), ->('$num'(float), bool)), bool).
funct(#/==, 2, 2, ->('$num'(int), ->('$num'(float), bool)), bool).
funct(domain, 3, 3, ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), bool))), bool).
funct(subset, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(inset, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(setcomplement, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(intersect, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(belongs, 2, 2, ->('$num'(int), ->(:('$num'(int), []), bool)), bool).
funct(labeling, 2, 2, ->(:(labelingType, []), ->(:('$num'(int), []), bool)), bool).
funct(indomain, 1, 1, ->('$num'(int), bool), bool).
funct(fdminimize, 2, 2, ->(bool, ->('$num'(int), bool)), bool).
funct(fdmaximize, 2, 2, ->(bool, ->('$num'(int), bool)), bool).
funct(#=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#\=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#<, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#<=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#>, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#>=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#+, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#-, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#*, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#/, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#&, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(sum, 3, 3, ->(:('$num'(int), []), ->(->('$num'(int), ->('$num'(int), bool)), ->('$num'(int), bool))), bool).
funct(scalar_product, 4, 4, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(->('$num'(int), ->('$num'(int), bool)), ->('$num'(int), bool)))), bool).
funct(all_different, 1, 1, ->(:('$num'(int), []), bool), bool).
funct('all_different\'', 2, 2, ->(:('$num'(int), []), ->(:(allDiffOptions, []), bool)), bool).
funct(assignment, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct(circuit, 1, 1, ->(:('$num'(int), []), bool), bool).
funct('circuit\'', 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct(count, 4, 4, ->('$num'(int), ->(:('$num'(int), []), ->(->('$num'(int), ->('$num'(int), bool)), ->('$num'(int), bool)))), bool).
funct(element, 3, 3, ->('$num'(int), ->(:('$num'(int), []), ->('$num'(int), bool))), bool).
funct(exactly, 3, 3, ->('$num'(int), ->(:('$num'(int), []), ->('$num'(int), bool))), bool).
funct(serialized, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct('serialized\'', 3, 3, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:(serialOptions, []), bool))), bool).
funct(cumulative, 4, 4, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), bool)))), bool).
funct('cumulative\'', 5, 5, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), ->(:(serialOptions, []), bool))))), bool).
funct(#\/, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(#<=>, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(#=>, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(fd_var, 1, 1, ->('$num'(int), bool), bool).
funct(fd_min, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_max, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_size, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_set, 1, 1, ->('$num'(int), :(fdinterval, [])), :(fdinterval, [])).
funct(fd_dom, 1, 1, ->('$num'(int), range), range).
funct(fd_degree, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_neighbors, 1, 1, ->('$num'(int), :('$num'(int), [])), :('$num'(int), [])).
funct(fd_closure, 1, 1, ->(:('$num'(int), []), :('$num'(int), [])), :('$num'(int), [])).
funct(inf, 0, 0, '$num'(int), '$num'(int)).
funct(sup, 0, 0, '$num'(int), '$num'(int)).
funct(is_fdset, 1, 1, ->(:(fdinterval, []), bool), bool).
funct(empty_fdset, 1, 1, ->(:(fdinterval, []), bool), bool).
funct(fdset_parts, 3, 3, ->('$num'(int), ->('$num'(int), ->(:(fdinterval, []), :(fdinterval, [])))), :(fdinterval, [])).
funct(fdset_split, 1, 1, ->(:(fdinterval, []), '$$tuple'(','('$num'(int), ','('$num'(int), :(fdinterval, []))))), '$$tuple'(','('$num'(int), ','('$num'(int), :(fdinterval, []))))).
funct(empty_interval, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(fdset_to_interval, 1, 1, ->(:(fdinterval, []), '$$tuple'(','('$num'(int), '$num'(int)))), '$$tuple'(','('$num'(int), '$num'(int)))).
funct(interval_to_fdset, 2, 2, ->('$num'(int), ->('$num'(int), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_singleton, 2, 2, ->(:(fdinterval, []), ->('$num'(int), bool)), bool).
funct(fdset_min, 1, 1, ->(:(fdinterval, []), '$num'(int)), '$num'(int)).
funct(fdset_max, 1, 1, ->(:(fdinterval, []), '$num'(int)), '$num'(int)).
funct(fdset_size, 1, 1, ->(:(fdinterval, []), '$num'(int)), '$num'(int)).
funct(list_to_fdset, 1, 1, ->(:('$num'(int), []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdset_to_list, 1, 1, ->(:(fdinterval, []), :('$num'(int), [])), :('$num'(int), [])).
funct(range_to_fdset, 1, 1, ->(range, :(fdinterval, [])), :(fdinterval, [])).
funct(fdset_to_range, 1, 1, ->(:(fdinterval, []), range), range).
funct(fdset_add_element, 2, 2, ->(:(fdinterval, []), ->('$num'(int), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_del_element, 2, 2, ->(:(fdinterval, []), ->('$num'(int), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_intersection, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_subtract, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_union, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_complement, 1, 1, ->(:(fdinterval, []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdsets_intersection, 1, 1, ->(:(:(fdinterval, []), []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdsets_union, 1, 1, ->(:(:(fdinterval, []), []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdset_equal, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_subset, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_disjoint, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_intersect, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_member, 2, 2, ->('$num'(int), ->(:(fdinterval, []), bool)), bool).
funct(fdset_belongs, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(isin, 2, 2, ->('$num'(int), ->('$$tuple'(','('$num'(int), '$num'(int))), bool)), bool).
funct(minimum, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_statistics, 0, 0, bool, bool).
funct('fd_statistics\'', 1, 1, ->(statistics, '$num'(int)), '$num'(int)).
funct(fd_global, 3, 3, ->(bool, ->(_A, ->(:(wakeOptions, []), bool))), bool).
funct(end_fd, 0, 0, '$num'(int), '$num'(int)).
funct(and, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(or, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(/\, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(\/, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(not, 1, 1, ->(bool, bool), bool).
funct(andL, 0, 1, ->(:(bool, []), bool), bool).
funct(orL, 0, 1, ->(:(bool, []), bool), bool).
funct('orL\'', 0, 1, ->(:(bool, []), bool), bool).
funct(any, 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct('any\'', 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct(all, 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct(undefined, 0, 0, _A, _A).
funct(def, 1, _A, ->(_B, bool), bool).
funct(not_undef, 1, _A, ->(_B, bool), bool).
funct(nf, 1, _A, ->(_B, _B), _B).
funct(hnf, 1, _A, ->(_B, _B), _B).
funct(strict, 2, _A, ->(->(_B, _C), ->(_B, _C)), _C).
funct('strict\'', 2, _A, ->(->(_B, _C), ->(_B, _C)), _C).
funct(map, 2, 2, ->(->(_A, _B), ->(:(_A, []), :(_B, []))), :(_B, [])).
funct('.', 3, 3, ->(->(_A, _B), ->(->(_C, _A), ->(_C, _B))), _B).
funct(++, 2, 2, ->(:(_A, []), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct('!!', 2, 2, ->(:(_A, []), ->('$num'(int), _A)), _A).
funct(iterate, 2, 2, ->(->(_A, _A), ->(_A, :(_A, []))), :(_A, [])).
funct(repeat, 1, 1, ->(_A, :(_A, [])), :(_A, [])).
funct(copy, 2, 2, ->('$num'(int), ->(_A, :(_A, []))), :(_A, [])).
funct(filter, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(foldl, 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), _A))), _A).
funct(foldl1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), _A)), _A).
funct('foldl\'', 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), _A))), _A).
funct(scanl, 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), :(_A, [])))), :(_A, [])).
funct(scanl1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct('scanl\'', 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), :(_A, [])))), :(_A, [])).
funct(foldr, 3, 3, ->(->(_A, ->(_B, _B)), ->(_B, ->(:(_A, []), _B))), _B).
funct(foldr1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), _A)), _A).
funct(scanr, 3, 3, ->(->(_A, ->(_B, _B)), ->(_B, ->(:(_A, []), :(_B, [])))), :(_B, [])).
funct(auxForScanr, 3, _A, ->(->(_B, ->(_C, _C)), ->(_B, ->(:(_C, []), :(_C, [])))), :(_C, [])).
funct(scanr1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(take, 2, 2, ->('$num'(int), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(drop, 2, 2, ->('$num'(int), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(splitAt, 2, 2, ->('$num'(int), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(auxForSplitAt, 2, _A, ->(_B, ->('$$tuple'(','(:(_B, []), _C)), '$$tuple'(','(:(_B, []), _C)))), '$$tuple'(','(:(_B, []), _C))).
funct(takeWhile, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(takeUntil, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(dropWhile, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(span, 2, 2, ->(->(_A, bool), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(auxForSpan, 2, _A, ->(_B, ->('$$tuple'(','(:(_B, []), _C)), '$$tuple'(','(:(_B, []), _C)))), '$$tuple'(','(:(_B, []), _C))).
funct(break, 1, 2, ->(->(_A, bool), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(zipWith, 3, 3, ->(->(_A, ->(_B, _C)), ->(:(_A, []), ->(:(_B, []), :(_C, [])))), :(_C, [])).
funct(zip, 2, 2, ->(:(_A, []), ->(:(_B, []), :('$$tuple'(','(_A, _B)), []))), :('$$tuple'(','(_A, _B)), [])).
funct(mkpair, 2, 2, ->(_A, ->(_B, '$$tuple'(','(_A, _B)))), '$$tuple'(','(_A, _B))).
funct(unzip, 1, 1, ->(:('$$tuple'(','(_A, _B)), []), '$$tuple'(','(:(_A, []), :(_B, [])))), '$$tuple'(','(:(_A, []), :(_B, [])))).
funct(auxForUnzip, 3, _A, ->(_B, ->(_C, ->('$$tuple'(','(:(_B, []), :(_C, []))), '$$tuple'(','(:(_B, []), :(_C, [])))))), '$$tuple'(','(:(_B, []), :(_C, [])))).
funct(until, 3, 3, ->(->(_A, bool), ->(->(_A, _A), ->(_A, _A))), _A).
funct('until\'', 2, 3, ->(->(_A, bool), ->(->(_A, _A), ->(_A, :(_A, [])))), :(_A, [])).
funct(const, 2, 2, ->(_A, ->(_B, _A)), _A).
funct(id, 1, 1, ->(_A, _A), _A).
funct(//, 2, 2, ->(_A, ->(_A, _A)), _A).
funct(curry, 3, 3, ->(->('$$tuple'(','(_A, _B)), _C), ->(_A, ->(_B, _C))), _C).
funct(uncurry, 2, 2, ->(->(_A, ->(_B, _C)), ->('$$tuple'(','(_A, _B)), _C)), _C).
funct(fst, 1, 1, ->('$$tuple'(','(_A, _B)), _A), _A).
funct(snd, 1, 1, ->('$$tuple'(','(_A, _B)), _B), _B).
funct(fst3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _A), _A).
funct(snd3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _B), _B).
funct(thd3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _C), _C).
funct(subtract, 0, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(even, 1, 1, ->('$num'(int), bool), bool).
funct(odd, 0, 1, ->('$num'(int), bool), bool).
funct(lcm, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(head, 1, 1, ->(:(_A, []), _A), _A).
funct(last, 1, 1, ->(:(_A, []), _A), _A).
funct(tail, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(init, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(nub, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(length, 1, 1, ->(:(_A, []), '$num'(int)), '$num'(int)).
funct(size, 0, 1, ->(:(_A, []), '$num'(int)), '$num'(int)).
funct(reverse, 0, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(member, 0, 2, ->(_A, ->(:(_A, []), bool)), bool).
funct(notMember, 0, 2, ->(_A, ->(:(_A, []), bool)), bool).
funct(concat, 0, 1, ->(:(:(_A, []), []), :(_A, [])), :(_A, [])).
funct(transpose, 0, 1, ->(:(:(_A, []), []), :(:(_A, []), [])), :(:(_A, []), [])).
funct(auxForTranspose, 2, _A, ->(:(_B, []), ->(:(:(_B, []), []), :(:(_B, []), []))), :(:(_B, []), [])).
funct(\\, 0, 2, ->(:(_A, []), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(del, 2, _A, ->(:(_B, []), ->(_B, :(_B, []))), :(_B, [])).
funct(incidencias, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), ','('$num'(_D), '$num'(_E))))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), ','('$num'(_D), '$num'(_E))))), [])).
funct(unasemana, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(unmes, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(dosmeses, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(tresmeses, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(cuatromeses, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(cincomeses, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(seismeses, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(ochomeses, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(diezmeses, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(anio, 0, _A, :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), []), :('$$tuple'(','('$num'(_B), ','('$num'(_C), '$num'(_D)))), [])).
funct(laborable, 0, _A, '$num'(_B), '$num'(_B)).
funct(festivo, 0, _A, '$num'(_B), '$num'(_B)).
funct(especial, 0, _A, '$num'(_B), '$num'(_B)).
funct(no, 0, _A, '$num'(_B), '$num'(_B)).
funct(t1, 0, _A, '$num'(_B), '$num'(_B)).
funct(t2, 0, _A, '$num'(_B), '$num'(_B)).
funct(t3, 0, _A, '$num'(_B), '$num'(_B)).
funct(t4, 0, _A, '$num'(_B), '$num'(_B)).
funct(t5, 0, _A, '$num'(_B), '$num'(_B)).
funct(t6, 0, _A, '$num'(_B), '$num'(_B)).
funct(bj, 0, _A, '$num'(_B), '$num'(_B)).
funct(vc, 0, _A, '$num'(_B), '$num'(_B)).
funct(grupo_activo, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(incrementar, 2, 2, ->(:('$num'(int), []), ->('$num'(int), :('$num'(int), []))), :('$num'(int), [])).
funct(crear_incidencias, 3, 3, ->('$num'(int), ->(:('$num'(int), []), ->(:('$num'(int), []), :('$num'(int), [])))), :('$num'(int), [])).
funct(proc_incidencia, 2, 2, ->(:('$num'(int), []), ->('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), :('$num'(int), []))), :('$num'(int), [])).
funct(inicio, 1, 1, ->('$num'(int), :('$num'(int), [])), :('$num'(int), [])).
funct(incidencias_dia, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(proc_vacaciones, 2, 2, ->(:('$num'(int), []), ->('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), :('$num'(int), []))), :('$num'(int), [])).
funct(vacaciones_dia, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(proc_bajas, 2, 2, ->(:('$num'(int), []), ->('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), :('$num'(int), []))), :('$num'(int), [])).
funct(bajas_dia, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(crear_grupos, 2, 2, ->('$num'(int), ->('$num'(int), :('$num'(int), []))), :('$num'(int), [])).
funct(solicitaNoche, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$num'(int), []), :(bool, []))), :(bool, [])).
funct(puedeNoche, 1, 1, ->(:(bool, []), :(bool, [])), :(bool, [])).
funct(t13trabaja_noche, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$num'(int), []), :(bool, []))), :(bool, [])).
funct(j1, 0, _A, '$num'(_B), '$num'(_B)).
funct(j2, 0, _A, '$num'(_B), '$num'(_B)).
funct(j3, 0, _A, '$num'(_B), '$num'(_B)).
funct(j4, 0, _A, '$num'(_B), '$num'(_B)).
funct(crear_plan_jornadas, 3, 3, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$num'(int), []), ->(:(bool, []), :('$num'(int), [])))), :('$num'(int), [])).
funct(crear_trabajo, 1, 1, ->('$num'(int), :('$num'(int), [])), :('$num'(int), [])).
funct(crear_planificacion, 2, 2, ->('$num'(int), ->('$num'(int), :(:('$num'(int), []), []))), :(:('$num'(int), []), [])).
funct(borrar_uno, 1, 1, ->(:('$num'(int), []), :('$num'(int), [])), :('$num'(int), [])).
funct(quitar_primeros, 1, 1, ->(:(:('$num'(int), []), []), :(:('$num'(int), []), [])), :(:('$num'(int), []), [])).
funct(prim, 1, 1, ->(:('$num'(int), []), '$num'(int)), '$num'(int)).
funct(primeros, 1, 1, ->(:(:('$num'(int), []), []), :('$num'(int), [])), :('$num'(int), [])).
funct(listas_vacias, 1, 1, ->(:(:('$num'(int), []), []), bool), bool).
funct(transponer, 1, 1, ->(:(:('$num'(int), []), []), :(:('$num'(int), []), [])), :(:('$num'(int), []), [])).
funct(crear_fila, 1, 1, ->('$num'(int), :('$num'(int), [])), :('$num'(int), [])).
funct(crear_tabla, 2, 2, ->('$num'(int), ->('$num'(int), :(:('$num'(int), []), []))), :(:('$num'(int), []), [])).
funct(anotar_en_trabajador, 2, 2, ->(:('$num'(int), []), ->('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), :('$num'(int), []))), :('$num'(int), [])).
funct(anotar_una, 2, 2, ->(:(:('$num'(int), []), []), ->('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), :(:('$num'(int), []), []))), :(:('$num'(int), []), [])).
funct(anotar_incidencias, 2, 2, ->(:(:('$num'(int), []), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), []), :(:('$num'(int), []), []))), :(:('$num'(int), []), [])).
funct(procesar_jornadas, 6, 6, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), bool)))))), bool).
funct(contar, 2, 2, ->('$num'(int), ->(:('$num'(int), []), '$num'(int))), '$num'(int)).
funct(empaquetar, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), :('$$tuple'(','('$num'(int), '$num'(int))), []))), :('$$tuple'(','('$num'(int), '$num'(int))), [])).
funct(proyectar, 1, 1, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), :('$num'(int), [])), :('$num'(int), [])).
funct(anotar_trab, 1, 1, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), :('$num'(int), [])), :('$num'(int), [])).
funct(anotar_desc, 1, 1, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), :('$num'(int), [])), :('$num'(int), [])).
funct(descansar, 4, 4, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), ->('$num'(int), ->('$num'(int), ->(:('$num'(int), []), :('$$tuple'(','('$num'(int), '$num'(int))), []))))), :('$$tuple'(','('$num'(int), '$num'(int))), [])).
funct(trabajar, 4, 4, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), ->('$num'(int), ->('$num'(int), ->(:('$num'(int), []), :('$$tuple'(','('$num'(int), '$num'(int))), []))))), :('$$tuple'(','('$num'(int), '$num'(int))), [])).
funct(grupo, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(procesar_tipo_dia, 4, 4, ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), ->('$num'(int), :('$num'(int), []))))), :('$num'(int), [])).
funct(procesar_dia, 7, 7, ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), ->('$num'(int), :('$num'(int), [])))))))), :('$num'(int), [])).
funct(procesar_trabajo, 7, 7, ->(:(:('$num'(int), []), []), ->(:(:('$num'(int), []), []), ->('$num'(int), ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$num'(int), []), :(:('$num'(int), []), [])))))))), :(:('$num'(int), []), [])).
funct(trab_comodin, 4, 4, ->('$num'(int), ->('$num'(int), ->('$num'(int), ->('$num'(int), '$num'(int))))), '$num'(int)).
funct(trabajar_comodin, 4, 4, ->(:('$num'(int), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$num'(int), []), ->(:('$num'(int), []), :('$num'(int), []))))), :('$num'(int), [])).
funct(proc_t6, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(sin_t6, 1, 1, ->(:('$num'(int), []), :('$num'(int), [])), :('$num'(int), [])).
funct(no_t6, 1, 1, ->(:(:('$num'(int), []), []), :(:('$num'(int), []), [])), :(:('$num'(int), []), [])).
funct(valido_laborables, 1, 1, ->(:('$num'(int), []), bool), bool).
funct(valido_festivos, 1, 1, ->(:('$num'(int), []), bool), bool).
funct(extrayendo, 4, 4, ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), :('$$tuple'(','('$num'(int), '$num'(int))), []))))), :('$$tuple'(','('$num'(int), '$num'(int))), [])).
funct(extraer_turnos, 3, 3, ->(:(:('$num'(int), []), []), ->(:('$num'(int), []), ->(:('$num'(int), []), :(:('$$tuple'(','('$num'(int), '$num'(int))), []), [])))), :(:('$$tuple'(','('$num'(int), '$num'(int))), []), [])).
funct(sacar_laborables, 1, 1, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), :('$num'(int), [])), :('$num'(int), [])).
funct(extraer_laborables, 1, 1, ->(:(:('$$tuple'(','('$num'(int), '$num'(int))), []), []), :(:('$num'(int), []), [])), :(:('$num'(int), []), [])).
funct(sacar_festivos, 1, 1, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), :('$num'(int), [])), :('$num'(int), [])).
funct(extraer_festivos, 1, 1, ->(:(:('$$tuple'(','('$num'(int), '$num'(int))), []), []), :(:('$num'(int), []), [])), :(:('$num'(int), []), [])).
funct(rotar_turnos_laborables, 1, 1, ->(:(:('$num'(int), []), []), bool), bool).
funct(rotar_turnos_festivos, 1, 1, ->(:(:('$num'(int), []), []), bool), bool).
funct(imponer_rotaciones, 3, 3, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:(:('$num'(int), []), []), :(:('$num'(int), []), [])))), :(:('$num'(int), []), [])).
funct(rango_jornadas, 1, 1, ->(:('$num'(int), []), bool), bool).
funct(establecer_dominios, 1, 1, ->(:(:('$num'(int), []), []), bool), bool).
funct(etiquetar, 2, 2, ->(:(:('$num'(int), []), []), ->(:(labelingType, []), bool)), bool).
funct(extraer, 1, 1, ->(:(:('$num'(int), []), []), :('$num'(int), [])), :('$num'(int), [])).
funct('etiquetar\'', 2, 2, ->(:(:('$num'(int), []), []), ->(:(:('$num'(int), []), []), bool)), bool).
funct(m0_0, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m1_24, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m2_14, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m3_14, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m4_17, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m5_13, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m6_6, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m7_6, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(m8_0, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct('duracion\'', 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(duracion, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(horasTrabajador, 1, 1, ->(:('$num'(int), []), '$num'(int)), '$num'(int)).
funct(trabajoMes, 3, 3, ->(:('$num'(int), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->('$num'(int), :('$num'(int), [])))), :('$num'(int), [])).
funct(hm, 5, 5, ->(:('$num'(int), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->('$num'(int), ->('$num'(int), ->('$num'(int), bool))))), bool).
funct(horasMesTrabajador, 5, 5, ->(:('$num'(int), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), bool))))), bool).
funct(horasCadaMes, 4, 4, ->(:(:('$num'(int), []), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$num'(int), []), ->('$num'(int), bool)))), bool).
funct(horasCadaAnio, 3, 3, ->(:(:('$num'(int), []), []), ->('$num'(int), ->('$num'(int), bool))), bool).
funct(obtenerMes, 1, 1, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), '$num'(int)), '$num'(int)).
funct(calcularMesUltimo, 1, 1, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), '$num'(int)), '$num'(int)).
funct(numeroMes, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(horasMes, 3, 3, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->('$num'(int), ->('$num'(int), :('$num'(int), [])))), :('$num'(int), [])).
funct(horasAnio, 1, 1, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), '$num'(int)), '$num'(int)).
funct(planificar, 3, 3, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), []), ->(:(labelingType, []), :(:('$num'(int), []), [])))), :(:('$num'(int), []), [])).
funct(sig_laborable, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(sig_festivo, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(extrayendo2, 4, 4, ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), :('$$tuple'(','('$num'(int), '$num'(int))), []))))), :('$$tuple'(','('$num'(int), '$num'(int))), [])).
funct(extraer_turnos2, 3, 3, ->(:(:('$num'(int), []), []), ->(:('$num'(int), []), ->(:('$num'(int), []), :(:('$$tuple'(','('$num'(int), '$num'(int))), []), [])))), :(:('$$tuple'(','('$num'(int), '$num'(int))), []), [])).
funct(escribir_lab, 2, 2, ->(:('$num'(int), []), ->('$num'(int), bool)), bool).
funct(escribir_laborables, 2, 2, ->(:(:('$num'(int), []), []), ->('$num'(int), bool)), bool).
funct(escribir_fes, 2, 2, ->(:('$num'(int), []), ->('$num'(int), bool)), bool).
funct(escribir_festivos, 2, 2, ->(:(:('$num'(int), []), []), ->('$num'(int), bool)), bool).
funct(establecer_des, 3, 3, ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), :('$num'(int), [])))), :('$num'(int), [])).
funct(establecer_descanso, 2, 2, ->(:(:('$num'(int), []), []), ->(:('$num'(int), []), :(:('$num'(int), []), []))), :(:('$num'(int), []), [])).
funct(primera_sol, 3, 3, ->(:(:('$num'(int), []), []), ->(:('$num'(int), []), ->(:('$num'(int), []), :(:('$num'(int), []), [])))), :(:('$num'(int), []), [])).
funct(apuntar, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(actividad_comodin, 5, 5, ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), ->(:('$num'(int), []), ->('$num'(int), '$num'(int)))))), '$num'(int)).
funct(primera_sol_act, 5, 5, ->(:(:('$num'(int), []), []), ->(:(:('$num'(int), []), []), ->('$num'(int), ->(:('$num'(int), []), ->(:('$num'(int), []), :(:('$num'(int), []), [])))))), :(:('$num'(int), []), [])).
funct(reapuntar, 1, 1, ->(:('$num'(int), []), :('$num'(int), [])), :('$num'(int), [])).
funct(planificar_una, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), []), :(:('$num'(int), []), []))), :(:('$num'(int), []), [])).
funct(j2esj1, 1, 1, ->(:('$num'(int), []), :('$num'(int), [])), :('$num'(int), [])).
funct(inizio, 2, 2, ->(:('$$tuple'(','('$num'(int), ','('$num'(int), '$num'(int)))), []), ->(:('$$tuple'(','('$num'(int), ','('$num'(int), ','('$num'(int), '$num'(int))))), []), :(:('$num'(int), []), []))), :(:('$num'(int), []), [])).
funct(resto, 2, 2, ->('$num'(int), ->('$num'(int), :('$num'(int), []))), :('$num'(int), [])).
funct(generar_lista, 2, 2, ->('$num'(int), ->('$num'(int), :('$num'(int), []))), :('$num'(int), [])).
funct(intentar, 2, 2, ->('$num'(int), ->(:('$num'(int), []), bool)), bool).
funct(mi_busqueda, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct(esNocturno, 1, 1, ->('$num'(int), bool), bool).
funct(elemento, 2, 2, ->('$num'(int), ->(:(_A, []), _A)), _A).
funct(deXhastaY, 2, 2, ->('$num'(int), ->('$num'(int), :('$num'(int), []))), :('$num'(int), [])).
funct('div\'', 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(sustituir, 3, 3, ->(:(_A, []), ->('$num'(int), ->(_A, :(_A, [])))), :(_A, [])).
funct(ultimo, 1, 1, ->(:(_A, []), _A), _A).
funct(n_menos_1, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(invertir, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(card, 1, 1, ->(:(_A, []), '$num'(int)), '$num'(int)).
funct(eliminar, 2, 2, ->(_A, ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(ini, 1, 1, ->(:(char, []), bool), bool).
funct(iniln, 1, 1, ->(:(char, []), bool), bool).

/************    CODE FOR FUNCIONS HNF    ************/

hnf_susp('$uminus', '.'(_A, []), _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
hnf_susp('$abs', '.'(_A, []), _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
hnf_susp('$sqrt', '.'(_A, []), _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
hnf_susp('$ln', '.'(_A, []), _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
hnf_susp('$exp', '.'(_A, []), _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
hnf_susp('$sin', '.'(_A, []), _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
hnf_susp('$cos', '.'(_A, []), _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
hnf_susp('$tan', '.'(_A, []), _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
hnf_susp('$cot', '.'(_A, []), _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
hnf_susp('$asin', '.'(_A, []), _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
hnf_susp('$acos', '.'(_A, []), _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
hnf_susp('$atan', '.'(_A, []), _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
hnf_susp('$acot', '.'(_A, []), _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
hnf_susp('$sinh', '.'(_A, []), _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
hnf_susp('$cosh', '.'(_A, []), _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
hnf_susp('$tanh', '.'(_A, []), _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
hnf_susp('$coth', '.'(_A, []), _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
hnf_susp('$asinh', '.'(_A, []), _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
hnf_susp('$acosh', '.'(_A, []), _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
hnf_susp('$atanh', '.'(_A, []), _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
hnf_susp('$acoth', '.'(_A, []), _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
hnf_susp('$evalfd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
hnf_susp($+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
hnf_susp($-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
hnf_susp($*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
hnf_susp('$min', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
hnf_susp('$max', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
hnf_susp($/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
hnf_susp($**, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
hnf_susp('$log', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
hnf_susp($^, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
hnf_susp('$div', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
hnf_susp('$mod', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
hnf_susp('$gcd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
hnf_susp('$round', '.'(_A, []), _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
hnf_susp('$trunc', '.'(_A, []), _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
hnf_susp('$floor', '.'(_A, []), _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
hnf_susp('$ceiling', '.'(_A, []), _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
hnf_susp('$toReal', '.'(_A, []), _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
hnf_susp($<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
hnf_susp($<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
hnf_susp($>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
hnf_susp($>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
hnf_susp($==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
hnf_susp($/=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
hnf_susp('$ord', '.'(_A, []), _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
hnf_susp('$chr', '.'(_A, []), _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
hnf_susp('$putChar', '.'(_A, []), _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
hnf_susp('$done', [], _A, _B, _C):-
        '$done'(_A, _B, _C).
hnf_susp('$getChar', [], _A, _B, _C):-
        '$getChar'(_A, _B, _C).
hnf_susp('$return', '.'(_A, []), _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
hnf_susp($>>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
hnf_susp($>>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
hnf_susp('$putStr', '.'(_A, []), _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
hnf_susp('$putStrLn', '.'(_A, []), _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
hnf_susp('$getLine', [], _A, _B, _C):-
        '$getLine'(_A, _B, _C).
hnf_susp('$cont1', '.'(_A, []), _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
hnf_susp('$cont2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
hnf_susp('$writeFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
hnf_susp('$readFile', '.'(_A, []), _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
hnf_susp('$readFileContents', '.'(_A, []), _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
hnf_susp('$dVal', '.'(_A, []), _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
hnf_susp('$dValToString', '.'(_A, []), _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
hnf_susp('$getConstraintStore', '.'(_A, []), _B, _C, _D):-
        '$getConstraintStore'(_A, _B, _C, _D).
hnf_susp('$selectWhereVariableXi', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$fails', '.'(_A, []), _B, _C, _D):-
        '$fails'(_A, _B, _C, _D).
hnf_susp('$once', '.'(_A, []), _B, _C, _D):-
        '$once'(_A, _B, _C, _D).
hnf_susp('$collect', '.'(_A, []), _B, _C, _D):-
        '$collect'(_A, _B, _C, _D).
hnf_susp('$collectN', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$collectN'(_A, _B, _C, _D, _E).
hnf_susp('$if_then_else', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
hnf_susp('$if_then', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
hnf_susp('$flip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$minimize', '.'(_A, []), _B, _C, _D):-
        '$minimize'(_A, _B, _C, _D).
hnf_susp('$maximize', '.'(_A, []), _B, _C, _D):-
        '$maximize'(_A, _B, _C, _D).
hnf_susp('$bb_minimize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$bb_minimize'(_A, _B, _C, _D, _E).
hnf_susp('$bb_maximize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$bb_maximize'(_A, _B, _C, _D, _E).
hnf_susp('$$apply', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$apply'(_A, _B, _C, _D, _E).
hnf_susp('$$eqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
hnf_susp('$$notEqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
hnf_susp('$init_fd', [], _A, _B, _C):-
        '$init_fd'(_A, _B, _C).
hnf_susp('$write', '.'(_A, []), _B, _C, _D):-
        '$write'(_A, _B, _C, _D).
hnf_susp('$nl', [], _A, _B, _C):-
        '$nl'(_A, _B, _C).
hnf_susp($#==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#==(_A, _B, _C, _D, _E).
hnf_susp($#/==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#/==(_A, _B, _C, _D, _E).
hnf_susp('$domain', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$domain'(_A, _B, _C, _D, _E, _F).
hnf_susp('$subset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$subset'(_A, _B, _C, _D, _E).
hnf_susp('$inset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$inset'(_A, _B, _C, _D, _E).
hnf_susp('$setcomplement', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$setcomplement'(_A, _B, _C, _D, _E).
hnf_susp('$intersect', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$intersect'(_A, _B, _C, _D, _E).
hnf_susp('$belongs', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$belongs'(_A, _B, _C, _D, _E).
hnf_susp('$labeling', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$labeling'(_A, _B, _C, _D, _E).
hnf_susp('$indomain', '.'(_A, []), _B, _C, _D):-
        '$indomain'(_A, _B, _C, _D).
hnf_susp('$fdminimize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdminimize'(_A, _B, _C, _D, _E).
hnf_susp('$fdmaximize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdmaximize'(_A, _B, _C, _D, _E).
hnf_susp($#=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#=(_A, _B, _C, _D, _E).
hnf_susp($#\=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#\=(_A, _B, _C, _D, _E).
hnf_susp($#<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#<(_A, _B, _C, _D, _E).
hnf_susp($#<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#<=(_A, _B, _C, _D, _E).
hnf_susp($#>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#>(_A, _B, _C, _D, _E).
hnf_susp($#>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#>=(_A, _B, _C, _D, _E).
hnf_susp($#+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#+(_A, _B, _C, _D, _E).
hnf_susp($#-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#-(_A, _B, _C, _D, _E).
hnf_susp($#*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#*(_A, _B, _C, _D, _E).
hnf_susp($#/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#/(_A, _B, _C, _D, _E).
hnf_susp($#&, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#&(_A, _B, _C, _D, _E).
hnf_susp('$sum', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$sum'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scalar_product', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$scalar_product'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$all_different', '.'(_A, []), _B, _C, _D):-
        '$all_different'(_A, _B, _C, _D).
hnf_susp('$all_different\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$all_different\''(_A, _B, _C, _D, _E).
hnf_susp('$assignment', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$assignment'(_A, _B, _C, _D, _E).
hnf_susp('$circuit', '.'(_A, []), _B, _C, _D):-
        '$circuit'(_A, _B, _C, _D).
hnf_susp('$circuit\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$circuit\''(_A, _B, _C, _D, _E).
hnf_susp('$count', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$count'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$element', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$element'(_A, _B, _C, _D, _E, _F).
hnf_susp('$exactly', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$exactly'(_A, _B, _C, _D, _E, _F).
hnf_susp('$serialized', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$serialized'(_A, _B, _C, _D, _E).
hnf_susp('$serialized\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$serialized\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$cumulative', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$cumulative'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$cumulative\'', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$cumulative\''(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp($#\/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#\/(_A, _B, _C, _D, _E).
hnf_susp($#<=>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#<=>(_A, _B, _C, _D, _E).
hnf_susp($#=>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#=>(_A, _B, _C, _D, _E).
hnf_susp('$fd_var', '.'(_A, []), _B, _C, _D):-
        '$fd_var'(_A, _B, _C, _D).
hnf_susp('$fd_min', '.'(_A, []), _B, _C, _D):-
        '$fd_min'(_A, _B, _C, _D).
hnf_susp('$fd_max', '.'(_A, []), _B, _C, _D):-
        '$fd_max'(_A, _B, _C, _D).
hnf_susp('$fd_size', '.'(_A, []), _B, _C, _D):-
        '$fd_size'(_A, _B, _C, _D).
hnf_susp('$fd_set', '.'(_A, []), _B, _C, _D):-
        '$fd_set'(_A, _B, _C, _D).
hnf_susp('$fd_dom', '.'(_A, []), _B, _C, _D):-
        '$fd_dom'(_A, _B, _C, _D).
hnf_susp('$fd_degree', '.'(_A, []), _B, _C, _D):-
        '$fd_degree'(_A, _B, _C, _D).
hnf_susp('$fd_neighbors', '.'(_A, []), _B, _C, _D):-
        '$fd_neighbors'(_A, _B, _C, _D).
hnf_susp('$fd_closure', '.'(_A, []), _B, _C, _D):-
        '$fd_closure'(_A, _B, _C, _D).
hnf_susp('$inf', [], _A, _B, _C):-
        '$inf'(_A, _B, _C).
hnf_susp('$sup', [], _A, _B, _C):-
        '$sup'(_A, _B, _C).
hnf_susp('$is_fdset', '.'(_A, []), _B, _C, _D):-
        '$is_fdset'(_A, _B, _C, _D).
hnf_susp('$empty_fdset', '.'(_A, []), _B, _C, _D):-
        '$empty_fdset'(_A, _B, _C, _D).
hnf_susp('$fdset_parts', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$fdset_parts'(_A, _B, _C, _D, _E, _F).
hnf_susp('$fdset_split', '.'(_A, []), _B, _C, _D):-
        '$fdset_split'(_A, _B, _C, _D).
hnf_susp('$empty_interval', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$empty_interval'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_to_interval', '.'(_A, []), _B, _C, _D):-
        '$fdset_to_interval'(_A, _B, _C, _D).
hnf_susp('$interval_to_fdset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$interval_to_fdset'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_singleton', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_singleton'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_min', '.'(_A, []), _B, _C, _D):-
        '$fdset_min'(_A, _B, _C, _D).
hnf_susp('$fdset_max', '.'(_A, []), _B, _C, _D):-
        '$fdset_max'(_A, _B, _C, _D).
hnf_susp('$fdset_size', '.'(_A, []), _B, _C, _D):-
        '$fdset_size'(_A, _B, _C, _D).
hnf_susp('$list_to_fdset', '.'(_A, []), _B, _C, _D):-
        '$list_to_fdset'(_A, _B, _C, _D).
hnf_susp('$fdset_to_list', '.'(_A, []), _B, _C, _D):-
        '$fdset_to_list'(_A, _B, _C, _D).
hnf_susp('$range_to_fdset', '.'(_A, []), _B, _C, _D):-
        '$range_to_fdset'(_A, _B, _C, _D).
hnf_susp('$fdset_to_range', '.'(_A, []), _B, _C, _D):-
        '$fdset_to_range'(_A, _B, _C, _D).
hnf_susp('$fdset_add_element', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_add_element'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_del_element', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_del_element'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_intersection', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_intersection'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_subtract', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_subtract'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_union', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_union'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_complement', '.'(_A, []), _B, _C, _D):-
        '$fdset_complement'(_A, _B, _C, _D).
hnf_susp('$fdsets_intersection', '.'(_A, []), _B, _C, _D):-
        '$fdsets_intersection'(_A, _B, _C, _D).
hnf_susp('$fdsets_union', '.'(_A, []), _B, _C, _D):-
        '$fdsets_union'(_A, _B, _C, _D).
hnf_susp('$fdset_equal', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_equal'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_subset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_subset'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_disjoint', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_disjoint'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_intersect', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_intersect'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_member', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_member'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_belongs', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_belongs'(_A, _B, _C, _D, _E).
hnf_susp('$isin', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$isin'(_A, _B, _C, _D, _E).
hnf_susp('$minimum', '.'(_A, []), _B, _C, _D):-
        '$minimum'(_A, _B, _C, _D).
hnf_susp('$fd_statistics', [], _A, _B, _C):-
        '$fd_statistics'(_A, _B, _C).
hnf_susp('$fd_statistics\'', '.'(_A, []), _B, _C, _D):-
        '$fd_statistics\''(_A, _B, _C, _D).
hnf_susp('$fd_global', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$fd_global'(_A, _B, _C, _D, _E, _F).
hnf_susp('$end_fd', [], _A, _B, _C):-
        '$end_fd'(_A, _B, _C).
hnf_susp('$and', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$and'(_A, _B, _C, _D, _E).
hnf_susp('$or', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$or'(_A, _B, _C, _D, _E).
hnf_susp($/\, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/\(_A, _B, _C, _D, _E).
hnf_susp($\/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $\/(_A, _B, _C, _D, _E).
hnf_susp('$not', '.'(_A, []), _B, _C, _D):-
        '$not'(_A, _B, _C, _D).
hnf_susp('$andL', [], _A, _B, _C):-
        '$andL'(_A, _B, _C).
hnf_susp('$orL', [], _A, _B, _C):-
        '$orL'(_A, _B, _C).
hnf_susp('$orL\'', [], _A, _B, _C):-
        '$orL\''(_A, _B, _C).
hnf_susp('$any', '.'(_A, []), _B, _C, _D):-
        '$any'(_A, _B, _C, _D).
hnf_susp('$any\'', '.'(_A, []), _B, _C, _D):-
        '$any\''(_A, _B, _C, _D).
hnf_susp('$all', '.'(_A, []), _B, _C, _D):-
        '$all'(_A, _B, _C, _D).
hnf_susp('$undefined', [], _A, _B, _C):-
        '$undefined'(_A, _B, _C).
hnf_susp('$def', '.'(_A, []), _B, _C, _D):-
        '$def'(_A, _B, _C, _D).
hnf_susp('$not_undef', '.'(_A, []), _B, _C, _D):-
        '$not_undef'(_A, _B, _C, _D).
hnf_susp('$nf', '.'(_A, []), _B, _C, _D):-
        '$nf'(_A, _B, _C, _D).
hnf_susp('$hnf', '.'(_A, []), _B, _C, _D):-
        '$hnf'(_A, _B, _C, _D).
hnf_susp('$strict', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$strict'(_A, _B, _C, _D, _E).
hnf_susp('$strict\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$strict\''(_A, _B, _C, _D, _E).
hnf_susp('$map', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$map'(_A, _B, _C, _D, _E).
hnf_susp($., '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        $.(_A, _B, _C, _D, _E, _F).
hnf_susp($++, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $++(_A, _B, _C, _D, _E).
hnf_susp('$!!', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$!!'(_A, _B, _C, _D, _E).
hnf_susp('$iterate', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$iterate'(_A, _B, _C, _D, _E).
hnf_susp('$repeat', '.'(_A, []), _B, _C, _D):-
        '$repeat'(_A, _B, _C, _D).
hnf_susp('$copy', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$copy'(_A, _B, _C, _D, _E).
hnf_susp('$filter', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$filter'(_A, _B, _C, _D, _E).
hnf_susp('$foldl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldl1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$foldl1'(_A, _B, _C, _D, _E).
hnf_susp('$foldl\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldl\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanl1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$scanl1'(_A, _B, _C, _D, _E).
hnf_susp('$scanl\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanl\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldr1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$foldr1'(_A, _B, _C, _D, _E).
hnf_susp('$scanr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$auxForScanr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$auxForScanr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanr1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$scanr1'(_A, _B, _C, _D, _E).
hnf_susp('$take', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$take'(_A, _B, _C, _D, _E).
hnf_susp('$drop', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$drop'(_A, _B, _C, _D, _E).
hnf_susp('$splitAt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$splitAt'(_A, _B, _C, _D, _E).
hnf_susp('$auxForSplitAt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForSplitAt'(_A, _B, _C, _D, _E).
hnf_susp('$takeWhile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$takeWhile'(_A, _B, _C, _D, _E).
hnf_susp('$takeUntil', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$takeUntil'(_A, _B, _C, _D, _E).
hnf_susp('$dropWhile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$dropWhile'(_A, _B, _C, _D, _E).
hnf_susp('$span', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$span'(_A, _B, _C, _D, _E).
hnf_susp('$auxForSpan', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForSpan'(_A, _B, _C, _D, _E).
hnf_susp('$break', '.'(_A, []), _B, _C, _D):-
        '$break'(_A, _B, _C, _D).
hnf_susp('$zipWith', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$zipWith'(_A, _B, _C, _D, _E, _F).
hnf_susp('$zip', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$zip'(_A, _B, _C, _D, _E).
hnf_susp('$mkpair', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mkpair'(_A, _B, _C, _D, _E).
hnf_susp('$unzip', '.'(_A, []), _B, _C, _D):-
        '$unzip'(_A, _B, _C, _D).
hnf_susp('$auxForUnzip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$auxForUnzip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$until', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$until'(_A, _B, _C, _D, _E, _F).
hnf_susp('$until\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$until\''(_A, _B, _C, _D, _E).
hnf_susp('$const', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$const'(_A, _B, _C, _D, _E).
hnf_susp('$id', '.'(_A, []), _B, _C, _D):-
        '$id'(_A, _B, _C, _D).
hnf_susp($//, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $//(_A, _B, _C, _D, _E).
hnf_susp('$curry', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$curry'(_A, _B, _C, _D, _E, _F).
hnf_susp('$uncurry', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$uncurry'(_A, _B, _C, _D, _E).
hnf_susp('$fst', '.'(_A, []), _B, _C, _D):-
        '$fst'(_A, _B, _C, _D).
hnf_susp('$snd', '.'(_A, []), _B, _C, _D):-
        '$snd'(_A, _B, _C, _D).
hnf_susp('$fst3', '.'(_A, []), _B, _C, _D):-
        '$fst3'(_A, _B, _C, _D).
hnf_susp('$snd3', '.'(_A, []), _B, _C, _D):-
        '$snd3'(_A, _B, _C, _D).
hnf_susp('$thd3', '.'(_A, []), _B, _C, _D):-
        '$thd3'(_A, _B, _C, _D).
hnf_susp('$subtract', [], _A, _B, _C):-
        '$subtract'(_A, _B, _C).
hnf_susp('$even', '.'(_A, []), _B, _C, _D):-
        '$even'(_A, _B, _C, _D).
hnf_susp('$odd', [], _A, _B, _C):-
        '$odd'(_A, _B, _C).
hnf_susp('$lcm', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$lcm'(_A, _B, _C, _D, _E).
hnf_susp('$head', '.'(_A, []), _B, _C, _D):-
        '$head'(_A, _B, _C, _D).
hnf_susp('$last', '.'(_A, []), _B, _C, _D):-
        '$last'(_A, _B, _C, _D).
hnf_susp('$tail', '.'(_A, []), _B, _C, _D):-
        '$tail'(_A, _B, _C, _D).
hnf_susp('$init', '.'(_A, []), _B, _C, _D):-
        '$init'(_A, _B, _C, _D).
hnf_susp('$nub', '.'(_A, []), _B, _C, _D):-
        '$nub'(_A, _B, _C, _D).
hnf_susp('$length', '.'(_A, []), _B, _C, _D):-
        '$length'(_A, _B, _C, _D).
hnf_susp('$size', [], _A, _B, _C):-
        '$size'(_A, _B, _C).
hnf_susp('$reverse', [], _A, _B, _C):-
        '$reverse'(_A, _B, _C).
hnf_susp('$member', [], _A, _B, _C):-
        '$member'(_A, _B, _C).
hnf_susp('$notMember', [], _A, _B, _C):-
        '$notMember'(_A, _B, _C).
hnf_susp('$concat', [], _A, _B, _C):-
        '$concat'(_A, _B, _C).
hnf_susp('$transpose', [], _A, _B, _C):-
        '$transpose'(_A, _B, _C).
hnf_susp('$auxForTranspose', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForTranspose'(_A, _B, _C, _D, _E).
hnf_susp($\\, [], _A, _B, _C):-
        $\\(_A, _B, _C).
hnf_susp('$del', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$del'(_A, _B, _C, _D, _E).
hnf_susp('$incidencias', [], _A, _B, _C):-
        '$incidencias'(_A, _B, _C).
hnf_susp('$unasemana', [], _A, _B, _C):-
        '$unasemana'(_A, _B, _C).
hnf_susp('$unmes', [], _A, _B, _C):-
        '$unmes'(_A, _B, _C).
hnf_susp('$dosmeses', [], _A, _B, _C):-
        '$dosmeses'(_A, _B, _C).
hnf_susp('$tresmeses', [], _A, _B, _C):-
        '$tresmeses'(_A, _B, _C).
hnf_susp('$cuatromeses', [], _A, _B, _C):-
        '$cuatromeses'(_A, _B, _C).
hnf_susp('$cincomeses', [], _A, _B, _C):-
        '$cincomeses'(_A, _B, _C).
hnf_susp('$seismeses', [], _A, _B, _C):-
        '$seismeses'(_A, _B, _C).
hnf_susp('$ochomeses', [], _A, _B, _C):-
        '$ochomeses'(_A, _B, _C).
hnf_susp('$diezmeses', [], _A, _B, _C):-
        '$diezmeses'(_A, _B, _C).
hnf_susp('$anio', [], _A, _B, _C):-
        '$anio'(_A, _B, _C).
hnf_susp('$laborable', [], _A, _B, _C):-
        '$laborable'(_A, _B, _C).
hnf_susp('$festivo', [], _A, _B, _C):-
        '$festivo'(_A, _B, _C).
hnf_susp('$especial', [], _A, _B, _C):-
        '$especial'(_A, _B, _C).
hnf_susp('$no', [], _A, _B, _C):-
        '$no'(_A, _B, _C).
hnf_susp('$t1', [], _A, _B, _C):-
        '$t1'(_A, _B, _C).
hnf_susp('$t2', [], _A, _B, _C):-
        '$t2'(_A, _B, _C).
hnf_susp('$t3', [], _A, _B, _C):-
        '$t3'(_A, _B, _C).
hnf_susp('$t4', [], _A, _B, _C):-
        '$t4'(_A, _B, _C).
hnf_susp('$t5', [], _A, _B, _C):-
        '$t5'(_A, _B, _C).
hnf_susp('$t6', [], _A, _B, _C):-
        '$t6'(_A, _B, _C).
hnf_susp('$bj', [], _A, _B, _C):-
        '$bj'(_A, _B, _C).
hnf_susp('$vc', [], _A, _B, _C):-
        '$vc'(_A, _B, _C).
hnf_susp('$grupo_activo', '.'(_A, []), _B, _C, _D):-
        '$grupo_activo'(_A, _B, _C, _D).
hnf_susp('$incrementar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$incrementar'(_A, _B, _C, _D, _E).
hnf_susp('$crear_incidencias', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$crear_incidencias'(_A, _B, _C, _D, _E, _F).
hnf_susp('$proc_incidencia', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$proc_incidencia'(_A, _B, _C, _D, _E).
hnf_susp('$inicio', '.'(_A, []), _B, _C, _D):-
        '$inicio'(_A, _B, _C, _D).
hnf_susp('$incidencias_dia', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$incidencias_dia'(_A, _B, _C, _D, _E).
hnf_susp('$proc_vacaciones', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$proc_vacaciones'(_A, _B, _C, _D, _E).
hnf_susp('$vacaciones_dia', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$vacaciones_dia'(_A, _B, _C, _D, _E).
hnf_susp('$proc_bajas', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$proc_bajas'(_A, _B, _C, _D, _E).
hnf_susp('$bajas_dia', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$bajas_dia'(_A, _B, _C, _D, _E).
hnf_susp('$crear_grupos', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$crear_grupos'(_A, _B, _C, _D, _E).
hnf_susp('$solicitaNoche', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$solicitaNoche'(_A, _B, _C, _D, _E).
hnf_susp('$puedeNoche', '.'(_A, []), _B, _C, _D):-
        '$puedeNoche'(_A, _B, _C, _D).
hnf_susp('$t13trabaja_noche', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$t13trabaja_noche'(_A, _B, _C, _D, _E).
hnf_susp('$j1', [], _A, _B, _C):-
        '$j1'(_A, _B, _C).
hnf_susp('$j2', [], _A, _B, _C):-
        '$j2'(_A, _B, _C).
hnf_susp('$j3', [], _A, _B, _C):-
        '$j3'(_A, _B, _C).
hnf_susp('$j4', [], _A, _B, _C):-
        '$j4'(_A, _B, _C).
hnf_susp('$crear_plan_jornadas', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$crear_plan_jornadas'(_A, _B, _C, _D, _E, _F).
hnf_susp('$crear_trabajo', '.'(_A, []), _B, _C, _D):-
        '$crear_trabajo'(_A, _B, _C, _D).
hnf_susp('$crear_planificacion', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$crear_planificacion'(_A, _B, _C, _D, _E).
hnf_susp('$borrar_uno', '.'(_A, []), _B, _C, _D):-
        '$borrar_uno'(_A, _B, _C, _D).
hnf_susp('$quitar_primeros', '.'(_A, []), _B, _C, _D):-
        '$quitar_primeros'(_A, _B, _C, _D).
hnf_susp('$prim', '.'(_A, []), _B, _C, _D):-
        '$prim'(_A, _B, _C, _D).
hnf_susp('$primeros', '.'(_A, []), _B, _C, _D):-
        '$primeros'(_A, _B, _C, _D).
hnf_susp('$listas_vacias', '.'(_A, []), _B, _C, _D):-
        '$listas_vacias'(_A, _B, _C, _D).
hnf_susp('$transponer', '.'(_A, []), _B, _C, _D):-
        '$transponer'(_A, _B, _C, _D).
hnf_susp('$crear_fila', '.'(_A, []), _B, _C, _D):-
        '$crear_fila'(_A, _B, _C, _D).
hnf_susp('$crear_tabla', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$crear_tabla'(_A, _B, _C, _D, _E).
hnf_susp('$anotar_en_trabajador', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$anotar_en_trabajador'(_A, _B, _C, _D, _E).
hnf_susp('$anotar_una', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$anotar_una'(_A, _B, _C, _D, _E).
hnf_susp('$anotar_incidencias', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$anotar_incidencias'(_A, _B, _C, _D, _E).
hnf_susp('$procesar_jornadas', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, '.'(_F, [])))))), _G, _H, _I):-
        '$procesar_jornadas'(_A, _B, _C, _D, _E, _F, _G, _H, _I).
hnf_susp('$contar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$contar'(_A, _B, _C, _D, _E).
hnf_susp('$empaquetar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$empaquetar'(_A, _B, _C, _D, _E).
hnf_susp('$proyectar', '.'(_A, []), _B, _C, _D):-
        '$proyectar'(_A, _B, _C, _D).
hnf_susp('$anotar_trab', '.'(_A, []), _B, _C, _D):-
        '$anotar_trab'(_A, _B, _C, _D).
hnf_susp('$anotar_desc', '.'(_A, []), _B, _C, _D):-
        '$anotar_desc'(_A, _B, _C, _D).
hnf_susp('$descansar', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$descansar'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$trabajar', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$trabajar'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$grupo', '.'(_A, []), _B, _C, _D):-
        '$grupo'(_A, _B, _C, _D).
hnf_susp('$procesar_tipo_dia', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$procesar_tipo_dia'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$procesar_dia', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, '.'(_F, '.'(_G, []))))))), _H, _I, _J):-
        '$procesar_dia'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J).
hnf_susp('$procesar_trabajo', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, '.'(_F, '.'(_G, []))))))), _H, _I, _J):-
        '$procesar_trabajo'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J).
hnf_susp('$trab_comodin', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$trab_comodin'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$trabajar_comodin', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$trabajar_comodin'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$proc_t6', '.'(_A, []), _B, _C, _D):-
        '$proc_t6'(_A, _B, _C, _D).
hnf_susp('$sin_t6', '.'(_A, []), _B, _C, _D):-
        '$sin_t6'(_A, _B, _C, _D).
hnf_susp('$no_t6', '.'(_A, []), _B, _C, _D):-
        '$no_t6'(_A, _B, _C, _D).
hnf_susp('$valido_laborables', '.'(_A, []), _B, _C, _D):-
        '$valido_laborables'(_A, _B, _C, _D).
hnf_susp('$valido_festivos', '.'(_A, []), _B, _C, _D):-
        '$valido_festivos'(_A, _B, _C, _D).
hnf_susp('$extrayendo', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$extrayendo'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$extraer_turnos', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$extraer_turnos'(_A, _B, _C, _D, _E, _F).
hnf_susp('$sacar_laborables', '.'(_A, []), _B, _C, _D):-
        '$sacar_laborables'(_A, _B, _C, _D).
hnf_susp('$extraer_laborables', '.'(_A, []), _B, _C, _D):-
        '$extraer_laborables'(_A, _B, _C, _D).
hnf_susp('$sacar_festivos', '.'(_A, []), _B, _C, _D):-
        '$sacar_festivos'(_A, _B, _C, _D).
hnf_susp('$extraer_festivos', '.'(_A, []), _B, _C, _D):-
        '$extraer_festivos'(_A, _B, _C, _D).
hnf_susp('$rotar_turnos_laborables', '.'(_A, []), _B, _C, _D):-
        '$rotar_turnos_laborables'(_A, _B, _C, _D).
hnf_susp('$rotar_turnos_festivos', '.'(_A, []), _B, _C, _D):-
        '$rotar_turnos_festivos'(_A, _B, _C, _D).
hnf_susp('$imponer_rotaciones', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$imponer_rotaciones'(_A, _B, _C, _D, _E, _F).
hnf_susp('$rango_jornadas', '.'(_A, []), _B, _C, _D):-
        '$rango_jornadas'(_A, _B, _C, _D).
hnf_susp('$establecer_dominios', '.'(_A, []), _B, _C, _D):-
        '$establecer_dominios'(_A, _B, _C, _D).
hnf_susp('$etiquetar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$etiquetar'(_A, _B, _C, _D, _E).
hnf_susp('$extraer', '.'(_A, []), _B, _C, _D):-
        '$extraer'(_A, _B, _C, _D).
hnf_susp('$etiquetar\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$etiquetar\''(_A, _B, _C, _D, _E).
hnf_susp('$m0_0', '.'(_A, []), _B, _C, _D):-
        '$m0_0'(_A, _B, _C, _D).
hnf_susp('$m1_24', '.'(_A, []), _B, _C, _D):-
        '$m1_24'(_A, _B, _C, _D).
hnf_susp('$m2_14', '.'(_A, []), _B, _C, _D):-
        '$m2_14'(_A, _B, _C, _D).
hnf_susp('$m3_14', '.'(_A, []), _B, _C, _D):-
        '$m3_14'(_A, _B, _C, _D).
hnf_susp('$m4_17', '.'(_A, []), _B, _C, _D):-
        '$m4_17'(_A, _B, _C, _D).
hnf_susp('$m5_13', '.'(_A, []), _B, _C, _D):-
        '$m5_13'(_A, _B, _C, _D).
hnf_susp('$m6_6', '.'(_A, []), _B, _C, _D):-
        '$m6_6'(_A, _B, _C, _D).
hnf_susp('$m7_6', '.'(_A, []), _B, _C, _D):-
        '$m7_6'(_A, _B, _C, _D).
hnf_susp('$m8_0', '.'(_A, []), _B, _C, _D):-
        '$m8_0'(_A, _B, _C, _D).
hnf_susp('$duracion\'', '.'(_A, []), _B, _C, _D):-
        '$duracion\''(_A, _B, _C, _D).
hnf_susp('$duracion', '.'(_A, []), _B, _C, _D):-
        '$duracion'(_A, _B, _C, _D).
hnf_susp('$horasTrabajador', '.'(_A, []), _B, _C, _D):-
        '$horasTrabajador'(_A, _B, _C, _D).
hnf_susp('$trabajoMes', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$trabajoMes'(_A, _B, _C, _D, _E, _F).
hnf_susp('$hm', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$hm'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$horasMesTrabajador', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$horasMesTrabajador'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$horasCadaMes', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$horasCadaMes'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$horasCadaAnio', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$horasCadaAnio'(_A, _B, _C, _D, _E, _F).
hnf_susp('$obtenerMes', '.'(_A, []), _B, _C, _D):-
        '$obtenerMes'(_A, _B, _C, _D).
hnf_susp('$calcularMesUltimo', '.'(_A, []), _B, _C, _D):-
        '$calcularMesUltimo'(_A, _B, _C, _D).
hnf_susp('$numeroMes', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$numeroMes'(_A, _B, _C, _D, _E).
hnf_susp('$horasMes', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$horasMes'(_A, _B, _C, _D, _E, _F).
hnf_susp('$horasAnio', '.'(_A, []), _B, _C, _D):-
        '$horasAnio'(_A, _B, _C, _D).
hnf_susp('$planificar', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$planificar'(_A, _B, _C, _D, _E, _F).
hnf_susp('$sig_laborable', '.'(_A, []), _B, _C, _D):-
        '$sig_laborable'(_A, _B, _C, _D).
hnf_susp('$sig_festivo', '.'(_A, []), _B, _C, _D):-
        '$sig_festivo'(_A, _B, _C, _D).
hnf_susp('$extrayendo2', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$extrayendo2'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$extraer_turnos2', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$extraer_turnos2'(_A, _B, _C, _D, _E, _F).
hnf_susp('$escribir_lab', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$escribir_lab'(_A, _B, _C, _D, _E).
hnf_susp('$escribir_laborables', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$escribir_laborables'(_A, _B, _C, _D, _E).
hnf_susp('$escribir_fes', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$escribir_fes'(_A, _B, _C, _D, _E).
hnf_susp('$escribir_festivos', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$escribir_festivos'(_A, _B, _C, _D, _E).
hnf_susp('$establecer_des', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$establecer_des'(_A, _B, _C, _D, _E, _F).
hnf_susp('$establecer_descanso', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$establecer_descanso'(_A, _B, _C, _D, _E).
hnf_susp('$primera_sol', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$primera_sol'(_A, _B, _C, _D, _E, _F).
hnf_susp('$apuntar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$apuntar'(_A, _B, _C, _D, _E).
hnf_susp('$actividad_comodin', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$actividad_comodin'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$primera_sol_act', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$primera_sol_act'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$reapuntar', '.'(_A, []), _B, _C, _D):-
        '$reapuntar'(_A, _B, _C, _D).
hnf_susp('$planificar_una', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$planificar_una'(_A, _B, _C, _D, _E).
hnf_susp('$j2esj1', '.'(_A, []), _B, _C, _D):-
        '$j2esj1'(_A, _B, _C, _D).
hnf_susp('$inizio', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$inizio'(_A, _B, _C, _D, _E).
hnf_susp('$resto', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$resto'(_A, _B, _C, _D, _E).
hnf_susp('$generar_lista', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$generar_lista'(_A, _B, _C, _D, _E).
hnf_susp('$intentar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$intentar'(_A, _B, _C, _D, _E).
hnf_susp('$mi_busqueda', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mi_busqueda'(_A, _B, _C, _D, _E).
hnf_susp('$esNocturno', '.'(_A, []), _B, _C, _D):-
        '$esNocturno'(_A, _B, _C, _D).
hnf_susp('$elemento', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$elemento'(_A, _B, _C, _D, _E).
hnf_susp('$deXhastaY', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$deXhastaY'(_A, _B, _C, _D, _E).
hnf_susp('$div\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div\''(_A, _B, _C, _D, _E).
hnf_susp('$sustituir', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$sustituir'(_A, _B, _C, _D, _E, _F).
hnf_susp('$ultimo', '.'(_A, []), _B, _C, _D):-
        '$ultimo'(_A, _B, _C, _D).
hnf_susp('$n_menos_1', '.'(_A, []), _B, _C, _D):-
        '$n_menos_1'(_A, _B, _C, _D).
hnf_susp('$invertir', '.'(_A, []), _B, _C, _D):-
        '$invertir'(_A, _B, _C, _D).
hnf_susp('$card', '.'(_A, []), _B, _C, _D):-
        '$card'(_A, _B, _C, _D).
hnf_susp('$eliminar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$eliminar'(_A, _B, _C, _D, _E).
hnf_susp('$ini', '.'(_A, []), _B, _C, _D):-
        '$ini'(_A, _B, _C, _D).
hnf_susp('$iniln', '.'(_A, []), _B, _C, _D):-
        '$iniln'(_A, _B, _C, _D).




/***************     CODE FOR APPLY     ***************/

'$$apply'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$$applyHnf'(_F, _B, _C, _G, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        var(_A),
        !,
        '$$apply_1_var'(_A, _B, _C, _D, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        '$$apply_1'(_A, _B, _C, _D, _E).

% constructors

'$$apply_1'(:, _A, :(_A), _B, _B).
'$$apply_1_var'(_A, _B, :(_B), _C, _D):-
        unifyHnfs(_A, :, _C, _D).

'$$apply_1'(:(_A), _B, :(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, :(_C, _B), _D, _E):-
        unifyHnfs(_A, :(_C), _D, _E).

'$$apply_1'('$io', _A, '$io'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$io'(_B), _C, _D):-
        unifyHnfs(_A, '$io', _C, _D).

'$$apply_1'('$stream', _A, '$stream'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$stream'(_B), _C, _D):-
        unifyHnfs(_A, '$stream', _C, _D).

'$$apply_1'('$channel', _A, '$channel'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$channel'(_B), _C, _D):-
        unifyHnfs(_A, '$channel', _C, _D).

'$$apply_1'('$channel'(_A), _B, '$channel'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$channel'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$channel'(_C), _D, _E).

'$$apply_1'('$varmut', _A, '$varmut'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$varmut'(_B), _C, _D):-
        unifyHnfs(_A, '$varmut', _C, _D).

'$$apply_1'(pValChar, _A, pValChar(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValChar(_B), _C, _D):-
        unifyHnfs(_A, pValChar, _C, _D).

'$$apply_1'(pValNum, _A, pValNum(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValNum(_B), _C, _D):-
        unifyHnfs(_A, pValNum, _C, _D).

'$$apply_1'(pValVar, _A, pValVar(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValVar(_B), _C, _D):-
        unifyHnfs(_A, pValVar, _C, _D).

'$$apply_1'(pValApp, _A, pValApp(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValApp(_B), _C, _D):-
        unifyHnfs(_A, pValApp, _C, _D).

'$$apply_1'(pValApp(_A), _B, pValApp(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, pValApp(_C, _B), _D, _E):-
        unifyHnfs(_A, pValApp(_C), _D, _E).

'$$apply_1'(constraint, _A, constraint(_A), _B, _B).
'$$apply_1_var'(_A, _B, constraint(_B), _C, _D):-
        unifyHnfs(_A, constraint, _C, _D).

'$$apply_1'(atomicConstraint, _A, atomicConstraint(_A), _B, _B).
'$$apply_1_var'(_A, _B, atomicConstraint(_B), _C, _D):-
        unifyHnfs(_A, atomicConstraint, _C, _D).

'$$apply_1'(atomicConstraint(_A), _B, atomicConstraint(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, atomicConstraint(_C, _B), _D, _E):-
        unifyHnfs(_A, atomicConstraint(_C), _D, _E).

'$$apply_1'(atomicConstraint(_A, _B), _C, atomicConstraint(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, atomicConstraint(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, atomicConstraint(_C, _D), _E, _F).

'$$apply_1'(cTreeNode, _A, cTreeNode(_A), _B, _B).
'$$apply_1_var'(_A, _B, cTreeNode(_B), _C, _D):-
        unifyHnfs(_A, cTreeNode, _C, _D).

'$$apply_1'(cTreeNode(_A), _B, cTreeNode(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _B), _D, _E):-
        unifyHnfs(_A, cTreeNode(_C), _D, _E).

'$$apply_1'(cTreeNode(_A, _B), _C, cTreeNode(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, cTreeNode(_C, _D), _E, _F).

'$$apply_1'(cTreeNode(_A, _B, _C), _D, cTreeNode(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E), _F, _G).

'$$apply_1'(cTreeNode(_A, _B, _C, _D), _E, cTreeNode(_A, _B, _C, _D, _E), _F, _F).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _B), _G, _H):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F), _G, _H).

'$$apply_1'(cTreeNode(_A, _B, _C, _D, _E), _F, cTreeNode(_A, _B, _C, _D, _E, _F), _G, _G).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _G, _B), _H, _I):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F, _G), _H, _I).

'$$apply_1'(cTreeNode(_A, _B, _C, _D, _E, _F), _G, cTreeNode(_A, _B, _C, _D, _E, _F, _G), _H, _H).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _G, _H, _B), _I, _J):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F, _G, _H), _I, _J).

'$$apply_1'(toMinimize, _A, toMinimize(_A), _B, _B).
'$$apply_1_var'(_A, _B, toMinimize(_B), _C, _D):-
        unifyHnfs(_A, toMinimize, _C, _D).

'$$apply_1'(toMaximize, _A, toMaximize(_A), _B, _B).
'$$apply_1_var'(_A, _B, toMaximize(_B), _C, _D):-
        unifyHnfs(_A, toMaximize, _C, _D).

'$$apply_1'(assumptions, _A, assumptions(_A), _B, _B).
'$$apply_1_var'(_A, _B, assumptions(_B), _C, _D):-
        unifyHnfs(_A, assumptions, _C, _D).

'$$apply_1'(on, _A, on(_A), _B, _B).
'$$apply_1_var'(_A, _B, on(_B), _C, _D):-
        unifyHnfs(_A, on, _C, _D).

'$$apply_1'(complete, _A, complete(_A), _B, _B).
'$$apply_1_var'(_A, _B, complete(_B), _C, _D):-
        unifyHnfs(_A, complete, _C, _D).

'$$apply_1'(d, _A, d(_A), _B, _B).
'$$apply_1_var'(_A, _B, d(_B), _C, _D):-
        unifyHnfs(_A, d, _C, _D).

'$$apply_1'(lift, _A, lift(_A), _B, _B).
'$$apply_1_var'(_A, _B, lift(_B), _C, _D):-
        unifyHnfs(_A, lift, _C, _D).

'$$apply_1'(precedences, _A, precedences(_A), _B, _B).
'$$apply_1_var'(_A, _B, precedences(_B), _C, _D):-
        unifyHnfs(_A, precedences, _C, _D).

'$$apply_1'(path_consistency, _A, path_consistency(_A), _B, _B).
'$$apply_1_var'(_A, _B, path_consistency(_B), _C, _D):-
        unifyHnfs(_A, path_consistency, _C, _D).

'$$apply_1'(static_sets, _A, static_sets(_A), _B, _B).
'$$apply_1_var'(_A, _B, static_sets(_B), _C, _D):-
        unifyHnfs(_A, static_sets, _C, _D).

'$$apply_1'(edge_finder, _A, edge_finder(_A), _B, _B).
'$$apply_1_var'(_A, _B, edge_finder(_B), _C, _D):-
        unifyHnfs(_A, edge_finder, _C, _D).

'$$apply_1'(decomposition, _A, decomposition(_A), _B, _B).
'$$apply_1_var'(_A, _B, decomposition(_B), _C, _D):-
        unifyHnfs(_A, decomposition, _C, _D).

'$$apply_1'(cte, _A, cte(_A), _B, _B).
'$$apply_1_var'(_A, _B, cte(_B), _C, _D):-
        unifyHnfs(_A, cte, _C, _D).

'$$apply_1'(cte(_A), _B, cte(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, cte(_C, _B), _D, _E):-
        unifyHnfs(_A, cte(_C), _D, _E).

'$$apply_1'(uni, _A, uni(_A), _B, _B).
'$$apply_1_var'(_A, _B, uni(_B), _C, _D):-
        unifyHnfs(_A, uni, _C, _D).

'$$apply_1'(uni(_A), _B, uni(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, uni(_C, _B), _D, _E):-
        unifyHnfs(_A, uni(_C), _D, _E).

'$$apply_1'(inter, _A, inter(_A), _B, _B).
'$$apply_1_var'(_A, _B, inter(_B), _C, _D):-
        unifyHnfs(_A, inter, _C, _D).

'$$apply_1'(inter(_A), _B, inter(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, inter(_C, _B), _D, _E):-
        unifyHnfs(_A, inter(_C), _D, _E).

'$$apply_1'(compl, _A, compl(_A), _B, _B).
'$$apply_1_var'(_A, _B, compl(_B), _C, _D):-
        unifyHnfs(_A, compl, _C, _D).

'$$apply_1'(interval, _A, interval(_A), _B, _B).
'$$apply_1_var'(_A, _B, interval(_B), _C, _D):-
        unifyHnfs(_A, interval, _C, _D).

'$$apply_1'(interval(_A), _B, interval(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, interval(_C, _B), _D, _E):-
        unifyHnfs(_A, interval(_C), _D, _E).

'$$apply_1'(domm, _A, domm(_A), _B, _B).
'$$apply_1_var'(_A, _B, domm(_B), _C, _D):-
        unifyHnfs(_A, domm, _C, _D).

'$$apply_1'(minn, _A, minn(_A), _B, _B).
'$$apply_1_var'(_A, _B, minn(_B), _C, _D):-
        unifyHnfs(_A, minn, _C, _D).

'$$apply_1'(maxx, _A, maxx(_A), _B, _B).
'$$apply_1_var'(_A, _B, maxx(_B), _C, _D):-
        unifyHnfs(_A, maxx, _C, _D).

'$$apply_1'(minmax, _A, minmax(_A), _B, _B).
'$$apply_1_var'(_A, _B, minmax(_B), _C, _D):-
        unifyHnfs(_A, minmax, _C, _D).

'$$apply_1'(vall, _A, vall(_A), _B, _B).
'$$apply_1_var'(_A, _B, vall(_B), _C, _D):-
        unifyHnfs(_A, vall, _C, _D).

% parcial aplictions of funs

'$$apply_1'('$eqFun', _A, '$eqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$eqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$eqFun', _C, _D).

'$$apply_1'('$notEqFun', _A, '$notEqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$notEqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$notEqFun', _C, _D).

'$$apply_1'(#==, _A, #==(_A), _B, _B).
'$$apply_1_var'(_A, _B, #==(_B), _C, _D):-
        unifyHnfs(_A, #==, _C, _D).

'$$apply_1'(#/==, _A, #/==(_A), _B, _B).
'$$apply_1_var'(_A, _B, #/==(_B), _C, _D):-
        unifyHnfs(_A, #/==, _C, _D).

'$$apply_1'(domain, _A, domain(_A), _B, _B).
'$$apply_1_var'(_A, _B, domain(_B), _C, _D):-
        unifyHnfs(_A, domain, _C, _D).

'$$apply_1'(domain(_A), _B, domain(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, domain(_C, _B), _D, _E):-
        unifyHnfs(_A, domain(_C), _D, _E).

'$$apply_1'(subset, _A, subset(_A), _B, _B).
'$$apply_1_var'(_A, _B, subset(_B), _C, _D):-
        unifyHnfs(_A, subset, _C, _D).

'$$apply_1'(inset, _A, inset(_A), _B, _B).
'$$apply_1_var'(_A, _B, inset(_B), _C, _D):-
        unifyHnfs(_A, inset, _C, _D).

'$$apply_1'(setcomplement, _A, setcomplement(_A), _B, _B).
'$$apply_1_var'(_A, _B, setcomplement(_B), _C, _D):-
        unifyHnfs(_A, setcomplement, _C, _D).

'$$apply_1'(intersect, _A, intersect(_A), _B, _B).
'$$apply_1_var'(_A, _B, intersect(_B), _C, _D):-
        unifyHnfs(_A, intersect, _C, _D).

'$$apply_1'(belongs, _A, belongs(_A), _B, _B).
'$$apply_1_var'(_A, _B, belongs(_B), _C, _D):-
        unifyHnfs(_A, belongs, _C, _D).

'$$apply_1'(labeling, _A, labeling(_A), _B, _B).
'$$apply_1_var'(_A, _B, labeling(_B), _C, _D):-
        unifyHnfs(_A, labeling, _C, _D).

'$$apply_1'(fdminimize, _A, fdminimize(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdminimize(_B), _C, _D):-
        unifyHnfs(_A, fdminimize, _C, _D).

'$$apply_1'(fdmaximize, _A, fdmaximize(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdmaximize(_B), _C, _D):-
        unifyHnfs(_A, fdmaximize, _C, _D).

'$$apply_1'(#=, _A, #=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #=(_B), _C, _D):-
        unifyHnfs(_A, #=, _C, _D).

'$$apply_1'(#\=, _A, #\=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #\=(_B), _C, _D):-
        unifyHnfs(_A, #\=, _C, _D).

'$$apply_1'(#<, _A, #<(_A), _B, _B).
'$$apply_1_var'(_A, _B, #<(_B), _C, _D):-
        unifyHnfs(_A, #<, _C, _D).

'$$apply_1'(#<=, _A, #<=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #<=(_B), _C, _D):-
        unifyHnfs(_A, #<=, _C, _D).

'$$apply_1'(#>, _A, #>(_A), _B, _B).
'$$apply_1_var'(_A, _B, #>(_B), _C, _D):-
        unifyHnfs(_A, #>, _C, _D).

'$$apply_1'(#>=, _A, #>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #>=(_B), _C, _D):-
        unifyHnfs(_A, #>=, _C, _D).

'$$apply_1'(#+, _A, #+(_A), _B, _B).
'$$apply_1_var'(_A, _B, #+(_B), _C, _D):-
        unifyHnfs(_A, #+, _C, _D).

'$$apply_1'(#-, _A, #-(_A), _B, _B).
'$$apply_1_var'(_A, _B, #-(_B), _C, _D):-
        unifyHnfs(_A, #-, _C, _D).

'$$apply_1'(#*, _A, #*(_A), _B, _B).
'$$apply_1_var'(_A, _B, #*(_B), _C, _D):-
        unifyHnfs(_A, #*, _C, _D).

'$$apply_1'(#/, _A, #/(_A), _B, _B).
'$$apply_1_var'(_A, _B, #/(_B), _C, _D):-
        unifyHnfs(_A, #/, _C, _D).

'$$apply_1'(#&, _A, #&(_A), _B, _B).
'$$apply_1_var'(_A, _B, #&(_B), _C, _D):-
        unifyHnfs(_A, #&, _C, _D).

'$$apply_1'(sum, _A, sum(_A), _B, _B).
'$$apply_1_var'(_A, _B, sum(_B), _C, _D):-
        unifyHnfs(_A, sum, _C, _D).

'$$apply_1'(sum(_A), _B, sum(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, sum(_C, _B), _D, _E):-
        unifyHnfs(_A, sum(_C), _D, _E).

'$$apply_1'(scalar_product, _A, scalar_product(_A), _B, _B).
'$$apply_1_var'(_A, _B, scalar_product(_B), _C, _D):-
        unifyHnfs(_A, scalar_product, _C, _D).

'$$apply_1'(scalar_product(_A), _B, scalar_product(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scalar_product(_C, _B), _D, _E):-
        unifyHnfs(_A, scalar_product(_C), _D, _E).

'$$apply_1'(scalar_product(_A, _B), _C, scalar_product(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, scalar_product(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, scalar_product(_C, _D), _E, _F).

'$$apply_1'('all_different\'', _A, 'all_different\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'all_different\''(_B), _C, _D):-
        unifyHnfs(_A, 'all_different\'', _C, _D).

'$$apply_1'(assignment, _A, assignment(_A), _B, _B).
'$$apply_1_var'(_A, _B, assignment(_B), _C, _D):-
        unifyHnfs(_A, assignment, _C, _D).

'$$apply_1'('circuit\'', _A, 'circuit\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'circuit\''(_B), _C, _D):-
        unifyHnfs(_A, 'circuit\'', _C, _D).

'$$apply_1'(count, _A, count(_A), _B, _B).
'$$apply_1_var'(_A, _B, count(_B), _C, _D):-
        unifyHnfs(_A, count, _C, _D).

'$$apply_1'(count(_A), _B, count(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, count(_C, _B), _D, _E):-
        unifyHnfs(_A, count(_C), _D, _E).

'$$apply_1'(count(_A, _B), _C, count(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, count(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, count(_C, _D), _E, _F).

'$$apply_1'(element, _A, element(_A), _B, _B).
'$$apply_1_var'(_A, _B, element(_B), _C, _D):-
        unifyHnfs(_A, element, _C, _D).

'$$apply_1'(element(_A), _B, element(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, element(_C, _B), _D, _E):-
        unifyHnfs(_A, element(_C), _D, _E).

'$$apply_1'(exactly, _A, exactly(_A), _B, _B).
'$$apply_1_var'(_A, _B, exactly(_B), _C, _D):-
        unifyHnfs(_A, exactly, _C, _D).

'$$apply_1'(exactly(_A), _B, exactly(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, exactly(_C, _B), _D, _E):-
        unifyHnfs(_A, exactly(_C), _D, _E).

'$$apply_1'(serialized, _A, serialized(_A), _B, _B).
'$$apply_1_var'(_A, _B, serialized(_B), _C, _D):-
        unifyHnfs(_A, serialized, _C, _D).

'$$apply_1'('serialized\'', _A, 'serialized\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'serialized\''(_B), _C, _D):-
        unifyHnfs(_A, 'serialized\'', _C, _D).

'$$apply_1'('serialized\''(_A), _B, 'serialized\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'serialized\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'serialized\''(_C), _D, _E).

'$$apply_1'(cumulative, _A, cumulative(_A), _B, _B).
'$$apply_1_var'(_A, _B, cumulative(_B), _C, _D):-
        unifyHnfs(_A, cumulative, _C, _D).

'$$apply_1'(cumulative(_A), _B, cumulative(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, cumulative(_C, _B), _D, _E):-
        unifyHnfs(_A, cumulative(_C), _D, _E).

'$$apply_1'(cumulative(_A, _B), _C, cumulative(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, cumulative(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, cumulative(_C, _D), _E, _F).

'$$apply_1'('cumulative\'', _A, 'cumulative\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'cumulative\''(_B), _C, _D):-
        unifyHnfs(_A, 'cumulative\'', _C, _D).

'$$apply_1'('cumulative\''(_A), _B, 'cumulative\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'cumulative\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'cumulative\''(_C), _D, _E).

'$$apply_1'('cumulative\''(_A, _B), _C, 'cumulative\''(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, 'cumulative\''(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, 'cumulative\''(_C, _D), _E, _F).

'$$apply_1'('cumulative\''(_A, _B, _C), _D, 'cumulative\''(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, 'cumulative\''(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, 'cumulative\''(_C, _D, _E), _F, _G).

'$$apply_1'(#\/, _A, #\/(_A), _B, _B).
'$$apply_1_var'(_A, _B, #\/(_B), _C, _D):-
        unifyHnfs(_A, #\/, _C, _D).

'$$apply_1'(#<=>, _A, #<=>(_A), _B, _B).
'$$apply_1_var'(_A, _B, #<=>(_B), _C, _D):-
        unifyHnfs(_A, #<=>, _C, _D).

'$$apply_1'(#=>, _A, #=>(_A), _B, _B).
'$$apply_1_var'(_A, _B, #=>(_B), _C, _D):-
        unifyHnfs(_A, #=>, _C, _D).

'$$apply_1'(fdset_parts, _A, fdset_parts(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_parts(_B), _C, _D):-
        unifyHnfs(_A, fdset_parts, _C, _D).

'$$apply_1'(fdset_parts(_A), _B, fdset_parts(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, fdset_parts(_C, _B), _D, _E):-
        unifyHnfs(_A, fdset_parts(_C), _D, _E).

'$$apply_1'(empty_interval, _A, empty_interval(_A), _B, _B).
'$$apply_1_var'(_A, _B, empty_interval(_B), _C, _D):-
        unifyHnfs(_A, empty_interval, _C, _D).

'$$apply_1'(interval_to_fdset, _A, interval_to_fdset(_A), _B, _B).
'$$apply_1_var'(_A, _B, interval_to_fdset(_B), _C, _D):-
        unifyHnfs(_A, interval_to_fdset, _C, _D).

'$$apply_1'(fdset_singleton, _A, fdset_singleton(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_singleton(_B), _C, _D):-
        unifyHnfs(_A, fdset_singleton, _C, _D).

'$$apply_1'(fdset_add_element, _A, fdset_add_element(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_add_element(_B), _C, _D):-
        unifyHnfs(_A, fdset_add_element, _C, _D).

'$$apply_1'(fdset_del_element, _A, fdset_del_element(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_del_element(_B), _C, _D):-
        unifyHnfs(_A, fdset_del_element, _C, _D).

'$$apply_1'(fdset_intersection, _A, fdset_intersection(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_intersection(_B), _C, _D):-
        unifyHnfs(_A, fdset_intersection, _C, _D).

'$$apply_1'(fdset_subtract, _A, fdset_subtract(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_subtract(_B), _C, _D):-
        unifyHnfs(_A, fdset_subtract, _C, _D).

'$$apply_1'(fdset_union, _A, fdset_union(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_union(_B), _C, _D):-
        unifyHnfs(_A, fdset_union, _C, _D).

'$$apply_1'(fdset_equal, _A, fdset_equal(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_equal(_B), _C, _D):-
        unifyHnfs(_A, fdset_equal, _C, _D).

'$$apply_1'(fdset_subset, _A, fdset_subset(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_subset(_B), _C, _D):-
        unifyHnfs(_A, fdset_subset, _C, _D).

'$$apply_1'(fdset_disjoint, _A, fdset_disjoint(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_disjoint(_B), _C, _D):-
        unifyHnfs(_A, fdset_disjoint, _C, _D).

'$$apply_1'(fdset_intersect, _A, fdset_intersect(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_intersect(_B), _C, _D):-
        unifyHnfs(_A, fdset_intersect, _C, _D).

'$$apply_1'(fdset_member, _A, fdset_member(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_member(_B), _C, _D):-
        unifyHnfs(_A, fdset_member, _C, _D).

'$$apply_1'(fdset_belongs, _A, fdset_belongs(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_belongs(_B), _C, _D):-
        unifyHnfs(_A, fdset_belongs, _C, _D).

'$$apply_1'(isin, _A, isin(_A), _B, _B).
'$$apply_1_var'(_A, _B, isin(_B), _C, _D):-
        unifyHnfs(_A, isin, _C, _D).

'$$apply_1'(fd_global, _A, fd_global(_A), _B, _B).
'$$apply_1_var'(_A, _B, fd_global(_B), _C, _D):-
        unifyHnfs(_A, fd_global, _C, _D).

'$$apply_1'(fd_global(_A), _B, fd_global(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, fd_global(_C, _B), _D, _E):-
        unifyHnfs(_A, fd_global(_C), _D, _E).

'$$apply_1'(and, _A, and(_A), _B, _B).
'$$apply_1_var'(_A, _B, and(_B), _C, _D):-
        unifyHnfs(_A, and, _C, _D).

'$$apply_1'(or, _A, or(_A), _B, _B).
'$$apply_1_var'(_A, _B, or(_B), _C, _D):-
        unifyHnfs(_A, or, _C, _D).

'$$apply_1'(/\, _A, /\(_A), _B, _B).
'$$apply_1_var'(_A, _B, /\(_B), _C, _D):-
        unifyHnfs(_A, /\, _C, _D).

'$$apply_1'(\/, _A, \/(_A), _B, _B).
'$$apply_1_var'(_A, _B, \/(_B), _C, _D):-
        unifyHnfs(_A, \/, _C, _D).

'$$apply_1'(strict, _A, strict(_A), _B, _B).
'$$apply_1_var'(_A, _B, strict(_B), _C, _D):-
        unifyHnfs(_A, strict, _C, _D).

'$$apply_1'('strict\'', _A, 'strict\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'strict\''(_B), _C, _D):-
        unifyHnfs(_A, 'strict\'', _C, _D).

'$$apply_1'(map, _A, map(_A), _B, _B).
'$$apply_1_var'(_A, _B, map(_B), _C, _D):-
        unifyHnfs(_A, map, _C, _D).

'$$apply_1'('.', _A, '.'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '.'(_B), _C, _D):-
        unifyHnfs(_A, '.', _C, _D).

'$$apply_1'('.'(_A), _B, '.'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '.'(_C, _B), _D, _E):-
        unifyHnfs(_A, '.'(_C), _D, _E).

'$$apply_1'(++, _A, ++(_A), _B, _B).
'$$apply_1_var'(_A, _B, ++(_B), _C, _D):-
        unifyHnfs(_A, ++, _C, _D).

'$$apply_1'('!!', _A, '!!'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '!!'(_B), _C, _D):-
        unifyHnfs(_A, '!!', _C, _D).

'$$apply_1'(iterate, _A, iterate(_A), _B, _B).
'$$apply_1_var'(_A, _B, iterate(_B), _C, _D):-
        unifyHnfs(_A, iterate, _C, _D).

'$$apply_1'(copy, _A, copy(_A), _B, _B).
'$$apply_1_var'(_A, _B, copy(_B), _C, _D):-
        unifyHnfs(_A, copy, _C, _D).

'$$apply_1'(filter, _A, filter(_A), _B, _B).
'$$apply_1_var'(_A, _B, filter(_B), _C, _D):-
        unifyHnfs(_A, filter, _C, _D).

'$$apply_1'(foldl, _A, foldl(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldl(_B), _C, _D):-
        unifyHnfs(_A, foldl, _C, _D).

'$$apply_1'(foldl(_A), _B, foldl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, foldl(_C, _B), _D, _E):-
        unifyHnfs(_A, foldl(_C), _D, _E).

'$$apply_1'(foldl1, _A, foldl1(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldl1(_B), _C, _D):-
        unifyHnfs(_A, foldl1, _C, _D).

'$$apply_1'('foldl\'', _A, 'foldl\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'foldl\''(_B), _C, _D):-
        unifyHnfs(_A, 'foldl\'', _C, _D).

'$$apply_1'('foldl\''(_A), _B, 'foldl\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'foldl\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'foldl\''(_C), _D, _E).

'$$apply_1'(scanl, _A, scanl(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanl(_B), _C, _D):-
        unifyHnfs(_A, scanl, _C, _D).

'$$apply_1'(scanl(_A), _B, scanl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scanl(_C, _B), _D, _E):-
        unifyHnfs(_A, scanl(_C), _D, _E).

'$$apply_1'(scanl1, _A, scanl1(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanl1(_B), _C, _D):-
        unifyHnfs(_A, scanl1, _C, _D).

'$$apply_1'('scanl\'', _A, 'scanl\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'scanl\''(_B), _C, _D):-
        unifyHnfs(_A, 'scanl\'', _C, _D).

'$$apply_1'('scanl\''(_A), _B, 'scanl\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'scanl\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'scanl\''(_C), _D, _E).

'$$apply_1'(foldr, _A, foldr(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldr(_B), _C, _D):-
        unifyHnfs(_A, foldr, _C, _D).

'$$apply_1'(foldr(_A), _B, foldr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, foldr(_C, _B), _D, _E):-
        unifyHnfs(_A, foldr(_C), _D, _E).

'$$apply_1'(foldr1, _A, foldr1(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldr1(_B), _C, _D):-
        unifyHnfs(_A, foldr1, _C, _D).

'$$apply_1'(scanr, _A, scanr(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanr(_B), _C, _D):-
        unifyHnfs(_A, scanr, _C, _D).

'$$apply_1'(scanr(_A), _B, scanr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scanr(_C, _B), _D, _E):-
        unifyHnfs(_A, scanr(_C), _D, _E).

'$$apply_1'(auxForScanr, _A, auxForScanr(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForScanr(_B), _C, _D):-
        unifyHnfs(_A, auxForScanr, _C, _D).

'$$apply_1'(auxForScanr(_A), _B, auxForScanr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, auxForScanr(_C, _B), _D, _E):-
        unifyHnfs(_A, auxForScanr(_C), _D, _E).

'$$apply_1'(scanr1, _A, scanr1(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanr1(_B), _C, _D):-
        unifyHnfs(_A, scanr1, _C, _D).

'$$apply_1'(take, _A, take(_A), _B, _B).
'$$apply_1_var'(_A, _B, take(_B), _C, _D):-
        unifyHnfs(_A, take, _C, _D).

'$$apply_1'(drop, _A, drop(_A), _B, _B).
'$$apply_1_var'(_A, _B, drop(_B), _C, _D):-
        unifyHnfs(_A, drop, _C, _D).

'$$apply_1'(splitAt, _A, splitAt(_A), _B, _B).
'$$apply_1_var'(_A, _B, splitAt(_B), _C, _D):-
        unifyHnfs(_A, splitAt, _C, _D).

'$$apply_1'(auxForSplitAt, _A, auxForSplitAt(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForSplitAt(_B), _C, _D):-
        unifyHnfs(_A, auxForSplitAt, _C, _D).

'$$apply_1'(takeWhile, _A, takeWhile(_A), _B, _B).
'$$apply_1_var'(_A, _B, takeWhile(_B), _C, _D):-
        unifyHnfs(_A, takeWhile, _C, _D).

'$$apply_1'(takeUntil, _A, takeUntil(_A), _B, _B).
'$$apply_1_var'(_A, _B, takeUntil(_B), _C, _D):-
        unifyHnfs(_A, takeUntil, _C, _D).

'$$apply_1'(dropWhile, _A, dropWhile(_A), _B, _B).
'$$apply_1_var'(_A, _B, dropWhile(_B), _C, _D):-
        unifyHnfs(_A, dropWhile, _C, _D).

'$$apply_1'(span, _A, span(_A), _B, _B).
'$$apply_1_var'(_A, _B, span(_B), _C, _D):-
        unifyHnfs(_A, span, _C, _D).

'$$apply_1'(auxForSpan, _A, auxForSpan(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForSpan(_B), _C, _D):-
        unifyHnfs(_A, auxForSpan, _C, _D).

'$$apply_1'(zipWith, _A, zipWith(_A), _B, _B).
'$$apply_1_var'(_A, _B, zipWith(_B), _C, _D):-
        unifyHnfs(_A, zipWith, _C, _D).

'$$apply_1'(zipWith(_A), _B, zipWith(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, zipWith(_C, _B), _D, _E):-
        unifyHnfs(_A, zipWith(_C), _D, _E).

'$$apply_1'(zip, _A, zip(_A), _B, _B).
'$$apply_1_var'(_A, _B, zip(_B), _C, _D):-
        unifyHnfs(_A, zip, _C, _D).

'$$apply_1'(mkpair, _A, mkpair(_A), _B, _B).
'$$apply_1_var'(_A, _B, mkpair(_B), _C, _D):-
        unifyHnfs(_A, mkpair, _C, _D).

'$$apply_1'(auxForUnzip, _A, auxForUnzip(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForUnzip(_B), _C, _D):-
        unifyHnfs(_A, auxForUnzip, _C, _D).

'$$apply_1'(auxForUnzip(_A), _B, auxForUnzip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, auxForUnzip(_C, _B), _D, _E):-
        unifyHnfs(_A, auxForUnzip(_C), _D, _E).

'$$apply_1'(until, _A, until(_A), _B, _B).
'$$apply_1_var'(_A, _B, until(_B), _C, _D):-
        unifyHnfs(_A, until, _C, _D).

'$$apply_1'(until(_A), _B, until(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, until(_C, _B), _D, _E):-
        unifyHnfs(_A, until(_C), _D, _E).

'$$apply_1'('until\'', _A, 'until\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'until\''(_B), _C, _D):-
        unifyHnfs(_A, 'until\'', _C, _D).

'$$apply_1'(const, _A, const(_A), _B, _B).
'$$apply_1_var'(_A, _B, const(_B), _C, _D):-
        unifyHnfs(_A, const, _C, _D).

'$$apply_1'(//, _A, //(_A), _B, _B).
'$$apply_1_var'(_A, _B, //(_B), _C, _D):-
        unifyHnfs(_A, //, _C, _D).

'$$apply_1'(curry, _A, curry(_A), _B, _B).
'$$apply_1_var'(_A, _B, curry(_B), _C, _D):-
        unifyHnfs(_A, curry, _C, _D).

'$$apply_1'(curry(_A), _B, curry(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, curry(_C, _B), _D, _E):-
        unifyHnfs(_A, curry(_C), _D, _E).

'$$apply_1'(uncurry, _A, uncurry(_A), _B, _B).
'$$apply_1_var'(_A, _B, uncurry(_B), _C, _D):-
        unifyHnfs(_A, uncurry, _C, _D).

'$$apply_1'(lcm, _A, lcm(_A), _B, _B).
'$$apply_1_var'(_A, _B, lcm(_B), _C, _D):-
        unifyHnfs(_A, lcm, _C, _D).

'$$apply_1'(auxForTranspose, _A, auxForTranspose(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForTranspose(_B), _C, _D):-
        unifyHnfs(_A, auxForTranspose, _C, _D).

'$$apply_1'(del, _A, del(_A), _B, _B).
'$$apply_1_var'(_A, _B, del(_B), _C, _D):-
        unifyHnfs(_A, del, _C, _D).

'$$apply_1'(incrementar, _A, incrementar(_A), _B, _B).
'$$apply_1_var'(_A, _B, incrementar(_B), _C, _D):-
        unifyHnfs(_A, incrementar, _C, _D).

'$$apply_1'(crear_incidencias, _A, crear_incidencias(_A), _B, _B).
'$$apply_1_var'(_A, _B, crear_incidencias(_B), _C, _D):-
        unifyHnfs(_A, crear_incidencias, _C, _D).

'$$apply_1'(crear_incidencias(_A), _B, crear_incidencias(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, crear_incidencias(_C, _B), _D, _E):-
        unifyHnfs(_A, crear_incidencias(_C), _D, _E).

'$$apply_1'(proc_incidencia, _A, proc_incidencia(_A), _B, _B).
'$$apply_1_var'(_A, _B, proc_incidencia(_B), _C, _D):-
        unifyHnfs(_A, proc_incidencia, _C, _D).

'$$apply_1'(incidencias_dia, _A, incidencias_dia(_A), _B, _B).
'$$apply_1_var'(_A, _B, incidencias_dia(_B), _C, _D):-
        unifyHnfs(_A, incidencias_dia, _C, _D).

'$$apply_1'(proc_vacaciones, _A, proc_vacaciones(_A), _B, _B).
'$$apply_1_var'(_A, _B, proc_vacaciones(_B), _C, _D):-
        unifyHnfs(_A, proc_vacaciones, _C, _D).

'$$apply_1'(vacaciones_dia, _A, vacaciones_dia(_A), _B, _B).
'$$apply_1_var'(_A, _B, vacaciones_dia(_B), _C, _D):-
        unifyHnfs(_A, vacaciones_dia, _C, _D).

'$$apply_1'(proc_bajas, _A, proc_bajas(_A), _B, _B).
'$$apply_1_var'(_A, _B, proc_bajas(_B), _C, _D):-
        unifyHnfs(_A, proc_bajas, _C, _D).

'$$apply_1'(bajas_dia, _A, bajas_dia(_A), _B, _B).
'$$apply_1_var'(_A, _B, bajas_dia(_B), _C, _D):-
        unifyHnfs(_A, bajas_dia, _C, _D).

'$$apply_1'(crear_grupos, _A, crear_grupos(_A), _B, _B).
'$$apply_1_var'(_A, _B, crear_grupos(_B), _C, _D):-
        unifyHnfs(_A, crear_grupos, _C, _D).

'$$apply_1'(solicitaNoche, _A, solicitaNoche(_A), _B, _B).
'$$apply_1_var'(_A, _B, solicitaNoche(_B), _C, _D):-
        unifyHnfs(_A, solicitaNoche, _C, _D).

'$$apply_1'(t13trabaja_noche, _A, t13trabaja_noche(_A), _B, _B).
'$$apply_1_var'(_A, _B, t13trabaja_noche(_B), _C, _D):-
        unifyHnfs(_A, t13trabaja_noche, _C, _D).

'$$apply_1'(crear_plan_jornadas, _A, crear_plan_jornadas(_A), _B, _B).
'$$apply_1_var'(_A, _B, crear_plan_jornadas(_B), _C, _D):-
        unifyHnfs(_A, crear_plan_jornadas, _C, _D).

'$$apply_1'(crear_plan_jornadas(_A), _B, crear_plan_jornadas(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, crear_plan_jornadas(_C, _B), _D, _E):-
        unifyHnfs(_A, crear_plan_jornadas(_C), _D, _E).

'$$apply_1'(crear_planificacion, _A, crear_planificacion(_A), _B, _B).
'$$apply_1_var'(_A, _B, crear_planificacion(_B), _C, _D):-
        unifyHnfs(_A, crear_planificacion, _C, _D).

'$$apply_1'(crear_tabla, _A, crear_tabla(_A), _B, _B).
'$$apply_1_var'(_A, _B, crear_tabla(_B), _C, _D):-
        unifyHnfs(_A, crear_tabla, _C, _D).

'$$apply_1'(anotar_en_trabajador, _A, anotar_en_trabajador(_A), _B, _B).
'$$apply_1_var'(_A, _B, anotar_en_trabajador(_B), _C, _D):-
        unifyHnfs(_A, anotar_en_trabajador, _C, _D).

'$$apply_1'(anotar_una, _A, anotar_una(_A), _B, _B).
'$$apply_1_var'(_A, _B, anotar_una(_B), _C, _D):-
        unifyHnfs(_A, anotar_una, _C, _D).

'$$apply_1'(anotar_incidencias, _A, anotar_incidencias(_A), _B, _B).
'$$apply_1_var'(_A, _B, anotar_incidencias(_B), _C, _D):-
        unifyHnfs(_A, anotar_incidencias, _C, _D).

'$$apply_1'(procesar_jornadas, _A, procesar_jornadas(_A), _B, _B).
'$$apply_1_var'(_A, _B, procesar_jornadas(_B), _C, _D):-
        unifyHnfs(_A, procesar_jornadas, _C, _D).

'$$apply_1'(procesar_jornadas(_A), _B, procesar_jornadas(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, procesar_jornadas(_C, _B), _D, _E):-
        unifyHnfs(_A, procesar_jornadas(_C), _D, _E).

'$$apply_1'(procesar_jornadas(_A, _B), _C, procesar_jornadas(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, procesar_jornadas(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, procesar_jornadas(_C, _D), _E, _F).

'$$apply_1'(procesar_jornadas(_A, _B, _C), _D, procesar_jornadas(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, procesar_jornadas(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, procesar_jornadas(_C, _D, _E), _F, _G).

'$$apply_1'(procesar_jornadas(_A, _B, _C, _D), _E, procesar_jornadas(_A, _B, _C, _D, _E), _F, _F).
'$$apply_1_var'(_A, _B, procesar_jornadas(_C, _D, _E, _F, _B), _G, _H):-
        unifyHnfs(_A, procesar_jornadas(_C, _D, _E, _F), _G, _H).

'$$apply_1'(contar, _A, contar(_A), _B, _B).
'$$apply_1_var'(_A, _B, contar(_B), _C, _D):-
        unifyHnfs(_A, contar, _C, _D).

'$$apply_1'(empaquetar, _A, empaquetar(_A), _B, _B).
'$$apply_1_var'(_A, _B, empaquetar(_B), _C, _D):-
        unifyHnfs(_A, empaquetar, _C, _D).

'$$apply_1'(descansar, _A, descansar(_A), _B, _B).
'$$apply_1_var'(_A, _B, descansar(_B), _C, _D):-
        unifyHnfs(_A, descansar, _C, _D).

'$$apply_1'(descansar(_A), _B, descansar(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, descansar(_C, _B), _D, _E):-
        unifyHnfs(_A, descansar(_C), _D, _E).

'$$apply_1'(descansar(_A, _B), _C, descansar(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, descansar(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, descansar(_C, _D), _E, _F).

'$$apply_1'(trabajar, _A, trabajar(_A), _B, _B).
'$$apply_1_var'(_A, _B, trabajar(_B), _C, _D):-
        unifyHnfs(_A, trabajar, _C, _D).

'$$apply_1'(trabajar(_A), _B, trabajar(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, trabajar(_C, _B), _D, _E):-
        unifyHnfs(_A, trabajar(_C), _D, _E).

'$$apply_1'(trabajar(_A, _B), _C, trabajar(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, trabajar(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, trabajar(_C, _D), _E, _F).

'$$apply_1'(procesar_tipo_dia, _A, procesar_tipo_dia(_A), _B, _B).
'$$apply_1_var'(_A, _B, procesar_tipo_dia(_B), _C, _D):-
        unifyHnfs(_A, procesar_tipo_dia, _C, _D).

'$$apply_1'(procesar_tipo_dia(_A), _B, procesar_tipo_dia(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, procesar_tipo_dia(_C, _B), _D, _E):-
        unifyHnfs(_A, procesar_tipo_dia(_C), _D, _E).

'$$apply_1'(procesar_tipo_dia(_A, _B), _C, procesar_tipo_dia(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, procesar_tipo_dia(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, procesar_tipo_dia(_C, _D), _E, _F).

'$$apply_1'(procesar_dia, _A, procesar_dia(_A), _B, _B).
'$$apply_1_var'(_A, _B, procesar_dia(_B), _C, _D):-
        unifyHnfs(_A, procesar_dia, _C, _D).

'$$apply_1'(procesar_dia(_A), _B, procesar_dia(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, procesar_dia(_C, _B), _D, _E):-
        unifyHnfs(_A, procesar_dia(_C), _D, _E).

'$$apply_1'(procesar_dia(_A, _B), _C, procesar_dia(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, procesar_dia(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, procesar_dia(_C, _D), _E, _F).

'$$apply_1'(procesar_dia(_A, _B, _C), _D, procesar_dia(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, procesar_dia(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, procesar_dia(_C, _D, _E), _F, _G).

'$$apply_1'(procesar_dia(_A, _B, _C, _D), _E, procesar_dia(_A, _B, _C, _D, _E), _F, _F).
'$$apply_1_var'(_A, _B, procesar_dia(_C, _D, _E, _F, _B), _G, _H):-
        unifyHnfs(_A, procesar_dia(_C, _D, _E, _F), _G, _H).

'$$apply_1'(procesar_dia(_A, _B, _C, _D, _E), _F, procesar_dia(_A, _B, _C, _D, _E, _F), _G, _G).
'$$apply_1_var'(_A, _B, procesar_dia(_C, _D, _E, _F, _G, _B), _H, _I):-
        unifyHnfs(_A, procesar_dia(_C, _D, _E, _F, _G), _H, _I).

'$$apply_1'(procesar_trabajo, _A, procesar_trabajo(_A), _B, _B).
'$$apply_1_var'(_A, _B, procesar_trabajo(_B), _C, _D):-
        unifyHnfs(_A, procesar_trabajo, _C, _D).

'$$apply_1'(procesar_trabajo(_A), _B, procesar_trabajo(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, procesar_trabajo(_C, _B), _D, _E):-
        unifyHnfs(_A, procesar_trabajo(_C), _D, _E).

'$$apply_1'(procesar_trabajo(_A, _B), _C, procesar_trabajo(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, procesar_trabajo(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, procesar_trabajo(_C, _D), _E, _F).

'$$apply_1'(procesar_trabajo(_A, _B, _C), _D, procesar_trabajo(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, procesar_trabajo(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, procesar_trabajo(_C, _D, _E), _F, _G).

'$$apply_1'(procesar_trabajo(_A, _B, _C, _D), _E, procesar_trabajo(_A, _B, _C, _D, _E), _F, _F).
'$$apply_1_var'(_A, _B, procesar_trabajo(_C, _D, _E, _F, _B), _G, _H):-
        unifyHnfs(_A, procesar_trabajo(_C, _D, _E, _F), _G, _H).

'$$apply_1'(procesar_trabajo(_A, _B, _C, _D, _E), _F, procesar_trabajo(_A, _B, _C, _D, _E, _F), _G, _G).
'$$apply_1_var'(_A, _B, procesar_trabajo(_C, _D, _E, _F, _G, _B), _H, _I):-
        unifyHnfs(_A, procesar_trabajo(_C, _D, _E, _F, _G), _H, _I).

'$$apply_1'(trab_comodin, _A, trab_comodin(_A), _B, _B).
'$$apply_1_var'(_A, _B, trab_comodin(_B), _C, _D):-
        unifyHnfs(_A, trab_comodin, _C, _D).

'$$apply_1'(trab_comodin(_A), _B, trab_comodin(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, trab_comodin(_C, _B), _D, _E):-
        unifyHnfs(_A, trab_comodin(_C), _D, _E).

'$$apply_1'(trab_comodin(_A, _B), _C, trab_comodin(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, trab_comodin(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, trab_comodin(_C, _D), _E, _F).

'$$apply_1'(trabajar_comodin, _A, trabajar_comodin(_A), _B, _B).
'$$apply_1_var'(_A, _B, trabajar_comodin(_B), _C, _D):-
        unifyHnfs(_A, trabajar_comodin, _C, _D).

'$$apply_1'(trabajar_comodin(_A), _B, trabajar_comodin(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, trabajar_comodin(_C, _B), _D, _E):-
        unifyHnfs(_A, trabajar_comodin(_C), _D, _E).

'$$apply_1'(trabajar_comodin(_A, _B), _C, trabajar_comodin(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, trabajar_comodin(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, trabajar_comodin(_C, _D), _E, _F).

'$$apply_1'(extrayendo, _A, extrayendo(_A), _B, _B).
'$$apply_1_var'(_A, _B, extrayendo(_B), _C, _D):-
        unifyHnfs(_A, extrayendo, _C, _D).

'$$apply_1'(extrayendo(_A), _B, extrayendo(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, extrayendo(_C, _B), _D, _E):-
        unifyHnfs(_A, extrayendo(_C), _D, _E).

'$$apply_1'(extrayendo(_A, _B), _C, extrayendo(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, extrayendo(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, extrayendo(_C, _D), _E, _F).

'$$apply_1'(extraer_turnos, _A, extraer_turnos(_A), _B, _B).
'$$apply_1_var'(_A, _B, extraer_turnos(_B), _C, _D):-
        unifyHnfs(_A, extraer_turnos, _C, _D).

'$$apply_1'(extraer_turnos(_A), _B, extraer_turnos(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, extraer_turnos(_C, _B), _D, _E):-
        unifyHnfs(_A, extraer_turnos(_C), _D, _E).

'$$apply_1'(imponer_rotaciones, _A, imponer_rotaciones(_A), _B, _B).
'$$apply_1_var'(_A, _B, imponer_rotaciones(_B), _C, _D):-
        unifyHnfs(_A, imponer_rotaciones, _C, _D).

'$$apply_1'(imponer_rotaciones(_A), _B, imponer_rotaciones(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, imponer_rotaciones(_C, _B), _D, _E):-
        unifyHnfs(_A, imponer_rotaciones(_C), _D, _E).

'$$apply_1'(etiquetar, _A, etiquetar(_A), _B, _B).
'$$apply_1_var'(_A, _B, etiquetar(_B), _C, _D):-
        unifyHnfs(_A, etiquetar, _C, _D).

'$$apply_1'('etiquetar\'', _A, 'etiquetar\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'etiquetar\''(_B), _C, _D):-
        unifyHnfs(_A, 'etiquetar\'', _C, _D).

'$$apply_1'(trabajoMes, _A, trabajoMes(_A), _B, _B).
'$$apply_1_var'(_A, _B, trabajoMes(_B), _C, _D):-
        unifyHnfs(_A, trabajoMes, _C, _D).

'$$apply_1'(trabajoMes(_A), _B, trabajoMes(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, trabajoMes(_C, _B), _D, _E):-
        unifyHnfs(_A, trabajoMes(_C), _D, _E).

'$$apply_1'(hm, _A, hm(_A), _B, _B).
'$$apply_1_var'(_A, _B, hm(_B), _C, _D):-
        unifyHnfs(_A, hm, _C, _D).

'$$apply_1'(hm(_A), _B, hm(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, hm(_C, _B), _D, _E):-
        unifyHnfs(_A, hm(_C), _D, _E).

'$$apply_1'(hm(_A, _B), _C, hm(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, hm(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, hm(_C, _D), _E, _F).

'$$apply_1'(hm(_A, _B, _C), _D, hm(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, hm(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, hm(_C, _D, _E), _F, _G).

'$$apply_1'(horasMesTrabajador, _A, horasMesTrabajador(_A), _B, _B).
'$$apply_1_var'(_A, _B, horasMesTrabajador(_B), _C, _D):-
        unifyHnfs(_A, horasMesTrabajador, _C, _D).

'$$apply_1'(horasMesTrabajador(_A), _B, horasMesTrabajador(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, horasMesTrabajador(_C, _B), _D, _E):-
        unifyHnfs(_A, horasMesTrabajador(_C), _D, _E).

'$$apply_1'(horasMesTrabajador(_A, _B), _C, horasMesTrabajador(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, horasMesTrabajador(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, horasMesTrabajador(_C, _D), _E, _F).

'$$apply_1'(horasMesTrabajador(_A, _B, _C), _D, horasMesTrabajador(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, horasMesTrabajador(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, horasMesTrabajador(_C, _D, _E), _F, _G).

'$$apply_1'(horasCadaMes, _A, horasCadaMes(_A), _B, _B).
'$$apply_1_var'(_A, _B, horasCadaMes(_B), _C, _D):-
        unifyHnfs(_A, horasCadaMes, _C, _D).

'$$apply_1'(horasCadaMes(_A), _B, horasCadaMes(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, horasCadaMes(_C, _B), _D, _E):-
        unifyHnfs(_A, horasCadaMes(_C), _D, _E).

'$$apply_1'(horasCadaMes(_A, _B), _C, horasCadaMes(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, horasCadaMes(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, horasCadaMes(_C, _D), _E, _F).

'$$apply_1'(horasCadaAnio, _A, horasCadaAnio(_A), _B, _B).
'$$apply_1_var'(_A, _B, horasCadaAnio(_B), _C, _D):-
        unifyHnfs(_A, horasCadaAnio, _C, _D).

'$$apply_1'(horasCadaAnio(_A), _B, horasCadaAnio(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, horasCadaAnio(_C, _B), _D, _E):-
        unifyHnfs(_A, horasCadaAnio(_C), _D, _E).

'$$apply_1'(numeroMes, _A, numeroMes(_A), _B, _B).
'$$apply_1_var'(_A, _B, numeroMes(_B), _C, _D):-
        unifyHnfs(_A, numeroMes, _C, _D).

'$$apply_1'(horasMes, _A, horasMes(_A), _B, _B).
'$$apply_1_var'(_A, _B, horasMes(_B), _C, _D):-
        unifyHnfs(_A, horasMes, _C, _D).

'$$apply_1'(horasMes(_A), _B, horasMes(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, horasMes(_C, _B), _D, _E):-
        unifyHnfs(_A, horasMes(_C), _D, _E).

'$$apply_1'(planificar, _A, planificar(_A), _B, _B).
'$$apply_1_var'(_A, _B, planificar(_B), _C, _D):-
        unifyHnfs(_A, planificar, _C, _D).

'$$apply_1'(planificar(_A), _B, planificar(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, planificar(_C, _B), _D, _E):-
        unifyHnfs(_A, planificar(_C), _D, _E).

'$$apply_1'(extrayendo2, _A, extrayendo2(_A), _B, _B).
'$$apply_1_var'(_A, _B, extrayendo2(_B), _C, _D):-
        unifyHnfs(_A, extrayendo2, _C, _D).

'$$apply_1'(extrayendo2(_A), _B, extrayendo2(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, extrayendo2(_C, _B), _D, _E):-
        unifyHnfs(_A, extrayendo2(_C), _D, _E).

'$$apply_1'(extrayendo2(_A, _B), _C, extrayendo2(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, extrayendo2(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, extrayendo2(_C, _D), _E, _F).

'$$apply_1'(extraer_turnos2, _A, extraer_turnos2(_A), _B, _B).
'$$apply_1_var'(_A, _B, extraer_turnos2(_B), _C, _D):-
        unifyHnfs(_A, extraer_turnos2, _C, _D).

'$$apply_1'(extraer_turnos2(_A), _B, extraer_turnos2(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, extraer_turnos2(_C, _B), _D, _E):-
        unifyHnfs(_A, extraer_turnos2(_C), _D, _E).

'$$apply_1'(escribir_lab, _A, escribir_lab(_A), _B, _B).
'$$apply_1_var'(_A, _B, escribir_lab(_B), _C, _D):-
        unifyHnfs(_A, escribir_lab, _C, _D).

'$$apply_1'(escribir_laborables, _A, escribir_laborables(_A), _B, _B).
'$$apply_1_var'(_A, _B, escribir_laborables(_B), _C, _D):-
        unifyHnfs(_A, escribir_laborables, _C, _D).

'$$apply_1'(escribir_fes, _A, escribir_fes(_A), _B, _B).
'$$apply_1_var'(_A, _B, escribir_fes(_B), _C, _D):-
        unifyHnfs(_A, escribir_fes, _C, _D).

'$$apply_1'(escribir_festivos, _A, escribir_festivos(_A), _B, _B).
'$$apply_1_var'(_A, _B, escribir_festivos(_B), _C, _D):-
        unifyHnfs(_A, escribir_festivos, _C, _D).

'$$apply_1'(establecer_des, _A, establecer_des(_A), _B, _B).
'$$apply_1_var'(_A, _B, establecer_des(_B), _C, _D):-
        unifyHnfs(_A, establecer_des, _C, _D).

'$$apply_1'(establecer_des(_A), _B, establecer_des(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, establecer_des(_C, _B), _D, _E):-
        unifyHnfs(_A, establecer_des(_C), _D, _E).

'$$apply_1'(establecer_descanso, _A, establecer_descanso(_A), _B, _B).
'$$apply_1_var'(_A, _B, establecer_descanso(_B), _C, _D):-
        unifyHnfs(_A, establecer_descanso, _C, _D).

'$$apply_1'(primera_sol, _A, primera_sol(_A), _B, _B).
'$$apply_1_var'(_A, _B, primera_sol(_B), _C, _D):-
        unifyHnfs(_A, primera_sol, _C, _D).

'$$apply_1'(primera_sol(_A), _B, primera_sol(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, primera_sol(_C, _B), _D, _E):-
        unifyHnfs(_A, primera_sol(_C), _D, _E).

'$$apply_1'(apuntar, _A, apuntar(_A), _B, _B).
'$$apply_1_var'(_A, _B, apuntar(_B), _C, _D):-
        unifyHnfs(_A, apuntar, _C, _D).

'$$apply_1'(actividad_comodin, _A, actividad_comodin(_A), _B, _B).
'$$apply_1_var'(_A, _B, actividad_comodin(_B), _C, _D):-
        unifyHnfs(_A, actividad_comodin, _C, _D).

'$$apply_1'(actividad_comodin(_A), _B, actividad_comodin(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, actividad_comodin(_C, _B), _D, _E):-
        unifyHnfs(_A, actividad_comodin(_C), _D, _E).

'$$apply_1'(actividad_comodin(_A, _B), _C, actividad_comodin(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, actividad_comodin(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, actividad_comodin(_C, _D), _E, _F).

'$$apply_1'(actividad_comodin(_A, _B, _C), _D, actividad_comodin(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, actividad_comodin(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, actividad_comodin(_C, _D, _E), _F, _G).

'$$apply_1'(primera_sol_act, _A, primera_sol_act(_A), _B, _B).
'$$apply_1_var'(_A, _B, primera_sol_act(_B), _C, _D):-
        unifyHnfs(_A, primera_sol_act, _C, _D).

'$$apply_1'(primera_sol_act(_A), _B, primera_sol_act(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, primera_sol_act(_C, _B), _D, _E):-
        unifyHnfs(_A, primera_sol_act(_C), _D, _E).

'$$apply_1'(primera_sol_act(_A, _B), _C, primera_sol_act(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, primera_sol_act(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, primera_sol_act(_C, _D), _E, _F).

'$$apply_1'(primera_sol_act(_A, _B, _C), _D, primera_sol_act(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, primera_sol_act(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, primera_sol_act(_C, _D, _E), _F, _G).

'$$apply_1'(planificar_una, _A, planificar_una(_A), _B, _B).
'$$apply_1_var'(_A, _B, planificar_una(_B), _C, _D):-
        unifyHnfs(_A, planificar_una, _C, _D).

'$$apply_1'(inizio, _A, inizio(_A), _B, _B).
'$$apply_1_var'(_A, _B, inizio(_B), _C, _D):-
        unifyHnfs(_A, inizio, _C, _D).

'$$apply_1'(resto, _A, resto(_A), _B, _B).
'$$apply_1_var'(_A, _B, resto(_B), _C, _D):-
        unifyHnfs(_A, resto, _C, _D).

'$$apply_1'(generar_lista, _A, generar_lista(_A), _B, _B).
'$$apply_1_var'(_A, _B, generar_lista(_B), _C, _D):-
        unifyHnfs(_A, generar_lista, _C, _D).

'$$apply_1'(intentar, _A, intentar(_A), _B, _B).
'$$apply_1_var'(_A, _B, intentar(_B), _C, _D):-
        unifyHnfs(_A, intentar, _C, _D).

'$$apply_1'(mi_busqueda, _A, mi_busqueda(_A), _B, _B).
'$$apply_1_var'(_A, _B, mi_busqueda(_B), _C, _D):-
        unifyHnfs(_A, mi_busqueda, _C, _D).

'$$apply_1'(elemento, _A, elemento(_A), _B, _B).
'$$apply_1_var'(_A, _B, elemento(_B), _C, _D):-
        unifyHnfs(_A, elemento, _C, _D).

'$$apply_1'(deXhastaY, _A, deXhastaY(_A), _B, _B).
'$$apply_1_var'(_A, _B, deXhastaY(_B), _C, _D):-
        unifyHnfs(_A, deXhastaY, _C, _D).

'$$apply_1'('div\'', _A, 'div\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'div\''(_B), _C, _D):-
        unifyHnfs(_A, 'div\'', _C, _D).

'$$apply_1'(sustituir, _A, sustituir(_A), _B, _B).
'$$apply_1_var'(_A, _B, sustituir(_B), _C, _D):-
        unifyHnfs(_A, sustituir, _C, _D).

'$$apply_1'(sustituir(_A), _B, sustituir(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, sustituir(_C, _B), _D, _E):-
        unifyHnfs(_A, sustituir(_C), _D, _E).

'$$apply_1'(eliminar, _A, eliminar(_A), _B, _B).
'$$apply_1_var'(_A, _B, eliminar(_B), _C, _D):-
        unifyHnfs(_A, eliminar, _C, _D).

% parcial aplictions of prims

'$$apply_1'(evalfd, _A, evalfd(_A), _B, _B).
'$$apply_1_var'(_A, _B, evalfd(_B), _C, _D):-
        unifyHnfs(_A, evalfd, _C, _D).

'$$apply_1'(+, _A, +(_A), _B, _B).
'$$apply_1_var'(_A, _B, +(_B), _C, _D):-
        unifyHnfs(_A, +, _C, _D).

'$$apply_1'(-, _A, -(_A), _B, _B).
'$$apply_1_var'(_A, _B, -(_B), _C, _D):-
        unifyHnfs(_A, -, _C, _D).

'$$apply_1'(*, _A, *(_A), _B, _B).
'$$apply_1_var'(_A, _B, *(_B), _C, _D):-
        unifyHnfs(_A, *, _C, _D).

'$$apply_1'(min, _A, min(_A), _B, _B).
'$$apply_1_var'(_A, _B, min(_B), _C, _D):-
        unifyHnfs(_A, min, _C, _D).

'$$apply_1'(max, _A, max(_A), _B, _B).
'$$apply_1_var'(_A, _B, max(_B), _C, _D):-
        unifyHnfs(_A, max, _C, _D).

'$$apply_1'(/, _A, /(_A), _B, _B).
'$$apply_1_var'(_A, _B, /(_B), _C, _D):-
        unifyHnfs(_A, /, _C, _D).

'$$apply_1'(**, _A, **(_A), _B, _B).
'$$apply_1_var'(_A, _B, **(_B), _C, _D):-
        unifyHnfs(_A, **, _C, _D).

'$$apply_1'(log, _A, log(_A), _B, _B).
'$$apply_1_var'(_A, _B, log(_B), _C, _D):-
        unifyHnfs(_A, log, _C, _D).

'$$apply_1'(^, _A, ^(_A), _B, _B).
'$$apply_1_var'(_A, _B, ^(_B), _C, _D):-
        unifyHnfs(_A, ^, _C, _D).

'$$apply_1'(div, _A, div(_A), _B, _B).
'$$apply_1_var'(_A, _B, div(_B), _C, _D):-
        unifyHnfs(_A, div, _C, _D).

'$$apply_1'(mod, _A, mod(_A), _B, _B).
'$$apply_1_var'(_A, _B, mod(_B), _C, _D):-
        unifyHnfs(_A, mod, _C, _D).

'$$apply_1'(gcd, _A, gcd(_A), _B, _B).
'$$apply_1_var'(_A, _B, gcd(_B), _C, _D):-
        unifyHnfs(_A, gcd, _C, _D).

'$$apply_1'(<, _A, <(_A), _B, _B).
'$$apply_1_var'(_A, _B, <(_B), _C, _D):-
        unifyHnfs(_A, <, _C, _D).

'$$apply_1'(<=, _A, <=(_A), _B, _B).
'$$apply_1_var'(_A, _B, <=(_B), _C, _D):-
        unifyHnfs(_A, <=, _C, _D).

'$$apply_1'(>, _A, >(_A), _B, _B).
'$$apply_1_var'(_A, _B, >(_B), _C, _D):-
        unifyHnfs(_A, >, _C, _D).

'$$apply_1'(>=, _A, >=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >=(_B), _C, _D):-
        unifyHnfs(_A, >=, _C, _D).

'$$apply_1'(==, _A, ==(_A), _B, _B).
'$$apply_1_var'(_A, _B, ==(_B), _C, _D):-
        unifyHnfs(_A, ==, _C, _D).

'$$apply_1'(/=, _A, /=(_A), _B, _B).
'$$apply_1_var'(_A, _B, /=(_B), _C, _D):-
        unifyHnfs(_A, /=, _C, _D).

'$$apply_1'(>>, _A, >>(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>(_B), _C, _D):-
        unifyHnfs(_A, >>, _C, _D).

'$$apply_1'(>>=, _A, >>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>=(_B), _C, _D):-
        unifyHnfs(_A, >>=, _C, _D).

'$$apply_1'(cont2, _A, cont2(_A), _B, _B).
'$$apply_1_var'(_A, _B, cont2(_B), _C, _D):-
        unifyHnfs(_A, cont2, _C, _D).

'$$apply_1'(writeFile, _A, writeFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeFile(_B), _C, _D):-
        unifyHnfs(_A, writeFile, _C, _D).

'$$apply_1'(selectWhereVariableXi, _A, selectWhereVariableXi(_A), _B, _B).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_B), _C, _D):-
        unifyHnfs(_A, selectWhereVariableXi, _C, _D).

'$$apply_1'(selectWhereVariableXi(_A), _B, selectWhereVariableXi(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _B), _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_C), _D, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B), _C, selectWhereVariableXi(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, selectWhereVariableXi(_C, _D), _E, _F).

'$$apply_1'(collectN, _A, collectN(_A), _B, _B).
'$$apply_1_var'(_A, _B, collectN(_B), _C, _D):-
        unifyHnfs(_A, collectN, _C, _D).

'$$apply_1'(if_then_else, _A, if_then_else(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then_else(_B), _C, _D):-
        unifyHnfs(_A, if_then_else, _C, _D).

'$$apply_1'(if_then_else(_A), _B, if_then_else(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, if_then_else(_C, _B), _D, _E):-
        unifyHnfs(_A, if_then_else(_C), _D, _E).

'$$apply_1'(if_then, _A, if_then(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then(_B), _C, _D):-
        unifyHnfs(_A, if_then, _C, _D).

'$$apply_1'(flip, _A, flip(_A), _B, _B).
'$$apply_1_var'(_A, _B, flip(_B), _C, _D):-
        unifyHnfs(_A, flip, _C, _D).

'$$apply_1'(flip(_A), _B, flip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, flip(_C, _B), _D, _E):-
        unifyHnfs(_A, flip(_C), _D, _E).

'$$apply_1'(bb_minimize, _A, bb_minimize(_A), _B, _B).
'$$apply_1_var'(_A, _B, bb_minimize(_B), _C, _D):-
        unifyHnfs(_A, bb_minimize, _C, _D).

'$$apply_1'(bb_maximize, _A, bb_maximize(_A), _B, _B).
'$$apply_1_var'(_A, _B, bb_maximize(_B), _C, _D):-
        unifyHnfs(_A, bb_maximize, _C, _D).

% functions

'$$apply_1'('$eqFun'(_A), _B, _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$eqFun'(_F), _D, _G),
        '$$eqFun'(_F, _B, _C, _G, _E).

'$$apply_1'('$notEqFun'(_A), _B, _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$notEqFun'(_F), _D, _G),
        '$$notEqFun'(_F, _B, _C, _G, _E).

'$$apply_1'(write, _A, _B, _C, _D):-
        '$write'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, write, _D, _F),
        '$write'(_B, _C, _F, _E).

'$$apply_1'(#==(_A), _B, _C, _D, _E):-
        $#==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #==(_F), _D, _G),
        $#==(_F, _B, _C, _G, _E).

'$$apply_1'(#/==(_A), _B, _C, _D, _E):-
        $#/==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #/==(_F), _D, _G),
        $#/==(_F, _B, _C, _G, _E).

'$$apply_1'(domain(_A, _B), _C, _D, _E, _F):-
        '$domain'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, domain(_F, _G), _D, _H),
        '$domain'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(subset(_A), _B, _C, _D, _E):-
        '$subset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, subset(_F), _D, _G),
        '$subset'(_F, _B, _C, _G, _E).

'$$apply_1'(inset(_A), _B, _C, _D, _E):-
        '$inset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, inset(_F), _D, _G),
        '$inset'(_F, _B, _C, _G, _E).

'$$apply_1'(setcomplement(_A), _B, _C, _D, _E):-
        '$setcomplement'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, setcomplement(_F), _D, _G),
        '$setcomplement'(_F, _B, _C, _G, _E).

'$$apply_1'(intersect(_A), _B, _C, _D, _E):-
        '$intersect'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, intersect(_F), _D, _G),
        '$intersect'(_F, _B, _C, _G, _E).

'$$apply_1'(belongs(_A), _B, _C, _D, _E):-
        '$belongs'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, belongs(_F), _D, _G),
        '$belongs'(_F, _B, _C, _G, _E).

'$$apply_1'(labeling(_A), _B, _C, _D, _E):-
        '$labeling'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, labeling(_F), _D, _G),
        '$labeling'(_F, _B, _C, _G, _E).

'$$apply_1'(indomain, _A, _B, _C, _D):-
        '$indomain'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, indomain, _D, _F),
        '$indomain'(_B, _C, _F, _E).

'$$apply_1'(fdminimize(_A), _B, _C, _D, _E):-
        '$fdminimize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdminimize(_F), _D, _G),
        '$fdminimize'(_F, _B, _C, _G, _E).

'$$apply_1'(fdmaximize(_A), _B, _C, _D, _E):-
        '$fdmaximize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdmaximize(_F), _D, _G),
        '$fdmaximize'(_F, _B, _C, _G, _E).

'$$apply_1'(#=(_A), _B, _C, _D, _E):-
        $#=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #=(_F), _D, _G),
        $#=(_F, _B, _C, _G, _E).

'$$apply_1'(#\=(_A), _B, _C, _D, _E):-
        $#\=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #\=(_F), _D, _G),
        $#\=(_F, _B, _C, _G, _E).

'$$apply_1'(#<(_A), _B, _C, _D, _E):-
        $#<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #<(_F), _D, _G),
        $#<(_F, _B, _C, _G, _E).

'$$apply_1'(#<=(_A), _B, _C, _D, _E):-
        $#<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #<=(_F), _D, _G),
        $#<=(_F, _B, _C, _G, _E).

'$$apply_1'(#>(_A), _B, _C, _D, _E):-
        $#>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #>(_F), _D, _G),
        $#>(_F, _B, _C, _G, _E).

'$$apply_1'(#>=(_A), _B, _C, _D, _E):-
        $#>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #>=(_F), _D, _G),
        $#>=(_F, _B, _C, _G, _E).

'$$apply_1'(#+(_A), _B, _C, _D, _E):-
        $#+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #+(_F), _D, _G),
        $#+(_F, _B, _C, _G, _E).

'$$apply_1'(#-(_A), _B, _C, _D, _E):-
        $#-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #-(_F), _D, _G),
        $#-(_F, _B, _C, _G, _E).

'$$apply_1'(#*(_A), _B, _C, _D, _E):-
        $#*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #*(_F), _D, _G),
        $#*(_F, _B, _C, _G, _E).

'$$apply_1'(#/(_A), _B, _C, _D, _E):-
        $#/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #/(_F), _D, _G),
        $#/(_F, _B, _C, _G, _E).

'$$apply_1'(#&(_A), _B, _C, _D, _E):-
        $#&(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #&(_F), _D, _G),
        $#&(_F, _B, _C, _G, _E).

'$$apply_1'(sum(_A, _B), _C, _D, _E, _F):-
        '$sum'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sum(_F, _G), _D, _H),
        '$sum'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scalar_product(_A, _B, _C), _D, _E, _F, _G):-
        '$scalar_product'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scalar_product(_F, _G, _H), _D, _I),
        '$scalar_product'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(all_different, _A, _B, _C, _D):-
        '$all_different'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, all_different, _D, _F),
        '$all_different'(_B, _C, _F, _E).

'$$apply_1'('all_different\''(_A), _B, _C, _D, _E):-
        '$all_different\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'all_different\''(_F), _D, _G),
        '$all_different\''(_F, _B, _C, _G, _E).

'$$apply_1'(assignment(_A), _B, _C, _D, _E):-
        '$assignment'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, assignment(_F), _D, _G),
        '$assignment'(_F, _B, _C, _G, _E).

'$$apply_1'(circuit, _A, _B, _C, _D):-
        '$circuit'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, circuit, _D, _F),
        '$circuit'(_B, _C, _F, _E).

'$$apply_1'('circuit\''(_A), _B, _C, _D, _E):-
        '$circuit\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'circuit\''(_F), _D, _G),
        '$circuit\''(_F, _B, _C, _G, _E).

'$$apply_1'(count(_A, _B, _C), _D, _E, _F, _G):-
        '$count'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, count(_F, _G, _H), _D, _I),
        '$count'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(element(_A, _B), _C, _D, _E, _F):-
        '$element'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, element(_F, _G), _D, _H),
        '$element'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(exactly(_A, _B), _C, _D, _E, _F):-
        '$exactly'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exactly(_F, _G), _D, _H),
        '$exactly'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(serialized(_A), _B, _C, _D, _E):-
        '$serialized'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, serialized(_F), _D, _G),
        '$serialized'(_F, _B, _C, _G, _E).

'$$apply_1'('serialized\''(_A, _B), _C, _D, _E, _F):-
        '$serialized\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'serialized\''(_F, _G), _D, _H),
        '$serialized\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(cumulative(_A, _B, _C), _D, _E, _F, _G):-
        '$cumulative'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cumulative(_F, _G, _H), _D, _I),
        '$cumulative'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'('cumulative\''(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$cumulative\''(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cumulative\''(_F, _G, _H, _I), _D, _J),
        '$cumulative\''(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(#\/(_A), _B, _C, _D, _E):-
        $#\/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #\/(_F), _D, _G),
        $#\/(_F, _B, _C, _G, _E).

'$$apply_1'(#<=>(_A), _B, _C, _D, _E):-
        $#<=>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #<=>(_F), _D, _G),
        $#<=>(_F, _B, _C, _G, _E).

'$$apply_1'(#=>(_A), _B, _C, _D, _E):-
        $#=>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #=>(_F), _D, _G),
        $#=>(_F, _B, _C, _G, _E).

'$$apply_1'(fd_var, _A, _B, _C, _D):-
        '$fd_var'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_var, _D, _F),
        '$fd_var'(_B, _C, _F, _E).

'$$apply_1'(fd_min, _A, _B, _C, _D):-
        '$fd_min'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_min, _D, _F),
        '$fd_min'(_B, _C, _F, _E).

'$$apply_1'(fd_max, _A, _B, _C, _D):-
        '$fd_max'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_max, _D, _F),
        '$fd_max'(_B, _C, _F, _E).

'$$apply_1'(fd_size, _A, _B, _C, _D):-
        '$fd_size'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_size, _D, _F),
        '$fd_size'(_B, _C, _F, _E).

'$$apply_1'(fd_set, _A, _B, _C, _D):-
        '$fd_set'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_set, _D, _F),
        '$fd_set'(_B, _C, _F, _E).

'$$apply_1'(fd_dom, _A, _B, _C, _D):-
        '$fd_dom'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_dom, _D, _F),
        '$fd_dom'(_B, _C, _F, _E).

'$$apply_1'(fd_degree, _A, _B, _C, _D):-
        '$fd_degree'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_degree, _D, _F),
        '$fd_degree'(_B, _C, _F, _E).

'$$apply_1'(fd_neighbors, _A, _B, _C, _D):-
        '$fd_neighbors'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_neighbors, _D, _F),
        '$fd_neighbors'(_B, _C, _F, _E).

'$$apply_1'(fd_closure, _A, _B, _C, _D):-
        '$fd_closure'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_closure, _D, _F),
        '$fd_closure'(_B, _C, _F, _E).

'$$apply_1'(is_fdset, _A, _B, _C, _D):-
        '$is_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, is_fdset, _D, _F),
        '$is_fdset'(_B, _C, _F, _E).

'$$apply_1'(empty_fdset, _A, _B, _C, _D):-
        '$empty_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, empty_fdset, _D, _F),
        '$empty_fdset'(_B, _C, _F, _E).

'$$apply_1'(fdset_parts(_A, _B), _C, _D, _E, _F):-
        '$fdset_parts'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_parts(_F, _G), _D, _H),
        '$fdset_parts'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(fdset_split, _A, _B, _C, _D):-
        '$fdset_split'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_split, _D, _F),
        '$fdset_split'(_B, _C, _F, _E).

'$$apply_1'(empty_interval(_A), _B, _C, _D, _E):-
        '$empty_interval'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, empty_interval(_F), _D, _G),
        '$empty_interval'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_to_interval, _A, _B, _C, _D):-
        '$fdset_to_interval'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_to_interval, _D, _F),
        '$fdset_to_interval'(_B, _C, _F, _E).

'$$apply_1'(interval_to_fdset(_A), _B, _C, _D, _E):-
        '$interval_to_fdset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, interval_to_fdset(_F), _D, _G),
        '$interval_to_fdset'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_singleton(_A), _B, _C, _D, _E):-
        '$fdset_singleton'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_singleton(_F), _D, _G),
        '$fdset_singleton'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_min, _A, _B, _C, _D):-
        '$fdset_min'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_min, _D, _F),
        '$fdset_min'(_B, _C, _F, _E).

'$$apply_1'(fdset_max, _A, _B, _C, _D):-
        '$fdset_max'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_max, _D, _F),
        '$fdset_max'(_B, _C, _F, _E).

'$$apply_1'(fdset_size, _A, _B, _C, _D):-
        '$fdset_size'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_size, _D, _F),
        '$fdset_size'(_B, _C, _F, _E).

'$$apply_1'(list_to_fdset, _A, _B, _C, _D):-
        '$list_to_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, list_to_fdset, _D, _F),
        '$list_to_fdset'(_B, _C, _F, _E).

'$$apply_1'(fdset_to_list, _A, _B, _C, _D):-
        '$fdset_to_list'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_to_list, _D, _F),
        '$fdset_to_list'(_B, _C, _F, _E).

'$$apply_1'(range_to_fdset, _A, _B, _C, _D):-
        '$range_to_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, range_to_fdset, _D, _F),
        '$range_to_fdset'(_B, _C, _F, _E).

'$$apply_1'(fdset_to_range, _A, _B, _C, _D):-
        '$fdset_to_range'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_to_range, _D, _F),
        '$fdset_to_range'(_B, _C, _F, _E).

'$$apply_1'(fdset_add_element(_A), _B, _C, _D, _E):-
        '$fdset_add_element'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_add_element(_F), _D, _G),
        '$fdset_add_element'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_del_element(_A), _B, _C, _D, _E):-
        '$fdset_del_element'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_del_element(_F), _D, _G),
        '$fdset_del_element'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_intersection(_A), _B, _C, _D, _E):-
        '$fdset_intersection'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_intersection(_F), _D, _G),
        '$fdset_intersection'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_subtract(_A), _B, _C, _D, _E):-
        '$fdset_subtract'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_subtract(_F), _D, _G),
        '$fdset_subtract'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_union(_A), _B, _C, _D, _E):-
        '$fdset_union'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_union(_F), _D, _G),
        '$fdset_union'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_complement, _A, _B, _C, _D):-
        '$fdset_complement'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_complement, _D, _F),
        '$fdset_complement'(_B, _C, _F, _E).

'$$apply_1'(fdsets_intersection, _A, _B, _C, _D):-
        '$fdsets_intersection'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdsets_intersection, _D, _F),
        '$fdsets_intersection'(_B, _C, _F, _E).

'$$apply_1'(fdsets_union, _A, _B, _C, _D):-
        '$fdsets_union'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdsets_union, _D, _F),
        '$fdsets_union'(_B, _C, _F, _E).

'$$apply_1'(fdset_equal(_A), _B, _C, _D, _E):-
        '$fdset_equal'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_equal(_F), _D, _G),
        '$fdset_equal'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_subset(_A), _B, _C, _D, _E):-
        '$fdset_subset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_subset(_F), _D, _G),
        '$fdset_subset'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_disjoint(_A), _B, _C, _D, _E):-
        '$fdset_disjoint'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_disjoint(_F), _D, _G),
        '$fdset_disjoint'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_intersect(_A), _B, _C, _D, _E):-
        '$fdset_intersect'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_intersect(_F), _D, _G),
        '$fdset_intersect'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_member(_A), _B, _C, _D, _E):-
        '$fdset_member'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_member(_F), _D, _G),
        '$fdset_member'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_belongs(_A), _B, _C, _D, _E):-
        '$fdset_belongs'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_belongs(_F), _D, _G),
        '$fdset_belongs'(_F, _B, _C, _G, _E).

'$$apply_1'(isin(_A), _B, _C, _D, _E):-
        '$isin'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, isin(_F), _D, _G),
        '$isin'(_F, _B, _C, _G, _E).

'$$apply_1'(minimum, _A, _B, _C, _D):-
        '$minimum'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, minimum, _D, _F),
        '$minimum'(_B, _C, _F, _E).

'$$apply_1'('fd_statistics\'', _A, _B, _C, _D):-
        '$fd_statistics\''(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'fd_statistics\'', _D, _F),
        '$fd_statistics\''(_B, _C, _F, _E).

'$$apply_1'(fd_global(_A, _B), _C, _D, _E, _F):-
        '$fd_global'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_global(_F, _G), _D, _H),
        '$fd_global'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(and(_A), _B, _C, _D, _E):-
        '$and'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, and(_F), _D, _G),
        '$and'(_F, _B, _C, _G, _E).

'$$apply_1'(or(_A), _B, _C, _D, _E):-
        '$or'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, or(_F), _D, _G),
        '$or'(_F, _B, _C, _G, _E).

'$$apply_1'(/\(_A), _B, _C, _D, _E):-
        $/\(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /\(_F), _D, _G),
        $/\(_F, _B, _C, _G, _E).

'$$apply_1'(\/(_A), _B, _C, _D, _E):-
        $\/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, \/(_F), _D, _G),
        $\/(_F, _B, _C, _G, _E).

'$$apply_1'(not, _A, _B, _C, _D):-
        '$not'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, not, _D, _F),
        '$not'(_B, _C, _F, _E).

'$$apply_1'(any, _A, _B, _C, _D):-
        '$any'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, any, _D, _F),
        '$any'(_B, _C, _F, _E).

'$$apply_1'('any\'', _A, _B, _C, _D):-
        '$any\''(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'any\'', _D, _F),
        '$any\''(_B, _C, _F, _E).

'$$apply_1'(all, _A, _B, _C, _D):-
        '$all'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, all, _D, _F),
        '$all'(_B, _C, _F, _E).

'$$apply_1'(def, _A, _B, _C, _D):-
        '$def'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, def, _D, _F),
        '$def'(_B, _C, _F, _E).

'$$apply_1'(not_undef, _A, _B, _C, _D):-
        '$not_undef'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, not_undef, _D, _F),
        '$not_undef'(_B, _C, _F, _E).

'$$apply_1'(nf, _A, _B, _C, _D):-
        '$nf'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, nf, _D, _F),
        '$nf'(_B, _C, _F, _E).

'$$apply_1'(hnf, _A, _B, _C, _D):-
        '$hnf'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, hnf, _D, _F),
        '$hnf'(_B, _C, _F, _E).

'$$apply_1'(strict(_A), _B, _C, _D, _E):-
        '$strict'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, strict(_F), _D, _G),
        '$strict'(_F, _B, _C, _G, _E).

'$$apply_1'('strict\''(_A), _B, _C, _D, _E):-
        '$strict\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'strict\''(_F), _D, _G),
        '$strict\''(_F, _B, _C, _G, _E).

'$$apply_1'(map(_A), _B, _C, _D, _E):-
        '$map'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, map(_F), _D, _G),
        '$map'(_F, _B, _C, _G, _E).

'$$apply_1'('.'(_A, _B), _C, _D, _E, _F):-
        $.(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '.'(_F, _G), _D, _H),
        $.(_F, _G, _B, _C, _H, _E).

'$$apply_1'(++(_A), _B, _C, _D, _E):-
        $++(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ++(_F), _D, _G),
        $++(_F, _B, _C, _G, _E).

'$$apply_1'('!!'(_A), _B, _C, _D, _E):-
        '$!!'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '!!'(_F), _D, _G),
        '$!!'(_F, _B, _C, _G, _E).

'$$apply_1'(iterate(_A), _B, _C, _D, _E):-
        '$iterate'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, iterate(_F), _D, _G),
        '$iterate'(_F, _B, _C, _G, _E).

'$$apply_1'(repeat, _A, _B, _C, _D):-
        '$repeat'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, repeat, _D, _F),
        '$repeat'(_B, _C, _F, _E).

'$$apply_1'(copy(_A), _B, _C, _D, _E):-
        '$copy'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, copy(_F), _D, _G),
        '$copy'(_F, _B, _C, _G, _E).

'$$apply_1'(filter(_A), _B, _C, _D, _E):-
        '$filter'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, filter(_F), _D, _G),
        '$filter'(_F, _B, _C, _G, _E).

'$$apply_1'(foldl(_A, _B), _C, _D, _E, _F):-
        '$foldl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldl(_F, _G), _D, _H),
        '$foldl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldl1(_A), _B, _C, _D, _E):-
        '$foldl1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldl1(_F), _D, _G),
        '$foldl1'(_F, _B, _C, _G, _E).

'$$apply_1'('foldl\''(_A, _B), _C, _D, _E, _F):-
        '$foldl\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'foldl\''(_F, _G), _D, _H),
        '$foldl\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanl(_A, _B), _C, _D, _E, _F):-
        '$scanl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanl(_F, _G), _D, _H),
        '$scanl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanl1(_A), _B, _C, _D, _E):-
        '$scanl1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanl1(_F), _D, _G),
        '$scanl1'(_F, _B, _C, _G, _E).

'$$apply_1'('scanl\''(_A, _B), _C, _D, _E, _F):-
        '$scanl\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'scanl\''(_F, _G), _D, _H),
        '$scanl\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldr(_A, _B), _C, _D, _E, _F):-
        '$foldr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldr(_F, _G), _D, _H),
        '$foldr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldr1(_A), _B, _C, _D, _E):-
        '$foldr1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldr1(_F), _D, _G),
        '$foldr1'(_F, _B, _C, _G, _E).

'$$apply_1'(scanr(_A, _B), _C, _D, _E, _F):-
        '$scanr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanr(_F, _G), _D, _H),
        '$scanr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(auxForScanr(_A, _B), _C, _D, _E, _F):-
        '$auxForScanr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForScanr(_F, _G), _D, _H),
        '$auxForScanr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanr1(_A), _B, _C, _D, _E):-
        '$scanr1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanr1(_F), _D, _G),
        '$scanr1'(_F, _B, _C, _G, _E).

'$$apply_1'(take(_A), _B, _C, _D, _E):-
        '$take'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, take(_F), _D, _G),
        '$take'(_F, _B, _C, _G, _E).

'$$apply_1'(drop(_A), _B, _C, _D, _E):-
        '$drop'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, drop(_F), _D, _G),
        '$drop'(_F, _B, _C, _G, _E).

'$$apply_1'(splitAt(_A), _B, _C, _D, _E):-
        '$splitAt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, splitAt(_F), _D, _G),
        '$splitAt'(_F, _B, _C, _G, _E).

'$$apply_1'(auxForSplitAt(_A), _B, _C, _D, _E):-
        '$auxForSplitAt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForSplitAt(_F), _D, _G),
        '$auxForSplitAt'(_F, _B, _C, _G, _E).

'$$apply_1'(takeWhile(_A), _B, _C, _D, _E):-
        '$takeWhile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, takeWhile(_F), _D, _G),
        '$takeWhile'(_F, _B, _C, _G, _E).

'$$apply_1'(takeUntil(_A), _B, _C, _D, _E):-
        '$takeUntil'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, takeUntil(_F), _D, _G),
        '$takeUntil'(_F, _B, _C, _G, _E).

'$$apply_1'(dropWhile(_A), _B, _C, _D, _E):-
        '$dropWhile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dropWhile(_F), _D, _G),
        '$dropWhile'(_F, _B, _C, _G, _E).

'$$apply_1'(span(_A), _B, _C, _D, _E):-
        '$span'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, span(_F), _D, _G),
        '$span'(_F, _B, _C, _G, _E).

'$$apply_1'(auxForSpan(_A), _B, _C, _D, _E):-
        '$auxForSpan'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForSpan(_F), _D, _G),
        '$auxForSpan'(_F, _B, _C, _G, _E).

'$$apply_1'(break, _A, _B, _C, _D):-
        '$break'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, break, _D, _F),
        '$break'(_B, _C, _F, _E).

'$$apply_1'(zipWith(_A, _B), _C, _D, _E, _F):-
        '$zipWith'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, zipWith(_F, _G), _D, _H),
        '$zipWith'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(zip(_A), _B, _C, _D, _E):-
        '$zip'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, zip(_F), _D, _G),
        '$zip'(_F, _B, _C, _G, _E).

'$$apply_1'(mkpair(_A), _B, _C, _D, _E):-
        '$mkpair'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mkpair(_F), _D, _G),
        '$mkpair'(_F, _B, _C, _G, _E).

'$$apply_1'(unzip, _A, _B, _C, _D):-
        '$unzip'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, unzip, _D, _F),
        '$unzip'(_B, _C, _F, _E).

'$$apply_1'(auxForUnzip(_A, _B), _C, _D, _E, _F):-
        '$auxForUnzip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForUnzip(_F, _G), _D, _H),
        '$auxForUnzip'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(until(_A, _B), _C, _D, _E, _F):-
        '$until'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, until(_F, _G), _D, _H),
        '$until'(_F, _G, _B, _C, _H, _E).

'$$apply_1'('until\''(_A), _B, _C, _D, _E):-
        '$until\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'until\''(_F), _D, _G),
        '$until\''(_F, _B, _C, _G, _E).

'$$apply_1'(const(_A), _B, _C, _D, _E):-
        '$const'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, const(_F), _D, _G),
        '$const'(_F, _B, _C, _G, _E).

'$$apply_1'(id, _A, _B, _C, _D):-
        '$id'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, id, _D, _F),
        '$id'(_B, _C, _F, _E).

'$$apply_1'(//(_A), _B, _C, _D, _E):-
        $//(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, //(_F), _D, _G),
        $//(_F, _B, _C, _G, _E).

'$$apply_1'(curry(_A, _B), _C, _D, _E, _F):-
        '$curry'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, curry(_F, _G), _D, _H),
        '$curry'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(uncurry(_A), _B, _C, _D, _E):-
        '$uncurry'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uncurry(_F), _D, _G),
        '$uncurry'(_F, _B, _C, _G, _E).

'$$apply_1'(fst, _A, _B, _C, _D):-
        '$fst'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fst, _D, _F),
        '$fst'(_B, _C, _F, _E).

'$$apply_1'(snd, _A, _B, _C, _D):-
        '$snd'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, snd, _D, _F),
        '$snd'(_B, _C, _F, _E).

'$$apply_1'(fst3, _A, _B, _C, _D):-
        '$fst3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fst3, _D, _F),
        '$fst3'(_B, _C, _F, _E).

'$$apply_1'(snd3, _A, _B, _C, _D):-
        '$snd3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, snd3, _D, _F),
        '$snd3'(_B, _C, _F, _E).

'$$apply_1'(thd3, _A, _B, _C, _D):-
        '$thd3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, thd3, _D, _F),
        '$thd3'(_B, _C, _F, _E).

'$$apply_1'(even, _A, _B, _C, _D):-
        '$even'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, even, _D, _F),
        '$even'(_B, _C, _F, _E).

'$$apply_1'(lcm(_A), _B, _C, _D, _E):-
        '$lcm'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, lcm(_F), _D, _G),
        '$lcm'(_F, _B, _C, _G, _E).

'$$apply_1'(head, _A, _B, _C, _D):-
        '$head'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, head, _D, _F),
        '$head'(_B, _C, _F, _E).

'$$apply_1'(last, _A, _B, _C, _D):-
        '$last'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, last, _D, _F),
        '$last'(_B, _C, _F, _E).

'$$apply_1'(tail, _A, _B, _C, _D):-
        '$tail'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tail, _D, _F),
        '$tail'(_B, _C, _F, _E).

'$$apply_1'(init, _A, _B, _C, _D):-
        '$init'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, init, _D, _F),
        '$init'(_B, _C, _F, _E).

'$$apply_1'(nub, _A, _B, _C, _D):-
        '$nub'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, nub, _D, _F),
        '$nub'(_B, _C, _F, _E).

'$$apply_1'(length, _A, _B, _C, _D):-
        '$length'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, length, _D, _F),
        '$length'(_B, _C, _F, _E).

'$$apply_1'(auxForTranspose(_A), _B, _C, _D, _E):-
        '$auxForTranspose'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForTranspose(_F), _D, _G),
        '$auxForTranspose'(_F, _B, _C, _G, _E).

'$$apply_1'(del(_A), _B, _C, _D, _E):-
        '$del'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, del(_F), _D, _G),
        '$del'(_F, _B, _C, _G, _E).

'$$apply_1'(grupo_activo, _A, _B, _C, _D):-
        '$grupo_activo'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, grupo_activo, _D, _F),
        '$grupo_activo'(_B, _C, _F, _E).

'$$apply_1'(incrementar(_A), _B, _C, _D, _E):-
        '$incrementar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, incrementar(_F), _D, _G),
        '$incrementar'(_F, _B, _C, _G, _E).

'$$apply_1'(crear_incidencias(_A, _B), _C, _D, _E, _F):-
        '$crear_incidencias'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, crear_incidencias(_F, _G), _D, _H),
        '$crear_incidencias'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(proc_incidencia(_A), _B, _C, _D, _E):-
        '$proc_incidencia'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, proc_incidencia(_F), _D, _G),
        '$proc_incidencia'(_F, _B, _C, _G, _E).

'$$apply_1'(inicio, _A, _B, _C, _D):-
        '$inicio'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, inicio, _D, _F),
        '$inicio'(_B, _C, _F, _E).

'$$apply_1'(incidencias_dia(_A), _B, _C, _D, _E):-
        '$incidencias_dia'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, incidencias_dia(_F), _D, _G),
        '$incidencias_dia'(_F, _B, _C, _G, _E).

'$$apply_1'(proc_vacaciones(_A), _B, _C, _D, _E):-
        '$proc_vacaciones'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, proc_vacaciones(_F), _D, _G),
        '$proc_vacaciones'(_F, _B, _C, _G, _E).

'$$apply_1'(vacaciones_dia(_A), _B, _C, _D, _E):-
        '$vacaciones_dia'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, vacaciones_dia(_F), _D, _G),
        '$vacaciones_dia'(_F, _B, _C, _G, _E).

'$$apply_1'(proc_bajas(_A), _B, _C, _D, _E):-
        '$proc_bajas'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, proc_bajas(_F), _D, _G),
        '$proc_bajas'(_F, _B, _C, _G, _E).

'$$apply_1'(bajas_dia(_A), _B, _C, _D, _E):-
        '$bajas_dia'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, bajas_dia(_F), _D, _G),
        '$bajas_dia'(_F, _B, _C, _G, _E).

'$$apply_1'(crear_grupos(_A), _B, _C, _D, _E):-
        '$crear_grupos'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, crear_grupos(_F), _D, _G),
        '$crear_grupos'(_F, _B, _C, _G, _E).

'$$apply_1'(solicitaNoche(_A), _B, _C, _D, _E):-
        '$solicitaNoche'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, solicitaNoche(_F), _D, _G),
        '$solicitaNoche'(_F, _B, _C, _G, _E).

'$$apply_1'(puedeNoche, _A, _B, _C, _D):-
        '$puedeNoche'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, puedeNoche, _D, _F),
        '$puedeNoche'(_B, _C, _F, _E).

'$$apply_1'(t13trabaja_noche(_A), _B, _C, _D, _E):-
        '$t13trabaja_noche'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, t13trabaja_noche(_F), _D, _G),
        '$t13trabaja_noche'(_F, _B, _C, _G, _E).

'$$apply_1'(crear_plan_jornadas(_A, _B), _C, _D, _E, _F):-
        '$crear_plan_jornadas'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, crear_plan_jornadas(_F, _G), _D, _H),
        '$crear_plan_jornadas'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(crear_trabajo, _A, _B, _C, _D):-
        '$crear_trabajo'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, crear_trabajo, _D, _F),
        '$crear_trabajo'(_B, _C, _F, _E).

'$$apply_1'(crear_planificacion(_A), _B, _C, _D, _E):-
        '$crear_planificacion'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, crear_planificacion(_F), _D, _G),
        '$crear_planificacion'(_F, _B, _C, _G, _E).

'$$apply_1'(borrar_uno, _A, _B, _C, _D):-
        '$borrar_uno'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, borrar_uno, _D, _F),
        '$borrar_uno'(_B, _C, _F, _E).

'$$apply_1'(quitar_primeros, _A, _B, _C, _D):-
        '$quitar_primeros'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, quitar_primeros, _D, _F),
        '$quitar_primeros'(_B, _C, _F, _E).

'$$apply_1'(prim, _A, _B, _C, _D):-
        '$prim'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, prim, _D, _F),
        '$prim'(_B, _C, _F, _E).

'$$apply_1'(primeros, _A, _B, _C, _D):-
        '$primeros'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, primeros, _D, _F),
        '$primeros'(_B, _C, _F, _E).

'$$apply_1'(listas_vacias, _A, _B, _C, _D):-
        '$listas_vacias'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, listas_vacias, _D, _F),
        '$listas_vacias'(_B, _C, _F, _E).

'$$apply_1'(transponer, _A, _B, _C, _D):-
        '$transponer'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, transponer, _D, _F),
        '$transponer'(_B, _C, _F, _E).

'$$apply_1'(crear_fila, _A, _B, _C, _D):-
        '$crear_fila'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, crear_fila, _D, _F),
        '$crear_fila'(_B, _C, _F, _E).

'$$apply_1'(crear_tabla(_A), _B, _C, _D, _E):-
        '$crear_tabla'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, crear_tabla(_F), _D, _G),
        '$crear_tabla'(_F, _B, _C, _G, _E).

'$$apply_1'(anotar_en_trabajador(_A), _B, _C, _D, _E):-
        '$anotar_en_trabajador'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, anotar_en_trabajador(_F), _D, _G),
        '$anotar_en_trabajador'(_F, _B, _C, _G, _E).

'$$apply_1'(anotar_una(_A), _B, _C, _D, _E):-
        '$anotar_una'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, anotar_una(_F), _D, _G),
        '$anotar_una'(_F, _B, _C, _G, _E).

'$$apply_1'(anotar_incidencias(_A), _B, _C, _D, _E):-
        '$anotar_incidencias'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, anotar_incidencias(_F), _D, _G),
        '$anotar_incidencias'(_F, _B, _C, _G, _E).

'$$apply_1'(procesar_jornadas(_A, _B, _C, _D, _E), _F, _G, _H, _I):-
        '$procesar_jornadas'(_A, _B, _C, _D, _E, _F, _G, _H, _I).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, procesar_jornadas(_F, _G, _H, _I, _J), _D, _K),
        '$procesar_jornadas'(_F, _G, _H, _I, _J, _B, _C, _K, _E).

'$$apply_1'(contar(_A), _B, _C, _D, _E):-
        '$contar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, contar(_F), _D, _G),
        '$contar'(_F, _B, _C, _G, _E).

'$$apply_1'(empaquetar(_A), _B, _C, _D, _E):-
        '$empaquetar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, empaquetar(_F), _D, _G),
        '$empaquetar'(_F, _B, _C, _G, _E).

'$$apply_1'(proyectar, _A, _B, _C, _D):-
        '$proyectar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, proyectar, _D, _F),
        '$proyectar'(_B, _C, _F, _E).

'$$apply_1'(anotar_trab, _A, _B, _C, _D):-
        '$anotar_trab'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, anotar_trab, _D, _F),
        '$anotar_trab'(_B, _C, _F, _E).

'$$apply_1'(anotar_desc, _A, _B, _C, _D):-
        '$anotar_desc'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, anotar_desc, _D, _F),
        '$anotar_desc'(_B, _C, _F, _E).

'$$apply_1'(descansar(_A, _B, _C), _D, _E, _F, _G):-
        '$descansar'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, descansar(_F, _G, _H), _D, _I),
        '$descansar'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(trabajar(_A, _B, _C), _D, _E, _F, _G):-
        '$trabajar'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trabajar(_F, _G, _H), _D, _I),
        '$trabajar'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(grupo, _A, _B, _C, _D):-
        '$grupo'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, grupo, _D, _F),
        '$grupo'(_B, _C, _F, _E).

'$$apply_1'(procesar_tipo_dia(_A, _B, _C), _D, _E, _F, _G):-
        '$procesar_tipo_dia'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, procesar_tipo_dia(_F, _G, _H), _D, _I),
        '$procesar_tipo_dia'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(procesar_dia(_A, _B, _C, _D, _E, _F), _G, _H, _I, _J):-
        '$procesar_dia'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, procesar_dia(_F, _G, _H, _I, _J, _K), _D, _L),
        '$procesar_dia'(_F, _G, _H, _I, _J, _K, _B, _C, _L, _E).

'$$apply_1'(procesar_trabajo(_A, _B, _C, _D, _E, _F), _G, _H, _I, _J):-
        '$procesar_trabajo'(_A, _B, _C, _D, _E, _F, _G, _H, _I, _J).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, procesar_trabajo(_F, _G, _H, _I, _J, _K), _D, _L),
        '$procesar_trabajo'(_F, _G, _H, _I, _J, _K, _B, _C, _L, _E).

'$$apply_1'(trab_comodin(_A, _B, _C), _D, _E, _F, _G):-
        '$trab_comodin'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trab_comodin(_F, _G, _H), _D, _I),
        '$trab_comodin'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(trabajar_comodin(_A, _B, _C), _D, _E, _F, _G):-
        '$trabajar_comodin'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trabajar_comodin(_F, _G, _H), _D, _I),
        '$trabajar_comodin'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(proc_t6, _A, _B, _C, _D):-
        '$proc_t6'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, proc_t6, _D, _F),
        '$proc_t6'(_B, _C, _F, _E).

'$$apply_1'(sin_t6, _A, _B, _C, _D):-
        '$sin_t6'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sin_t6, _D, _F),
        '$sin_t6'(_B, _C, _F, _E).

'$$apply_1'(no_t6, _A, _B, _C, _D):-
        '$no_t6'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, no_t6, _D, _F),
        '$no_t6'(_B, _C, _F, _E).

'$$apply_1'(valido_laborables, _A, _B, _C, _D):-
        '$valido_laborables'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, valido_laborables, _D, _F),
        '$valido_laborables'(_B, _C, _F, _E).

'$$apply_1'(valido_festivos, _A, _B, _C, _D):-
        '$valido_festivos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, valido_festivos, _D, _F),
        '$valido_festivos'(_B, _C, _F, _E).

'$$apply_1'(extrayendo(_A, _B, _C), _D, _E, _F, _G):-
        '$extrayendo'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, extrayendo(_F, _G, _H), _D, _I),
        '$extrayendo'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(extraer_turnos(_A, _B), _C, _D, _E, _F):-
        '$extraer_turnos'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, extraer_turnos(_F, _G), _D, _H),
        '$extraer_turnos'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(sacar_laborables, _A, _B, _C, _D):-
        '$sacar_laborables'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sacar_laborables, _D, _F),
        '$sacar_laborables'(_B, _C, _F, _E).

'$$apply_1'(extraer_laborables, _A, _B, _C, _D):-
        '$extraer_laborables'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, extraer_laborables, _D, _F),
        '$extraer_laborables'(_B, _C, _F, _E).

'$$apply_1'(sacar_festivos, _A, _B, _C, _D):-
        '$sacar_festivos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sacar_festivos, _D, _F),
        '$sacar_festivos'(_B, _C, _F, _E).

'$$apply_1'(extraer_festivos, _A, _B, _C, _D):-
        '$extraer_festivos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, extraer_festivos, _D, _F),
        '$extraer_festivos'(_B, _C, _F, _E).

'$$apply_1'(rotar_turnos_laborables, _A, _B, _C, _D):-
        '$rotar_turnos_laborables'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, rotar_turnos_laborables, _D, _F),
        '$rotar_turnos_laborables'(_B, _C, _F, _E).

'$$apply_1'(rotar_turnos_festivos, _A, _B, _C, _D):-
        '$rotar_turnos_festivos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, rotar_turnos_festivos, _D, _F),
        '$rotar_turnos_festivos'(_B, _C, _F, _E).

'$$apply_1'(imponer_rotaciones(_A, _B), _C, _D, _E, _F):-
        '$imponer_rotaciones'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, imponer_rotaciones(_F, _G), _D, _H),
        '$imponer_rotaciones'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(rango_jornadas, _A, _B, _C, _D):-
        '$rango_jornadas'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, rango_jornadas, _D, _F),
        '$rango_jornadas'(_B, _C, _F, _E).

'$$apply_1'(establecer_dominios, _A, _B, _C, _D):-
        '$establecer_dominios'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, establecer_dominios, _D, _F),
        '$establecer_dominios'(_B, _C, _F, _E).

'$$apply_1'(etiquetar(_A), _B, _C, _D, _E):-
        '$etiquetar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, etiquetar(_F), _D, _G),
        '$etiquetar'(_F, _B, _C, _G, _E).

'$$apply_1'(extraer, _A, _B, _C, _D):-
        '$extraer'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, extraer, _D, _F),
        '$extraer'(_B, _C, _F, _E).

'$$apply_1'('etiquetar\''(_A), _B, _C, _D, _E):-
        '$etiquetar\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'etiquetar\''(_F), _D, _G),
        '$etiquetar\''(_F, _B, _C, _G, _E).

'$$apply_1'(m0_0, _A, _B, _C, _D):-
        '$m0_0'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m0_0, _D, _F),
        '$m0_0'(_B, _C, _F, _E).

'$$apply_1'(m1_24, _A, _B, _C, _D):-
        '$m1_24'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m1_24, _D, _F),
        '$m1_24'(_B, _C, _F, _E).

'$$apply_1'(m2_14, _A, _B, _C, _D):-
        '$m2_14'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m2_14, _D, _F),
        '$m2_14'(_B, _C, _F, _E).

'$$apply_1'(m3_14, _A, _B, _C, _D):-
        '$m3_14'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m3_14, _D, _F),
        '$m3_14'(_B, _C, _F, _E).

'$$apply_1'(m4_17, _A, _B, _C, _D):-
        '$m4_17'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m4_17, _D, _F),
        '$m4_17'(_B, _C, _F, _E).

'$$apply_1'(m5_13, _A, _B, _C, _D):-
        '$m5_13'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m5_13, _D, _F),
        '$m5_13'(_B, _C, _F, _E).

'$$apply_1'(m6_6, _A, _B, _C, _D):-
        '$m6_6'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m6_6, _D, _F),
        '$m6_6'(_B, _C, _F, _E).

'$$apply_1'(m7_6, _A, _B, _C, _D):-
        '$m7_6'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m7_6, _D, _F),
        '$m7_6'(_B, _C, _F, _E).

'$$apply_1'(m8_0, _A, _B, _C, _D):-
        '$m8_0'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, m8_0, _D, _F),
        '$m8_0'(_B, _C, _F, _E).

'$$apply_1'('duracion\'', _A, _B, _C, _D):-
        '$duracion\''(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'duracion\'', _D, _F),
        '$duracion\''(_B, _C, _F, _E).

'$$apply_1'(duracion, _A, _B, _C, _D):-
        '$duracion'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, duracion, _D, _F),
        '$duracion'(_B, _C, _F, _E).

'$$apply_1'(horasTrabajador, _A, _B, _C, _D):-
        '$horasTrabajador'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, horasTrabajador, _D, _F),
        '$horasTrabajador'(_B, _C, _F, _E).

'$$apply_1'(trabajoMes(_A, _B), _C, _D, _E, _F):-
        '$trabajoMes'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trabajoMes(_F, _G), _D, _H),
        '$trabajoMes'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(hm(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$hm'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, hm(_F, _G, _H, _I), _D, _J),
        '$hm'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(horasMesTrabajador(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$horasMesTrabajador'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, horasMesTrabajador(_F, _G, _H, _I), _D, _J),
        '$horasMesTrabajador'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(horasCadaMes(_A, _B, _C), _D, _E, _F, _G):-
        '$horasCadaMes'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, horasCadaMes(_F, _G, _H), _D, _I),
        '$horasCadaMes'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(horasCadaAnio(_A, _B), _C, _D, _E, _F):-
        '$horasCadaAnio'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, horasCadaAnio(_F, _G), _D, _H),
        '$horasCadaAnio'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(obtenerMes, _A, _B, _C, _D):-
        '$obtenerMes'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, obtenerMes, _D, _F),
        '$obtenerMes'(_B, _C, _F, _E).

'$$apply_1'(calcularMesUltimo, _A, _B, _C, _D):-
        '$calcularMesUltimo'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, calcularMesUltimo, _D, _F),
        '$calcularMesUltimo'(_B, _C, _F, _E).

'$$apply_1'(numeroMes(_A), _B, _C, _D, _E):-
        '$numeroMes'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, numeroMes(_F), _D, _G),
        '$numeroMes'(_F, _B, _C, _G, _E).

'$$apply_1'(horasMes(_A, _B), _C, _D, _E, _F):-
        '$horasMes'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, horasMes(_F, _G), _D, _H),
        '$horasMes'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(horasAnio, _A, _B, _C, _D):-
        '$horasAnio'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, horasAnio, _D, _F),
        '$horasAnio'(_B, _C, _F, _E).

'$$apply_1'(planificar(_A, _B), _C, _D, _E, _F):-
        '$planificar'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, planificar(_F, _G), _D, _H),
        '$planificar'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(sig_laborable, _A, _B, _C, _D):-
        '$sig_laborable'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sig_laborable, _D, _F),
        '$sig_laborable'(_B, _C, _F, _E).

'$$apply_1'(sig_festivo, _A, _B, _C, _D):-
        '$sig_festivo'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sig_festivo, _D, _F),
        '$sig_festivo'(_B, _C, _F, _E).

'$$apply_1'(extrayendo2(_A, _B, _C), _D, _E, _F, _G):-
        '$extrayendo2'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, extrayendo2(_F, _G, _H), _D, _I),
        '$extrayendo2'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(extraer_turnos2(_A, _B), _C, _D, _E, _F):-
        '$extraer_turnos2'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, extraer_turnos2(_F, _G), _D, _H),
        '$extraer_turnos2'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(escribir_lab(_A), _B, _C, _D, _E):-
        '$escribir_lab'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, escribir_lab(_F), _D, _G),
        '$escribir_lab'(_F, _B, _C, _G, _E).

'$$apply_1'(escribir_laborables(_A), _B, _C, _D, _E):-
        '$escribir_laborables'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, escribir_laborables(_F), _D, _G),
        '$escribir_laborables'(_F, _B, _C, _G, _E).

'$$apply_1'(escribir_fes(_A), _B, _C, _D, _E):-
        '$escribir_fes'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, escribir_fes(_F), _D, _G),
        '$escribir_fes'(_F, _B, _C, _G, _E).

'$$apply_1'(escribir_festivos(_A), _B, _C, _D, _E):-
        '$escribir_festivos'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, escribir_festivos(_F), _D, _G),
        '$escribir_festivos'(_F, _B, _C, _G, _E).

'$$apply_1'(establecer_des(_A, _B), _C, _D, _E, _F):-
        '$establecer_des'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, establecer_des(_F, _G), _D, _H),
        '$establecer_des'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(establecer_descanso(_A), _B, _C, _D, _E):-
        '$establecer_descanso'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, establecer_descanso(_F), _D, _G),
        '$establecer_descanso'(_F, _B, _C, _G, _E).

'$$apply_1'(primera_sol(_A, _B), _C, _D, _E, _F):-
        '$primera_sol'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, primera_sol(_F, _G), _D, _H),
        '$primera_sol'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(apuntar(_A), _B, _C, _D, _E):-
        '$apuntar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, apuntar(_F), _D, _G),
        '$apuntar'(_F, _B, _C, _G, _E).

'$$apply_1'(actividad_comodin(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$actividad_comodin'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, actividad_comodin(_F, _G, _H, _I), _D, _J),
        '$actividad_comodin'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(primera_sol_act(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$primera_sol_act'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, primera_sol_act(_F, _G, _H, _I), _D, _J),
        '$primera_sol_act'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(reapuntar, _A, _B, _C, _D):-
        '$reapuntar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, reapuntar, _D, _F),
        '$reapuntar'(_B, _C, _F, _E).

'$$apply_1'(planificar_una(_A), _B, _C, _D, _E):-
        '$planificar_una'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, planificar_una(_F), _D, _G),
        '$planificar_una'(_F, _B, _C, _G, _E).

'$$apply_1'(j2esj1, _A, _B, _C, _D):-
        '$j2esj1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, j2esj1, _D, _F),
        '$j2esj1'(_B, _C, _F, _E).

'$$apply_1'(inizio(_A), _B, _C, _D, _E):-
        '$inizio'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, inizio(_F), _D, _G),
        '$inizio'(_F, _B, _C, _G, _E).

'$$apply_1'(resto(_A), _B, _C, _D, _E):-
        '$resto'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, resto(_F), _D, _G),
        '$resto'(_F, _B, _C, _G, _E).

'$$apply_1'(generar_lista(_A), _B, _C, _D, _E):-
        '$generar_lista'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, generar_lista(_F), _D, _G),
        '$generar_lista'(_F, _B, _C, _G, _E).

'$$apply_1'(intentar(_A), _B, _C, _D, _E):-
        '$intentar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, intentar(_F), _D, _G),
        '$intentar'(_F, _B, _C, _G, _E).

'$$apply_1'(mi_busqueda(_A), _B, _C, _D, _E):-
        '$mi_busqueda'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mi_busqueda(_F), _D, _G),
        '$mi_busqueda'(_F, _B, _C, _G, _E).

'$$apply_1'(esNocturno, _A, _B, _C, _D):-
        '$esNocturno'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, esNocturno, _D, _F),
        '$esNocturno'(_B, _C, _F, _E).

'$$apply_1'(elemento(_A), _B, _C, _D, _E):-
        '$elemento'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, elemento(_F), _D, _G),
        '$elemento'(_F, _B, _C, _G, _E).

'$$apply_1'(deXhastaY(_A), _B, _C, _D, _E):-
        '$deXhastaY'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, deXhastaY(_F), _D, _G),
        '$deXhastaY'(_F, _B, _C, _G, _E).

'$$apply_1'('div\''(_A), _B, _C, _D, _E):-
        '$div\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'div\''(_F), _D, _G),
        '$div\''(_F, _B, _C, _G, _E).

'$$apply_1'(sustituir(_A, _B), _C, _D, _E, _F):-
        '$sustituir'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sustituir(_F, _G), _D, _H),
        '$sustituir'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(ultimo, _A, _B, _C, _D):-
        '$ultimo'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ultimo, _D, _F),
        '$ultimo'(_B, _C, _F, _E).

'$$apply_1'(n_menos_1, _A, _B, _C, _D):-
        '$n_menos_1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, n_menos_1, _D, _F),
        '$n_menos_1'(_B, _C, _F, _E).

'$$apply_1'(invertir, _A, _B, _C, _D):-
        '$invertir'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, invertir, _D, _F),
        '$invertir'(_B, _C, _F, _E).

'$$apply_1'(card, _A, _B, _C, _D):-
        '$card'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, card, _D, _F),
        '$card'(_B, _C, _F, _E).

'$$apply_1'(eliminar(_A), _B, _C, _D, _E):-
        '$eliminar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, eliminar(_F), _D, _G),
        '$eliminar'(_F, _B, _C, _G, _E).

'$$apply_1'(ini, _A, _B, _C, _D):-
        '$ini'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ini, _D, _F),
        '$ini'(_B, _C, _F, _E).

'$$apply_1'(iniln, _A, _B, _C, _D):-
        '$iniln'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, iniln, _D, _F),
        '$iniln'(_B, _C, _F, _E).

% primitives

'$$apply_1'(uminus, _A, _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uminus, _D, _F),
        '$uminus'(_B, _C, _F, _E).

'$$apply_1'(abs, _A, _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, abs, _D, _F),
        '$abs'(_B, _C, _F, _E).

'$$apply_1'(sqrt, _A, _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sqrt, _D, _F),
        '$sqrt'(_B, _C, _F, _E).

'$$apply_1'(ln, _A, _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ln, _D, _F),
        '$ln'(_B, _C, _F, _E).

'$$apply_1'(exp, _A, _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exp, _D, _F),
        '$exp'(_B, _C, _F, _E).

'$$apply_1'(sin, _A, _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sin, _D, _F),
        '$sin'(_B, _C, _F, _E).

'$$apply_1'(cos, _A, _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cos, _D, _F),
        '$cos'(_B, _C, _F, _E).

'$$apply_1'(tan, _A, _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tan, _D, _F),
        '$tan'(_B, _C, _F, _E).

'$$apply_1'(cot, _A, _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cot, _D, _F),
        '$cot'(_B, _C, _F, _E).

'$$apply_1'(asin, _A, _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asin, _D, _F),
        '$asin'(_B, _C, _F, _E).

'$$apply_1'(acos, _A, _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acos, _D, _F),
        '$acos'(_B, _C, _F, _E).

'$$apply_1'(atan, _A, _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atan, _D, _F),
        '$atan'(_B, _C, _F, _E).

'$$apply_1'(acot, _A, _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acot, _D, _F),
        '$acot'(_B, _C, _F, _E).

'$$apply_1'(sinh, _A, _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sinh, _D, _F),
        '$sinh'(_B, _C, _F, _E).

'$$apply_1'(cosh, _A, _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cosh, _D, _F),
        '$cosh'(_B, _C, _F, _E).

'$$apply_1'(tanh, _A, _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tanh, _D, _F),
        '$tanh'(_B, _C, _F, _E).

'$$apply_1'(coth, _A, _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, coth, _D, _F),
        '$coth'(_B, _C, _F, _E).

'$$apply_1'(asinh, _A, _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asinh, _D, _F),
        '$asinh'(_B, _C, _F, _E).

'$$apply_1'(acosh, _A, _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acosh, _D, _F),
        '$acosh'(_B, _C, _F, _E).

'$$apply_1'(atanh, _A, _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atanh, _D, _F),
        '$atanh'(_B, _C, _F, _E).

'$$apply_1'(acoth, _A, _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acoth, _D, _F),
        '$acoth'(_B, _C, _F, _E).

'$$apply_1'(evalfd(_A), _B, _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, evalfd(_F), _D, _G),
        '$evalfd'(_F, _B, _C, _G, _E).

'$$apply_1'(+(_A), _B, _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, +(_F), _D, _G),
        $+(_F, _B, _C, _G, _E).

'$$apply_1'(-(_A), _B, _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, -(_F), _D, _G),
        $-(_F, _B, _C, _G, _E).

'$$apply_1'(*(_A), _B, _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, *(_F), _D, _G),
        $*(_F, _B, _C, _G, _E).

'$$apply_1'(min(_A), _B, _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, min(_F), _D, _G),
        '$min'(_F, _B, _C, _G, _E).

'$$apply_1'(max(_A), _B, _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, max(_F), _D, _G),
        '$max'(_F, _B, _C, _G, _E).

'$$apply_1'(/(_A), _B, _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /(_F), _D, _G),
        $/(_F, _B, _C, _G, _E).

'$$apply_1'(**(_A), _B, _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, **(_F), _D, _G),
        $**(_F, _B, _C, _G, _E).

'$$apply_1'(log(_A), _B, _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, log(_F), _D, _G),
        '$log'(_F, _B, _C, _G, _E).

'$$apply_1'(^(_A), _B, _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ^(_F), _D, _G),
        $^(_F, _B, _C, _G, _E).

'$$apply_1'(div(_A), _B, _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, div(_F), _D, _G),
        '$div'(_F, _B, _C, _G, _E).

'$$apply_1'(mod(_A), _B, _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mod(_F), _D, _G),
        '$mod'(_F, _B, _C, _G, _E).

'$$apply_1'(gcd(_A), _B, _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, gcd(_F), _D, _G),
        '$gcd'(_F, _B, _C, _G, _E).

'$$apply_1'(round, _A, _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, round, _D, _F),
        '$round'(_B, _C, _F, _E).

'$$apply_1'(trunc, _A, _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trunc, _D, _F),
        '$trunc'(_B, _C, _F, _E).

'$$apply_1'(floor, _A, _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, floor, _D, _F),
        '$floor'(_B, _C, _F, _E).

'$$apply_1'(ceiling, _A, _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ceiling, _D, _F),
        '$ceiling'(_B, _C, _F, _E).

'$$apply_1'(toReal, _A, _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, toReal, _D, _F),
        '$toReal'(_B, _C, _F, _E).

'$$apply_1'(<(_A), _B, _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <(_F), _D, _G),
        $<(_F, _B, _C, _G, _E).

'$$apply_1'(<=(_A), _B, _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <=(_F), _D, _G),
        $<=(_F, _B, _C, _G, _E).

'$$apply_1'(>(_A), _B, _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >(_F), _D, _G),
        $>(_F, _B, _C, _G, _E).

'$$apply_1'(>=(_A), _B, _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >=(_F), _D, _G),
        $>=(_F, _B, _C, _G, _E).

'$$apply_1'(==(_A), _B, _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ==(_F), _D, _G),
        $==(_F, _B, _C, _G, _E).

'$$apply_1'(/=(_A), _B, _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /=(_F), _D, _G),
        $/=(_F, _B, _C, _G, _E).

'$$apply_1'(ord, _A, _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ord, _D, _F),
        '$ord'(_B, _C, _F, _E).

'$$apply_1'(chr, _A, _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, chr, _D, _F),
        '$chr'(_B, _C, _F, _E).

'$$apply_1'(putChar, _A, _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putChar, _D, _F),
        '$putChar'(_B, _C, _F, _E).

'$$apply_1'(return, _A, _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, return, _D, _F),
        '$return'(_B, _C, _F, _E).

'$$apply_1'(>>(_A), _B, _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>(_F), _D, _G),
        $>>(_F, _B, _C, _G, _E).

'$$apply_1'(>>=(_A), _B, _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>=(_F), _D, _G),
        $>>=(_F, _B, _C, _G, _E).

'$$apply_1'(putStr, _A, _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStr, _D, _F),
        '$putStr'(_B, _C, _F, _E).

'$$apply_1'(putStrLn, _A, _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLn, _D, _F),
        '$putStrLn'(_B, _C, _F, _E).

'$$apply_1'(cont1, _A, _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont1, _D, _F),
        '$cont1'(_B, _C, _F, _E).

'$$apply_1'(cont2(_A), _B, _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont2(_F), _D, _G),
        '$cont2'(_F, _B, _C, _G, _E).

'$$apply_1'(writeFile(_A), _B, _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeFile(_F), _D, _G),
        '$writeFile'(_F, _B, _C, _G, _E).

'$$apply_1'(readFile, _A, _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFile, _D, _F),
        '$readFile'(_B, _C, _F, _E).

'$$apply_1'(readFileContents, _A, _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFileContents, _D, _F),
        '$readFileContents'(_B, _C, _F, _E).

'$$apply_1'(dVal, _A, _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dVal, _D, _F),
        '$dVal'(_B, _C, _F, _E).

'$$apply_1'(dValToString, _A, _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dValToString, _D, _F),
        '$dValToString'(_B, _C, _F, _E).

'$$apply_1'(getConstraintStore, _A, _B, _C, _D):-
        '$getConstraintStore'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getConstraintStore, _D, _F),
        '$getConstraintStore'(_B, _C, _F, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B, _C), _D, _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_F, _G, _H), _D, _I),
        '$selectWhereVariableXi'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(fails, _A, _B, _C, _D):-
        '$fails'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fails, _D, _F),
        '$fails'(_B, _C, _F, _E).

'$$apply_1'(once, _A, _B, _C, _D):-
        '$once'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, once, _D, _F),
        '$once'(_B, _C, _F, _E).

'$$apply_1'(collect, _A, _B, _C, _D):-
        '$collect'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, collect, _D, _F),
        '$collect'(_B, _C, _F, _E).

'$$apply_1'(collectN(_A), _B, _C, _D, _E):-
        '$collectN'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, collectN(_F), _D, _G),
        '$collectN'(_F, _B, _C, _G, _E).

'$$apply_1'(if_then_else(_A, _B), _C, _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then_else(_F, _G), _D, _H),
        '$if_then_else'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(if_then(_A), _B, _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then(_F), _D, _G),
        '$if_then'(_F, _B, _C, _G, _E).

'$$apply_1'(flip(_A, _B), _C, _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, flip(_F, _G), _D, _H),
        '$flip'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(minimize, _A, _B, _C, _D):-
        '$minimize'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, minimize, _D, _F),
        '$minimize'(_B, _C, _F, _E).

'$$apply_1'(maximize, _A, _B, _C, _D):-
        '$maximize'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, maximize, _D, _F),
        '$maximize'(_B, _C, _F, _E).

'$$apply_1'(bb_minimize(_A), _B, _C, _D, _E):-
        '$bb_minimize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, bb_minimize(_F), _D, _G),
        '$bb_minimize'(_F, _B, _C, _G, _E).

'$$apply_1'(bb_maximize(_A), _B, _C, _D, _E):-
        '$bb_maximize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, bb_maximize(_F), _D, _G),
        '$bb_maximize'(_F, _B, _C, _G, _E).


/************   CODE FOR INFIX OPERATORS   ************/

infix(#=, noasoc, 20).
infix(#\=, noasoc, 20).
infix(#<, noasoc, 30).
infix(#<=, noasoc, 30).
infix(#>, noasoc, 30).
infix(#>=, noasoc, 30).
infix(#+, left, 50).
infix(#-, left, 50).
infix(#*, right, 90).
infix(#/, left, 90).
infix(#&, left, 90).
infix(#\/, noasoc, 15).
infix(#<=>, noasoc, 15).
infix(#=>, noasoc, 15).
infix('!!', left, 90).
infix('.', right, 90).
infix(++, right, 50).
infix(//, right, 40).
infix(and, right, 40).
infix(/\, right, 40).
infix(or, right, 30).
infix(\/, right, 30).
infix(\\, noasoc, 50).
infix(^, noasoc, 98).
infix(**, noasoc, 98).
infix(/, left, 90).
infix(*, right, 90).
infix(+, left, 50).
infix(-, left, 50).
infix(<, noasoc, 30).
infix(<=, noasoc, 30).
infix(>, noasoc, 30).
infix(>=, noasoc, 30).
infix(==, noasoc, 10).
infix(/=, noasoc, 10).
infix(>>, left, 11).
infix(>>=, left, 11).



'$flip'(F, A1, A2, H, Cin, Cout):-         '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%  BEGIN OF CFLPFDFILE %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% B Sonia
%:- load_files(dyn,[if(changed),imports([ prop_active/0 ])]).
%:- load_files(toycomm,[if(changed)]). %,imports([toSolverFD/3,listToSolverFD/3])]).

:- tools:complete_root_filename(dyn,F),load_files(F,[if(changed),imports([ prop_active/0 ])]).
:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed),imports([toSolverFD/3,listToSolverFD/3])]).
:- dyn:clpr_active, !, tools:complete_root_filename(cooperation,F),load_files(F,[if(changed)]).

%% E Sonia

%%%%%%%%%%%%%%%%  CFLPFD CONSTRAINTS   %%%%%%%%%%%%%%%%%%%%%%%%

:- use_module(library(clpfd)).
:- use_module(library(ordsets)).
:- use_module(library(lists)).

%%  B :: Sonia
:- assert(clpfd:full_answer).
:- use_module(library(clpr)).
%%  E :: Sonia

% Determining the maximum upper and minimum lower bounds of
% finite domains, 
% independent of SICStus version and platform.

narrow(Val0, Val) :-
    clpfd:fd_integer(Val0), !,
    Val = Val0.
narrow(Val0, Val) :-
    Val1 is Val0>>1,
    narrow(Val1, Val).

:-  Min0 is -1<<64,
    narrow(Min0, Min),
    Max0 is (1<<64)-1,
    narrow(Max0, Max),
    assert(cflpfd:inf(Min)),
    assert(cflpfd:sup(Max)).



/**************    CODE FOR FUNCTIONS    **************/

%FSP 06-02-2007 ::B
%% Debugging
% write :: A -> bool
'$write'(A,true,C,C) :-
  (nonvar(A),A = :(_,_) -> toyListToPrologList(A,P); P=A),
  write(P).

%nl :: A -> bool
'$nl'(true,C,C) :-
  nl.
  
%::E


%%%%%%%%%%%%%%%%%%% MEMBERSHIP CONSTRAINTS %%%%%%%%%%%%%%%%%%%%%%

% Sonia B

% comento todo el domain y lo escribo de nuevo con las modificaciones

/*

% domain :: [int] -> int -> int -> bool
% domain :=: [in] -> in -> in -> inout
'$domain'(VL, Low, Upp, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error(domain,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
        hnf(Low, HLow, Cout1, Cout2), 
        hnf(Upp, HUpp, Cout2, Cout), 
        HLow1 is integer(HLow), 
        HUpp1 is integer(HUpp), 
        ((Out=true, domain(PrologHVL, HLow1, HUpp1))
         ;
         (Out=false, HLow2 is integer(HLow1 - 1), HUpp2 is integer(HUpp1 + 1), 
          domain_remove(PrologHVL, HLow2, HUpp2))). 
*/

% domain :: [int] -> int -> int -> bool
% domain :=: [in] -> in -> in -> inout
'$domain'(VL, Low, Upp, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
%FSP 26/02/2007 
        (var(HVL) -> raise_exception(instatiation_error(domain,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
        hnf(Low, HLow, Cout1, Cout2), 
        hnf(Upp, HUpp, Cout2, Cout3), 
        HLow1 is integer(HLow), 
        HUpp1 is integer(HUpp), 
        HLowR is float(HLow1), 
        HUppR is float(HUpp1),
        listToSolverFD(PrologHVL,Cout3,Cout4),
        ((Out=true, domain(PrologHVL, HLow1, HUpp1),
        (prop_active -> (changeDomainR(PrologHVL, HLowR, HUppR,Cout4,Cout),!); Cout = Cout4))
         ;
         (Out=false, HLow2 is integer(HLow1 - 1), HUpp2 is integer(HUpp1 + 1), 
          domain_remove(PrologHVL, HLow2, HUpp2),
%FSP 26/02/2007 
          Cout=Cout4          
           )). 

changeDomainR([], HLowR, HUppR,C, C).

changeDomainR([H|Rest], HLowR, HUppR,Cin, Cout):-
    searchVarsR(H,Cin,Cout1,HR), 
    {HR >= HLowR, HR =< HUppR},
    changeDomainR(Rest, HLowR, HUppR,Cout1, Cout).
% Sonia E

domain_remove([], _HLow2, _HUpp2). 
domain_remove([X|Xs], HLow2, HUpp2) :- 
        X in (inf..HLow2) \/ (HUpp2..sup), 
        domain_remove(Xs, HLow2, HUpp2).


subset(X, Y) +:
  X in dom(Y)/\dom(X).

setcomplement(X, Y) +:
  X in \dom(Y).

% subset :: int -> int -> bool
% subset :=: inout -> inout -> inout
'$subset'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, subset(HL, HR));
         (Out=false, setcomplement(HL, HR))). 
 
% inset :: int -> int -> bool
% inset :=: inout -> inout -> inout
'$inset'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, fd_set(HR, SR), HL in_set SR);
         (Out=false, fd_set(HR, SR), fdset_complement(SR, CSR), HL in_set CSR)). 
 
% setcomplement :: int -> int -> bool
% setcomplement :=: inout -> inout -> inout
'$setcomplement'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, setcomplement(HL, HR));
         (Out=false, subset(HL, HR))). 

% intersect :: int -> int -> int
% intersect :=: inout -> inout -> inout
'$intersect'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        fd_set(HR, SR), 
        fd_set(HL, SL), 
        fdset_intersection(SR, SL, SI), 
        Out in_set SI.
 
% sonia B
/* 

% belongs :: int -> [int] -> bool
% belongs :=: inout -> [in] -> inout
'$belongs'(V, L, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(L, HL, Cout1, Cout), 
        (var(HL) -> raise_exception(instatiation_error(belongs,2)); true),
        toyListToPrologList(HL, PL), 
        list_to_fdset(PL, PS), 
        ((Out=true, HV in_set PS);
         (Out=false, fdset_complement(PS, CPS), HV in_set CPS)).
*/

'$belongs'(V, L, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(L, HL, Cout1, Cout2), 
%FSP 26/02/2007 
        (var(HL) -> raise_exception(instatiation_error(belongs,2)); true),
        toyListToPrologList(HL, PL), 
        list_to_fdset(PL, PS), 
        toSolverFD(HV,Cout2,Cout3),
        listToSolverFD(PL,Cout3,Cout4),
        (( Out=true, HV in_set PS, 
         (prop_active -> (searchVarsR(HV,Cout4,Cout,HVR), 
                     min_list(PL, HLowR),
                     max_list(PL,HUppR),
                     {HVR >= HLowR}, {HVR =< HUppR},!
                   )
                   ;
                   Cout =Cout4
        )
        )
        ;
          ( Out=false, fdset_complement(PS, CPS), HV in_set CPS,
%FSP 26/02/2007 
          Cout=Cout4)
       ).
% sonia E
         

%%%%%%%%%%%%%%%%%%% ENUMERATION FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% labeling :: [labelingType] -> [int] -> bool
% labeling :=: inout -> [inout] -> inout
'$labeling'(OL, VL, true, Cin, Cout) :- 
        nf(OL, HOL, Cin, Cout1), 
        toyListToPrologList(HOL, PrologHOL), 
%B::Sonia        
%        nf(VL, HVL, Cout1, Cout), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
        listToSolverFD(PrologHVL,Cout2,Cout),
%E::Sonia        
        processLabelingOptions(PrologHOL, LabPrologHOL), 
        labeling(LabPrologHOL, PrologHVL), 
        translateLabOptions(LabToyHOL, LabPrologHOL), 
        toyNonVarListToPrologList(OL, LabToyHOL).


processLabelingOptions(TLs, PLs) :- 
        setof(TLs, validLabOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateLabOptions(TLs, PLs).


memberU(X, [X|Xs]).
memberU(X, [Y|Xs]) :- memberU(X, Xs).

removeU_duplicates(L, S) :- 
        removeU_duplicates(L, [], S). % List, GrowingNonDuplicatesList, Set

removeU_duplicates([], In, In).
removeU_duplicates([X|Xs], In, Set) :- 
        nonU_member(X, In), !, append(In, [X], NIn), !, 
        removeU_duplicates(Xs, NIn, Set).
removeU_duplicates([_|Xs], In, Set) :- 
        removeU_duplicates(Xs, In, Set).


nonU_member(_, []) :- !.
nonU_member(X, [X|_]) :- 
        !, fail.
nonU_member(X, [Y|Ys]) :- 
        \+ X=Y, 
        nonU_member(X, Ys).


validLabOptions(Opts) :- 
        (groundL1(Opts) -> buildGroundLabOptSet(OptSet) ; buildLabOptSet(OptSet)), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).

groundL1(L) :- 
        L == [], !.
groundL1([H|T]) :- 
        ((ground(H) ; nonvar(H)) -> groundL1(T)).


ordU_subset([], _).
ordU_subset([H|T1], [H|T2]) :- ordU_subset(T1, T2).
ordU_subset([H1|T1], [H2|T2]) :- lt(H2, H1), ordU_subset([H1|T1], T2).

lt(X, Y) :- var(X); var(Y).
lt(X, Y) :- nonvar(X), nonvar(Y), X @< Y.


buildLabOptSet(OptSet) :- 
        ordU_member(G1, [ff, ffc, leftmost, maxi, mini]), 
        ordU_member(G2, [bisect, down, enum, step, up]), 
        ordU_member(G3, [assumptions(K)]), 
        list_to_ord_set([G1, G2, G3], OptSet).

buildGroundLabOptSet(OptSet) :- 
        ordU_member(G1, [ff, ffc, leftmost, maxi, mini]), 
        ordU_member(G2, [bisect, down, enum, step, up]), 
        ordU_member(G3, [each(X), toMaximize(Y), toMinimize(Z)]), 
        ordU_member(G4, [assumptions(K)]), 
        list_to_ord_set([G1, G2, G3, G4], OptSet).


ordU_member(X, [X|_T]).
ordU_member(X, [Y|T]) :- lt(Y, X), ordU_member(X, T).

translateLabOptions([], []) :- !.
translateLabOptions([mini|As], [min|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([maxi|As], [max|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([toMinimize(X)|As], [minimize(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([toMaximize(X)|As], [maximize(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
   %%Antonio Ojo, 'each' se traduce a 'all'
translateLabOptions([each(X)|As], [all(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([Option|As], [Option|Bs]) :- 
        !, translateLabOptions(As, Bs).


% indomain :: int -> bool
% indomain :=: inout -> inout
'$indomain'(I, true, Cin, Cout) :- 
%B::Sonia
%         hnf(I, HI, Cin, Cout), 
         hnf(I, HI, Cin, Cout1), 
         toSolverFD(HI,Cout1,Cout),
%E::Sonia
         indomain(HI).

% fdminimize
'$fdminimize'(B, I, true, Cin, Cout) :- 
         hnf(B, HB, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         minimize(HB, HI).

%%%%Antonio 17/01/02 20:00
%%%%%%%%%%%%% OJO, no funciona exactamente como en SICSTus (comprobar)
% fdmaximize
'$fdmaximize'(B, I, true, Cin, Cout) :- 
         hnf(B, HB, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         maximize(HB, HI).


%%%%%%%%%%%%%% RELATIONAL CONSTRAINTS  %%%%%%%%%%%%%%%%%

%% B Sonia
/*      comento todo y lo reescribo de nuevo   
        
% #= :: int -> int -> bool
% #= :=: inout -> inout -> inout
$#=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #=  HR);
         (Out=false, HL #\= HR)). 
       
% #\= :: int -> int -> bool
% #\= :=: inout -> inout -> inout
$#\=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #\= HR);
         (Out=false, HL #=  HR)). 
      
% #< :: int -> int -> bool
% #< :=: inout -> inout -> inout
$#<(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #<  HR);
         (Out=false, HL #>= HR)). 

% #<= :: int -> int -> bool
% #<= :=: inout -> inout -> inout
$#<=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #=< HR);
         (Out=false, HL #> HR)). 
    
% #> :: int -> int -> bool
% #> :=: inout -> inout -> inout
$#>(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #> HR);
         (Out=false, HL #=< HR)). 

% #>= :: int -> int -> bool
% #>= :=: inout -> inout -> inout
$#>=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #>= HR);
         (Out=false, HL #< HR)). 

FIN DE LA PARTE COMENTADA */

%FSP06-02-2007 ::B
$#=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout4),
        ((Out=true, HL #=  HR);
         (Out=false, HL #\= HR)),
    (prop_active -> (
         searchVarsR(HL,Cout4,Cout5,HLR), 
         searchVarsR(HR,Cout5,Cout,HRR),
         ((Out == true, { HLR = HRR },!);
          (Out == false, { HLR =\= HRR },!)
         )
        ); Cout=Cout4
    ). 
       
% #\= :: int -> int -> bool
% #\= :=: inout -> inout -> inout
$#\=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #\= HR);
         (Out=false, HL #=  HR)), 
    (prop_active -> (
         searchVarsR(HL,Cout4,Cout5,HLR), 
         searchVarsR(HR,Cout5,Cout,HRR),
         ((Out == true, { HLR =\= HRR },!);
          (Out == false, { HLR = HRR },!)
         )
        ); Cout=Cout4
    ). 
%::E         
         
% #>
% #>
$#>(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #>  HR);
       (Out=false, HL #=< HR)), 
    (prop_active -> (
         searchVarsR(HL,Cout4,Cout5,HLR), 
         searchVarsR(HR,Cout5,Cout,HRR),
         ((Out == true, { HLR > HRR },!);
          (Out == false, { HLR =< HRR },!)
         )
        ); Cout=Cout4
    ). 


% #<
$#<(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #<  HR);
       (Out=false, HL #>= HR)),       
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR < HRR },!);
         (Out == false, { HLR >= HRR },!)
        )
        ); Cout=Cout4
    ). 


% #>=
$#>=(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #>= HR);
       (Out=false, HL #< HR)),
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR >= HRR },!);
         (Out == false, { HLR < HRR },!)
        )
        ); Cout=Cout4
    ). 

% #<=
$#<=(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #=< HR);
       (Out=false, HL #> HR)),
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR =< HRR },!);
         (Out == false, { HLR > HRR },!)
        )
        ); Cout=Cout4
    ). 

%% E Sonia

  
%%%%%%%%%%%%%%%% ARITHMETIC CONSTRAINT OPERATORS %%%%%%%%%%%%%%%%%%%%%%

%% B Sonia
/*  comento todo y lo reescribo de nuevo  

% #+ :: int -> int -> int
% #+ :=: inout -> inout -> inout
$#+(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL + HR #= O.
 
% #- :: int -> int -> int
% #- :=: inout -> inout -> inout
$#-(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL - HR #= O.       

% #* :: int -> int -> int
% #* :=: inout -> inout -> inout
$#*(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL * HR #= O.
        
% #/ :: int -> int -> int
% #/ :=: inout -> inout -> inout
$#/(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL / HR #= O.

% #& :: int -> int -> int
% #& :=: inout -> inout -> inout
$#&(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL mod HR #= O. 

FIN DE LA PARTE COMENTADA*/
    
% #+
$#+(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL + HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR + HRR = OR }
        ); Cout=Cout5 
    ).

% #-
$#-(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL - HR #= O,   
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR - HRR = OR }
        ); Cout=Cout5 
    ).

% #*
$#*(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL * HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR * HRR = OR }
        ); Cout=Cout5 
    ).

% #/
$#/(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL / HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR / HRR = OR }
        ); Cout=Cout5 
    ).

%% E Sonia   

% #& :: int -> int -> int
% #& :=: inout -> inout -> inout
$#&(L, R, O, Cin, Cout) :- 
     hnf(L, HL, Cin, Cout1), 
     hnf(R, HR, Cout1, Cout2), 
     toSolverFD(HL,Cout2,Cout3),
     toSolverFD(HR,Cout3,Cout4),
     toSolverFD(O,Cout4,Cout),
     HL mod HR #= O.

%%%%%%%%%%%%%%%%%%% ARITHMETIC CONSTRAINTS  %%%%%%%%%%%%%%%%%%%%%

% sum :: [int] -> (int -> int -> bool) -> int -> bool
% sum :=: [inout] -> inout -> inout
'$sum'(VL, Op, O, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error(sum,1)); true),
        hnf(Op, HOp, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%::B Sonia
%        nf(O,HO,Cout2,Cout),    
        nf(O,HO,Cout2,Cout3),    
        toSolverFD(HO,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout),
%::E Sonia
        ((Out=true, relOp(Op), sum(PrologHVL, HOp, HO));
         (Out=false, negRelOp(HOp, HNOp), sum(PrologHVL, HNOp, HO))). 

% scalar_product :: [int] -> [int] -> (int -> int -> bool) -> int -> bool
% scalar_product :=: [inout] -> [inout] -> inout -> inout -> inout
'$scalar_product'(VL1, VL2, Op, O, Out, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        (var(HVL1) -> raise_exception(instatiation_error(scalar_product,1)); true),
        nf(VL2, HVL2, Cout1, Cout2), 
        (var(HVL2) -> raise_exception(instatiation_error(scalar_product,2)); true),
        hnf(Op, HOp, Cout2, Cout3), 
%B:: Sonia        
%        nf(O, HO, Cout3, Cout), 
        nf(O, HO, Cout3, Cout4), 
%E:: Sonia        
        toyListToPrologList(HVL1, PrologHVL1), 
        toyListToPrologList(HVL2, PrologHVL2), 
%B:: Sonia        
        listToSolverFD(PrologHVL1,Cout4,Cout5),
        listToSolverFD(PrologHVL2,Cout5,Cout6),
        toSolverFD(HO,Cout6,Cout),
%E:: Sonia        
        ((Out=true, relOp(Op), scalar_product(PrologHVL1, PrologHVL2, HOp, HO));
         (Out=false, negRelOp(HOp, HNOp), scalar_product(PrologHVL1, PrologHVL2, HNOp, HO))). 
        
        
        
%%%%%%%%%%%%%%%%%%% COMBINATORIAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%

% all_different :: [int] ->  bool
% all_different :=: [inout] ->  inout
'$all_different'(VL, true, Cin, Cout) :- 
%B:: Sonia        
%        nf(VL, HVL, Cin, Cout), 
        nf(VL, HVL, Cin, Cout1), 
%E:: Sonia        
        (var(HVL) -> raise_exception(instatiation_error(all_different,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout1,Cout),
%E:: Sonia        

        all_different(PrologHVL).


% all_different' :: [int] -> [options] -> bool
% all_different' :=: [inout] ->  inout ->  inout
'$all_different\''(VL, OL, true, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error('all_different\'',1)); true),
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
%        nf(OL, HOL, Cout1, Cout), 
        nf(OL, HOL, Cout1, Cout2), 
%E:: Sonia        
        toyListToPrologList(HOL, PrologHOL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout2,Cout),
%E:: Sonia        
        processDiffOptions(PrologHOL, DiffPrologHOL), 
        all_different(PrologHVL, DiffPrologHOL), 
        translateDiffOptions(DiffToyHOL, DiffPrologHOL), 
        toyNonVarListToPrologList(OL, DiffToyHOL).

processDiffOptions(TLs, PLs) :- 
        setof(TLs, validDiffOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateDiffOptions(TLs, PLs).

validDiffOptions(Opts) :- 
        buildDiffOptSet(OptSet), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).

buildDiffOptSet(OptSet) :- 
        ordU_member(G1, [on(value), on(domain), on(range)]), 
        ordU_member(G2, [complete(true), complete(false)]), 
        list_to_ord_set([G1, G2], OptSet).

translateDiffOptions([], []) :- !.
translateDiffOptions([domains|As], [domain|Bs]) :- 
        !, translateDiffOptions(As, Bs).
translateDiffOptions([Option|As], [Option|Bs]) :- 
        !, translateDiffOptions(As, Bs).


       
% assignment :: [int] -> [int] -> bool
% assignment :=: [inout] -> [inout] -> inout
'$assignment'(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        (var(HVL1) -> raise_exception(instatiation_error(assignment,1)); true),
        toyListToPrologList(HVL1, PrologHVL1), 
%B:: Sonia        
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
%B:: Sonia        
        (var(HVL2) -> raise_exception(instatiation_error(assignment,2)); true),
        toyListToPrologList(HVL2, PrologHVL2), 
%B:: Sonia        
        listToSolverFD(PrologHVL1,Cout2,Cout3),
        listToSolverFD(PrologHVL2,Cout3,Cout),
%E:: Sonia        
        assignment(PrologHVL1, PrologHVL2).
        

% circuit :: [int] -> bool
% circuit :=: [inout] -> inout
'$circuit'(VL, true, Cin, Cout) :- 
%B:: Sonia        
%        nf(VL, HVL, Cin, Cout), 
        nf(VL, HVL, Cin, Cout1), 
%E:: Sonia        
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout1,Cout),
%E:: Sonia        
        circuit(PrologHVL).

% circuit' :: [int] -> [int] -> bool
% circuit' :=: [inout] -> [inout] -> inout
'$circuit\''(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
%B:: Sonia        
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
        listToSolverFD(PrologHVL1,Cout2,Cout),
%E:: Sonia        
        toyListToPrologList(HVL2, PrologHVL2), 
        circuit(PrologHVL1, PrologHVL2).


% count :: int -> [int] -> (int -> int -> bool) ->  int -> bool
% count :: in -> inout -> inout -> inout -> inout
'$count'(V, VL, Op, O, true, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        (var(HV) -> raise_exception(instatiation_error(count,1)); true),
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(Op, HOp, Cout2, Cout), 
        hnf(Op, HOp, Cout2, Cout3),
        toSolverFD(HV,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout5),
        toSolverFD(O,Cout5,Cout),
%E::Sonia
        relOp(HOp), 
        count(HV, PrologHVL, HOp, O),
        toyListToPrologList(HVL, PrologHVL).

       
% element :: int -> [int] -> int -> bool
% element :=: inout -> [inout] -> inout -> inout
'$element'(I, VL, V, true, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout1), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(V, HV, Cout2, Cout), 
        hnf(V, HV, Cout2, Cout3),
        toSolverFD(HI,Cout3,Cout4),
        toSolverFD(HV,Cout4,Cout5),
        listToSolverFD(PrologHVL,Cout5,Cout),
%E::Sonia
        element(HI, PrologHVL, HV).
        
% exactly :: int -> [int] -> int -> bool
% exactly :=: inout -> inout -> inout -> inout
'$exactly'(NEle, VL, N, true, Cin, Cout) :- 
        hnf(NEle, HNEle, Cin, Cout1), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(N, HN, Cout2, Cout), 
        hnf(N, HN, Cout2, Cout3), 
        toSolverFD(HNEle,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout5),
        toSolverFD(HNEle,Cout5,Cout),        
%E::Sonia
        exactly(HNEle, PrologHVL, HN),
        toyListToPrologList(HVL, PrologHVL). 

exactly(_, [], 0).
exactly(X, [Y|L], N) :- 
        X #=Y #<=> B, 
        N #= M + B, 
        exactly(X, L, M).


% serialized :: [int] -> [int] -> bool
% serialized :=: [inout] -> [inout] -> inout
'$serialized'(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
%B::Sonia
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
%E::Sonia
        toyListToPrologList(HVL2, PrologHVL2), 
%B::Sonia
        listToSolverFD(PrologHVL1,Cout2,Cout3),
        listToSolverFD(PrologHVL2,Cout3,Cout),
%E::Sonia
        serialized(PrologHVL1, PrologHVL2).


% 'serialized\'' :: [int] -> [int] -> [serialOptions] -> bool
% 'serialized\'' :=: [inout] -> [inout] -> inout -> inout
'$serialized\''(VL1, VL2, OL, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
        nf(VL2, HVL2, Cout1, Cout2), 
        toyListToPrologList(HVL2, PrologHVL2), 
        nf(OL, HOL, Cout2, Cout3), 
        toyListToPrologList(HOL, PrologHOL), 
        processSchedulingOptions(PrologHOL, SchedPrologHOL, Cout3, Cout4), 
        serialized(PrologHVL1, PrologHVL2, SchedPrologHOL), 
%B::Sonia
%        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout4, Cout), 
        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout4, Cout5),       
        listToSolverFD(PrologHVL1,Cout5,Cout6),
        listToSolverFD(PrologHVL2,Cout6,Cout),
%E::Sonia
        toyNonVarListToPrologList(OL, SchedToyHOL).


% cumulative :: [int] ->  [int] ->  [int] -> int  -> bool
% cumulative :=: [inout] -> [inout] -> [inout] -> inout -> inout
'$cumulative'(SL, DL, RL, LIM, true, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout1), 
        toyListToPrologList(HSL, PrologHSL), 
        nf(DL, HDL, Cout1, Cout2), 
        toyListToPrologList(HDL, PrologHDL), 
        nf(RL, HRL, Cout2, Cout3), 
        toyListToPrologList(HRL, PrologHRL), 
        hnf(LIM, HLIM, Cout3, Cout4), 
%B::Sonia
%        hnf(LIM, HLIM, Cout3, Cout), 
        hnf(LIM, HLIM, Cout3, Cout4), 
        listToSolverFD(PrologHSL,Cout4,Cout5),
        listToSolverFD(PrologHDL,Cout5,Cout6),
        listToSolverFD(PrologHRL,Cout6,Cout7),
        toSolverFD(HLIM,Cout7,Cout),
%E::Sonia
        cumulative(PrologHSL, PrologHDL, PrologHRL, HLIM).

% 'cumulative\'' :: [int] ->  [int] ->  [int] -> int  -> [serialOptions] -> bool
% 'cumulative\'' :=: [inout] -> [inout] -> [inout] -> inout -> inout -> inout
'$cumulative\''(SL, DL, RL, Lim, OL, true, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout1), 
        toyListToPrologList(HSL, PrologHSL), 
        nf(DL, HDL, Cout1, Cout2), 
        toyListToPrologList(HDL, PrologHDL), 
        nf(RL, HRL, Cout2, Cout3), 
        toyListToPrologList(HRL, PrologHRL), 
        hnf(Lim, HLim, Cout3, Cout4), 
        nf(OL, HOL, Cout4, Cout5), 
        toyListToPrologList(HOL, PrologHOL), 
        processSchedulingOptions(PrologHOL, SchedPrologHOL, Cout5, Cout6), 
        cumulative(PrologHSL, PrologHDL, PrologHRL, HLim, SchedPrologHOL), 
%B::Sonia
%        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout6, Cout), 
        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout6, Cout7), 
        listToSolverFD(PrologHSL,Cout7,Cout8),
        listToSolverFD(PrologHDL,Cout8,Cout9),
        listToSolverFD(PrologHRL,Cout9,Cout10),
        toSolverFD(HLim,Cout10,Cout),
%E::Sonia
        toyNonVarListToPrologList(OL, SchedToyHOL).

 
processSchedulingOptions(TLs, PLs, Cin, Cout) :- 
        setof(TLs, validSchedOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateSchedOptions(TLs, PLs, Cin, Cout).


validSchedOptions(Opts) :- 
        (groundL1(Opts) -> buildGroundSchedOptSet(OptSet) ; buildSchedOptSet(OptSet)), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).


buildSchedOptSet(OptSet) :- 
        OptSet = [
                  decomposition(true), 
                  edge_finder(true), 
                  path_consistency(true), 
                  static_sets(true)
                 ]. % This must be an ordered list

buildGroundSchedOptSet(OptSet) :- 
        OptSet = [
                  decomposition(true), 
                  edge_finder(true), 
                  path_consistency(true), 
                  precedences(L), 
                  static_sets(true)
                 ]. % This must be an ordered list


translateSchedOptions([], [], C, C) :- !.
translateSchedOptions([precedences(T)|Ls], [precedences(T1)|Lss], Cin, Cout) :- 
        !, hnf(T, TT, Cin, Cout1), 
        toyListToPrologList(TT, TTT), 
        process_precedences(TTT, T1), 
        translateSchedOptions(Ls, Lss, Cout1, Cout).
translateSchedOptions([Option|As], [Option|Bs], Cin, Cout) :- 
        !, translateSchedOptions(As, Bs, Cin, Cout).


process_precedences([], []).
process_precedences([d('$$tup'((I1, I2, I3)))|Ls], [d(I1, I2, O3)|Lss]) :- 
        !, process_value(I3, O3), 
        process_precedences(Ls, Lss).
process_precedences([X|Ls], [X|Lss]) :- process_precedences(Ls, Lss).

process_value(lift(I3), I3).
process_value(superior, sup).


%%%%%%%%%%%%%%%%%%% PROPOSITIONAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%

% #\/  :: bool -> bool -> bool
% #\/  :=: inout -> inout -> inout
$#\/(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #\/ HRINT.

% #<=> :: bool -> bool -> bool
% #<=> :=: inout -> inout -> inout
$#<=>(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #<=> HRINT.

% #=> :: bool -> bool -> bool
% #=> :=: inout -> inout -> inout
$#=>(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #=> HRINT.


%%%%%%%%%%%%%%%%%%% REFLECTION FUNCTIONS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% fd_var :: int -> bool
% fd_var :=: inout -> inout
'$fd_var'(V, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        (fd_var(HV) -> Out = true; Out=false).
        
% fd_min :: int -> int
% fd_min :=: inout -> inout
'$fd_min'(I, Min, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout), 
        fd_min(HI, Min).

% fd_max :: int -> int
% fd_max :=: inout -> inout
'$fd_max'(I, Max, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout), 
        fd_max(HI, Max).

% fd_size :: int -> int
% fd_size :=: inout -> inout
'$fd_size'(V, S, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_size(HV, S).

% fd_set :: int -> fdset
% fd_set :=: inout -> inout
'$fd_set'(V, S, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_set(HV, PS), 
        toySetToPrologSet(S, PS).

% fd_dom :: int -> range
% fd_dom :=: inout -> inout
'$fd_dom'(V, R, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_dom(HV, PR), 
        toyRangeToPrologRange(R, PR).

% fd_degree :: int -> int
% fd_degree :=: inout -> inout
'$fd_degree'(V, I, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_degree(HV, I).
       
% fd_neighbors :: int -> [int]
% fd_neighbors :=: inout -> inout
'$fd_neighbors'(V, L, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_neighbors(HV, PL),
        toyListToPrologList(L, PL).          
        
% fd_closure :: [int] -> [int]
% fd_neighbors :=: [inout] -> [inout]
'$fd_closure'(L1, L2, Cin, Cout) :- 
        nf(L1, HL1, Cin, Cout), 
        (var(HL1) -> raise_exception(instatiation_error(fd_closure,1)); true),
        toyListToPrologList(HL1, PHL1), 
        fd_closure(PHL1, PL2), 
        toyListToPrologList(L2, PL2).
        
% sup :: int
% sup :=: {}
'$sup'(X, Cin, Cin) :- cflpfd:sup(X).

% inf :: int
% inf :: {}
'$inf'(X, Cin, Cin) :- cflpfd:inf(X).


%%%%%%%%%%%%%%%%%%% FD SET FUNCTIONS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% is_fdset :: fdset -> bool
% is_fdset :=: in -> inout
'$is_fdset'(S, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS,PS),
        (is_fdset(PS) -> Out = true; Out = false).     
        
% empty_fdset :: fdset -> bool
% empty_fdset :=: inout -> inout
'$empty_fdset'(S, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        ((Out=true, empty_fdset(HS), Cout1=Cout); 
         (Out=false, (var(HS) -> notEqualVar(HS,[],Cout1,Cout) ) ) ).

% fdset_parts :: int -> int -> fdset -> fdset
% fdset_parts :=: in  -> in  -> in  -> inout
'$fdset_parts'(Min, Max, P, S, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout2), 
        nf(P, HP, Cout2, Cout), 
        toySetToPrologSet(HP, PP),
        fdset_parts(PS, HMin, HMax, PP),
        toySetToPrologSet(S, PS).

% fdset_split :: fdset -> (int -> int -> fdset)
% fdset_split :=: in  -> (inout -> inout -> inout)
'$fdset_split'(S, '$$tup'(','(Min, ','(Max, P))), Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        toySetToPrologSet(HS, PS),
        fdset_parts(PS, Min, Max, PP),
        toySetToPrologSet(P, PP).

% empty_interval :: int -> int -> bool
% empty_interval :=: in -> in -> inout
'$empty_interval'(Min, Max, Out, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout), 
        (var(HMin) -> raise_exception(instatiation_error(empty_interval,1)); true),
        (var(HMax) -> raise_exception(instatiation_error(empty_interval,2)); true),
        (empty_interval(HMin, HMax) -> Out = true; Out = false).

% fdset_to_interval :: fdset -> (int, int)
% fdset_to_interval :=: in -> (inout, inout)
'$fdset_to_interval'(S, '$$tup'(','(Min, Max)), Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_interval(PS, Min, Max).

% interval_to_fdset :: int -> int -> fdset
% interval_to_fdset :=: in -> in -> inout
'$interval_to_fdset'(Min, Max, S, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout), 
        (var(HMin) -> raise_exception(instatiation_error(interval_to_fdset,1)); true),
        (var(HMax) -> raise_exception(instatiation_error(interval_to_fdset,2)); true),
        fdset_interval(PS, HMin, HMax), 
        toySetToPrologSet(S, PS).

% fdset_singleton :: fdset -> int -> bool
% fdset_singleton :=: {in -> out -> out, out -> in -> out}
'$fdset_singleton'(S, E, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(E, HE, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        (fdset_singleton(PS, HE) -> 
         (Out = true, toySetToPrologSet(HS, PS)); 
         Out = false).

% fdset_min :: fdset -> int 
% fdset_min :=: in -> inout
'$fdset_min'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_min(PS, I).
        
% fdset_max :: fdset -> int
% fdset_max :=: in -> inout
'$fdset_max'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_max(PS, I).

% fdset_size :: fdset -> int
% fdset_size :=: in -> inout
'$fdset_size'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_size(PS, I).
     
% list_to_fdset :: [int] -> fdset
% list_to_fdset :=: in -> inout
'$list_to_fdset'(L, S, Cin, Cout) :- 
        nf(L, HL, Cin, Cout),
        toyListToPrologList(HL, PHL), 
        list_to_fdset(PHL, PS), 
        toySetToPrologSet(S, PS).
        
% fdset_to_list :: fdset -> [int]
% fdset_to_list :=: in -> inout
'$fdset_to_list'(S, L, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS), 
        fdset_to_list(PS, PL), 
        toyListToPrologList(L, PL).

% range_to_fdset :: range -> fdset
% range_to_fdset :=: in -> inout
'$range_to_fdset'(R, S, Cin, Cout) :- 
        nf(R, HR, Cin, Cout), 
        toyRangeToPrologRange(HR, PR), 
        range_to_fdset(PR, PS), 
        toySetToPrologSet(S, PS).

% fdset_to_range :: fdset -> range
% fdset_to_range :=: in -> inout
'$fdset_to_range'(S, R, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS), 
        fdset_to_range(PS, PR), 
        toyRangeToPrologRange(R, PR).

% fdset_add_element :: fdset -> int -> fdset 
% fdset_add_element :=: in -> in -> inout
'$fdset_add_element'(S, I, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(I, HI, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_add_element(PS, HI, PO),
        toySetToPrologSet(O, PO). 

% fdset_del_element :: fdset -> int -> fdset 
% fdset_del_element :=: in -> in -> inout
'$fdset_del_element'(S, I, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(I, HI, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_del_element(PS, HI, PO),
        toySetToPrologSet(O, PO). 

% fdset_intersection :: fdset -> fdset -> fdset
% fdset_intersection :=: in -> in -> inout
'$fdset_intersection'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_intersection(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_subtract :: fdset -> fdset -> fdset
% fdset_subtract :=: in -> in -> inout
'$fdset_subtract'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_subtract(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_union :: fdset -> fdset -> fdset
% fdset_union :=: in -> in -> inout
'$fdset_union'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_union(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_complement :: fdset -> fdset
% fdset_complement :=: in -> inout
'$fdset_complement'(S, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_complement(PS, PO),
        toySetToPrologSet(O, PO). 

% fdsets_intersection :: [fdset] -> fdset
% fdsets_intersection :=: in -> inout
'$fdsets_intersection'(SL, O, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout), 
        toyListSetToPrologListSet(HSL, PSL),
        fdset_intersection(PSL, PO),
        toySetToPrologSet(O, PO). 

% fdsets_union :: [fdset] -> fdset
% fdsets_union :=: in -> inout
'$fdsets_union'(SL, O, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout), 
        toyListSetToPrologListSet(HSL, PSL),
        fdset_union(PSL, PO),
        toySetToPrologSet(O, PO).

% fdset_equal :: fdset -> fdset-> bool
% fdset_equal :=: in -> in -> inout
'$fdset_equal'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_eq(PS1, PS2) -> Out = true; Out = false).

% fdset_subset :: fdset -> fdset-> bool
% fdset_subset :=: in -> in -> inout
'$fdset_subset'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_subset(PS1, PS2) -> Out = true; Out = false).

% fdset_disjoint :: fdset -> fdset-> bool
% fdset_disjoint :=: in -> in -> inout
'$fdset_disjoint'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_disjoint(PS1, PS2) -> Out = true; Out = false).
  
% fdset_intersect :: fdset -> fdset-> bool
% fdset_intersect :=: in -> in -> inout
'$fdset_intersect'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_intersect(PS1, PS2) -> Out = true; Out = false).

% fdset_member :: int -> fdset -> bool
% fdset_member :=: inout -> in -> inout
'$fdset_member'(V, S, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(S, HS, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        ((Out = true, fdset_member(HV, PS)); 
         Out = false).

% fdset_belongs :: int -> int -> bool
% fdset_belongs :=: inout -> in -> inout
'$fdset_belongs'(X, Y, Out, Cin, Cout) :- 
        hnf(X, HX, Cin, Cout1), 
        hnf(Y, HY, Cout1, Cout), 
        fd_set(HY, PS),
        ((Out = true, fdset_member(HX, PS)); 
         Out = false).


traduction(domm(X), dom(X)).
traduction(minn(X), min(X)).
traduction(maxx(X), max(X)).
traduction(vall(X), val(X)).
traduction(minmax(X), minmax(X)).

traduce_list([], []).
traduce_list([X|Xs], [Y|Ys]) :- traduction(X, Y), traduce_list(Xs, Ys).

traduce_args([], []).
traduce_args([X:Xs|Rs], [Y|Ys]) :- toyListToPrologList(X:Xs, Y), !, 
        traduce_args(Rs, Ys).
traduce_args([X|Rs], [X|Ys]) :- traduce_args(Rs, Ys).

% fd_global
%'$fd_global'(_A, _B, _C, true, _D, _E) :- 
%        hnf(_A, _A1, _D, _F), 
%
%        hnf(_B, _BB, _F, _I), %%_B = st('$$tup'((Args)))
%        _BB=..[st, Tuple], 
%         printf("\n Tuple = %w \n", [Tuple]), 
%        Tuple =..['$$tup', Ar], %% Tuple = '$$tup'(Args)
%        printf("\n Ar = %w \n", [Ar]), 
%        Ar =..[C|Args], %% C = '.', 
%         printf("\n Args = %w \n", [Args]), 
%        traduce_args(Args, PrologArgs), 
%         printf("\n PrologArgs = %w \n", [PrologArgs]), 
%        _B1  =..[st|PrologArgs], 
%        
%        hnf(_C, _CC, _I, _E), 
%        toyListToPrologList(_CC, CCC), 
%        printf("\n Las variables son _AA = %w \n  _BB = %w \n  _CC = %w \n", [_AA, _BB, _CC]), 
%        printf("\n                                        PrologCC = %w \n", [PrologCC]), 
%        traduce_list(CCC, C1), 
%        printf("\n Las variables son _A1 = %w \n  _B1 = %w \n  _C1 = %w \n", [_A1, _B1, C1]), 
%        fd_global(_A1, _B1, C1).   

% fd_global
'$fd_global'(_A, _B, _C, _O, _D, _E) :- 
        hnf(_A, _A1, _D, _F), 
        hnf(_B, _BB, _F, _I), %%_B = st('$$tup'((Args)))
        _BB=..[st, Tuple], 
        Tuple =..['$$tup', Ar], %% Tuple = '$$tup'(Args)
        Ar =..[C|Args], %% C = '.', 
        traduce_args(Args, PrologArgs), 
        _B1  =..[st|PrologArgs], 
        hnf(_C, _CC, _I, _E), 
        toyListToPrologList(_CC, CCC), 
        traduce_list(CCC, C1), 
        printf("\n Las variables son _A1 = %w \n  _B1 = %w \n  _C1 = %w \n", [_A1, _B1, C1]), 
        fd_global(A1, _B1, C1).   


%%%%%%%%%%%%%%%%%%% INDEXICAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%%%%%

% isin
'$isin'(_A, _B, true, _C, _D) :- 
        hnf(_B, '$$tup'(_E), _C, _F), 
        hnf(_E, ', '(_G, _H), _F, _F1), 
        hnf(_G, _GG, _F1, _F2), 
        hnf(_H, _HH, _F2, _F3), 
        hnf(_A, _AA, _F3, _D), 
        lanzar(_AA, _GG, _HH).
        
lanzar(_AA, _GG, _HH)+:        
        _GG=..[min, _YY], 
        _AA in min(_YY).._HH.
        
%%:- use_module(library(charsio)).        

%infixl mini  
%infix(<<<, left, 11).
%%

% minimum
'$minimum'(_A, min(_AA), _C, _D) :- 
        hnf(_A, _AA, _C, _C1), 
        printf("\n Las variables son _AA = %w\n", [_AA]).


%%%%%%%%%%%%%%%%%%% STATISTICS FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%

% fd_statistics' :: statistics -> int
% fd_statistics' :=: inout -> inout
'$fd_statistics\''(S, I, Cin, Cout) :- 
         hnf(S, HS, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         fd_statistics(HS, HI).

% 'fd_statistics' :: bool
% 'fd_statistics' :=: inout
'$fd_statistics'(true, Cin, Cin) :- 
         fd_statistics.


%%%%%%%%%%%% Auxiliary Predicates   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%float_to_int(F,I) :- freeze(F, I is integer(F)), freeze(I, F is float(I)).

bool_to_int(B, I) :- 
        freeze(B, (B = false -> I = 0 ; I = 1)), 
        freeze(I, (I = 0 -> B = false ; B = true)).


relOp(Op) :- negRelOp(Op, _).

negRelOp(#=, #\=).
negRelOp(#\=, #=).
negRelOp(#<, #>=).
negRelOp(#<=, #>).
negRelOp(#>, #<=).
negRelOp(#>=, #<).



/*
hnfList(L, HL, Cin, Cout) :- 
        (var(L) -> L = HL, Cin = Cout; hnfListR(L, HL, Cin, Cout)).

hnfListR([], [], C, C).
hnfListR(H:T, NH:NT, Cin, Cout) :- 
        hnf(H, NH, Cin, Cout1), 
        hnfListR(T, NT, Cout1, Cout).


%% Prolog FD Sets come implemented as lists of [Min|Max] elements
%% Toy FD Sets are implemented as Toy lists of (interval Min Max) elements


hnfSet(S, HS, Cin, Cout) :- 
        (var(S) -> S = HS, Cin = Cout; hnfSetR(S, HS, Cin, Cout)).

hnfSetR([], [], C, C) :- !.
hnfSetR(:(interval(Min,Max), T), :(interval(HMin,HMax), HT), Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout2), 
        hnfSetR(T, HT, Cout2, Cout).


% Prolog FD Ranges come implemented as conjunctions (R1/\R2), disjunctions (R1\/R2), 
%   and complement (\R) of ranges, where a range can also be a constant range (Min..Max)
% Toy FD Ranges are implemented as unions (uni(R1,R2)), intersections (inter(R1,R2)), 
%   and complement (compl(R)) of ranges, where a range can also be a constant range (cte(Min,Max))

hnfRange(R, HR, Cin, Cout) :- 
        (var(R) -> R = HR, Cin = Cout; hnfRangeR(R, HR, Cin, Cout)).

hnfRangeR(cte(Min, Max), cte(HMin, HMax), Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1),
        hnf(Max, HMax, Cout1, Cout), !.
hnfRangeR(uni(R1, R2), uni(HR1, HR2), Cin, Cout) :- 
        hnfRange(R1, HR1, Cin, Cout1), 
        hnfRange(R2, HR2, Cout1, Cout), !.
hnfRangeR(inter(R1, R2), inter(HR1, HR2), Cin, Cout) :- 
        hnfRange(R1, HR1, Cin, Cout1), 
        hnfRange(R2, HR2, Cout1, Cout), !.
hnfRangeR(compl(R), compl(HR), Cin, Cout) :- 
        hnfRange(R, HR, Cin, Cout), !.

*/


toyListSetToPrologListSet(TSL, PSL) :-
        (var(TSL), var(PSL) -> true; toyNonVarListSetToPrologListSet(TSL, PSL)).

toyNonVarListSetToPrologListSet([], []) :- !.
toyNonVarListSetToPrologListSet(TS:R, [PS|RR]) :- 
        toyNonVarSetToPrologSet(TS, PS),
        toyNonVarListSetToPrologListSet(R, RR).


toySetToPrologSet(TS, PS) :- 
        (var(TS), var(PS) -> true; toyNonVarSetToPrologSet(TS, PS)).
toyNonVarSetToPrologSet([], []) :- !.
toyNonVarSetToPrologSet(:(interval(Min,Max),TT), [[IMin|IMax]|PT]) :- 
        IMin = Min,
        IMax = Max,
        toyNonVarSetToPrologSet(TT, PT).

hnf_recursive(S, HS, Cin, Cout) :-
        (var(S) -> Cin=Cout; hnf_recursiveNonVar(S, HS, Cin, Cout)).

hnf_recursiveNonVar([], [], C, C) :- !.
hnf_recursiveNonVar(_B, [[_F|_G] | _Resto], Cin, Cout) :- 
        hnf(_T, interval(_F, _G), Cin, Cout1), 
        hnf_recursive(_R, _Resto, Cout1, Cout2), !, 
        hnf(_B, :(_T, _R), Cout2, Cout).
        

toyRangeToPrologRange(TR, PR) :- 
        (var(TR), var(PR) -> true; toyNonVarRangeToPrologRange(TR, PR)).
toyNonVarRangeToPrologRange(cte(Min, Max), Min..Max) :- !.
toyNonVarRangeToPrologRange(uni(TR1, TR2), PR1 \/ PR2) :- 
        toyRangeToPrologRange(TR1, PR1), 
        toyRangeToPrologRange(TR2, PR2), !.
toyNonVarRangeToPrologRange(inter(TR1, TR2), PR1 /\ PR2) :- 
        toyRangeToPrologRange(TR1, PR1), 
        toyRangeToPrologRange(TR2, PR2), !.
toyNonVarRangeToPrologRange(compl(TR), PC, Cin, Cout) :- 
        PC=..[\, PR],
        toyRangeToPrologRange(TR, PR), !.



%------      LISTS              ---------------------------------

%% Translates a Toy list (such as 1:2:3:[]) into a Prolog list ([1, 2, 3])
toyListToPrologList(Ts, Ps) :- (var(Ts), var(Ps) -> true; toyNonVarListToPrologList(Ts, Ps)).

toyNonVarListToPrologList([], []) :- !.
toyNonVarListToPrologList(A:R, [A|RR]) :- toyNonVarListToPrologList(R, RR).


% nonmember/2
nonmember(_X, []).
nonmember(X, [X|_Ys]) :- !, fail.
nonmember(X, [_Y|Ys]) :- !, nonmember(X, Ys).

%-----------------------------------------------------------------------
%-----------------------------------------------------------------------
%-----------------------------------------------------------------------
%------      INPUT/OUTPUT              ---------------------------------


%------------------- Predicates for I/O ---------------------------------------------

%------------------- Predicates for formatting ---------------------------------------

%------------------- printf: formatted ouput ----------------------------------------

% All the output generated by the program uses this printf
% procedure.

% control chars '\.'



printf([92, 110|F], Ts) :- !, nl, printf(F, Ts).  % 92, 110 = \n
printf([92, 116|F], Ts) :- !, put(9), printf(F, Ts).  % 92, 116 = \t
printf([92, 92|F], Ts) :- !, put(92), printf(F, Ts).  % 92, 92 = \\
printf([92, 37|F], Ts) :- !, put(37), printf(F, Ts).  % 92, 37 = \%
printf([92, 34|F], Ts) :- !, put(34), printf(F, Ts).  % 92, 34 = \"

% format chars '%.'

printf([37, 119|F], [T|Ts]) :- !, write_term(T, [portrayed(true)]), printf(F, Ts).  % 37, 119 = %w
printf([37, 113|F], [T|Ts]) :- !, writeq(T, [portrayed(true)]), printf(F, Ts).  % 37, 113 = %q
printf([37, 100|F], [T|Ts]) :- !, display(T), printf(F, Ts).  % 37, 100 = %d
printf([37, 115|F], [T|Ts]) :- !, puts(T), printf(F, Ts).  % 37, 115 = %s
printf([37, 118|F], [V, T|Ts]) :- !, nameTermVars(T, V, Tn), printf(F, [Tn|Ts]). % 37, 118 = %v

% plain chars '.'

printf([Ch|F], Ts) :- !, put(Ch), printf(F, Ts).

printf([], _).

printf(F) :- printf(F, []).

puts([]).
puts([Ch|S]) :- put(Ch), puts(S).


%%NEW11 To print the list L (including elements as 'X'=A) in the predicate solve.
print_list([]) :- !.
%%print_list([X=A|L]) :- X\==A, printf("    %w = %w \n", [X, A]), print_list(L).
%%print_list([X=A|L]) :- X==A, print_list(L).
print_list([(X=A)|L]) :- ground(A), 
        printf("    %w = %w \n", [X, A]), 
        print_list(L), !, 
        assert(sol(true)).   %% Indicates that a semi-solution is found
print_list([(_X=_A)|L]) :- print_list(L).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  END OF CFLPFDFILE %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
