

user:portray_message(warning,_):- write('').

:- module(plgenerated,[sourceFileNameStr/1,hnf_susp/5,constr/4,funct/5,infix/3,'$$apply'/5,'$flip'/6,'$and' /5,'$or' /5,$/\ /5,$\/ /5,'$not' /4,'$andL' /3,'$orL' /3,'$orL\'' /3,'$any' /4,'$any\'' /4,'$all' /4,'$undefined' /3,'$def' /4,'$not_undef' /4,'$nf' /4,'$hnf' /4,'$strict' /5,'$strict\'' /5,'$map' /5,$. /6,$++ /5,'$!!' /5,'$iterate' /5,'$repeat' /4,'$copy' /5,'$filter' /5,'$foldl' /6,'$foldl1' /5,'$foldl\'' /6,'$scanl' /6,'$scanl1' /5,'$scanl\'' /6,'$foldr' /6,'$foldr1' /5,'$scanr' /6,'$auxForScanr' /6,'$scanr1' /5,'$take' /5,'$drop' /5,'$splitAt' /5,'$auxForSplitAt' /5,'$takeWhile' /5,'$takeUntil' /5,'$dropWhile' /5,'$span' /5,'$auxForSpan' /5,'$break' /4,'$zipWith' /6,'$zip' /5,'$mkpair' /5,'$unzip' /4,'$auxForUnzip' /6,'$until' /6,'$until\'' /5,'$const' /5,'$id' /4,$// /5,'$curry' /6,'$uncurry' /5,'$fst' /4,'$snd' /4,'$fst3' /4,'$snd3' /4,'$thd3' /4,'$subtract' /3,'$even' /4,'$odd' /3,'$lcm' /5,'$head' /4,'$last' /4,'$tail' /4,'$init' /4,'$nub' /4,'$length' /4,'$size' /3,'$reverse' /3,'$member' /3,'$notMember' /3,'$concat' /3,'$transpose' /3,'$auxForTranspose' /5,$\\ /3,'$del' /5,'$parse' /4,'$expression' /3,'$term' /3,'$factor' /3,'$number' /3]).

:- dynamic $== /5, $/= /5.

:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed)]).

:- tools:complete_root_filename(primFunct,F),load_files(F,[if(changed)]).

:- tools:complete_root_filename(primitivCod,F),load_files(F,[if(changed)]).








% nombre del fichero fuente
sourceFileNameStr('examples/parser').


/**************    CODE FOR FUNCTIONS    **************/


% and
'$and'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$and_1'(_F, _B, _C, _G, _E).
'$and'(_A, _B, false, _C, _D):-
        hnf(_B, false, _C, _D).
'$and_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$and_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _E),
        hnf(_B, true, _E, _D).

% or
'$or'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$or_1'(_F, _B, _C, _G, _E).
'$or'(_A, _B, true, _C, _D):-
        hnf(_B, true, _C, _D).
'$or_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$or_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _E),
        hnf(_B, false, _E, _D).

% /\
$/\(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$/\\_1'(_F, _B, _C, _G, _E).
'$/\\_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$/\\_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, true, _D, _F),
        hnf(_B, _C, _F, _E).

% \/
$\/(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$\\/_1'(_F, _B, _C, _G, _E).
'$\\/_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$\\/_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, false, _D, _F),
        hnf(_B, _C, _F, _E).

% not
'$not'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$not_1'(_E, _B, _F, _D).
'$not_1'(_A, false, _B, _C):-
        unifyHnfs(_A, true, _B, _C).
'$not_1'(_A, true, _B, _C):-
        unifyHnfs(_A, false, _B, _C).

% andL
'$andL'(foldr(/\, true), _A, _A).

% orL
'$orL'(foldr(or, false), _A, _A).

% 'orL\''
'$orL\''(foldr(\/, false), _A, _A).

% any
'$any'(_A, '.'('$$susp'( '$orL',  [], _B, _C ), map(_A)), _D, _D).

% 'any\''
'$any\''(_A, '.'('$$susp'( '$orL\'',  [], _B, _C ), map(_A)), _D, _D).

% all
'$all'(_A, '.'('$$susp'( '$andL',  [], _B, _C ), map(_A)), _D, _D).

% undefined
'$undefined'(_A, _B, _C):-
        '$if_then'(false, '$$susp'( '$undefined',  [], _D, _E ), _A, _B, _C).

% def
'$def'(_A, true, _B, _C):-
        '$$eqFun'(_A, _D, true, _B, _C).

% not_undef
'$not_undef'(_A, true, _B, _C):-
        '$$notEqFun'(_A, _D, true, _B, _C).

% nf
'$nf'(_A, _B, _C, _D):-
        equal(_A, _E, _C, _F),
        hnf(_E, _B, _F, _D).

% hnf
'$hnf'(_A, _B, _C, _D):-
        notEqual(_A, _E, _C, _F),
        hnf(_A, _B, _F, _D).

% strict
'$strict'(_A, _B, _C, _D, _E):-
        equal(_B, _F, _D, _G),
        '$$apply'(_A, _F, _C, _G, _E).

% 'strict\''
'$strict\''(_A, _B, _C, _D, _E):-
        notEqual(_B, _F, _D, _G),
        '$$apply'(_A, _B, _C, _G, _E).

% map
'$map'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$map_2'(_A, _F, _C, _G, _E).
'$map_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$map_2'(_A, _B, :('$$susp'( '$$apply', [ _A, _C ], _D, _E ), '$$susp'( '$map', [ _A, _F ], _G, _H )), _I, _J):-
        unifyHnfs(_B, :(_C, _F), _I, _J).

% '.'
$.(_A, _B, _C, _D, _E, _F):-
        '$$apply'(_A, '$$susp'( '$$apply', [ _B, _C ], _G, _H ), _D, _E, _F).

% ++
$++(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$++_1'(_F, _B, _C, _G, _E).
'$++_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, _C, _F, _E).
'$++_1'(_A, _B, :(_C, '$$susp'( $++, [ _D, _B ], _E, _F )), _G, _H):-
        unifyHnfs(_A, :(_C, _D), _G, _H).

% '!!'
'$!!'(_A, _B, _C, _D, _E):-
        hnf(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _B, 0 ], _I, _J ), _F, '$$susp'( '$!!', [ _G, '$$susp'( $-, [ _B, 1 ], _K, _L ) ], _M, _N ), _C, _H, _E).

% iterate
'$iterate'(_A, _B, :(_B, '$$susp'( '$iterate', [ _A, '$$susp'( '$$apply', [ _A, _B ], _C, _D ) ], _E, _F )), _G, _G).

% repeat
'$repeat'(_A, :(_A, '$$susp'( '$repeat', [ _A ], _B, _C )), _D, _D).

% copy
'$copy'(_A, _B, _C, _D, _E):-
        '$take'(_A, '$$susp'( '$repeat', [ _B ], _F, _G ), _C, _D, _E).

% filter
'$filter'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$filter_2'(_A, _F, _C, _G, _E).
'$filter_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$filter_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), :(_F, '$$susp'( '$filter', [ _A, _G ], _K, _L )), '$$susp'( '$filter', [ _A, _G ], _M, _N ), _C, _H, _E).

% foldl
'$foldl'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldl_3'(_A, _B, _G, _D, _H, _F).
'$foldl_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldl_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$foldl'(_A, '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _J, _K ), _G ], _L, _M ), _H, _D, _I, _F).

% foldl1
'$foldl1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        '$foldl'(_A, _F, _G, _C, _H, _E).

% 'foldl\''
'$foldl\''(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldl\'_3'(_A, _B, _G, _D, _H, _F).
'$foldl\'_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldl\'_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$strict', [ 'foldl\''(_A), '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _J, _K ), _G ], _L, _M ) ], _N, _O ), _H, _D, _I, _F).

% scanl
'$scanl'(_A, _B, _C, :(_D, _E), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$scanl_3'(_A, _B, _H, :(_D, _E), _I, _G).
'$scanl_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanl_3'(_A, _B, _C, :(_B, '$$susp'( '$scanl', [ _A, '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _D, _E ), _F ], _G, _H ), _I ], _J, _K )), _L, _M):-
        unifyHnfs(_C, :(_F, _I), _L, _M).

% scanl1
'$scanl1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        '$scanl'(_A, _F, _G, _C, _H, _E).

% 'scanl\''
'$scanl\''(_A, _B, _C, :(_D, _E), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$scanl\'_3'(_A, _B, _H, :(_D, _E), _I, _G).
'$scanl\'_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanl\'_3'(_A, _B, _C, :(_B, '$$susp'( '$$apply', [ '$$susp'( '$strict', [ 'scanl\''(_A), '$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _D, _E ), _F ], _G, _H ) ], _I, _J ), _K ], _L, _M )), _N, _O):-
        unifyHnfs(_C, :(_F, _K), _N, _O).

% foldr
'$foldr'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldr_3'(_A, _B, _G, _D, _H, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$$apply', [ _A, _G ], _J, _K ), '$$susp'( '$foldr', [ _A, _B, _H ], _L, _M ), _D, _I, _F).

% foldr1
'$foldr1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        hnf(_G, _I, _H, _J),
        '$foldr1_2_2.2_:'(_A, _F, _I, _C, _J, _E).
'$foldr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$$apply', [ _A, _B ], _J, _K ), '$$susp'( '$foldr1', [ _A, :(_G, _H) ], _L, _M ), _D, _I, _F).

% scanr
'$scanr'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$scanr_3'(_A, _B, _G, _D, _H, _F).
'$scanr_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$auxForScanr'(_A, _G, '$$susp'( '$scanr', [ _A, _B, _H ], _J, _K ), _D, _I, _F).

% auxForScanr
'$auxForScanr'(_A, _B, _C, :('$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _D, _E ), '$$susp'( '$head', [ _C ], _F, _G ) ], _H, _I ), _C), _J, _J).

% scanr1
'$scanr1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        hnf(_G, _I, _H, _J),
        '$scanr1_2_2.2_:'(_A, _F, _I, _C, _J, _E).
'$scanr1_2_2.2_:'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$auxForScanr'(_A, _B, '$$susp'( '$scanr1', [ _A, :(_G, _H) ], _J, _K ), _D, _I, _F).

% take
'$take'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$take_2'(_A, _F, _C, _G, _E).
'$take_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$take_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, 0 ], _I, _J ), [], :(_F, '$$susp'( '$take', [ '$$susp'( $-, [ _A, 1 ], _K, _L ), _G ], _M, _N )), _C, _H, _E).

% drop
'$drop'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$drop_2'(_A, _F, _C, _G, _E).
'$drop_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$drop_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, 0 ], _I, _J ), :(_F, _G), '$$susp'( '$drop', [ '$$susp'( $-, [ _A, 1 ], _K, _L ), _G ], _M, _N ), _C, _H, _E).

% splitAt
'$splitAt'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$splitAt_2'(_A, _F, _C, _G, _E).
'$splitAt_2'(_A, _B, '$$tup'(','([], [])), _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$splitAt_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _A, 0 ], _I, _J ), '$$tup'(','([], :(_F, _G))), '$$susp'( '$auxForSplitAt', [ _F, '$$susp'( '$splitAt', [ '$$susp'( $-, [ _A, 1 ], _K, _L ), _G ], _M, _N ) ], _O, _P ), _C, _H, _E).

% auxForSplitAt
'$auxForSplitAt'(_A, _B, '$$tup'(','(:(_A, _C), _D)), _E, _F):-
        hnf(_B, '$$tup'(_G), _E, _H),
        hnf(_G, ','(_C, _D), _H, _F).

% takeWhile
'$takeWhile'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$takeWhile_2'(_A, _F, _C, _G, _E).
'$takeWhile_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$takeWhile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), :(_F, '$$susp'( '$takeWhile', [ _A, _G ], _K, _L )), [], _C, _H, _E).

% takeUntil
'$takeUntil'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$takeUntil_2'(_A, _F, _C, _G, _E).
'$takeUntil_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$takeUntil_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), :(_F, []), :(_F, '$$susp'( '$takeUntil', [ _A, _G ], _K, _L )), _C, _H, _E).

% dropWhile
'$dropWhile'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$dropWhile_2'(_A, _F, _C, _G, _E).
'$dropWhile_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$dropWhile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), '$$susp'( '$dropWhile', [ _A, _G ], _K, _L ), :(_F, _G), _C, _H, _E).

% span
'$span'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$span_2'(_A, _F, _C, _G, _E).
'$span_2'(_A, _B, '$$tup'(','([], [])), _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$span_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply', [ _A, _F ], _I, _J ), '$$susp'( '$auxForSpan', [ _F, '$$susp'( '$span', [ _A, _G ], _K, _L ) ], _M, _N ), '$$tup'(','([], :(_F, _G))), _C, _H, _E).

% auxForSpan
'$auxForSpan'(_A, _B, '$$tup'(','(:(_A, _C), _D)), _E, _F):-
        hnf(_B, '$$tup'(_G), _E, _H),
        hnf(_G, ','(_C, _D), _H, _F).

% break
'$break'(_A, span('.'(not, _A)), _B, _B).

% zipWith
'$zipWith'(_A, _B, _C, _D, _E, _F):-
        hnf(_B, _G, _E, _H),
        '$zipWith_2'(_A, _G, _C, _D, _H, _F).
'$zipWith_2'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_B, [], _D, _E).
'$zipWith_2'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, :(_G, _H), _E, _I),
        hnf(_C, _J, _I, _K),
        '$zipWith_2_3_:'(_A, _G, _H, _J, _D, _K, _F).
'$zipWith_2_3_:'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_D, [], _E, _F).
'$zipWith_2_3_:'(_A, _B, _C, _D, :('$$susp'( '$$apply', [ '$$susp'( '$$apply', [ _A, _B ], _E, _F ), _G ], _H, _I ), '$$susp'( '$zipWith', [ _A, _C, _J ], _K, _L )), _M, _N):-
        unifyHnfs(_D, :(_G, _J), _M, _N).

% zip
'$zip'(_A, _B, _C, _D, _E):-
        '$zipWith'(mkpair, _A, _B, _C, _D, _E).

% mkpair
'$mkpair'(_A, _B, '$$tup'(','(_A, _B)), _C, _C).

% unzip
'$unzip'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$unzip_1'(_E, _B, _F, _D).
'$unzip_1'(_A, '$$tup'(','([], [])), _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$unzip_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        '$auxForUnzip'(_J, _K, '$$susp'( '$unzip', [ _F ], _M, _N ), _B, _L, _D).

% auxForUnzip
'$auxForUnzip'(_A, _B, _C, '$$tup'(','(:(_A, _D), :(_B, _E))), _F, _G):-
        hnf(_C, '$$tup'(_H), _F, _I),
        hnf(_H, ','(_D, _E), _I, _G).

% until
'$until'(_A, _B, _C, _D, _E, _F):-
        '$if_then_else'('$$susp'( '$$apply', [ _A, _C ], _G, _H ), _C, '$$susp'( '$until', [ _A, _B, '$$susp'( '$$apply', [ _B, _C ], _I, _J ) ], _K, _L ), _D, _E, _F).

% 'until\''
'$until\''(_A, _B, '.'(takeUntil(_A), iterate(_B)), _C, _C).

% const
'$const'(_A, _B, _C, _D, _E):-
        hnf(_A, _C, _D, _E).

% id
'$id'(_A, _B, _C, _D):-
        hnf(_A, _B, _C, _D).

% //
$//(_A, _B, _C, _D, _E):-
        hnf(_A, _C, _D, _E).
$//(_A, _B, _C, _D, _E):-
        hnf(_B, _C, _D, _E).

% curry
'$curry'(_A, _B, _C, _D, _E, _F):-
        '$$apply'(_A, '$$tup'(','(_B, _C)), _D, _E, _F).

% uncurry
'$uncurry'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        '$$apply'('$$susp'( '$$apply', [ _A, _H ], _K, _L ), _I, _C, _J, _E).

% fst
'$fst'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_G, _B, _I, _D).

% snd
'$snd'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, _B, _I, _D).

% fst3
'$fst3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_G, _B, _L, _D).

% snd3
'$snd3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_J, _B, _L, _D).

% thd3
'$thd3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_K, _B, _L, _D).

% subtract
'$subtract'(flip(-), _A, _A).

% even
'$even'(_A, _B, _C, _D):-
        '$$eqFun'('$$susp'( '$mod', [ _A, 2 ], _E, _F ), 0, _B, _C, _D).

% odd
'$odd'('.'(not, even), _A, _A).

% lcm
'$lcm'(_A, _B, _C, _D, _E):-
        '$if_then_else'('$$susp'( $\/, [ '$$susp'( '$$eqFun', [ _A, 0 ], _F, _G ), '$$susp'( '$$eqFun', [ _B, 0 ], _H, _I ) ], _J, _K ), 0, '$$susp'( '$abs', [ '$$susp'( $*, [ '$$susp'( '$div', [ _A, '$$susp'( '$gcd', [ _A, _B ], _L, _M ) ], _N, _O ), _B ], _P, _Q ) ], _R, _S ), _C, _D, _E).

% head
'$head'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_E, _B, _G, _D).

% last
'$last'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$last_1_1.2_:'(_E, _H, _B, _I, _D).
'$last_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, [], _D, _F),
        hnf(_A, _C, _F, _E).
'$last_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$last'(:(_F, _G), _C, _H, _E).

% tail
'$tail'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _B, _G, _D).

% init
'$init'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$init_1_1.2_:'(_E, _H, _B, _I, _D).
'$init_1_1.2_:'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$init_1_1.2_:'(_A, _B, :(_A, '$$susp'( '$init', [ :(_C, _D) ], _E, _F )), _G, _H):-
        unifyHnfs(_B, :(_C, _D), _G, _H).

% nub
'$nub'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$nub_1'(_E, _B, _F, _D).
'$nub_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$nub_1'(_A, :(_B, '$$susp'( '$nub', [ '$$susp'( '$filter', [ '$notEqFun'(_B), _C ], _D, _E ) ], _F, _G )), _H, _I):-
        unifyHnfs(_A, :(_B, _C), _H, _I).

% length
'$length'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$length_1'(_E, _B, _F, _D).
'$length_1'(_A, 0, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$length_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $+(1, '$$susp'( '$length', [ _F ], _H, _I ), _B, _G, _D).

% size
'$size'('.'(length, nub), _A, _A).

% reverse
'$reverse'(foldl(flip(:), []), _A, _A).

% member
'$member'('.'('any\'', '$eqFun'), _A, _A).

% notMember
'$notMember'('.'(all, '$notEqFun'), _A, _A).

% concat
'$concat'(foldr(++, []), _A, _A).

% transpose
'$transpose'(foldr(auxForTranspose, []), _A, _A).

% auxForTranspose
'$auxForTranspose'(_A, _B, _C, _D, _E):-
        '$zipWith'(:, _A, '$$susp'( $++, [ _B, '$$susp'( '$repeat', [ [] ], _F, _G ) ], _H, _I ), _C, _D, _E).

% \\
$\\(foldl(del), _A, _A).

% del
'$del'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$del_1'(_F, _B, _C, _G, _E).
'$del_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$del_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun', [ _F, _B ], _I, _J ), _G, '$$susp'( '$del', [ :(_F, _G), _B ], _K, _L ), _C, _H, _E).

% parse
'$parse'(_A, true, _B, _C):-
        '$$eqFun'(_A, '$$susp'( '$expression',  [], _D, _E ), true, _B, _C).

% expression
'$expression'(_A, _B, _C):-
        '$term'(_A, _B, _C).
'$expression'(_A, _B, _C):-
        $++('$$susp'( '$term',  [], _D, _E ), '$$susp'( $++, [ :('$$susp'( $//, [ plus, minus ], _F, _G ), []), '$$susp'( '$expression',  [], _H, _I ) ], _J, _K ), _A, _B, _C).

% term
'$term'(_A, _B, _C):-
        '$factor'(_A, _B, _C).
'$term'(_A, _B, _C):-
        $++('$$susp'( '$factor',  [], _D, _E ), '$$susp'( $++, [ :('$$susp'( $//, [ times, quot ], _F, _G ), []), '$$susp'( '$term',  [], _H, _I ) ], _J, _K ), _A, _B, _C).

% factor
'$factor'(_A, _B, _C):-
        '$number'(_A, _B, _C).
'$factor'(_A, _B, _C):-
        $++(:(lpar, []), '$$susp'( $++, [ '$$susp'( '$expression',  [], _D, _E ), :(rpar, []) ], _F, _G ), _A, _B, _C).

% number
'$number'(:(n(_A), []), _B, _B).


/***********   CODE FOR DINAMIC CUT         ***********/

/*Lista de funciones deterministas indicadas por el usuario */

annotate(deterministic('$if_then_else')).


/*Lista de funciones deterministas por programa *************/

annotate(deterministic('$and')).
annotate(deterministic('$or')).
annotate(deterministic($/\)).
annotate(deterministic($\/)).
annotate(deterministic('$not')).
annotate(deterministic('$andL')).
annotate(deterministic('$orL')).
annotate(deterministic('$orL\'')).
annotate(deterministic('$any')).
annotate(deterministic('$any\'')).
annotate(deterministic('$all')).
annotate(deterministic('$undefined')).
annotate(deterministic('$def')).
annotate(deterministic('$not_undef')).
annotate(deterministic('$nf')).
annotate(deterministic('$hnf')).
annotate(deterministic('$strict')).
annotate(deterministic('$strict\'')).
annotate(deterministic('$map')).
annotate(deterministic($.)).
annotate(deterministic($++)).
annotate(deterministic('$!!')).
annotate(deterministic('$iterate')).
annotate(deterministic('$repeat')).
annotate(deterministic('$copy')).
annotate(deterministic('$filter')).
annotate(deterministic('$foldl')).
annotate(deterministic('$foldl1')).
annotate(deterministic('$foldl\'')).
annotate(deterministic('$scanl')).
annotate(deterministic('$scanl1')).
annotate(deterministic('$scanl\'')).
annotate(deterministic('$foldr')).
annotate(deterministic('$foldr1')).
annotate(deterministic('$scanr')).
annotate(deterministic('$auxForScanr')).
annotate(deterministic('$scanr1')).
annotate(deterministic('$take')).
annotate(deterministic('$drop')).
annotate(deterministic('$splitAt')).
annotate(deterministic('$auxForSplitAt')).
annotate(deterministic('$takeWhile')).
annotate(deterministic('$takeUntil')).
annotate(deterministic('$dropWhile')).
annotate(deterministic('$span')).
annotate(deterministic('$auxForSpan')).
annotate(deterministic('$break')).
annotate(deterministic('$zipWith')).
annotate(deterministic('$zip')).
annotate(deterministic('$mkpair')).
annotate(deterministic('$unzip')).
annotate(deterministic('$auxForUnzip')).
annotate(deterministic('$until')).
annotate(deterministic('$until\'')).
annotate(deterministic('$const')).
annotate(deterministic('$id')).
annotate(deterministic('$curry')).
annotate(deterministic('$uncurry')).
annotate(deterministic('$fst')).
annotate(deterministic('$snd')).
annotate(deterministic('$fst3')).
annotate(deterministic('$snd3')).
annotate(deterministic('$thd3')).
annotate(deterministic('$subtract')).
annotate(deterministic('$even')).
annotate(deterministic('$odd')).
annotate(deterministic('$lcm')).
annotate(deterministic('$head')).
annotate(deterministic('$last')).
annotate(deterministic('$tail')).
annotate(deterministic('$init')).
annotate(deterministic('$nub')).
annotate(deterministic('$length')).
annotate(deterministic('$size')).
annotate(deterministic('$reverse')).
annotate(deterministic('$member')).
annotate(deterministic('$notMember')).
annotate(deterministic('$concat')).
annotate(deterministic('$transpose')).
annotate(deterministic('$auxForTranspose')).
annotate(deterministic($\\)).
annotate(deterministic('$del')).
annotate(deterministic('$number')).


% varList(+List,-ListVars): ListVars is a list with all the variables from
% terms in List  that can avoid the cut if they are bound
% Each variable occurrs only once in ListVars.
varList(ListTerms,ListVars) :- varList(ListTerms,[],ListVars),!.

% varList(+List,+LI, -LO): Analagous to varList/2 but with LI
% the list of variables accumulated at the moment.
varList([],ListVars,ListVars) :- !.
varList([X|Xs],LI,LO) :- varListTerm(X,LI,LO1),
                         varList(Xs,LO1,LO).
% varListTerm(+Term,+LI,-LO) : Analogous to varList/3 but for a single term
varListTerm(T,L,L)       :- atomic(T),!.
varListTerm(V,LI,LI)     :- var(V), varInList(V,LI),!.
varListTerm(V,LI,[V|LI]) :- var(V),!.

% evaluated suspension: check the result
varListTerm('$$susp'(_F,_Args,R,S),LI,LO) :- \+var(S),
                                             !,
                                             varListTerm(R,LI,LO).

% non-evaluated suspension: collect the variables of the arguments, and
% the variable determining if it is evaluated if it is non-deterministic
varListTerm('$$susp'(F,Args,_R,S),LI,LO) :- varList(Args,LI,LO1),
                                           (
                                             \+annotate(deterministic(F)),
                                             \+varInList(S,LO1),
                                             LO=[S|LO1]
                                               ;
                                             LO = LO1
                                           ),
                                           !.
% rest of the possibilities
varListTerm(Term,LI,LO):- Term =.. [F|Args],
varListTerm(F,LI,LO1),
varList(Args,LO1,LO).

% varInList(+V,+L)
% Checks if the var V occurrs in the list L
varInList(V,[R|_L]) :- V==R,!.
varInList(V,[_R|L]) :- varInList(V,L).
% checkVarList(L): Checks if the input list contains different variables
checkVarList([]) :- !.
checkVarList([X|Xs]) :- var(X), \+varInList(X,Xs), checkVarList(Xs).


/***********   CONSTRUCTORS AND FUNCTIONS   ***********/

constr(',', 2, ->(_A, ->(_B, ','(_A, _B))), ','(_A, _B)).
constr('$$tup', 1, ->(','(_A, _B), '$$tuple'(','(_A, _B))), '$$tuple'(','(_A, _B))).
constr([], 0, :(_A, []), :(_A, [])).
constr(:, 2, ->(_A, ->(:(_A, []), :(_A, []))), :(_A, [])).
constr('$char', 1, ->(_A, char), char).
constr('$io', 1, ->(_A, '$io'(_A)), '$io'(_A)).
constr('$stream', 1, handle, handle).
constr(readMode, 0, ioMode, ioMode).
constr(writeMode, 0, ioMode, ioMode).
constr(appendMode, 0, ioMode, ioMode).
constr('$channel', 2, channel, channel).
constr('$varmut', 1, varmut, varmut).
constr(pValBottom, 0, pVal, pVal).
constr(pValChar, 1, ->(char, pVal), pVal).
constr(pValNum, 1, ->(:(char, []), pVal), pVal).
constr(pValVar, 1, ->(:(char, []), pVal), pVal).
constr(pValApp, 2, ->(:(char, []), ->(:(pVal, []), pVal)), pVal).
constr(constraint, 1, ->(:(atomicConstraint, []), constraint), constraint).
constr(atomicConstraint, 3, ->(:(char, []), ->(:(pVal, []), ->(pVal, atomicConstraint))), atomicConstraint).
constr(cTreeNode, 7, ->(:(char, []), ->(:(pVal, []), ->(pVal, ->(:(char, []), ->(:(pVal, []), ->(:(char, []), ->(:('$$tuple'(','(pVal, cTree)), []), cTree))))))), cTree).
constr(cTreeVoid, 0, cTree, cTree).
constr(n, 1, ->('$num'(int), token), token).
constr(plus, 0, token, token).
constr(minus, 0, token, token).
constr(times, 0, token, token).
constr(quot, 0, token, token).
constr(lpar, 0, token, token).
constr(rpar, 0, token, token).
constr(true, 0, bool, bool).
constr(false, 0, bool, bool).

funct(uminus, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(abs, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(sqrt, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(ln, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(exp, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(coth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acoth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(evalfd, 2, 2, ->(:(char, []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(+, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(-, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(*, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(min, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(max, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(/, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(float))), '$num'(float)).
funct(**, 2, 2, ->('$num'(_A), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(log, 2, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(^, 2, 2, ->('$num'(_A), ->('$num'(int), '$num'(_A))), '$num'(_A)).
funct(div, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(mod, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(gcd, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(round, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(trunc, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(floor, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(ceiling, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(toReal, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(<, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(<=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(==, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(/=, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(ord, 1, 1, ->(char, '$num'(int)), '$num'(int)).
funct(chr, 1, 1, ->('$num'(int), char), char).
funct(putChar, 1, 1, ->(char, io(unit)), io(unit)).
funct(done, 0, 0, io(unit), io(unit)).
funct(getChar, 0, 0, io(char), io(char)).
funct(return, 1, 1, ->(_A, io(_A)), io(_A)).
funct(>>, 2, 2, ->(io(_A), ->(io(_B), io(_B))), io(_B)).
funct(>>=, 2, 2, ->(io(_A), ->(->(_A, io(_B)), io(_B))), io(_B)).
funct(putStr, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(putStrLn, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(getLine, 0, 0, io(:(char, [])), io(:(char, []))).
funct(cont1, 1, 1, ->(char, io(:(char, []))), io(:(char, []))).
funct(cont2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).
funct(writeFile, 2, 2, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(readFile, 1, 1, ->(:(char, []), io(:(char, []))), io(:(char, []))).
funct(readFileContents, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(dVal, 1, 1, ->(_A, pVal), pVal).
funct(dValToString, 1, 1, ->(_A, :(char, [])), :(char, [])).
funct(getConstraintStore, 1, 1, ->(:(_A, []), constraint), constraint).
funct(selectWhereVariableXi, 4, 4, ->(_A, ->('$num'(int), ->('$num'(int), ->(_B, _C)))), _C).
funct(fails, 1, 1, ->(_A, bool), bool).
funct(once, 1, 1, ->(_A, _A), _A).
funct(collect, 1, 1, ->(_A, :(_A, [])), :(_A, [])).
funct(collectN, 2, 2, ->('$num'(int), ->(_A, :(_A, []))), :(_A, [])).
funct(if_then_else, 3, 3, ->(bool, ->(_A, ->(_A, _A))), _A).
funct(if_then, 2, 2, ->(bool, ->(_A, _A)), _A).
funct(flip, 3, 3, ->(->(_A, ->(_B, _C)), ->(_B, ->(_A, _C))), _C).

funct('$apply', 2, 2, ->(->(->(_A, _B), _A), _B), _B).
funct('$eqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct('$notEqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct(and, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(or, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(/\, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(\/, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(not, 1, 1, ->(bool, bool), bool).
funct(andL, 0, 1, ->(:(bool, []), bool), bool).
funct(orL, 0, 1, ->(:(bool, []), bool), bool).
funct('orL\'', 0, 1, ->(:(bool, []), bool), bool).
funct(any, 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct('any\'', 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct(all, 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct(undefined, 0, 0, _A, _A).
funct(def, 1, _A, ->(_B, bool), bool).
funct(not_undef, 1, _A, ->(_B, bool), bool).
funct(nf, 1, _A, ->(_B, _B), _B).
funct(hnf, 1, _A, ->(_B, _B), _B).
funct(strict, 2, _A, ->(->(_B, _C), ->(_B, _C)), _C).
funct('strict\'', 2, _A, ->(->(_B, _C), ->(_B, _C)), _C).
funct(map, 2, 2, ->(->(_A, _B), ->(:(_A, []), :(_B, []))), :(_B, [])).
funct('.', 3, 3, ->(->(_A, _B), ->(->(_C, _A), ->(_C, _B))), _B).
funct(++, 2, 2, ->(:(_A, []), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct('!!', 2, 2, ->(:(_A, []), ->('$num'(int), _A)), _A).
funct(iterate, 2, 2, ->(->(_A, _A), ->(_A, :(_A, []))), :(_A, [])).
funct(repeat, 1, 1, ->(_A, :(_A, [])), :(_A, [])).
funct(copy, 2, 2, ->('$num'(int), ->(_A, :(_A, []))), :(_A, [])).
funct(filter, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(foldl, 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), _A))), _A).
funct(foldl1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), _A)), _A).
funct('foldl\'', 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), _A))), _A).
funct(scanl, 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), :(_A, [])))), :(_A, [])).
funct(scanl1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct('scanl\'', 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), :(_A, [])))), :(_A, [])).
funct(foldr, 3, 3, ->(->(_A, ->(_B, _B)), ->(_B, ->(:(_A, []), _B))), _B).
funct(foldr1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), _A)), _A).
funct(scanr, 3, 3, ->(->(_A, ->(_B, _B)), ->(_B, ->(:(_A, []), :(_B, [])))), :(_B, [])).
funct(auxForScanr, 3, _A, ->(->(_B, ->(_C, _C)), ->(_B, ->(:(_C, []), :(_C, [])))), :(_C, [])).
funct(scanr1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(take, 2, 2, ->('$num'(int), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(drop, 2, 2, ->('$num'(int), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(splitAt, 2, 2, ->('$num'(int), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(auxForSplitAt, 2, _A, ->(_B, ->('$$tuple'(','(:(_B, []), _C)), '$$tuple'(','(:(_B, []), _C)))), '$$tuple'(','(:(_B, []), _C))).
funct(takeWhile, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(takeUntil, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(dropWhile, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(span, 2, 2, ->(->(_A, bool), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(auxForSpan, 2, _A, ->(_B, ->('$$tuple'(','(:(_B, []), _C)), '$$tuple'(','(:(_B, []), _C)))), '$$tuple'(','(:(_B, []), _C))).
funct(break, 1, 2, ->(->(_A, bool), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(zipWith, 3, 3, ->(->(_A, ->(_B, _C)), ->(:(_A, []), ->(:(_B, []), :(_C, [])))), :(_C, [])).
funct(zip, 2, 2, ->(:(_A, []), ->(:(_B, []), :('$$tuple'(','(_A, _B)), []))), :('$$tuple'(','(_A, _B)), [])).
funct(mkpair, 2, 2, ->(_A, ->(_B, '$$tuple'(','(_A, _B)))), '$$tuple'(','(_A, _B))).
funct(unzip, 1, 1, ->(:('$$tuple'(','(_A, _B)), []), '$$tuple'(','(:(_A, []), :(_B, [])))), '$$tuple'(','(:(_A, []), :(_B, [])))).
funct(auxForUnzip, 3, _A, ->(_B, ->(_C, ->('$$tuple'(','(:(_B, []), :(_C, []))), '$$tuple'(','(:(_B, []), :(_C, [])))))), '$$tuple'(','(:(_B, []), :(_C, [])))).
funct(until, 3, 3, ->(->(_A, bool), ->(->(_A, _A), ->(_A, _A))), _A).
funct('until\'', 2, 3, ->(->(_A, bool), ->(->(_A, _A), ->(_A, :(_A, [])))), :(_A, [])).
funct(const, 2, 2, ->(_A, ->(_B, _A)), _A).
funct(id, 1, 1, ->(_A, _A), _A).
funct(//, 2, 2, ->(_A, ->(_A, _A)), _A).
funct(curry, 3, 3, ->(->('$$tuple'(','(_A, _B)), _C), ->(_A, ->(_B, _C))), _C).
funct(uncurry, 2, 2, ->(->(_A, ->(_B, _C)), ->('$$tuple'(','(_A, _B)), _C)), _C).
funct(fst, 1, 1, ->('$$tuple'(','(_A, _B)), _A), _A).
funct(snd, 1, 1, ->('$$tuple'(','(_A, _B)), _B), _B).
funct(fst3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _A), _A).
funct(snd3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _B), _B).
funct(thd3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _C), _C).
funct(subtract, 0, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(even, 1, 1, ->('$num'(int), bool), bool).
funct(odd, 0, 1, ->('$num'(int), bool), bool).
funct(lcm, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(head, 1, 1, ->(:(_A, []), _A), _A).
funct(last, 1, 1, ->(:(_A, []), _A), _A).
funct(tail, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(init, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(nub, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(length, 1, 1, ->(:(_A, []), '$num'(int)), '$num'(int)).
funct(size, 0, 1, ->(:(_A, []), '$num'(int)), '$num'(int)).
funct(reverse, 0, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(member, 0, 2, ->(_A, ->(:(_A, []), bool)), bool).
funct(notMember, 0, 2, ->(_A, ->(:(_A, []), bool)), bool).
funct(concat, 0, 1, ->(:(:(_A, []), []), :(_A, [])), :(_A, [])).
funct(transpose, 0, 1, ->(:(:(_A, []), []), :(:(_A, []), [])), :(:(_A, []), [])).
funct(auxForTranspose, 2, _A, ->(:(_B, []), ->(:(:(_B, []), []), :(:(_B, []), []))), :(:(_B, []), [])).
funct(\\, 0, 2, ->(:(_A, []), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(del, 2, _A, ->(:(_B, []), ->(_B, :(_B, []))), :(_B, [])).
funct(parse, 1, 1, ->(:(token, []), bool), bool).
funct(expression, 0, 0, :(token, []), :(token, [])).
funct(term, 0, 0, :(token, []), :(token, [])).
funct(factor, 0, 0, :(token, []), :(token, [])).
funct(number, 0, 0, :(token, []), :(token, [])).

/************    CODE FOR FUNCIONS HNF    ************/

hnf_susp('$uminus', '.'(_A, []), _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
hnf_susp('$abs', '.'(_A, []), _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
hnf_susp('$sqrt', '.'(_A, []), _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
hnf_susp('$ln', '.'(_A, []), _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
hnf_susp('$exp', '.'(_A, []), _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
hnf_susp('$sin', '.'(_A, []), _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
hnf_susp('$cos', '.'(_A, []), _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
hnf_susp('$tan', '.'(_A, []), _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
hnf_susp('$cot', '.'(_A, []), _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
hnf_susp('$asin', '.'(_A, []), _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
hnf_susp('$acos', '.'(_A, []), _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
hnf_susp('$atan', '.'(_A, []), _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
hnf_susp('$acot', '.'(_A, []), _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
hnf_susp('$sinh', '.'(_A, []), _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
hnf_susp('$cosh', '.'(_A, []), _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
hnf_susp('$tanh', '.'(_A, []), _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
hnf_susp('$coth', '.'(_A, []), _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
hnf_susp('$asinh', '.'(_A, []), _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
hnf_susp('$acosh', '.'(_A, []), _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
hnf_susp('$atanh', '.'(_A, []), _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
hnf_susp('$acoth', '.'(_A, []), _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
hnf_susp('$evalfd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
hnf_susp($+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
hnf_susp($-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
hnf_susp($*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
hnf_susp('$min', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
hnf_susp('$max', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
hnf_susp($/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
hnf_susp($**, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
hnf_susp('$log', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
hnf_susp($^, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
hnf_susp('$div', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
hnf_susp('$mod', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
hnf_susp('$gcd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
hnf_susp('$round', '.'(_A, []), _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
hnf_susp('$trunc', '.'(_A, []), _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
hnf_susp('$floor', '.'(_A, []), _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
hnf_susp('$ceiling', '.'(_A, []), _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
hnf_susp('$toReal', '.'(_A, []), _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
hnf_susp($<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
hnf_susp($<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
hnf_susp($>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
hnf_susp($>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
hnf_susp($==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
hnf_susp($/=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
hnf_susp('$ord', '.'(_A, []), _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
hnf_susp('$chr', '.'(_A, []), _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
hnf_susp('$putChar', '.'(_A, []), _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
hnf_susp('$done', [], _A, _B, _C):-
        '$done'(_A, _B, _C).
hnf_susp('$getChar', [], _A, _B, _C):-
        '$getChar'(_A, _B, _C).
hnf_susp('$return', '.'(_A, []), _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
hnf_susp($>>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
hnf_susp($>>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
hnf_susp('$putStr', '.'(_A, []), _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
hnf_susp('$putStrLn', '.'(_A, []), _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
hnf_susp('$getLine', [], _A, _B, _C):-
        '$getLine'(_A, _B, _C).
hnf_susp('$cont1', '.'(_A, []), _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
hnf_susp('$cont2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
hnf_susp('$writeFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
hnf_susp('$readFile', '.'(_A, []), _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
hnf_susp('$readFileContents', '.'(_A, []), _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
hnf_susp('$dVal', '.'(_A, []), _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
hnf_susp('$dValToString', '.'(_A, []), _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
hnf_susp('$getConstraintStore', '.'(_A, []), _B, _C, _D):-
        '$getConstraintStore'(_A, _B, _C, _D).
hnf_susp('$selectWhereVariableXi', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$fails', '.'(_A, []), _B, _C, _D):-
        '$fails'(_A, _B, _C, _D).
hnf_susp('$once', '.'(_A, []), _B, _C, _D):-
        '$once'(_A, _B, _C, _D).
hnf_susp('$collect', '.'(_A, []), _B, _C, _D):-
        '$collect'(_A, _B, _C, _D).
hnf_susp('$collectN', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$collectN'(_A, _B, _C, _D, _E).
hnf_susp('$if_then_else', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
hnf_susp('$if_then', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
hnf_susp('$flip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$$apply', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$apply'(_A, _B, _C, _D, _E).
hnf_susp('$$eqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
hnf_susp('$$notEqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
hnf_susp('$and', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$and'(_A, _B, _C, _D, _E).
hnf_susp('$or', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$or'(_A, _B, _C, _D, _E).
hnf_susp($/\, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/\(_A, _B, _C, _D, _E).
hnf_susp($\/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $\/(_A, _B, _C, _D, _E).
hnf_susp('$not', '.'(_A, []), _B, _C, _D):-
        '$not'(_A, _B, _C, _D).
hnf_susp('$andL', [], _A, _B, _C):-
        '$andL'(_A, _B, _C).
hnf_susp('$orL', [], _A, _B, _C):-
        '$orL'(_A, _B, _C).
hnf_susp('$orL\'', [], _A, _B, _C):-
        '$orL\''(_A, _B, _C).
hnf_susp('$any', '.'(_A, []), _B, _C, _D):-
        '$any'(_A, _B, _C, _D).
hnf_susp('$any\'', '.'(_A, []), _B, _C, _D):-
        '$any\''(_A, _B, _C, _D).
hnf_susp('$all', '.'(_A, []), _B, _C, _D):-
        '$all'(_A, _B, _C, _D).
hnf_susp('$undefined', [], _A, _B, _C):-
        '$undefined'(_A, _B, _C).
hnf_susp('$def', '.'(_A, []), _B, _C, _D):-
        '$def'(_A, _B, _C, _D).
hnf_susp('$not_undef', '.'(_A, []), _B, _C, _D):-
        '$not_undef'(_A, _B, _C, _D).
hnf_susp('$nf', '.'(_A, []), _B, _C, _D):-
        '$nf'(_A, _B, _C, _D).
hnf_susp('$hnf', '.'(_A, []), _B, _C, _D):-
        '$hnf'(_A, _B, _C, _D).
hnf_susp('$strict', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$strict'(_A, _B, _C, _D, _E).
hnf_susp('$strict\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$strict\''(_A, _B, _C, _D, _E).
hnf_susp('$map', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$map'(_A, _B, _C, _D, _E).
hnf_susp($., '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        $.(_A, _B, _C, _D, _E, _F).
hnf_susp($++, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $++(_A, _B, _C, _D, _E).
hnf_susp('$!!', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$!!'(_A, _B, _C, _D, _E).
hnf_susp('$iterate', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$iterate'(_A, _B, _C, _D, _E).
hnf_susp('$repeat', '.'(_A, []), _B, _C, _D):-
        '$repeat'(_A, _B, _C, _D).
hnf_susp('$copy', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$copy'(_A, _B, _C, _D, _E).
hnf_susp('$filter', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$filter'(_A, _B, _C, _D, _E).
hnf_susp('$foldl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldl1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$foldl1'(_A, _B, _C, _D, _E).
hnf_susp('$foldl\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldl\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanl1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$scanl1'(_A, _B, _C, _D, _E).
hnf_susp('$scanl\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanl\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldr1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$foldr1'(_A, _B, _C, _D, _E).
hnf_susp('$scanr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$auxForScanr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$auxForScanr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanr1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$scanr1'(_A, _B, _C, _D, _E).
hnf_susp('$take', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$take'(_A, _B, _C, _D, _E).
hnf_susp('$drop', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$drop'(_A, _B, _C, _D, _E).
hnf_susp('$splitAt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$splitAt'(_A, _B, _C, _D, _E).
hnf_susp('$auxForSplitAt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForSplitAt'(_A, _B, _C, _D, _E).
hnf_susp('$takeWhile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$takeWhile'(_A, _B, _C, _D, _E).
hnf_susp('$takeUntil', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$takeUntil'(_A, _B, _C, _D, _E).
hnf_susp('$dropWhile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$dropWhile'(_A, _B, _C, _D, _E).
hnf_susp('$span', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$span'(_A, _B, _C, _D, _E).
hnf_susp('$auxForSpan', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForSpan'(_A, _B, _C, _D, _E).
hnf_susp('$break', '.'(_A, []), _B, _C, _D):-
        '$break'(_A, _B, _C, _D).
hnf_susp('$zipWith', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$zipWith'(_A, _B, _C, _D, _E, _F).
hnf_susp('$zip', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$zip'(_A, _B, _C, _D, _E).
hnf_susp('$mkpair', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mkpair'(_A, _B, _C, _D, _E).
hnf_susp('$unzip', '.'(_A, []), _B, _C, _D):-
        '$unzip'(_A, _B, _C, _D).
hnf_susp('$auxForUnzip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$auxForUnzip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$until', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$until'(_A, _B, _C, _D, _E, _F).
hnf_susp('$until\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$until\''(_A, _B, _C, _D, _E).
hnf_susp('$const', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$const'(_A, _B, _C, _D, _E).
hnf_susp('$id', '.'(_A, []), _B, _C, _D):-
        '$id'(_A, _B, _C, _D).
hnf_susp($//, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $//(_A, _B, _C, _D, _E).
hnf_susp('$curry', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$curry'(_A, _B, _C, _D, _E, _F).
hnf_susp('$uncurry', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$uncurry'(_A, _B, _C, _D, _E).
hnf_susp('$fst', '.'(_A, []), _B, _C, _D):-
        '$fst'(_A, _B, _C, _D).
hnf_susp('$snd', '.'(_A, []), _B, _C, _D):-
        '$snd'(_A, _B, _C, _D).
hnf_susp('$fst3', '.'(_A, []), _B, _C, _D):-
        '$fst3'(_A, _B, _C, _D).
hnf_susp('$snd3', '.'(_A, []), _B, _C, _D):-
        '$snd3'(_A, _B, _C, _D).
hnf_susp('$thd3', '.'(_A, []), _B, _C, _D):-
        '$thd3'(_A, _B, _C, _D).
hnf_susp('$subtract', [], _A, _B, _C):-
        '$subtract'(_A, _B, _C).
hnf_susp('$even', '.'(_A, []), _B, _C, _D):-
        '$even'(_A, _B, _C, _D).
hnf_susp('$odd', [], _A, _B, _C):-
        '$odd'(_A, _B, _C).
hnf_susp('$lcm', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$lcm'(_A, _B, _C, _D, _E).
hnf_susp('$head', '.'(_A, []), _B, _C, _D):-
        '$head'(_A, _B, _C, _D).
hnf_susp('$last', '.'(_A, []), _B, _C, _D):-
        '$last'(_A, _B, _C, _D).
hnf_susp('$tail', '.'(_A, []), _B, _C, _D):-
        '$tail'(_A, _B, _C, _D).
hnf_susp('$init', '.'(_A, []), _B, _C, _D):-
        '$init'(_A, _B, _C, _D).
hnf_susp('$nub', '.'(_A, []), _B, _C, _D):-
        '$nub'(_A, _B, _C, _D).
hnf_susp('$length', '.'(_A, []), _B, _C, _D):-
        '$length'(_A, _B, _C, _D).
hnf_susp('$size', [], _A, _B, _C):-
        '$size'(_A, _B, _C).
hnf_susp('$reverse', [], _A, _B, _C):-
        '$reverse'(_A, _B, _C).
hnf_susp('$member', [], _A, _B, _C):-
        '$member'(_A, _B, _C).
hnf_susp('$notMember', [], _A, _B, _C):-
        '$notMember'(_A, _B, _C).
hnf_susp('$concat', [], _A, _B, _C):-
        '$concat'(_A, _B, _C).
hnf_susp('$transpose', [], _A, _B, _C):-
        '$transpose'(_A, _B, _C).
hnf_susp('$auxForTranspose', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForTranspose'(_A, _B, _C, _D, _E).
hnf_susp($\\, [], _A, _B, _C):-
        $\\(_A, _B, _C).
hnf_susp('$del', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$del'(_A, _B, _C, _D, _E).
hnf_susp('$parse', '.'(_A, []), _B, _C, _D):-
        '$parse'(_A, _B, _C, _D).
hnf_susp('$expression', [], _A, _B, _C):-
        '$expression'(_A, _B, _C).
hnf_susp('$term', [], _A, _B, _C):-
        '$term'(_A, _B, _C).
hnf_susp('$factor', [], _A, _B, _C):-
        '$factor'(_A, _B, _C).
hnf_susp('$number', [], _A, _B, _C):-
        '$number'(_A, _B, _C).




/***************     CODE FOR APPLY     ***************/

'$$apply'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$$applyHnf'(_F, _B, _C, _G, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        var(_A),
        !,
        '$$apply_1_var'(_A, _B, _C, _D, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        '$$apply_1'(_A, _B, _C, _D, _E).

% constructors

'$$apply_1'(:, _A, :(_A), _B, _B).
'$$apply_1_var'(_A, _B, :(_B), _C, _D):-
        unifyHnfs(_A, :, _C, _D).

'$$apply_1'(:(_A), _B, :(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, :(_C, _B), _D, _E):-
        unifyHnfs(_A, :(_C), _D, _E).

'$$apply_1'('$io', _A, '$io'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$io'(_B), _C, _D):-
        unifyHnfs(_A, '$io', _C, _D).

'$$apply_1'('$stream', _A, '$stream'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$stream'(_B), _C, _D):-
        unifyHnfs(_A, '$stream', _C, _D).

'$$apply_1'('$channel', _A, '$channel'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$channel'(_B), _C, _D):-
        unifyHnfs(_A, '$channel', _C, _D).

'$$apply_1'('$channel'(_A), _B, '$channel'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$channel'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$channel'(_C), _D, _E).

'$$apply_1'('$varmut', _A, '$varmut'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$varmut'(_B), _C, _D):-
        unifyHnfs(_A, '$varmut', _C, _D).

'$$apply_1'(pValChar, _A, pValChar(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValChar(_B), _C, _D):-
        unifyHnfs(_A, pValChar, _C, _D).

'$$apply_1'(pValNum, _A, pValNum(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValNum(_B), _C, _D):-
        unifyHnfs(_A, pValNum, _C, _D).

'$$apply_1'(pValVar, _A, pValVar(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValVar(_B), _C, _D):-
        unifyHnfs(_A, pValVar, _C, _D).

'$$apply_1'(pValApp, _A, pValApp(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValApp(_B), _C, _D):-
        unifyHnfs(_A, pValApp, _C, _D).

'$$apply_1'(pValApp(_A), _B, pValApp(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, pValApp(_C, _B), _D, _E):-
        unifyHnfs(_A, pValApp(_C), _D, _E).

'$$apply_1'(constraint, _A, constraint(_A), _B, _B).
'$$apply_1_var'(_A, _B, constraint(_B), _C, _D):-
        unifyHnfs(_A, constraint, _C, _D).

'$$apply_1'(atomicConstraint, _A, atomicConstraint(_A), _B, _B).
'$$apply_1_var'(_A, _B, atomicConstraint(_B), _C, _D):-
        unifyHnfs(_A, atomicConstraint, _C, _D).

'$$apply_1'(atomicConstraint(_A), _B, atomicConstraint(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, atomicConstraint(_C, _B), _D, _E):-
        unifyHnfs(_A, atomicConstraint(_C), _D, _E).

'$$apply_1'(atomicConstraint(_A, _B), _C, atomicConstraint(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, atomicConstraint(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, atomicConstraint(_C, _D), _E, _F).

'$$apply_1'(cTreeNode, _A, cTreeNode(_A), _B, _B).
'$$apply_1_var'(_A, _B, cTreeNode(_B), _C, _D):-
        unifyHnfs(_A, cTreeNode, _C, _D).

'$$apply_1'(cTreeNode(_A), _B, cTreeNode(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _B), _D, _E):-
        unifyHnfs(_A, cTreeNode(_C), _D, _E).

'$$apply_1'(cTreeNode(_A, _B), _C, cTreeNode(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, cTreeNode(_C, _D), _E, _F).

'$$apply_1'(cTreeNode(_A, _B, _C), _D, cTreeNode(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E), _F, _G).

'$$apply_1'(cTreeNode(_A, _B, _C, _D), _E, cTreeNode(_A, _B, _C, _D, _E), _F, _F).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _B), _G, _H):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F), _G, _H).

'$$apply_1'(cTreeNode(_A, _B, _C, _D, _E), _F, cTreeNode(_A, _B, _C, _D, _E, _F), _G, _G).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _G, _B), _H, _I):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F, _G), _H, _I).

'$$apply_1'(cTreeNode(_A, _B, _C, _D, _E, _F), _G, cTreeNode(_A, _B, _C, _D, _E, _F, _G), _H, _H).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _G, _H, _B), _I, _J):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F, _G, _H), _I, _J).

'$$apply_1'(n, _A, n(_A), _B, _B).
'$$apply_1_var'(_A, _B, n(_B), _C, _D):-
        unifyHnfs(_A, n, _C, _D).

% parcial aplictions of funs

'$$apply_1'('$eqFun', _A, '$eqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$eqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$eqFun', _C, _D).

'$$apply_1'('$notEqFun', _A, '$notEqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$notEqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$notEqFun', _C, _D).

'$$apply_1'(and, _A, and(_A), _B, _B).
'$$apply_1_var'(_A, _B, and(_B), _C, _D):-
        unifyHnfs(_A, and, _C, _D).

'$$apply_1'(or, _A, or(_A), _B, _B).
'$$apply_1_var'(_A, _B, or(_B), _C, _D):-
        unifyHnfs(_A, or, _C, _D).

'$$apply_1'(/\, _A, /\(_A), _B, _B).
'$$apply_1_var'(_A, _B, /\(_B), _C, _D):-
        unifyHnfs(_A, /\, _C, _D).

'$$apply_1'(\/, _A, \/(_A), _B, _B).
'$$apply_1_var'(_A, _B, \/(_B), _C, _D):-
        unifyHnfs(_A, \/, _C, _D).

'$$apply_1'(strict, _A, strict(_A), _B, _B).
'$$apply_1_var'(_A, _B, strict(_B), _C, _D):-
        unifyHnfs(_A, strict, _C, _D).

'$$apply_1'('strict\'', _A, 'strict\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'strict\''(_B), _C, _D):-
        unifyHnfs(_A, 'strict\'', _C, _D).

'$$apply_1'(map, _A, map(_A), _B, _B).
'$$apply_1_var'(_A, _B, map(_B), _C, _D):-
        unifyHnfs(_A, map, _C, _D).

'$$apply_1'('.', _A, '.'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '.'(_B), _C, _D):-
        unifyHnfs(_A, '.', _C, _D).

'$$apply_1'('.'(_A), _B, '.'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '.'(_C, _B), _D, _E):-
        unifyHnfs(_A, '.'(_C), _D, _E).

'$$apply_1'(++, _A, ++(_A), _B, _B).
'$$apply_1_var'(_A, _B, ++(_B), _C, _D):-
        unifyHnfs(_A, ++, _C, _D).

'$$apply_1'('!!', _A, '!!'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '!!'(_B), _C, _D):-
        unifyHnfs(_A, '!!', _C, _D).

'$$apply_1'(iterate, _A, iterate(_A), _B, _B).
'$$apply_1_var'(_A, _B, iterate(_B), _C, _D):-
        unifyHnfs(_A, iterate, _C, _D).

'$$apply_1'(copy, _A, copy(_A), _B, _B).
'$$apply_1_var'(_A, _B, copy(_B), _C, _D):-
        unifyHnfs(_A, copy, _C, _D).

'$$apply_1'(filter, _A, filter(_A), _B, _B).
'$$apply_1_var'(_A, _B, filter(_B), _C, _D):-
        unifyHnfs(_A, filter, _C, _D).

'$$apply_1'(foldl, _A, foldl(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldl(_B), _C, _D):-
        unifyHnfs(_A, foldl, _C, _D).

'$$apply_1'(foldl(_A), _B, foldl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, foldl(_C, _B), _D, _E):-
        unifyHnfs(_A, foldl(_C), _D, _E).

'$$apply_1'(foldl1, _A, foldl1(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldl1(_B), _C, _D):-
        unifyHnfs(_A, foldl1, _C, _D).

'$$apply_1'('foldl\'', _A, 'foldl\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'foldl\''(_B), _C, _D):-
        unifyHnfs(_A, 'foldl\'', _C, _D).

'$$apply_1'('foldl\''(_A), _B, 'foldl\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'foldl\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'foldl\''(_C), _D, _E).

'$$apply_1'(scanl, _A, scanl(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanl(_B), _C, _D):-
        unifyHnfs(_A, scanl, _C, _D).

'$$apply_1'(scanl(_A), _B, scanl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scanl(_C, _B), _D, _E):-
        unifyHnfs(_A, scanl(_C), _D, _E).

'$$apply_1'(scanl1, _A, scanl1(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanl1(_B), _C, _D):-
        unifyHnfs(_A, scanl1, _C, _D).

'$$apply_1'('scanl\'', _A, 'scanl\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'scanl\''(_B), _C, _D):-
        unifyHnfs(_A, 'scanl\'', _C, _D).

'$$apply_1'('scanl\''(_A), _B, 'scanl\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'scanl\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'scanl\''(_C), _D, _E).

'$$apply_1'(foldr, _A, foldr(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldr(_B), _C, _D):-
        unifyHnfs(_A, foldr, _C, _D).

'$$apply_1'(foldr(_A), _B, foldr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, foldr(_C, _B), _D, _E):-
        unifyHnfs(_A, foldr(_C), _D, _E).

'$$apply_1'(foldr1, _A, foldr1(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldr1(_B), _C, _D):-
        unifyHnfs(_A, foldr1, _C, _D).

'$$apply_1'(scanr, _A, scanr(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanr(_B), _C, _D):-
        unifyHnfs(_A, scanr, _C, _D).

'$$apply_1'(scanr(_A), _B, scanr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scanr(_C, _B), _D, _E):-
        unifyHnfs(_A, scanr(_C), _D, _E).

'$$apply_1'(auxForScanr, _A, auxForScanr(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForScanr(_B), _C, _D):-
        unifyHnfs(_A, auxForScanr, _C, _D).

'$$apply_1'(auxForScanr(_A), _B, auxForScanr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, auxForScanr(_C, _B), _D, _E):-
        unifyHnfs(_A, auxForScanr(_C), _D, _E).

'$$apply_1'(scanr1, _A, scanr1(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanr1(_B), _C, _D):-
        unifyHnfs(_A, scanr1, _C, _D).

'$$apply_1'(take, _A, take(_A), _B, _B).
'$$apply_1_var'(_A, _B, take(_B), _C, _D):-
        unifyHnfs(_A, take, _C, _D).

'$$apply_1'(drop, _A, drop(_A), _B, _B).
'$$apply_1_var'(_A, _B, drop(_B), _C, _D):-
        unifyHnfs(_A, drop, _C, _D).

'$$apply_1'(splitAt, _A, splitAt(_A), _B, _B).
'$$apply_1_var'(_A, _B, splitAt(_B), _C, _D):-
        unifyHnfs(_A, splitAt, _C, _D).

'$$apply_1'(auxForSplitAt, _A, auxForSplitAt(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForSplitAt(_B), _C, _D):-
        unifyHnfs(_A, auxForSplitAt, _C, _D).

'$$apply_1'(takeWhile, _A, takeWhile(_A), _B, _B).
'$$apply_1_var'(_A, _B, takeWhile(_B), _C, _D):-
        unifyHnfs(_A, takeWhile, _C, _D).

'$$apply_1'(takeUntil, _A, takeUntil(_A), _B, _B).
'$$apply_1_var'(_A, _B, takeUntil(_B), _C, _D):-
        unifyHnfs(_A, takeUntil, _C, _D).

'$$apply_1'(dropWhile, _A, dropWhile(_A), _B, _B).
'$$apply_1_var'(_A, _B, dropWhile(_B), _C, _D):-
        unifyHnfs(_A, dropWhile, _C, _D).

'$$apply_1'(span, _A, span(_A), _B, _B).
'$$apply_1_var'(_A, _B, span(_B), _C, _D):-
        unifyHnfs(_A, span, _C, _D).

'$$apply_1'(auxForSpan, _A, auxForSpan(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForSpan(_B), _C, _D):-
        unifyHnfs(_A, auxForSpan, _C, _D).

'$$apply_1'(zipWith, _A, zipWith(_A), _B, _B).
'$$apply_1_var'(_A, _B, zipWith(_B), _C, _D):-
        unifyHnfs(_A, zipWith, _C, _D).

'$$apply_1'(zipWith(_A), _B, zipWith(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, zipWith(_C, _B), _D, _E):-
        unifyHnfs(_A, zipWith(_C), _D, _E).

'$$apply_1'(zip, _A, zip(_A), _B, _B).
'$$apply_1_var'(_A, _B, zip(_B), _C, _D):-
        unifyHnfs(_A, zip, _C, _D).

'$$apply_1'(mkpair, _A, mkpair(_A), _B, _B).
'$$apply_1_var'(_A, _B, mkpair(_B), _C, _D):-
        unifyHnfs(_A, mkpair, _C, _D).

'$$apply_1'(auxForUnzip, _A, auxForUnzip(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForUnzip(_B), _C, _D):-
        unifyHnfs(_A, auxForUnzip, _C, _D).

'$$apply_1'(auxForUnzip(_A), _B, auxForUnzip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, auxForUnzip(_C, _B), _D, _E):-
        unifyHnfs(_A, auxForUnzip(_C), _D, _E).

'$$apply_1'(until, _A, until(_A), _B, _B).
'$$apply_1_var'(_A, _B, until(_B), _C, _D):-
        unifyHnfs(_A, until, _C, _D).

'$$apply_1'(until(_A), _B, until(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, until(_C, _B), _D, _E):-
        unifyHnfs(_A, until(_C), _D, _E).

'$$apply_1'('until\'', _A, 'until\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'until\''(_B), _C, _D):-
        unifyHnfs(_A, 'until\'', _C, _D).

'$$apply_1'(const, _A, const(_A), _B, _B).
'$$apply_1_var'(_A, _B, const(_B), _C, _D):-
        unifyHnfs(_A, const, _C, _D).

'$$apply_1'(//, _A, //(_A), _B, _B).
'$$apply_1_var'(_A, _B, //(_B), _C, _D):-
        unifyHnfs(_A, //, _C, _D).

'$$apply_1'(curry, _A, curry(_A), _B, _B).
'$$apply_1_var'(_A, _B, curry(_B), _C, _D):-
        unifyHnfs(_A, curry, _C, _D).

'$$apply_1'(curry(_A), _B, curry(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, curry(_C, _B), _D, _E):-
        unifyHnfs(_A, curry(_C), _D, _E).

'$$apply_1'(uncurry, _A, uncurry(_A), _B, _B).
'$$apply_1_var'(_A, _B, uncurry(_B), _C, _D):-
        unifyHnfs(_A, uncurry, _C, _D).

'$$apply_1'(lcm, _A, lcm(_A), _B, _B).
'$$apply_1_var'(_A, _B, lcm(_B), _C, _D):-
        unifyHnfs(_A, lcm, _C, _D).

'$$apply_1'(auxForTranspose, _A, auxForTranspose(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForTranspose(_B), _C, _D):-
        unifyHnfs(_A, auxForTranspose, _C, _D).

'$$apply_1'(del, _A, del(_A), _B, _B).
'$$apply_1_var'(_A, _B, del(_B), _C, _D):-
        unifyHnfs(_A, del, _C, _D).

% parcial aplictions of prims

'$$apply_1'(evalfd, _A, evalfd(_A), _B, _B).
'$$apply_1_var'(_A, _B, evalfd(_B), _C, _D):-
        unifyHnfs(_A, evalfd, _C, _D).

'$$apply_1'(+, _A, +(_A), _B, _B).
'$$apply_1_var'(_A, _B, +(_B), _C, _D):-
        unifyHnfs(_A, +, _C, _D).

'$$apply_1'(-, _A, -(_A), _B, _B).
'$$apply_1_var'(_A, _B, -(_B), _C, _D):-
        unifyHnfs(_A, -, _C, _D).

'$$apply_1'(*, _A, *(_A), _B, _B).
'$$apply_1_var'(_A, _B, *(_B), _C, _D):-
        unifyHnfs(_A, *, _C, _D).

'$$apply_1'(min, _A, min(_A), _B, _B).
'$$apply_1_var'(_A, _B, min(_B), _C, _D):-
        unifyHnfs(_A, min, _C, _D).

'$$apply_1'(max, _A, max(_A), _B, _B).
'$$apply_1_var'(_A, _B, max(_B), _C, _D):-
        unifyHnfs(_A, max, _C, _D).

'$$apply_1'(/, _A, /(_A), _B, _B).
'$$apply_1_var'(_A, _B, /(_B), _C, _D):-
        unifyHnfs(_A, /, _C, _D).

'$$apply_1'(**, _A, **(_A), _B, _B).
'$$apply_1_var'(_A, _B, **(_B), _C, _D):-
        unifyHnfs(_A, **, _C, _D).

'$$apply_1'(log, _A, log(_A), _B, _B).
'$$apply_1_var'(_A, _B, log(_B), _C, _D):-
        unifyHnfs(_A, log, _C, _D).

'$$apply_1'(^, _A, ^(_A), _B, _B).
'$$apply_1_var'(_A, _B, ^(_B), _C, _D):-
        unifyHnfs(_A, ^, _C, _D).

'$$apply_1'(div, _A, div(_A), _B, _B).
'$$apply_1_var'(_A, _B, div(_B), _C, _D):-
        unifyHnfs(_A, div, _C, _D).

'$$apply_1'(mod, _A, mod(_A), _B, _B).
'$$apply_1_var'(_A, _B, mod(_B), _C, _D):-
        unifyHnfs(_A, mod, _C, _D).

'$$apply_1'(gcd, _A, gcd(_A), _B, _B).
'$$apply_1_var'(_A, _B, gcd(_B), _C, _D):-
        unifyHnfs(_A, gcd, _C, _D).

'$$apply_1'(<, _A, <(_A), _B, _B).
'$$apply_1_var'(_A, _B, <(_B), _C, _D):-
        unifyHnfs(_A, <, _C, _D).

'$$apply_1'(<=, _A, <=(_A), _B, _B).
'$$apply_1_var'(_A, _B, <=(_B), _C, _D):-
        unifyHnfs(_A, <=, _C, _D).

'$$apply_1'(>, _A, >(_A), _B, _B).
'$$apply_1_var'(_A, _B, >(_B), _C, _D):-
        unifyHnfs(_A, >, _C, _D).

'$$apply_1'(>=, _A, >=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >=(_B), _C, _D):-
        unifyHnfs(_A, >=, _C, _D).

'$$apply_1'(==, _A, ==(_A), _B, _B).
'$$apply_1_var'(_A, _B, ==(_B), _C, _D):-
        unifyHnfs(_A, ==, _C, _D).

'$$apply_1'(/=, _A, /=(_A), _B, _B).
'$$apply_1_var'(_A, _B, /=(_B), _C, _D):-
        unifyHnfs(_A, /=, _C, _D).

'$$apply_1'(>>, _A, >>(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>(_B), _C, _D):-
        unifyHnfs(_A, >>, _C, _D).

'$$apply_1'(>>=, _A, >>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>=(_B), _C, _D):-
        unifyHnfs(_A, >>=, _C, _D).

'$$apply_1'(cont2, _A, cont2(_A), _B, _B).
'$$apply_1_var'(_A, _B, cont2(_B), _C, _D):-
        unifyHnfs(_A, cont2, _C, _D).

'$$apply_1'(writeFile, _A, writeFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeFile(_B), _C, _D):-
        unifyHnfs(_A, writeFile, _C, _D).

'$$apply_1'(selectWhereVariableXi, _A, selectWhereVariableXi(_A), _B, _B).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_B), _C, _D):-
        unifyHnfs(_A, selectWhereVariableXi, _C, _D).

'$$apply_1'(selectWhereVariableXi(_A), _B, selectWhereVariableXi(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _B), _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_C), _D, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B), _C, selectWhereVariableXi(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, selectWhereVariableXi(_C, _D), _E, _F).

'$$apply_1'(collectN, _A, collectN(_A), _B, _B).
'$$apply_1_var'(_A, _B, collectN(_B), _C, _D):-
        unifyHnfs(_A, collectN, _C, _D).

'$$apply_1'(if_then_else, _A, if_then_else(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then_else(_B), _C, _D):-
        unifyHnfs(_A, if_then_else, _C, _D).

'$$apply_1'(if_then_else(_A), _B, if_then_else(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, if_then_else(_C, _B), _D, _E):-
        unifyHnfs(_A, if_then_else(_C), _D, _E).

'$$apply_1'(if_then, _A, if_then(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then(_B), _C, _D):-
        unifyHnfs(_A, if_then, _C, _D).

'$$apply_1'(flip, _A, flip(_A), _B, _B).
'$$apply_1_var'(_A, _B, flip(_B), _C, _D):-
        unifyHnfs(_A, flip, _C, _D).

'$$apply_1'(flip(_A), _B, flip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, flip(_C, _B), _D, _E):-
        unifyHnfs(_A, flip(_C), _D, _E).

% functions

'$$apply_1'('$eqFun'(_A), _B, _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$eqFun'(_F), _D, _G),
        '$$eqFun'(_F, _B, _C, _G, _E).

'$$apply_1'('$notEqFun'(_A), _B, _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$notEqFun'(_F), _D, _G),
        '$$notEqFun'(_F, _B, _C, _G, _E).

'$$apply_1'(and(_A), _B, _C, _D, _E):-
        '$and'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, and(_F), _D, _G),
        '$and'(_F, _B, _C, _G, _E).

'$$apply_1'(or(_A), _B, _C, _D, _E):-
        '$or'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, or(_F), _D, _G),
        '$or'(_F, _B, _C, _G, _E).

'$$apply_1'(/\(_A), _B, _C, _D, _E):-
        $/\(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /\(_F), _D, _G),
        $/\(_F, _B, _C, _G, _E).

'$$apply_1'(\/(_A), _B, _C, _D, _E):-
        $\/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, \/(_F), _D, _G),
        $\/(_F, _B, _C, _G, _E).

'$$apply_1'(not, _A, _B, _C, _D):-
        '$not'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, not, _D, _F),
        '$not'(_B, _C, _F, _E).

'$$apply_1'(any, _A, _B, _C, _D):-
        '$any'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, any, _D, _F),
        '$any'(_B, _C, _F, _E).

'$$apply_1'('any\'', _A, _B, _C, _D):-
        '$any\''(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'any\'', _D, _F),
        '$any\''(_B, _C, _F, _E).

'$$apply_1'(all, _A, _B, _C, _D):-
        '$all'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, all, _D, _F),
        '$all'(_B, _C, _F, _E).

'$$apply_1'(def, _A, _B, _C, _D):-
        '$def'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, def, _D, _F),
        '$def'(_B, _C, _F, _E).

'$$apply_1'(not_undef, _A, _B, _C, _D):-
        '$not_undef'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, not_undef, _D, _F),
        '$not_undef'(_B, _C, _F, _E).

'$$apply_1'(nf, _A, _B, _C, _D):-
        '$nf'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, nf, _D, _F),
        '$nf'(_B, _C, _F, _E).

'$$apply_1'(hnf, _A, _B, _C, _D):-
        '$hnf'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, hnf, _D, _F),
        '$hnf'(_B, _C, _F, _E).

'$$apply_1'(strict(_A), _B, _C, _D, _E):-
        '$strict'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, strict(_F), _D, _G),
        '$strict'(_F, _B, _C, _G, _E).

'$$apply_1'('strict\''(_A), _B, _C, _D, _E):-
        '$strict\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'strict\''(_F), _D, _G),
        '$strict\''(_F, _B, _C, _G, _E).

'$$apply_1'(map(_A), _B, _C, _D, _E):-
        '$map'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, map(_F), _D, _G),
        '$map'(_F, _B, _C, _G, _E).

'$$apply_1'('.'(_A, _B), _C, _D, _E, _F):-
        $.(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '.'(_F, _G), _D, _H),
        $.(_F, _G, _B, _C, _H, _E).

'$$apply_1'(++(_A), _B, _C, _D, _E):-
        $++(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ++(_F), _D, _G),
        $++(_F, _B, _C, _G, _E).

'$$apply_1'('!!'(_A), _B, _C, _D, _E):-
        '$!!'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '!!'(_F), _D, _G),
        '$!!'(_F, _B, _C, _G, _E).

'$$apply_1'(iterate(_A), _B, _C, _D, _E):-
        '$iterate'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, iterate(_F), _D, _G),
        '$iterate'(_F, _B, _C, _G, _E).

'$$apply_1'(repeat, _A, _B, _C, _D):-
        '$repeat'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, repeat, _D, _F),
        '$repeat'(_B, _C, _F, _E).

'$$apply_1'(copy(_A), _B, _C, _D, _E):-
        '$copy'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, copy(_F), _D, _G),
        '$copy'(_F, _B, _C, _G, _E).

'$$apply_1'(filter(_A), _B, _C, _D, _E):-
        '$filter'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, filter(_F), _D, _G),
        '$filter'(_F, _B, _C, _G, _E).

'$$apply_1'(foldl(_A, _B), _C, _D, _E, _F):-
        '$foldl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldl(_F, _G), _D, _H),
        '$foldl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldl1(_A), _B, _C, _D, _E):-
        '$foldl1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldl1(_F), _D, _G),
        '$foldl1'(_F, _B, _C, _G, _E).

'$$apply_1'('foldl\''(_A, _B), _C, _D, _E, _F):-
        '$foldl\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'foldl\''(_F, _G), _D, _H),
        '$foldl\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanl(_A, _B), _C, _D, _E, _F):-
        '$scanl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanl(_F, _G), _D, _H),
        '$scanl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanl1(_A), _B, _C, _D, _E):-
        '$scanl1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanl1(_F), _D, _G),
        '$scanl1'(_F, _B, _C, _G, _E).

'$$apply_1'('scanl\''(_A, _B), _C, _D, _E, _F):-
        '$scanl\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'scanl\''(_F, _G), _D, _H),
        '$scanl\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldr(_A, _B), _C, _D, _E, _F):-
        '$foldr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldr(_F, _G), _D, _H),
        '$foldr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldr1(_A), _B, _C, _D, _E):-
        '$foldr1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldr1(_F), _D, _G),
        '$foldr1'(_F, _B, _C, _G, _E).

'$$apply_1'(scanr(_A, _B), _C, _D, _E, _F):-
        '$scanr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanr(_F, _G), _D, _H),
        '$scanr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(auxForScanr(_A, _B), _C, _D, _E, _F):-
        '$auxForScanr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForScanr(_F, _G), _D, _H),
        '$auxForScanr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanr1(_A), _B, _C, _D, _E):-
        '$scanr1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanr1(_F), _D, _G),
        '$scanr1'(_F, _B, _C, _G, _E).

'$$apply_1'(take(_A), _B, _C, _D, _E):-
        '$take'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, take(_F), _D, _G),
        '$take'(_F, _B, _C, _G, _E).

'$$apply_1'(drop(_A), _B, _C, _D, _E):-
        '$drop'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, drop(_F), _D, _G),
        '$drop'(_F, _B, _C, _G, _E).

'$$apply_1'(splitAt(_A), _B, _C, _D, _E):-
        '$splitAt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, splitAt(_F), _D, _G),
        '$splitAt'(_F, _B, _C, _G, _E).

'$$apply_1'(auxForSplitAt(_A), _B, _C, _D, _E):-
        '$auxForSplitAt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForSplitAt(_F), _D, _G),
        '$auxForSplitAt'(_F, _B, _C, _G, _E).

'$$apply_1'(takeWhile(_A), _B, _C, _D, _E):-
        '$takeWhile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, takeWhile(_F), _D, _G),
        '$takeWhile'(_F, _B, _C, _G, _E).

'$$apply_1'(takeUntil(_A), _B, _C, _D, _E):-
        '$takeUntil'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, takeUntil(_F), _D, _G),
        '$takeUntil'(_F, _B, _C, _G, _E).

'$$apply_1'(dropWhile(_A), _B, _C, _D, _E):-
        '$dropWhile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dropWhile(_F), _D, _G),
        '$dropWhile'(_F, _B, _C, _G, _E).

'$$apply_1'(span(_A), _B, _C, _D, _E):-
        '$span'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, span(_F), _D, _G),
        '$span'(_F, _B, _C, _G, _E).

'$$apply_1'(auxForSpan(_A), _B, _C, _D, _E):-
        '$auxForSpan'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForSpan(_F), _D, _G),
        '$auxForSpan'(_F, _B, _C, _G, _E).

'$$apply_1'(break, _A, _B, _C, _D):-
        '$break'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, break, _D, _F),
        '$break'(_B, _C, _F, _E).

'$$apply_1'(zipWith(_A, _B), _C, _D, _E, _F):-
        '$zipWith'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, zipWith(_F, _G), _D, _H),
        '$zipWith'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(zip(_A), _B, _C, _D, _E):-
        '$zip'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, zip(_F), _D, _G),
        '$zip'(_F, _B, _C, _G, _E).

'$$apply_1'(mkpair(_A), _B, _C, _D, _E):-
        '$mkpair'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mkpair(_F), _D, _G),
        '$mkpair'(_F, _B, _C, _G, _E).

'$$apply_1'(unzip, _A, _B, _C, _D):-
        '$unzip'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, unzip, _D, _F),
        '$unzip'(_B, _C, _F, _E).

'$$apply_1'(auxForUnzip(_A, _B), _C, _D, _E, _F):-
        '$auxForUnzip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForUnzip(_F, _G), _D, _H),
        '$auxForUnzip'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(until(_A, _B), _C, _D, _E, _F):-
        '$until'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, until(_F, _G), _D, _H),
        '$until'(_F, _G, _B, _C, _H, _E).

'$$apply_1'('until\''(_A), _B, _C, _D, _E):-
        '$until\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'until\''(_F), _D, _G),
        '$until\''(_F, _B, _C, _G, _E).

'$$apply_1'(const(_A), _B, _C, _D, _E):-
        '$const'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, const(_F), _D, _G),
        '$const'(_F, _B, _C, _G, _E).

'$$apply_1'(id, _A, _B, _C, _D):-
        '$id'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, id, _D, _F),
        '$id'(_B, _C, _F, _E).

'$$apply_1'(//(_A), _B, _C, _D, _E):-
        $//(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, //(_F), _D, _G),
        $//(_F, _B, _C, _G, _E).

'$$apply_1'(curry(_A, _B), _C, _D, _E, _F):-
        '$curry'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, curry(_F, _G), _D, _H),
        '$curry'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(uncurry(_A), _B, _C, _D, _E):-
        '$uncurry'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uncurry(_F), _D, _G),
        '$uncurry'(_F, _B, _C, _G, _E).

'$$apply_1'(fst, _A, _B, _C, _D):-
        '$fst'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fst, _D, _F),
        '$fst'(_B, _C, _F, _E).

'$$apply_1'(snd, _A, _B, _C, _D):-
        '$snd'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, snd, _D, _F),
        '$snd'(_B, _C, _F, _E).

'$$apply_1'(fst3, _A, _B, _C, _D):-
        '$fst3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fst3, _D, _F),
        '$fst3'(_B, _C, _F, _E).

'$$apply_1'(snd3, _A, _B, _C, _D):-
        '$snd3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, snd3, _D, _F),
        '$snd3'(_B, _C, _F, _E).

'$$apply_1'(thd3, _A, _B, _C, _D):-
        '$thd3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, thd3, _D, _F),
        '$thd3'(_B, _C, _F, _E).

'$$apply_1'(even, _A, _B, _C, _D):-
        '$even'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, even, _D, _F),
        '$even'(_B, _C, _F, _E).

'$$apply_1'(lcm(_A), _B, _C, _D, _E):-
        '$lcm'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, lcm(_F), _D, _G),
        '$lcm'(_F, _B, _C, _G, _E).

'$$apply_1'(head, _A, _B, _C, _D):-
        '$head'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, head, _D, _F),
        '$head'(_B, _C, _F, _E).

'$$apply_1'(last, _A, _B, _C, _D):-
        '$last'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, last, _D, _F),
        '$last'(_B, _C, _F, _E).

'$$apply_1'(tail, _A, _B, _C, _D):-
        '$tail'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tail, _D, _F),
        '$tail'(_B, _C, _F, _E).

'$$apply_1'(init, _A, _B, _C, _D):-
        '$init'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, init, _D, _F),
        '$init'(_B, _C, _F, _E).

'$$apply_1'(nub, _A, _B, _C, _D):-
        '$nub'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, nub, _D, _F),
        '$nub'(_B, _C, _F, _E).

'$$apply_1'(length, _A, _B, _C, _D):-
        '$length'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, length, _D, _F),
        '$length'(_B, _C, _F, _E).

'$$apply_1'(auxForTranspose(_A), _B, _C, _D, _E):-
        '$auxForTranspose'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForTranspose(_F), _D, _G),
        '$auxForTranspose'(_F, _B, _C, _G, _E).

'$$apply_1'(del(_A), _B, _C, _D, _E):-
        '$del'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, del(_F), _D, _G),
        '$del'(_F, _B, _C, _G, _E).

'$$apply_1'(parse, _A, _B, _C, _D):-
        '$parse'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, parse, _D, _F),
        '$parse'(_B, _C, _F, _E).

% primitives

'$$apply_1'(uminus, _A, _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uminus, _D, _F),
        '$uminus'(_B, _C, _F, _E).

'$$apply_1'(abs, _A, _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, abs, _D, _F),
        '$abs'(_B, _C, _F, _E).

'$$apply_1'(sqrt, _A, _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sqrt, _D, _F),
        '$sqrt'(_B, _C, _F, _E).

'$$apply_1'(ln, _A, _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ln, _D, _F),
        '$ln'(_B, _C, _F, _E).

'$$apply_1'(exp, _A, _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exp, _D, _F),
        '$exp'(_B, _C, _F, _E).

'$$apply_1'(sin, _A, _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sin, _D, _F),
        '$sin'(_B, _C, _F, _E).

'$$apply_1'(cos, _A, _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cos, _D, _F),
        '$cos'(_B, _C, _F, _E).

'$$apply_1'(tan, _A, _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tan, _D, _F),
        '$tan'(_B, _C, _F, _E).

'$$apply_1'(cot, _A, _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cot, _D, _F),
        '$cot'(_B, _C, _F, _E).

'$$apply_1'(asin, _A, _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asin, _D, _F),
        '$asin'(_B, _C, _F, _E).

'$$apply_1'(acos, _A, _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acos, _D, _F),
        '$acos'(_B, _C, _F, _E).

'$$apply_1'(atan, _A, _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atan, _D, _F),
        '$atan'(_B, _C, _F, _E).

'$$apply_1'(acot, _A, _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acot, _D, _F),
        '$acot'(_B, _C, _F, _E).

'$$apply_1'(sinh, _A, _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sinh, _D, _F),
        '$sinh'(_B, _C, _F, _E).

'$$apply_1'(cosh, _A, _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cosh, _D, _F),
        '$cosh'(_B, _C, _F, _E).

'$$apply_1'(tanh, _A, _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tanh, _D, _F),
        '$tanh'(_B, _C, _F, _E).

'$$apply_1'(coth, _A, _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, coth, _D, _F),
        '$coth'(_B, _C, _F, _E).

'$$apply_1'(asinh, _A, _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asinh, _D, _F),
        '$asinh'(_B, _C, _F, _E).

'$$apply_1'(acosh, _A, _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acosh, _D, _F),
        '$acosh'(_B, _C, _F, _E).

'$$apply_1'(atanh, _A, _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atanh, _D, _F),
        '$atanh'(_B, _C, _F, _E).

'$$apply_1'(acoth, _A, _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acoth, _D, _F),
        '$acoth'(_B, _C, _F, _E).

'$$apply_1'(evalfd(_A), _B, _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, evalfd(_F), _D, _G),
        '$evalfd'(_F, _B, _C, _G, _E).

'$$apply_1'(+(_A), _B, _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, +(_F), _D, _G),
        $+(_F, _B, _C, _G, _E).

'$$apply_1'(-(_A), _B, _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, -(_F), _D, _G),
        $-(_F, _B, _C, _G, _E).

'$$apply_1'(*(_A), _B, _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, *(_F), _D, _G),
        $*(_F, _B, _C, _G, _E).

'$$apply_1'(min(_A), _B, _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, min(_F), _D, _G),
        '$min'(_F, _B, _C, _G, _E).

'$$apply_1'(max(_A), _B, _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, max(_F), _D, _G),
        '$max'(_F, _B, _C, _G, _E).

'$$apply_1'(/(_A), _B, _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /(_F), _D, _G),
        $/(_F, _B, _C, _G, _E).

'$$apply_1'(**(_A), _B, _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, **(_F), _D, _G),
        $**(_F, _B, _C, _G, _E).

'$$apply_1'(log(_A), _B, _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, log(_F), _D, _G),
        '$log'(_F, _B, _C, _G, _E).

'$$apply_1'(^(_A), _B, _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ^(_F), _D, _G),
        $^(_F, _B, _C, _G, _E).

'$$apply_1'(div(_A), _B, _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, div(_F), _D, _G),
        '$div'(_F, _B, _C, _G, _E).

'$$apply_1'(mod(_A), _B, _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mod(_F), _D, _G),
        '$mod'(_F, _B, _C, _G, _E).

'$$apply_1'(gcd(_A), _B, _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, gcd(_F), _D, _G),
        '$gcd'(_F, _B, _C, _G, _E).

'$$apply_1'(round, _A, _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, round, _D, _F),
        '$round'(_B, _C, _F, _E).

'$$apply_1'(trunc, _A, _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trunc, _D, _F),
        '$trunc'(_B, _C, _F, _E).

'$$apply_1'(floor, _A, _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, floor, _D, _F),
        '$floor'(_B, _C, _F, _E).

'$$apply_1'(ceiling, _A, _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ceiling, _D, _F),
        '$ceiling'(_B, _C, _F, _E).

'$$apply_1'(toReal, _A, _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, toReal, _D, _F),
        '$toReal'(_B, _C, _F, _E).

'$$apply_1'(<(_A), _B, _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <(_F), _D, _G),
        $<(_F, _B, _C, _G, _E).

'$$apply_1'(<=(_A), _B, _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <=(_F), _D, _G),
        $<=(_F, _B, _C, _G, _E).

'$$apply_1'(>(_A), _B, _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >(_F), _D, _G),
        $>(_F, _B, _C, _G, _E).

'$$apply_1'(>=(_A), _B, _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >=(_F), _D, _G),
        $>=(_F, _B, _C, _G, _E).

'$$apply_1'(==(_A), _B, _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ==(_F), _D, _G),
        $==(_F, _B, _C, _G, _E).

'$$apply_1'(/=(_A), _B, _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /=(_F), _D, _G),
        $/=(_F, _B, _C, _G, _E).

'$$apply_1'(ord, _A, _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ord, _D, _F),
        '$ord'(_B, _C, _F, _E).

'$$apply_1'(chr, _A, _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, chr, _D, _F),
        '$chr'(_B, _C, _F, _E).

'$$apply_1'(putChar, _A, _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putChar, _D, _F),
        '$putChar'(_B, _C, _F, _E).

'$$apply_1'(return, _A, _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, return, _D, _F),
        '$return'(_B, _C, _F, _E).

'$$apply_1'(>>(_A), _B, _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>(_F), _D, _G),
        $>>(_F, _B, _C, _G, _E).

'$$apply_1'(>>=(_A), _B, _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>=(_F), _D, _G),
        $>>=(_F, _B, _C, _G, _E).

'$$apply_1'(putStr, _A, _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStr, _D, _F),
        '$putStr'(_B, _C, _F, _E).

'$$apply_1'(putStrLn, _A, _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLn, _D, _F),
        '$putStrLn'(_B, _C, _F, _E).

'$$apply_1'(cont1, _A, _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont1, _D, _F),
        '$cont1'(_B, _C, _F, _E).

'$$apply_1'(cont2(_A), _B, _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont2(_F), _D, _G),
        '$cont2'(_F, _B, _C, _G, _E).

'$$apply_1'(writeFile(_A), _B, _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeFile(_F), _D, _G),
        '$writeFile'(_F, _B, _C, _G, _E).

'$$apply_1'(readFile, _A, _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFile, _D, _F),
        '$readFile'(_B, _C, _F, _E).

'$$apply_1'(readFileContents, _A, _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFileContents, _D, _F),
        '$readFileContents'(_B, _C, _F, _E).

'$$apply_1'(dVal, _A, _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dVal, _D, _F),
        '$dVal'(_B, _C, _F, _E).

'$$apply_1'(dValToString, _A, _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dValToString, _D, _F),
        '$dValToString'(_B, _C, _F, _E).

'$$apply_1'(getConstraintStore, _A, _B, _C, _D):-
        '$getConstraintStore'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getConstraintStore, _D, _F),
        '$getConstraintStore'(_B, _C, _F, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B, _C), _D, _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_F, _G, _H), _D, _I),
        '$selectWhereVariableXi'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(fails, _A, _B, _C, _D):-
        '$fails'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fails, _D, _F),
        '$fails'(_B, _C, _F, _E).

'$$apply_1'(once, _A, _B, _C, _D):-
        '$once'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, once, _D, _F),
        '$once'(_B, _C, _F, _E).

'$$apply_1'(collect, _A, _B, _C, _D):-
        '$collect'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, collect, _D, _F),
        '$collect'(_B, _C, _F, _E).

'$$apply_1'(collectN(_A), _B, _C, _D, _E):-
        '$collectN'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, collectN(_F), _D, _G),
        '$collectN'(_F, _B, _C, _G, _E).

'$$apply_1'(if_then_else(_A, _B), _C, _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then_else(_F, _G), _D, _H),
        '$if_then_else'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(if_then(_A), _B, _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then(_F), _D, _G),
        '$if_then'(_F, _B, _C, _G, _E).

'$$apply_1'(flip(_A, _B), _C, _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, flip(_F, _G), _D, _H),
        '$flip'(_F, _G, _B, _C, _H, _E).


/************   CODE FOR INFIX OPERATORS   ************/

infix('!!', left, 90).
infix('.', right, 90).
infix(++, right, 50).
infix(//, right, 40).
infix(and, right, 40).
infix(/\, right, 40).
infix(or, right, 30).
infix(\/, right, 30).
infix(\\, noasoc, 50).
infix(^, noasoc, 98).
infix(**, noasoc, 98).
infix(/, left, 90).
infix(*, right, 90).
infix(+, left, 50).
infix(-, left, 50).
infix(<, noasoc, 30).
infix(<=, noasoc, 30).
infix(>, noasoc, 30).
infix(>=, noasoc, 30).
infix(==, noasoc, 10).
infix(/=, noasoc, 10).
infix(>>, left, 11).
infix(>>=, left, 11).



'$flip'(F, A1, A2, H, Cin, Cout):-         '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).