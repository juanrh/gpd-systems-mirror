
%---------------------------------------------------------------------------%
% pVal.pl
%---------------------------------------------------------------------------%
/*
- Author: mercedes

- Description: es el modulo encargado del predicado pVal para la depuracion
- Modules which import it:.

- Imported modules:
    > .

- Modified: 09/08/01 rafa: Adaptado para que devuelva el nuevo tipo de datos
                           pVal


*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(pVal,[atomToPVal/3, atomToString/3, pValToPrologString/2,atomToPrologString/3,
                nextVarName/1,prologStringToToyString/3,exprToTerm/2,dValProlog/2,toyStringToList/2,
        listAtomsToString/2,simpleValue/2,constraintToPrologString/2,putName/2,variableName/2]).

:- load_files(dyn,[if(changed),
                   imports([latestNameVar/1,assertlatestNameVar/1,
                        retractlatestNameVar/1, getTot/1])]).

:- load_files(writing,[if(changed),imports([extractName/2, isOpInfix/3])]).

:- load_files(tools,[if(changed),imports([append/3,concatLsts/2,member/2])]).

:- load_files(toycomm,[if(changed),imports([hnf/4])]).

:- load_files(errortoy,[if(changed),imports([isVariable/1])]).

% rafa 19-11-04 I will use the attributes library
 :- use_module(library(atts)).
:- attribute name/1.


%%%% verify_attributes/3 is required by the attributes sicstus specification
%%%% it is called when trying to unify a variable with attributes
%%%% in our case we simply fail because the only variables with attributes are those of the initial
%%%% which must not be unified.
verify_attributes(_Var,_Other,_Goals) :- fail.


%----------------------------------------------------------------------------%
% atomToString(+Mode, +ExprToy, -String)
% Si Mode=varToString
% convierte una expresion toy en una cadena de caracteres, renombrando las
% variables.
% Si Mode=varToPVal
% Convierte una expresion toy en una lista de cadena de caracteres,
% donde las variables X aparecen como pVal(X) con el formato:
% '$concat' ["f ", pVal(X), ......]
%----------------------------------------------------------------------------%

% Depu 05/12/00  mercedes
% La lista vacia se traduce de forma especial, como "[]", en lugar de como ""
atomToString(Mode, Expr, String) :-
    Expr == [],
    !,
    prologStringToToyString(Mode," []",String).


atomToString(Mode, Expr, String) :-
    !,
    atomToPrologString(Mode,Expr,PrologString),
    prologStringToToyString(Mode,PrologString, String).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% dValProlog
%
% Funcionamiento de dVal cuando se est� generando el �rbol para DDT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


dValProlog(A,A) :- atom(A), !.

% rafa 18-11-04: Las variables devuelven nombres que se generan autom�ticamente
dValProlog(V,Name) :-
    var(V),
    variableName(V,Name).

% variables convertidas en constantes para que no se instancien en la depuracion
dValProlog(pValVar(Name), Name2) :- toyStringToList(Name,Name2).

dValProlog('$$susp'(_Name,_Args,Result,Evaluated),Value):-
   (var(Evaluated),
    % no esta evaluada
    Value = pValBottom
   ;
    % si esta evaluada, convertimos a pVal el resultado
    dValProlog(Result,Value)
   ),!.


% estructuras
dValProlog(T,Value) :-
    !,
    T =.. [F|Args],
        mapdValProlog(Args,LValues),
    Value =.. [F|LValues].

mapdValProlog([],[]).
mapdValProlog([X|Xs],[Y|Ys]) :-
    dValProlog(X,Y),
    mapdValProlog(Xs,Ys).


%%%%%%%%%%%%%%%%%%%%%%
% putName(?V,+N) changes the attribute of V to be N
%putName(V,N) :-  get_atts(V,name(Name)),  !.
putName(V,N) :- put_atts(V,name(N)).

%%%%%%%%%%%%%%%%%%%%%%5
% variableName(+V,-Name)
% Returns a name associated to the Prolog Variable V
% If a name already exists for the variable it is returned, otherwise a new name
% is created. Name will be a Prolog list
variableName(V,Name) :-
    get_atts(V,name(Name)), % is there a name attribute already?
    !.

     
variableName(V,Name) :- % no name attribute yet
    !,
    nextVarName(Name), % generate a new name
    % store the last name used in the B.D. deleting the old one
    (
     retractlatestNameVar(_)
    ;
     true
    ),
    assertlatestNameVar(Name),
    % store the variable associated to its name
    put_atts(V,name(Name)),
    !.


%----------------------------------------------------------------------------%
% atomToPVal(+Mode, +ExprToy, -pVal)
% Si Mode=varToString
% convierte una expresion toy en una expresion tipo pVal, renombrando las
% variables.
% Si Mode=varToPVal
% Convierte una expresion toy en una lista de cadena de caracteres,
% donde las variables X aparecen como pVal(X) con el formato:
% '$concat' ["f ", pVal(X), ......]
%----------------------------------------------------------------------------%

atomToPVal(varToString,Expr, Expr2) :- !, atomToPVal(Expr,Expr2).

% Posibles casos:
%   1.- Variables
%   2.- Tipos simples
%       3.- Suspensiones
%       4.- Functores


% 0
atomToPVal(A, pValVar(String)) :-
    A=='$var'(Name),
    !,
    prologStringToToyString(varToString,Name,String).

% 1.- Variables
% atomToPVal(Expr, pValVar(Name)) :-
atomToPVal(Expr, pValVar(Name)) :-
    var(Expr),
    variableName(Expr,PrologName),
    prologStringToToyString(varToString,PrologName,Name),
    !.

% variables convertidas en constantes para que no se instancien en la depuracion
atomToPVal(pValVar(Name), pValVar(Name)) :- !.


% 2.- Tipos simples

% char
atomToPVal('$char'(N),pValChar('$char'(N))):-
    !.
% numeros naturales; se distinguen porque al truncarlos se obtiene el mismo numero
atomToPVal(N,pValNum(String)):-
    number(N),
        N is truncate(N),
    !,
    Nat is integer(N),
    name(Nat,String1),
        prologStringToToyString(varToString,String1,String).


% n�meros reales
atomToPVal(N,pValNum(String)):-
    number(N),
    !,
    name(N,String1),
        prologStringToToyString(varToString,String1,String).

% 3 Suspensiones
atomToPVal('$$call'(Result,Evaluated),PVal):-
    !,
       atomToPVal('$$susp'(_Name,_Args,Result,Evaluated),PVal).

atomToPVal('$$susp'(_Name,_Args,Result,Evaluated),PVal):-
   (var(Evaluated),
    % no esta evaluada
    PVal = pValBottom
   ;
    % si esta evaluada, convertimos a pVal el resultado
    atomToPVal(Result,PVal)
   ),!.


% 4 aplicaciones

% 21/08/01 un caso especial de aplicaci�n es la tupla
atomToPVal('$$tup'(Tuple),pValApp(NameString,ArgsPVal)):-
        !,
        prologStringToToyString(varToString,"$$tup",NameString),
        tupleToList(Tuple,Args),
        listAtomToPVal(Args,ArgsPVal).


atomToPVal(T,pValApp(NameString,ArgsPVal)):-
    !,
    T =.. [F|Args],
        name(F, NameF),
        prologStringToToyString(varToString,NameF,NameString),
        listAtomToPVal(Args,ArgsPVal).

listAtomToPVal([],[]) :- !.
listAtomToPVal([X|Xs],':'(X2,Xs2)) :-
   !,
   atomToPVal(X,X2),
   listAtomToPVal(Xs,Xs2).

tupleToList((A,B),[A|Rst]) :-
    !,
    tupleToList(B,Rst).

tupleToList(A,[A]) :-
    !.

listToTuple(A:[],S) :-
    !,
         pValToPrologString(A,S).

listToTuple((A:B:R),(S,Rest)) :-
    !,
         pValToPrologString(A,S),
    listToTuple((B:R),Rest).


map(_F,[],[]) :- !.
map(F,[X|Xs],[XOut|XsOut]) :-
    !,
    Term =.. [F|[X,XOut]],
        call(Term),
        map(F,Xs,XsOut).


%----------------------------------------------------------------------------%
% prologStringToToyString(Mode,PrologString, String)
% convierte una lista de caracteres Prolog en una cadena de caracteres Toy,
%----------------------------------------------------------------------------%
prologStringToToyString(Mode,[], []):-
    !.

prologStringToToyString(varToString,[X|Xs], ':'('$char'(X), Xs2)) :-
    !,
    prologStringToToyString(varToString,Xs, Xs2).


prologStringToToyString(varToPVal,[X|Xs], '$concat'(LOut)) :-
    !,
    prologStringToConcatList([X|Xs],LOut).

prologStringToConcatList([],[]) :-
    !.

prologStringToConcatList([dValToString(X)|Xs],':'(dValToString(X),Xs2)) :-
    !,
    prologStringToConcatList(Xs,Xs2).

prologStringToConcatList([X|Xs],':'(':'('$char'(X),[]),Xs2)) :-
    !,
    prologStringToConcatList(Xs,Xs2).



%----------------------------------------------------------------------------%
% pValToPrologString(PVal, String)
% convierte un termino de tipo pVal en una cadena de caracteres prolog,
%----------------------------------------------------------------------------%
pValToPrologString(pValBottom, "_")     :- !.

pValToPrologString(pValChar('$char'(Ch)), [Ch]) :- !.

pValToPrologString(pValNum(Num), String) :- !,toyStringToList(Num,String).

pValToPrologString(pValVar(Var), String) :- !,toyStringToList(Var,String).

% las tuplas se tratan aparte
pValToPrologString(pValApp(Tup,List),String ) :-
        toyStringToList(Tup,"$$tup"),
    !,
        listToTuple(List,Tuple),
        atomToPrologString(varToString,'$$tup'(Tuple),String).


% las listas se tratan aparte
pValToPrologString(pValApp('$char'(91):'$char'(93):[],[])," []") :- !.

pValToPrologString(pValApp('$char'(58):[],Args), String):-
        !,
    listPValToToyString(pValApp('$char'(58):[],Args),ToyString),
        atomToPrologString(varToString,ToyString,String).


pValToPrologString(pValApp(Name,Args), String):-
    !,
        toyStringToList(Name,ListProlog),
        name(NameProlog,ListProlog),
        listPValToPrologString(Args,PrologArgs),
        Term =.. [NameProlog|PrologArgs],
        atomToPrologString(varToString,Term,String),
    !.

% la lista vacia se traduce por [] no por " []"
listPValToToyString(pValApp('$char'(91):'$char'(93):[],[]),[]) :- !.
listPValToToyString(pValApp('$char'(58):[],':'(Head,':'(Rest,[]))),
                     ':'(HeadProlog,RestProlog)) :-
        !,
    pValToPrologString(Head,HeadProlog),
    listPValToToyString(Rest,RestProlog).

listPValToToyString(pValBottom:[], pValBottom)     :- !.
listPValToToyString(pValBottom, pValBottom)     :- !.

listPValToToyString(Other, Result) :-
        !,
    pValToPrologString(Other,Result).


listPValToPrologString([],[]) :- !.
listPValToPrologString(':'(X,Xs),[X2|Xs2]) :-
    !,
        pValToPrologString(X,X2),
    listPValToPrologString(Xs,Xs2).

%----------------------------------------------------------------------------%
% nextVarName(-NameVar)
% devuelve nombre de variable aun no utilizado
%----------------------------------------------------------------------------%
nextVarName(NameVar) :-
    (
     % obtenemos el ultimo nombre de variable utilizado
     latestNameVar(LastNameVar),
     generateNewName(LastNameVar,NameVar)
    ;
     % si no hay ninguno empezamos por la "A"
     NameVar = "A"
    ),
    !.



%----------------------------------------------------------------------------%
% generateNewName(+LastNameVar,-NameVar)
% Genera un nuevo nombre de variable sabiendo que el ultimo fue LastNameVar
%----------------------------------------------------------------------------%
generateNewName(LastNameVar,NameVar) :-
    !,
    % convertimos LastNameVar a numero
    nameToNumber(LastNameVar, 0, Number),
    NewNumber is Number+1,
    extractName(NewNumber,NameVar).

%----------------------------------------------------------------------------%
% nameToNumber(+Name,+PartialNumber, -Number)
% Genera un numero a partir de una cadena de caracteres, segun el orden
% lexicografico
%----------------------------------------------------------------------------%
nameToNumber([],PartialNumber,PartialNumber):- !.
nameToNumber([X|Xs],PartialNumber,Number):-
    !,
    PartialNumber2  is PartialNumber*26 + (X-65),
    nameToNumber(Xs,PartialNumber2,Number).




%----------------------------------------------------------------------------%
% atomToPrologString(Mode,+ExprToy, -String)
% convierte una expresion toy en una cadena de caracteres, renombrando las
% variables
%----------------------------------------------------------------------------%
atomToPrologString(varToString,Expr, Name) :-
    var(Expr),
    % si es variable hacemos unificacion (Pacos idea)
    % para eso generamos un nuevo nombre de variable
    nextVarName(Name),
     Expr = '$var'(Name),
    % guardamos el nuevo nombre en la B.D. borrando el antiguo
    (
     retractlatestNameVar(_)
    ;
     true
    ),
    assertlatestNameVar(Name),
    !.

% variables sustituidas por constantes
atomToPrologString(varToString,pValVar(Name), Name3) :-
    !,
    listToString(varToString,Name,[R|Name2]),
        removeTail(Name2,Name3).


atomToPrologString(varToPVal,Var, [dValToString(Var)]) :-
    isVariable(Var),
    !.

atomToPrologString(Mode,pValBottom, "_") :-
    !.

atomToPrologString(Mode,[], " []") :-
    !.

atomToPrologString(Mode,[C|R],[C|R]):-
    !.

atomToPrologString(Mode,'$char'(N),[N]):-
    !.

atomToPrologString(varToPVal,'$int'(N),String):-
    !,
    name(N,String).

atomToPrologString(varToString,N,String):-
    number(N),
        N is truncate(N),
    !,
    Nat is integer(N),
    name(Nat,String).

atomToPrologString(varToString,'$$main',"$$main"):-
    !.

atomToPrologString(varToString,N,String):-
    atomic(N),
    !,
    name(N,String1),
    (
    concatLsts([[X|Xs],"$",Y],String1),
    String = [X|Xs]
    ;
        String = String1
     ),
     !.

%atomToPrologString(varToString,N,String):-
%   atomic(N),
%   !,
%   name(N,String).


atomToPrologString(varToPVal,'$float'(N),String):-
    !,
    name(N,String).



atomToPrologString(Mode,T,WhatEverString):-
    functor(T,Name,Ar),
    (

     % Nuestra constructora de listas ':', si la salida es a
     % pantalla se escribe como una lista prolog, si no como
     % una constructora mas
     (Name==':',Ar==2;Name='.'),
     !,
     listToString(Mode,T,WhatEverString)
    ;
     (Name=='$$tup';Name=='$$tuple'),
     !,
     tupleToString(Mode,T,WhatEverString)
%   ;
         % 01-08-01 rafa en el caso de una variable sustituida por una constante
%    T='$$varConstant'(NameVar),
%    !,
         % el unico argumento es el nombre de la var. en forma de string toy
%         toyStringToList(NameVar, WhatEverString)
    ;
     % Si la salida es a pantalla y es infijo lo escribimos como
     % infijo
     isOpInfix(Name,P,Asoc),
     !,
     atomInfixToString(Mode,T,Name,Ar,P,Asoc,WhatEverString)
    ;
     % En caso contrario lo escribimos como prefija
     atomPrefixToString(Mode,T,WhatEverString)
    ),!.

removeTail([C],[]):-!.
removeTail([X|Xs],[X|Xs2]) :- !, removeTail(Xs,Xs2).

% convertimos un string de toy en una lista de caracteres prolog
toyStringToList([],[]):-!.
toyStringToList(('$char'(A):RIn),[A|ROut]):-
    !,
    toyStringToList(RIn,ROut).




%tuplas
tupleToString(Mode,T,StringWhatEver):-
    T=..[_,Sec],
    sequenceToString(Mode,Sec,SecString),
    concatLsts([ "(", SecString, ")"], StringWhatEver).

sequenceToString(Mode,T,StringWhatEver):-
    (var(T);isVariable(T)),
    !,
    atomToPrologString(Mode,T,StringWhatEver).



sequenceToString(Mode,','(A,B),StringWhatEver):-
    !,
    atomToPrologString(Mode,A,AString),
    sequenceToString(Mode,B,BString),
    concatLsts([AString,", ",BString],StringWhatEver).

sequenceToString(Mode,A,StringWhatEver):-
    !,
    atomToPrologString(Mode,A,StringWhatEver).




atomPrefixToString(Mode,T,String):-
    T=..[Name|Args],
    (
     Name== '$$susp',
     !,
     suspToString(Mode,Args,String)
    ;
     applicationToString(Mode,Name,Args,String)
    ),
    !.

%----------------------------------------------------------------------------%
% suspToString(Mode,Args,String)
% Convierte una suspension en una cadena. Se le pasan los argumentos de la susp.
%----------------------------------------------------------------------------%
suspToString(Mode,Args,String):-
    Args=[F,Lista,R,S],
    % distinguimos 2 casos: la suspension esta evaluada (S no var.) o no
    (
     var(S),
     String = "_"
    ;
% Ponia  applicationToString(Mode,F,Lista,String)
% Debe ser:
         atomToPrologString(Mode,R,String)
    ),
    !.


%----------------------------------------------------------------------------%
% applicationToString(Mode,+Name,+Args,-String)
% Convierte una aplicacion de nombre Name con parametros Args en String
%----------------------------------------------------------------------------%

applicationToString(Mode,Name,Args,String) :-
     funToString(Mode,Name,NameString),
     listAtomsToString(Mode,Args," ",ArgsString),
     (
      Args\==[],
      !,
      concatLsts([ NameString, " ", ArgsString], String)
     ;
      append(NameString, ArgsString,String)
     ).



%----------------------------------------------------------------------------%
% listAtomsToString(Mode,+ListAtoms,+Separator,-String)
% Transforma la lista de atomos en una cadena de caracteres
%----------------------------------------------------------------------------%
listAtomsToString(L,L2) :-
    !,
    listAtomsToString(varToString,L," ",L2).

listAtomsToString(Mode,[],_,[]):-!.
listAtomsToString(Mode,[At],Separator,AtToString):-
    !,
    atomArgumentToPrologString(Mode,At,AtToString).

listAtomsToString(Mode,[At,At2|Rest],Separator,String):-
    atomArgumentToPrologString(Mode,At,AtToString),
    listAtomsToString(Mode,[At2|Rest],Separator,RestString),
    concatLsts([AtToString,Separator,RestString],String).


atomArgumentToPrologString(Mode,Arg,String) :-
    atomToPrologString(Mode,Arg,String1),
    (
      simpleValue(Mode,Arg),
      !,
      String = String1
    ;
      concatLsts(["(", String1,")"], String)
   ).

% ponia varToPVal
simpleValue(R,Arg) :-
    (var(Arg); isVariable(Arg); Arg = '$char'(N); Arg = '$int'(N); Arg = '$float'(N); Arg = '$$tup'(M);
       Arg=pValVar(Name);  atom(Arg); number(Arg);  simpleList(Arg)),!.


% es siempre (o casi, no estoy seguro) una lista de numeros. Si hay espacios entonces no es simple.
simpleValue(varToString,Arg) :-
      Arg = [X|Xs],
      (
       \+  member(32,[X|Xs])
       ;
       concatLsts([" [",R,"]"],[X|Xs]) % is a list
       ),
       !.





/*
simpleValue(varToString,'$$susp'(_Name,_Args,Result,Evaluated)) :-
    !,
    simpleValue(varToString,Result).

simpleValue(varToString,NameArg) :-
    T=..[Name|Args],
    (
     Name== '$$tup',


simpleValue(varToString,NameArg) :-
    name(Arg, NameArg),
    (Arg = '$char'(N); Arg = '$int'(N); Arg = '$float'(N);
      var(Arg); Arg=pValVar(Name); isVariable(Arg); atom(Arg); number(Arg);  simpleList(Arg)),!.

*/
simpleList([]) :-!.
simpleList([H|L]) :-
    simpleValue(_,H),
    simpleList(L).
simpleList(L) :- !,simpleToyList(L).

simpleToyList(pValBottom) :-!.
simpleToyList([]) :-!.
simpleToyList(H:L) :-!,
    simpleValue(_,H),
    simpleToyList(L).


%----------------------------------------------------------------------------%
% atomInfixToString: solo se usa para transformar en cadedna de caracteres
% expresiones con operadore infijos
% Parametros:
%   +T:     expresion a transformar
%   +Name:  functor principal de T
%   +Ar:    Aridad de T
%   +Prior: prioridad del functor principal de T
%   +Asoc:  asociatividad del functor de T (right,left o noasoc)
%   -String:cadena de caracteres correspondiente a la expresion
%
%   Si la aridad es 0 ponemos el operador entre parentesis. Si es 1, ponemos
% el operando y el operador entre parentesis.
% Si es 2, esto es, si tiene sus dos operandos hay que hacer un analisis mas
% fino sobre sus argumentos: si son variable llamamos a atomToPrologString que se
% encarga de transformarla. Si no, miramos si su functor es un op infijo que habra
% que parentizar en los siguientes casos:
%   - Si la prioridad del mas extermo es mayor que la del mas interno
%   - Si tienen la misma prioridad y:
%       - ambos asocian por la dcha si es el operando izdo, o por la
%         izda si el el dcho.
%       - no tienen la misma asociatividad
%----------------------------------------------------------------------------%

atomInfixToString(Mode,T,Name,Ar,Prior,Asoc,String):-
    (
        Ar==0,
        !,
        funToString(Mode,Name,NameString),
        concatLsts(["(",NameString,")"],String)
    ;
        Ar==1,
        !,
        arg(1,T,A1),
        funToString(Mode,Name,NameString),
        atomToPrologString(Mode,A1,A1String),
        concatLsts(["(",A1String," ",NameString,")"],String)
    ;
            !,
            % al menos dos argumentos; comenzamos por extraerlos
        T =.. [Functor,A1,A2|RestArgs],
        (
            functor(A1,Name1,Ar1),
            !,
            (
                isOpInfix(Name1,Prior1,Asoc1),
                (Prior>Prior1;
                    Prior==Prior1,
                    (Asoc==Asoc1,Asoc==right;Asoc\==Asoc1)),
                !,
                atomInfixToString(Mode,A1,Name1,Ar1,Prior1,Asoc1,
                          A1String),
                concatLsts(["(", A1String, ")"], String1)
            ;
                atomToPrologString(Mode,A1,String1)
            )
        ;
            atomToPrologString(Mode,A1,String1)
        ),
        funToString(Mode,Name,NameString),
        concatLsts([String1," ",NameString, " "], String2),
        (
            functor(A2,Name2,Ar2),
            (
                isOpInfix(Name2,Prior2,Asoc2),
                (Prior>Prior2;
                    Prior==Prior1,
                    (Asoc==Asoc2,Asoc==left;Asoc\==Asoc2)),
                !,
                atomInfixToString(Mode,A2,Name2,Ar2,Prior2,Asoc2,
                          A2String),
                concatLsts(["(", A2String, ")"], String3)
            ;
                atomToPrologString(Mode,A2,String3)
            )
        ;
                atomToPrologString(Mode,A2,String3)
        ),
        append(String2,String3,String4),
        % tratamos los argumentos extras, si los hay
        (
          RestArgs == [],!,
          String = String4
         ;
              listAtomsToString(Mode,RestArgs," ",ArgsString),
          concatLsts(["(", String4, ") ",ArgsString], String)
         )
    ).




%----------------------------------------------------------------------------%
% listToString(Mode,+T,-String) con T expresion a transformar en String
%----------------------------------------------------------------------------%

listToString(Mode,[]," []"):-!.

listToString(Mode,Ls,String):-
    Ls=..[_,Head,Tail], % puede ser el operador : o .
    (
    % 23-11-00 rafa El segundo caso de abajo (Head='$char'(N))
    % no funciona correctamemte si se trata de una variable
            (var(Head) ; isVariable(Head)),
            atomToPrologString(Mode,Head,HeadString),
        tailToString(Mode,Tail,TailString),
        concatLsts([" [", HeadString, TailString], String)
    ;
            Head='$char'(N),
        !,
        chainToString(Mode,Tail,TailString),
        concatLsts(["\"",[N],TailString], String)
    ;
        atomToPrologString(Mode,Head,HeadString),
        tailToString(Mode,Tail,TailString),
        concatLsts([" [", HeadString, TailString], String)
    ).


% Depu 28/11/00
% el caso de la lista vacia debe ir el primero
tailToString(Mode,[],"]"):-!.


tailToString(varToString,Ls,String):-
    (
     var(Ls)
    ;
     Ls =.. ['$$susp' | Args]
    ),
    !,
    atomToPrologString(varToString,Ls,LsString),
        suspToPrologString(varToString,LsString,String).


tailToString(varToPVal,Ls,String):-
    (
     isVariable(Ls)
    ;
     Ls =.. [Name | Args], Name \= ':'
    ),
    !,
    atomToPrologString(Mode,Ls,LsString),
    concatLsts([" | ", LsString, " ]"], String).

% 20-12-03 Cambio varToString por Mode
tailToString(Mode,pValBottom," | _ ]"):- !.

tailToString(Mode,Ls, String):-
    Ls=..[_,Head,Tail],
    (
        Head='$char'(N),
        !,
        chainToString(Mode,Tail,TailString),
        concatLsts([" ] ++ \"", [N], TailString], String)
    ;
        atomToPrologString(Mode,Head,HeadString),
        tailToString(Mode,Tail,TailString),
        concatLsts([", ", HeadString, TailString], String)
    ).

% si es una suspensi�n no evaluada utilizaremos la forma "[...|_]",
% si no separaremos los elementos con comas (a no ser que sea [])
suspToPrologString(Mode,"_", " | _ ]") :-
    !.

suspToPrologString(Mode," []", " ]") :-
    !.

% si es de la forma " [...." lo transformamos en ", ...."
suspToPrologString(Mode,[32,91|R], [44,32|R]) :-
    !.





chainToString(Mode,Chain, String):-
    (var(Chain);isVariable(Chain)),
    !,
    atomToPrologString(Mode,Chain,ChainString),
    concatLsts(["\" ++ ", ChainString], String).

chainToString(Mode,[],"\""):-
    !.

chainToString(Mode,Ls,String):-
    Ls=..[_,Head,Tail],
    (
        Head='$char'(N),
        !,
        chainToString(Mode,Tail,TailString),
        concatLsts([[N], TailString], String)
    ;
        atomToPrologString(Mode,Head, HeadString),
        tailToString(Mode,Tail, TailString),
        concatLsts(["\" ++ [", HeadString, TailString], String)
    ).

%----------------------------------------------------------------------------%
% funToString(Mode,+Name,-String)
% Transfooorma el nombre de una funcion en una cadena de caracteres.
% Si la funcion es $eqFun o $notEqFun
% saca == o /== respectivamente. Si es $apply no saca nada. En otro caso saca el
% nombre que le llega
%----------------------------------------------------------------------------%

funToString(Mode,Name,String):-
    (
     Name=='$eqFun',!, String = "(==)"
    ;
     Name=='$notEqFun',!,String = "(/=)"
    ;
    Name=='.$',!,String = "." % Rafa 31-08-03 Ahora '.$' es la representacion interna del op. infijo '.'
    ;
     Name=='$apply',!
    ;
     number(Name),!,
     name(Name, String)
    ;
     aplicationNameToString(Name,String)
    ).

%----------------------------------------------------------------------------%
% aplicationNameToString(Name,String)
% Transforma en cadena de caracteres el nombre de la funcion.
%  Si la a funcion es
% una funcion auxiliar, tiene la forma $Nombre$i, y hay que dejarla de la forma
% Nombre
%----------------------------------------------------------------------------%
% 07/09/03 rafa: main debe tratarse de forma especial
aplicationNameToString('$$main',"$$main"):- !.

aplicationNameToString(Name,String):-
    (
     name(Name,[36|String1]),  % 36 --> '$'
     searchDollar(String1,[],String)
    ;
     name(Name,String1),           % antes en vez de estas dos cosas
     searchDollar(String1,[],String)   % ponia: name(Name,String)
    ),
    !.






%----------------------------------------------------------------------------%
% searchDollar(+RestString,+PrefixString1,-String)
% String es PrefixString+Resto, donde Resto es la parte de RestString hasta el
% simbolo '$' (todo si no aparece).
%----------------------------------------------------------------------------%

searchDollar([],PL,PL):- !.

searchDollar([36|R],PL,PL):- !.

searchDollar([C|R],PL,String):-
    !,
    append(PL,[C],PL1),
    searchDollar(R,PL1,String).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"

% convierte la expresi�n en un t�rmino. Para ello sustituye las suspensiones por una
% nueva 'constructora' $$call/2 que s�lo contiene inf. acerca de las dos variables
% que le hacen falta a pVal.

exprToTerm(A,A):- !.

exprToTerm('$$susp'(_Name,_Args,Result,Evaluated),'$$call'(Result,Evaluated)):-
    !.
exprToTerm(A,A):- atom(A) ,!.

exprToTerm(A,B) :-
    !,
    A=..[Name|Args],
    exprToTermMap(Args,NewArgs),
    B =..[Name|NewArgs].

exprToTermMap([],[]):-!.
exprToTermMap([X|Xs],[Y|Ys]):-
    exprToTerm(X,Y),
    exprToTermMap(Xs,Ys).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%"
% constraintToPrologString(+C,-P)
constraintToPrologString(constraint([]),"") :- !.
constraintToPrologString(constraint(L),R) :-
    listAtomicConstraintToPrologString(L,R).

listAtomicConstraintToPrologString(':'(A,[]),R) :-
      atomicConstraintToPrologString(A,R).
listAtomicConstraintToPrologString(':'(A,':'(B,C)),R) :-
      atomicConstraintToPrologString(A,R1),
      listAtomicConstraintToPrologString(':'(B,C),R2),
      % 10/07/05: three possibilities:
      ( R1==[],
        R = R2
      ; 
        R2 == [],
        R = R1
      ;             
       concatLsts([R1,", ", R2],R)
      ),
      !.

atomicConstraintToPrologString(atomicConstraint(Name,Args,Result),Output) :-
       toyStringToList(Name,"seq"),
       pValToPrologString(Result,"false"),
       !,
       Args = ':'(A,':'(B,[])),
       pValToPrologString(A,A1),
       pValToPrologString(B,B1),
      concatLsts([" (",A1," /= ", B1,") "],Output).

atomicConstraintToPrologString(atomicConstraint(Name,Args,Result),Output) :-
       toyStringToList(Name,"tot"),
      (
       getTot(on),
       pValToPrologString(Result,"true"),
       !,
       Args = ':'(A,[]),
       pValToPrologString(A,A1),
       concatLsts([" tot(",A1,") "],Output)
      ;
       Output=[]
      ),
      !.  

% constraint over real numbers
/*
atomicConstraintToPrologString(atomicConstraint(Name,Args,Result),Output) :-
       toyStringToList(Name,TheName),
       pValToPrologString(Result,"true"),
       !,
       Args = ':'(A,L),
       toyStringToList(A,A1),
       pValToPrologString(L,L1),
       plain(L1,L2),
       concatLsts([A1," ",TheName," ",L2],Output).
*/       

atomicConstraintToPrologString(atomicConstraint(Name,Args,Result),Name).

plain([],[]).
plain([[X|Xs]|Y],[X|L]) :-
   append(Xs,Y,Ys),
   plain(Ys,L).
   
plain([X|Xs],[X|L]) :-
   plain(Xs,L).
