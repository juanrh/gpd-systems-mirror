
primitiveFunct(minimize, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).

primitiveFunct(maximize, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).

primitiveFunct(bb_minimize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).

primitiveFunct(bb_maximize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).





