

user:portray_message(warning,_):- write('').

:- module(plgenerated,[hnf_susp/5,constr/4,funct/5,infix/3,'$$apply'/5,'$flip'/6,'$and' /5,'$or' /5,$/\ /5,$\/ /5,'$not' /4,'$andL' /3,'$orL' /3,'$orL\'' /3,'$any' /4,'$any\'' /4,'$all' /4,'$undefined' /3,'$def' /4,'$not_undef' /4,'$nf' /4,'$hnf' /4,'$strict' /5,'$strict\'' /5,'$map' /5,$. /6,$++ /5,'$!!' /5,'$iterate' /5,'$repeat' /4,'$copy' /5,'$filter' /5,'$foldl' /6,'$foldl1' /5,'$foldl\'' /6,'$scanl' /6,'$scanl1' /5,'$scanl\'' /6,'$foldr' /6,'$foldr1' /5,'$scanr' /6,'$auxForScanr' /6,'$scanr1' /5,'$take' /5,'$drop' /5,'$splitAt' /5,'$auxForSplitAt' /5,'$takeWhile' /5,'$takeUntil' /5,'$dropWhile' /5,'$span' /5,'$auxForSpan' /5,'$break' /4,'$zipWith' /6,'$zip' /5,'$mkpair' /5,'$unzip' /4,'$auxForUnzip' /6,'$until' /6,'$until\'' /5,'$const' /5,'$id' /4,$// /5,'$curry' /6,'$uncurry' /5,'$fst' /4,'$snd' /4,'$fst3' /4,'$snd3' /4,'$thd3' /4,'$substract' /3,'$even' /4,'$odd' /3,'$lcm' /5,'$head' /4,'$last' /4,'$tail' /4,'$init' /4,'$nub' /4,'$length' /4,'$size' /3,'$reverse' /3,'$member' /3,'$notMember' /3,'$concat' /3,'$transpose' /3,'$auxForTranspose' /5,$\\ /3,'$del' /5,'$strToint' /4,'$getNumber' /5,'$intTostr' /4,'$getString' /5,'$tkShowErrors' /3,'$tkRef2Label' /4,'$tkRef2Wtype' /4,'$tk2tcl' /6,'$tkConfCollection2tcl' /5,'$tkConf2tcl' /7,'$setlistelems' /5,'$tkMenu2tcl' /5,'$setmenuelems' /5,'$tkConfs2handler' /5,'$tkMenu2handler' /6,'$tkConfs2tcl' /7,'$tkcitems2tcl' /5,'$tkcitem' /5,'$tkShowCoords' /4,'$tkLabel2Refname' /4,'$aux' /4,'$tkRefname2Label' /4,'$aux1' /4,'$tks2tcl' /7,'$tkslabels' /6,'$tkmain2tcl' /5,'$debugTcl' /4,'$forkWish' /5,'$runWidget' /5,'$aux4' /4,'$runWidgetInit' /6,'$runWidgetPassive' /5,'$initSchedule' /8,'$tkSchedule' /7,'$aux2' /8,'$tkTerminateWish' /5,'$tkSelectEvent' /7,'$tkGetVar' /6,'$tkGetVarMsg' /6,'$aux3' /7,'$tkGetVarValue' /6,'$tkParseInt' /5,'$checkWishConsistency' /5,'$escape_tcl' /4,'$tkVoid' /4,'$tkExit' /4,'$tkGetValue' /5,'$tkSetValue' /6,'$tkUpdate' /6,'$tkConfig' /6,'$tkFocus' /5,'$tkAddCanvas' /6]).

:- dynamic $== /5, $/= /5.

/*  AF0503
:- load_files('$TOYDIR/toycomm',[if(changed)]).

:- load_files('$TOYDIR/primitivesGra',[if(changed)]).
*/
%F010204
:- load_files(tools,[if(changed),imports([complete_root_filename/2])]).

:- complete_root_filename(toycomm,F),load_files(F,[if(changed)]).

:- complete_root_filename(primitivesGra,F),load_files(F,[if(changed)]).





/**************    CODE FOR FUNCTIONS    **************/


% and
'$and'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$and_1'(_F, _B, _C, _G, _E).
'$and'(_A, _B, false, _C, _D):-
        hnf(_B, false, _C, _D).
'$and_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$and_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _E),
        hnf(_B, true, _E, _D).

% or
'$or'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$or_1'(_F, _B, _C, _G, _E).
'$or'(_A, _B, true, _C, _D):-
        hnf(_B, true, _C, _D).
'$or_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$or_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _E),
        hnf(_B, false, _E, _D).

% /\
$/\(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$/\\_1'(_F, _B, _C, _G, _E).
'$/\\_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$/\\_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, true, _D, _F),
        hnf(_B, _C, _F, _E).

% \/
$\/(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$\\/_1'(_F, _B, _C, _G, _E).
'$\\/_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$\\/_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, false, _D, _F),
        hnf(_B, _C, _F, _E).

% not
'$not'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$not_1'(_E, _B, _F, _D).
'$not_1'(_A, false, _B, _C):-
        unifyHnfs(_A, true, _B, _C).
'$not_1'(_A, true, _B, _C):-
        unifyHnfs(_A, false, _B, _C).

% andL
'$andL'(foldr(/\, true), _A, _A).

% orL
'$orL'(foldr(or, false), _A, _A).

% 'orL\''
'$orL\''(foldr(\/, false), _A, _A).

% any
'$any'(_A, '.'('$$susp'( '$orL',  [], _B, _C ), map(_A)), _D, _D).

% 'any\''
'$any\''(_A, '.'('$$susp'( '$orL\'',  [], _B, _C ), map(_A)), _D, _D).

% all
'$all'(_A, '.'('$$susp'( '$andL',  [], _B, _C ), map(_A)), _D, _D).

% undefined
'$undefined'(_A, _B, _C):-
        '$if_then'(false, '$$susp'( '$undefined',  [], _D, _E ), _A, _B, _C).

% def
'$def'(_A, true, _B, _C):-
        '$$eqFun'(_A, _D, true, _B, _C).

% not_undef
'$not_undef'(_A, true, _B, _C):-
        '$$notEqFun'(_A, _D, true, _B, _C).

% nf
'$nf'(_A, _B, _C, _D):-
        equal(_A, _E, _C, _F),
        hnf(_E, _B, _F, _D).

% hnf
'$hnf'(_A, _B, _C, _D):-
        notEqual(_A, _E, _C, _F),
        hnf(_A, _B, _F, _D).

% strict
'$strict'(_A, _B, _C, _D, _E):-
        equal(_B, _F, _D, _G),
        '$$apply'(_A, _F, _C, _G, _E).

% 'strict\''
'$strict\''(_A, _B, _C, _D, _E):-
        notEqual(_B, _F, _D, _G),
        '$$apply'(_A, _B, _C, _G, _E).

% map
'$map'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$map_2'(_A, _F, _C, _G, _E).
'$map_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$map_2'(_A, _B, :('$$susp'( '$$apply',  [ _A, _C ], _D, _E ), '$$susp'( '$map',  [ _A, _F ], _G, _H )), _I, _J):-
        unifyHnfs(_B, :(_C, _F), _I, _J).

% '.'
$.(_A, _B, _C, _D, _E, _F):-
        '$$apply'(_A, '$$susp'( '$$apply',  [ _B, _C ], _G, _H ), _D, _E, _F).

% ++
$++(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$++_1'(_F, _B, _C, _G, _E).
'$++_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, _C, _F, _E).
'$++_1'(_A, _B, :(_C, '$$susp'( $++,  [ _D, _B ], _E, _F )), _G, _H):-
        unifyHnfs(_A, :(_C, _D), _G, _H).

% '!!'
'$!!'(_A, _B, _C, _D, _E):-
        hnf(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _B, 0.0 ], _I, _J ), _F, '$$susp'( '$!!',  [ _G, '$$susp'( $-,  [ _B, 1.0 ], _K, _L ) ], _M, _N ), _C, _H, _E).

% iterate
'$iterate'(_A, _B, :(_B, '$$susp'( '$iterate',  [ _A, '$$susp'( '$$apply',  [ _A, _B ], _C, _D ) ], _E, _F )), _G, _G).

% repeat
'$repeat'(_A, :(_A, '$$susp'( '$repeat',  [ _A ], _B, _C )), _D, _D).

% copy
'$copy'(_A, _B, _C, _D, _E):-
        '$take'(_A, '$$susp'( '$repeat',  [ _B ], _F, _G ), _C, _D, _E).

% filter
'$filter'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$filter_2'(_A, _F, _C, _G, _E).
'$filter_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$filter_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply',  [ _A, _F ], _I, _J ), :(_F, '$$susp'( '$filter',  [ _A, _G ], _K, _L )), '$$susp'( '$filter',  [ _A, _G ], _M, _N ), _C, _H, _E).

% foldl
'$foldl'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldl_3'(_A, _B, _G, _D, _H, _F).
'$foldl_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldl_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$foldl'(_A, '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, _B ], _J, _K ), _G ], _L, _M ), _H, _D, _I, _F).

% foldl1
'$foldl1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        '$foldl'(_A, _F, _G, _C, _H, _E).

% 'foldl\''
'$foldl\''(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldl\'_3'(_A, _B, _G, _D, _H, _F).
'$foldl\'_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldl\'_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$strict',  [ 'foldl\''(_A), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, _B ], _J, _K ), _G ], _L, _M ) ], _N, _O ), _H, _D, _I, _F).

% scanl
'$scanl'(_A, _B, _C, :(_D, _E), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$scanl_3'(_A, _B, _H, :(_D, _E), _I, _G).
'$scanl_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanl_3'(_A, _B, _C, :(_B, '$$susp'( '$scanl',  [ _A, '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, _B ], _D, _E ), _F ], _G, _H ), _I ], _J, _K )), _L, _M):-
        unifyHnfs(_C, :(_F, _I), _L, _M).

% scanl1
'$scanl1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        '$scanl'(_A, _F, _G, _C, _H, _E).

% 'scanl\''
'$scanl\''(_A, _B, _C, :(_D, _E), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$scanl\'_3'(_A, _B, _H, :(_D, _E), _I, _G).
'$scanl\'_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanl\'_3'(_A, _B, _C, :(_B, '$$susp'( '$$apply',  [ '$$susp'( '$strict',  [ 'scanl\''(_A), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, _B ], _D, _E ), _F ], _G, _H ) ], _I, _J ), _K ], _L, _M )), _N, _O):-
        unifyHnfs(_C, :(_F, _K), _N, _O).

% foldr
'$foldr'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldr_3'(_A, _B, _G, _D, _H, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$$apply',  [ _A, _G ], _J, _K ), '$$susp'( '$foldr',  [ _A, _B, _H ], _L, _M ), _D, _I, _F).

% foldr1
'$foldr1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        hnf(_G, _I, _H, _J),
        '$foldr1_2_2.2_:'(_A, _F, _I, _C, _J, _E).
'$foldr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$$apply',  [ _A, _B ], _J, _K ), '$$susp'( '$foldr1',  [ _A, :(_G, _H) ], _L, _M ), _D, _I, _F).

% scanr
'$scanr'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$scanr_3'(_A, _B, _G, _D, _H, _F).
'$scanr_3'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$auxForScanr'(_A, _G, '$$susp'( '$scanr',  [ _A, _B, _H ], _J, _K ), _D, _I, _F).

% auxForScanr
'$auxForScanr'(_A, _B, _C, :('$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, _B ], _D, _E ), '$$susp'( '$head',  [ _C ], _F, _G ) ], _H, _I ), _C), _J, _J).

% scanr1
'$scanr1'(_A, _B, _C, _D, _E):-
        hnf(_B, :(_F, _G), _D, _H),
        hnf(_G, _I, _H, _J),
        '$scanr1_2_2.2_:'(_A, _F, _I, _C, _J, _E).
'$scanr1_2_2.2_:'(_A, _B, _C, :(_B, []), _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$scanr1_2_2.2_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$auxForScanr'(_A, _B, '$$susp'( '$scanr1',  [ _A, :(_G, _H) ], _J, _K ), _D, _I, _F).

% take
'$take'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$take_2'(_A, _F, _C, _G, _E).
'$take_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$take_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, 0.0 ], _I, _J ), [], :(_F, '$$susp'( '$take',  [ '$$susp'( $-,  [ _A, 1.0 ], _K, _L ), _G ], _M, _N )), _C, _H, _E).

% drop
'$drop'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$drop_2'(_A, _F, _C, _G, _E).
'$drop_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$drop_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, 0.0 ], _I, _J ), :(_F, _G), '$$susp'( '$drop',  [ '$$susp'( $-,  [ _A, 1.0 ], _K, _L ), _G ], _M, _N ), _C, _H, _E).

% splitAt
'$splitAt'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$splitAt_2'(_A, _F, _C, _G, _E).
'$splitAt_2'(_A, _B, '$$tup'(','([], [])), _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$splitAt_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, 0.0 ], _I, _J ), '$$tup'(','([], :(_F, _G))), '$$susp'( '$auxForSplitAt',  [ _F, '$$susp'( '$splitAt',  [ '$$susp'( $-,  [ _A, 1.0 ], _K, _L ), _G ], _M, _N ) ], _O, _P ), _C, _H, _E).

% auxForSplitAt
'$auxForSplitAt'(_A, _B, '$$tup'(','(:(_A, _C), _D)), _E, _F):-
        hnf(_B, '$$tup'(_G), _E, _H),
        hnf(_G, ','(_C, _D), _H, _F).

% takeWhile
'$takeWhile'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$takeWhile_2'(_A, _F, _C, _G, _E).
'$takeWhile_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$takeWhile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply',  [ _A, _F ], _I, _J ), :(_F, '$$susp'( '$takeWhile',  [ _A, _G ], _K, _L )), [], _C, _H, _E).

% takeUntil
'$takeUntil'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$takeUntil_2'(_A, _F, _C, _G, _E).
'$takeUntil_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$takeUntil_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply',  [ _A, _F ], _I, _J ), :(_F, []), :(_F, '$$susp'( '$takeUntil',  [ _A, _G ], _K, _L )), _C, _H, _E).

% dropWhile
'$dropWhile'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$dropWhile_2'(_A, _F, _C, _G, _E).
'$dropWhile_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$dropWhile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply',  [ _A, _F ], _I, _J ), '$$susp'( '$dropWhile',  [ _A, _G ], _K, _L ), :(_F, _G), _C, _H, _E).

% span
'$span'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$span_2'(_A, _F, _C, _G, _E).
'$span_2'(_A, _B, '$$tup'(','([], [])), _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$span_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$apply',  [ _A, _F ], _I, _J ), '$$susp'( '$auxForSpan',  [ _F, '$$susp'( '$span',  [ _A, _G ], _K, _L ) ], _M, _N ), '$$tup'(','([], :(_F, _G))), _C, _H, _E).

% auxForSpan
'$auxForSpan'(_A, _B, '$$tup'(','(:(_A, _C), _D)), _E, _F):-
        hnf(_B, '$$tup'(_G), _E, _H),
        hnf(_G, ','(_C, _D), _H, _F).

% break
'$break'(_A, span('.'(not, _A)), _B, _B).

% zipWith
'$zipWith'(_A, _B, _C, _D, _E, _F):-
        hnf(_B, _G, _E, _H),
        '$zipWith_2'(_A, _G, _C, _D, _H, _F).
'$zipWith_2'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_B, [], _D, _E).
'$zipWith_2'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, :(_G, _H), _E, _I),
        hnf(_C, _J, _I, _K),
        '$zipWith_2_3_:'(_A, _G, _H, _J, _D, _K, _F).
'$zipWith_2_3_:'(_A, _B, _C, _D, [], _E, _F):-
        unifyHnfs(_D, [], _E, _F).
'$zipWith_2_3_:'(_A, _B, _C, _D, :('$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, _B ], _E, _F ), _G ], _H, _I ), '$$susp'( '$zipWith',  [ _A, _C, _J ], _K, _L )), _M, _N):-
        unifyHnfs(_D, :(_G, _J), _M, _N).

% zip
'$zip'(_A, _B, _C, _D, _E):-
        '$zipWith'(mkpair, _A, _B, _C, _D, _E).

% mkpair
'$mkpair'(_A, _B, '$$tup'(','(_A, _B)), _C, _C).

% unzip
'$unzip'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$unzip_1'(_E, _B, _F, _D).
'$unzip_1'(_A, '$$tup'(','([], [])), _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$unzip_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        '$auxForUnzip'(_J, _K, '$$susp'( '$unzip',  [ _F ], _M, _N ), _B, _L, _D).

% auxForUnzip
'$auxForUnzip'(_A, _B, _C, '$$tup'(','(:(_A, _D), :(_B, _E))), _F, _G):-
        hnf(_C, '$$tup'(_H), _F, _I),
        hnf(_H, ','(_D, _E), _I, _G).

% until
'$until'(_A, _B, _C, _D, _E, _F):-
        '$if_then_else'('$$susp'( '$$apply',  [ _A, _C ], _G, _H ), _C, '$$susp'( '$until',  [ _A, _B, '$$susp'( '$$apply',  [ _B, _C ], _I, _J ) ], _K, _L ), _D, _E, _F).

% 'until\''
'$until\''(_A, _B, '.'(takeUntil(_A), iterate(_B)), _C, _C).

% const
'$const'(_A, _B, _C, _D, _E):-
        hnf(_A, _C, _D, _E).

% id
'$id'(_A, _B, _C, _D):-
        hnf(_A, _B, _C, _D).

% //
$//(_A, _B, _C, _D, _E):-
        hnf(_A, _C, _D, _E).
$//(_A, _B, _C, _D, _E):-
        hnf(_B, _C, _D, _E).

% curry
'$curry'(_A, _B, _C, _D, _E, _F):-
        '$$apply'(_A, '$$tup'(','(_B, _C)), _D, _E, _F).

% uncurry
'$uncurry'(_A, _B, _C, _D, _E):-
        hnf(_B, '$$tup'(_F), _D, _G),
        hnf(_F, ','(_H, _I), _G, _J),
        '$$apply'('$$susp'( '$$apply',  [ _A, _H ], _K, _L ), _I, _C, _J, _E).

% fst
'$fst'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_G, _B, _I, _D).

% snd
'$snd'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, _B, _I, _D).

% fst3
'$fst3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_G, _B, _L, _D).

% snd3
'$snd3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_J, _B, _L, _D).

% thd3
'$thd3'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        hnf(_K, _B, _L, _D).

% substract
'$substract'(flip(-), _A, _A).

% even
'$even'(_A, _B, _C, _D):-
        '$$eqFun'('$$susp'( '$mod',  [ _A, 2.0 ], _E, _F ), 0.0, _B, _C, _D).

% odd
'$odd'('.'(not, even), _A, _A).

% lcm
'$lcm'(_A, _B, _C, _D, _E):-
        '$if_then_else'('$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, 0.0 ], _F, _G ), '$$susp'( '$$eqFun',  [ _B, 0.0 ], _H, _I ) ], _J, _K ), 0.0, '$$susp'( '$abs',  [ '$$susp'( $*,  [ '$$susp'( '$div',  [ _A, '$$susp'( '$gcd',  [ _A, _B ], _L, _M ) ], _N, _O ), _B ], _P, _Q ) ], _R, _S ), _C, _D, _E).

% head
'$head'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_E, _B, _G, _D).

% last
'$last'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$last_1_1.2_:'(_E, _H, _B, _I, _D).
'$last_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, [], _D, _F),
        hnf(_A, _C, _F, _E).
'$last_1_1.2_:'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$last'(:(_F, _G), _C, _H, _E).

% tail
'$tail'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _B, _G, _D).

% init
'$init'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _H, _G, _I),
        '$init_1_1.2_:'(_E, _H, _B, _I, _D).
'$init_1_1.2_:'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$init_1_1.2_:'(_A, _B, :(_A, '$$susp'( '$init',  [ :(_C, _D) ], _E, _F )), _G, _H):-
        unifyHnfs(_B, :(_C, _D), _G, _H).

% nub
'$nub'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$nub_1'(_E, _B, _F, _D).
'$nub_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$nub_1'(_A, :(_B, '$$susp'( '$nub',  [ '$$susp'( '$filter',  [ '$notEqFun'(_B), _C ], _D, _E ) ], _F, _G )), _H, _I):-
        unifyHnfs(_A, :(_B, _C), _H, _I).

% length
'$length'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$length_1'(_E, _B, _F, _D).
'$length_1'(_A, 0.0, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$length_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $+(1.0, '$$susp'( '$length',  [ _F ], _H, _I ), _B, _G, _D).

% size
'$size'('.'(length, nub), _A, _A).

% reverse
'$reverse'(foldl(flip(:), []), _A, _A).

% member
'$member'('.'('any\'', '$eqFun'), _A, _A).

% notMember
'$notMember'('.'(all, '$notEqFun'), _A, _A).

% concat
'$concat'(foldr(++, []), _A, _A).

% transpose
'$transpose'(foldr(auxForTranspose, []), _A, _A).

% auxForTranspose
'$auxForTranspose'(_A, _B, _C, _D, _E):-
        '$zipWith'(:, _A, '$$susp'( $++,  [ _B, '$$susp'( '$repeat',  [ [] ], _F, _G ) ], _H, _I ), _C, _D, _E).

% \\
$\\(foldl(del), _A, _A).

% del
'$del'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$del_1'(_F, _B, _C, _G, _E).
'$del_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$del_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _F, _B ], _I, _J ), _G, '$$susp'( '$del',  [ :(_F, _G), _B ], _K, _L ), _C, _H, _E).

% strToint
'$strToint'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ '$$susp'( '$head',  [ _A ], _E, _F ), '$char'(45) ], _G, _H ), '$$susp'( '$uminus',  [ '$$susp'( '$getNumber',  [ '$$susp'( '$tail',  [ _A ], _I, _J ), 0.0 ], _K, _L ) ], _M, _N ), '$$susp'( '$getNumber',  [ _A, 0.0 ], _O, _P ), _B, _C, _D).

% getNumber
'$getNumber'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$getNumber_1'(_F, _B, _C, _G, _E).
'$getNumber_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, _C, _F, _E).
'$getNumber_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        '$getNumber'(_G, '$$susp'( $+,  [ '$$susp'( $*,  [ _B, 10.0 ], _I, _J ), '$$susp'( $-,  [ '$$susp'( '$ord',  [ _F ], _K, _L ), '$$susp'( '$ord',  [ '$char'(48) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).

% intTostr
'$intTostr'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( $<,  [ _A, 0.0 ], _E, _F ), :('$char'(45), '$$susp'( '$getString',  [ '$$susp'( '$uminus',  [ _A ], _G, _H ), [] ], _I, _J )), '$$susp'( '$getString',  [ _A, [] ], _K, _L ), _B, _C, _D).

% getString
'$getString'(_A, _B, _C, _D, _E):-
        equal(_A, 0.0, _D, _F),
        hnf(_B, _C, _F, _E).
'$getString'(_A, _B, _C, _D, _E):-
        $>(_A, 0.0, true, _D, _F),
        equal(_G, '$$susp'( '$div',  [ _A, 10.0 ], _H, _I ), _F, _J),
        equal(_K, '$$susp'( '$mod',  [ _A, 10.0 ], _L, _M ), _J, _N),
        equal(_O, '$$susp'( '$chr',  [ '$$susp'( $+,  [ '$$susp'( '$ord',  [ '$char'(48) ], _P, _Q ), _K ], _R, _S ) ], _T, _U ), _N, _V),
        '$getString'(_G, :(_O, _B), _C, _V, _E).

% tkShowErrors
'$tkShowErrors'(false, _A, _A).

% tkRef2Label
'$tkRef2Label'(_A, _B, _C, _D):-
        hnf(_A, tkRefLabel(_E, _F, _G), _C, _H),
        '$tkRefname2Label'(_F, _B, _H, _D).

% tkRef2Wtype
'$tkRef2Wtype'(_A, _B, _C, _D):-
        hnf(_A, tkRefLabel(_E, _F, _G), _C, _H),
        hnf(_G, _B, _H, _D).

% tk2tcl
'$tk2tcl'(_A, _B, _C, '$$tup'(','(_D, _E)), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$tk2tcl_3'(_A, _B, _H, '$$tup'(','(_D, _E)), _I, _G).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(32), []))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ) ], _MB, _NB ) ], _OB, _PB ), :('$$tup'(','(_B, _QB)), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))), _A, _B, _R ], _RB, _SB ) ], _TB, _UB )))), _VB, _WB):-
        unifyHnfs(_C, tkButton(_QB, _R), _VB, _WB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(99), :('$char'(97), :('$char'(110), :('$char'(118), :('$char'(97), :('$char'(115), :('$char'(32), []))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(97), :('$char'(110), :('$char'(118), :('$char'(97), :('$char'(115), [])))))), _A, _B, _D ], _E, _F ) ], _G, _H ) ], _I, _J ) ], _K, _L ) ], _M, _N ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(97), :('$char'(110), :('$char'(118), :('$char'(97), :('$char'(115), [])))))), _A, _B, _D ], _O, _P ) ], _Q, _R ))), _S, _T):-
        unifyHnfs(_C, tkCanvas(_D), _S, _T).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(32), [])))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkCheckButton(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkEntry(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), []))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), []))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkLabel(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(108), :('$char'(105), :('$char'(115), :('$char'(116), :('$char'(98), :('$char'(111), :('$char'(120), :('$char'(32), [])))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(111), :('$char'(114), :('$char'(116), :('$char'(115), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(99), :('$char'(116), :('$char'(105), :('$char'(111), :('$char'(110), :('$char'(32), :('$char'(102), :('$char'(97), :('$char'(108), :('$char'(115), :('$char'(101), :('$char'(10), [])))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(105), :('$char'(115), :('$char'(116), :('$char'(98), :('$char'(111), :('$char'(120), []))))))), _A, _B, _P ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(105), :('$char'(115), :('$char'(116), :('$char'(98), :('$char'(111), :('$char'(120), []))))))), _A, _B, _P ], _CB, _DB ) ], _EB, _FB ))), _GB, _HB):-
        unifyHnfs(_C, tkListBox(_P), _GB, _HB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), :('$char'(32), [])))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), []))))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), []))))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkMessage(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(32), []))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkMenuButton(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(114), :('$char'(111), :('$char'(109), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _D ], _E, _F ), '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(111), :('$char'(32), []))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _G ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(122), :('$char'(111), :('$char'(110), :('$char'(116), :('$char'(97), :('$char'(108), :('$char'(32), :('$char'(45), :('$char'(108), :('$char'(101), :('$char'(110), :('$char'(103), :('$char'(116), :('$char'(104), :('$char'(32), :('$char'(50), :('$char'(48), :('$char'(48), :('$char'(10), [])))))))))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _D ], _L, _M ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _R, _S ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _T, _U ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _V, _W ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _X, _Y ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _Z, _AA ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))), _A, _B, _BA ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ) ], _MB, _NB ) ], _OB, _PB ) ], _QB, _RB ) ], _SB, _TB ) ], _UB, _VB ) ], _WB, _XB ) ], _YB, _ZB ) ], _AC, _BC ) ], _CC, _DC ) ], _EC, _FC ) ], _GC, _HC ) ], _IC, _JC ) ], _KC, _LC ) ], _MC, _NC ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))), _A, _B, _BA ], _OC, _PC ) ], _QC, _RC ))), _SC, _TC):-
        unifyHnfs(_C, tkScale(_D, _G, _BA), _SC, _TC).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), :('$char'(32), [])))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(122), :('$char'(111), :('$char'(110), :('$char'(116), :('$char'(97), :('$char'(108), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), [])))))))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _E, _F ), '$$susp'( $++,  [ :('$char'(32), :('$char'(120), :('$char'(118), :('$char'(105), :('$char'(101), :('$char'(119), :('$char'(125), :('$char'(10), [])))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _G, _H ), '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(120), :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), [])))))))))))))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(125), :('$char'(10), [])))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _I, _J ), '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(119), :('$char'(114), :('$char'(97), :('$char'(112), :('$char'(32), :('$char'(110), :('$char'(111), :('$char'(110), :('$char'(101), :('$char'(10), [])))))))))))))))))))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _K ], _L, _M ) ], _N, _O ) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ) ], _FA, _GA ) ], _HA, _IA ) ], _JA, _KA ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _K ], _LA, _MA ) ], _NA, _OA ))), _PA, _QA):-
        unifyHnfs(_C, tkScrollH(_D, _K), _PA, _QA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), :('$char'(32), [])))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _E, _F ), '$$susp'( $++,  [ :('$char'(32), :('$char'(121), :('$char'(118), :('$char'(105), :('$char'(101), :('$char'(119), :('$char'(125), :('$char'(10), [])))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _G, _H ), '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(121), :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), [])))))))))))))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(125), :('$char'(10), [])))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _I ], _J, _K ) ], _L, _M ) ], _N, _O ) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _I ], _FA, _GA ) ], _HA, _IA ))), _JA, _KA):-
        unifyHnfs(_C, tkScrollV(_D, _I), _JA, _KA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(32), []))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(104), :('$char'(101), :('$char'(105), :('$char'(103), :('$char'(104), :('$char'(116), :('$char'(32), :('$char'(49), :('$char'(53), :('$char'(10), [])))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(32), :('$char'(49), :('$char'(46), :('$char'(48), :('$char'(32), :('$char'(123), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(45), :('$char'(49), :('$char'(32), :('$char'(99), :('$char'(104), :('$char'(97), :('$char'(114), :('$char'(115), :('$char'(125), :('$char'(125), :('$char'(10), []))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), []))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(100), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(49), :('$char'(46), :('$char'(48), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(59), :('$char'(32), [])))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(105), :('$char'(110), :('$char'(115), :('$char'(101), :('$char'(114), :('$char'(116), :('$char'(32), :('$char'(49), :('$char'(46), :('$char'(48), :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), [])))))))))))))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))), _A, _B, _H ], _I, _J ) ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))), _A, _B, _H ], _QA, _RA ) ], _SA, _TA ))), _UA, _VA):-
        unifyHnfs(_C, tkTextEdit(_H), _UA, _VA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ '$$susp'( '$if_then_else',  [ '$$susp'( '$$eqFun',  [ _B, [] ], _D, _E ), [], '$$susp'( $++,  [ :('$char'(102), :('$char'(114), :('$char'(97), :('$char'(109), :('$char'(101), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, :('$char'(10), []) ], _F, _G ) ], _H, _I ) ], _J, _K ), '$$susp'( $++,  [ '$$susp'( '$fst',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _M, _N ) ], _O, _P ), '$$susp'( $++,  [ :('$char'(112), :('$char'(97), :('$char'(99), :('$char'(107), :('$char'(32), []))))), '$$susp'( $++,  [ '$$susp'( '$tkslabels',  [ _B, 97.0, _L ], _Q, _R ), '$$susp'( $++,  [ '$$susp'( '$tkConfCollection2tcl',  [ :('$char'(114), :('$char'(111), :('$char'(119), []))), _S ], _T, _U ), :('$char'(45), :('$char'(115), :('$char'(105), :('$char'(100), :('$char'(101), :('$char'(32), :('$char'(108), :('$char'(101), :('$char'(102), :('$char'(116), :('$char'(10), []))))))))))) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$snd',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _FA, _GA ) ], _HA, _IA ))), _JA, _KA):-
        unifyHnfs(_C, tkRow(_S, _L), _JA, _KA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ '$$susp'( '$if_then_else',  [ '$$susp'( '$$eqFun',  [ _B, [] ], _D, _E ), [], '$$susp'( $++,  [ :('$char'(102), :('$char'(114), :('$char'(97), :('$char'(109), :('$char'(101), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, :('$char'(10), []) ], _F, _G ) ], _H, _I ) ], _J, _K ), '$$susp'( $++,  [ '$$susp'( '$fst',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _M, _N ) ], _O, _P ), '$$susp'( $++,  [ :('$char'(112), :('$char'(97), :('$char'(99), :('$char'(107), :('$char'(32), []))))), '$$susp'( $++,  [ '$$susp'( '$tkslabels',  [ _B, 97.0, _L ], _Q, _R ), '$$susp'( $++,  [ '$$susp'( '$tkConfCollection2tcl',  [ :('$char'(99), :('$char'(111), :('$char'(108), []))), _S ], _T, _U ), :('$char'(10), []) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$snd',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _FA, _GA ) ], _HA, _IA ))), _JA, _KA):-
        unifyHnfs(_C, tkCol(_S, _L), _JA, _KA).

% tkConfCollection2tcl
'$tkConfCollection2tcl'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkConfCollection2tcl_2'(_A, _F, _C, _G, _E).
'$tkConfCollection2tcl_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$tkConfCollection2tcl_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        hnf(_F, _I, _H, _J),
        '$tkConfCollection2tcl_2_2.1_:'(_A, _I, _G, _C, _J, _E).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkCenter, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(99), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(101), :('$char'(114), :('$char'(32), []))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkLeft, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(119), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkRight, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(101), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkTop, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(110), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkBottom, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(119), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkExpand, _E, _G),
        $++(:('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(49), :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(105), :('$char'(108), :('$char'(108), :('$char'(32), :('$char'(98), :('$char'(111), :('$char'(116), :('$char'(104), :('$char'(32), []))))))))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkExpandX, _E, _G),
        $++(:('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(49), :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(105), :('$char'(108), :('$char'(108), :('$char'(32), :('$char'(120), :('$char'(32), [])))))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkExpandY, _E, _G),
        $++(:('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(49), :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(105), :('$char'(108), :('$char'(108), :('$char'(32), :('$char'(121), :('$char'(32), [])))))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).

% tkConf2tcl
'$tkConf2tcl'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_D, _H, _F, _I),
        '$tkConf2tcl_4'(_A, _B, _C, _H, _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkActive(_H), _F, _I),
        '$if_then'('$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))) ], _N, _O ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))) ], _P, _Q ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))) ], _R, _S ), '$$susp'( '$$eqFun',  [ _A, :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$if_then_else',  [ _H, '$$susp'( $++,  [ _C, :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(115), :('$char'(116), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(110), :('$char'(111), :('$char'(114), :('$char'(109), :('$char'(97), :('$char'(108), :('$char'(10), []))))))))))))))))))))))))) ], _FA, _GA ), '$$susp'( $++,  [ _C, :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(115), :('$char'(116), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(100), :('$char'(105), :('$char'(115), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(100), :('$char'(10), []))))))))))))))))))))))))))) ], _HA, _IA ) ], _JA, _KA ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkAnchor(_H), _F, _I),
        '$if_then'('$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))) ], _N, _O ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))) ], _P, _Q ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))) ], _R, _S ), '$$susp'( '$$eqFun',  [ _A, :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( $++,  [ _C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), []))))))))))))))))))), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _FA, _GA ) ], _HA, _IA ) ], _JA, _KA ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkBackground(_H), _F, _I),
        $++(_J, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(98), :('$char'(97), :('$char'(99), :('$char'(107), :('$char'(103), :('$char'(114), :('$char'(111), :('$char'(117), :('$char'(110), :('$char'(100), :('$char'(32), []))))))))))))))))))))))), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _K, _L ) ], _M, _N ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkCmd(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, _O, _N, _P),
        '$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_O, _K, _B, _C, _H, _E, _P, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkHeight(_H), _F, _I),
        '$if_then'('$$susp'( '$not',  [ '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), []))))))) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))) ], _N, _O ), '$$susp'( '$$eqFun',  [ _A, :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ), '$$susp'( $++,  [ _C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(104), :('$char'(101), :('$char'(105), :('$char'(103), :('$char'(104), :('$char'(116), :('$char'(32), []))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _H ], _Z, _AA ), :('$char'(10), []) ], _BA, _CA ) ], _DA, _EA ) ], _FA, _GA ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkInit(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 104, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 101, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 99, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 107, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 98, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 117, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 116, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 111, _PB, _QB),
        hnf(_MB, :(_RB, _SB), _QB, _TB),
        hnf(_RB, '$char'(_UB), _TB, _VB),
        hnf(_UB, 110, _VB, _WB),
        hnf(_SB, [], _WB, _XB),
        $++(:('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _C ], _YB, _ZB ), '$$susp'( $++,  [ :('$char'(32), :('$char'(34), [])), '$$susp'( $++,  [ _H, :('$char'(34), :('$char'(10), [])) ], _AC, _BC ) ], _CC, _DC ) ], _EC, _FC ), _E, _XB, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkItems(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 97, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 110, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 118, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 97, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 115, _RA, _SA),
        hnf(_OA, [], _SA, _TA),
        '$tkcitems2tcl'(_C, _H, _E, _TA, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkList(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 108, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 105, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 115, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 116, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 98, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 111, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 120, _XA, _YA),
        hnf(_UA, [], _YA, _ZA),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(100), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(48), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(10), [])))))))))))))), '$$susp'( '$setlistelems',  [ _H, _C ], _AB, _BB ) ], _CB, _DB ), _E, _ZA, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkMenu(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 109, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 101, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 110, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 117, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 98, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 117, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 116, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 111, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 110, _PB, _QB),
        hnf(_MB, [], _QB, _RB),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(32), []))))))))))))))))), '$$susp'( $++,  [ _C, '$$susp'( $++,  [ :('$char'(46), :('$char'(97), :('$char'(10), []))), '$$susp'( '$tkMenu2tcl',  [ '$$susp'( $++,  [ _C, :('$char'(46), :('$char'(97), [])) ], _SB, _TB ), _H ], _UB, _VB ) ], _WB, _XB ) ], _YB, _ZB ) ], _AC, _BC ), _E, _RB, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkRef(_H), _F, _I),
        '$if_then'('$$susp'( '$$eqFun',  [ _H, tkRefLabel(_B, '$$susp'( '$tkLabel2Refname',  [ _C ], _J, _K ), _A) ], _L, _M ), [], _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkText(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 104, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 101, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 99, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 107, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 98, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 117, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 116, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 111, _PB, _QB),
        hnf(_MB, :(_RB, _SB), _QB, _TB),
        hnf(_RB, '$char'(_UB), _TB, _VB),
        hnf(_UB, 110, _VB, _WB),
        hnf(_SB, [], _WB, _XB),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _H ], _YB, _ZB ), :('$char'(34), :('$char'(10), [])) ], _AC, _BC ) ], _CC, _DC ), _E, _XB, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkText(_H), _F, _I),
        $++(:('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _C ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(34), [])), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _H ], _L, _M ), :('$char'(34), :('$char'(10), [])) ], _N, _O ) ], _P, _Q ) ], _R, _S ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkWidth(_H), _F, _I),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(119), :('$char'(105), :('$char'(100), :('$char'(116), :('$char'(104), :('$char'(32), [])))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _H ], _J, _K ), :('$char'(10), []) ], _L, _M ) ], _N, _O ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkTcl(_H), _F, _I),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), []))))))))))), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _J, _K ) ], _L, _M ), _E, _I, _G).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 99, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 104, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 101, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 99, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 107, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 98, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 117, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 116, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 111, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 110, _PB, _QB),
        hnf(_MB, [], _QB, _RB),
        $++(_D, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))) ], _SB, _TB ) ], _UB, _VB ), _F, _RB, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 101, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 110, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 116, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 114, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 121, _FA, _GA),
        hnf(_CA, [], _GA, _HA),
        $++(:('$char'(98), :('$char'(105), :('$char'(110), :('$char'(100), :('$char'(32), []))))), '$$susp'( $++,  [ _D, '$$susp'( $++,  [ :('$char'(32), :('$char'(60), :('$char'(82), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(62), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ), _F, _HA, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 115, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 97, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 108, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 101, _FA, _GA),
        hnf(_CA, [], _GA, _HA),
        $++(_IA, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(125), :('$char'(10), []))) ], _JA, _KA ) ], _LA, _MA ), _F, _HA, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 108, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 105, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 115, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 116, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 98, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 111, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 120, _RA, _SA),
        hnf(_OA, [], _SA, _TA),
        $++(:('$char'(98), :('$char'(105), :('$char'(110), :('$char'(100), :('$char'(32), []))))), '$$susp'( $++,  [ _D, '$$susp'( $++,  [ :('$char'(32), :('$char'(60), :('$char'(66), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(80), :('$char'(114), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(45), :('$char'(49), :('$char'(62), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), []))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(125), :('$char'(10), []))) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ), _F, _TA, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 116, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 101, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 120, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 116, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 101, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 100, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 105, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 116, _XA, _YA),
        hnf(_UA, [], _YA, _ZA),
        $++(:('$char'(98), :('$char'(105), :('$char'(110), :('$char'(100), :('$char'(32), []))))), '$$susp'( $++,  [ _D, '$$susp'( $++,  [ :('$char'(32), :('$char'(60), :('$char'(66), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(80), :('$char'(114), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(45), :('$char'(49), :('$char'(62), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), []))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(125), :('$char'(10), []))) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ), _F, _ZA, _H).

% setlistelems
'$setlistelems'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$setlistelems_1'(_F, _B, _C, _G, _E).
'$setlistelems_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$setlistelems_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        $++(_B, '$$susp'( $++,  [ :('$char'(32), :('$char'(105), :('$char'(110), :('$char'(115), :('$char'(101), :('$char'(114), :('$char'(116), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(34), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _F ], _I, _J ), '$$susp'( $++,  [ :('$char'(34), :('$char'(10), [])), '$$susp'( '$setlistelems',  [ _G, _B ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).

% tkMenu2tcl
'$tkMenu2tcl'(_A, _B, _C, _D, _E):-
        $++(:('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(32), []))))), '$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(97), :('$char'(114), :('$char'(111), :('$char'(102), :('$char'(102), :('$char'(32), :('$char'(102), :('$char'(97), :('$char'(108), :('$char'(115), :('$char'(101), :('$char'(10), [])))))))))))))))), '$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(32), :('$char'(100), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(48), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(10), [])))))))))))))), '$$susp'( '$setmenuelems',  [ _B, 0.0 ], _F, _G ) ], _H, _I ) ], _J, _K ) ], _L, _M ) ], _N, _O ), _C, _D, _E).

% setmenuelems
'$setmenuelems'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$setmenuelems_1'(_F, _B, _C, _G, _E).
'$setmenuelems_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$setmenuelems_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        hnf(_F, _I, _H, _J),
        '$setmenuelems_1_1.1_:'(_I, _G, _B, _C, _J, _E).
'$setmenuelems_1_1.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, tkMButton(_G, _H), _E, _I),
        $++(_J, '$$susp'( $++,  [ :('$char'(32), :('$char'(97), :('$char'(100), :('$char'(100), :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(45), :('$char'(76), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(34), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _H ], _K, _L ), '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), []))))))))))))))))))))))))), '$$susp'( $++,  [ _J, '$$susp'( $++,  [ :('$char'(46), []), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _C ], _M, _N ), '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))), '$$susp'( '$setmenuelems',  [ _B, '$$susp'( $+,  [ _C, 1.0 ], _O, _P ) ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ), _D, _I, _F).
'$setmenuelems_1_1.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, tkMSeparator, _E, _G),
        $++(_H, '$$susp'( $++,  [ :('$char'(32), :('$char'(97), :('$char'(100), :('$char'(100), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(112), :('$char'(97), :('$char'(114), :('$char'(97), :('$char'(116), :('$char'(111), :('$char'(114), :('$char'(10), []))))))))))))))), '$$susp'( '$setmenuelems',  [ _B, '$$susp'( $+,  [ _C, 1.0 ], _I, _J ) ], _K, _L ) ], _M, _N ), _D, _G, _F).
'$setmenuelems_1_1.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, tkMMenuButton(_G, _H), _E, _I),
        $++(_J, '$$susp'( $++,  [ :('$char'(32), :('$char'(97), :('$char'(100), :('$char'(100), :('$char'(32), :('$char'(99), :('$char'(97), :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(100), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(34), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _G ], _K, _L ), '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(45), :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(32), [])))))))), '$$susp'( $++,  [ _J, '$$susp'( $++,  [ :('$char'(46), :('$char'(97), :('$char'(10), []))), '$$susp'( $++,  [ '$$susp'( '$tkMenu2tcl',  [ '$$susp'( $++,  [ _J, :('$char'(46), :('$char'(97), [])) ], _M, _N ), _H ], _O, _P ), '$$susp'( '$setmenuelems',  [ _B, '$$susp'( $+,  [ _C, 1.0 ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ), _D, _I, _F).

% tkConfs2handler
'$tkConfs2handler'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkConfs2handler_2'(_A, _F, _C, _G, _E).
'$tkConfs2handler_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$tkConfs2handler_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        hnf(_F, _I, _H, _J),
        '$tkConfs2handler_2_2.1_:'(_A, _I, _G, _C, _J, _E).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, :('$$tup'(','(_A, _D)), '$$susp'( '$tkConfs2handler',  [ _A, _C ], _E, _F )), _G, _H):-
        unifyHnfs(_B, tkCmd(_D), _G, _H).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkActive(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkAnchor(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkBackground(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkHeight(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkInit(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkItems(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkList(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkMenu(_G), _E, _H),
        $++('$$susp'( '$tkMenu2handler',  [ _A, _G, 0.0 ], _I, _J ), '$$susp'( '$tkConfs2handler',  [ _A, _C ], _K, _L ), _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkRef(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkText(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkWidth(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkTcl(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).

% tkMenu2handler
'$tkMenu2handler'(_A, _B, _C, _D, _E, _F):-
        hnf(_B, _G, _E, _H),
        '$tkMenu2handler_2'(_A, _G, _C, _D, _H, _F).
'$tkMenu2handler_2'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_B, [], _D, _E).
'$tkMenu2handler_2'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, :(_G, _H), _E, _I),
        hnf(_G, _J, _I, _K),
        '$tkMenu2handler_2_2.1_:'(_A, _J, _H, _C, _D, _K, _F).
'$tkMenu2handler_2_2.1_:'(_A, _B, _C, _D, :('$$tup'(','('$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(46), :('$char'(97), :('$char'(46), []))), '$$susp'( '$intTostr',  [ _D ], _E, _F ) ], _G, _H ) ], _I, _J ), _K)), '$$susp'( '$tkMenu2handler',  [ _A, _C, '$$susp'( $+,  [ _D, 1.0 ], _L, _M ) ], _N, _O )), _P, _Q):-
        unifyHnfs(_B, tkMButton(_K, _R), _P, _Q).
'$tkMenu2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_B, tkMSeparator, _F, _H),
        '$tkMenu2handler'(_A, _C, '$$susp'( $+,  [ _D, 1.0 ], _I, _J ), _E, _H, _G).
'$tkMenu2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_B, tkMMenuButton(_H, _I), _F, _J),
        $++('$$susp'( '$tkMenu2handler',  [ '$$susp'( $++,  [ _A, :('$char'(46), :('$char'(97), [])) ], _K, _L ), _I, 0.0 ], _M, _N ), '$$susp'( '$tkMenu2handler',  [ _A, _C, '$$susp'( $+,  [ _D, 1.0 ], _O, _P ) ], _Q, _R ), _E, _J, _G).

% tkConfs2tcl
'$tkConfs2tcl'(_A, _B, _C, _D, '$$tup'(','('$$susp'( '$$apply',  [ '$$susp'( '$concat',  [], _E, _F ), '$$susp'( '$map',  [ tkConf2tcl(_A, _B, _C), _D ], _G, _H ) ], _I, _J ), '$$susp'( '$tkConfs2handler',  [ _C, _D ], _K, _L ))), _M, _M).

% tkcitems2tcl
'$tkcitems2tcl'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkcitems2tcl_2'(_A, _F, _C, _G, _E).
'$tkcitems2tcl_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$tkcitems2tcl_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        $++('$$susp'( '$tkcitem',  [ _A, _F ], _I, _J ), '$$susp'( '$tkcitems2tcl',  [ _A, _G ], _K, _L ), _C, _H, _E).

% tkcitem
'$tkcitem'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkcitem_2'(_A, _F, _C, _G, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkLine(_F, _G), _D, _H),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(108), :('$char'(105), :('$char'(110), :('$char'(101), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ _F ], _I, _J ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _G, :('$char'(10), []) ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkPolygon(_F, _G), _D, _H),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(112), :('$char'(111), :('$char'(108), :('$char'(121), :('$char'(103), :('$char'(111), :('$char'(110), :('$char'(32), [])))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ _F ], _I, _J ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _G, :('$char'(10), []) ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkRectangle(_F, _G, _H), _D, _I),
        hnf(_F, '$$tup'(_J), _I, _K),
        hnf(_J, ','(_L, _M), _K, _N),
        hnf(_G, '$$tup'(_O), _N, _P),
        hnf(_O, ','(_Q, _R), _P, _S),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(99), :('$char'(116), :('$char'(97), :('$char'(110), :('$char'(103), :('$char'(108), :('$char'(101), :('$char'(32), [])))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ :('$$tup'(','(_L, _M)), :('$$tup'(','(_Q, _R)), [])) ], _T, _U ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ), _C, _S, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkOval(_F, _G, _H), _D, _I),
        hnf(_F, '$$tup'(_J), _I, _K),
        hnf(_J, ','(_L, _M), _K, _N),
        hnf(_G, '$$tup'(_O), _N, _P),
        hnf(_O, ','(_Q, _R), _P, _S),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(79), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ :('$$tup'(','(_L, _M)), :('$$tup'(','(_Q, _R)), [])) ], _T, _U ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ), _C, _S, _E).

% tkShowCoords
'$tkShowCoords'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$tkShowCoords_1'(_E, _B, _F, _D).
'$tkShowCoords_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$tkShowCoords_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        $++('$$susp'( '$intTostr',  [ _J ], _M, _N ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _K ], _O, _P ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( '$tkShowCoords',  [ _F ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ), _B, _L, _D).

% tkLabel2Refname
'$tkLabel2Refname'(_A, _B, _C, _D):-
        '$map'(aux, _A, _B, _C, _D).

% aux
'$aux'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, '$char'(46) ], _E, _F ), '$char'(95), _A, _B, _C, _D).

% tkRefname2Label
'$tkRefname2Label'(_A, _B, _C, _D):-
        '$map'(aux1, _A, _B, _C, _D).

% aux1
'$aux1'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, '$char'(95) ], _E, _F ), '$char'(46), _A, _B, _C, _D).

% tks2tcl
'$tks2tcl'(_A, _B, _C, _D, '$$tup'(','(_E, _F)), _G, _H):-
        hnf(_D, _I, _G, _J),
        '$tks2tcl_4'(_A, _B, _C, _I, '$$tup'(','(_E, _F)), _J, _H).
'$tks2tcl_4'(_A, _B, _C, _D, '$$tup'(','([], [])), _E, _F):-
        unifyHnfs(_D, [], _E, _F).
'$tks2tcl_4'(_A, _B, _C, _D, '$$tup'(','('$$susp'( $++,  [ '$$susp'( '$fst',  [ '$$susp'( '$tk2tcl',  [ _A, '$$susp'( $++,  [ _B, :('$char'(46), :('$$susp'( '$chr',  [ _C ], _E, _F ), [])) ], _G, _H ), _I ], _J, _K ) ], _L, _M ), '$$susp'( '$fst',  [ '$$susp'( '$tks2tcl',  [ _A, _B, '$$susp'( $+,  [ _C, 1.0 ], _N, _O ), _P ], _Q, _R ) ], _S, _T ) ], _U, _V ), '$$susp'( $++,  [ '$$susp'( '$snd',  [ '$$susp'( '$tk2tcl',  [ _A, '$$susp'( $++,  [ _B, :('$char'(46), :('$$susp'( '$chr',  [ _C ], _W, _X ), [])) ], _Y, _Z ), _I ], _AA, _BA ) ], _CA, _DA ), '$$susp'( '$snd',  [ '$$susp'( '$tks2tcl',  [ _A, _B, '$$susp'( $+,  [ _C, 1.0 ], _EA, _FA ), _P ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ))), _MA, _NA):-
        unifyHnfs(_D, :(_I, _P), _MA, _NA).

% tkslabels
'$tkslabels'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$tkslabels_3'(_A, _B, _G, _D, _H, _F).
'$tkslabels_3'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$tkslabels_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        $++('$$susp'( $++,  [ _A, :('$char'(46), :('$$susp'( '$chr',  [ _B ], _J, _K ), :('$char'(32), []))) ], _L, _M ), '$$susp'( '$tkslabels',  [ _A, '$$susp'( $+,  [ _B, 1.0 ], _N, _O ), _H ], _P, _Q ), _D, _I, _F).

% tkmain2tcl
'$tkmain2tcl'(_A, _B, '$$tup'(','('$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(123), :('$char'(108), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(115), :('$char'(32), :('$char'(34), :('$char'(58), :('$char'(69), :('$char'(86), :('$char'(84), :('$char'(36), :('$char'(108), :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))))))))))))))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(123), :('$char'(108), :('$char'(32), :('$char'(118), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(36), :('$char'(108), :('$char'(32), :('$char'(125), :('$char'(10), [])))))))))))))))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(32), :('$char'(123), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(32), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(117), :('$char'(101), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(115), :('$char'(32), :('$char'(34), :('$char'(58), :('$char'(86), :('$char'(65), :('$char'(82), :('$char'(36), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(37), :('$char'(91), :('$char'(115), :('$char'(116), :('$char'(114), :('$char'(105), :('$char'(110), :('$char'(103), :('$char'(32), :('$char'(108), :('$char'(101), :('$char'(110), :('$char'(103), :('$char'(116), :('$char'(104), :('$char'(32), :('$char'(36), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(117), :('$char'(101), :('$char'(93), :('$char'(42), :('$char'(36), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(117), :('$char'(101), :('$char'(34), :('$char'(125), :('$char'(10), []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), '$$susp'( '$fst',  [ '$$susp'( '$tk2tcl',  [ _A, [], _B ], _C, _D ) ], _E, _F ) ], _G, _H ) ], _I, _J ) ], _K, _L ), '$$susp'( '$snd',  [ '$$susp'( '$tk2tcl',  [ _A, [], _B ], _M, _N ) ], _O, _P ))), _Q, _Q).

% debugTcl
'$debugTcl'(_A, _B, _C, _D):-
        '$putStrLn'('$$susp'( '$fst',  [ '$$susp'( '$tkmain2tcl',  [ _E, _A ], _F, _G ) ], _H, _I ), _B, _C, _D).

% forkWish
'$forkWish'(_A, _B, _C, _D, _E):-
        '$do'( [ _F ], [ openWish(escape_tcl(_A)), writeWish(_F, _B) ],_C,_D,_E).

% runWidget
'$runWidget'(_A, _B, _C, _D, _E):-
        '$do'( [ _F ], [ openWish(escape_tcl(_A)), initSchedule(>>, done, _B, _F, aux4) ],_C,_D,_E).

% aux4
'$aux4'(_A, _B, _C, _D):-
        '$done'(_B, _C, _D).

% runWidgetInit
'$runWidgetInit'(_A, _B, _C, _D, _E, _F):-
        '$do'( [ _G ], [ openWish(escape_tcl(_A)), initSchedule(>>, done, _B, _G, _C) ],_D,_E,_F).

% runWidgetPassive
'$runWidgetPassive'(_A, _B, _C, _D, _E):-
        '$do'( [ _F, _G ], [ openWish(escape_tcl(_A)), writeWish(_F, fst(tkmain2tcl(_F, _B))), return(_F) ],_C,_D,_E).

% initSchedule
'$initSchedule'(_A, _B, _C, _D, _E, _F, _G, _H):-
        $>>('$$susp'( '$writeWish',  [ _D, '$$susp'( '$fst',  [ '$$susp'( '$tkmain2tcl',  [ _D, _C ], _I, _J ) ], _K, _L ) ], _M, _N ), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, '$$susp'( '$$apply',  [ _E, _D ], _O, _P ) ], _Q, _R ), '$$susp'( '$tkSchedule',  [ _A, _B, '$$susp'( '$snd',  [ '$$susp'( '$tkmain2tcl',  [ _D, _C ], _S, _T ) ], _U, _V ), _D ], _W, _X ) ], _Y, _Z ), _F, _G, _H).

% tkSchedule
'$tkSchedule'(_A, _B, _C, _D, _E, _F, _G):-
        $>>=('$$susp'( '$readWish',  [ _D ], _H, _I ), aux2(_A, _B, _C, _D), _E, _F, _G).

% aux2
'$aux2'(_A, _B, _C, _D, _E, _F, _G, _H):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _E, :('$char'(58), :('$char'(69), :('$char'(88), :('$char'(73), :('$char'(84), []))))) ], _I, _J ), '$$susp'( '$tkTerminateWish',  [ _B, _D ], _K, _L ), '$$susp'( '$if_then_else',  [ '$$susp'( '$$eqFun',  [ '$$susp'( '$take',  [ 4.0, _E ], _M, _N ), :('$char'(58), :('$char'(69), :('$char'(86), :('$char'(84), [])))) ], _O, _P ), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, '$$susp'( '$tkSelectEvent',  [ _B, '$$susp'( '$drop',  [ 4.0, _E ], _Q, _R ), _C, _D ], _S, _T ) ], _U, _V ), '$$susp'( '$tkSchedule',  [ _A, _B, _C, _D ], _W, _X ) ], _Y, _Z ), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, '$$susp'( '$if_then',  [ '$$susp'( '$not',  [ '$$susp'( '$tkShowErrors',  [], _AA, _BA ) ], _CA, _DA ), _B ], _EA, _FA ) ], _GA, _HA ), '$$susp'( '$done',  [], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ), _F, _G, _H).

% tkTerminateWish
'$tkTerminateWish'(_A, _B, _C, _D, _E):-
        $>>('$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _B, :('$char'(101), :('$char'(120), :('$char'(105), :('$char'(116), [])))) ], _F, _G ), '$$susp'( '$closeWish',  [ _B ], _H, _I ) ], _J, _K ), _A, _C, _D, _E).

% tkSelectEvent
'$tkSelectEvent'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_C, :(_H, _I), _F, _J),
        hnf(_H, '$$tup'(_K), _J, _L),
        hnf(_K, ','(_M, _N), _L, _O),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _B, _M ], _P, _Q ), '$$susp'( '$$apply',  [ _N, _D ], _R, _S ), '$$susp'( '$tkSelectEvent',  [ _A, _B, _I, _D ], _T, _U ), _E, _O, _G).

% tkGetVar
'$tkGetVar'(_A, _B, _C, _D, _E, _F):-
        $>>('$$susp'( '$writeWish',  [ _B, '$$susp'( $++,  [ :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(32), []))))))), '$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(32), :('$char'(91), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))))), '$$susp'( $++,  [ _A, :('$char'(93), []) ], _G, _H ) ], _I, _J ) ], _K, _L ) ], _M, _N ) ], _O, _P ), '$$susp'( '$tkGetVarMsg',  [ _A, _B, _C ], _Q, _R ), _D, _E, _F).

% tkGetVarMsg
'$tkGetVarMsg'(_A, _B, _C, _D, _E, _F):-
        '$do'( [ _G ], [ readWish(_B), aux3(_A, _B, _C, _G) ],_D,_E,_F).

% aux3
'$aux3'(_A, _B, _C, _D, _E, _F, _G):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ '$$susp'( '$takeWhile',  [ flip('$notEqFun', '$char'(37)), _D ], _H, _I ), '$$susp'( $++,  [ :('$char'(58), :('$char'(86), :('$char'(65), :('$char'(82), [])))), _A ], _J, _K ) ], _L, _M ), '$$susp'( '$do',  [ '.'(_C, []), '.'(tkGetVarValue(tkParseInt(tail(dropWhile(flip('$notEqFun', '$char'(37)), _D)), 0.0), tail(dropWhile(flip('$notEqFun', '$char'(42)), _D)), _B), '.'(done, [])) ], _N, _O ), '$$susp'( '$tkGetVarMsg',  [ _A, _B, _C ], _P, _Q ), _E, _F, _G).

% tkGetVarValue
'$tkGetVarValue'(_A, _B, _C, _D, _E, _F):-
        '$if_then_else'('$$susp'( $<,  [ '$$susp'( '$length',  [ _B ], _G, _H ), _A ], _I, _J ), '$$susp'( '$do',  [ '.'(_K, '.'(_L, [])), '.'(readWish(_C), '.'(tkGetVarValue(-(_A, +(length(_B), 1.0)), _K, _C), '.'(return(++(_B, ++(:('$char'(10), []), _L))), []))) ], _M, _N ), '$$susp'( '$if_then',  [ '$$susp'( '$not',  [ '$$susp'( '$and',  [ '$$susp'( $>,  [ '$$susp'( '$length',  [ _B ], _O, _P ), _A ], _Q, _R ), '$$susp'( '$tkShowErrors',  [], _S, _T ) ], _U, _V ) ], _W, _X ), '$$susp'( '$return',  [ _B ], _Y, _Z ) ], _AA, _BA ), _D, _E, _F).

% tkParseInt
'$tkParseInt'(_A, _B, _C, _D, _E):-
        hnf(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _F, '$char'(42) ], _I, _J ), _B, '$$susp'( '$tkParseInt',  [ _G, '$$susp'( $-,  [ '$$susp'( $+,  [ '$$susp'( $*,  [ _B, 10.0 ], _K, _L ), '$$susp'( '$ord',  [ _F ], _M, _N ) ], _O, _P ), '$$susp'( '$ord',  [ '$char'(48) ], _Q, _R ) ], _S, _T ) ], _U, _V ), _C, _H, _E).

% checkWishConsistency
'$checkWishConsistency'(_A, _B, _C, _D, _E):-
        '$if_then'('$$susp'( '$$eqFun',  [ _A, _B ], _F, _G ), true, _C, _D, _E).

% escape_tcl
'$escape_tcl'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$escape_tcl_1'(_E, _B, _F, _D).
'$escape_tcl_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$escape_tcl_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        '$if_then_else'('$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(91) ], _H, _I ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(93) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(36) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(34) ], _N, _O ), '$$susp'( '$$eqFun',  [ _E, '$char'(92) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ), :('$char'(92), :(_E, '$$susp'( '$escape_tcl',  [ _F ], _Z, _AA ))), :(_E, '$$susp'( '$escape_tcl',  [ _F ], _BA, _CA )), _B, _G, _D).

% tkVoid
'$tkVoid'(_A, _B, _C, _D):-
        '$done'(_B, _C, _D).

% tkExit
'$tkExit'(_A, _B, _C, _D):-
        $>>('$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _A, :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(115), :('$char'(32), :('$char'(34), :('$char'(58), :('$char'(69), :('$char'(88), :('$char'(73), :('$char'(84), :('$char'(34), [])))))))))))) ], _E, _F ), '$$susp'( '$writeWish',  [ _A, :('$char'(101), :('$char'(120), :('$char'(105), :('$char'(116), [])))) ], _G, _H ) ], _I, _J ), '$$susp'( '$done',  [], _K, _L ), _B, _C, _D).

% tkGetValue
'$tkGetValue'(_A, _B, _C, _D, _E):-
        hnf(_A, tkRefLabel(_F, _G, _H), _D, _I),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _F, _B ], _J, _K ), '$$susp'( $>>,  [ '$$susp'( '$tkGetVar',  [ _G, _B, _L ], _M, _N ), '$$susp'( '$return',  [ _L ], _O, _P ) ], _Q, _R ), _C, _I, _E).

% tkSetValue
'$tkSetValue'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, tkRefLabel(_G, _H, _I), _E, _J),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _G, _C ], _K, _L ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _C, '$$susp'( $++,  [ :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))), '$$susp'( $++,  [ _H, '$$susp'( $++,  [ :('$char'(32), :('$char'(34), [])), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _B ], _M, _N ), :('$char'(34), []) ], _O, _P ) ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ), '$$susp'( '$done',  [], _Y, _Z ) ], _AA, _BA ), _D, _J, _F).

% tkUpdate
'$tkUpdate'(_A, _B, _C, _D, _E, _F):-
        '$do'( [ _G ], [ tkGetValue(_B, _C), tkSetValue(_B, '$apply'(_A, _G), _C) ],_D,_E,_F).

% tkConfig
'$tkConfig'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, tkRefLabel(_G, _H, _I), _E, _J),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _G, _C ], _K, _L ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _C, '$$susp'( '$tkConf2tcl',  [ _I, _G, '$$susp'( '$tkRefname2Label',  [ _H ], _M, _N ), _B ], _O, _P ) ], _Q, _R ), '$$susp'( '$done',  [], _S, _T ) ], _U, _V ), _D, _J, _F).

% tkFocus
'$tkFocus'(_A, _B, _C, _D, _E):-
        hnf(_A, tkRefLabel(_F, _G, _H), _D, _I),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _F, _B ], _J, _K ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _B, '$$susp'( $++,  [ :('$char'(102), :('$char'(111), :('$char'(99), :('$char'(117), :('$char'(115), :('$char'(32), [])))))), '$$susp'( '$tkRefname2Label',  [ _G ], _L, _M ) ], _N, _O ) ], _P, _Q ), '$$susp'( '$done',  [], _R, _S ) ], _T, _U ), _C, _I, _E).

% tkAddCanvas
'$tkAddCanvas'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, tkRefLabel(_G, _H, _I), _E, _J),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _G, _C ], _K, _L ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _C, '$$susp'( '$tkConf2tcl',  [ _I, _G, '$$susp'( '$tkRefname2Label',  [ _H ], _M, _N ), tkItems(_B) ], _O, _P ) ], _Q, _R ), '$$susp'( '$done',  [], _S, _T ) ], _U, _V ), _D, _J, _F).


/***********   CONSTRUCTORS AND FUNCTIONS   ***********/

constr(',', 2, ->(_A, ->(_B, ','(_A, _B))), ','(_A, _B)).
constr('$$tup', 1, ->(','(_A, _B), '$$tuple'(','(_A, _B))), '$$tuple'(','(_A, _B))).
constr([], 0, :(_A, []), :(_A, [])).
constr(:, 2, ->(_A, ->(:(_A, []), :(_A, []))), :(_A, [])).
constr('$char', 1, ->(_A, char), char).
constr('$io', 1, ->(_A, '$io'(_A)), '$io'(_A)).
constr('$stream', 1, handle, handle).
constr(read, 0, ioMode, ioMode).
constr(write, 0, ioMode, ioMode).
constr(append, 0, ioMode, ioMode).
constr('$channel', 2, channel, channel).
constr('$varmut', 1, varmut, varmut).
constr(tkButton, 2, ->(->(channel, _A), ->(:(tkConfItem(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkCanvas, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkCheckButton, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkEntry, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkLabel, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkListBox, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkMessage, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkMenuButton, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkScale, 3, ->('$num'(int), ->('$num'(int), ->(:(tkConfItem(_A), []), tkWidget(_A)))), tkWidget(_A)).
constr(tkScrollV, 2, ->(tkRefType, ->(:(tkConfItem(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkScrollH, 2, ->(tkRefType, ->(:(tkConfItem(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkTextEdit, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkRow, 2, ->(:(tkConfCollection, []), ->(:(tkWidget(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkCol, 2, ->(:(tkConfCollection, []), ->(:(tkWidget(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkActive, 1, ->(bool, tkConfItem(_A)), tkConfItem(_A)).
constr(tkAnchor, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkBackground, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkCmd, 1, ->(->(channel, _A), tkConfItem(_A)), tkConfItem(_A)).
constr(tkHeight, 1, ->('$num'(int), tkConfItem(_A)), tkConfItem(_A)).
constr(tkInit, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkItems, 1, ->(:(tkCanvasItem, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkList, 1, ->(:(:(char, []), []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkMenu, 1, ->(:(tkMenuItem(_A), []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkRef, 1, ->(tkRefType, tkConfItem(_A)), tkConfItem(_A)).
constr(tkText, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkWidth, 1, ->('$num'(int), tkConfItem(_A)), tkConfItem(_A)).
constr(tkTcl, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkCenter, 0, tkConfCollection, tkConfCollection).
constr(tkLeft, 0, tkConfCollection, tkConfCollection).
constr(tkRight, 0, tkConfCollection, tkConfCollection).
constr(tkTop, 0, tkConfCollection, tkConfCollection).
constr(tkBottom, 0, tkConfCollection, tkConfCollection).
constr(tkExpand, 0, tkConfCollection, tkConfCollection).
constr(tkExpandX, 0, tkConfCollection, tkConfCollection).
constr(tkExpandY, 0, tkConfCollection, tkConfCollection).
constr(tkMButton, 2, ->(->(channel, _A), ->(:(char, []), tkMenuItem(_A))), tkMenuItem(_A)).
constr(tkMSeparator, 0, tkMenuItem(_A), tkMenuItem(_A)).
constr(tkMMenuButton, 2, ->(:(char, []), ->(:(tkMenuItem(_A), []), tkMenuItem(_A))), tkMenuItem(_A)).
constr(tkLine, 2, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), ->(:(char, []), tkCanvasItem)), tkCanvasItem).
constr(tkPolygon, 2, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), ->(:(char, []), tkCanvasItem)), tkCanvasItem).
constr(tkRectangle, 3, ->('$$tuple'(','('$num'(int), '$num'(int))), ->('$$tuple'(','('$num'(int), '$num'(int))), ->(:(char, []), tkCanvasItem))), tkCanvasItem).
constr(tkOval, 3, ->('$$tuple'(','('$num'(int), '$num'(int))), ->('$$tuple'(','('$num'(int), '$num'(int))), ->(:(char, []), tkCanvasItem))), tkCanvasItem).
constr(tkRefLabel, 3, ->(channel, ->(:(char, []), ->(:(char, []), tkRefType))), tkRefType).
constr(true, 0, bool, bool).
constr(false, 0, bool, bool).

funct(uminus, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(abs, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(sqrt, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(ln, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(exp, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(coth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acoth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(+, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(-, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(*, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(min, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(max, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(/, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(float))), '$num'(float)).
funct(**, 2, 2, ->('$num'(_A), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(log, 2, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(^, 2, 2, ->('$num'(_A), ->('$num'(int), '$num'(_A))), '$num'(_A)).
funct(div, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(mod, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(gcd, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(round, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(trunc, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(floor, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(ceiling, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(toReal, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(<, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(<=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(==, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(/=, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(ord, 1, 1, ->(char, '$num'(int)), '$num'(int)).
funct(chr, 1, 1, ->('$num'(int), char), char).
funct(putChar, 1, 1, ->(char, io(unit)), io(unit)).
funct(done, 0, 0, io(unit), io(unit)).
funct(getChar, 0, 0, io(char), io(char)).
funct(return, 1, 1, ->(_A, io(_A)), io(_A)).
funct(>>, 2, 2, ->(io(_A), ->(io(_B), io(_B))), io(_B)).
funct(>>=, 2, 2, ->(io(_A), ->(->(_A, io(_B)), io(_B))), io(_B)).
funct(putStr, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(putStrLn, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(getLine, 0, 0, io(:(char, [])), io(:(char, []))).
funct(cont1, 1, 1, ->(char, io(:(char, []))), io(:(char, []))).
funct(cont2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).
funct(writeFile, 2, 2, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(readFile, 1, 1, ->(:(char, []), io(:(char, []))), io(:(char, []))).
funct(readFileContents, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(openFile, 2, 2, ->(:(char, []), ->(ioMode, io(handle))), io(handle)).
funct(closeFile, 1, 1, ->(handle, io(unit)), io(unit)).
funct(end_of_file, 1, 1, ->(handle, io(bool)), io(bool)).
funct(getCharFile, 1, 1, ->(handle, io(char)), io(char)).
funct(putCharFile, 2, 2, ->(handle, ->(char, io(unit))), io(unit)).
funct(putStrFile, 2, 2, ->(handle, ->(:(char, []), io(unit))), io(unit)).
funct(putStrLnFile, 2, 2, ->(handle, ->(:(char, []), io(unit))), io(unit)).
funct(getLineFile, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(contin1, 2, 2, ->(handle, ->(char, io(:(char, [])))), io(:(char, []))).
funct(contin2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).
funct(openWish, 1, 1, ->(:(char, []), io(channel)), io(channel)).
funct(readWish, 1, 1, ->(channel, io(:(char, []))), io(:(char, []))).
funct(writeWish, 2, 2, ->(channel, ->(:(char, []), io(unit))), io(unit)).
funct(closeWish, 1, 1, ->(channel, io(unit)), io(unit)).
funct(newVar, 1, 1, ->(_A, io(varmut(_A))), io(varmut(_A))).
funct(newVar1, 1, 1, ->(_A, _A), _A).
funct(newVar2, 1, 1, ->(_A, _A), _A).
funct(readVar, 1, 1, ->(varmut(_A), io(_A)), io(_A)).
funct(writeVar, 2, 2, ->(_A, ->(varmut(_A), io(unit))), io(unit)).
funct(writeVar1, 1, 1, ->(_A, _A), _A).
funct(if_then_else, 3, 3, ->(bool, ->(_A, ->(_A, _A))), _A).
funct(if_then, 2, 2, ->(bool, ->(_A, _A)), _A).
funct(flip, 3, 3, ->(->(_A, ->(_B, _C)), ->(_B, ->(_A, _C))), _C).

funct('$apply', 2, 2, ->(->(->(_A, _B), _A), _B), _B).
funct('$eqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct('$notEqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct(and, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(or, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(/\, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(\/, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(not, 1, 1, ->(bool, bool), bool).
funct(andL, 0, 1, ->(:(bool, []), bool), bool).
funct(orL, 0, 1, ->(:(bool, []), bool), bool).
funct('orL\'', 0, 1, ->(:(bool, []), bool), bool).
funct(any, 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct('any\'', 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct(all, 1, 2, ->(->(_A, bool), ->(:(_A, []), bool)), bool).
funct(undefined, 0, 0, _A, _A).
funct(def, 1, _A, ->(_B, bool), bool).
funct(not_undef, 1, _A, ->(_B, bool), bool).
funct(nf, 1, _A, ->(_B, _B), _B).
funct(hnf, 1, _A, ->(_B, _B), _B).
funct(strict, 2, _A, ->(->(_B, _C), ->(_B, _C)), _C).
funct('strict\'', 2, _A, ->(->(_B, _C), ->(_B, _C)), _C).
funct(map, 2, 2, ->(->(_A, _B), ->(:(_A, []), :(_B, []))), :(_B, [])).
funct('.', 3, 3, ->(->(_A, _B), ->(->(_C, _A), ->(_C, _B))), _B).
funct(++, 2, 2, ->(:(_A, []), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct('!!', 2, 2, ->(:(_A, []), ->('$num'(int), _A)), _A).
funct(iterate, 2, 2, ->(->(_A, _A), ->(_A, :(_A, []))), :(_A, [])).
funct(repeat, 1, 1, ->(_A, :(_A, [])), :(_A, [])).
funct(copy, 2, 2, ->('$num'(int), ->(_A, :(_A, []))), :(_A, [])).
funct(filter, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(foldl, 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), _A))), _A).
funct(foldl1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), _A)), _A).
funct('foldl\'', 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), _A))), _A).
funct(scanl, 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), :(_A, [])))), :(_A, [])).
funct(scanl1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct('scanl\'', 3, 3, ->(->(_A, ->(_B, _A)), ->(_A, ->(:(_B, []), :(_A, [])))), :(_A, [])).
funct(foldr, 3, 3, ->(->(_A, ->(_B, _B)), ->(_B, ->(:(_A, []), _B))), _B).
funct(foldr1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), _A)), _A).
funct(scanr, 3, 3, ->(->(_A, ->(_B, _B)), ->(_B, ->(:(_A, []), :(_B, [])))), :(_B, [])).
funct(auxForScanr, 3, _A, ->(->(_B, ->(_C, _C)), ->(_B, ->(:(_C, []), :(_C, [])))), :(_C, [])).
funct(scanr1, 2, 2, ->(->(_A, ->(_A, _A)), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(take, 2, 2, ->('$num'(int), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(drop, 2, 2, ->('$num'(int), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(splitAt, 2, 2, ->('$num'(int), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(auxForSplitAt, 2, _A, ->(_B, ->('$$tuple'(','(:(_B, []), _C)), '$$tuple'(','(:(_B, []), _C)))), '$$tuple'(','(:(_B, []), _C))).
funct(takeWhile, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(takeUntil, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(dropWhile, 2, 2, ->(->(_A, bool), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(span, 2, 2, ->(->(_A, bool), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(auxForSpan, 2, _A, ->(_B, ->('$$tuple'(','(:(_B, []), _C)), '$$tuple'(','(:(_B, []), _C)))), '$$tuple'(','(:(_B, []), _C))).
funct(break, 1, 2, ->(->(_A, bool), ->(:(_A, []), '$$tuple'(','(:(_A, []), :(_A, []))))), '$$tuple'(','(:(_A, []), :(_A, [])))).
funct(zipWith, 3, 3, ->(->(_A, ->(_B, _C)), ->(:(_A, []), ->(:(_B, []), :(_C, [])))), :(_C, [])).
funct(zip, 2, 2, ->(:(_A, []), ->(:(_B, []), :('$$tuple'(','(_A, _B)), []))), :('$$tuple'(','(_A, _B)), [])).
funct(mkpair, 2, 2, ->(_A, ->(_B, '$$tuple'(','(_A, _B)))), '$$tuple'(','(_A, _B))).
funct(unzip, 1, 1, ->(:('$$tuple'(','(_A, _B)), []), '$$tuple'(','(:(_A, []), :(_B, [])))), '$$tuple'(','(:(_A, []), :(_B, [])))).
funct(auxForUnzip, 3, _A, ->(_B, ->(_C, ->('$$tuple'(','(:(_B, []), :(_C, []))), '$$tuple'(','(:(_B, []), :(_C, [])))))), '$$tuple'(','(:(_B, []), :(_C, [])))).
funct(until, 3, 3, ->(->(_A, bool), ->(->(_A, _A), ->(_A, _A))), _A).
funct('until\'', 2, 3, ->(->(_A, bool), ->(->(_A, _A), ->(_A, :(_A, [])))), :(_A, [])).
funct(const, 2, 2, ->(_A, ->(_B, _A)), _A).
funct(id, 1, 1, ->(_A, _A), _A).
funct(//, 2, 2, ->(_A, ->(_A, _A)), _A).
funct(curry, 3, 3, ->(->('$$tuple'(','(_A, _B)), _C), ->(_A, ->(_B, _C))), _C).
funct(uncurry, 2, 2, ->(->(_A, ->(_B, _C)), ->('$$tuple'(','(_A, _B)), _C)), _C).
funct(fst, 1, 1, ->('$$tuple'(','(_A, _B)), _A), _A).
funct(snd, 1, 1, ->('$$tuple'(','(_A, _B)), _B), _B).
funct(fst3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _A), _A).
funct(snd3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _B), _B).
funct(thd3, 1, 1, ->('$$tuple'(','(_A, ','(_B, _C))), _C), _C).
funct(substract, 0, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(even, 1, 1, ->('$num'(int), bool), bool).
funct(odd, 0, 1, ->('$num'(int), bool), bool).
funct(lcm, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(head, 1, 1, ->(:(_A, []), _A), _A).
funct(last, 1, 1, ->(:(_A, []), _A), _A).
funct(tail, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(init, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(nub, 1, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(length, 1, 1, ->(:(_A, []), '$num'(int)), '$num'(int)).
funct(size, 0, 1, ->(:(_A, []), '$num'(int)), '$num'(int)).
funct(reverse, 0, 1, ->(:(_A, []), :(_A, [])), :(_A, [])).
funct(member, 0, 2, ->(_A, ->(:(_A, []), bool)), bool).
funct(notMember, 0, 2, ->(_A, ->(:(_A, []), bool)), bool).
funct(concat, 0, 1, ->(:(:(_A, []), []), :(_A, [])), :(_A, [])).
funct(transpose, 0, 1, ->(:(:(_A, []), []), :(:(_A, []), [])), :(:(_A, []), [])).
funct(auxForTranspose, 2, _A, ->(:(_B, []), ->(:(:(_B, []), []), :(:(_B, []), []))), :(:(_B, []), [])).
funct(\\, 0, 2, ->(:(_A, []), ->(:(_A, []), :(_A, []))), :(_A, [])).
funct(del, 2, _A, ->(:(_B, []), ->(_B, :(_B, []))), :(_B, [])).
funct(strToint, 1, 1, ->(:(char, []), '$num'(int)), '$num'(int)).
funct(getNumber, 2, _A, ->(:(char, []), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(intTostr, 1, 1, ->('$num'(int), :(char, [])), :(char, [])).
funct(getString, 2, _A, ->('$num'(int), ->(:(char, []), :(char, []))), :(char, [])).
funct(tkShowErrors, 0, _A, bool, bool).
funct(tkRef2Label, 1, _A, ->(tkRefType, :(char, [])), :(char, [])).
funct(tkRef2Wtype, 1, _A, ->(tkRefType, :(char, [])), :(char, [])).
funct(tk2tcl, 3, 3, ->(channel, ->(:(char, []), ->(tkWidget(_A), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _A))), [])))))), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _A))), [])))).
funct(tkConfCollection2tcl, 2, _A, ->(_B, ->(:(tkConfCollection, []), :(char, []))), :(char, [])).
funct(tkConf2tcl, 4, 4, ->(:(char, []), ->(channel, ->(:(char, []), ->(tkConfItem(_A), :(char, []))))), :(char, [])).
funct(setlistelems, 2, _A, ->(:(:(char, []), []), ->(:(char, []), :(char, []))), :(char, [])).
funct(tkMenu2tcl, 2, _A, ->(:(char, []), ->(:(tkMenuItem(_B), []), :(char, []))), :(char, [])).
funct(setmenuelems, 2, _A, ->(:(tkMenuItem(_B), []), ->('$num'(int), :(char, []))), :(char, [])).
funct(tkConfs2handler, 2, 2, ->(:(char, []), ->(:(tkConfItem(_A), []), :('$$tuple'(','(:(char, []), ->(channel, _A))), []))), :('$$tuple'(','(:(char, []), ->(channel, _A))), [])).
funct(tkMenu2handler, 3, _A, ->(:(char, []), ->(:(tkMenuItem(_B), []), ->('$num'(int), :('$$tuple'(','(:(char, []), ->(channel, _B))), [])))), :('$$tuple'(','(:(char, []), ->(channel, _B))), [])).
funct(tkConfs2tcl, 4, 4, ->(:(char, []), ->(channel, ->(:(char, []), ->(:(tkConfItem(_A), []), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _A))), []))))))), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _A))), [])))).
funct(tkcitems2tcl, 2, _A, ->(:(char, []), ->(:(tkCanvasItem, []), :(char, []))), :(char, [])).
funct(tkcitem, 2, _A, ->(:(char, []), ->(tkCanvasItem, :(char, []))), :(char, [])).
funct(tkShowCoords, 1, _A, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), :(char, [])), :(char, [])).
funct(tkLabel2Refname, 1, _A, ->(:(char, []), :(char, [])), :(char, [])).
funct(aux, 1, _A, ->(char, char), char).
funct(tkRefname2Label, 1, _A, ->(:(char, []), :(char, [])), :(char, [])).
funct(aux1, 1, _A, ->(char, char), char).
funct(tks2tcl, 4, _A, ->(channel, ->(:(char, []), ->('$num'(int), ->(:(tkWidget(_B), []), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _B))), []))))))), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _B))), [])))).
funct(tkslabels, 3, _A, ->(:(char, []), ->('$num'(int), ->(:(_B, []), :(char, [])))), :(char, [])).
funct(tkmain2tcl, 2, _A, ->(channel, ->(tkWidget(_B), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _B))), []))))), '$$tuple'(','(:(char, []), :('$$tuple'(','(:(char, []), ->(channel, _B))), [])))).
funct(debugTcl, 1, _A, ->(tkWidget(_B), io(unit)), io(unit)).
funct(forkWish, 2, _A, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(runWidget, 2, 2, ->(:(char, []), ->(tkWidget(io(unit)), io(unit))), io(unit)).
funct(aux4, 1, _A, ->(_B, io(unit)), io(unit)).
funct(runWidgetInit, 3, 3, ->(:(char, []), ->(tkWidget(io(unit)), ->(->(channel, io(unit)), io(unit)))), io(unit)).
funct(runWidgetPassive, 2, 2, ->(:(char, []), ->(tkWidget(_A), io(channel))), io(channel)).
funct(initSchedule, 5, _A, ->(->(io(unit), ->(io(unit), io(unit))), ->(io(unit), ->(tkWidget(io(unit)), ->(channel, ->(->(channel, io(unit)), io(unit)))))), io(unit)).
funct(tkSchedule, 4, _A, ->(->(io(unit), ->(io(unit), io(unit))), ->(io(unit), ->(:('$$tuple'(','(:(char, []), ->(channel, io(unit)))), []), ->(channel, io(unit))))), io(unit)).
funct(aux2, 5, _A, ->(->(io(unit), ->(io(unit), io(unit))), ->(io(unit), ->(:('$$tuple'(','(:(char, []), ->(channel, io(unit)))), []), ->(channel, ->(:(char, []), io(unit)))))), io(unit)).
funct(tkTerminateWish, 2, _A, ->(io(_B), ->(channel, io(_B))), io(_B)).
funct(tkSelectEvent, 4, _A, ->(_B, ->(_C, ->(:('$$tuple'(','(_C, ->(_D, _E))), []), ->(_D, _E)))), _E).
funct(tkGetVar, 3, 3, ->(:(char, []), ->(channel, ->(:(char, []), io(unit)))), io(unit)).
funct(tkGetVarMsg, 3, _A, ->(:(char, []), ->(channel, ->(:(char, []), io(unit)))), io(unit)).
funct(aux3, 4, _A, ->(:(char, []), ->(channel, ->(:(char, []), ->(:(char, []), io(unit))))), io(unit)).
funct(tkGetVarValue, 3, _A, ->('$num'(int), ->(:(char, []), ->(channel, io(:(char, []))))), io(:(char, []))).
funct(tkParseInt, 2, _A, ->(:(char, []), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(checkWishConsistency, 2, _A, ->(_B, ->(_B, bool)), bool).
funct(escape_tcl, 1, _A, ->(:(char, []), :(char, [])), :(char, [])).
funct(tkVoid, 1, 1, ->(channel, io(unit)), io(unit)).
funct(tkExit, 1, 1, ->(channel, io(unit)), io(unit)).
funct(tkGetValue, 2, 2, ->(tkRefType, ->(channel, io(:(char, [])))), io(:(char, []))).
funct(tkSetValue, 3, 3, ->(tkRefType, ->(:(char, []), ->(channel, io(unit)))), io(unit)).
funct(tkUpdate, 3, 3, ->(->(:(char, []), :(char, [])), ->(tkRefType, ->(channel, io(unit)))), io(unit)).
funct(tkConfig, 3, 3, ->(tkRefType, ->(tkConfItem(_A), ->(channel, io(unit)))), io(unit)).
funct(tkFocus, 2, 2, ->(tkRefType, ->(channel, io(unit))), io(unit)).
funct(tkAddCanvas, 3, 3, ->(tkRefType, ->(:(tkCanvasItem, []), ->(channel, io(unit)))), io(unit)).

/************    CODE FOR FUNCIONS HNF    ************/

hnf_susp('$uminus', '.'(_A, []), _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
hnf_susp('$abs', '.'(_A, []), _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
hnf_susp('$sqrt', '.'(_A, []), _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
hnf_susp('$ln', '.'(_A, []), _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
hnf_susp('$exp', '.'(_A, []), _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
hnf_susp('$sin', '.'(_A, []), _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
hnf_susp('$cos', '.'(_A, []), _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
hnf_susp('$tan', '.'(_A, []), _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
hnf_susp('$cot', '.'(_A, []), _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
hnf_susp('$asin', '.'(_A, []), _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
hnf_susp('$acos', '.'(_A, []), _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
hnf_susp('$atan', '.'(_A, []), _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
hnf_susp('$acot', '.'(_A, []), _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
hnf_susp('$sinh', '.'(_A, []), _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
hnf_susp('$cosh', '.'(_A, []), _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
hnf_susp('$tanh', '.'(_A, []), _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
hnf_susp('$coth', '.'(_A, []), _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
hnf_susp('$asinh', '.'(_A, []), _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
hnf_susp('$acosh', '.'(_A, []), _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
hnf_susp('$atanh', '.'(_A, []), _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
hnf_susp('$acoth', '.'(_A, []), _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
hnf_susp($+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
hnf_susp($-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
hnf_susp($*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
hnf_susp('$min', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
hnf_susp('$max', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
hnf_susp($/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
hnf_susp($**, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
hnf_susp('$log', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
hnf_susp($^, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
hnf_susp('$div', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
hnf_susp('$mod', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
hnf_susp('$gcd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
hnf_susp('$round', '.'(_A, []), _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
hnf_susp('$trunc', '.'(_A, []), _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
hnf_susp('$floor', '.'(_A, []), _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
hnf_susp('$ceiling', '.'(_A, []), _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
hnf_susp('$toReal', '.'(_A, []), _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
hnf_susp($<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
hnf_susp($<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
hnf_susp($>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
hnf_susp($>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
hnf_susp($==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
hnf_susp($/=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
hnf_susp('$ord', '.'(_A, []), _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
hnf_susp('$chr', '.'(_A, []), _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
hnf_susp('$putChar', '.'(_A, []), _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
hnf_susp('$done', [], _A, _B, _C):-
        '$done'(_A, _B, _C).
hnf_susp('$getChar', [], _A, _B, _C):-
        '$getChar'(_A, _B, _C).
hnf_susp('$return', '.'(_A, []), _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
hnf_susp($>>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
hnf_susp($>>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
hnf_susp('$putStr', '.'(_A, []), _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
hnf_susp('$putStrLn', '.'(_A, []), _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
hnf_susp('$getLine', [], _A, _B, _C):-
        '$getLine'(_A, _B, _C).
hnf_susp('$cont1', '.'(_A, []), _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
hnf_susp('$cont2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
hnf_susp('$writeFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
hnf_susp('$readFile', '.'(_A, []), _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
hnf_susp('$readFileContents', '.'(_A, []), _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
hnf_susp('$openFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$openFile'(_A, _B, _C, _D, _E).
hnf_susp('$closeFile', '.'(_A, []), _B, _C, _D):-
        '$closeFile'(_A, _B, _C, _D).
hnf_susp('$end_of_file', '.'(_A, []), _B, _C, _D):-
        '$end_of_file'(_A, _B, _C, _D).
hnf_susp('$getCharFile', '.'(_A, []), _B, _C, _D):-
        '$getCharFile'(_A, _B, _C, _D).
hnf_susp('$putCharFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$putCharFile'(_A, _B, _C, _D, _E).
hnf_susp('$putStrFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$putStrFile'(_A, _B, _C, _D, _E).
hnf_susp('$putStrLnFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$putStrLnFile'(_A, _B, _C, _D, _E).
hnf_susp('$getLineFile', '.'(_A, []), _B, _C, _D):-
        '$getLineFile'(_A, _B, _C, _D).
hnf_susp('$contin1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$contin1'(_A, _B, _C, _D, _E).
hnf_susp('$contin2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$contin2'(_A, _B, _C, _D, _E).
hnf_susp('$openWish', '.'(_A, []), _B, _C, _D):-
        '$openWish'(_A, _B, _C, _D).
hnf_susp('$readWish', '.'(_A, []), _B, _C, _D):-
        '$readWish'(_A, _B, _C, _D).
hnf_susp('$writeWish', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeWish'(_A, _B, _C, _D, _E).
hnf_susp('$closeWish', '.'(_A, []), _B, _C, _D):-
        '$closeWish'(_A, _B, _C, _D).
hnf_susp('$newVar', '.'(_A, []), _B, _C, _D):-
        '$newVar'(_A, _B, _C, _D).
hnf_susp('$newVar1', '.'(_A, []), _B, _C, _D):-
        '$newVar1'(_A, _B, _C, _D).
hnf_susp('$newVar2', '.'(_A, []), _B, _C, _D):-
        '$newVar2'(_A, _B, _C, _D).
hnf_susp('$readVar', '.'(_A, []), _B, _C, _D):-
        '$readVar'(_A, _B, _C, _D).
hnf_susp('$writeVar', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeVar'(_A, _B, _C, _D, _E).
hnf_susp('$writeVar1', '.'(_A, []), _B, _C, _D):-
        '$writeVar1'(_A, _B, _C, _D).
hnf_susp('$if_then_else', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
hnf_susp('$if_then', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
hnf_susp('$flip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$$apply', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$apply'(_A, _B, _C, _D, _E).
hnf_susp('$$eqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
hnf_susp('$$notEqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
hnf_susp('$and', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$and'(_A, _B, _C, _D, _E).
hnf_susp('$or', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$or'(_A, _B, _C, _D, _E).
hnf_susp($/\, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/\(_A, _B, _C, _D, _E).
hnf_susp($\/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $\/(_A, _B, _C, _D, _E).
hnf_susp('$not', '.'(_A, []), _B, _C, _D):-
        '$not'(_A, _B, _C, _D).
hnf_susp('$andL', [], _A, _B, _C):-
        '$andL'(_A, _B, _C).
hnf_susp('$orL', [], _A, _B, _C):-
        '$orL'(_A, _B, _C).
hnf_susp('$orL\'', [], _A, _B, _C):-
        '$orL\''(_A, _B, _C).
hnf_susp('$any', '.'(_A, []), _B, _C, _D):-
        '$any'(_A, _B, _C, _D).
hnf_susp('$any\'', '.'(_A, []), _B, _C, _D):-
        '$any\''(_A, _B, _C, _D).
hnf_susp('$all', '.'(_A, []), _B, _C, _D):-
        '$all'(_A, _B, _C, _D).
hnf_susp('$undefined', [], _A, _B, _C):-
        '$undefined'(_A, _B, _C).
hnf_susp('$def', '.'(_A, []), _B, _C, _D):-
        '$def'(_A, _B, _C, _D).
hnf_susp('$not_undef', '.'(_A, []), _B, _C, _D):-
        '$not_undef'(_A, _B, _C, _D).
hnf_susp('$nf', '.'(_A, []), _B, _C, _D):-
        '$nf'(_A, _B, _C, _D).
hnf_susp('$hnf', '.'(_A, []), _B, _C, _D):-
        '$hnf'(_A, _B, _C, _D).
hnf_susp('$strict', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$strict'(_A, _B, _C, _D, _E).
hnf_susp('$strict\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$strict\''(_A, _B, _C, _D, _E).
hnf_susp('$map', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$map'(_A, _B, _C, _D, _E).
hnf_susp($., '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        $.(_A, _B, _C, _D, _E, _F).
hnf_susp($++, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $++(_A, _B, _C, _D, _E).
hnf_susp('$!!', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$!!'(_A, _B, _C, _D, _E).
hnf_susp('$iterate', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$iterate'(_A, _B, _C, _D, _E).
hnf_susp('$repeat', '.'(_A, []), _B, _C, _D):-
        '$repeat'(_A, _B, _C, _D).
hnf_susp('$copy', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$copy'(_A, _B, _C, _D, _E).
hnf_susp('$filter', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$filter'(_A, _B, _C, _D, _E).
hnf_susp('$foldl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldl1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$foldl1'(_A, _B, _C, _D, _E).
hnf_susp('$foldl\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldl\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanl1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$scanl1'(_A, _B, _C, _D, _E).
hnf_susp('$scanl\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanl\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$foldr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$foldr1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$foldr1'(_A, _B, _C, _D, _E).
hnf_susp('$scanr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$scanr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$auxForScanr', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$auxForScanr'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scanr1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$scanr1'(_A, _B, _C, _D, _E).
hnf_susp('$take', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$take'(_A, _B, _C, _D, _E).
hnf_susp('$drop', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$drop'(_A, _B, _C, _D, _E).
hnf_susp('$splitAt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$splitAt'(_A, _B, _C, _D, _E).
hnf_susp('$auxForSplitAt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForSplitAt'(_A, _B, _C, _D, _E).
hnf_susp('$takeWhile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$takeWhile'(_A, _B, _C, _D, _E).
hnf_susp('$takeUntil', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$takeUntil'(_A, _B, _C, _D, _E).
hnf_susp('$dropWhile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$dropWhile'(_A, _B, _C, _D, _E).
hnf_susp('$span', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$span'(_A, _B, _C, _D, _E).
hnf_susp('$auxForSpan', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForSpan'(_A, _B, _C, _D, _E).
hnf_susp('$break', '.'(_A, []), _B, _C, _D):-
        '$break'(_A, _B, _C, _D).
hnf_susp('$zipWith', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$zipWith'(_A, _B, _C, _D, _E, _F).
hnf_susp('$zip', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$zip'(_A, _B, _C, _D, _E).
hnf_susp('$mkpair', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mkpair'(_A, _B, _C, _D, _E).
hnf_susp('$unzip', '.'(_A, []), _B, _C, _D):-
        '$unzip'(_A, _B, _C, _D).
hnf_susp('$auxForUnzip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$auxForUnzip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$until', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$until'(_A, _B, _C, _D, _E, _F).
hnf_susp('$until\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$until\''(_A, _B, _C, _D, _E).
hnf_susp('$const', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$const'(_A, _B, _C, _D, _E).
hnf_susp('$id', '.'(_A, []), _B, _C, _D):-
        '$id'(_A, _B, _C, _D).
hnf_susp($//, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $//(_A, _B, _C, _D, _E).
hnf_susp('$curry', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$curry'(_A, _B, _C, _D, _E, _F).
hnf_susp('$uncurry', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$uncurry'(_A, _B, _C, _D, _E).
hnf_susp('$fst', '.'(_A, []), _B, _C, _D):-
        '$fst'(_A, _B, _C, _D).
hnf_susp('$snd', '.'(_A, []), _B, _C, _D):-
        '$snd'(_A, _B, _C, _D).
hnf_susp('$fst3', '.'(_A, []), _B, _C, _D):-
        '$fst3'(_A, _B, _C, _D).
hnf_susp('$snd3', '.'(_A, []), _B, _C, _D):-
        '$snd3'(_A, _B, _C, _D).
hnf_susp('$thd3', '.'(_A, []), _B, _C, _D):-
        '$thd3'(_A, _B, _C, _D).
hnf_susp('$substract', [], _A, _B, _C):-
        '$substract'(_A, _B, _C).
hnf_susp('$even', '.'(_A, []), _B, _C, _D):-
        '$even'(_A, _B, _C, _D).
hnf_susp('$odd', [], _A, _B, _C):-
        '$odd'(_A, _B, _C).
hnf_susp('$lcm', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$lcm'(_A, _B, _C, _D, _E).
hnf_susp('$head', '.'(_A, []), _B, _C, _D):-
        '$head'(_A, _B, _C, _D).
hnf_susp('$last', '.'(_A, []), _B, _C, _D):-
        '$last'(_A, _B, _C, _D).
hnf_susp('$tail', '.'(_A, []), _B, _C, _D):-
        '$tail'(_A, _B, _C, _D).
hnf_susp('$init', '.'(_A, []), _B, _C, _D):-
        '$init'(_A, _B, _C, _D).
hnf_susp('$nub', '.'(_A, []), _B, _C, _D):-
        '$nub'(_A, _B, _C, _D).
hnf_susp('$length', '.'(_A, []), _B, _C, _D):-
        '$length'(_A, _B, _C, _D).
hnf_susp('$size', [], _A, _B, _C):-
        '$size'(_A, _B, _C).
hnf_susp('$reverse', [], _A, _B, _C):-
        '$reverse'(_A, _B, _C).
hnf_susp('$member', [], _A, _B, _C):-
        '$member'(_A, _B, _C).
hnf_susp('$notMember', [], _A, _B, _C):-
        '$notMember'(_A, _B, _C).
hnf_susp('$concat', [], _A, _B, _C):-
        '$concat'(_A, _B, _C).
hnf_susp('$transpose', [], _A, _B, _C):-
        '$transpose'(_A, _B, _C).
hnf_susp('$auxForTranspose', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$auxForTranspose'(_A, _B, _C, _D, _E).
hnf_susp($\\, [], _A, _B, _C):-
        $\\(_A, _B, _C).
hnf_susp('$del', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$del'(_A, _B, _C, _D, _E).
hnf_susp('$strToint', '.'(_A, []), _B, _C, _D):-
        '$strToint'(_A, _B, _C, _D).
hnf_susp('$getNumber', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$getNumber'(_A, _B, _C, _D, _E).
hnf_susp('$intTostr', '.'(_A, []), _B, _C, _D):-
        '$intTostr'(_A, _B, _C, _D).
hnf_susp('$getString', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$getString'(_A, _B, _C, _D, _E).
hnf_susp('$tkShowErrors', [], _A, _B, _C):-
        '$tkShowErrors'(_A, _B, _C).
hnf_susp('$tkRef2Label', '.'(_A, []), _B, _C, _D):-
        '$tkRef2Label'(_A, _B, _C, _D).
hnf_susp('$tkRef2Wtype', '.'(_A, []), _B, _C, _D):-
        '$tkRef2Wtype'(_A, _B, _C, _D).
hnf_susp('$tk2tcl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tk2tcl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkConfCollection2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkConfCollection2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$tkConf2tcl', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkConf2tcl'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$setlistelems', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$setlistelems'(_A, _B, _C, _D, _E).
hnf_susp('$tkMenu2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkMenu2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$setmenuelems', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$setmenuelems'(_A, _B, _C, _D, _E).
hnf_susp('$tkConfs2handler', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkConfs2handler'(_A, _B, _C, _D, _E).
hnf_susp('$tkMenu2handler', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkMenu2handler'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkConfs2tcl', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkConfs2tcl'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkcitems2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkcitems2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$tkcitem', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkcitem'(_A, _B, _C, _D, _E).
hnf_susp('$tkShowCoords', '.'(_A, []), _B, _C, _D):-
        '$tkShowCoords'(_A, _B, _C, _D).
hnf_susp('$tkLabel2Refname', '.'(_A, []), _B, _C, _D):-
        '$tkLabel2Refname'(_A, _B, _C, _D).
hnf_susp('$aux', '.'(_A, []), _B, _C, _D):-
        '$aux'(_A, _B, _C, _D).
hnf_susp('$tkRefname2Label', '.'(_A, []), _B, _C, _D):-
        '$tkRefname2Label'(_A, _B, _C, _D).
hnf_susp('$aux1', '.'(_A, []), _B, _C, _D):-
        '$aux1'(_A, _B, _C, _D).
hnf_susp('$tks2tcl', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tks2tcl'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkslabels', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkslabels'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkmain2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkmain2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$debugTcl', '.'(_A, []), _B, _C, _D):-
        '$debugTcl'(_A, _B, _C, _D).
hnf_susp('$forkWish', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$forkWish'(_A, _B, _C, _D, _E).
hnf_susp('$runWidget', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$runWidget'(_A, _B, _C, _D, _E).
hnf_susp('$aux4', '.'(_A, []), _B, _C, _D):-
        '$aux4'(_A, _B, _C, _D).
hnf_susp('$runWidgetInit', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$runWidgetInit'(_A, _B, _C, _D, _E, _F).
hnf_susp('$runWidgetPassive', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$runWidgetPassive'(_A, _B, _C, _D, _E).
hnf_susp('$initSchedule', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$initSchedule'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$tkSchedule', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkSchedule'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$aux2', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$aux2'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$tkTerminateWish', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkTerminateWish'(_A, _B, _C, _D, _E).
hnf_susp('$tkSelectEvent', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkSelectEvent'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkGetVar', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkGetVar'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkGetVarMsg', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkGetVarMsg'(_A, _B, _C, _D, _E, _F).
hnf_susp('$aux3', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$aux3'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkGetVarValue', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkGetVarValue'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkParseInt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkParseInt'(_A, _B, _C, _D, _E).
hnf_susp('$checkWishConsistency', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$checkWishConsistency'(_A, _B, _C, _D, _E).
hnf_susp('$escape_tcl', '.'(_A, []), _B, _C, _D):-
        '$escape_tcl'(_A, _B, _C, _D).
hnf_susp('$tkVoid', '.'(_A, []), _B, _C, _D):-
        '$tkVoid'(_A, _B, _C, _D).
hnf_susp('$tkExit', '.'(_A, []), _B, _C, _D):-
        '$tkExit'(_A, _B, _C, _D).
hnf_susp('$tkGetValue', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkGetValue'(_A, _B, _C, _D, _E).
hnf_susp('$tkSetValue', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkSetValue'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkUpdate', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkUpdate'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkConfig', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkConfig'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkFocus', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkFocus'(_A, _B, _C, _D, _E).
hnf_susp('$tkAddCanvas', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkAddCanvas'(_A, _B, _C, _D, _E, _F).




/***************     CODE FOR APPLY     ***************/

'$$apply'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$$applyHnf'(_F, _B, _C, _G, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        var(_A),
        !,
        '$$apply_1_var'(_A, _B, _C, _D, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        '$$apply_1'(_A, _B, _C, _D, _E).

% constructors

'$$apply_1'(:, _A, :(_A), _B, _B).
'$$apply_1_var'(_A, _B, :(_B), _C, _D):-
        unifyHnfs(_A, :, _C, _D).

'$$apply_1'(:(_A), _B, :(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, :(_C, _B), _D, _E):-
        unifyHnfs(_A, :(_C), _D, _E).

'$$apply_1'('$io', _A, '$io'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$io'(_B), _C, _D):-
        unifyHnfs(_A, '$io', _C, _D).

'$$apply_1'('$stream', _A, '$stream'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$stream'(_B), _C, _D):-
        unifyHnfs(_A, '$stream', _C, _D).

'$$apply_1'('$channel', _A, '$channel'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$channel'(_B), _C, _D):-
        unifyHnfs(_A, '$channel', _C, _D).

'$$apply_1'('$channel'(_A), _B, '$channel'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$channel'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$channel'(_C), _D, _E).

'$$apply_1'('$varmut', _A, '$varmut'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$varmut'(_B), _C, _D):-
        unifyHnfs(_A, '$varmut', _C, _D).

'$$apply_1'(tkButton, _A, tkButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkButton(_B), _C, _D):-
        unifyHnfs(_A, tkButton, _C, _D).

'$$apply_1'(tkButton(_A), _B, tkButton(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkButton(_C, _B), _D, _E):-
        unifyHnfs(_A, tkButton(_C), _D, _E).

'$$apply_1'(tkCanvas, _A, tkCanvas(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCanvas(_B), _C, _D):-
        unifyHnfs(_A, tkCanvas, _C, _D).

'$$apply_1'(tkCheckButton, _A, tkCheckButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCheckButton(_B), _C, _D):-
        unifyHnfs(_A, tkCheckButton, _C, _D).

'$$apply_1'(tkEntry, _A, tkEntry(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkEntry(_B), _C, _D):-
        unifyHnfs(_A, tkEntry, _C, _D).

'$$apply_1'(tkLabel, _A, tkLabel(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkLabel(_B), _C, _D):-
        unifyHnfs(_A, tkLabel, _C, _D).

'$$apply_1'(tkListBox, _A, tkListBox(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkListBox(_B), _C, _D):-
        unifyHnfs(_A, tkListBox, _C, _D).

'$$apply_1'(tkMessage, _A, tkMessage(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMessage(_B), _C, _D):-
        unifyHnfs(_A, tkMessage, _C, _D).

'$$apply_1'(tkMenuButton, _A, tkMenuButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenuButton(_B), _C, _D):-
        unifyHnfs(_A, tkMenuButton, _C, _D).

'$$apply_1'(tkScale, _A, tkScale(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkScale(_B), _C, _D):-
        unifyHnfs(_A, tkScale, _C, _D).

'$$apply_1'(tkScale(_A), _B, tkScale(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkScale(_C, _B), _D, _E):-
        unifyHnfs(_A, tkScale(_C), _D, _E).

'$$apply_1'(tkScale(_A, _B), _C, tkScale(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkScale(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkScale(_C, _D), _E, _F).

'$$apply_1'(tkScrollV, _A, tkScrollV(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkScrollV(_B), _C, _D):-
        unifyHnfs(_A, tkScrollV, _C, _D).

'$$apply_1'(tkScrollV(_A), _B, tkScrollV(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkScrollV(_C, _B), _D, _E):-
        unifyHnfs(_A, tkScrollV(_C), _D, _E).

'$$apply_1'(tkScrollH, _A, tkScrollH(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkScrollH(_B), _C, _D):-
        unifyHnfs(_A, tkScrollH, _C, _D).

'$$apply_1'(tkScrollH(_A), _B, tkScrollH(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkScrollH(_C, _B), _D, _E):-
        unifyHnfs(_A, tkScrollH(_C), _D, _E).

'$$apply_1'(tkTextEdit, _A, tkTextEdit(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkTextEdit(_B), _C, _D):-
        unifyHnfs(_A, tkTextEdit, _C, _D).

'$$apply_1'(tkRow, _A, tkRow(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRow(_B), _C, _D):-
        unifyHnfs(_A, tkRow, _C, _D).

'$$apply_1'(tkRow(_A), _B, tkRow(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkRow(_C, _B), _D, _E):-
        unifyHnfs(_A, tkRow(_C), _D, _E).

'$$apply_1'(tkCol, _A, tkCol(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCol(_B), _C, _D):-
        unifyHnfs(_A, tkCol, _C, _D).

'$$apply_1'(tkCol(_A), _B, tkCol(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkCol(_C, _B), _D, _E):-
        unifyHnfs(_A, tkCol(_C), _D, _E).

'$$apply_1'(tkActive, _A, tkActive(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkActive(_B), _C, _D):-
        unifyHnfs(_A, tkActive, _C, _D).

'$$apply_1'(tkAnchor, _A, tkAnchor(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkAnchor(_B), _C, _D):-
        unifyHnfs(_A, tkAnchor, _C, _D).

'$$apply_1'(tkBackground, _A, tkBackground(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkBackground(_B), _C, _D):-
        unifyHnfs(_A, tkBackground, _C, _D).

'$$apply_1'(tkCmd, _A, tkCmd(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCmd(_B), _C, _D):-
        unifyHnfs(_A, tkCmd, _C, _D).

'$$apply_1'(tkHeight, _A, tkHeight(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkHeight(_B), _C, _D):-
        unifyHnfs(_A, tkHeight, _C, _D).

'$$apply_1'(tkInit, _A, tkInit(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkInit(_B), _C, _D):-
        unifyHnfs(_A, tkInit, _C, _D).

'$$apply_1'(tkItems, _A, tkItems(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkItems(_B), _C, _D):-
        unifyHnfs(_A, tkItems, _C, _D).

'$$apply_1'(tkList, _A, tkList(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkList(_B), _C, _D):-
        unifyHnfs(_A, tkList, _C, _D).

'$$apply_1'(tkMenu, _A, tkMenu(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenu(_B), _C, _D):-
        unifyHnfs(_A, tkMenu, _C, _D).

'$$apply_1'(tkRef, _A, tkRef(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRef(_B), _C, _D):-
        unifyHnfs(_A, tkRef, _C, _D).

'$$apply_1'(tkText, _A, tkText(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkText(_B), _C, _D):-
        unifyHnfs(_A, tkText, _C, _D).

'$$apply_1'(tkWidth, _A, tkWidth(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkWidth(_B), _C, _D):-
        unifyHnfs(_A, tkWidth, _C, _D).

'$$apply_1'(tkTcl, _A, tkTcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkTcl(_B), _C, _D):-
        unifyHnfs(_A, tkTcl, _C, _D).

'$$apply_1'(tkMButton, _A, tkMButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMButton(_B), _C, _D):-
        unifyHnfs(_A, tkMButton, _C, _D).

'$$apply_1'(tkMButton(_A), _B, tkMButton(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkMButton(_C, _B), _D, _E):-
        unifyHnfs(_A, tkMButton(_C), _D, _E).

'$$apply_1'(tkMMenuButton, _A, tkMMenuButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMMenuButton(_B), _C, _D):-
        unifyHnfs(_A, tkMMenuButton, _C, _D).

'$$apply_1'(tkMMenuButton(_A), _B, tkMMenuButton(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkMMenuButton(_C, _B), _D, _E):-
        unifyHnfs(_A, tkMMenuButton(_C), _D, _E).

'$$apply_1'(tkLine, _A, tkLine(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkLine(_B), _C, _D):-
        unifyHnfs(_A, tkLine, _C, _D).

'$$apply_1'(tkLine(_A), _B, tkLine(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkLine(_C, _B), _D, _E):-
        unifyHnfs(_A, tkLine(_C), _D, _E).

'$$apply_1'(tkPolygon, _A, tkPolygon(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkPolygon(_B), _C, _D):-
        unifyHnfs(_A, tkPolygon, _C, _D).

'$$apply_1'(tkPolygon(_A), _B, tkPolygon(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkPolygon(_C, _B), _D, _E):-
        unifyHnfs(_A, tkPolygon(_C), _D, _E).

'$$apply_1'(tkRectangle, _A, tkRectangle(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRectangle(_B), _C, _D):-
        unifyHnfs(_A, tkRectangle, _C, _D).

'$$apply_1'(tkRectangle(_A), _B, tkRectangle(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkRectangle(_C, _B), _D, _E):-
        unifyHnfs(_A, tkRectangle(_C), _D, _E).

'$$apply_1'(tkRectangle(_A, _B), _C, tkRectangle(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkRectangle(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkRectangle(_C, _D), _E, _F).

'$$apply_1'(tkOval, _A, tkOval(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkOval(_B), _C, _D):-
        unifyHnfs(_A, tkOval, _C, _D).

'$$apply_1'(tkOval(_A), _B, tkOval(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkOval(_C, _B), _D, _E):-
        unifyHnfs(_A, tkOval(_C), _D, _E).

'$$apply_1'(tkOval(_A, _B), _C, tkOval(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkOval(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkOval(_C, _D), _E, _F).

'$$apply_1'(tkRefLabel, _A, tkRefLabel(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRefLabel(_B), _C, _D):-
        unifyHnfs(_A, tkRefLabel, _C, _D).

'$$apply_1'(tkRefLabel(_A), _B, tkRefLabel(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkRefLabel(_C, _B), _D, _E):-
        unifyHnfs(_A, tkRefLabel(_C), _D, _E).

'$$apply_1'(tkRefLabel(_A, _B), _C, tkRefLabel(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkRefLabel(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkRefLabel(_C, _D), _E, _F).

% parcial aplictions of funs

'$$apply_1'('$eqFun', _A, '$eqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$eqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$eqFun', _C, _D).

'$$apply_1'('$notEqFun', _A, '$notEqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$notEqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$notEqFun', _C, _D).

'$$apply_1'(and, _A, and(_A), _B, _B).
'$$apply_1_var'(_A, _B, and(_B), _C, _D):-
        unifyHnfs(_A, and, _C, _D).

'$$apply_1'(or, _A, or(_A), _B, _B).
'$$apply_1_var'(_A, _B, or(_B), _C, _D):-
        unifyHnfs(_A, or, _C, _D).

'$$apply_1'(/\, _A, /\(_A), _B, _B).
'$$apply_1_var'(_A, _B, /\(_B), _C, _D):-
        unifyHnfs(_A, /\, _C, _D).

'$$apply_1'(\/, _A, \/(_A), _B, _B).
'$$apply_1_var'(_A, _B, \/(_B), _C, _D):-
        unifyHnfs(_A, \/, _C, _D).

'$$apply_1'(strict, _A, strict(_A), _B, _B).
'$$apply_1_var'(_A, _B, strict(_B), _C, _D):-
        unifyHnfs(_A, strict, _C, _D).

'$$apply_1'('strict\'', _A, 'strict\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'strict\''(_B), _C, _D):-
        unifyHnfs(_A, 'strict\'', _C, _D).

'$$apply_1'(map, _A, map(_A), _B, _B).
'$$apply_1_var'(_A, _B, map(_B), _C, _D):-
        unifyHnfs(_A, map, _C, _D).

'$$apply_1'('.', _A, '.'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '.'(_B), _C, _D):-
        unifyHnfs(_A, '.', _C, _D).

'$$apply_1'('.'(_A), _B, '.'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '.'(_C, _B), _D, _E):-
        unifyHnfs(_A, '.'(_C), _D, _E).

'$$apply_1'(++, _A, ++(_A), _B, _B).
'$$apply_1_var'(_A, _B, ++(_B), _C, _D):-
        unifyHnfs(_A, ++, _C, _D).

'$$apply_1'('!!', _A, '!!'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '!!'(_B), _C, _D):-
        unifyHnfs(_A, '!!', _C, _D).

'$$apply_1'(iterate, _A, iterate(_A), _B, _B).
'$$apply_1_var'(_A, _B, iterate(_B), _C, _D):-
        unifyHnfs(_A, iterate, _C, _D).

'$$apply_1'(copy, _A, copy(_A), _B, _B).
'$$apply_1_var'(_A, _B, copy(_B), _C, _D):-
        unifyHnfs(_A, copy, _C, _D).

'$$apply_1'(filter, _A, filter(_A), _B, _B).
'$$apply_1_var'(_A, _B, filter(_B), _C, _D):-
        unifyHnfs(_A, filter, _C, _D).

'$$apply_1'(foldl, _A, foldl(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldl(_B), _C, _D):-
        unifyHnfs(_A, foldl, _C, _D).

'$$apply_1'(foldl(_A), _B, foldl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, foldl(_C, _B), _D, _E):-
        unifyHnfs(_A, foldl(_C), _D, _E).

'$$apply_1'(foldl1, _A, foldl1(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldl1(_B), _C, _D):-
        unifyHnfs(_A, foldl1, _C, _D).

'$$apply_1'('foldl\'', _A, 'foldl\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'foldl\''(_B), _C, _D):-
        unifyHnfs(_A, 'foldl\'', _C, _D).

'$$apply_1'('foldl\''(_A), _B, 'foldl\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'foldl\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'foldl\''(_C), _D, _E).

'$$apply_1'(scanl, _A, scanl(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanl(_B), _C, _D):-
        unifyHnfs(_A, scanl, _C, _D).

'$$apply_1'(scanl(_A), _B, scanl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scanl(_C, _B), _D, _E):-
        unifyHnfs(_A, scanl(_C), _D, _E).

'$$apply_1'(scanl1, _A, scanl1(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanl1(_B), _C, _D):-
        unifyHnfs(_A, scanl1, _C, _D).

'$$apply_1'('scanl\'', _A, 'scanl\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'scanl\''(_B), _C, _D):-
        unifyHnfs(_A, 'scanl\'', _C, _D).

'$$apply_1'('scanl\''(_A), _B, 'scanl\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'scanl\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'scanl\''(_C), _D, _E).

'$$apply_1'(foldr, _A, foldr(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldr(_B), _C, _D):-
        unifyHnfs(_A, foldr, _C, _D).

'$$apply_1'(foldr(_A), _B, foldr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, foldr(_C, _B), _D, _E):-
        unifyHnfs(_A, foldr(_C), _D, _E).

'$$apply_1'(foldr1, _A, foldr1(_A), _B, _B).
'$$apply_1_var'(_A, _B, foldr1(_B), _C, _D):-
        unifyHnfs(_A, foldr1, _C, _D).

'$$apply_1'(scanr, _A, scanr(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanr(_B), _C, _D):-
        unifyHnfs(_A, scanr, _C, _D).

'$$apply_1'(scanr(_A), _B, scanr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scanr(_C, _B), _D, _E):-
        unifyHnfs(_A, scanr(_C), _D, _E).

'$$apply_1'(auxForScanr, _A, auxForScanr(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForScanr(_B), _C, _D):-
        unifyHnfs(_A, auxForScanr, _C, _D).

'$$apply_1'(auxForScanr(_A), _B, auxForScanr(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, auxForScanr(_C, _B), _D, _E):-
        unifyHnfs(_A, auxForScanr(_C), _D, _E).

'$$apply_1'(scanr1, _A, scanr1(_A), _B, _B).
'$$apply_1_var'(_A, _B, scanr1(_B), _C, _D):-
        unifyHnfs(_A, scanr1, _C, _D).

'$$apply_1'(take, _A, take(_A), _B, _B).
'$$apply_1_var'(_A, _B, take(_B), _C, _D):-
        unifyHnfs(_A, take, _C, _D).

'$$apply_1'(drop, _A, drop(_A), _B, _B).
'$$apply_1_var'(_A, _B, drop(_B), _C, _D):-
        unifyHnfs(_A, drop, _C, _D).

'$$apply_1'(splitAt, _A, splitAt(_A), _B, _B).
'$$apply_1_var'(_A, _B, splitAt(_B), _C, _D):-
        unifyHnfs(_A, splitAt, _C, _D).

'$$apply_1'(auxForSplitAt, _A, auxForSplitAt(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForSplitAt(_B), _C, _D):-
        unifyHnfs(_A, auxForSplitAt, _C, _D).

'$$apply_1'(takeWhile, _A, takeWhile(_A), _B, _B).
'$$apply_1_var'(_A, _B, takeWhile(_B), _C, _D):-
        unifyHnfs(_A, takeWhile, _C, _D).

'$$apply_1'(takeUntil, _A, takeUntil(_A), _B, _B).
'$$apply_1_var'(_A, _B, takeUntil(_B), _C, _D):-
        unifyHnfs(_A, takeUntil, _C, _D).

'$$apply_1'(dropWhile, _A, dropWhile(_A), _B, _B).
'$$apply_1_var'(_A, _B, dropWhile(_B), _C, _D):-
        unifyHnfs(_A, dropWhile, _C, _D).

'$$apply_1'(span, _A, span(_A), _B, _B).
'$$apply_1_var'(_A, _B, span(_B), _C, _D):-
        unifyHnfs(_A, span, _C, _D).

'$$apply_1'(auxForSpan, _A, auxForSpan(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForSpan(_B), _C, _D):-
        unifyHnfs(_A, auxForSpan, _C, _D).

'$$apply_1'(zipWith, _A, zipWith(_A), _B, _B).
'$$apply_1_var'(_A, _B, zipWith(_B), _C, _D):-
        unifyHnfs(_A, zipWith, _C, _D).

'$$apply_1'(zipWith(_A), _B, zipWith(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, zipWith(_C, _B), _D, _E):-
        unifyHnfs(_A, zipWith(_C), _D, _E).

'$$apply_1'(zip, _A, zip(_A), _B, _B).
'$$apply_1_var'(_A, _B, zip(_B), _C, _D):-
        unifyHnfs(_A, zip, _C, _D).

'$$apply_1'(mkpair, _A, mkpair(_A), _B, _B).
'$$apply_1_var'(_A, _B, mkpair(_B), _C, _D):-
        unifyHnfs(_A, mkpair, _C, _D).

'$$apply_1'(auxForUnzip, _A, auxForUnzip(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForUnzip(_B), _C, _D):-
        unifyHnfs(_A, auxForUnzip, _C, _D).

'$$apply_1'(auxForUnzip(_A), _B, auxForUnzip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, auxForUnzip(_C, _B), _D, _E):-
        unifyHnfs(_A, auxForUnzip(_C), _D, _E).

'$$apply_1'(until, _A, until(_A), _B, _B).
'$$apply_1_var'(_A, _B, until(_B), _C, _D):-
        unifyHnfs(_A, until, _C, _D).

'$$apply_1'(until(_A), _B, until(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, until(_C, _B), _D, _E):-
        unifyHnfs(_A, until(_C), _D, _E).

'$$apply_1'('until\'', _A, 'until\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'until\''(_B), _C, _D):-
        unifyHnfs(_A, 'until\'', _C, _D).

'$$apply_1'(const, _A, const(_A), _B, _B).
'$$apply_1_var'(_A, _B, const(_B), _C, _D):-
        unifyHnfs(_A, const, _C, _D).

'$$apply_1'(//, _A, //(_A), _B, _B).
'$$apply_1_var'(_A, _B, //(_B), _C, _D):-
        unifyHnfs(_A, //, _C, _D).

'$$apply_1'(curry, _A, curry(_A), _B, _B).
'$$apply_1_var'(_A, _B, curry(_B), _C, _D):-
        unifyHnfs(_A, curry, _C, _D).

'$$apply_1'(curry(_A), _B, curry(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, curry(_C, _B), _D, _E):-
        unifyHnfs(_A, curry(_C), _D, _E).

'$$apply_1'(uncurry, _A, uncurry(_A), _B, _B).
'$$apply_1_var'(_A, _B, uncurry(_B), _C, _D):-
        unifyHnfs(_A, uncurry, _C, _D).

'$$apply_1'(lcm, _A, lcm(_A), _B, _B).
'$$apply_1_var'(_A, _B, lcm(_B), _C, _D):-
        unifyHnfs(_A, lcm, _C, _D).

'$$apply_1'(auxForTranspose, _A, auxForTranspose(_A), _B, _B).
'$$apply_1_var'(_A, _B, auxForTranspose(_B), _C, _D):-
        unifyHnfs(_A, auxForTranspose, _C, _D).

'$$apply_1'(del, _A, del(_A), _B, _B).
'$$apply_1_var'(_A, _B, del(_B), _C, _D):-
        unifyHnfs(_A, del, _C, _D).

'$$apply_1'(getNumber, _A, getNumber(_A), _B, _B).
'$$apply_1_var'(_A, _B, getNumber(_B), _C, _D):-
        unifyHnfs(_A, getNumber, _C, _D).

'$$apply_1'(getString, _A, getString(_A), _B, _B).
'$$apply_1_var'(_A, _B, getString(_B), _C, _D):-
        unifyHnfs(_A, getString, _C, _D).

'$$apply_1'(tk2tcl, _A, tk2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tk2tcl(_B), _C, _D):-
        unifyHnfs(_A, tk2tcl, _C, _D).

'$$apply_1'(tk2tcl(_A), _B, tk2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tk2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tk2tcl(_C), _D, _E).

'$$apply_1'(tkConfCollection2tcl, _A, tkConfCollection2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfCollection2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkConfCollection2tcl, _C, _D).

'$$apply_1'(tkConf2tcl, _A, tkConf2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConf2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkConf2tcl, _C, _D).

'$$apply_1'(tkConf2tcl(_A), _B, tkConf2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkConf2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tkConf2tcl(_C), _D, _E).

'$$apply_1'(tkConf2tcl(_A, _B), _C, tkConf2tcl(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkConf2tcl(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkConf2tcl(_C, _D), _E, _F).

'$$apply_1'(setlistelems, _A, setlistelems(_A), _B, _B).
'$$apply_1_var'(_A, _B, setlistelems(_B), _C, _D):-
        unifyHnfs(_A, setlistelems, _C, _D).

'$$apply_1'(tkMenu2tcl, _A, tkMenu2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenu2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkMenu2tcl, _C, _D).

'$$apply_1'(setmenuelems, _A, setmenuelems(_A), _B, _B).
'$$apply_1_var'(_A, _B, setmenuelems(_B), _C, _D):-
        unifyHnfs(_A, setmenuelems, _C, _D).

'$$apply_1'(tkConfs2handler, _A, tkConfs2handler(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfs2handler(_B), _C, _D):-
        unifyHnfs(_A, tkConfs2handler, _C, _D).

'$$apply_1'(tkMenu2handler, _A, tkMenu2handler(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenu2handler(_B), _C, _D):-
        unifyHnfs(_A, tkMenu2handler, _C, _D).

'$$apply_1'(tkMenu2handler(_A), _B, tkMenu2handler(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkMenu2handler(_C, _B), _D, _E):-
        unifyHnfs(_A, tkMenu2handler(_C), _D, _E).

'$$apply_1'(tkConfs2tcl, _A, tkConfs2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfs2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkConfs2tcl, _C, _D).

'$$apply_1'(tkConfs2tcl(_A), _B, tkConfs2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkConfs2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tkConfs2tcl(_C), _D, _E).

'$$apply_1'(tkConfs2tcl(_A, _B), _C, tkConfs2tcl(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkConfs2tcl(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkConfs2tcl(_C, _D), _E, _F).

'$$apply_1'(tkcitems2tcl, _A, tkcitems2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkcitems2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkcitems2tcl, _C, _D).

'$$apply_1'(tkcitem, _A, tkcitem(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkcitem(_B), _C, _D):-
        unifyHnfs(_A, tkcitem, _C, _D).

'$$apply_1'(tks2tcl, _A, tks2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tks2tcl(_B), _C, _D):-
        unifyHnfs(_A, tks2tcl, _C, _D).

'$$apply_1'(tks2tcl(_A), _B, tks2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tks2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tks2tcl(_C), _D, _E).

'$$apply_1'(tks2tcl(_A, _B), _C, tks2tcl(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tks2tcl(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tks2tcl(_C, _D), _E, _F).

'$$apply_1'(tkslabels, _A, tkslabels(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkslabels(_B), _C, _D):-
        unifyHnfs(_A, tkslabels, _C, _D).

'$$apply_1'(tkslabels(_A), _B, tkslabels(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkslabels(_C, _B), _D, _E):-
        unifyHnfs(_A, tkslabels(_C), _D, _E).

'$$apply_1'(tkmain2tcl, _A, tkmain2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkmain2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkmain2tcl, _C, _D).

'$$apply_1'(forkWish, _A, forkWish(_A), _B, _B).
'$$apply_1_var'(_A, _B, forkWish(_B), _C, _D):-
        unifyHnfs(_A, forkWish, _C, _D).

'$$apply_1'(runWidget, _A, runWidget(_A), _B, _B).
'$$apply_1_var'(_A, _B, runWidget(_B), _C, _D):-
        unifyHnfs(_A, runWidget, _C, _D).

'$$apply_1'(runWidgetInit, _A, runWidgetInit(_A), _B, _B).
'$$apply_1_var'(_A, _B, runWidgetInit(_B), _C, _D):-
        unifyHnfs(_A, runWidgetInit, _C, _D).

'$$apply_1'(runWidgetInit(_A), _B, runWidgetInit(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, runWidgetInit(_C, _B), _D, _E):-
        unifyHnfs(_A, runWidgetInit(_C), _D, _E).

'$$apply_1'(runWidgetPassive, _A, runWidgetPassive(_A), _B, _B).
'$$apply_1_var'(_A, _B, runWidgetPassive(_B), _C, _D):-
        unifyHnfs(_A, runWidgetPassive, _C, _D).

'$$apply_1'(initSchedule, _A, initSchedule(_A), _B, _B).
'$$apply_1_var'(_A, _B, initSchedule(_B), _C, _D):-
        unifyHnfs(_A, initSchedule, _C, _D).

'$$apply_1'(initSchedule(_A), _B, initSchedule(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, initSchedule(_C, _B), _D, _E):-
        unifyHnfs(_A, initSchedule(_C), _D, _E).

'$$apply_1'(initSchedule(_A, _B), _C, initSchedule(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, initSchedule(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, initSchedule(_C, _D), _E, _F).

'$$apply_1'(initSchedule(_A, _B, _C), _D, initSchedule(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, initSchedule(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, initSchedule(_C, _D, _E), _F, _G).

'$$apply_1'(tkSchedule, _A, tkSchedule(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkSchedule(_B), _C, _D):-
        unifyHnfs(_A, tkSchedule, _C, _D).

'$$apply_1'(tkSchedule(_A), _B, tkSchedule(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkSchedule(_C, _B), _D, _E):-
        unifyHnfs(_A, tkSchedule(_C), _D, _E).

'$$apply_1'(tkSchedule(_A, _B), _C, tkSchedule(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkSchedule(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkSchedule(_C, _D), _E, _F).

'$$apply_1'(aux2, _A, aux2(_A), _B, _B).
'$$apply_1_var'(_A, _B, aux2(_B), _C, _D):-
        unifyHnfs(_A, aux2, _C, _D).

'$$apply_1'(aux2(_A), _B, aux2(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, aux2(_C, _B), _D, _E):-
        unifyHnfs(_A, aux2(_C), _D, _E).

'$$apply_1'(aux2(_A, _B), _C, aux2(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, aux2(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, aux2(_C, _D), _E, _F).

'$$apply_1'(aux2(_A, _B, _C), _D, aux2(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, aux2(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, aux2(_C, _D, _E), _F, _G).

'$$apply_1'(tkTerminateWish, _A, tkTerminateWish(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkTerminateWish(_B), _C, _D):-
        unifyHnfs(_A, tkTerminateWish, _C, _D).

'$$apply_1'(tkSelectEvent, _A, tkSelectEvent(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkSelectEvent(_B), _C, _D):-
        unifyHnfs(_A, tkSelectEvent, _C, _D).

'$$apply_1'(tkSelectEvent(_A), _B, tkSelectEvent(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkSelectEvent(_C, _B), _D, _E):-
        unifyHnfs(_A, tkSelectEvent(_C), _D, _E).

'$$apply_1'(tkSelectEvent(_A, _B), _C, tkSelectEvent(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkSelectEvent(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkSelectEvent(_C, _D), _E, _F).

'$$apply_1'(tkGetVar, _A, tkGetVar(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetVar(_B), _C, _D):-
        unifyHnfs(_A, tkGetVar, _C, _D).

'$$apply_1'(tkGetVar(_A), _B, tkGetVar(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkGetVar(_C, _B), _D, _E):-
        unifyHnfs(_A, tkGetVar(_C), _D, _E).

'$$apply_1'(tkGetVarMsg, _A, tkGetVarMsg(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetVarMsg(_B), _C, _D):-
        unifyHnfs(_A, tkGetVarMsg, _C, _D).

'$$apply_1'(tkGetVarMsg(_A), _B, tkGetVarMsg(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkGetVarMsg(_C, _B), _D, _E):-
        unifyHnfs(_A, tkGetVarMsg(_C), _D, _E).

'$$apply_1'(aux3, _A, aux3(_A), _B, _B).
'$$apply_1_var'(_A, _B, aux3(_B), _C, _D):-
        unifyHnfs(_A, aux3, _C, _D).

'$$apply_1'(aux3(_A), _B, aux3(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, aux3(_C, _B), _D, _E):-
        unifyHnfs(_A, aux3(_C), _D, _E).

'$$apply_1'(aux3(_A, _B), _C, aux3(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, aux3(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, aux3(_C, _D), _E, _F).

'$$apply_1'(tkGetVarValue, _A, tkGetVarValue(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetVarValue(_B), _C, _D):-
        unifyHnfs(_A, tkGetVarValue, _C, _D).

'$$apply_1'(tkGetVarValue(_A), _B, tkGetVarValue(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkGetVarValue(_C, _B), _D, _E):-
        unifyHnfs(_A, tkGetVarValue(_C), _D, _E).

'$$apply_1'(tkParseInt, _A, tkParseInt(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkParseInt(_B), _C, _D):-
        unifyHnfs(_A, tkParseInt, _C, _D).

'$$apply_1'(checkWishConsistency, _A, checkWishConsistency(_A), _B, _B).
'$$apply_1_var'(_A, _B, checkWishConsistency(_B), _C, _D):-
        unifyHnfs(_A, checkWishConsistency, _C, _D).

'$$apply_1'(tkGetValue, _A, tkGetValue(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetValue(_B), _C, _D):-
        unifyHnfs(_A, tkGetValue, _C, _D).

'$$apply_1'(tkSetValue, _A, tkSetValue(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkSetValue(_B), _C, _D):-
        unifyHnfs(_A, tkSetValue, _C, _D).

'$$apply_1'(tkSetValue(_A), _B, tkSetValue(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkSetValue(_C, _B), _D, _E):-
        unifyHnfs(_A, tkSetValue(_C), _D, _E).

'$$apply_1'(tkUpdate, _A, tkUpdate(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkUpdate(_B), _C, _D):-
        unifyHnfs(_A, tkUpdate, _C, _D).

'$$apply_1'(tkUpdate(_A), _B, tkUpdate(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkUpdate(_C, _B), _D, _E):-
        unifyHnfs(_A, tkUpdate(_C), _D, _E).

'$$apply_1'(tkConfig, _A, tkConfig(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfig(_B), _C, _D):-
        unifyHnfs(_A, tkConfig, _C, _D).

'$$apply_1'(tkConfig(_A), _B, tkConfig(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkConfig(_C, _B), _D, _E):-
        unifyHnfs(_A, tkConfig(_C), _D, _E).

'$$apply_1'(tkFocus, _A, tkFocus(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkFocus(_B), _C, _D):-
        unifyHnfs(_A, tkFocus, _C, _D).

'$$apply_1'(tkAddCanvas, _A, tkAddCanvas(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkAddCanvas(_B), _C, _D):-
        unifyHnfs(_A, tkAddCanvas, _C, _D).

'$$apply_1'(tkAddCanvas(_A), _B, tkAddCanvas(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkAddCanvas(_C, _B), _D, _E):-
        unifyHnfs(_A, tkAddCanvas(_C), _D, _E).

% parcial aplictions of prims

'$$apply_1'(+, _A, +(_A), _B, _B).
'$$apply_1_var'(_A, _B, +(_B), _C, _D):-
        unifyHnfs(_A, +, _C, _D).

'$$apply_1'(-, _A, -(_A), _B, _B).
'$$apply_1_var'(_A, _B, -(_B), _C, _D):-
        unifyHnfs(_A, -, _C, _D).

'$$apply_1'(*, _A, *(_A), _B, _B).
'$$apply_1_var'(_A, _B, *(_B), _C, _D):-
        unifyHnfs(_A, *, _C, _D).

'$$apply_1'(min, _A, min(_A), _B, _B).
'$$apply_1_var'(_A, _B, min(_B), _C, _D):-
        unifyHnfs(_A, min, _C, _D).

'$$apply_1'(max, _A, max(_A), _B, _B).
'$$apply_1_var'(_A, _B, max(_B), _C, _D):-
        unifyHnfs(_A, max, _C, _D).

'$$apply_1'(/, _A, /(_A), _B, _B).
'$$apply_1_var'(_A, _B, /(_B), _C, _D):-
        unifyHnfs(_A, /, _C, _D).

'$$apply_1'(**, _A, **(_A), _B, _B).
'$$apply_1_var'(_A, _B, **(_B), _C, _D):-
        unifyHnfs(_A, **, _C, _D).

'$$apply_1'(log, _A, log(_A), _B, _B).
'$$apply_1_var'(_A, _B, log(_B), _C, _D):-
        unifyHnfs(_A, log, _C, _D).

'$$apply_1'(^, _A, ^(_A), _B, _B).
'$$apply_1_var'(_A, _B, ^(_B), _C, _D):-
        unifyHnfs(_A, ^, _C, _D).

'$$apply_1'(div, _A, div(_A), _B, _B).
'$$apply_1_var'(_A, _B, div(_B), _C, _D):-
        unifyHnfs(_A, div, _C, _D).

'$$apply_1'(mod, _A, mod(_A), _B, _B).
'$$apply_1_var'(_A, _B, mod(_B), _C, _D):-
        unifyHnfs(_A, mod, _C, _D).

'$$apply_1'(gcd, _A, gcd(_A), _B, _B).
'$$apply_1_var'(_A, _B, gcd(_B), _C, _D):-
        unifyHnfs(_A, gcd, _C, _D).

'$$apply_1'(<, _A, <(_A), _B, _B).
'$$apply_1_var'(_A, _B, <(_B), _C, _D):-
        unifyHnfs(_A, <, _C, _D).

'$$apply_1'(<=, _A, <=(_A), _B, _B).
'$$apply_1_var'(_A, _B, <=(_B), _C, _D):-
        unifyHnfs(_A, <=, _C, _D).

'$$apply_1'(>, _A, >(_A), _B, _B).
'$$apply_1_var'(_A, _B, >(_B), _C, _D):-
        unifyHnfs(_A, >, _C, _D).

'$$apply_1'(>=, _A, >=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >=(_B), _C, _D):-
        unifyHnfs(_A, >=, _C, _D).

'$$apply_1'(==, _A, ==(_A), _B, _B).
'$$apply_1_var'(_A, _B, ==(_B), _C, _D):-
        unifyHnfs(_A, ==, _C, _D).

'$$apply_1'(/=, _A, /=(_A), _B, _B).
'$$apply_1_var'(_A, _B, /=(_B), _C, _D):-
        unifyHnfs(_A, /=, _C, _D).

'$$apply_1'(>>, _A, >>(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>(_B), _C, _D):-
        unifyHnfs(_A, >>, _C, _D).

'$$apply_1'(>>=, _A, >>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>=(_B), _C, _D):-
        unifyHnfs(_A, >>=, _C, _D).

'$$apply_1'(cont2, _A, cont2(_A), _B, _B).
'$$apply_1_var'(_A, _B, cont2(_B), _C, _D):-
        unifyHnfs(_A, cont2, _C, _D).

'$$apply_1'(writeFile, _A, writeFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeFile(_B), _C, _D):-
        unifyHnfs(_A, writeFile, _C, _D).

'$$apply_1'(openFile, _A, openFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, openFile(_B), _C, _D):-
        unifyHnfs(_A, openFile, _C, _D).

'$$apply_1'(putCharFile, _A, putCharFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, putCharFile(_B), _C, _D):-
        unifyHnfs(_A, putCharFile, _C, _D).

'$$apply_1'(putStrFile, _A, putStrFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, putStrFile(_B), _C, _D):-
        unifyHnfs(_A, putStrFile, _C, _D).

'$$apply_1'(putStrLnFile, _A, putStrLnFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, putStrLnFile(_B), _C, _D):-
        unifyHnfs(_A, putStrLnFile, _C, _D).

'$$apply_1'(contin1, _A, contin1(_A), _B, _B).
'$$apply_1_var'(_A, _B, contin1(_B), _C, _D):-
        unifyHnfs(_A, contin1, _C, _D).

'$$apply_1'(contin2, _A, contin2(_A), _B, _B).
'$$apply_1_var'(_A, _B, contin2(_B), _C, _D):-
        unifyHnfs(_A, contin2, _C, _D).

'$$apply_1'(writeWish, _A, writeWish(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeWish(_B), _C, _D):-
        unifyHnfs(_A, writeWish, _C, _D).

'$$apply_1'(writeVar, _A, writeVar(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeVar(_B), _C, _D):-
        unifyHnfs(_A, writeVar, _C, _D).

'$$apply_1'(if_then_else, _A, if_then_else(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then_else(_B), _C, _D):-
        unifyHnfs(_A, if_then_else, _C, _D).

'$$apply_1'(if_then_else(_A), _B, if_then_else(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, if_then_else(_C, _B), _D, _E):-
        unifyHnfs(_A, if_then_else(_C), _D, _E).

'$$apply_1'(if_then, _A, if_then(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then(_B), _C, _D):-
        unifyHnfs(_A, if_then, _C, _D).

'$$apply_1'(flip, _A, flip(_A), _B, _B).
'$$apply_1_var'(_A, _B, flip(_B), _C, _D):-
        unifyHnfs(_A, flip, _C, _D).

'$$apply_1'(flip(_A), _B, flip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, flip(_C, _B), _D, _E):-
        unifyHnfs(_A, flip(_C), _D, _E).

% functions

'$$apply_1'('$eqFun'(_A), _B, _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$eqFun'(_F), _D, _G),
        '$$eqFun'(_F, _B, _C, _G, _E).

'$$apply_1'('$notEqFun'(_A), _B, _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$notEqFun'(_F), _D, _G),
        '$$notEqFun'(_F, _B, _C, _G, _E).

'$$apply_1'(and(_A), _B, _C, _D, _E):-
        '$and'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, and(_F), _D, _G),
        '$and'(_F, _B, _C, _G, _E).

'$$apply_1'(or(_A), _B, _C, _D, _E):-
        '$or'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, or(_F), _D, _G),
        '$or'(_F, _B, _C, _G, _E).

'$$apply_1'(/\(_A), _B, _C, _D, _E):-
        $/\(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /\(_F), _D, _G),
        $/\(_F, _B, _C, _G, _E).

'$$apply_1'(\/(_A), _B, _C, _D, _E):-
        $\/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, \/(_F), _D, _G),
        $\/(_F, _B, _C, _G, _E).

'$$apply_1'(not, _A, _B, _C, _D):-
        '$not'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, not, _D, _F),
        '$not'(_B, _C, _F, _E).

'$$apply_1'(any, _A, _B, _C, _D):-
        '$any'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, any, _D, _F),
        '$any'(_B, _C, _F, _E).

'$$apply_1'('any\'', _A, _B, _C, _D):-
        '$any\''(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'any\'', _D, _F),
        '$any\''(_B, _C, _F, _E).

'$$apply_1'(all, _A, _B, _C, _D):-
        '$all'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, all, _D, _F),
        '$all'(_B, _C, _F, _E).

'$$apply_1'(def, _A, _B, _C, _D):-
        '$def'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, def, _D, _F),
        '$def'(_B, _C, _F, _E).

'$$apply_1'(not_undef, _A, _B, _C, _D):-
        '$not_undef'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, not_undef, _D, _F),
        '$not_undef'(_B, _C, _F, _E).

'$$apply_1'(nf, _A, _B, _C, _D):-
        '$nf'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, nf, _D, _F),
        '$nf'(_B, _C, _F, _E).

'$$apply_1'(hnf, _A, _B, _C, _D):-
        '$hnf'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, hnf, _D, _F),
        '$hnf'(_B, _C, _F, _E).

'$$apply_1'(strict(_A), _B, _C, _D, _E):-
        '$strict'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, strict(_F), _D, _G),
        '$strict'(_F, _B, _C, _G, _E).

'$$apply_1'('strict\''(_A), _B, _C, _D, _E):-
        '$strict\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'strict\''(_F), _D, _G),
        '$strict\''(_F, _B, _C, _G, _E).

'$$apply_1'(map(_A), _B, _C, _D, _E):-
        '$map'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, map(_F), _D, _G),
        '$map'(_F, _B, _C, _G, _E).

'$$apply_1'('.'(_A, _B), _C, _D, _E, _F):-
        $.(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '.'(_F, _G), _D, _H),
        $.(_F, _G, _B, _C, _H, _E).

'$$apply_1'(++(_A), _B, _C, _D, _E):-
        $++(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ++(_F), _D, _G),
        $++(_F, _B, _C, _G, _E).

'$$apply_1'('!!'(_A), _B, _C, _D, _E):-
        '$!!'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '!!'(_F), _D, _G),
        '$!!'(_F, _B, _C, _G, _E).

'$$apply_1'(iterate(_A), _B, _C, _D, _E):-
        '$iterate'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, iterate(_F), _D, _G),
        '$iterate'(_F, _B, _C, _G, _E).

'$$apply_1'(repeat, _A, _B, _C, _D):-
        '$repeat'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, repeat, _D, _F),
        '$repeat'(_B, _C, _F, _E).

'$$apply_1'(copy(_A), _B, _C, _D, _E):-
        '$copy'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, copy(_F), _D, _G),
        '$copy'(_F, _B, _C, _G, _E).

'$$apply_1'(filter(_A), _B, _C, _D, _E):-
        '$filter'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, filter(_F), _D, _G),
        '$filter'(_F, _B, _C, _G, _E).

'$$apply_1'(foldl(_A, _B), _C, _D, _E, _F):-
        '$foldl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldl(_F, _G), _D, _H),
        '$foldl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldl1(_A), _B, _C, _D, _E):-
        '$foldl1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldl1(_F), _D, _G),
        '$foldl1'(_F, _B, _C, _G, _E).

'$$apply_1'('foldl\''(_A, _B), _C, _D, _E, _F):-
        '$foldl\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'foldl\''(_F, _G), _D, _H),
        '$foldl\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanl(_A, _B), _C, _D, _E, _F):-
        '$scanl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanl(_F, _G), _D, _H),
        '$scanl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanl1(_A), _B, _C, _D, _E):-
        '$scanl1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanl1(_F), _D, _G),
        '$scanl1'(_F, _B, _C, _G, _E).

'$$apply_1'('scanl\''(_A, _B), _C, _D, _E, _F):-
        '$scanl\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'scanl\''(_F, _G), _D, _H),
        '$scanl\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldr(_A, _B), _C, _D, _E, _F):-
        '$foldr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldr(_F, _G), _D, _H),
        '$foldr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(foldr1(_A), _B, _C, _D, _E):-
        '$foldr1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, foldr1(_F), _D, _G),
        '$foldr1'(_F, _B, _C, _G, _E).

'$$apply_1'(scanr(_A, _B), _C, _D, _E, _F):-
        '$scanr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanr(_F, _G), _D, _H),
        '$scanr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(auxForScanr(_A, _B), _C, _D, _E, _F):-
        '$auxForScanr'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForScanr(_F, _G), _D, _H),
        '$auxForScanr'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scanr1(_A), _B, _C, _D, _E):-
        '$scanr1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scanr1(_F), _D, _G),
        '$scanr1'(_F, _B, _C, _G, _E).

'$$apply_1'(take(_A), _B, _C, _D, _E):-
        '$take'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, take(_F), _D, _G),
        '$take'(_F, _B, _C, _G, _E).

'$$apply_1'(drop(_A), _B, _C, _D, _E):-
        '$drop'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, drop(_F), _D, _G),
        '$drop'(_F, _B, _C, _G, _E).

'$$apply_1'(splitAt(_A), _B, _C, _D, _E):-
        '$splitAt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, splitAt(_F), _D, _G),
        '$splitAt'(_F, _B, _C, _G, _E).

'$$apply_1'(auxForSplitAt(_A), _B, _C, _D, _E):-
        '$auxForSplitAt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForSplitAt(_F), _D, _G),
        '$auxForSplitAt'(_F, _B, _C, _G, _E).

'$$apply_1'(takeWhile(_A), _B, _C, _D, _E):-
        '$takeWhile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, takeWhile(_F), _D, _G),
        '$takeWhile'(_F, _B, _C, _G, _E).

'$$apply_1'(takeUntil(_A), _B, _C, _D, _E):-
        '$takeUntil'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, takeUntil(_F), _D, _G),
        '$takeUntil'(_F, _B, _C, _G, _E).

'$$apply_1'(dropWhile(_A), _B, _C, _D, _E):-
        '$dropWhile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dropWhile(_F), _D, _G),
        '$dropWhile'(_F, _B, _C, _G, _E).

'$$apply_1'(span(_A), _B, _C, _D, _E):-
        '$span'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, span(_F), _D, _G),
        '$span'(_F, _B, _C, _G, _E).

'$$apply_1'(auxForSpan(_A), _B, _C, _D, _E):-
        '$auxForSpan'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForSpan(_F), _D, _G),
        '$auxForSpan'(_F, _B, _C, _G, _E).

'$$apply_1'(break, _A, _B, _C, _D):-
        '$break'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, break, _D, _F),
        '$break'(_B, _C, _F, _E).

'$$apply_1'(zipWith(_A, _B), _C, _D, _E, _F):-
        '$zipWith'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, zipWith(_F, _G), _D, _H),
        '$zipWith'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(zip(_A), _B, _C, _D, _E):-
        '$zip'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, zip(_F), _D, _G),
        '$zip'(_F, _B, _C, _G, _E).

'$$apply_1'(mkpair(_A), _B, _C, _D, _E):-
        '$mkpair'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mkpair(_F), _D, _G),
        '$mkpair'(_F, _B, _C, _G, _E).

'$$apply_1'(unzip, _A, _B, _C, _D):-
        '$unzip'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, unzip, _D, _F),
        '$unzip'(_B, _C, _F, _E).

'$$apply_1'(auxForUnzip(_A, _B), _C, _D, _E, _F):-
        '$auxForUnzip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForUnzip(_F, _G), _D, _H),
        '$auxForUnzip'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(until(_A, _B), _C, _D, _E, _F):-
        '$until'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, until(_F, _G), _D, _H),
        '$until'(_F, _G, _B, _C, _H, _E).

'$$apply_1'('until\''(_A), _B, _C, _D, _E):-
        '$until\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'until\''(_F), _D, _G),
        '$until\''(_F, _B, _C, _G, _E).

'$$apply_1'(const(_A), _B, _C, _D, _E):-
        '$const'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, const(_F), _D, _G),
        '$const'(_F, _B, _C, _G, _E).

'$$apply_1'(id, _A, _B, _C, _D):-
        '$id'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, id, _D, _F),
        '$id'(_B, _C, _F, _E).

'$$apply_1'(//(_A), _B, _C, _D, _E):-
        $//(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, //(_F), _D, _G),
        $//(_F, _B, _C, _G, _E).

'$$apply_1'(curry(_A, _B), _C, _D, _E, _F):-
        '$curry'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, curry(_F, _G), _D, _H),
        '$curry'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(uncurry(_A), _B, _C, _D, _E):-
        '$uncurry'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uncurry(_F), _D, _G),
        '$uncurry'(_F, _B, _C, _G, _E).

'$$apply_1'(fst, _A, _B, _C, _D):-
        '$fst'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fst, _D, _F),
        '$fst'(_B, _C, _F, _E).

'$$apply_1'(snd, _A, _B, _C, _D):-
        '$snd'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, snd, _D, _F),
        '$snd'(_B, _C, _F, _E).

'$$apply_1'(fst3, _A, _B, _C, _D):-
        '$fst3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fst3, _D, _F),
        '$fst3'(_B, _C, _F, _E).

'$$apply_1'(snd3, _A, _B, _C, _D):-
        '$snd3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, snd3, _D, _F),
        '$snd3'(_B, _C, _F, _E).

'$$apply_1'(thd3, _A, _B, _C, _D):-
        '$thd3'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, thd3, _D, _F),
        '$thd3'(_B, _C, _F, _E).

'$$apply_1'(even, _A, _B, _C, _D):-
        '$even'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, even, _D, _F),
        '$even'(_B, _C, _F, _E).

'$$apply_1'(lcm(_A), _B, _C, _D, _E):-
        '$lcm'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, lcm(_F), _D, _G),
        '$lcm'(_F, _B, _C, _G, _E).

'$$apply_1'(head, _A, _B, _C, _D):-
        '$head'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, head, _D, _F),
        '$head'(_B, _C, _F, _E).

'$$apply_1'(last, _A, _B, _C, _D):-
        '$last'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, last, _D, _F),
        '$last'(_B, _C, _F, _E).

'$$apply_1'(tail, _A, _B, _C, _D):-
        '$tail'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tail, _D, _F),
        '$tail'(_B, _C, _F, _E).

'$$apply_1'(init, _A, _B, _C, _D):-
        '$init'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, init, _D, _F),
        '$init'(_B, _C, _F, _E).

'$$apply_1'(nub, _A, _B, _C, _D):-
        '$nub'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, nub, _D, _F),
        '$nub'(_B, _C, _F, _E).

'$$apply_1'(length, _A, _B, _C, _D):-
        '$length'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, length, _D, _F),
        '$length'(_B, _C, _F, _E).

'$$apply_1'(auxForTranspose(_A), _B, _C, _D, _E):-
        '$auxForTranspose'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, auxForTranspose(_F), _D, _G),
        '$auxForTranspose'(_F, _B, _C, _G, _E).

'$$apply_1'(del(_A), _B, _C, _D, _E):-
        '$del'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, del(_F), _D, _G),
        '$del'(_F, _B, _C, _G, _E).

'$$apply_1'(strToint, _A, _B, _C, _D):-
        '$strToint'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, strToint, _D, _F),
        '$strToint'(_B, _C, _F, _E).

'$$apply_1'(getNumber(_A), _B, _C, _D, _E):-
        '$getNumber'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getNumber(_F), _D, _G),
        '$getNumber'(_F, _B, _C, _G, _E).

'$$apply_1'(intTostr, _A, _B, _C, _D):-
        '$intTostr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, intTostr, _D, _F),
        '$intTostr'(_B, _C, _F, _E).

'$$apply_1'(getString(_A), _B, _C, _D, _E):-
        '$getString'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getString(_F), _D, _G),
        '$getString'(_F, _B, _C, _G, _E).

'$$apply_1'(tkRef2Label, _A, _B, _C, _D):-
        '$tkRef2Label'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkRef2Label, _D, _F),
        '$tkRef2Label'(_B, _C, _F, _E).

'$$apply_1'(tkRef2Wtype, _A, _B, _C, _D):-
        '$tkRef2Wtype'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkRef2Wtype, _D, _F),
        '$tkRef2Wtype'(_B, _C, _F, _E).

'$$apply_1'(tk2tcl(_A, _B), _C, _D, _E, _F):-
        '$tk2tcl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tk2tcl(_F, _G), _D, _H),
        '$tk2tcl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkConfCollection2tcl(_A), _B, _C, _D, _E):-
        '$tkConfCollection2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfCollection2tcl(_F), _D, _G),
        '$tkConfCollection2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(tkConf2tcl(_A, _B, _C), _D, _E, _F, _G):-
        '$tkConf2tcl'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConf2tcl(_F, _G, _H), _D, _I),
        '$tkConf2tcl'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(setlistelems(_A), _B, _C, _D, _E):-
        '$setlistelems'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, setlistelems(_F), _D, _G),
        '$setlistelems'(_F, _B, _C, _G, _E).

'$$apply_1'(tkMenu2tcl(_A), _B, _C, _D, _E):-
        '$tkMenu2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkMenu2tcl(_F), _D, _G),
        '$tkMenu2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(setmenuelems(_A), _B, _C, _D, _E):-
        '$setmenuelems'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, setmenuelems(_F), _D, _G),
        '$setmenuelems'(_F, _B, _C, _G, _E).

'$$apply_1'(tkConfs2handler(_A), _B, _C, _D, _E):-
        '$tkConfs2handler'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfs2handler(_F), _D, _G),
        '$tkConfs2handler'(_F, _B, _C, _G, _E).

'$$apply_1'(tkMenu2handler(_A, _B), _C, _D, _E, _F):-
        '$tkMenu2handler'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkMenu2handler(_F, _G), _D, _H),
        '$tkMenu2handler'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkConfs2tcl(_A, _B, _C), _D, _E, _F, _G):-
        '$tkConfs2tcl'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfs2tcl(_F, _G, _H), _D, _I),
        '$tkConfs2tcl'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkcitems2tcl(_A), _B, _C, _D, _E):-
        '$tkcitems2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkcitems2tcl(_F), _D, _G),
        '$tkcitems2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(tkcitem(_A), _B, _C, _D, _E):-
        '$tkcitem'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkcitem(_F), _D, _G),
        '$tkcitem'(_F, _B, _C, _G, _E).

'$$apply_1'(tkShowCoords, _A, _B, _C, _D):-
        '$tkShowCoords'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkShowCoords, _D, _F),
        '$tkShowCoords'(_B, _C, _F, _E).

'$$apply_1'(tkLabel2Refname, _A, _B, _C, _D):-
        '$tkLabel2Refname'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkLabel2Refname, _D, _F),
        '$tkLabel2Refname'(_B, _C, _F, _E).

'$$apply_1'(aux, _A, _B, _C, _D):-
        '$aux'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux, _D, _F),
        '$aux'(_B, _C, _F, _E).

'$$apply_1'(tkRefname2Label, _A, _B, _C, _D):-
        '$tkRefname2Label'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkRefname2Label, _D, _F),
        '$tkRefname2Label'(_B, _C, _F, _E).

'$$apply_1'(aux1, _A, _B, _C, _D):-
        '$aux1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux1, _D, _F),
        '$aux1'(_B, _C, _F, _E).

'$$apply_1'(tks2tcl(_A, _B, _C), _D, _E, _F, _G):-
        '$tks2tcl'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tks2tcl(_F, _G, _H), _D, _I),
        '$tks2tcl'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkslabels(_A, _B), _C, _D, _E, _F):-
        '$tkslabels'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkslabels(_F, _G), _D, _H),
        '$tkslabels'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkmain2tcl(_A), _B, _C, _D, _E):-
        '$tkmain2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkmain2tcl(_F), _D, _G),
        '$tkmain2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(debugTcl, _A, _B, _C, _D):-
        '$debugTcl'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, debugTcl, _D, _F),
        '$debugTcl'(_B, _C, _F, _E).

'$$apply_1'(forkWish(_A), _B, _C, _D, _E):-
        '$forkWish'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, forkWish(_F), _D, _G),
        '$forkWish'(_F, _B, _C, _G, _E).

'$$apply_1'(runWidget(_A), _B, _C, _D, _E):-
        '$runWidget'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, runWidget(_F), _D, _G),
        '$runWidget'(_F, _B, _C, _G, _E).

'$$apply_1'(aux4, _A, _B, _C, _D):-
        '$aux4'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux4, _D, _F),
        '$aux4'(_B, _C, _F, _E).

'$$apply_1'(runWidgetInit(_A, _B), _C, _D, _E, _F):-
        '$runWidgetInit'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, runWidgetInit(_F, _G), _D, _H),
        '$runWidgetInit'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(runWidgetPassive(_A), _B, _C, _D, _E):-
        '$runWidgetPassive'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, runWidgetPassive(_F), _D, _G),
        '$runWidgetPassive'(_F, _B, _C, _G, _E).

'$$apply_1'(initSchedule(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$initSchedule'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, initSchedule(_F, _G, _H, _I), _D, _J),
        '$initSchedule'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(tkSchedule(_A, _B, _C), _D, _E, _F, _G):-
        '$tkSchedule'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkSchedule(_F, _G, _H), _D, _I),
        '$tkSchedule'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(aux2(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$aux2'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux2(_F, _G, _H, _I), _D, _J),
        '$aux2'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(tkTerminateWish(_A), _B, _C, _D, _E):-
        '$tkTerminateWish'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkTerminateWish(_F), _D, _G),
        '$tkTerminateWish'(_F, _B, _C, _G, _E).

'$$apply_1'(tkSelectEvent(_A, _B, _C), _D, _E, _F, _G):-
        '$tkSelectEvent'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkSelectEvent(_F, _G, _H), _D, _I),
        '$tkSelectEvent'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkGetVar(_A, _B), _C, _D, _E, _F):-
        '$tkGetVar'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetVar(_F, _G), _D, _H),
        '$tkGetVar'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkGetVarMsg(_A, _B), _C, _D, _E, _F):-
        '$tkGetVarMsg'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetVarMsg(_F, _G), _D, _H),
        '$tkGetVarMsg'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(aux3(_A, _B, _C), _D, _E, _F, _G):-
        '$aux3'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux3(_F, _G, _H), _D, _I),
        '$aux3'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkGetVarValue(_A, _B), _C, _D, _E, _F):-
        '$tkGetVarValue'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetVarValue(_F, _G), _D, _H),
        '$tkGetVarValue'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkParseInt(_A), _B, _C, _D, _E):-
        '$tkParseInt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkParseInt(_F), _D, _G),
        '$tkParseInt'(_F, _B, _C, _G, _E).

'$$apply_1'(checkWishConsistency(_A), _B, _C, _D, _E):-
        '$checkWishConsistency'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, checkWishConsistency(_F), _D, _G),
        '$checkWishConsistency'(_F, _B, _C, _G, _E).

'$$apply_1'(escape_tcl, _A, _B, _C, _D):-
        '$escape_tcl'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, escape_tcl, _D, _F),
        '$escape_tcl'(_B, _C, _F, _E).

'$$apply_1'(tkVoid, _A, _B, _C, _D):-
        '$tkVoid'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkVoid, _D, _F),
        '$tkVoid'(_B, _C, _F, _E).

'$$apply_1'(tkExit, _A, _B, _C, _D):-
        '$tkExit'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkExit, _D, _F),
        '$tkExit'(_B, _C, _F, _E).

'$$apply_1'(tkGetValue(_A), _B, _C, _D, _E):-
        '$tkGetValue'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetValue(_F), _D, _G),
        '$tkGetValue'(_F, _B, _C, _G, _E).

'$$apply_1'(tkSetValue(_A, _B), _C, _D, _E, _F):-
        '$tkSetValue'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkSetValue(_F, _G), _D, _H),
        '$tkSetValue'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkUpdate(_A, _B), _C, _D, _E, _F):-
        '$tkUpdate'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkUpdate(_F, _G), _D, _H),
        '$tkUpdate'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkConfig(_A, _B), _C, _D, _E, _F):-
        '$tkConfig'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfig(_F, _G), _D, _H),
        '$tkConfig'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkFocus(_A), _B, _C, _D, _E):-
        '$tkFocus'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkFocus(_F), _D, _G),
        '$tkFocus'(_F, _B, _C, _G, _E).

'$$apply_1'(tkAddCanvas(_A, _B), _C, _D, _E, _F):-
        '$tkAddCanvas'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkAddCanvas(_F, _G), _D, _H),
        '$tkAddCanvas'(_F, _G, _B, _C, _H, _E).

% primitives

'$$apply_1'(uminus, _A, _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uminus, _D, _F),
        '$uminus'(_B, _C, _F, _E).

'$$apply_1'(abs, _A, _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, abs, _D, _F),
        '$abs'(_B, _C, _F, _E).

'$$apply_1'(sqrt, _A, _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sqrt, _D, _F),
        '$sqrt'(_B, _C, _F, _E).

'$$apply_1'(ln, _A, _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ln, _D, _F),
        '$ln'(_B, _C, _F, _E).

'$$apply_1'(exp, _A, _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exp, _D, _F),
        '$exp'(_B, _C, _F, _E).

'$$apply_1'(sin, _A, _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sin, _D, _F),
        '$sin'(_B, _C, _F, _E).

'$$apply_1'(cos, _A, _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cos, _D, _F),
        '$cos'(_B, _C, _F, _E).

'$$apply_1'(tan, _A, _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tan, _D, _F),
        '$tan'(_B, _C, _F, _E).

'$$apply_1'(cot, _A, _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cot, _D, _F),
        '$cot'(_B, _C, _F, _E).

'$$apply_1'(asin, _A, _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asin, _D, _F),
        '$asin'(_B, _C, _F, _E).

'$$apply_1'(acos, _A, _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acos, _D, _F),
        '$acos'(_B, _C, _F, _E).

'$$apply_1'(atan, _A, _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atan, _D, _F),
        '$atan'(_B, _C, _F, _E).

'$$apply_1'(acot, _A, _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acot, _D, _F),
        '$acot'(_B, _C, _F, _E).

'$$apply_1'(sinh, _A, _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sinh, _D, _F),
        '$sinh'(_B, _C, _F, _E).

'$$apply_1'(cosh, _A, _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cosh, _D, _F),
        '$cosh'(_B, _C, _F, _E).

'$$apply_1'(tanh, _A, _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tanh, _D, _F),
        '$tanh'(_B, _C, _F, _E).

'$$apply_1'(coth, _A, _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, coth, _D, _F),
        '$coth'(_B, _C, _F, _E).

'$$apply_1'(asinh, _A, _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asinh, _D, _F),
        '$asinh'(_B, _C, _F, _E).

'$$apply_1'(acosh, _A, _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acosh, _D, _F),
        '$acosh'(_B, _C, _F, _E).

'$$apply_1'(atanh, _A, _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atanh, _D, _F),
        '$atanh'(_B, _C, _F, _E).

'$$apply_1'(acoth, _A, _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acoth, _D, _F),
        '$acoth'(_B, _C, _F, _E).

'$$apply_1'(+(_A), _B, _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, +(_F), _D, _G),
        $+(_F, _B, _C, _G, _E).

'$$apply_1'(-(_A), _B, _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, -(_F), _D, _G),
        $-(_F, _B, _C, _G, _E).

'$$apply_1'(*(_A), _B, _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, *(_F), _D, _G),
        $*(_F, _B, _C, _G, _E).

'$$apply_1'(min(_A), _B, _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, min(_F), _D, _G),
        '$min'(_F, _B, _C, _G, _E).

'$$apply_1'(max(_A), _B, _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, max(_F), _D, _G),
        '$max'(_F, _B, _C, _G, _E).

'$$apply_1'(/(_A), _B, _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /(_F), _D, _G),
        $/(_F, _B, _C, _G, _E).

'$$apply_1'(**(_A), _B, _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, **(_F), _D, _G),
        $**(_F, _B, _C, _G, _E).

'$$apply_1'(log(_A), _B, _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, log(_F), _D, _G),
        '$log'(_F, _B, _C, _G, _E).

'$$apply_1'(^(_A), _B, _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ^(_F), _D, _G),
        $^(_F, _B, _C, _G, _E).

'$$apply_1'(div(_A), _B, _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, div(_F), _D, _G),
        '$div'(_F, _B, _C, _G, _E).

'$$apply_1'(mod(_A), _B, _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mod(_F), _D, _G),
        '$mod'(_F, _B, _C, _G, _E).

'$$apply_1'(gcd(_A), _B, _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, gcd(_F), _D, _G),
        '$gcd'(_F, _B, _C, _G, _E).

'$$apply_1'(round, _A, _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, round, _D, _F),
        '$round'(_B, _C, _F, _E).

'$$apply_1'(trunc, _A, _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trunc, _D, _F),
        '$trunc'(_B, _C, _F, _E).

'$$apply_1'(floor, _A, _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, floor, _D, _F),
        '$floor'(_B, _C, _F, _E).

'$$apply_1'(ceiling, _A, _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ceiling, _D, _F),
        '$ceiling'(_B, _C, _F, _E).

'$$apply_1'(toReal, _A, _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, toReal, _D, _F),
        '$toReal'(_B, _C, _F, _E).

'$$apply_1'(<(_A), _B, _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <(_F), _D, _G),
        $<(_F, _B, _C, _G, _E).

'$$apply_1'(<=(_A), _B, _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <=(_F), _D, _G),
        $<=(_F, _B, _C, _G, _E).

'$$apply_1'(>(_A), _B, _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >(_F), _D, _G),
        $>(_F, _B, _C, _G, _E).

'$$apply_1'(>=(_A), _B, _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >=(_F), _D, _G),
        $>=(_F, _B, _C, _G, _E).

'$$apply_1'(==(_A), _B, _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ==(_F), _D, _G),
        $==(_F, _B, _C, _G, _E).

'$$apply_1'(/=(_A), _B, _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /=(_F), _D, _G),
        $/=(_F, _B, _C, _G, _E).

'$$apply_1'(ord, _A, _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ord, _D, _F),
        '$ord'(_B, _C, _F, _E).

'$$apply_1'(chr, _A, _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, chr, _D, _F),
        '$chr'(_B, _C, _F, _E).

'$$apply_1'(putChar, _A, _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putChar, _D, _F),
        '$putChar'(_B, _C, _F, _E).

'$$apply_1'(return, _A, _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, return, _D, _F),
        '$return'(_B, _C, _F, _E).

'$$apply_1'(>>(_A), _B, _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>(_F), _D, _G),
        $>>(_F, _B, _C, _G, _E).

'$$apply_1'(>>=(_A), _B, _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>=(_F), _D, _G),
        $>>=(_F, _B, _C, _G, _E).

'$$apply_1'(putStr, _A, _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStr, _D, _F),
        '$putStr'(_B, _C, _F, _E).

'$$apply_1'(putStrLn, _A, _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLn, _D, _F),
        '$putStrLn'(_B, _C, _F, _E).

'$$apply_1'(cont1, _A, _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont1, _D, _F),
        '$cont1'(_B, _C, _F, _E).

'$$apply_1'(cont2(_A), _B, _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont2(_F), _D, _G),
        '$cont2'(_F, _B, _C, _G, _E).

'$$apply_1'(writeFile(_A), _B, _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeFile(_F), _D, _G),
        '$writeFile'(_F, _B, _C, _G, _E).

'$$apply_1'(readFile, _A, _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFile, _D, _F),
        '$readFile'(_B, _C, _F, _E).

'$$apply_1'(readFileContents, _A, _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFileContents, _D, _F),
        '$readFileContents'(_B, _C, _F, _E).

'$$apply_1'(openFile(_A), _B, _C, _D, _E):-
        '$openFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, openFile(_F), _D, _G),
        '$openFile'(_F, _B, _C, _G, _E).

'$$apply_1'(closeFile, _A, _B, _C, _D):-
        '$closeFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, closeFile, _D, _F),
        '$closeFile'(_B, _C, _F, _E).

'$$apply_1'(end_of_file, _A, _B, _C, _D):-
        '$end_of_file'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, end_of_file, _D, _F),
        '$end_of_file'(_B, _C, _F, _E).

'$$apply_1'(getCharFile, _A, _B, _C, _D):-
        '$getCharFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getCharFile, _D, _F),
        '$getCharFile'(_B, _C, _F, _E).

'$$apply_1'(putCharFile(_A), _B, _C, _D, _E):-
        '$putCharFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putCharFile(_F), _D, _G),
        '$putCharFile'(_F, _B, _C, _G, _E).

'$$apply_1'(putStrFile(_A), _B, _C, _D, _E):-
        '$putStrFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrFile(_F), _D, _G),
        '$putStrFile'(_F, _B, _C, _G, _E).

'$$apply_1'(putStrLnFile(_A), _B, _C, _D, _E):-
        '$putStrLnFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLnFile(_F), _D, _G),
        '$putStrLnFile'(_F, _B, _C, _G, _E).

'$$apply_1'(getLineFile, _A, _B, _C, _D):-
        '$getLineFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getLineFile, _D, _F),
        '$getLineFile'(_B, _C, _F, _E).

'$$apply_1'(contin1(_A), _B, _C, _D, _E):-
        '$contin1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, contin1(_F), _D, _G),
        '$contin1'(_F, _B, _C, _G, _E).

'$$apply_1'(contin2(_A), _B, _C, _D, _E):-
        '$contin2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, contin2(_F), _D, _G),
        '$contin2'(_F, _B, _C, _G, _E).

'$$apply_1'(openWish, _A, _B, _C, _D):-
        '$openWish'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, openWish, _D, _F),
        '$openWish'(_B, _C, _F, _E).

'$$apply_1'(readWish, _A, _B, _C, _D):-
        '$readWish'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readWish, _D, _F),
        '$readWish'(_B, _C, _F, _E).

'$$apply_1'(writeWish(_A), _B, _C, _D, _E):-
        '$writeWish'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeWish(_F), _D, _G),
        '$writeWish'(_F, _B, _C, _G, _E).

'$$apply_1'(closeWish, _A, _B, _C, _D):-
        '$closeWish'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, closeWish, _D, _F),
        '$closeWish'(_B, _C, _F, _E).

'$$apply_1'(newVar, _A, _B, _C, _D):-
        '$newVar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, newVar, _D, _F),
        '$newVar'(_B, _C, _F, _E).

'$$apply_1'(newVar1, _A, _B, _C, _D):-
        '$newVar1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, newVar1, _D, _F),
        '$newVar1'(_B, _C, _F, _E).

'$$apply_1'(newVar2, _A, _B, _C, _D):-
        '$newVar2'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, newVar2, _D, _F),
        '$newVar2'(_B, _C, _F, _E).

'$$apply_1'(readVar, _A, _B, _C, _D):-
        '$readVar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readVar, _D, _F),
        '$readVar'(_B, _C, _F, _E).

'$$apply_1'(writeVar(_A), _B, _C, _D, _E):-
        '$writeVar'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeVar(_F), _D, _G),
        '$writeVar'(_F, _B, _C, _G, _E).

'$$apply_1'(writeVar1, _A, _B, _C, _D):-
        '$writeVar1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeVar1, _D, _F),
        '$writeVar1'(_B, _C, _F, _E).

'$$apply_1'(if_then_else(_A, _B), _C, _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then_else(_F, _G), _D, _H),
        '$if_then_else'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(if_then(_A), _B, _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then(_F), _D, _G),
        '$if_then'(_F, _B, _C, _G, _E).

'$$apply_1'(flip(_A, _B), _C, _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, flip(_F, _G), _D, _H),
        '$flip'(_F, _G, _B, _C, _H, _E).


/************   CODE FOR INFIX OPERATORS   ************/

infix('!!', left, 90).
infix('.', right, 90).
infix(++, right, 50).
infix(//, right, 40).
infix(and, right, 40).
infix(/\, right, 40).
infix(or, right, 30).
infix(\/, right, 30).
infix(\\, noasoc, 50).
infix(^, noasoc, 98).
infix(**, noasoc, 98).
infix(/, left, 90).
infix(*, right, 90).
infix(+, left, 50).
infix(-, left, 50).
infix(<, noasoc, 30).
infix(<=, noasoc, 30).
infix(>, noasoc, 30).
infix(>=, noasoc, 30).
infix(==, noasoc, 10).
infix(/=, noasoc, 10).
infix(>>, left, 11).
infix(>>=, left, 11).



'$flip'(F, A1, A2, H, Cin, Cout):-         '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).
