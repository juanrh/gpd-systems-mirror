%----------------------------------------------------------------------------%
% compil.pl
%----------------------------------------------------------------------------%
/*
- Fecha: 23-03-1996
- Author: Rafa Caballero.
- Description: Programa principal para la generacion de codigo intermedio.
  Traduce a codigo intermedio el fichero File.toy dejando la salida
  en File.out usando como fichero intermdio File.tmp.
- Modules which import it: process, transob, gramma_toy.
- Imported modules:
    > errortoy: a este modulo se le llama con varios predicados: con
      'treatLexiconError' y 'treatSintacticError' (al leer el fichero de
      entrada para hacerle el analisis lexico, sintactic y parte del 
      semantic en la primera fase de compilacion, hay que mostrar por 
      pantalla los errores lexicos y sintactics que se han producido), con
      'treatError' (al finalizar la primera fase de compilacion, hay que 
      comprobar si ha habido conflictos: un tipo y una declaracion data con
      el mismo nombre, una constructora y una funcion con el mismo 
      nombre... Si se da uno de estos conflictos, se llama a treatError y 
      este escribe por pantalla el mensaje de error), con 'variablesRepeated'
      (para hacer el analisis semantico, hay que hacer comprobaciones 
      semanticas como ver que en una sentenciadata no hay variables 
      repetidas en la cabeza , y dar error si es que las hay), con 
      'errorIfNotContained' (otra comprobacion semantica es ver que en una
      sentencia data, en la derecha no hay variables que no hay en la 
      izquierda. Si esto no se cumole hay que dar error), con
          'patterns_as_nk'
      (para hacer el analisis semantico de una regla de funcion, eliminamos
      los patrones as) y con 'changeArity' (para hacer el analisis 
      semantico de una funcion, hay que comprobar que si la funcion ya 
      habia aparecido, debe tener la misma aridad. Si no, hay que dar 
      error). Tambien se le llama con 'isVariable', 'errorFaultDeclaration'
      y 'treatError1'.
      > token: con 'searchToken' (en la primera fase de compilacion, hay 
      que hacer el analisis lexico, sintactic y parte del semantico del 
      fichero de entrada. Para ello, hay que buscar el primer caracter no 
      blanco de la primera seccion, y esto se hace con searchToken) y con 
      'readSection' (realiza el analisis lexico de una seccion, por tanto se 
      le llama en la primera fase de compilacion).
    > gramma_toy (con 'section'): para analizar sintacticamente un 
      fichero, hay que reconocer el componente basico, que es la seccion).
    > tools (con 'take_n_elements', 'joinLists', 'mixLists',
      'searchInList', 'writeText', 'append', 'lookandput','closeHollow',
      'endFile','member_relax', 'member' y 'concatenation').
    > plgenerated (con 'constr', 'funct','infix/3').
    > primitives
    > dyn
    
- Modified: 
    11-01-1999 (var. en data)
    30/09/99 mercedes (se han comentado los predicados)
    26/10/99 mercedes (modularizacion).
    05/11/99 mercedes (se ha modificado el predicado includeIfNew, de 
              manera que solo se permiten 2 declaraciones 
              consecutivas del mismo objeto si este es una refla de
              funcion. Esto se ha hecho para no permitir que haya 
              varias definiciones de un mismo data aunque esten
              seguidas, i.e., no podemos tener las siguientes
              declaraciones:
              data t A = p A
              data t A = c A
              por tanto en cuanto ya tengamos ese elemento data en
              la tabla de los datas, sea el anterior o no, hay que
              dar error. Lo mismo pasa con el resto de cosas que no
              sean funcion).
    08/11/99 mercedes (Habia un error con los alias de tipos.Para arreglarlo
              he modificado el predicado checkTypes). 
    24/03/00 mercedes (Se ha cambiado la prioridad por defecto de algunos
               operadores en 'priorityOperator' porque si no se
               producian errores indeseables).

    07/04/00 mercedes y rafa (se ha modificado 'transformToList para evitar
                  un error con los alias).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



:- module(compil,[compil/3,lexicon/5, createTablesCompilation/1, 
          semantic/7, eliminateApply/8,extractTable/3,priorityOperator/4,
%F010204 Es necesario para primitivCod
          chainToyToProlog/2,
          variables/3]). 
                   

:- load_files(errortoy,[if(changed),imports([treatLexiconError/1, 
             treatError/3, treatError/2, isVariable/1,
             treatSintacticError/1, variablesRepeated/5, 
             errorIfNotContained/4, patterns_as_nk/10, changeArity/5,
             errorFaultDeclaration/2,treatError1/3,treatError/4,
             name_of_variable/2])]). 
             
:- load_files(token,[if(changed),imports([searchToken/3, readSection/6])]).

:- load_files(gramma_toy,[if(changed),imports([section/7])]).

:- load_files(tools,[if(changed),imports([take_n_elements/6,joinLists/2,
              mixLists/3,searchInList/3,writeText/1,append/3,
%F010204
              root_path/1,include_path/1,
              lookandput/4,closeHollow/1,endFile/1,member_relax/2,member/2,
              concatenation/2,concatLsts/2,tupToArgs/2])]).

:- load_files(dyn,[if(changed)]).

:- load_files(basic,[if(changed),imports([constr/4,funct/5,infix/3])]).

/* Este modulo llama al modulo plgenerated en el predicado lookToSee cuando
estamos en tiempo de ejecucion, es decir, cuando estamos con objetivos.
Lo que se hace es cargar inicialmente el fichero basic.pl que contiene el modulo
plgenerated inicial, pero cuando se genere un fichero.pl y se cargue (en el modulo
process), como lo generamos como modulo plgenerated, se borra el modulo 
plgenerated antiguo y se carga este nuevo.
*/

:- load_files(primFunct,[if(changed)]).

:- load_files(primitivCod,[if(changed)]).

:- (
    clpr_active,!,load_files(primitivCodClpr,[if(changed)])
   ;
    load_files(primitivCod,[if(changed)])
   ).

:- (
    io_active,!,load_files(primitivCodIo,[if(changed)])
   ;
    1==1
   ).

:- (
    iographic_active,!,load_files(primitivCodGra,[if(changed)])
   ;
    1==1
   ).
   
:- use_module(library(system)).

/*****************************************************************************/
/*                            C O M P I L A                  */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
%compil(+FileIn)
% version de compil que traduce a codigo intermedio el fichero 'FileIn.toy'
% dejando la salida en 'FileIn.out', usando como fichero intermedio
% 'FileIn.tmp'
%-----------------------------------------------------------------------------%

compil(FileIn) :-
        !,
        compil(FileIn,_).


%-----------------------------------------------------------------------------%
% compil(+NameFile,+FileIn,-Error)
% igual que el anterior, pero devolviendo 'true' si hay error o 'false' si no.
%-----------------------------------------------------------------------------%

compil(NameFile,FileIn,Error) :-
    % formamos los nombres de los ficheros
        %name(FileIn,Chain),
        append(FileIn,".toy",ChainIn), name(FIn,ChainIn),
        append(FileIn,".tmp",ChainTmp), name(FTmp,ChainTmp),
        append(FileIn,".out",ChainOut), name(FOut,ChainOut),
        
        % Depu 10/11/00 mercedes
        deleteDebugFiles(NameFile),
        % Fin Depu
       
        % hacemos la compilacion
        compil(FIn,FTmp,FOut,Error),
        % asegurarnos de que el error vale true o false
        ( Error = false ; Error = true),
        !.

% Depu 10/11/00 mercedes
deleteDebugFiles(FileIn):-
        % borramos el .debug.pl y el .debug.tmp.out porque vamos a crear un 
        % nuevo fichero .tmp.out
        append(FileIn,".debug.pl",ChainDebugpl), name(FDebugpl,ChainDebugpl),
        append(FileIn,".debug.tmp.out",ChainDebugtmpout),name(FDebugtmpout,ChainDebugtmpout),
        % primero nos aseguramos de que existe
        (
         file_exists(FDebugpl),
         delete_file(FDebugpl, [ignore])
        ;
         true
        ),
        (
         file_exists(FDebugtmpout),
         delete_file(FDebugtmpout, [ignore])
        ;
         true
        ),
        !.
% Fin Depu
 

% compil(+FileIn,+FileTmp,+FileOut,-Error)
% clausula principal.
% Argumentos: - FileIn : Name del fichero de entrada
%             - FileTmp : Name del fichero intermedio temporal
%             - FileOut : Name del fichero de salida
%             - Error   : false si no ha habido error o true e.o.c.
% Si no hay errores, genera un fichero 'codigo.sal'. Si hay errores los
% muestra, se para y no genera nada.
compil(FileIn,FileTmp,FileOut,Error) :-
        !,
        nl,
        write('Checking syntax '),
        nl,
        % crear las tablas que se usaran durante el proceso de compilaci�n
        createTablesCompilation(Tab),
        % valores iniciales de las tablas
        initialsValuesTables(Tab),
        % primera pasada
        firstPhaseCompilation(FileIn,FileTmp,Tab,Error),
        write('Done.'), nl,nl,
        write('Checking dependencies...'),
% SICSTUS
flush_output,


        % segunda, quitando los apply y unificando funciones
        secondPhaseCompilation(FileTmp,FileOut,Tab,Error),
        write('Done.'), nl.

%       si tenemos que borrar las tablas de compilacion de la B.D.
%       deleteTablesOfCompilation(Tab).



%-----------------------------------------------------------------------------%
% compil(+H,+HOut,+DataChar,DataSin,[-Tables,]+N,-Error)
% H        : Handle del fichero del que va leyendo y tratando secciones
% HOut  : Handle del fichero en el que se ira escribiendo la salida.
% DataChar : posicion actual en H. Viene dada por (Line_ini,Pos_ini,Ch_ini).
% DataSin : Dato de la pieza sintactica que se esta tratando.
% Tables   : Tablas necesarias para llevar los datos semanticos.
% N        : Numero de secciones erroneas habidas hasta el momento
% Error    : Si no hay error no toma ningun valor. Si lo hay vale true.
% Cada vez que ha tratado una seccion, se llama a si mismo para continuar.
% Para cuando se ha llegado al fin de fichero sin errores.
%-----------------------------------------------------------------------------%

compil(H,HOut,DataChar,DataSin,Tables,N,Error) :-
        lexicon(H,DataChar,ListTokens,(Line,Pos,Ch_end),Error2),
        sintactic(Tables,ListTokens,S,Error2),
        semantic(HOut,S,S2,DataSin,NewSin,Tables,Error2),
        (\+ var(Error2), Error2=true, Error=true, N2 is N+1;N2=N),
        % escribimos la salida
        writeSection(HOut,S2,Error),
        write('.'),
% SICSTUS
flush_output,
        !,
        nextCompilation(H,HOut,(Line,Pos,Ch_end),
                              NewSin,Tables,N2,Error).


%-----------------------------------------------------------------------------%
% nextCompilation tiene los mismos argumentos que compil/7.
% Lo que hace es continuar con la compilacion aunque hayan aparecido errores, 
% para que el usuario tenga en una sola compilacion la mayor informacion posible
% sobre sus errores. Para que esto no produzca errores en cascada, solo se
% permiten 10 errores como maximo. 
%-----------------------------------------------------------------------------%

% si es fin de fichero o van 10 errores, parar
nextCompilation(_,_,(_,_,Ch),_,_,N,_):-
        (
         endFile(Ch)
        ;
         N >= 10
        ),
        !.

% en otro caso seguir compilando secciones
nextCompilation(HE,HS,Present,DataSin,Tab,N,Error):-
        !,
        compil(HE,HS,Present,DataSin,Tab,N,Error).

%-----------------------------------------------------------------------------%
% initialsValuesTables(+Tab) : inicializaciones en las tablas
%-----------------------------------------------------------------------------%

initialsValuesTables(Tab) :-
        % tabla con los valores iniciales
        Initial=
        [
         % Yoli YGR 5/12/2005 INICIO.
         % Inicializa la tabla 'annotate' con un elemento
         (annotate,annotate(deterministic(if_then_else)),annotate(deterministic(if_then_else))),  
         % YGR 5/12/2005 FIN

         (constructors,(':',2),_), % constructora de listas en Toy
         
         % Input/output. Mercedes 29-04-00
         % incluimos como predefinido el tipo de datos io (data io A = '$io'(A))
         (constructors, ('$io',1), _),
         (data, io, data(io)),
         
         (constructors, ('$stream',1), _),  % 12/05/00 mercedes
         (data, handle, data(handle)),
         
         % 12/05/00 mercedes
         % incluimos como predefinido el tipo de datos ioMode 
         % (data ioMode = readMode | writeMode | appendMode)
         (constructors,(readMode,0),_),
         (constructors,(writeMode,0),_),
         (constructors,(appendMode,0),_),
         (data, ioMode, data(ioMode)), 


     % 29/05/00 mercedes
         % incluimos como predefinido el tipo de datos channel 
         % (data channel = '$channel'(Win,Wout))
         (constructors,('$channel',2), _),
         (data,channel,data(channel)),

     % 14/09/00 mercedes
     % incluimos como predefinido el tipo de datos varmut 
         % (data varmut A = '$varmut'(A))
         (constructors,('$varmut',1), _),
         (data, varmut, data(varmut)),

     % 28-04-00 
         % incluimos como predefinido el tipo 'unit'
         (data, unit,data(unit)),

         % 06/08/01 depu rafa
         % incluimos como predefinido el tipo:
         % data pVal = pValBottom | pValVar [char] | pValChar char |
         %             pValNum [char]  | pValApp [char] [pVal]
         (constructors,('pValBottom', 0),_),
         (constructors,('pValChar', 1),_),
         (constructors,('pValNum', 1),_),
         (constructors,('pValVar', 1),_),
         (constructors,('pValApp', 2),_),
         (data, pVal,data(pVal)),

       %data constraint = constraint [atomicConstraint]
       %data atomicConstraint = atomicConstraint  [char] [pVal] pVal
        (constructors,(constraint, 1),_),
        (constructors,(atomicConstraint, 3),_),
         (data, constraint,data(constraint)),
         (data, atomicConstraint,data(atomicConstraint)),

        % type fun = [char] % nombre de la funci�n
        % type  ruleNum = [char] % n�mero de orden de aparici�n de la regla entre todas las que definen la funci�n
        % type args = [pVal]  % argumentos de llamada
        % type result = pVal % resultado
        % type body = [char] % representaci�n del cuerpo como string para mostrar la instancia de regla
        % type conds = [pVal] % representaci�n de las condiciones

        % data cTree = cTreeNode fun args result body conds ruleNum [(pVal,cTree)]
        %                      | cTreeVoid

        %data ccTree = cTree ::<== constraint

        (constructors, (cTreeNode, 7), _),
        (constructors, (cTreeVoid, 0), _),
        (constructors, (::<==, 2),_),

        (data,cTree,data(cTree)),
        (data,ccTree, data(ccTree))
       ],
        includeInitialSymbols(Tab,Initial).


includeInitialSymbols(_Tab,[]) :- !.
includeInitialSymbols(Tab,[(NameTab,Value,Info)|Xs]) :-
        includeIfNew(NameTab,Tab,Value,false,nothing,Info,14,-1,_Error), 
    includeInitialSymbols(Tab,Xs).


/*****************************************************************************/
/*                     P R I M E R A   F A S E                   */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% firstPhaseCompilation(+FileIn,+FileOut,?Tab,?Error)
% se encarga del analisis l�xico, sintactic y parte del semantico del
% fichero FileIn. El resultado queda en el fichero FileOut, 
% junto con el contenido de las tablas de simbolos que se van rellenando.
% 'Error' valdra  true si hay error y se quedara como estaba e.o.c.
%-----------------------------------------------------------------------------%

firstPhaseCompilation(FileIn,FileOut,Tab,Error) :-
        !,

% ARITY para la apertura de ficheros
%       open(H,FileIn,r),    % abrimos para lectura el fichero de entrada
%       create(Temp,FileOut), % abrimos para escritura el fichero temporal


% SICSTUS
        open(FileIn,read,H),    % abrimos para lectura el fichero de entrada
        open(FileOut,write,Temp), % abrimos para escritura el fichero temporal

        % buscamos algun caracter no blanco
        beginningSection(H,FirstChar,Error),
        % llamamos a compil/7 que es quien realmente hace el trabajo
        compil(H,Temp,FirstChar,nothing,Tab,0,Error),

        % tapamos los huecos del final. Hay que pasarle el n� de tabla 1�.
        closeHollowsTables(Tab,1),
        % 15/02/99  evitar conflictos y/o ambiguedades
        checkConflicts(Tab,Error),
        % comprobamos referencias para asegurarnos de que ningun objeto
        % queda sin declarar
        checkReferences(Tab,Error),
        % fin de la primera fase
    close(H),
        close(Temp).

%-----------------------------------------------------------------------------%
% beginningSection(+H,FirstChar,-Error)
% Devuelve los datos que identifican el primer caracter de la primera seccion.
% si hay error, lo trata y devuelve Error = true. e.o.c. Error=false
%-----------------------------------------------------------------------------%

beginningSection(H,(Line,Pos,Ch),Error) :-
        !,
        searchToken(H,(1,0,32), (Line,Pos,Ch)),
        treatLexiconError(Error).




/*****************************************************************************/
/*              C O M P R U E B A   C O N F L I C T O S              */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% checkConflicts(+Tables,?Error)
% Se utiliza tras finalizar la primera fase. Las Tablas ya no deben tener
% hueco al final. Si ha habido errores en la primera fase no se hace nada
% Los conflictos que se detectan son:
%  1) Un tipo y una dec. data con el mismo nombre
%  2) Una constructora y una funcion con el mismo nombre
%  3) Una funcion o una constr con el mismo nombre que una constr o una func
%     predefinida
%-----------------------------------------------------------------------------%

% si ha habido errores no comprobamos conflictos
checkConflicts(_,Error) :- Error==true,!.
% en otro caso si.
checkConflicts(T,Error) :-
        !,
        % extraemos las tablas
        extractTable(data,T,Data),
        extractTable(types,T,Types),
        extractTable(constructors,T,Const),
        extractTable(functions,T,Functi),
        % comprobacion 1)
        conflict_type_data(Types,Data,Error),
        % comprobacion 2)
        conflict_const_funct(Const,Functi,Error).

%-----------------------------------------------------------------------------%
% conflict_type_data(+Types,+Data,?Error) donde:
% +Types: tabla con los tipos definidos
% +Data: tabla con lo data definidos
% ?Error: indica si hay conflicto 1) o no lo hay. 
% Busca alias de tipo que esten definidos tb. como data
%-----------------------------------------------------------------------------%

conflict_type_data([],_Data,_E):-!.
conflict_type_data([(V,_)|Rt],Data,E):-
    member(V,Data),
    !,
    % error
    E = true,
    error_conflict(33,V,"defined as a type alias name and a data name"),
    conflict_type_data(Rt,Data,E).
      
conflict_type_data([(_V,_)|Rt],Data,E):-
    !,
    conflict_type_data(Rt,Data,E).

%-----------------------------------------------------------------------------%
% conflict_const_funct(+Const,+Functi,?Error) donde:
% +Const: tabla con las constructoras definidas
% +Functi: tabla con las funciones definidad
% ?Error: indica si hay conflicto 2) o no lo hay.
% Busca constructoras que esten definidos tb. como funciones
%-----------------------------------------------------------------------------%

conflict_const_funct([],_Func,_E):- !.
conflict_const_funct([(V,_)|Rt],Func,E):-
    member_relax((V,_),Func),
    !,
    % error V def. como constructora y como funcion
    E = true,
    error_conflict(34,V,"defined as a constructor name and a function name"),
    conflict_const_funct(Rt,Func,E).
      
conflict_const_funct([(_V,_)|Rt],Func,E):-
    !,
    conflict_const_funct(Rt,Func,E).





/* Lo que viene ahora, se haria para hacer la comprobacion del conflicto 3),
pero no hace falta porque las funciones y constructoras predefinidas forman
parte de las tablas, y por tanto esto ya se comprueba en conflict_const_funct.

% mira a ver si hay conflicto entre las tablas y los simbolos definidos a pelo
conflict_const_funct_predef(LConst, LFunc, E) :- 
   conflict_const_predef(LFunc, E),
   conflicto_funct_predef(LConst, E).

% mira a ver si alguna funcion del usuario coincide con una constructora predef.
conflict_const_predef([], _E) :- !.
conflict_const_predef([(F,_A)|Lf], E) :-
   lookToSee(n_use_tables,constructor,(F,_),_Table),
   !,
   % la funcion del usuario F ya estaba def. como constructora
   E = true,
   error_conflict(31,F,"not allowed as function name (reserved symbol)"),
   conflict_const_predef(Lf,E).

% si llega hasta aqui es que F no estaba def. como constructora predef.
conflict_const_predef([(_F,_A)|Lf], E) :-
    !,
   conflict_const_predef(Lf,E).

% mira a ver si alguna funcion del usuario coincide con una funcion predef.
conflicto_funct_predef([],_E) :- !.
conflicto_funct_predef([(Cons,_A) |LC],E) :-
   lookToSee(n_use_tables,function,(Cons,_),_Table),
   !,
   % la constructora del usuario Cons ya estaba def. como funcion predef
   E = true,
   error_conflict(32,Cons,"not allowed as constructor name (reserved symbol)"),
   conflicto_funct_predef(LC,E).

% si llega hasta aqui es que C no estaba def. como funcion predef.
conflicto_funct_predef([(_C,_A)|LC], E) :-
   !,
   conflicto_funct_predef(LC,E).
*/
          
%-----------------------------------------------------------------------------%
% error_conflict(+N,+Name,+Rest): construimos el mensaje de error y lo 
% mostramos
%-----------------------------------------------------------------------------%

error_conflict(N,Name, Rest) :-  
         name(Name,CName),
         concatenation(["Symbol ",CName," ", Rest],Message),
         treatError(N,[],Message).




/*****************************************************************************/
/*              C O M P R U E B A   R E F E R E N C I A S            */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% checkReferences(+Tables,?Error)
% Se utiliza tras finalizar la primera fase. Las Tablas ya no deben tener
% hueco al final. En caso de que exista algun objeto referenciado y no
% declarado da el correspondiente error, a no ser que haya habido ya errores
% en la 1� fase.
%-----------------------------------------------------------------------------%

% si ha habido errores no comprobamos referencias
checkReferences(_,Error) :- Error==true,!.
% en otro caso si.
checkReferences(T,E) :-
        !,
        arg(1,T,Ref),
        arg(2,T,Tables),
        checkReferences(Ref,Tables,E).

checkReferences([One|More],Tab,E) :-
        checkOneReference(One,Tab,E),
        checkReferences(More,Tab,E).
checkReferences([],_,_) :- !.


% tipo
checkOneReference(type(V),T,_E) :-
        % ha de estar declarado o bien como data o bien como tipo
        % o ser un tipo reservado
        (extractTable2(data,T,Types),member(V,Types)
        ;
         extractTable2(types,T,Types),member_relax((V,_),Types)
/* ahora se encarga el lexicon
        ;
         typ_res(V)
*/
        ),
        !. % esta bien
        
% si llega hasta aqui, hay error
checkOneReference(type(V),_,true) :-
        !,
        errorFaultDeclaration("type",V).

% constructoras
checkOneReference(cons(V),T,_E) :-
        % ha de estar declarado en la tabla de constructoras
        extractTable2(constructors,T,Const),
        member_relax((V,_),Const),
        !.

checkOneReference(cons(V),_T,true) :-
        !,
        errorFaultDeclaration("constructor",V).


% funciones y operadores

% cons_func. Hay que hacer lo mismo que con las funciones
checkOneReference(cons_o_func(V),T,E) :-
        !,
        checkOneReference(func(V),T,E).

% funciones, que tambien pueden ser constructoras
checkOneReference(func(V),T,_E) :-
        % ha de estar declarado en la tabla de funciones o en la de const.
        extractTable2(functions,T,Functi),
        extractTable2(constructors,T,Const),
        (
          member_relax((V,_),Functi)
        ;
          member_relax((V,_),Const)

        ),
        !.


% si no esta ....
checkOneReference(func(V),_T,true) :-
        !,
        errorFaultDeclaration("function",V).

% si llega hasta aqui es que esta bien
checkOneReference(_,_,_) :- !.


%-----------------------------------------------------------------------------%
% 30-09-1996. Caso especial, para el caso de que no se trabaje con tablas
% como parametros sino con clausulas metidas en la base de datos
%-----------------------------------------------------------------------------%
lookToSee(use_tables,_Pat,Elem,Table) :- !,member_relax(Elem,Table).
lookToSee(_,function,(Name,Arity),_Table) :- !,funct(Name,Arity,_,_,_).
lookToSee(_,constructor,(Name,Arity),_Table) :- !,constr(Name,Arity,_,_).




/*****************************************************************************/
/*                  L E X I C O G R A F I C O                */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% lexicon(+H,+CharIn,-Tokens, -CharOut,-Error)
% Argumentos: - H         : Handle 'H' del fichero de entrada.
%             - CharIn: Primer caracter de la seccion a leer.
%             - Tokens    : Lista de tokens correspondiente a la seccion leida.
%             - CharOut : Primer caracter de la seccion siguiente a la leida.
%             - Error     : true si hay error, y no lo toca en otro caso.
%-----------------------------------------------------------------------------%

lexicon(H,CharIn,Tokens,CharOut,Error) :-
        !,
        % le pedimos al l�xico una seccion.
        readSection( H,                            % handle del fichero
                     CharIn,                   % datos del caracter 1�
                     CharOut,                    % datos del car.salida
                     [],                           % Pila de llaves
                     32,
                     Tokens),
        % miramos a ver si ha habido algun error, y si es asi, lo mostramos.
        
        treatLexiconError(Error).




/*****************************************************************************/
/*                      S I N T A C T I C O                  */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% sintactic(?Tables,+Tokens,-S,-Error)
% Analiza sintacticamente 'Tokens' y devuelve su representacion en S
% si hay errores los muestra
%-----------------------------------------------------------------------------%

% si ya hubo errores l�xicos, no hacemos nada
sintactic(_,_Tokens,[],Error) :- Error==true,!.

sintactic(Tables,Tokens, S, Error) :-
        !,
        ( section(S,Tokens,[],Tables,0,_,true)
         ;
          % si llega aqui es que hubo error; buscar el mas profundo
          Error = true,section(S,Tokens,[],Tables,0,_,false)
         ;
          % mostrarlo
          Error = true,
          S = error,
          treatSintacticError(_)
        ).




/*****************************************************************************/
/*                           S E M A N T I C O                   */
/*****************************************************************************/


%-----------------------------------------------------------------------------%
% semantic(+H,+In,-Out,+SinIn, -SinOut, ?Error)
% version que coge las tablas de la B.D.
%-----------------------------------------------------------------------------%

semantic(H,In,Out,SinIn,SinOut,Error):-
        !,
        deleteTablesOfCompilation(Tables), % extraemos las tablas
        semantic(H,In,Out,SinIn,SinOut,Tables,Error),
        modifyTablesOfCompilation(Tables). % guardamos la nueva



%-----------------------------------------------------------------------------%
% semantic(+H,+In,-Out,+SinEn, -SinOut, -Tables, ?Error)
% prepara para imprimir el resultado del analisis. Si hubo error no hace nada
% SinEn representa a la pieza sintactica que se trato en la ultima seccion
% y SinOut a la nueva.
%-----------------------------------------------------------------------------%

/*
% para solo uno
semantic(H,[First],FirstOut,SinIn,SinOut,Tables,Error) :-
        !,
        semantic(H,First,FirstOut,SinIn,SinOut,Tables,Error).
*/

% para mas de uno
semantic(H,[First|Rest],[FirstOut|RestOut],SinIn,SinOut,Tables,Error) :-
        !,
        semantic(H,First,FirstOut,SinIn,SinOut,Tables,Error),
        semantic(H,Rest,RestOut,SinOut,SinOut,Tables,Error).

% cuando llega hasta aqui y no queda nada, no hacemos nada (�?).
semantic(_,[],[],_,_,_,_) :- !.


% a partir de aqui tratamos cada posibilidad en particular


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INCLUDE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

semantic(HS,include(Chain),[],
                _SinIn,include, Tables, Error) :-
        !,
    % pasamos el nombre de fichero a cadena Prolog
    chainToyToProlog(Chain,ChainProlog),
        % pasamos el nombre de fichero a  atomo
%F010204
        name(File,ChainProlog),
% Se comprueba si existe el fichero en la ruta actual
        (file_exists(File) ->
%Si existe, no se hace nada
         FileInc=File
        ;
%Se busca en el directorio de la distribuci�n
         (root_path(RootPath), name(RootPath,SRootPath), 
          append(SRootPath,ChainProlog,SFileRoot), name(FileRoot,SFileRoot),
          (file_exists(FileRoot) ->
           FileInc=FileRoot
          ;
%Se busca en el directorio Include
           include_path(IncludePath), name(IncludePath,SIncludePath),
           append(SIncludePath,ChainProlog,SFileInclude), name(FileInclude,SFileInclude),
           (file_exists(FileInclude) ->
            FileInc=FileInclude
           ;
%No se ha encontrado en ning�n sitio y se producir� m�s tarde un error
            FileInc=File
           )
          )
         )
        ),

% ARITY para la apetura de ficheros hay que usar
%       open(H,FileInc,r),


% SICSTUS
        open(FileInc,read,H),

        nl,
        concatenation(["Including File ",ChainProlog],Messa1),
        writeText(Messa1),
        % lo compilamos pero sin generar codigo
        % 1.- buscamos algun caracter no blanco
        beginningSection(H,FirstChar,Error),
        % 2.- llamamos a compil/7 que es quien realmente hace el trabajo
        compil(H,HS,FirstChar,nothing,Tables,0,Error),
        % ya esta 
        writeText("Done."),nl,
        writeText("Next Block"),
        close(H).


%%::B AF
%%%%%%%%%%%%%%%%%%%%%%%%%%%% INCLUDECFLPFD %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


semantic(HS,includecflpfd(Chain),[],
                _SinIn,includecflpfd, Tables, Error) :-
        !,
        % pasamos el nombre de fichero a cadena Prolog
      chainToyToProlog(Chain,ChainProlog),
        % pasamos el nombre de fichero a  atomo
        name(FileInc,ChainProlog),
        assert(initToy:cflpfdfile(FileInc)).

%%::E 




%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INFIX %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% infix. Primero eliminamos la posibilidad de definir varios operadores
% simultanemamente. Mejor de uno en uno.
semantic(H,infix([One|More], Asoc, Pri,Line), [OneS|MoreS],
          SinIn,infix,Tables,Error) :-
        !,
        semantic(H,infix(One,Asoc,Pri,Line),OneS,SinIn,SinOut,Tables,Error),
        semantic(H,infix(More,Asoc,Pri,Line),MoreS,SinIn,SinOut,Tables,Error).

semantic(_,infix([], _, _, _), [], _,_,_,_) :- !.

% Ahora tratamos los casos individuales.
% Si ya esta en la tabla error. En otro caso se le a�ade
semantic(H,infix(Op, Asoc, '$int'(Pri), Line),infix(Op,Asoc, Pri,Line),
                SinIn, SinOut, Tables, Error) :-
        !,
        % si es nueva guardarla. Si no error.
        includeIfNew(priorityes,Tables,(Op,Asoc,Pri),
                       false, nothing,infix, % dar error si hay 2 con el mismo Op
                       13,Line,Error).   % datos para el error



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 11/07/97 Ya no se escriben las clausulas Data
% si alguna vez se vuelven a poner, tener en cuenta que Const debe ser 
% transformado segun los alias de tipo. Tal y como esta estaria MAL
semantic(H,data(Base,Const,Line), /*[data(Base,Const,Line)|*/ LConst /*]*/,
          SinIn,data(Base2),T,E):-
        !,
        functor(Base,Base2,_NumVar),  % por si es cabecera compuesta
        % 11-1-99 Comprobar que las variables cumplen las pdes. semanticas
        checkVariables(Base,Const,Line,T,E),
        % guardar el tipo de datos definido
        includeIfNew(data,T,Base2,false,
                       SinIn,data(Base2),14,Line,E),
        transferConst(Base,Const,Line,LConst,SinIn,data(Base2),T,E).



%-----------------------------------------------------------------------------%
% checkVariables(+Name,+Type,+Line,+T,?Error)
% 11/01/99
%
%  Name : Parte izquierda de la declaracion de la forma Head(Arg1,...)
%  Type   : Parte derecha de la declaracion
%  Line  : Linea de codigo fuente en la que se inicia la declaracion
%  T      : Tablas de compilacion
%  Error  : Se pondra a true si hay error o se dejara tal cual e.o.c.
% 
% comprobaciones semanticas para una sentencia data:
%  1--> Comprobamos que en la cabeza no hay variables repetidas
%  2--> Comprobar que en la derecha no hay variables que no hay en la izq.
%-----------------------------------------------------------------------------%

checkVariables(Name,Type,Line,T,Error) :- 
        !,
        % Obtenemos el nombre del tipo sin parametros
        functor(Name,Head,NumVar),

        % 1.- miramos a ver si hay variables repetidas
        % 'LeftVar' es una 'tabla con hueco' sobre la que se devolvera la lista
        % de las variables que aparecen antes del '=' en la declaracion de tipos
        % el primer parametro se pone a 'si' para indicar que de error si hay
        % variables repetidas (en la parte derecha puede haberlas, pero en la
        % izquierda no)
        variablesRepeated(yes,Name,LeftVar,Line,Error),

       
        % cogemos las variables del lado derecho
        % El primer parametro 'no' indica que solo estamos recolectando
        variablesRepeated(no,Type,RightVar,Line,Error),

        % quitamos los huecos del final de las dos listas
        closeHollow(LeftVar), closeHollow(RightVar),

        % 2 .- si a la derecha hay alguna variable que no esta a la Izq.-->error
        errorIfNotContained(RightVar,LeftVar,Line,Error).

% -----------------------------------------------------------------------------

% vamos creando una clausula a partir de cada posible construccion
% si ha habido error anteriormente no hacemos nada
transferConst(_Base,_Const,_Line,_LConst,_SinIn,_SinOut,_T,E) :-
        E == true,
    !.

transferConst(Base,[One|Rest],Line,[OneS|RestS],SinIn,SinOut,T,E) :-
        !,
        transferConst(Base,One,Line,OneS,SinIn,SinOut,T,E),
        transferConst(Base,Rest,Line,RestS,SinOut,SinOut,T,E).
transferConst(_,[],_,[],_,_,_,_):-!.

% una construccion simple
transferConst(Base,Const,Line,cdata(Name,Arity,TypeOut,Line),
              SinIn,SinOut,Tables,Error):-
        !,
        functor(Const,Name,Arity), % obtenemos nombre y aridad
        Const =.. [Name|Args],
        append(Args,[Base],Args2),
        insertArrow(Args2,Type),

        % mirar a ver si dentro del tipo hay tipos definidos por el usuario
        % y en ese caso sustituirlos por su definicion
        % Miramos a ver si los tipos que lo forman ya existen y transformamos
        % los tipos definidos del usuario en sus equivalentes
        extractTable(types,Tables,TabTypes),
        checkTypes(TabTypes,Type,Line,TypeOut,Error),

        % asi tenemos ya el tipo
        % guardarlo, repitiendo si estamos leyendo varios data para el mismo
        includeIfNew(constructors,Tables,(Name,Arity),true,
                       SinIn,SinOut,14,Line,Error).


%-----------------------------------------------------------------------------%
% insertArrow(+List,-Flechitas)
% coge la lista [a,b,c,...] y devuelve en 'Flechitas' ->(a,->(b,->(c,...)))
%-----------------------------------------------------------------------------%

insertArrow([],[]):-!.   % caso base
insertArrow([B],B) :- !. % si solo es un elemento, no metemos ->
insertArrow([H|T],'->'(H,Rest)) :-  !, insertArrow(T,Rest).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PRIMITIVE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% primitive. Declaracion de una funcion primitiva, esto es, una funcion
% cuyas reglas no estan escritas en el lenguaje fuente sino que son parte
% del propio compilador
% 23/07/1996

% si el primer argumento de primitive es una lista, tratarlo como
% si fuera una lista de clausulas 'primitive', cada una con un solo argumento
semantic(H,primitive([One|More],Type,Line), [OneS|MoreS],
          SinIn, primitive, Tables, Error) :-
        !,
        semantic(H,primitive(One,Type,Line),OneS,SinIn,SinOut,Tables,Error),
        semantic(H,primitive(More,Type,Line),MoreS,SinIn,SinOut,Tables,Error).

% caso base, lista vacia
semantic(_,primitive([], _, _), [], _,_,_,_) :- !.

% Caso unitario. Una clausula primitive genera dos clausulas de salida: una
% correspondiente a la propia 'primitive' y otra corespondiente al tipo de la
% funcion.
% Ademas, anotamos la funcion como si ya tuviesemos su declaracion,
% para no dar error cuando se utilice
semantic(H,primitive(Name,Type,Line),[primitive(Name,Type,Line),Outf],
          SinIn,SinOut,Tables,Error) :-
        !,
        semantic(H,ftype(Name,Type,Line),Outf,SinIn,SinOut,Tables,Error),
        % indicamos que el codigo de la funcion existe, aunque en realidad
        % no lo haya introducido el usuario, usando la aridad declarada
        arityOfTheType(Type,Arity),
        includeIfNew(functions, Tables,(Name,Arity),
                       false, % no incluirlo si esta
                       % 03-01-00 Mercedes & Rafa
                       % De momento decicidmos que los prinitives son 
                       % no-deterministas
                       SinIn, rule(Name,"="), 17,Line,Error).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FTYPE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ftype. Declaracion del tipo de una funcion. Hay que tener en cuenta que se
% puede declarar el tipo de varias funciones simultaneamente y que hay que
% separarlos en varias clausulas.
% Se  permite incluir varias veces el mismo tipo (sobrecarga)
semantic(H,ftype([One|More], Type, Line), [OneS|MoreS],
          SinIn, ftype, Tables, Error) :-
        !,
        semantic(H,ftype(One,Type,Line),OneS,SinIn,SinOut,Tables,Error),
        semantic(H,ftype(More,Type,Line),MoreS,SinIn,SinOut,Tables,Error).

semantic(_,ftype([], _, _), [], _,_,_,_) :- !.

% Ahora tratamos los casos individuales.
% A�adirlo a la tabla, sin importar si ya esta o no (sobrecarga)
semantic(H,ftype(Name,Type,Line), ftype(Name,Arity,TypeOut,Line),
                SinIn, SinOut, Tables, Error) :-
        !,
        % Miramos a ver si los tipos que lo forman ya existen y transformamos
        % los tipos definidos del usuario en sus equivalentes
        extractTable(types,Tables,TabTypes),
        checkTypes(TabTypes,Type,Line,TypeOut,Error),
    % Despues de 'expandir' los tipos de usuario, calculamos la aridad de tipo
        arityOfTheType(TypeOut,Arity),
        % Utilizamos IncluyeSiNuevo para incluirlo, aunque no sea nuevo (!!)
        includeIfNew(ftypes,Tables,(Name,Arity),
                       true, nothing, ftype, % dar error si hay 2 con el mismo Op
                       16,Line,Error).    % datos para el error



%-----------------------------------------------------------------------------%
% checkTypes(+TabTypes,+Type,,+Line,-TypeOut,?Error)
% Modifica el tipo, sustituyendo los tipos definidos por usuario (alias) por sus
% definiciones
%-----------------------------------------------------------------------------%

% si ya ha habido error no hacemos nada
checkTypes(_TabTypes,_Type,_Line,[],Error) :-
        Error == true,
        !.

% Si es una lista vacia, no hacer nada
checkTypes(_TabTypes,[],_Line,[],_Error) :- !.
% si es una lista no vacia. tratar la cabeza y el resto
checkTypes(TabTypes,[C|R],Line,[CS|RS],Error) :-
        !,
        checkTypes(TabTypes,C,Line,CS,Error),
        checkTypes(TabTypes,R,Line,RS,Error).

% si es un tipo definido por el usuario
checkTypes(TabTypes,Type,Line,TypeOut,Error) :-
        % si es una estructura
        Type =.. [C|Rest],
        % si ademas el functor es un tipo compuesto ...
        lookandput((C,type(LVariables,StrType)),false,Was,TabTypes),
        Was == true,
        !,
        % transformar el resto de la lista en una lista de tipos
        transformToList(Rest,ListTypes),
        transformType(LVariables,StrType,Line,ListOut,TypeOut1,Error),
        (
         % si se puede unificar, pues ya esta porque al tiempo se instanciaran
         % las variables de TypeOut
         ListOut = ListTypes,
         
         % 08/11/99 mercedes
         checkTypes(TabTypes,TypeOut1,Line,TypeOut,Error)
        ;
         % si no se puede dar error
        treatError(27,Line),Error=true
        ).

% si es otra estructura cualquiera, miramos cada parte
checkTypes(TabTypes,Type,Line,TypeOut,Error) :-
        % si es una estructura
        Type =.. [C|List],
        !,
        checkTypes(TabTypes,List,Line,ListOut,Error),
        % reconstruimos el tipo
        TypeOut =.. [C|ListOut].

% cualquier otra cosa se queda igual
checkTypes(_TabTypes,Type,_Line,Type,_Error) :- !.

%-----------------------------------------------------------------------------%
% transforToList(+Str,-List): transforma la estructura que se le pasa entre [] 
% a lista
%-----------------------------------------------------------------------------%

% si no hay estructura, ya esta
transformToList([],[]) :- !.

% si es una lista toy, respetarla (28/07/97) 
% (no funcionaba bien cuando los parametros del type eran listas o tuplas)
transformToList([A:[]],[LA:[]]) :- 
    !.
        % 07-04-00. Rafa. Respetarla del todo.He quitado la linea de abajo.
    % transformToList([A],LA).
    % Se ha quitado porque habia un error con los alias. El ejemplo:
    % type mset A = [A]
    % type b = bool
    % type t = mset (b,b,b)
    %
    % f:: t -> bool
    % f [(X,Y,Z)] = true
    % fallaba porque el tipo declarado que inferia para la f lo sacaba mal

% si es una tupla toy, respetarla (28/07/97)
% 1- el functor principal
transformToList(['$$tuple'(A)],['$$tuple'(A)]) :- 
    !.
        % 07-04-00. Rafa. Respetarla del todo. He quitado la linea de abajo.
    % transformToList([A],LA).

% 2- la tupla Prolog que hay dentro del '$$tuple'
transformToList([(A,B)],[(LA,LB)]) :-
    !,
    transformToList([A],LA),
    transformToList([B],LB).

% si es una variable toy tambien se respeta
transformToList([L],[L]) :- 
    isVariable(L),!.

% si es una estructura, convertirla a lista
transformToList([Structure],[Functor|RestList]):-
        !,
        Structure =.. [Functor|List2],
        transformToList(List2,RestList).

% si es una lista, tal cual
transformToList([C|R],[C|R]) :- !.


%-----------------------------------------------------------------------------%
% transformType(+LeftVar, +Type,+Line, -VarProlog, -TypeProlog,?Error)
% Cambia en la estructura 'Type' todas las variables de tipo 'Toy' (cuya lista
% viene en 'LeftVar') por una estructura con variables tipo Prolog llamada 
% 'TypeProlog'.
% En 'VarProlog' se devuelve la lista de variables Prolog
%-----------------------------------------------------------------------------%

% si ya hubo error no hacemos nada
transformType(_LeftVar,_Type,_Line,_VarProlog,_TypeProlog,Error) :-
        Error == true,
        !.

transformType(LeftVar,Type,Line,VarProlog,TypeProlog,Error) :-
        % transforma la lista de variables 'Toy' ($Var) en variables Prolog
        createListVarProlog(LeftVar,VarProlog),

        % necesitamos combinar las dos listas en una sola, de forma que
        % al buscar la variable Toy encontramos su variable Prolog corresp.
        mixLists(LeftVar,VarProlog,ListVariables),

        % transformar la estructura de la izquierda, cambiando cada
        % ocurrencia de una variable Toy por su variable Prolog
        % Tambien se da error si en la parte derecha hay variables nuevas
        % esto es, que no estaban en la parte izquierda
        prologStructure(ListVariables,Type,Line,TypeProlog,Error).


%-----------------------------------------------------------------------------%
% arityOfTheType(+Type,-Arity): devuelve en Arity el num. de -> que hay en el
% tipo Type.
%-----------------------------------------------------------------------------%

arityOfTheType(Type,Arity) :-
        functor(Type,'->',2),
        !,
        arg(2,Type,Type2),
        arityOfTheType(Type2,N),
        Arity is N+1.

% caso base, no hay '->'
arityOfTheType(Type,0) :- !.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TYPE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% type. Declaracion de tipo.
% Anyadirlo a la tabla, cuidando de que no haya repeticiones
% comprobaciones semanticas:
%  1--> Comprobamos que en la cabeza no hay variables repetidas
%  2--> Comprobar que en la derecha no hay variables que no hay en la izq.
%  3--> Comprobar que en la derecha no aparecen tipos no declarados

%11/07/97 ya no se escriben los ftype al fichero. No le hacen falta ni a Jaime 
% ni a mi.
semantic(H,type(Name,Type,Line), /*type(Name,TypeOut,Line)*/ [],
                SinIn, type(Head), Tables, Error) :-
        !,
        % Obtenemos el nombre del tipo sin parametros
        functor(Name,Head,_NumVar),

        % 1.- miramos a ver si hay variables repetidas
        % 'LeftVar' es una 'tabla con hueco' sobre la que se devolvera la lista
        % de las variables que aparecen antes del '=' en la declaracion de tipos
        % El primer parametro se pone a 'si' para indicar que de error si hay
        % variables repetidas (en la parte derecha puede haberlas, pero en la
        % izquierda no)
        variablesRepeated(yes,Name,LeftVar,Line,Error),

        % Ahora examinamos el tipo (la parte derecha);
        % miramos a ver si los tipos que lo forman ya existen y transformamos
        % los tipos definidos del usuario en sus equivalentes,
        % ya que puede haber tipos dependientes del otros
        extractTable(types,Tables,TabTypes),
        checkTypes(TabTypes,Type,Line,TypeOut,Error),

        % cogemos las variables del lado derecho
        % El primer parametro 'no' indica que solo estamos recolectando
        variablesRepeated(no,TypeOut,RightVar,Line,Error),

        % quitamos los huecos del final de las dos listas
        closeHollow(LeftVar), closeHollow(RightVar),

        % 2 .- si a la derecha hay alguna variable que no esta a la Izq.-->error
        errorIfNotContained(RightVar,LeftVar,Line,Error),

        % 3 .- Incluirlo, a no ser que el tipo ya haya aparecido antes
        includeKey(types,Tables,(Head,type(LeftVar,TypeOut)),16,Line,Error).



%-----------------------------------------------------------------------------%
% prologStructure(+Variables,+StrIn,+Line,-StrOut,?Error)
% Description:
%       Cambia las variables 'Toy' de la estructura 'StrIn' por variables
%        'Prolog', a partir de la correspondencia dada por la lista
%       'Variables'=[(VarToy,VarProlog),....].
%       El resultado quedara en la estructura 'StrOut'.
%       Si alguna variable Toy de 'StrIn' no se encuentra en 'Variables'
%       se dara y devolvera error.
%-----------------------------------------------------------------------------%

% si hay error anterior, no hacemos nada
prologStructure(_Variables,_StrIn,_Line,[],Error) :-
        Error == true,
        !.

% si es un atomo no lo tocamos
prologStructure(_Variables,Atomito,_Line,Atomito,_Error) :-
        atom(Atomito),
        !.

% si es una lista, mirar en la cabeza y en el resto
prologStructure(Variables,[A|List],Line,[AOut|ListOut],Error) :-
        !,
        prologStructure(Variables,A,Line,AOut,Error),
        prologStructure(Variables,List,Line,ListOut,Error).

% la lista vacia no tiene variables
prologStructure(_Variables,[],_Line,[],_Error):-!.

% intentamos ver si es una variable
prologStructure(Variables,V,Line,VProlog,Error) :-
        isVariable(V),
        !,
        % buscarla
        searchInList((V,VProlog),Variables,Was),
        (Was=false, treatError(26,Line), Error=true
         ;
         true).

% si es una estructura, la pasamos a lista
prologStructure(Variables,Str,Line,StrS,Error) :-
        Str =.. [Functor|List],
        !,

        % tratamos cada parte por separado
        prologStructure(Variables,Functor,Line,FunctorS,Error),
        prologStructure(Variables,List,Line,ListS,Error),

        % hay que preveer posibles errores
        ( Error==true, StrS=[]
        ;
         % creamos la estructura de salida
         StrS =.. [FunctorS|ListS]
       ).


% cualquier otra cosa vale
prologStructure(_Variables,Str,_Line,Str,_Error) :- !.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% FUN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Fun. Una regla de funcion.
% A�adirlo a la tabla, cuidando de que no haya repeticiones
% 09/97 reemplazar parametros as
% 03-01-00 Incluimos la posibilidad de usar = o --> al definir funciones.
% Restriccion: todas las reglas deben usar el mismo simbolo (= o -->)
semantic(H,rule(Head,Body,Condition,Where,HeadSep,Line),
          rule(Head2,Body2,Condition2,Where2,HeadSep,Line),
          SinIn, rule(Name,HeadSep), Tables, Error) :-
        !,
        % 22/06/00 mercedes: listas intensionales
        treat_lists(Body, Body1,1,Cont1,Line,Error),
        treat_lists(Condition,Condition1,Cont1,Cont2,Line,Error),
        treat_lists(Where, Where1,Cont2, _ContOut,Line, Error),
        
    % quitamos patrones as y (n+k)
    patterns_as_nk(Head,Body1,Condition1,Where1,Line,
                Head2,Body2,Condition2,Where2,Error),
        
        
    % Depu 03/10/00 mercedes
    % comprobaciones semanticas del where:
    % a) partes izquierdas patrones planos
    % b) las variables en las ti son nuevas, es decir no aparecen en 
        %    tj y ni en las ej anteriores ni en la cabeza.
        % en este punto solo se puede hacer la comprobacion b)
        % para la a) se necesita saber si el simbolo de la cabeza es una 
        % constructora o una funcion y esto no se sabe hasta la segunda fase
        no_recursive_where(Head2,Where2,Error), % b)   
        % Fin Depu         
        
        % Obtenemos el nombre del tipo sin parametros
        functor(Head2,Name,Arity),
        % miramos si ya esta a ver si no ha cambiado de aridad
        extractTable(functions,Tables,Tab),
        lookandput((Name,Arity2),false,Was,Tab),
        changeArity(Was,Arity,Arity2,Line,Error),
        % 03-01-00 Comprobamos si la regla anterior usaba el mismo separador
        % entre cabeza y cuerpo si era regla de la misma funcion
        checkHeadSepSymbol(SinIn, rule(Name, HeadSep), Line, Error),
        % Comprobamos que no hay variables repetidas
% ???        variablesRepeated(no,Head2,_,Line,Error),
        % Comprobamos que la aridad es <= que la del tipo
        smallerArity(Name,Arity,Was,Tables,Line,Error),
        % Utilizamos IncluyeSiNuevo para incluirlo
        includeIfNew(functions, Tables,(Name,Arity),
                       false, % no incluirlo si esta
                       SinIn, rule(Name,HeadSep), 17,Line,Error),
        % Yoli YGR 5/12/2005 INICIO
        % miramos si la funci�n es determinista
        checkDeterminism(Tables,rule(Name,HeadSep))
        % YGR 5/12/2005 FIN
        .

% Yoli YGR 5/12/2005 INICIO
%----------------------------------------------------------------------------
% checkDeterminism(+Tab,+rule(Name,HeadSep))
% Si la funci�n tiene como separador --> en lugar de =, significa que el usuario
% informa que la funci�n es determinista, por lo que introducimos esa funci�n en
% la tabla de funciones deterministas. El nombre de la tabla es 'annotate'.
%----------------------------------------------------------------------------

checkDeterminism(Tab,rule(Name,HeadSep)) :-
    HeadSep = [45,45,62], % empieza por -->
    includeIfNew(annotate,Tab,annotate(deterministic(Name)),
                       false,nothing,_,0,0,_Error).   
checkDeterminism(Tab,rule(Name,HeadSep)) :- 
    !.

% YGR 5/12/2005 FIN


% Depu 03/10/00 mercedes
%----------------------------------------------------------------------------
% plane_patterns(+Mode,+TabC,+TabF,+Where, ?Error)
% comprobar que la lista de wheres tiene los patrones de la parte izquierda
% planos. Mode puede ser 'use_tables' o loquesea, segun si estamos compilando
% un programa, o se mira en memoria (al traducir un objetivo)
%----------------------------------------------------------------------------
plane_patterns(_Mode,_TabC,_TabF,_Where,Error) :- 
    Error == true,
    !. 

% la lista vacia es plana
plane_patterns(_Mode,_TabC,_TabF,[],_Error) :- 
    !.

plane_patterns(Mode,TabC,TabF,[UnWhere|MoreWheres],Error) :- 
    plane_pattern(Mode,TabC,TabF,UnWhere,Error),
    plane_patterns(Mode,TabC,TabF,MoreWheres, Error).

%----------------------------------------------------------------------------
% plane_pattern(+TabC, +TabF, +Where, ?Error)
% comprobar que el patron  de la parte izquierda de un where sencillo es
% plano. 
%----------------------------------------------------------------------------
plane_pattern(Mode,TabC,TabF,'='(Pat,_Exp,Lin),Error) :-
   % posibilidades:
   (
    % Pat es una variable --> plano
    isVariable(Pat)
   ;
    Pat = '$$tup'(Tup),
    tupToArgs(Tup,Args),
    allVariables(Args)
   ;
    % si no, debe ser una constructora con argumentos variables
    Pat =.. [C|LVar],
    lookToSee(Mode,_,(C,_Arity),TabC),
    allVariables(LVar)
   ;
    Pat =.. [F|Args],
    % tambien puede ser una funcion aplicada a menos argumentos que su aridad
    lookToSee(Mode,_,(F,Arity),TabF),
    length(Args,N),
    N<Arity,
    allVariables(Args)
   ;
    % hay error; no es plano
    Error = true,
    treatError(38,Lin)    
   ),
   !.




    
    


%----------------------------------------------------------------------------
% allVariables(List)
% Tiene exito si y solo si todos los miembros de la lista son var. Toy 
%----------------------------------------------------------------------------
allVariables([]) :- !.
allVariables([C|S]) :- !, isVariable(C), allVariables(S).
 
%----------------------------------------------------------------------------
% no_recursive_where(+Head, +Where, ?Error)
% Comprueba que no hay definiciones recursivas en los where 
%----------------------------------------------------------------------------
no_recursive_where(_Head,_Where,Error):-
    Error==true,
    !.
no_recursive_where(Head, Where,Error) :-
    variables(Head,[],ListVar),
    % a partir de aqui perdemos la cabeza
        no_variable_repeated(ListVar, Where, Error).


%----------------------------------------------------------------------------
% no_variable_repeated(+List, +Where, ?Error)
% Comprueba que no hay definiciones recursivas en los where 
%----------------------------------------------------------------------------
no_variable_repeated(_List, [], _Error) :- 
    !.

no_variable_repeated(List, ['='(Pat,Expr,Line)|MoreGueres], Error) :- 
    !,
        variables(Expr,List,List1),
    variables(Pat,[],PatVar),
        (
         any_in_list(PatVar,List1),
         % error
         Error=true,
         treatError(41,Line)
        ;
         append(List1,PatVar,List2),
         no_variable_repeated(List2, MoreGueres,Error)
        ).

%----------------------------------------------------------------------------
% any_in_list(+L1, +L2)
% Tiene exito si alguno de los elemntos de L1 esta en L2 
%----------------------------------------------------------------------------
any_in_list([X|Xs],L2) :- 
    member(X,L2),
    !.
any_in_list([X|Xs],L2) :- 
    !,
    any_in_list(Xs,L2).

% Fin Depu

% 22/06/00 mercedes
%----------------------------------------------------------------------------
% treat_lists(+ExpI, -ExpO, ContI, ContO,Line, ?Error)
%----------------------------------------------------------------------------

treat_lists(Exp,Exp,C,C,_Line,Error) :- 
        Error == true,
    !.



% si es un atomo no lo tocamos
treat_lists(Atomito,Atomito,C,C,_Line,_Error) :-
        atom(Atomito),
        !.

% si es una lista, mirar en la cabeza y en el resto
treat_lists([A|List],[AOut|ListOut],ContI,ContO,Line, Error) :-
        !,
        treat_lists(A,AOut,ContI, ContO1, Line,Error),
        treat_lists(List,ListOut, ContO1, ContO, Line,Error).

% la lista vacia no tiene listas intensionales
treat_lists([],[],C,C,_Line,_Error):-!.

% intentamos ver si es una variable
treat_lists(V,V,C,C,_Line,_Error) :-
        isVariable(V),
        !.

% es una lista intensional
treat_lists(intensional(Exp,L),intensional(Exp2,L2),ContI,ContO,Line,Error) :-
    !,
    treat_int(intensional(Exp,L),intensional(Exp2,L2),ContI,ContO,Line,Error).



% 07/09/00 mercedes (Ahora se comprueba que las generadoras siempre aparezcan
% antes que las condiciones booleanas en las que aparecen)

treat_int(intensional(Exp,L),intensional(Exp2,L2),ContI,ContO,Line,Error) :-
    !,
        % primero eliminamos las listas intensionales
        treat_lists(L,L1,ContI,C1,Line,Error),
        ContO is C1+1,
    lookForLittleArrows(L1,ContO,LVar,[],ListOut,Line,Error),
    checkAllDifferent(LVar,Line,Error),
    renameIntensionalVariables(LVar,Exp,Exp2),
    renameIntensionalVariables(LVar,L1,L2).


% renameIntensionalVariables(LVar,E,E2)

 
% si no hay nada que sustituir, pues ya esta
renameIntensionalVariables([],E,E) :- 
    !.

renameIntensionalVariables([X|Xs],E,Es) :- 
    !,
    renameIntensionalVariable(X,E,Es1),
    renameIntensionalVariables(Xs,Es1,Es).

% renameIntensionalVariable((Var,NewName),E,Es)

% si es un atomo no lo tocamos
renameIntensionalVariable(_PairV,Atomito,Atomito) :-
        atom(Atomito),
        !.

% si es una lista, mirar en la cabeza y en el resto
renameIntensionalVariable(PairV,[A|List],[AOut|ListOut]) :-
        !,
        renameIntensionalVariable(PairV,A,AOut),
        renameIntensionalVariable(PairV,List,ListOut).

% la lista vacia no tiene variables
renameIntensionalVariable(_PairV,[],[]) :-
    !.

% si la variable a sustituir, pues eso, nose
renameIntensionalVariable((Var,NewVar),Var,NewVar) :-     
        !.

% si es variable, pero no es la que queremos sustituir la dejamos en paz. 
renameIntensionalVariable((Var,NewVar),VarOther,VarOther) :-
    isVariable(VarOther),
    !.

% si es una estructura, la pasamos a lista
renameIntensionalVariable(PairV,Str,StrS) :-
        Str =.. [Functor|List],
        !,
        % el functor no se trata (no puede tener var.), solo los argumentos
        renameIntensionalVariable(PairV,List,ListS),
        % hay que preveer posibles errores
        % creamos la estructura de salida
         StrS =.. [Functor|ListS].


% cualquier otra cosa vale
renameIntensionalVariable(_PairV,E,E) :- !.
    
    

% lookForLittleArrows(+L,+Cont,-LVar)

lookForLittleArrows(_L,_Cont,_LVar,_ListIn,_ListOut,_Line,Error):-
    Error==true,
    !.

lookForLittleArrows([],_Cont,[],List,List,_Line,_Error) :-
    !.

lookForLittleArrows(['<-'(V,_Exp)|Rest],Cont,[(V,NewName)|RestV],ListIn,ListOut,Line,Error) :-
    !,
    (
     member(V,ListIn),
     !,
     treatError(40,Line),
     Error=true
    ;
     name_of_variable(V,Name),
     name(Name,Nname),
     name(Cont,ContName),
     concatLsts([Nname,"$",ContName], Nname1),
     name(NewName1,Nname1),
     name_of_variable(NewName,NewName1),
     lookForLittleArrows(Rest,Cont,RestV,ListIn,ListOut,Line,Error)
    ).


    
lookForLittleArrows([Exp|Rest],Cont,RestV,ListIn,ListOut,Line,Error) :-
    !,
    variables(Exp,ListIn,ListOut1),
    lookForLittleArrows(Rest,Cont,RestV,ListOut1,ListOut,Line,Error).


variables(Atomito,List,List):-
    atom(Atomito),
    !.
    
variables([A|Rest],List,ListOut):-
    !,
    variables(A,List,List1),
    variables(Rest,List1,ListOut).
    
variables([],List,List):-
    !.
    
variables(Var,List,[Var|List]):-
    isVariable(Var),
    !.
    
variables(Str,List,ListOut):-
    Str=..[Functor|L],
    !,
    variables(L,List,ListOut).
    
variables(E,List,List):-
    !.


% checkAllDifferent(+LVar,Line,?Error).

% si ya hay error no hacemos nada
checkAllDifferent(_LVar,_Line,Error) :-
    Error==true,
    !.
    
% en la lista vacia todos son diferentes    
checkAllDifferent([],_Line,_Error) :-
    !.

checkAllDifferent([V|Rest],Line,Error) :-
    !,
    (
     member(V,Rest),
     treatError(37,Line),
     Error=true
    ; 
     checkAllDifferent(Rest,Line,Error)
    ).


/*
Este era el tratamiento que se hacia con las listas intensionales antes de
que se comprobara que las generadoras deben aparecer siempre antes que las 
condiciones booleanas en las que aparecen.

treat_int(intensional(Exp,L),intensional(Exp2,L2),ContI,ContO,Line,Error) :-
    !,
        % primero eliminamos las listas intensionales
        treat_lists(L,L1,ContI,C1,Line,Error),
        ContO is C1+1,
    lookForLittleArrows(L1,ContO,LVar),
    checkAllDifferent(LVar,Line,Error),
    renameIntensionalVariables(LVar,Exp,Exp2),
    renameIntensionalVariables(LVar,L1,L2).


% renameIntensionalVariables(LVar,E,E2)

 
% si no hay nada que sustituir, pues ya esta
renameIntensionalVariables([],E,E) :- 
    !.

renameIntensionalVariables([X|Xs],E,Es) :- 
    !,
    renameIntensionalVariable(X,E,Es1),
    renameIntensionalVariables(Xs,Es1,Es).

% renameIntensionalVariable((Var,NewName),E,Es)

% si es un atomo no lo tocamos
renameIntensionalVariable(_PairV,Atomito,Atomito) :-
        atom(Atomito),
        !.

% si es una lista, mirar en la cabeza y en el resto
renameIntensionalVariable(PairV,[A|List],[AOut|ListOut]) :-
        !,
        renameIntensionalVariable(PairV,A,AOut),
        renameIntensionalVariable(PairV,List,ListOut).

% la lista vacia no tiene variables
renameIntensionalVariable(_PairV,[],[]) :-
    !.

% si la variable a sustituir, pues eso, nose
renameIntensionalVariable((Var,NewVar),Var,NewVar) :-     
        !.

% si es variable, pero no es la que queremos sustituir la dejamos en paz. 
renameIntensionalVariable((Var,NewVar),VarOther,VarOther) :-
    isVariable(VarOther),
    !.

% si es una estructura, la pasamos a lista
renameIntensionalVariable(PairV,Str,StrS) :-
        Str =.. [Functor|List],
        !,
        % el functor no se trata (no puede tener var.), solo los argumentos
        renameIntensionalVariable(PairV,List,ListS),
        % hay que preveer posibles errores
        % creamos la estructura de salida
         StrS =.. [Functor|ListS].


% cualquier otra cosa vale
renameIntensionalVariable(_PairV,E,E) :- !.
    
    

% lookForLittleArrows(+L,+Cont,-LVar)
lookForLittleArrows([],_Cont,[]) :-
    !.
    
lookForLittleArrows(['<-'(V,_Exp)|Rest],Cont,[(V,NewName)|RestV]) :-
    !,
    name_of_variable(V,Name),
    name(Name,Nname),
    name(Cont,ContName),
    concatLsts([Nname,"$",ContName], Nname1),
    name(NewName1,Nname1),
    name_of_variable(NewName,NewName1),
    lookForLittleArrows(Rest,Cont,RestV).
    
lookForLittleArrows([_Exp|Rest],Cont,RestV) :-
    !,
    lookForLittleArrows(Rest,Cont,RestV).

    
% checkAllDifferent(+LVar,Line,?Error).

% si ya hay error no hacemos nada
checkAllDifferent(_LVar,_Line,Error) :-
    Error==true,
    !.
    
% en la lista vacia todos son diferentes    
checkAllDifferent([],_Line,_Error) :-
    !.

checkAllDifferent([V|Rest],Line,Error) :-
    !,
    (
     member(V,Rest),
     treatError(37,Line),
     Error=true
    ; 
     checkAllDifferent(Rest,Line,Error)
    ).

*/
    
% si es una estructura, la pasamos a lista
treat_lists(Str,StrS,ContI,ContO,Line,Error) :-
        Str =.. [Functor|List],
        !,

        % tratamos cada parte por separado
        treat_lists(List,ListS,ContI,ContO,Line,Error),
        
        % hay que preveer posibles errores
        ( 
         Error==true, StrS=[]
        ;
         % creamos la estructura de salida         
         StrS =.. [Functor|ListS]
    ).
        
        
        
% cualquier otra cosa vale
treat_list(Str,Str,ContI,ContI,_Line,_Error) :- !.





% ------------------------------------------------------------------------------
% checkHeadSepSymbol(+rule(Nombre1,HeadSep1), +rule(Nombre2,HeadSep2), 
%                      +Linea, ?Error),
% Si Nombre1 = Nombre2 (estamos tratando una regla de funcion que no es la 
%                       primera)
% entonces comprobamos que se usa el mismo separador entre cabeza y cuerpo
% (HeadSep1 = HeadSep2). En otro caso hay error.

% si ya hubo error no hacemos nada
checkHeadSepSymbol(_SinEnt, _Sinsal, _Linea, Error):-
     Error == true,
     !.

checkHeadSepSymbol(rule(Nombre1,HeadSep1), rule(Nombre2,HeadSep2),
                   Linea, Error):-
            % si es la misma regla de funcion pero ha cambiado el separador,
            % error
            Nombre1 == Nombre2,
            \+ (HeadSep1 = HeadSep2),
            !,
            Error = true,
            trata_error(35,Linea).

% en otro caso no hacer nada
checkHeadSepSymbol(_SinEnt, _SinSal, _Linea, _Error):-
        !.



%-----------------------------------------------------------------------------%
% smallerArity(+Name,+Arity,+Was,+Tables,+Line,?Error)
% verifica que la aridad de la funci�n en el programa <= aridad de tipo
%-----------------------------------------------------------------------------%

% s�lo se comprueba si es la primera vez
smallerArity(Name,ArityProg,false,Tables,Line,Error) :-
        % sacamos la tabla de tipos
        extractTable(ftypes,Tables,Tab),
        % mirar a ver si est�
        lookandput((Name,ArityType),false,true,Tab),
        nonvar(ArityType),
        % comprobar si la aridad es > que la del tipo
        ArityProg > ArityType,
        !,
        Error = true,
        treatError(21,Line).

% en otro caso, todo va bien
smallerArity(_,_,_,_,_,_) :- !.



%%%%%%%%%%%%%%%%%%%%%%%%%% CLAUSE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clause. Clausulas tipo Prolog, que son transformadas en funciones.
% Si el cuerpo contiene varios elementos hay que transformalo en varias
% restricciones.
semantic(H,clause(Head,Cond,Where,Line), Out,
          SinIn, SinOut, Tables, Error) :-
        !,
        % transformamos la lista Cond en una lista de restricciones '=='
        createConstraints(Cond,Constra),
        % por lo demas es como si fuera una funcion con cuerpo True
        % 03-01-00 Suponemos que el separador de cabeza/cuerpo corresponsiente
        % es = (Mercedes & Rafa)
        semantic(H,rule(Head,true,Constra,Where,"=",Line), Out,
                   SinIn,SinOut,Tables,Error ).


%-----------------------------------------------------------------------------%
% createConstraints(+List,-List): genera una restriccion '=='(X,true) por cada 
% X elemento de la lista. La salida es a su vez una lista.
%-----------------------------------------------------------------------------%

createConstraints([],[]) :- !.
createConstraints([Elem|Rest],['=='(Elem,true)|RestConstra]) :-
        !,
        createConstraints(Rest,RestConstra).



% Depu 27/10/00 mercedes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CONDITION WHERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

semantic(H,where(Cond,Where),where(Condition1,Where1),SinIn,SinOut,Tables,Error) :-
    !,
    treat_lists(Cond,Condition1,1,Cont1,_Line,Error),
        treat_lists(Where,Where1,Cont1,_ContOut,_Line,Error),
        
    % comprobaciones semanticas del where:
    % a) partes izquierdas patrones planos
    % b) las variables en las ti son nuevas, es decir no aparecen en 
        %    tj y ni en las ej anteriores ni en la cabeza.
        % en este punto solo se puede hacer la comprobacion b)
        % para la a) se necesita saber si el simbolo de la cabeza es una 
        % constructora o una funcion y esto no se sabe hasta la segunda fase
        no_recursive_where(nothing,Where1,Error), % b)   
        plane_patterns(loquesea,_TabC,_TabF,Where1,Error).
        
% Fin Depu         

    









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 23/06/00 mercedes
semantic(_,L,[L2],_,_,_,Error) :- 
    !,
    treat_lists(L,L2,1,ContO,0,Error).


          
          
          
          
          
          










/*****************************************************************************/
/*                    E S C R I B E___S E C C I O N              */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% writeSection(+H,+S, +Error)
% Escribe la seccion ya traducida S en el fichero de salida. Si hubo error
% no escribe nada
%-----------------------------------------------------------------------------%

writeSection(H,S,Error) :-
        Error \== true,   % es decir si vale false o esta sin instanciar
        !,
        writeSection(H,S).

writeSection(H,S,Error) :- !.


%-----------------------------------------------------------------------------%
% writeSection(+H,+S)
% Escribe en H cada una de las partes de la lista S, a�adiendo un '.' para
% facilitar la lectura desde Prolog
%-----------------------------------------------------------------------------%

writeSection(H,[[]|Rest]):-
        !,
        writeSection(H,Rest).

writeSection(H,[One|Rest]) :-
        !,
        writeSection(H,One),
        writeSection(H,Rest).

writeSection(H,[]) :- !.

writeSection(H,One) :-
        !,
%        nl, writeq(One),
         writeq(H,One), put(H,46),nl(H).




/*****************************************************************************/
/*                       S E G U N D A     F A S E               */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% secondPhaseCompilation(+FileIn,+FileOut,+Tab,?Error)
% Si Error==true no hace nada. En otro caso:
% A partir del fichero de entrada con una representacion intermedia unifica
% las funciones con el mismo nombre y elimina los apply innecesarios
% Si hay error pone 'Error' a true.
%-----------------------------------------------------------------------------%

% si hay error, no hacemos nada
secondPhaseCompilation(_,_,_,Error) :-
        Error==true,
        !.

% en otro caso ...
secondPhaseCompilation(FileIn,FileOut,Tab,Error) :-
        !,
% ARITY para la apertura de ficheros hay que usar
%       open(HIn,FileIn,r),    % abrimos para lectura el fichero de entrada
%       create(HOut,FileOut), % abrimos para escritura el fichero temporal
% SICSTUS
         open(FileIn,read,HIn),  % abrimos para lectura el fichero de entrada
         open(FileOut,write,HOut), % abrimos para escritura el fichero temporal

        % solo usamos la parte de la declaracion de objetos
        extractTable(functions,Tab,TabF),
        extractTable(constructors,Tab,TabC),
        % escribimos el prologo
        prologueFileOut(HOut),
        % hacer el trabajo
        treatSecondPhase(HIn,HOut,nothing,_,TabF,TabC,Error),
        % fin de la segunda fase

        % Yoli YGR 5/12/05 INICIO 
        % escribir anotaciones para las funciones deterministas
        nl(HOut),   		% (Escribo un salto de l�nea)
        extractTable(annotate,Tab,TabD),
        escribirAnnotates(HOut,TabD),	
	  % YGR 5/12/05 FIN 

        close(HIn),
        close(HOut).

% Yoli YGR 5/12/05 inicio
%-----------------------------------------------------------------------------%
% Se esribe la lista de funciones deterministas en el fichero temporal
% Esta lista, contiene las funciones deterministas indicadas por el usuario
%-----------------------------------------------------------------------------%
escribirAnnotates(H,[]).
escribirAnnotates(H,[annotate(deterministic(F))|RestoF]):-
		  writeq(H,annotate(deterministic(F))),
		  put(H,46),
		  nl(H),
		  escribirAnnotates(H,RestoF).

% YGR 5/12/05 fin

%-----------------------------------------------------------------------------%
% prologueFileOut(+Out): se escribe el prologo en el fichero de salida, i.e.,
% se escribe la cabecera del modulo outgenerado (la declaracion de modulo y los
% modulos que importa) y algunas cosas mas.
%-----------------------------------------------------------------------------%

prologueFileOut(HOut) :-
        !,
        % 26-09-1996: cosas de Jaime
        nl(HOut),
        
        % 19/10/99 mercedes
        % Yoli YGR 25/01/2006 inicio
 %      write(HOut,':- module(outgenerated,[cdata/4,infix/4,ftype/4,fun/4,depends/2,primitive/3]).'),
        write(HOut,':- module(outgenerated,[cdata/4,infix/4,ftype/4,fun/4,depends/2,primitive/3,annotate/1]).'),
        % Yoli YGR 25/01/2006 fin
        nl(HOut),
        write(HOut,':- dynamic depends/2, fun/4.'),
        nl(HOut),
        
        % 14-05-1996. Incluimos por defecto las constructoras de las listas
        % se hace asi porque estas constructoras no siguen la gramatica

    % 10/07/1997 
        % tuplas a partir de secuencias. El constructor de seq. es la ','
        writeSection(HOut, cdata(',',2,('$var'('A')->'$var'('B')->
        ('$var'('A'),'$var'('B'))),0)),
        writeSection(HOut,
          cdata('$$tup',1,(('$var'('A'),
      '$var'('B'))->'$$tuple'(('$var'('A'),'$var'('B')))),0)),
        writeSection(HOut,cdata([],0,':'('$var'('A'),[]),0)),
        writeSection(HOut,
    cdata(':',2,('$var'('A')->':'('$var'('A'),[])->':'('$var'('A'),[])),0)),
    % 07/07/97 San Fermin
    writeSection(HOut,cdata('$char',1,('$var'('A')->char),0)),
    
    % 29-04-00 mercedes
    % incluimos la constructora '$io'
    writeSection(HOut,cdata('$io',1,('$var'('A')->'$io'('$var'('A'))),0)),
    
    % 12/05/00 mercedes
    % incluimos la constructora '$stream'(A)
    writeSection(HOut,cdata('$stream',1,handle,0)),
    
    % 12/05/00 mercedes
    % incluimos la constructora readMode
    writeSection(HOut,cdata(readMode,0,ioMode,0)),
    
    % 12/05/00 mercedes
    % incluimos la constructora writeMode
    writeSection(HOut,cdata(writeMode,0,ioMode,0)),
    
    % 12/05/00 mercedes
    % incluimos la constructora appendMode
    writeSection(HOut,cdata(appendMode,0,ioMode,0)),
    
    % 29/05/00 mercedes
    % incluimos la constructora '$channel'(Win,Wout)
    writeSection(HOut,cdata('$channel',2,channel,0)),
    
    % 14/09/00 mercedes
    % incluimos la constructora '$varmut'(A)
    writeSection(HOut,cdata('$varmut',1,varmut,0)),

         % 06/08/01 rafa
        % constructoras del tipo devuelto por pVal
    writeSection(HOut,cdata(pValBottom,0,pVal,0)),
    writeSection(HOut,cdata(pValChar,1,(char->pVal),0)),
    writeSection(HOut,cdata(pValNum,1,(char:[]->pVal),0)),
    writeSection(HOut,cdata(pValVar,1,(char:[]->pVal),0)),
    writeSection(HOut,cdata(pValApp,2,(char:[]->pVal:[]->pVal),0)),

       % constructoras para representar constraints
    writeSection(HOut,cdata(constraint, 1, ->(:(atomicConstraint, []), constraint), constraint)),
    writeSection(HOut,cdata(atomicConstraint, 3, ->(:(char, []), ->(:(pVal, []), ->(pVal, atomicConstraint))), atomicConstraint)),


    % constructoras para representar �rboles
    writeSection(HOut,
    cdata('cTreeNode',7,(char:[]->pVal:[]->pVal->char:[]->pVal:[]->char:[]->'$$tuple'((pVal,'cTree')):[]->'cTree'),0)
        ),
    writeSection(HOut,  cdata('cTreeVoid',0,'cTree',0) ),
%       writeSection(HOut,cdata(cTreeNode, 7, ->(:(char, []), ->(:(pVal, []), ->(pVal, ->(:(char, []), ->(:(pVal, []), ->(:(char, []), ->(:('$$tuple'(','(pVal, cTree)), []), cTree))))))), cTree,0)),
%       writeSection(HOut,cdata(cTreeVoid, 0, cTree, cTree,0)),
       writeSection(HOut,cdata(::<==, 2, ->(cTree, ->(constraint, ccTree)), ccTree,0))
     .



%-----------------------------------------------------------------------------%
% treatSecondPhase(+HIn,+HOut,+RepIn,-RepOut,+TabF,+TabC,?Error)
% HIn   : Handle del que va leyendo
% HOut   : Handle en el que va escribiendo
% RepIn : Representacion acumulada (para unificacion de 'rules')
% RepOut : Representacion acumulada de salida
% TabF   : Tabla con los nombres de las funciones declaradas y sus aridades
% TabC   : Tabla con los nombres de las constructoras declaradas y sus aridades
% Error  : de momento no se usa, no puede haber error
% Dos acciones:
% Si esta leyendo una funcion la escribe en una sola clausula
% Si encuentra 'apply' elimina los innecesarios
%-----------------------------------------------------------------------------%

% si hay error no hacemos mas
treatSecondPhase(_,_,_,_,_,_,Error) :- Error==true,!.

treatSecondPhase(HIn,HOut,RepIn,RepOut,TabF,TabC,Error) :-
        read(HIn,Clause),
        % asegurarse de que no es fin de fichero
        \+ endFile(Clause),
        % eliminamos apply innecesarios de la clausula
        eliminateApply(use_tables,TabF,TabC,(no,[]),Clause,
                      Clause2,Dependences,Error),
        % tratamiento de la clausula leida
    % Depu 04/10/00 mercedes
    % se meten la tablas de constructoras y de funciones como argumento 
    % para mirar si las partes izq. de los where son patrones planos 
    % (constructores planos o funciones aplicadas a menos argumentos que 
    % su aridad y que sean planas tb).
    % Fin Depu
        treatClauseSecondPhase(HOut,Dependences,TabC,TabF,
                                    Clause2,RepIn,RepOut,Error),
        !,
        treatSecondPhase(HIn,HOut,RepOut,_,TabF,TabC,Error).


% cuando llege hasta aqui es por que ha encontrado el fin de fichero
treatSecondPhase(_,H,Rep,_,_,_,_) :-
        !,
        % a lo mejor queda por escribir la ultima funcion
        writeClauseFun(H,Rep).


%-----------------------------------------------------------------------------%
% eliminateApply(+Tables,+TabF,TabC,+LeftSide,+Clause,
%               -Clause2,-Dependences,Error)
% Tables   : puede valer 'usa_tabla' si se quiere que se use o 'no_usa_tabla'
%            si se quiere que lo tome
% TabF     : Tabla con las funciones que han ido apareciendo
% TabC     : Tabla con las constructoras que han ido apareciendo 
% LeftSide : Si vale 'si' es que se esta tratando la parte izquierda de una
%            regla. En este caso no se permite que la aridad de programa para
%            una funcion sea la misma que la aridad de declaracion (en ese caso
%            se trataria de una expresion evaluable, que no se permiten en las
%            partes izquierdas).
%            Si vale 'no' se trata de una parte derecha y se trata normal.
% Clause : Clausula (en formato del fichero temporal) a la que se quieren
%            quitar los applies.
% Clause2: Clausula de salida, con el menor numero de apply posibles.
% Dependec.: Lista con las dependencias de la clausula. Solo tiene sentido si
%            es una 'rule'.
% Error    : true si hay error y sin instanciar en otro caso
%
% eliminateApply se encarga de eliminar los 'apply' innecesarios a partir de las 
% tablas con las aridades de cada funcion y constructora. Tambien extrae las 
% dependecias.
%-----------------------------------------------------------------------------%

% si ha habido algun error, no hay que seguir
eliminateApply(_,_,_,_,_,[],_,Error) :- Error==true,!.

% Rafa 01-12-05: cambio la segunda cla�sula. 
% Programas como g = 1  g= 0  f g = 0 compilaban err�neamente
%Pon�a:

% si es un atomo, no hay nada que hacer
/*
eliminateApply(Tables,TabF,_,_,Clause,Clause,Dependences,_) :-
        (atom(Clause);number(Clause)),
        !,
        % miramos a ver si es una funcion
        (
         lookToSee(Tables,function,(Clause,_),TabF),
         lookandput(Clause,true,_,Dependences)
         ;
         % de cualquier forma esta clausula no debe fallar
         true
         ).
*/
% Ahora pone:
eliminateApply(Tables,TabF,_,Left,Clause,Clause,Dependences,Error) :-
        (atom(Clause);number(Clause)),
        !,
        % miramos a ver si es una funcion
        (
         lookToSee(Tables,function,(Clause,Arity),TabF),
         lookandput(Clause,true,_,Dependences),
         ( Left =(yes,Line),Arity=0,
           Error=true,
           % construimos el mensaje de error y lo mostramos
           name(Clause,CName),
           concatenation([CName,
                     " is not a pattern."],Message),
           treatError(24,Line,Message)
          ; 
           true
          )  
         ;
         % de cualquier forma esta clausula no debe fallar
         true
         ).

% si es una lista vacia, tampoco
eliminateApply(_,_,_,_,[],[],_,_) :- !.

% si es una lista mirar cada elemento
eliminateApply(Tables,TabF,TabC,Left,[One|Rest],
                [OneS|RestS],Dependences,Error) :-
        !,
        eliminateApply(Tables,TabF,TabC,Left,One,OneS,Dependences,Error),
        eliminateApply(Tables,TabF,TabC,Left,Rest,RestS,Dependences,Error).



% si es un apply ...

% primer caso, un apply de una apply

eliminateApply(Tables,TabF,TabC,LeftSide,
                '$apply'('$apply'(Name,List1),List2),
                 Out,Dependences,Error) :-
        !,
        % consideramos que apply(apply(Algo,[a,b]),[c,d])=apply(Algo,[a,b,c,d])
        append(List1,List2,List),
        eliminateApply(Tables,TabF,TabC,LeftSide,
                        '$apply'(Name,List),
                        Out,Dependences,Error).


% segundo caso, es un apply de algo concreto, ver de que y actuar en consec.
eliminateApply(Tables,TabF,TabC,LeftSide,'$apply'(Name,List),
              Out,Dependences,Error) :-
        !,
        % mirar a ver que es lo que se esta aplicando
        examinateApplying(Tables,TabF,TabC,Name,WhatIs,Arity),
        % incluye dependencias si hace falta
        includeDependences(Name,WhatIs,Dependences),
        % tratamiento del apply en concreto
        treatOneApply(Tables,TabF,TabC,Name,List,WhatIs,Arity,LeftSide,
                        Out,Dependences,Error).



%-----------------------------------------------------------------------------%
% calculateStrict(+LeftSide, +WhatIs, -SmallerEstrict, -Line)     
% Description: A partir de LeftSide y WhatIs indica si el numero de argumentos
% que podra tener un apply puede ser menor o igual a su aridad. El que sea
% estrictamente menor o pueda ser menor o igual, importa.
%-----------------------------------------------------------------------------%

calculateStrict((yes,Line),is_constructor,false,Line) :- !.
calculateStrict((yes,Line),is_function,true,Line)     :- !.
calculateStrict((yes,Line),_WhatIs,notimportant,Line)   :- !.
calculateStrict((no,Line),_WhatIs,notimportant,Line)   :- !.




%-----------------------------------------------------------------------------%
% includeDependences(+Name, +WhatIs, +Dependences) 
% Description: Anyade a la tabla 'Dependences' el 'Name' si es de una
% funcion.
%-----------------------------------------------------------------------------%

includeDependences(Name,is_function,Dependences) :-
        !,
        lookandput(Name,true,_,Dependences).

% en cualquier otro caso, no se hace nada
includeDependences(_Name,_WhatIs,_Dependences) :- !.




%-----------------------------------------------------------------------------%
% treatOneApply(+Tab,+TabF,+TabC,+Name, +List, +WhatIs, +Arity, +Left, 
%                      -Out, ?Depend,?Error)                           
% Description: Aplica el 'nombre' a la 'lista', dejando los apply's que no se
% puedan suprimir, y mirando si hay que incluir nuevas dependencias, o dar
% algun error, segun lo 'WhatIs'.
%-----------------------------------------------------------------------------%

% si hay error, no se hace nada
treatOneApply(_Tab,_TabF,TabC,_Name,_List,_WhatIs,_Arity,_Left,
                _Out,_Depend,Error):-
        Error==true,
        !.

/* no trato el error. Se lo paso a Jaime y el lo da mejor */

% en cualquier otro caso, el tratamiento es comun
treatOneApply(Tab,TabF,TabC,Name,List,WhatIs,Arity,LeftSide,
                Out,Dependences,Error) :-
        !,
        eliminateApply(Tab,TabF,TabC,LeftSide,List,ListArg,Dependences,Error),
        % calculamos si el numero de argumentos tendra que ser menor o
        % puede ser igual a la aridad
        calculateStrict(LeftSide,WhatIs,SmallerEstrict,Line),
        % formamos el nuevo apply
        builtNewApply(Name,ListArg,Arity,SmallerEstrict,Line,
                        Out,Error).



%-----------------------------------------------------------------------------%
% examinateApplying(+Tab,+TabF,+TabC,+ElementToExamitate,-WhatIs,-Arity)  
% Description: Devuelve en WhatIs un nombre explicativo de lo que es la
%              'ElementToExamitate', asi como su Arity, si tiene sentido
% Parametros:
% Tab : parametro para 'miraver'. Si vale 'usa_tabla' es que se usaran TabF
%       TabC para buscar los datos, si vale 'no_usa_tabla', se buscaran las
%       clausulas correspondientes en la base de datos.
% TabF,TabC : Tablas con las funciones y constructoras que se han definido en
% el programa.
% ElementToExamitate : El operando del apply, queremos ver que es
% WhatIs         : Salida con lo que es el parametro:
%                'is_variables', 'is_function', 'is_constructor', 'is_something'
% Arity        : La aridad de la 'ElementToExamitate'
%-----------------------------------------------------------------------------%

%  es una variable. Su aridad sera entonces 0
examinateApplying(_Tab,_TabF,_TabC,ElementToExamitate,is_variables,0) :-
        isVariable(ElementToExamitate),
        !.

% es una funcion.
examinateApplying(Tab,TabF,_TabC,ElementToExamitate,is_function,Arity) :-
        lookToSee(Tab,function,(ElementToExamitate,Arity),TabF),
        !.

%  es una constructora.
examinateApplying(Tab,_TabF,TabC,ElementToExamitate,is_constructor,Arity) :-
        lookToSee(Tab,constructor,(ElementToExamitate,Arity),TabC),
        !.

% no se que puede ser sino.
examinateApplying(_Tab,_TabF,_TabC,_ElementToExamitate,is_something,_Arity) :- !.



% 23-07-1996
% Si es una regla de funcion distinguimos entre la parte izquierda y la
% parte derecha.
% Esto se hace asi porque en la parte izquierda no se permite que la aridad
% de una funcion como patron iguale su aridad de programa (es decir, que sea
% una expresion evaluable), mientras que en la parte derecha si
% 03-01-00 Se incluye el argumento HeadSep
eliminateApply(Tab,TabF,TabC,(no,_L),rule(Head,Body,Condition,Where,HeadSep,Line),
                rule(HeadS,BodyS,ConditionS,WhereS,HeadSep,Line),Dep,Error) :-
        !,
        % en el caso de la cabeza, no pasamos el propio nombre de la funcion
        % porque ahi seguro que no hay apply, ademas el parametro (yes,_)
        % indica que se compruebe las aridades de funcion y constructora
        Head =.. [NameF|ListArg],
        eliminateApply(Tab,TabF,TabC,(yes,Line),ListArg,ListArgS,Dep,Error),
        HeadS =.. [NameF|ListArgS],

        % el resto se trata normal
        eliminateApply(Tab,TabF,TabC,(no,Line),Body,BodyS,Dep,Error),
        eliminateApply(Tab,TabF,TabC,(no,Line),Condition,ConditionS,Dep,Error),
        eliminateApply(Tab,TabF,TabC,(no,Line),Where,WhereS,Dep,Error).


% en otro caso, lo convertimos en una lista y tratamos cada elemento
eliminateApply(Tab,TabF,TabC,LeftSide,Clause,Out,Dependences,Error) :-
        !,
        Clause =.. [F|List],
        eliminateApply(Tab,TabF,TabC,LeftSide,List,ListOut,Dependences,Error),
        Out =.. [F|ListOut].


%-----------------------------------------------------------------------------%
% builtNewApply(+Name,+List,+Arity,SmallerEstrict,Line,-Out,Error)
% construye una estructura con functor 'Name' y los k primeros argumentos
% de la 'List', siendo k = min(Arity,Longitud(List)).
% El resto de los argumentos formaran applys
%-----------------------------------------------------------------------------%

% si no tiene aridad no formamos la estructura, metemos apply directamente
builtNewApply(Name,List,0,SmallerEstrict,Line,Out,Error) :-
        !,
        introduceApplyes(Name,List,Out).

% si tiene aridad, habra que compararla con el numero de parametros
% reales y ver si hay que dar un error, y si no meter los applies corresp.
builtNewApply(Name,List,Arity,SmallerEstrict,Line,Out,Error) :-
        take_n_elements(Arity,List,ListOut,RestList,Just,Exceed),
        Struct =.. [Name|ListOut],
       (
        %  ver si tiene el numero correcto de parametros
         correct_number_of_arguments(SmallerEstrict,Just,Exceed),
         % en este caso metemos los applies
         introduceApplyes(Struct,RestList,Out)
        ;
        % en otro caso damos el error correspondiente

         Error=true,
         % la salida no importa, puesto que hay error, pero por si acaso...
         Out=[],
         % construimos el mensaje de error y lo mostramos
         name(Name,CName),
         concatenation(["Invalid number of arguments for ",CName,
                     " in left hand side of rule."],Message),
         treatError(24,Line,Message)
       ),
       % rafa 16/11/00 cambiado el sitio del corte
       !.

%-----------------------------------------------------------------------------%
% correct_number_of_arguments(+SmallerEstrict,+Just,+Exceed)
% Este predicado sirve para comprobar si las funciones (SmallerEstrict=true) y
% las constructoras (SmallerEstrict=false) tiene un numero adecuado de argumentos
% cuando se encuentran en la parte izquierda de una declaracion de funcion, es 
% decir, cuando dicha funcion o constructora es a su vez un argumento.
%-----------------------------------------------------------------------------%

correct_number_of_arguments(false,true,false) :- !.
% rafa 21/10/05: A program like
%   data d = c int int
%   f (c 3) = 4
% failed. The next clause fixes this error:
correct_number_of_arguments(false,false,false) :- !.
correct_number_of_arguments(true,false,false) :- !.
correct_number_of_arguments(notimportant,_Just,_Exceed) :- !.


%-----------------------------------------------------------------------------%
% introduceApplyes(+Struct,+List,-Out)
% cada elemento de la lista sera el segundo componente de un apply, siendo el
% primero el resutado de aplicar la funcion a 'Estruct' con el resto de la lista
%-----------------------------------------------------------------------------%
introduceApplyes(Struct,[],Struct) :- !. % caso base
introduceApplyes(Struct,[H|T],Out) :-
        !,introduceApplyes('$apply'(Struct,H),T,Out).


%-----------------------------------------------------------------------------%
% treatClauseSecondPhase(+HOut,+Depend,+TabC,+TabF,+Clause,+RepIn,-RepOut,?Error)
% va haciendo las comprobaciones efectivas sobre cada clausula, escribiendo
% en el fichero de salida cuando corresponda.
% El parametro 'Depend' solo se usa si se trata de una regla de funcion
%-----------------------------------------------------------------------------%

% si ha habido algun error, no hacemos nada
treatClauseSecondPhase(_,_,_,_,_,_,_,Error) :- Error==true,!.


%%%%%%%%%%%%%%%%%%%%%%%%%%%% REGLAS DE FUNCION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% si encontramos la primera aparicion de una funcion ...
% 03-01-00 incluimos en rule el argumento HeadSep, pero no en 'fun'
treatClauseSecondPhase(HOut,Dependences, TabC,TabF,
                            rule(Head,Body,Condition,Where,HeadSep,Line),
                            nothing,fun(Name,Ari,Rules,LDepends,Line),Error):-
        !,
    % Depu 04/10/00 mercedes
        % comprobamos que los patrones de la parte izq. de las decl. where
        % son planos
    plane_patterns(use_tables,TabC,TabF,Where,Error),
    % Fin Depu
        
    functor(Head,Name,Ari),
        % a�adimos a la tabla de reglas la primera regla
        lookandput(rule(Head,Body,Condition,Where,
%                       HeadSep,
                        Line),true,_,Rules),
        % incorporamos las nuevas dependencias, si las hubiere
        joinLists(Dependences,LDepends).



% si estamos leyendo una funcion seguimos encontrando reglas ...
% 03-01-00 incluimos en rule el argumento HeadSep, pero no en 'fun'
treatClauseSecondPhase(HOut,Dependences,TabC,TabF,
                            rule(Head,Body,Condition,Where,HeadSep,Linerule),
                            fun(Name,Ari,Rules,LDepends,Line),
                            fun(Name,Ari,Rules,LDepends,Line),Error) :-
        
    % Depu 04/10/00 mercedes
        % comprobamos que los patrones de la parte izq. de las decl. where
        % son planos
    plane_patterns(use_tables,TabC,TabF,Where,Error),
        % Fin Depu

    % asegurarnos de que seguimos con la misma
        functor(Head,Name,Ari),
        !,
        % a�adimos a la tabla la nueva regla
        lookandput(rule(Head,Body,Condition,Where,
%                       HeadSep,
                        Linerule),true,_,Rules),
        % incorporamos las nuevas dependencias, si las hay
        joinLists(Dependences,LDepends).


% si estamos leyendo una funcion y encontramos otra cosa, escribirla
treatClauseSecondPhase(HOut,Dependences,_TabC,_TabF,Clause,
                            fun(Name,Ari,Rules,LDepends,Line),
                            Out,Error):-
        !,
        writeClauseFun(HOut,fun(Name,Ari,Rules,LDepends,Line)),
        % aun queda por tratar la clausula
        treatClauseSecondPhase(HOut,Dependences,TabC,TabF,
                                    Clause,nothing,Out,Error).

% cuando llega hasta aqui es que es inofensiva, escribirla sin mas
treatClauseSecondPhase(HOut,Dependences,TabC,TabF,Clause,_,nothing,Error) :-
        !,
        writeSection(HOut,Clause).


%-----------------------------------------------------------------------------%
% writeClauseFun(+H,+Rep): Escribir en H una clausula de funcion. Si no 
% lo es, no hace nada.
%-----------------------------------------------------------------------------%

writeClauseFun(H,fun(N,A,R,D,L)) :-
        !,
        closeHollow(R),
        closeHollow(D),
        nl(H),
        writeDependences(H,N,D),
        writeSection(H,fun(N,A,R,L)),
        nl(H).
writeClauseFun(_,_) :- !.


%-----------------------------------------------------------------------------%
% writeDependences(+H,+F,+L)
% escribe en el fichero de salida H las dependencias de la funcion F, que
% vienen dadas por la lista L
%-----------------------------------------------------------------------------%

writeDependences(H,F,[]) :- !.
writeDependences(H,F,[Dep|T]) :-
        writeSection(H,depends(F,Dep)),
        writeDependences(H,F,T).


%-----------------------------------------------------------------------------%
% chainToyToProlog(+Chain,-ChainProlog)
% Transforma una cadena toy de la forma $char(N):$char(N2):...:[] a una cadena
% tipo prolog, es decir una lista de numeros de la forma [N,N2,...]
%-----------------------------------------------------------------------------%

chainToyToProlog( ':'('$char'(N),R), [N|R2]) :- chainToyToProlog(R,R2).
chainToyToProlog([],[]).




/*****************************************************************************/
/*                           T A B L A S                     */
/*****************************************************************************/

% Mantenimiento de Tablas
% Se trabaja con una estructura que contiene todas las tablas.
% La estructura es una tupla cuyo primer elemento es la tabla de simbolos,
% y el segundo es a su vez una tupla con todas las tablas.
% Los elementos de cada tabla son a su vez tuplas, siendo el primer
% componente la clave que se utilizara para buscar repeticiones
% El formato de cada tabla es
%
%         NOMBRE         FORMATO
%         -----------    -------
%  1      references    Type(Name)
%  2      priorityes    (Operator,Priority,{left,right,noasoc})
%  3      data          Name
%  4      constructors  (Name,Arity)
%  5      ftypes         (Name,Arity)
%  6      types          (Name,ListVar,Type)
%  7      functions      (Name,Arity)


%-----------------------------------------------------------------------------%
% returnTablesOfCompilation(-Tables)
% Devuelve las tablas de compilacion, aunque sin eliminarlas de la B.D.
% Hay 2 versiones. En una se puede pedir una tabla concreta, mientras que
% en la otra se devuelven todas las tablas
% Si no hay tablas en la B.D. devuelve una estructura con huecos.
%-----------------------------------------------------------------------------%

returnTablesOfCompilation(Tables) :-
        !,
        % primero creamos una estructura con los huecos
        createTablesCompilation(Tables),
        % ahora se intentan rellenar los huecos
        (clause(Tables,true); true).

returnTablesOfCompilation(Name,Table) :-
        !,
        returnTablesOfCompilation(Tables),
        extractTable(Name,Tables,Table).


%-----------------------------------------------------------------------------%
% deleteTablesOfCompilation(+Tables)
% Elimina las tablas de compilacion de la B.D., devolviendo su valor
%-----------------------------------------------------------------------------%

deleteTablesOfCompilation(Tables) :-
        !,
        createTablesCompilation(Tables),
        (retract(Tables); true).


%-----------------------------------------------------------------------------%
% modifyTablesOfCompilation(+Tables)
% Cambia la tabla actual, si la hay, por la nueva. Si no simplemente guarda
% la nueva. Supone que la nueva es siempre una ampliacion de la antigua
% es decir, la unica modificacion esta en el hueco del final
%-----------------------------------------------------------------------------%

modifyTablesOfCompilation(Tables) :-
        deleteTablesOfCompilation(_),
        asserttables(Tables).

modifyTablesOfCompilation(NameTable,Tab) :-
        deleteTablesOfCompilation(Tables),
        % aqui en realidad se utiliza extractTable para meter el nuevo valor
        extractTable(Name,Tables,Tab),
        % guardamos la nueva
        asserttables(Tables).


%-----------------------------------------------------------------------------%
% createTablesCompilation(-Tables)
% Creacion de las tablas vacias
%-----------------------------------------------------------------------------%

createTablesCompilation(tablesOfCompilation(_,tables(_Priority,_Data,_Const,_FTypes,_Types,_Functions,
% Yoli YGR 25/10/2006 inicio a�adimos una nueva tabla 
_Annotates))) :- !.
% Yoli YGR 25/10/2006 fin

%-----------------------------------------------------------------------------%
% extractTable(+Name,+Tables,+Table)
% Clausulas que devuelven la tabla solicitada de entre la tupla
% de tablas
%-----------------------------------------------------------------------------%

extractTable(references,Tables,P)    :- !,arg(1,Tables,P).
extractTable(X,Tables,P)              :- \+ number(X),!,
                                      arg(2,Tables,T),extractTable2(X,T,P).
extractTable2(priorityes,Tables,P)   :- !,arg(1,Tables,P).
extractTable2(data,Tables,P)         :- !,arg(2,Tables,P).
extractTable2(constructors,Tables,P) :- !,arg(3,Tables,P).
extractTable2(ftypes,Tables,P)        :- !,arg(4,Tables,P).
extractTable2(types,Tables,P)         :- !,arg(5,Tables,P).
extractTable2(functions,Tables,P)     :- !,arg(6,Tables,P).
% Yoli YGR inicio 25/01/2006
extractTable2(annotate,Tables,P)     :- !,arg(7,Tables,P).
% Yoli YGR fin 25/01/2006
% tambi�n se puede obtener a partir del numero
extractTable(1,Tables,P)             :- !,arg(1,Tables,P).
extractTable(N,Tables,P)             :- !,N2 is N-1,arg(2,Tables,T),arg(N2,T,P).
% version para sacar la tabla a partir de la segunda componente
extractTable2(N,Tables,P)            :- !, arg(N,Tables,P).


%-----------------------------------------------------------------------------%
% closeHollowsTables(?Table,+N)
% quitamos los agujeros del final
%-----------------------------------------------------------------------------%

closeHollowsTables(Tab,N) :-
        extractTable(N,Tab,T),
        closeHollow(T),
        N2 is N+1,
        !,
        closeHollowsTables(Tab,N2).
closeHollowsTables(_,_):-!.



%-----------------------------------------------------------------------------%
% includeKey(+NameTable,+Table,+Elem,+CodError,+Line,?Error)
% NameTable: Name de la subtabla sobre la que vamos a trabajar
% Table      : Tupla que contiene todas las tablas
% Elem  : Elemento a insertar en la tabla. Debe ser una estructura cuyo primer
%         elemento es la clave.
% CodError   : Cod. de error, si lo hubiere.
% Line      ; Numero de linea para mostrar el error
% Error      : True si hay error o lo que valiera e.o.c.
%-----------------------------------------------------------------------------%

includeKey(NameTable,Table,Elem,CodError,Line,Error) :-
        % 'Tab' sera la tabla con hueco sobre la que trabajaremos
        extractTable(NameTable,Table,Tab), % extraemos la tabla corresp.
        % buscamos la clave en la tabla
        arg(1,Elem,Key),
        lookandput((Key,_),false,Was,Tab),
        (
          % si ya estaba, dar error
          Was == true,
          treatError1(CodError,Line,Elem),
          Error=true
        ;
          % si no esta, incluirlo
          Was==false,
          includeElement(Elem,Tab)
       ).



%-----------------------------------------------------------------------------%
% includeElement(+Elem,?Tab)
% incluye  'Elem' en la tabla con hueco 'Tab'.
% no le importa si ya estaba o no. Simplemente lo anyade al final
%-----------------------------------------------------------------------------%

includeElement(Elem,Tab) :- lookandput(Elem,true,_,Tab).




%-----------------------------------------------------------------------------%
% includeIfNew(+NameTable,?Table,+Elem,+Repe,+SinIn,-SinOut,
%                +CodError,+Line,?Error)
% NameTable: Name de la subtabla sobre la que vamos a trabajar
% Table      : Tupla que contiene todas las tablas
% Elem       : Elemento que queremos incluir si es nuevo
% Repe       : true si hay que incluir aunque ya esta en la tabla. false e.o.c.
% SinIn     : Ultima pieza tratada
% SinOut     : Nueva pieza tratada
% CodError   : Cod. de error, si lo hubiere.
% Line      ; Numero de linea para mostrar el error
% Error      : True si hay error o lo que valiera e.o.c.
%-----------------------------------------------------------------------------%

% si hay error no hacemos nada
includeIfNew(_NameTable,_Table,_Elem,_Repe,_SinIn,_SinOut,_CodError,
                _Line,Error) :-
        Error == true,
        !.

% incluye un elemento en la tabla indicada, dando todos los errores pertinentes
includeIfNew(NameTable,Table,Elem,Repe,SinIn,SinOut,CodError,Line,Error):-
        !,
        extractTable(NameTable,Table,Tab), % extraemos la tabla corresp.
        (
            (
            %% si ya esta pero es el anterior no importa
            % 29-11-99 Solo se permiten 2 declaraciones consecutivas
            % del mismo objeto si este es una regla de funcion
            NameTable = functions, 
            SinIn=rule(_Name,_HeadSep), SinIn = SinOut, Was = true
            ;
		  (  % YGR 5/12/05
                 NameTable = annotate,        % YGR 5/12/05
                 Search = Elem                % YGR 5/12/05
           
                 ;
                 % lo buscamos

                 (arg(1,Elem,Key),
                  Search=(Key,_)
                  ; 
                  Search=Elem
                  ),
                  lookandput(Search,false,Was,Tab),
                  Was=false
               ) % Yoli YGR 5/12/05

            ),
            (
             (Was=true,Repe=true
              ;
              Was=false
             ),
             % si hay que guardar el nuevo dato
             lookandput(Elem,true,_,Tab)
            ;
             true  % si esta y no hay que repetir, no hacer nada
            )
         ;
            % esta en la tabla, pero no deberia
            (
            Error=true  , treatError1(CodError,Line,Elem)
            ;
            treatError(CodError,Line)
            )
        ).



%-----------------------------------------------------------------------------%
% includeIfNew(+NameTable,+Elem,+Repe,+SinIn,-SinOut,
%                +CodError,+Line,?Error)
% version que obtiene la tabla de la B.D.
%-----------------------------------------------------------------------------%

includeIfNew(NameTable,Elem,Repe,SinIn,SinOut,CodError,Line,Error):-
        !,
        deleteTablesOfCompilation(Tables), % extraemos la tabla
        includeIfNew(NameTable,Tables,Elem,Repe,
                       SinIn,SinOut,CodError,Line,Error),
        modifyTablesOfCompilation(Tables). % guardamos la nueva

%-----------------------------------------------------------------------------%
% createListVarProlog(+ListIn,-ListOut)
% Description: Devuelve una 'ListOutida' cuyos elementos son variables
%               Prolog diferentes y cuya longitud es la misma que la de
%               la 'ListIn'. Es decir permite establecer una biyeccion
%               entre los elementos de la 'ListIn' y una lista de
%               variables Prolog.
%-----------------------------------------------------------------------------%

% Caso base: la lista vac�a
createListVarProlog([],[]):-!.

% En otro caso: Convertir la cabeza en un par de la forma (Var$(A),_V1)
% y tratar el resto analogamente
createListVarProlog([_C|R],[_VarProlog|Rtreated]) :-
        !,
        createListVarProlog(R,Rtreated).


%-----------------------------------------------------------------------------%
% priorityOperator
% se distinguen dos casos:
% 1) La prioridad esta en las tablas correspondientes
% 2) Estamos leyendo de linea de comandos y las prioridades estan en la B.D.
%-----------------------------------------------------------------------------%

priorityOperator(Tab,Op,Asoc,Pri) :-
        % obtenemos la tabla de prioridades.
        extractTable(priorityes,Tab,T),
        % Si esta aqui obtenemos sus datos
        lookandput((Op,Asoc,Pri),false,Was,T),
        Was = true,
        !.

priorityOperator(_Tab,Op,Asoc,Pri) :-
        % en este caso las prioridades hay que sacarlas de la B.D.
        (
         infix(Op,Asoc,Pri)
         ;
         % 4-11-1996
         primInfix(Op,Asoc,Pri)
         ;
         fail
        ),
        !.

% por defecto prioridad 11 y no asociativos
% 24/03/00 mercedes
% antes se daba prioridad 9 por defecto pero se ha cambiado a 11 para que
% div, mod... tengan mas prioridad que == (prioridad 10), ya que si no, si
% pones TOY> 10 `div` 5 == X, da error porque considera:
% 10 `div` (5 == X)
priorityOperator(_,_,noasoc,11) :- !.
