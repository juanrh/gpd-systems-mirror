runtime_entry(start) :-
	['toy.pl'].