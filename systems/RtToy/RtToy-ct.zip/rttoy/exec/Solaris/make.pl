:- compile(main), save_program('toyunix.sav'), halt.

