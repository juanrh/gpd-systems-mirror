:- compile(main), save_program('main.sav'), halt.

