%----------------------------------------------------------------------------%
% connected.pl
%----------------------------------------------------------------------------%
/*
- Author: Jaime
- Description: This module searches the connected components of a graph of 
  dependences, concretely the functional dependences of the declared functions
  by the user and the standard dependences.
- Modules which import it: inferrer
- Imported modules: 
	> tools (with 'member', 'append').
	> dyn
	> outgenerated (with 'fun', 'depends' and 'primitive').
	
- Modified: 
	30/09/99 mercedes (the predicates have been commented)
	26/10/99 mercedes (modules).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(connected, [connected_comp/1]).

:- load_files(tools,[if(changed),imports([member/2,append/3])]).

:- load_files(dyn,[if(changed)]).

:- load_files(newout,[if(changed),imports([fun/4,depends/2,primitive/3])]).


/* Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.

*/



/*

LLAMADA AL MODULO:
	connected_comp(LCOM)

	Devuelve en LCOM la lista de componentes conexas (a su vez, listas).

	

	Este modulo busca las componentes conexas de un grafo de dependencias,
en concreto de las dependencias funcionales de las funciones declaradas por
el usuario y las del standard.bab. Para ello Necesita tener en la BD todas las
clausulas fun del .out correspondiente al programa y tb necesita todos los
hechos depends(X,Y).
En principio en la BD estan tambien las dependencias de las primitivas (de las 
funciones que dependen de primitivas, ya que, una primitiva no depende de nadie)
y tenemos que hacer una criba de las que no son dependencias de primitivas que
son las que nos interesan. De lo contrario intentariamos inferir el tipo de 
las primitivas, que como no tienen reglas (explicitas), causaria errores de
inferencia.

Asertaremos a la BD clausulas depFun, iguales que depends excepto en las 
primitivas.

*/


%:-dynamic depFun/2.


%----------------------------------------------------------------------------%
% RUNOVERGRAPH(-V,-VI): this predicates runs over the graph to asign visit order
% to the nodes
%----------------------------------------------------------------------------%
runOverGraph(VAL,VISITED):-
	findall(F,fun(F,_,_,_),TOTALS),
	% write(TOTALS),nl,
	runOver(TOTALS,[],VISITED,[],VAL).
	% write(VAL),nl.


%----------------------------------------------------------------------------% 
% RUNOVER(+L,+VI,-VO,+VVI,-VVO): auxiliar predicate of runOverGraph            
%----------------------------------------------------------------------------%

runOver([],[],[],[],[]).

runOver([F],VISIN,VISOUT,VIN,VOUT):-
	!, 
	% write(F),nl,
	visit(F,VISIN,VISOUT,VIN,VOUT).

runOver([F|L],VISIN,VISOUT,VIN,VOUT):- 
	% write(F),nl,
	visit(F,VISIN,VISOUT1,VIN,VOUT1),
	runOver(L,VISOUT1,VISOUT,VOUT1,VOUT).


%----------------------------------------------------------------------------%
% VISIT(+N,+VI,-VO,+VVI,-VVO): this predicate visits a node                    
%----------------------------------------------------------------------------%

visit(F,VISIN,VISOUT,VIN,[value(F,1)]):-
			notvisit(F,VISIN),
                        setof(G,depFun(G,F),LNODOS),
			%write(LNODOS),nl,
                        visitnodes(F,LNODOS,[F|VISIN],VISOUT,
			VIN,[]),
		        !.

visit(F,VISIN,VISOUT,VIN,[value(F,N1),value(H,N)|VOUT]):-
			notvisit(F,VISIN),
			setof(G,depFun(G,F),LNODOS),
			%write(LNODOS),nl,
			visitnodes(F,LNODOS,[F|VISIN],VISOUT,
			VIN,[value(H,N)|VOUT]),!,
		        N1 is N+1.


visit(F,VISIN,[F|VISIN],[value(H,N)|VIN],[value(F,N1),value(H,N)|VIN]):-
			notvisit(F,VISIN),!,N1 is N+1.

visit(F,VISIN,[F|VISIN],[],[value(F,1)]):-
			notvisit(F,VISIN),!.

visit(_,VISIN,VISIN,VIN,VIN).


%----------------------------------------------------------------------------%
% VISITNODES(+N,+VI,-VO,+VVI,-VVO): auxiliar predicate of visit          
%----------------------------------------------------------------------------%  

visitnodes(_,[],VISIN,VISIN,VIN,VIN):-!.

visitnodes(F,[G|L],VISIN,VISOUT,VIN,VOUT):-
			notvisit(G,VISIN),!,
			visit(G,VISIN,VISOUT1,VIN,VOUT1),
                        visitnodes(F,L,VISOUT1,VISOUT,VOUT1,VOUT).

visitnodes(F,[_|L],VISIN,VISOUT,VIN,VOUT):-
                visitnodes(F,L,VISIN,VISOUT,VIN,VOUT).


%----------------------------------------------------------------------------%
% LIST(-L): this predicate runs over the graph and returns the visit order
%----------------------------------------------------------------------------%

list(L):-runOverGraph(V,_),order(V,L).


%----------------------------------------------------------------------------%
% RUNOVERINORDER(+LN,+CI,-CO,-LNO): this predicate runs over the graph to 
% obtain the connected components
%----------------------------------------------------------------------------%

runOverInOrder([],INPUT,INPUT,[]):-!.

runOverInOrder([F|L],INPUT,OUTPUT,L2):-
		member(F,INPUT),!,
		runOverInOrder(L,INPUT,OUTPUT,L2).

runOverInOrder([F|L],INPUT,OUTPUT,[LF|L2]):-
		component(F,[F|INPUT],OUTPUT1,L1),
		LF=[F|L1],
		runOverInOrder(L,OUTPUT1,OUTPUT,L2).


%----------------------------------------------------------------------------%
% COMPONENT(+N,+CI,-CO,-L): this predicate examinates a node
%----------------------------------------------------------------------------%

component(F,INPUT,OUTPUT,L):-
		setof(G,depFun(F,G),LNODOS),!,
		components(LNODOS,INPUT,OUTPUT,L).

component(_,INPUT,INPUT,[]):-!.


%----------------------------------------------------------------------------%
% COMPONENTS(+LN,+CI,-CO,-LO): connected component of a node
%----------------------------------------------------------------------------%

components([],INPUT,INPUT,[]):-!.

components([G|RG],INPUT,OUTPUT,LRG):-
		member(G,INPUT),!,
		components(RG,INPUT,OUTPUT,LRG).

components([G|RG],INPUT,OUTPUT,LIST):-
		component(G,[G|INPUT],OUTPUT1,LG),
		components(RG,OUTPUT1,OUTPUT,LRG),
		append([G|LRG],LG,LIST).


%----------------------------------------------------------------------------%
% connected_comp(+V,-LCOM): main predicate
%----------------------------------------------------------------------------%

connected_comp(LCOM):-
	% En el .out tenemos hechos depends que recogen las dependencias entre
	% funciones incluidas las primitivas. Para este modulo nos interesan
	% solo las dependencias entre funciones no primitivas. Este predicado
	% mete en la BD hechos depFun que criban el total de dependencias 
	% excluyendo las de primitivas. 
	assertFunctionalDependences,
	list(V),
	runOverInOrder(V,[],_,LCOM).
	%retractall(depFun(_,_)).  
	%write(LCOM),nl.


/********************** Auxiliar predicates************************/

assertFunctionalDependences:-
	findall(depFun(F,G),depends(F,G),LstDepFun),
	assertLstClausules(LstDepFun).

assertLstClausules([]).
assertLstClausules([depFun(F,G)|R]):-
	(primitive(G,_,_),!,true;
	assertdepFun(F,G)),
	assertLstClausules(R).

/******************************************************************/

%----------------------------------------------------------------------------%
% NOTVISIT(+N,+LN): this predicate fails if the node N is in the list LN of
% visited nodes
%----------------------------------------------------------------------------%
notvisit(_,[]):-!.
notvisit(F,[G|Q]):-F\==G,!,notvisit(F,Q).


%----------------------------------------------------------------------------%  
% ORDER(+LVN,LN): this predicate obtains a nodo of a list of elements of the 
% form: (value,node)
%----------------------------------------------------------------------------%

order([],[]):-!.

order([value(F,_)|R],[F|RF]):-order(R,RF).





