
:- module(primitivCod,['$if_then_else'/6,
          '$if_then'/5,
          % '$flip'/6,
%%::B
          '$evalfd'/5,
%%::E
          '$uminus'/4,'$abs'/4,'$sqrt'/4,'$ln'/4,'$exp'/4,
          '$sin'/4,'$cos'/4,'$tan'/4,'$cot'/4,'$asin'/4,'$acos'/4,'$atan'/4,
          '$acot'/4,'$sinh'/4,'$cosh'/4,'$tanh'/4,'$coth'/4,'$asinh'/4,'$acosh'/4,
          '$atanh'/4,'$acoth'/4,$+ /5,$- /5,$* /5,'$min'/5,'$max'/5,$/ /5,'$**'/5,
          '$log'/5,$^ /5,'$div'/5,'$mod'/5,'$gcd'/5,'$round'/4,'$trunc'/4,
          '$floor'/4,'$ceiling'/4,'$toReal'/4,$< /5,$> /5,$<= /5,$>= /5,
          '$ord'/4,'$chr'/4,
          '$putChar'/4,'$done'/3,'$getChar'/3,'$return'/4,$>> /5,$>>= /5,
          '$putStr'/4,'$putStrLn'/4,'$getLine'/3,'$cont1'/4,'$cont2'/5,
          '$writeFile'/5,'$readFile'/4,'$readFileContents'/4,
          '$trans'/3,'$control_open'/3,'$add_control'/5,'$remove_control'/3,
%% ::B Rafa           
          '$dValToString'/4,'$dVal'/4,'$selectWhereVariableXi'/7,
          '$getConstraintStore'/4,
%% ::E

% FALLO FINITO Y CORTE 
% pacol 17-03-05
           '$fails'/4, '$once'/4, '$collect'/4, '$collectN'/5,
% RUN-TIME CHOICE 
% pacol 19-09-08
           '$rt'/4
          ]).



:- load_files(toycomm,[if(changed)]). %,imports([hnf/4,unifyHnfs/4,nf/4])]).

% :- load_files(basic,[if(changed),imports(['$$apply'/5])]).
% Esta dependencia se debia exclusivamente al codigo para 'flip',
% y generaba efectos indeseables al activar y desactivar /cflpr cuando estamos
% con la version con restricciones sobre los reales.
% Se ha eliminado, y para ello, el codigo de flip se ha llevado a
% basic.pl



% 11/05/00 mercedes
% Estos modulos se necesitan para la parte de entrada/salida

:- load_files(tools,[if(changed),imports([append/3, member/2])]).

:- load_files(codfun,[if(changed),imports([introduceSusp/3])]).

:- load_files(dyn,[if(changed),imports([assertfile/3,retractfile/3,file/3])]).

:- load_files(errortoy,[if(changed),imports([treat_error/2])]).

:- load_files(primFunct,[if(changed),imports([errPrim/0])]).

%%::R 05-05-2004
:- load_files(pVal,[if(changed),imports([atomToPVal/3,atomToString/3,exprToTerm/2,dValProlog/2])]). % rafa 09/08/01
%%::E

%%::B
:- load_files(compil,[if(changed),imports([chainToyToProlog/2])]).
%%::E

/*
    This module contains the code for primitives. This functions haves a
direct tranlation into Prolog. Cin and Cout are the stores of disequality 
constraints and must be placed as in the following examples. Before the Prolog
operation the hnf predicate must be called for each one argument.


Types for aritmethic functions are defined in a quite ad-hoc way here
in order to allow (a very limited) overloading of arithmetic operations.
The idea is the following: we represent the types 'int' and 'real'
by the terms 'num(int)' and 'num(real)', and we use 'num(A)' for
achieving overloading, when desired. 

Nota: Los tipos de las primitivas se toman de aqui (no del standard) para 
poder forzar el tipo de algunas funciones como / o sqrt y siempre devuelvan 
real (num(float))

P.e. el + respeta la declaracion + :: num(A) -> num(A) -> num(A), lo que quiere
 decir que si los dos argumentos son int el resultado es int y si alguno de los
dos es float el resultado es float.
En / tenemos / :: num(A) -> num(

*/

/***************     CODE PRIMITIVE FUNCTIONS     ***************/


% Las funciones de aridad 1 tienen el siguiente modo de uso:
% funcion(+X,-H,+Cin,-Cout) donde X es al argumento al que se aplica la funcion,
% H es el resultado de aplicar la funcion a X, y Cin y Cout son los almacenes
% de restricciones.
% Las funciones de aridad 2 tienen el siguiente modo de uso:
% funcion(+X,+Y,-H,+Cin,-Cout) donde X e Y son los argumentos a los que se 
% aplica la funcion, H es el resultado de aplicar la funcion a X e Y, y Cin y
% Cout son los almacenes de restricciones.
% Las funciones de aridad 3 tienen el siguiente modo de uso:
% funcion(+X,+Y,+Z,-H,+Cin,-Cout) donde X, Y y Z son los argumentos a los que se 
% aplica la funcion, H es el resultado de aplicar la funcion a X, Y y Z, y Cin y
% Cout son los almacenes de restricciones.

'$if_then_else'(B, E1, E2, H, Cin, Cout):-
        hnf(B, HB, Cin, Cout1),
        '$if_then_else_1'(HB, E1, E2, H, Cout1, Cout).

'$if_then_else_1'(B, E1, _E2, H, Cin, Cout):-
        unifyHnfs(B, true, Cin, Cout1),
        hnf(E1, H, Cout1, Cout).

'$if_then_else_1'(B, _E1, E2, H, Cin, Cout):-
        unifyHnfs(B, false, Cin, Cout1),
        hnf(E2, H, Cout1, Cout).


'$if_then'(B, E, H, Cin, Cout):-
        hnf(B, true, Cin, Cout1),
        hnf(E, H, Cout1, Cout).


% '$flip'(F, A1, A2, H, Cin, Cout):-
%         '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).
% Este codigo se ha llevado a basic.pl porque aqui hacia que se necesitara
% importar el $$apply de basic y eso genera efectos indeseables al activar y  
% desactivar /cflpr cuando estamos en la version con restricciones sobre reales

%%::B
'$evalfd'(CL, PL, H, Cin, Cout):-
      toyListToIntPrologList(PL,PrologList),
      chainToyToProlog(CL,PrologString),
      name(Predicate, PrologString),
    FDGoal =.. [Predicate,PrologList,PrologH],
      call(plgenerated:FDGoal),
      intPrologListToToyList(PrologH,H),
      Cin=Cout.

intPrologListToToyList([],[]) :-
    !.
intPrologListToToyList([AI|Bs],A:B) :-
    !,
      write(AI),
      A is float(AI),
    intPrologListToToyList(Bs,B).       

toyListToIntPrologList([],[]) :-
    !.
toyListToIntPrologList(A:B, [AI|Bs]) :-
    !,
      write(A),
      AI is integer(A),
    toyListToIntPrologList(B,Bs).       

%%::E 

% Funciones unarias para enteros y reales.

'$uminus'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is -HX;errPrim).


'$abs'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is abs(HX);errPrim).


% Funciones reales unarias. 

'$sqrt'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is sqrt(HX);errPrim).

'$ln'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is log(HX);errPrim).

'$exp'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is exp(HX);errPrim).


'$sin'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is sin(HX);errPrim).


'$cos'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is cos(HX);errPrim).


'$tan'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is tan(HX);errPrim).


'$cot'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is cot(HX);errPrim).

'$asin'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is asin(HX);errPrim).


'$acos'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is acos(HX);errPrim).


'$atan'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is atan(HX);errPrim).


'$acot'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is acot(HX);errPrim).

'$sinh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is sinh(HX);errPrim).


'$cosh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is cosh(HX);errPrim).


'$tanh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is tanh(HX);errPrim).


'$coth'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is coth(HX);errPrim).

'$asinh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is asinh(HX);errPrim).


'$acosh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is acosh(HX);errPrim).


'$atanh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is atanh(HX);errPrim).


'$acoth'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is acoth(HX);errPrim).


% operadores y funciones aritmeticos binarias para enteros y reales.

$+(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is HX + HY;errPrim).


$-(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is HX - HY;errPrim).


$*(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is HX * HY;errPrim).


'$min'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is min(HX,HY);errPrim).


'$max'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is max(HX,HY);errPrim).


% funciones reales binarias

$/(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is HX / HY;errPrim).

'$**'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is exp(HX,HY);errPrim).

'$log'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is log(HX,HY);errPrim).

% potencia con exponente natural

$^(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY), HY >= 0 -> H is exp(HX,HY);errPrim).
        
    % HY >= 0 En otro caso, se podria sacar mensaje, e incluso abortar
       


'$div'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is float(HX // HY);errPrim).


'$mod'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is float(HX mod HY);errPrim).

'$gcd'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> H is float(gcd(HX,HY));errPrim).

'$round'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is round(HX);errPrim).

'$trunc'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is float(integer(HX));errPrim).

'$floor'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is floor(HX);errPrim).


'$ceiling'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H is ceiling(HX);errPrim).



%Conversion de enteros a reales

'$toReal'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout),
    (number(HX) -> H=HX;errPrim).



$<(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> (HX<HY,H=true;HX>=HY,H=false);errPrim).


$>(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> (HX>HY,H=true;HX=<HY,H=false);errPrim).


$<=(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> (HX=<HY,H=true;HX>HY,H=false);errPrim).



$>=(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout),
    (number(HX),number(HY) -> (HX>=HY,H=true;HX<HY,H=false);errPrim).



% 10/07/00 mercedes (se necesitan para la libreria de tcltk y son utiles para
% muchas otras cosas)
'$ord'(C,H,Cin,Cout):-
    hnf(C,'$char'(H),Cin,Cout).
    
'$chr'(N,H,Cin,Cout):-
    hnf(N,HN1,Cin,Cout1),
    HN is integer(HN1),
    hnf(H,'$char'(HN),Cin,Cout).
    



/*****************************   E/S    *************************************/
% 26/04/00 mercedes

% operaciones basicas

'$putChar'(A,'$io'(unit),Cin,Cout):-
    hnf(A,'$char'(HA),Cin,Cout),
    %unifyHnfs(A,'$char'(HA),Cin,Cout),
    put(HA),
    flush_output.
    

'$done'('$io'(unit),Cin,Cin).



'$getChar'('$io'('$char'(C)),Cin,Cin):- get0(C).


'$return'(V,'$io'(V),Cin,Cin).


% secuencializadores

$>>(A,B,H,Cin,Cout):-
    hnf(A,HA,Cin,Cout1),
    hnf(B,H,Cout1,Cout).
    
    
$>>=(A,B,H,Cin,Cout):-
    hnf(A,'$io'(L),Cin,Cout1),
    '$aplica'(B,L,H,Cout1,Cout).
    
'$aplica'(A,B,H,Cin,Cout):- 
    B\==unit,!,
    A=..[F|Args],
    %Args=[Args1],
    append(Args,[B],NArgs),
    A1=..[F|NArgs],
    introduceSusp(A1,H1,execution),
    hnf(H1,H,Cin,Cout).
    
'$aplica'(A,B,H,Cin,Cout):- hnf(A,H,Cin,Cout).


% operaciones adicionales

'$putStr'(Cs,H,Cin,Cout):- 
    hnf(Cs,HCs,Cin,Cout1),
%   '$trans'(HCs1,[],HCs),
    '$putStr_1'(HCs,H,Cout1,Cout).
    
%'$trans'([],X,X):-!.
%'$trans'('$char'(A):R,I,O):- 
%   append(I,[A],I1),
%   '$trans'(R,I1,O).


'$putStr_1'([],'$io'(unit),Cin,Cin).

'$putStr_1'(C:Cs,H,Cin,Cout):-
    introduceSusp(putChar(C),H1,execution),
    introduceSusp(putStr(Cs),H2,execution),
    $>>(H1,H2,H,Cin,Cout).
    

%'$putStr_1'([C|Cs],H,Cin,Cout):-
%   '$putChar'(C,H1,Cin,Cout1),
%   '$putStr'(Cs,H2,Cout1,Cout2),
%   $>>(H1,H2,H,Cout2,Cout).
    
    
    
    
'$putStrLn'(Cs,H,Cin,Cout):-
    introduceSusp(putStr(Cs),H1,execution),
    introduceSusp(putChar('$char'(10)),H2,execution),  % 10 = '\n'
    $>>=(H1,H2,H,Cin,Cout).

    
%'$putStrLn'(Cs,H,Cin,Cout):-
%   '$putStr'(Cs,H1,Cin,Cout1),
%   '$putChar'('$char'(10),H2,Cout1,Cout2),   % 10 = '\n'
%   $>>=(H1,H2,H,Cout2,Cout).   
    
    
'$getLine'(H,Cin,Cout):-
    introduceSusp(getChar,H1,execution),
    %introduceSusp(cont1,H2,execution),  
    $>>=(H1,cont1,H,Cin,Cout).

'$cont1'(C,'$io'([]),Cin,Cin):- C=='$char'(10),!.  % 10 = '\n'

'$cont1'(C,H,Cin,Cout):-
    introduceSusp(getLine,H1,execution),
    %introduceSusp(cont2(C),H2,execution),  
    $>>=(H1,cont2(C),H,Cin,Cout).

'$cont2'(C,Cs,'$io'(':'(C,Cs)),Cin,Cin).


% operaciones de ficheros

'$writeFile'(NF,Str,H,Cin,Cout):-
    nf(NF,Name_File1,Cin,Cout1),!,
    '$trans'(Name_File1,[],Name_File),
    name(Name,Name_File),
    '$control_open'(Name,Cout1,Cout2),
    open(Name,write,FD),
    '$add_control'(Name,write,FD,Cout2,Cout3),
    hnf(Str,HStr,Cout3,Cout4),!,
    '$write_in_file'(HStr,FD,H,Cout4,Cout).
    
'$trans'([],X,X):-!.
'$trans'('$char'(A):R,I,O):- 
    append(I,[A],I1),
    '$trans'(R,I1,O).


    
'$write_in_file'([],FD,'$io'(unit),Cin,Cout):- close(FD),'$remove_control'(FD,Cin,Cout).

'$write_in_file'(':'(C,Cs),FD,H,Cin,Cout):-
    hnf(C,'$char'(HC),Cin,Cout1),!,
    put(FD,HC),
    hnf(Cs,HCs,Cout1,Cout2),
    '$write_in_file'(HCs,FD,H,Cout2,Cout).
    
'$control_open'(Name,Cin,Cin):- file(Name,_,_),!,treat_error(36,Name),fail.
'$control_open'(Name,Cin,Cin).

'$add_control'(Name,Mode,Handle,Cin,Cin):- assertfile(Name,Mode,Handle).
    
'$remove_control'(Handle,Cin,Cin):- retractfile(N,M,Handle).


'$readFile'(NF,'$io'(readFileContents(FD)),Cin,Cout):-
    nf(NF,Str1,Cin,Cout1),!,
    '$trans'(Str1,[],Str),
    name(Name,Str),
    '$control_open'(Name,Cout1,Cout2),
    open(Name,read,FD),
    '$add_control'(Name,read,FD,Cout2,Cout).


'$readFileContents'(FD,L,Cin,Cout):-
    get0(FD,C),
    (
     C== -1,!,
     L=[], 
     close(FD),
     '$remove_control'(FD,Cin,Cout)
    ;
     '$readFileContents'(FD,L1,Cin,Cout),
     L=':'('$char'(C),L1)
    ).


/*****************************************************************************/

%::B
% Depu 10/10/00 mercedes
% 09/08/01 rafa cambiado el nombre a dVal
'$dValToString'(A,C,Cin,Cin):-atomToString(varToString,A,C).

% 22-09-03 Ahora dVal funciona de diferente manera seg�n si estamos usando el dep. topdown o DDT
% 17-12-03 Vuelve a funcionar igual en ambos casos
'$dVal'(A,C,Cin,Cin):- %(ddtFlag,
                    !,
                    dValProlog(A,C).
                    %;
                    %atomToPVal(varToString,A,C)
                    %).

%-----------------------------------------------------------------------------------------------------------
% '$getConstraintStore'(+[A],-Constraint,+Cin,-COut)
% returns in Constraint the constrain Store as a Toy value of type "constraint"
% the list [A] contains pairs of the form (NameVar, PrologVar) with the names 
% of the variables which must be kept 
'$getConstraintStore'(ListVars,constraint(List),Cin,Cin) :-
            % unify the format
          formatConstraint(Cin,[],Cin2),
            % simplify 
          simplifyStore(ListVars,Cin2,Cin3),
            % delete redundant constraints
              eliminateRepetitions(Cin3,Cin4),
        % convert Cin in a Toy list of values of type atomicConstraint
          generateAtomicConstraints(Cin4,List).


% formatConstraint
formatConstraint([],Ac,Ac).
formatConstraint([A|R],Ac,Res) :-
  addConstraints(A,Ac,Ac2),
  formatConstraint(R,Ac2,Res).

addConstraints(A:[],Ac,Ac).
addConstraints(A:[B|C],Ac,[neq(A,B)|R1]) :-
   !,
   addConstraints(A:C,Ac,R1).
addConstraints(A,Ac,[A|Ac]) :-
   !.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
simplifyStore(L,A,B) :-
   simmetry(A,B1),
   eliminateRepetitions(B1,B2),
   relevantVariables(L,B2,B).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simplify by simmetry
simmetry([],[]).
simmetry([neq(A,B)|C],R):-
    member(neq(B,A),C),
    !,
    simmetry(C,R).
simmetry([A|B], [A|R]) :-
    simmetry(B,R).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eliminateRepetitions([],[]).
eliminateRepetitions([X|Xs],Ys) :- 
    member(X,Xs),
    !,
    eliminateRepetitions(Xs,Ys).
eliminateRepetitions([X|Xs],[X|Ys]) :- 
    !,
    eliminateRepetitions(Xs,Ys).
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
relevantVariables(L,A,B) :-
   B=A,
   !.


% generateAtomicConstraints(+L,-C)
% Given L = [t1,...,tn] stores in C the list
% ':'(atomicConstraint "seq" [Var, t1'] ->false,':'(...,':'(atomicConstraint "seq" [Var tn'] -> false,[])...)
% where t1',...,tn' are the pVal representations of t1
generateAtomicConstraints([],[]).
generateAtomicConstraints([neq(V,Term)|RestTerms],':'(AC,RC)):-
 !,
  atomToPVal(varToString,V,Var),
  atomToPVal(varToString,Term,PValTerm),
  AC=atomicConstraint(:('$char'(115), :('$char'(101), :('$char'(113), []))), % seq
                                          :(Var,:(PValTerm, [])),  % [Var,PValTerm]
                       pValApp(:('$char'(102), :('$char'(97), :('$char'(108), :('$char'(115), :('$char'(101), []))))), []) %false
                    ),
 generateAtomicConstraints(RestTerms,RC).

generateAtomicConstraints([tot(V)|RestTerms],':'(AC,RC)):-
 !,
 atomToPVal(varToString,V,Var),
 AC=atomicConstraint(:('$char'(116), :('$char'(111), :('$char'(116), []))), % tot
                                          :(Var, []),  % [Var]
                       pValApp(:('$char'(116), :('$char'(114), :('$char'(117),  :('$char'(101), [])))), []) %true
                    ),
 generateAtomicConstraints(RestTerms,RC).


%-----------------------------------------------------------------------------------------------------------

% Fin Depu

%::E

% Depu 16/11/00 mercedes
'$selectWhereVariableXi'(Name,IFloat,NFloat,X,Xi,Cin,Cout) :-
    % El num. de arg. (IFloat) y el total de argumentos (NFloat) nos
    % llegan como float con decimal .0. Los convertimos a enteros para
    % que funcionen functor, args,...
    I is integer(IFloat),
    N is integer(NFloat),
    functor(Pattern,Name,N),
    % transformar el patron si es una tupla
    transformTup(Pattern,Pattern1),
        hnf(X,Pattern1,Cin,Cout1),  
     arg(I,Pattern,Result), 
     hnf(Result,Xi,Cout1,Cout).
    

% transforma los patrones de tipo tupla
% si el patron no es una tupla no lo cambia 
transformTup(Pattern,PatternOut) :-
    Pattern =.. ['$$tup'|Args],
    !,
    argsToTup(Args,ArgsOut),
    PatternOut =.. ['$$tup'|[ArgsOut]].

transformTup(Pattern,Pattern) :- 
    !.
    

argsToTup([Arg],Arg) :-
    !.

argsToTup([HArg|RArgs],(HArg,TRArgs)) :-
    !,
    argsToTup(RArgs,TRArgs).

    
% Fin Depu



/**********************  FALLO FINITO Y CORTE ********************************/
% pacol 17-03-05
'$fails'(X,H,Cin,Cin):-
     \+ hnf(X,_,Cin,Cout) -> H=true ; H=false.

'$once'(X,H,Cin,Cout):-
     hnf(X,H,Cin,Cout),!.


% Este collect esta mal
%'$collect'(X,L2,Cin,Cin):-
%    findall(H,nf(X,H,Cin,_),L1),    % jaime 23-1-2004
%        convert(L1,L2).

%ppaco 28-11-07
%Este codigo de collect supone que cada vez que se invoca a 'collect e'
%en el programa P.toy original, en el codigo Prolog generado (P.pl)
%se han recolectado y hecho expl�citas 
%las variables de suspensiones de e, en la forma
%[X1,...,Xn]^e,
%de modo que la invocacion a bagof
%en que se basa collect las ponga como prefijo existencial.
%Ver el programa 'bancopruebas/ej_collect1.toy' y el codigo generado y 
%luego retocado a mano que se encuentra en mi_ej_collect1.pl

'$collect'(X,L2,Cin,Cin):-
    build_collect_goal(X,H,Cin,G),
    bagof(H,G,L1),
        convert(L1,L2).

build_collect_goal([]^E,H,Cin,nf(E,H,Cin,_)).
build_collect_goal([X|Y]^E,H,Cin,X^G):- 
    build_collect_goal(Y^E,H,Cin,G).
%ppaco 28-11-07 end

%% este seguramente estar� tambi�n mal %%ppaco 28-11-07
'$collectN'(N,X,L2,Cin,Cout):-
        hnf(N, HN, Cin, Cout),
    findN(HN,X,nf(X,H,Cin,_),L1),   % jaime 23-1-2004
        convert(L1,L2).



% convierte lista prolog a lista toy (constructor '.' a constructor ':')
convert([],[]).
convert([X|Xs],:(X,Xs1)):- convert(Xs,Xs1).


% pereza??.... no es trivial -> mirar eficiencia
findN(N,X,G,L):-
        (
          N==0,!,L=[]
        ;
          retractall(res(_)), retractall(cont(_)), 
          assert(cont(0)), !,       
          (findNAux(N,X,G),!; true),
          findall(Y,res(Y),L)
        ).


findNAux(N,X,G):-
        call(G), cont(C),
        C1 is C+1, (C1>N,!; retractall(cont(_)), assert(cont(C1)), assert(res(X)), fail).

/**********************  FIN FALLO FINITO Y CORTE ****************************/
/**********************  RUN TIME ********************************/
% pacol 19-09-2008
'$rt'(X,H,Cin,Cout):-
     hnf(X,H,Cin,Cout).
/**********************  FIN RUN TIME ********************************/
