%-----------------------------------------------------------------------------%
% sailing.pl
%-----------------------------------------------------------------------------%
/*
- Author: Mercedes

- Description: Este modulo contiene el algoritmo para navegar el arbol de
depuracion.

- Modules which import it: 
  
- Modules imported into it:

- Modified:
	26/10/99 mercedes (modules).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(sailing,[navegate/1]).

:- load_files(tools,[if(changed),imports([concatLsts/2,deleteElement/3,
					  insertLst/3,member/2])]).

:- load_files(goals,[if(changed),imports([eliminateSweepings/1])]).

navegate(Tree) :-
	navegate(Tree,Result),
	(
	 Result=weAreOkDaddy,
	 nl,
	 write('Any wrong rule has been found'),
	 nl
	;
	 true
	),
	!.
	

navegate(Tree,Result) :-
	!,
	whoAreMyChildren(Tree,WeAre),
	navegatingChildren(WeAre,[],_,[],_,[],_,[],_,Result).





% Surprise puede ser
% - weAreOkDaddy
% - weAreSickDaddy
% - weDontKnowDaddy

navegatingChildren([],I,I,NotI,NotI,MayBeI,MayBeI,[],[],weAreOkDaddy):-
	!.

navegatingChildren([],I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,[X|Xs],[X|Xs],Surprise):-
	!,
	reexamineMayBeChildren([X|Xs],I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,Surprise).
	

navegatingChildren(X:Xs,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,
                    ListMayBeChildrenI,ListMayBeChildrenOut,HowAreYou):-
	navegating(X,I,IOut1,NotI,NotIOut1,MayBeI,MayBeIOut1,TellMeBrother),
	(
	 % si esta bien seguimos con los hermanos
	 TellMeBrother=iAmOkBrother,
	 navegatingChildren(Xs,IOut1,IOut,NotIOut1,NotIOut,MayBeIOut1,MayBeIOut,
                    ListMayBeChildrenI,ListMayBeChildrenOut,HowAreYou)
        ;
         % si esta mal, ya hemos acabado
         TellMeBrother=iAmSickBrother,
         HowAreYou=weAreSickDaddy,
         IOut=IOut1,
	 NotIOut = NotIOut1,
	 MayBeIOut = MayBeIOut1
	;       
	 % si es incierto seguimos con los hermanos
	 TellMeBrother=iDontKnowBrother,
	 navegatingChildren(Xs,IOut1,IOut,NotIOut1,NotIOut,MayBeIOut1,MayBeIOut,
                    [X|ListMayBeChildrenI],ListMayBeChildrenOut,HowAreYou)  
        ),
        !.
         
         
         
         
% devuelve:
%	- iAmSickBrother, 
%	- iAmOkBrother,   
%	- iDontKnowBrother      
navegating(X,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,TellMe):-
	rootArrow(X,Arrow),
	askOracle(Arrow,I,IOut1,NotI,NotIOut1,MayBeI,MayBeIOut1,TellMe),
	(
	 TellMe = iAmSickBrother,
	 % vamos a ver si es el el nodo critico
	 whoAreMyChildren(X,WeAre),
	 % es erroneo, preguntamos por los hijos
         navegatingChildren(WeAre,IOut1,IOut,NotIOut1,NotIOut,MayBeIOut1,MayBeIOut,
                            [],_ListMayBeChildren,TellMeChildren),

	 ( 
	  % si estan sanos ya esta
	  TellMeChildren = weAreOkDaddy,
	  showBuggyNode(X)
	 ;
	  TellMeChildren = weDontKnowDaddy,
	  nl,
	  write('Any wrong rule has been found'),
	  nl
	 ;
	  true
	 )
	;
	 IOut=IOut1, 
	 NotIOut = NotIOut1,
	 MayBeIOut = MayBeIOut1
	),
	!.
  	 

askOracle(Arrow,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,TellMeBrother):-
	deduceArrow(Arrow,I,NotI,MayBeI,Possible,TellMeBrother),
	(
	 Possible=yes,
	 IOut      = I,
	 NotIOut   = NotI,
	 MayBeIOut = MayBeI
	;
	 askUser(Arrow,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,TellMeBrother)
	),
	!.
	
	
deduceArrow(Arrow,I,NotI,MayBeI,Possible,TellMeBrother):-
	(
	 member(Arrow,I),
	 TellMeBrother = iAmOkBrother,
	 Possible=yes
	;
	 member(Arrow,NotI),
	 TellMeBrother = iAmSickBrother,
	 Possible=yes
	;
	 member(Arrow,MayBeI),
	 TellMeBrother = iDontKnowBrother,
	 Possible=yes
	;
	 Possible=no
	),
	!.

askUser(Arrow,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,TellMeBrother):-	 
	 nl,
	 write('Is ('),
	 name(NameArrow,Arrow),
	 write(NameArrow),
	 write(') valid? ([y]es / [n]o / [m]aybe) '),
	 getOracleAnswer(Answer),
	 (
	  (Answer==121; Answer==98),
	  TellMeBrother = iAmOkBrother,
	  IOut = [Arrow|I],
	  NotIOut   = NotI,
	  MayBeIOut = MayBeI
	 ;
	  (Answer==110; Answer==78),
	  TellMeBrother= iAmSickBrother,
	  IOut = I,
	  NotIOut = [Arrow|NotI],
	  MayBeIOut = MayBeI
	 ;
	  (Answer==109; Answer==77),
	  TellMeBrother = iDontKnowBrother,
	  IOut = I,
	  NotIOut   = NotI,
	  MayBeIOut = [Arrow|MayBeI]
	 ),
	 !.


getOracleAnswer(Answer) :-
	get(Answer1),
	eliminateSweepings(Answer1),
	(
	 (Answer1==121; Answer1==98),
	 Answer=Answer1
	;
	 (Answer1==110; Answer1==78),
	 Answer=Answer1
	;
	 (Answer1==109; Answer1==77),
	 Answer=Answer1
	;
	 nl,
	 write('Please, answer y, n or m: '),
	 getOracleAnswer(Answer)
	),
	!.
	 

showBuggyNode(X):-
	!,
	getRuleData(X,Name,Number,Instance),
	name(NameName,Name), 
	name(NameNumber,Number),
	name(NameInstance,Instance),
	nl,
	write('Rule number '),
	write(NameNumber),
	write(' of the function '), 
	write(NameName),
	write(' is wrong.'),
	nl,
	write('Wrong instance: '),
	write(NameInstance),
	nl.
	


% Surprise puede ser
% - weAreOkDaddy
% - weAreSickDaddy
% - weDontKnowDaddy
                     
reexamineMayBeChildren(L,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,Surprise):-
	!,
	nl,
        write('Considering the following facts: '),
        nl,
        writeArrowsList(L,0,NumArrows),
        nl,
        write('Are all of them valid? ([y]es / [n]ot / [m]aybe) '),
        getOracleAnswer(Answer),
        (
	 (Answer==121; Answer==98),
	 !,
	 Surprise = weAreOkDaddy,
	 deleteMaybes(L,MayBeI,MayBeIOut),
	 insertOks(L,I,IOut),
	 NotIOut=NotI
	;
	 (Answer==110; Answer==78),
	 !,
	 % Navegar el hijo; la respuesta que devuelva sera tb la del padre
	
navegateChild(NumArrows,L,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,Surprise)
	; 
  	 (Answer==109; Answer==77),
	 !,
	 Surprise = weDontKnowDaddy,
	 IOut = I,
	 NotIOut = NotI,
	 MayBeIOut = MayBeI
	).

deleteMaybes([],List,List):-
	!.
	
deleteMaybes([X|Xs],ListIn,ListOut):-
	!,
	deleteElement(X,ListIn,ListOut1),
	deleteMaybes(Xs,ListOut1,ListOut).
	
insertOks([],List,List):-
	!.

insertOks([X|Xs],ListIn,ListOut):-
	!,
	insertLst(X,ListIn,ListOut1),
	insertOks(Xs,ListOut1,ListOut).

% navega un arbol cuya raiz es erronea
navegateChild(NumArrows,L,I,IOut,NotI,NotIOut,MayBeI,MayBeIOut,Surprise):-	
	 !,
	 write('Enter the number of a non-valid fact in the list, followed by a fullstop: '),
	 getOracleNumber(NumArrows,Number),
	 getNthElement(L,Number,Child),
	 rootArrow(Child,Arrow),
	 deleteElement(Arrow,MayBeI,MayBeIOut1),
	 navegating(Child,I,IOut,[Arrow|NotI],NotIOut,MayBeIOut1,MayBeIOut,TellMeChild),
	 (
	  TellMeChild=iAmOkBrother, Surprise=weAreOkDaddy
	 ;
  	  TellMeChild=iAmSickBrother, Surprise=weAreSickDaddy
	 ;
 	  TellMeChild=iDontKnowBrother, Surprise=weDontKnowDaddy
	 ).
	 
	 
	 

getOracleNumber(NumArrows,Choice) :-
	read(Choice1),
	(
	 number(Choice1), 
	 Choice1>0,
	 Choice1=<NumArrows,
	 Choice=Choice1
	;
	 nl,
	 write('Please, write a valid arrow number: '),
	 getOracleNumber(NumArrows,Choice)
	),
	!.
	 
writeArrowsList([],Num,Num) :-
 	!.

writeArrowsList([T|Ts],N,NOut) :-
	!,
	N2 is N+1,
	write(N2),
	write(': '),
	rootArrow(T,Arrow),
	name(NameArrow,Arrow),
	write(NameArrow),
 	nl,
 	writeArrowsList(Ts,N2,NOut).
        
       
       
getNthElement([X|Xs],1,X):-
	!.
       
getNthElement([X|Xs],N,Element):-       
	!,
	N2 is N-1,
	getNthElement(Xs,N2,Element).



toyStringToPrologString([],[]):-       
       !.
 

toyStringToPrologString(':'('$char'(X), Xs2),[X|Xs]):-       
       !,
       toyStringToPrologString(Xs2,Xs).
       
       
       
       
/*****************************************************************************/
/*	Predicados auxiliares para extraer las componentes del arbol	     */
/*****************************************************************************/


whoAreMyChildren('$cTreeNode'(_Name,_Args,_Result,_Body,_Conds,_NumRule,WeAre),
		 WeAre).

rootArrow('$cTreeNode'(Name,Args,Result,_Body,_Conds,_NumRule,_WeAre), Arrow):-
	toyStringToPrologString(Name,PrologName),
	toyStringToPrologString(Args,PrologArgs),
	toyExprToPrologString(Result,PrologResult),
	!,
	concatLsts([PrologName," ",PrologArgs," -> ",PrologResult], Arrow).


getRuleData('$cTreeNode'(Name,Args,Result,Body,Conds,NumRule,_WeAre),
	    PrologName,PrologNumRule,Instance):-
	!,
	toyStringToPrologString(Name,PrologName),
	toyStringToPrologString(Args,PrologArgs),
	toyStringToPrologString(Conds,PrologConds),
	toyStringToPrologString(NumRule,PrologNumRule),
	toyExprToPrologString(Body,PrologBody),
	( 
	 Conds == [],
	 concatLsts([PrologName," ",PrologArgs," -> ", PrologBody],Instance)
	;
  	 concatLsts([PrologName," ",PrologArgs," -> ", PrologBody," <== ", PrologConds], Instance)
  	).


% Si la expresion es la lista vacia tenemos que escribir "[]"
% en otro caso es una lista de char
toyExprToPrologString(Expr,PrologString):-
	(
	 Expr=[],
	 PrologString="[]"
	;
	 toyStringToPrologString(Expr,PrologString)
	),
	!.


       










