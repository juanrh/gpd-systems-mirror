%-----------------------------------------------------------------------------%
% process.pl
%-----------------------------------------------------------------------------%
/*
- Author: Jaime
- Description: Es el modulo principal de la generacion de codigo. Se comprueba 
  que existe el archivo File.toy. Luego se crea un nuevo archivo pegando:
  File.toy + basic.toy al que llama: File.tmp.toy.
- Modules which import it: initToy.
- Imported modules:
	> compil (con 'compil/2'): con esta llamada se realiza el analisis
	  lexico y sintactico que da como resultado un fichero: File.tmp.out
	  usando como fichero intermedio File.tmp.tmp).
	> transfun: con 'processFunction' (si el analisis anterior no ha 
	  producido error, se procede a generar codigo en el fichero File.pl y 
	  se borra File.tmp.toy y File.tmp.tmp. Esta generacion de codigo se 
	  hace con processOut y aqui se llama a processFunction), con 
	  'extractDestinationType' y con 'traslateCheckRules'.
	> inferrer: con 'infTypes' (para procesar el archivo de entrada,
	  se hace la inferencia de tipos de las funciones) y con 
	  'translateType'.
	> tools (con 'append', 'reverse', 'openFile', 'closeFile', 'existFile',
	  'extractNameExtension' y 'concatLsts').
	> dyn.
	> writing (con 'writeAtom/3').
	> outgenerated (con 'cdata','infix/4','ftype','fun','depends' y 
	  'primitive', 'annotate').
	> primitives.
	> osystem (with 'makeTemp' and 'deleteTemps').
      > transtrees.pl  : Yoli YGR 5/12/05 (para detectar si las funciones son deterministas y transformar el �rbol.)
 
		  
	  
- Modified: 30/09/99 mercedes (Se han comentado los predicados)
	    		  26/10/99 mercedes (modularizacion).

- Modified 01/10/2005 Yolanda Garc�a Ruiz 
                Se modifica el predicado writeClBodyName para que cuando 
                se encuentre algo de la forma: [grupo(Uno,Dos)], 
                escriba:
                   (Uno,
               !    % Corte din�mico
                   ;
                     Dos
                    )

*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(process,[do/2,deletePredsComp/0,consult/2,check/2,generateCode/2]).


:- load_files(transtrees, [if(changed),imports([checkCut/6])]).    % YGR 5/12/05 
:- load_files(compil,[if(changed),imports([compil/3])]).
:- load_files(codfun,[if(changed),imports([generateFinalCode/3])]).  % YGR 5/12/05 


:- load_files(transfun,[if(changed),imports([processFunction/2,
		processFunctionCut/2,    
	   % YGR 05/12/05 : he a�adido la funci�n processFunctionCut/2
	      extractDestinationType/2,traslateCheckRules/3])]).

:- load_files(inferrer,[if(changed),imports([infTypes/0,translateType/2])]).

:- load_files(tools,[if(changed),imports([append/3,reverse/2,openFile/4,
 	      closeFile/1,existFile/2,extractNameExtension/3,
 	      concatLsts/2
% YGR 10/01/2006 he a�adido member
              ,member/2

%F010204
              ,complete_root_filename/2
              ])]).

:- load_files(dyn,[if(changed)]).

:- load_files(writing,[if(changed),imports([writeAtom/3])]).

:- load_files(newout,[if(changed),imports([cdata/4,infix/4,ftype/4,fun/4,
 	      depends/2,primitive/3
      % Yoli YGR inicio 25/01/2006
			, annotate/1 
      % Yoli YGR fin 25/01/2006

			])]).

/* Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.
*/

% 16/05/00 mercedes. Para cuando usamos la libreria de e/s de ficheros.
:- load_files(primFunct,[if(changed)]).

:- (
    clpr_active,!,load_files(primitivCodClpr,[if(changed)])
   ;
    load_files(primitivCod,[if(changed)])
   ).

:- (
    io_active,!,load_files(primitivCodIo,[if(changed)])
   ;
    1==1
   ).

:- (
    iographic_active,!,load_files(primitivCodGra,[if(changed)])
   ;
    1==1
   ).

:- load_files(osystem,[if(changed),imports([makeTemp/2,deleteTemps/1])]).

:- use_module(library(system)).  % file_exists, shell, system, findall


/***********************************************************************
	COMPILADOR, MODULO PPAL DE LA GENERACION DE CODIGO

Llamada: do(+Fich,-Error).
	+ Fich: Fichero de entrada
	- Error: Indica si se ha producido algun error en la primera fase	

El proceso se realiza en dos fases:
	* Analisis lexico y sintactico del fichero de entrada Fich,
	  que da como resultado un fichero <Fich>.out
	* Si la fase anterior no ha provocado ningun error se 
	  procede a generar codigo en el fichero <Fich>.pl


Este modulo contiene la llamada a la primera fase (usa el modulo compil.pl) y 
la segunda fase, que para las funciones utiliza los modulos: dds.pl, codfun.pl y
transfun.pl.
(Realmente este modulo solo llama a transfun.pl y este es el que se encarga de
llamar a dds.pl y a codfun.pl).

Para que funcione este modulo es necesario haber consultado previamente el
modulo toy.pl que se ocupa de la carga de todos los modulos del compilador.


**************************************************************************/
  
%----------------------------------------------------------------------------%
% do(+File,?Error) primero comprueba que existe el archivo File.toy, luego crea 
% un nuevo archivo pegando File + basic.toy al que llama File.tmp.toy, compila 
% este archivo dandole el nombre File.pl y borra File.tmp.tmp y File.tmp.toy
%----------------------------------------------------------------------------%

%080199
% Ya no se concatena el basic.toy antes de compilar
/*
do(F,Error):-
	
	extractNameExtension(F,Name,Ext),
	append(Name,Ext,NameL),
	name(NameF,NameL),
	file_exists(NameF),
	!,

	% construimos el nombre del archivo temporal donde pegaremos el fuente
	% y el basic
%	append(Name,".tmp",Temp),
	% les pegamos y obtenemos Name.tmp.toy (suma de los dos)
%	includeBasic(Name,Ext),

	%compilamos
	compil(Name,Err),		% llamada al compilador de Rafa
%	name(NTemp,Temp),

	(Err==false,processOut(NameL,Error)	% si no da error continuamos
	;				% generando codigo
	nl,nl,nl,
	write('THERE IS SOME SYNTAX ERROR. NO CODE HAS BEEN GENERATED!!!! '),
		nl,Error=true),

	deleteTemps(Name).




do(F,true):-nl,write('Error: Cannot find file '),write(F),nl.

concatLsts([],[]).
concatLsts([[]|R],S):-concatLsts(R,S).
concatLsts([[C|R1]|R2],[C|S]):-concatLsts([R1|R2],S).





processOut(File,Error):-
	consult(File,".out"),
	name(Name,File),
	openFile(Name,".pl",write,Handle),
	processIn(Handle,Error),

	% Cuando acabamos de compilar limpiamos la base de datos de las
	% clausulas que hemos metido del .out (data,cdata,...), para que en
	% posteriores compilaciones (posiblemete de otros programas), las 
	% funciones, datos, etc, de este programa no afecten.

	deletePredsComp,
	closeFile(Handle).

*/




do(F,Error):-

	extractNameExtension(F,Name,Ext),
	append(Name,Ext,NameL),
	name(NameF,NameL),
	file_exists(NameF),
	!,

	% construimos el nombre del archivo temporal donde pegaremos el fuente
	% y el basic
	append(Name,".tmp",Temp),
	% les pegamos y obtenemos Name.tmp.toy (suma de los dos)
	makeTemp(Name,Ext),
	%includeBasic(Name,Ext),
	%compilamos
	compil(Name,Temp,Err),		% llamada al compilador de Rafa
	name(NTemp,Temp),
	

	(Err==false,processOut(NTemp,Name,Error) % si no da error continuamos
	;			  	        % generando codigo
	nl,nl,nl,
	write('THERE IS SOME SYNTAX ERROR. NO CODE HAS BEEN GENERATED!!!! '),
		nl,Error=true),

	deleteTemps(Name).
	



do(F,true):-nl,write('Error: Cannot find file '),write(F),nl.


 
 
 
%----------------------------------------------------------------------------%
% processOut(+Ntemp,+NameF,-Error) donde:
% +Ntemp: es el nombre del fichero temporal, i.e. Ntemp=NameF.tmp
% +NameF: es el nombre del fichero
% -Error: indica si se ha producido algun error
% processOut lo que hace es generar codigo en el fichero NameF.pl
%----------------------------------------------------------------------------%

processOut(Ntemp,NameF,Error):-
	%deletePredsComp,
	consult(Ntemp,".out"),
	%consult(gencod,".ini"),
	name(Name,NameF),
	openFile(Name,".pl",write,Handle),
	% Depu 02/11/00 mercedes
	% Se annade el NameF como parametro
	processIn(Handle,NameF, Error),
	% Fin Depu

	% Cuando acabamos de compilar limpiamos la base de datos de las
	% clausulas que hemos metido del .out (data,cdata,...), para que en
	% posteriores compilaciones (posiblemete de otros programas), las 
	% funciones, datos, etc, de este programa no afecten.

	deletePredsComp,
	closeFile(Handle),
%%B F
	% Reorganizaci�n del c�digo para dominios finitos
	% s�lo si est�n activados.
	if(cflpfd_active,arrange_fdcode(NameF),true).


%-----------------------------------------------------------------------------%
% arrange_fdcode(+NameF:string): Reorganizaci�n del c�digo para dominios finitos
% 1- Elimina las definiciones de funciones enmarcadas entre %init_fd y %end_fd
% 2- A�ade las definiciones de funciones de dominio finito al final del archivo
%    NameF que se encuentran en el archivo cflpfdfile.pl (que incluye tambi�n
%    la directiva :-use_module(library(clpfd)).
%-----------------------------------------------------------------------------%

arrange_fdcode(NameF) :-
%Open file for reading
	name(Name,NameF),
	openFile(Name,".pl",read,HandleIn),
	openFile(voidfd,".pl",write,HandleOut),
%Remove void fd function definitions
	remove_void_defs(HandleIn,HandleOut),
	closeFile(HandleIn),
%Append the clpfdfile
	append_cflpfdfile(HandleOut),
	closeFile(HandleOut),
%Delete the source file
	append(NameF,".pl",NamePL),
	name(NamePLAtom,NamePL),
	delete_file(NamePLAtom),
%Rename the voidfd file as the source file
	rename_file('voidfd.pl',NamePLAtom).

/*
*/

%-----------------------------------------------------------------------------%
% remove_void_defs(+HandleIn,+HandleOut): Elimina las definiciones de funciones 
% enmarcadas entre %init_fd y %end_fd
%-----------------------------------------------------------------------------%

remove_void_defs(HandleIn,HandleOut) :- 
        get0(HandleIn,Percent),
	get0(HandleIn,Space),  
	get0(HandleIn,I1), 
	get0(HandleIn,N),
	get0(HandleIn,I2),
	get0(HandleIn,T),
	get0(HandleIn,Underscore),
	get0(HandleIn,F),
        put(HandleOut,Percent),
        put(HandleOut,Space),
        put(HandleOut,I1),
        put(HandleOut,N),
        put(HandleOut,I2),
        put(HandleOut,T),
        put(HandleOut,Underscore),
        put(HandleOut,F),
        remove_void_defs(HandleIn,HandleOut,[Percent,Space,I1,N,I2,T,Underscore,F]).

remove_void_defs(HandleIn,HandleOut,[Percent,Space,I1,N,I2,T,Underscore,F]) :-
	(at_end_of_stream(HandleIn)
	 ;
	 (
	  get0(HandleIn,D),
          if([Percent,Space,I1,N,I2,T,Underscore,F,D]=[37,32,105,110,105,116,95,102,100],
           (skip_void_fd_functions(HandleIn),copy_items(HandleIn,HandleOut)),
           (
            put(HandleOut,D),
	      remove_void_defs(HandleIn,HandleOut,[Space,I1,N,I2,T,Underscore,F,D])))
       )
	).

%-----------------------------------------------------------------------------%
% skip_void_fd_functions(+HandleIn): Salta las definiciones de funciones 
% hasta la indicada por %end_fd (incluida)
%-----------------------------------------------------------------------------%

skip_void_fd_functions(HandleIn) :-
        get0(HandleIn,Percent),
	get0(HandleIn,Space),  
	get0(HandleIn,E), 
	get0(HandleIn,N),
	get0(HandleIn,D),
	get0(HandleIn,Underscore),
	get0(HandleIn,F),
        skip_void_fd_functions(HandleIn,[Percent,Space,E,N,D,Underscore,F]).

skip_void_fd_functions(HandleIn,[Percent,Space,E,N,D1,Underscore,F]) :-
	(at_end_of_stream(HandleIn)
	 ;
	 (
	  get0(HandleIn,D2),
          if([Percent,Space,E,N,D1,Underscore,F,D2]="% end_fd",
           (skip_line(HandleIn),skip_line(HandleIn)),
           (
%           put(D),
	      skip_void_fd_functions(HandleIn,[Space,E,N,D1,Underscore,F,D2])))
       )
	).


%-----------------------------------------------------------------------------%
% append_cflpfdfile(+HandleOut): A�ade las definiciones de funciones de dominio
% finito al final del archivo HandleOut que se encuentran en el archivo 
% cflpfdfile.pl (que incluye tambi�n la directiva :-use_module(library(clpfd)).
%-----------------------------------------------------------------------------%

append_cflpfdfile(HandleOut) :-
        complete_root_filename(cflpfdfile,File),
	openFile(File,".pl",read,HandleIn),
	copy_items(HandleIn,HandleOut),
	closeFile(HandleIn).

%-----------------------------------------------------------------------------%
% copy_items(+HandleIn,+HandleOut): Copia todos los caracteres de HandleIn en
% HandleOut
%-----------------------------------------------------------------------------%

copy_items(HandleIn,HandleOut) :-
	(at_end_of_stream(HandleIn)
	 ;
	 (get0(HandleIn,X),
	  put(HandleOut,X),
	  copy_items(HandleIn,HandleOut))
	).
%%E


	

%-----------------------------------------------------------------------------%
% consult(+Fich,+Ext): lo que hace es reconsultar Fich.Ext
%-----------------------------------------------------------------------------%

consult(F,Ext):-
	name(F,N),
	append(N,Ext,N1),
	name(NF,N1),
	%prolog_flag(redefine_warnings,Old,off),

	%reconsult(N2).
	reconsult(NF).

	%prolog_flag(redefine_warnings,Old).






/****************************************************************************/
/*	PROCESADO DEL ARCHIVO DE ENTRADA, CORAZON DE LA GENERACION DE       */
/*			CODIGO.						    */
/****************************************************************************/

%----------------------------------------------------------------------------%
% processIn(+Handle,+NameF, -Error)
% Depu 02/11/00 super-meercedotas
% annadimos el nombre de fichero como parametro
% Fin Depu
%----------------------------------------------------------------------------%

processIn(Handle,NameF,Error):-

	% hacemos la inferencia de tipos de las funciones. Esto provoca que se
	% incluyan en la BD. clausulas functiontype que corresponden al tipo 
	% inferido de las funciones. Esta informacion no se pasa como parametro
	% porque el propio inferidor necesita ir metiendo en la BD dicha 
	% informacion y ya aprovechamos para tomarla de memoria.
	infTypes,
	(
	 typeError,!,nl,nl,nl,
	 write('THERE ARE SOME TYPE ERROR. NO GENERATED CODE !!!!'),
		nl,Error=true
	;
	 generateCode(Handle,NameF),nl,write('PROCESS COMPLETE'),nl
	).



%----------------------------------------------------------------------------%
% generateCode(+Handle,+NameF)
% Depu 02/11/00 super-meercedotas
% annadimos el nombre de fichero como parametro
% Fin Depu
%----------------------------------------------------------------------------%

generateCode(Handle,NameF):-

	% Hacemos una declaracion dinamica para los predicados const y funct
	% para que nos deje insertaralos y borrarlos de la base.

	%write(Handle,':-dynamic constr/4, funct/5.'),nl(Handle),nl(Handle),

	nl,nl,
	%write('-------------------------------------------------------'),nl,nl,
	write('Generating code...'),nl,
	
	doListFunctions(LstFuns),		% Sacamos todos los nom/ar

    % YGR  05/12/05 INICIO --------------------------------------------------

    doListDepends(LstDepends),       % YGR sacamos todos los depends(F,G).
    doListAnnotates(LstAnnot),       %  
    generateTrees(LstFuns,LstTrees), % Se generan los �rboles definicionales
    checkCut(LstTrees,LstDepends,LstAnnot,LstTreesTransform, LstAnnotProg, LstNotDeter),
    writeTreesTemp(LstTrees, LstTreesTransform, LstAnnotProg, LstNotDeter),  

   % YGR 05/12/05 FIN ------------------------------------------------------

	doListConstructors(LstCons),		% de funcion y constructora 
	doListPrimitives(LstPrims),		% y primitiva
	


        % 22/10/99 mercedes
	nl(Handle),nl(Handle),
	
	
	% Eso se usa para modificar los mensajes que da Sicstus. En este caso
	% se modifican los mensajes de warning. Lo que hace es que cada mensaje
	% de warning, en vez de sacar el mensaje, no escribe nada. Esto se hace
	% para evitar que salgan los warnings cuando se ejecuta un programa 
	% despues de haber ejecutado otro, porque se quedaba con la informacion
	% de las funciones del primer programa y decia que esas funciones no se
	% podian importar.
	write(Handle,'user:portray_message(warning,_):- write(\'\').'),
	nl(Handle),nl(Handle),
	
	
	writeModule(Handle,LstFuns,LstPrims),
	nl(Handle),nl(Handle),
	
	
	% 03/11/99 mercedes
	% He declarado dinamicos el == y el /=. Esto se hace porque si no, como 
	% no hay codigo de /= ni de ==, daba error. No se pueden eliminar aunque
	% haya equal y notEqual, porque ese == y el /= no son las restricciones 
	% de igualdad y desigualdad, sino las funciones igualdad y desigualdad. 
	% Para esto no sirve el eqFun y el notEqFun, porque esto vale en momento
	% de ejecucion, pero en momento de compilacion, se necesitan el == y el 
	% /=.
	write(Handle,':- dynamic $== /5, $/= /5.'),
	nl(Handle),nl(Handle),
	
	
%F010204
        write(Handle,':- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed)]).'),
	nl(Handle),nl(Handle),
%F010204
        write(Handle,':- tools:complete_root_filename(primFunct,F),load_files(F,[if(changed)]).'),
	nl(Handle),nl(Handle) ,
	(
	 clpr_active,!,
%F010204
         write(Handle,':- tools:complete_root_filename(primitivCodClpr,F),load_files(F,[if(changed)]).')
	;
%F010204
        write(Handle,':- tools:complete_root_filename(primitivCod,F),load_files(F,[if(changed)]).')),
	nl(Handle),nl(Handle),
	(
	 io_active,!,
%F010204
         write(Handle,':- tools:complete_root_filename(primitivCodIo,F),load_files(F,[if(changed)]).')
	;
	 1==1
	),

	nl(Handle),nl(Handle),
	(
	 iographic_active,!,
%F010204
         write(Handle,':- tools:complete_root_filename(primitivCodGra,F),load_files(F,[if(changed)]).')
	;
	 1==1
	),
	nl(Handle),nl(Handle),nl(Handle),
	
%%::B AF
	(
         cflpfd_active,!,
	 write(Handle,':- use_module(library(clpfd)).')
	;
	 1==1
	),
	nl(Handle),nl(Handle),
%%::E

	% Depu 02/11/00 mercedes
	% Apuntamos el nombre del fichero fuente (sin extension)
	write(Handle,'% nombre del fichero fuente'),
	nl(Handle),
	write(Handle,'sourceFileNameStr('''),
	name(NameFileStr,NameF),
	write(Handle,NameFileStr),
	write(Handle,''').'),
	nl(Handle),nl(Handle),nl(Handle),
	
	% Fin Depu
	
	write(Handle,'/**************    CODE FOR FUNCTIONS    **************/'),
	nl(Handle),nl(Handle),
	
	% procesamos la lista de funciones

	% YGR 05/12/05 INICIO ---------------------------------------------------------

    % processListFunctions(Handle,LstFuns),   % LO QUITO YGR
      processListFunctionsCut(Handle,LstTrees,LstTreesTransform, LstAnnot, LstAnnotProg),   % �ste es el que se debe ejecutar
                % ahora se le pasa LstTreesTransform ern lugar de LstFuns

    %  processListFunctionsCut(Handle,LstTrees),             % pongo �sto para que funcione
    
      nl(Handle),nl(Handle),
      write(Handle,'/***********   CODE FOR DINAMIC CUT         ***********/'),
      nl(Handle),  nl(Handle),
      write(Handle,'/*Lista de funciones deterministas indicadas por el usuario */'),
      nl(Handle),  nl(Handle),
      processListAnnotates(Handle,LstAnnot),
      nl(Handle), nl(Handle),


      write(Handle,'/*Lista de funciones deterministas por programa *************/'),
      nl(Handle), nl(Handle),
      processListAnnotates(Handle,LstAnnotProg),
      
      nl(Handle),

      % varList y checkVarList
      writeFunctionsCut(Handle),


    % YGR 05/12/05 FIN -------------------------------------------------------------


	write(Handle,'/***********   CONSTRUCTORS AND FUNCTIONS   ***********/'),
	nl(Handle),




	% escribimos en el archivo de salida la lista de constructoras y 
	% funciones de la forma 
	% constr(Name,Arity,Type,DestinationType)
	% y funct(Name,Arity de programa, Ar de la Declaracion, Type,DestinationType),
	% donde el Type es el declarado (si existe) o el inferido (si no hay
	% declarado)

	%nl,write('writing clauses for constructors and functions...'),
	%write('...'),flush_output,
	write('.'),
	writeListCons(Handle,LstCons),
	write('.'),
	nl(Handle),
	writeListPrims(Handle,LstPrims),
	write('.'),
	nl(Handle),
	writeListFuns(Handle,LstFuns),
	write('.'),
	%write('Done'),nl,
	nl(Handle),nl(Handle),




	% clausulas para que Sicstus indexe por el primer argumento en hnf, que
	% sera el nombre de la funcion.

	write(Handle,'/************    CODE FOR FUNCIONS HNF    ************/'),
	nl(Handle),
	processHnfSusp(Handle,LstPrims,LstFuns),
	nl(Handle),nl(Handle),

	
	% completamos la lista de constructoras con otras del mismo nombre
	% pero con aridades que van de 0 a la aridad original
	completeConsCons(LstCons,0,LstConsCons),
	% idem con las funciones y primitivas
	completeConsFuns(LstPrims,0,LstConsPrims),
	completeConsFuns(LstFuns,0,LstConsFuns),


	nl(Handle),nl(Handle),


	nl(Handle),
	write(Handle,'/***************     CODE FOR APPLY     ***************/'),
	nl(Handle),

	% clausulas para apply
	%nl,nl,
	%write('proccesing clauses for apply...'),	
	processApply(Handle,LstConsCons,LstConsPrims,LstConsFuns,LstPrims,LstFuns),
	%write('Done'),nl,nl,
	nl(Handle),nl(Handle),


	% escribimos en el fichero de salida los infix tal y como estan en el
	% .out. Se necesitaran en tiempo de ejecucion para conocer las 
	% prioridades.
	%write('processing clauses for operator precedence...'),
	nl(Handle),
	write(Handle,'/************   CODE FOR INFIX OPERATORS   ************/'),
	nl(Handle),
	processInfix(Handle),
	nl(Handle),nl(Handle),nl(Handle),nl(Handle),
	write(Handle,'\'$flip\'(F, A1, A2, H, Cin, Cout):- '),
	write(Handle,'        \'$$apply\'(\'$$susp\'( \'$$apply\',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).'),
	write('Done'),nl,nl.	


	

%----------------------------------------------------------------------------%
% writeModule(+Handle,+LstFuns,+LstPrims): escribe en el Handle la declaracion 
% modulo del plgenerado con la lista de predicados que exporta.
%----------------------------------------------------------------------------%

writeModule(Handle,LstFuns,LstPrims):-
	%append(LstFuns,LstPrims,Lst),
	dollarAndArity(LstFuns,Lst1),
	% Depu 02/11/00 mercedotas
	% exportamos el predicado que nos da el nombre del fichero fuente, 
	% que ahora se incluye como un hecho sourceFileNameStr(Nombre)
	% en el fichero.pl (ver generateCode)
	write(Handle,':- module(plgenerated,[sourceFileNameStr/1,hnf_susp/5,constr/4,funct/5,infix/3,\'$$apply\'/5,\'$flip\'/6'),
	% Fin Depu
	writeLst(Handle,Lst1),
	write(Handle,']).').
	

%----------------------------------------------------------------------------%
% dollarAndArity(+LstIn,-LstOut): introduce un dolar al principio de cada
% funcion de LstIn y le pone su aridad.
%----------------------------------------------------------------------------%

dollarAndArity([],[]).
dollarAndArity(['$apply'/2|Rest],List):- !,dollarAndArity(Rest,List).
dollarAndArity(['$eqFun'/2|Rest],List):- !,dollarAndArity(Rest,List).
dollarAndArity(['$notEqFun'/2|Rest],List):- !,dollarAndArity(Rest,List).
dollarAndArity([Name/Ar|Y],[NewName/NAr|NY]):-
	name(Name,Name1),
	introduceDollar(Name1,Name2),
	name(NewName,Name2),
	NAr is Ar+3,
	dollarAndArity(Y,NY).
	

%----------------------------------------------------------------------------%
% introduceDollar(+NameIn,-NameOut): pone un dolar al principio de NameIn
%----------------------------------------------------------------------------%

introduceDollar([39|Rest],Name):- introduceDollar(Rest,Name).
introduceDollar(X,[36|X]).


%----------------------------------------------------------------------------%
% writeLst(+Handle,+Lst): escribe en el Handle el nombre de la funcion con su
% aridad y lo escribe de la forma: Name/Arity
%----------------------------------------------------------------------------%

writeLst(Handle,[]).
writeLst(Handle,[Name/Ar|Rest]):-
        write(Handle,','),
        writeAtom(Handle,[]/_,Name),
        write(Handle,' /'),
        write(Handle,Ar),
        writeLst(Handle,Rest).
        


%%%%%%%%%%%%% LISTAS DE CONSTRUCTORAS, FUNCIONES Y PRIMITIVAS %%%%%%%%%%%%%%%%%

%----------------------------------------------------------------------------%
% doListFunctions(-LstFuns): devuelve en una lista todos los Name/Ar de funcion
%----------------------------------------------------------------------------%

doListFunctions(['$apply'/2,'$eqFun'/2,'$notEqFun'/2|LstFuns]):-
	findall(Name/Ar,fun(Name,Ar,_,_),LstFuns).


%----------------------------------------------------------------------------%
% doListConstructors(-LstCons): devuelve en una lista todos los Name/Ar de 
% constructora.
%----------------------------------------------------------------------------%

doListConstructors(LstCons):-
	findall(Name/Ar,cdata(Name,Ar,_,_),LstCons).


% YGR 05/12/05 INICIO
%----------------------------------------------------------------------------%
% doListAnnotates(-LstAnnot) : Devuelve la lita de funciones deterministas
%----------------------------------------------------------------------------%
doListAnnotates(LstAnnot):-
    findall(Name,annotate(deterministic(Name)),LstAnnot).

%----------------------------------------------------------------------------%
% doListDepends(-LstDepends) : Devuelve la lita de dependencis entre funciones
%----------------------------------------------------------------------------%

doListDepends(LstDepends):- 
    findall(depends(F,G),depends(F,G), LstDepends).

% YGR 05/12/05 FIN 

%----------------------------------------------------------------------------%
% doListPrimitives(-LstPrims): devuelve en una lista todos los Name/Ar de 
% primitiva.
%----------------------------------------------------------------------------%

doListPrimitives(LstPrims):-
	findall(Name,primitive(Name,_,_),LstNamePrims),
	associateArity(LstNamePrims,LstPrims).


%----------------------------------------------------------------------------%
% associateArity(+LstNamePrims,-LstPrims) donde:
% +LstNamePrims: lista con los nombres de las primitivas
% -LstPrims: lista con los nombres de las primitivas y sus aridades.
%----------------------------------------------------------------------------%

associateArity([],[]).
associateArity([Name|R],[Name/Ar|RR]):-
	% Depu 25/10/00 mercedes
	% cambiamos ftype por primitiveFunct
	% ftype(Name,Ar,_,_),
	primitiveFunct(Name,_,Ar,_,_),
	associateArity(R,RR).




%%%%%%%%%%%%%%%%% COMPLECCION DE LA LISTA DE CONSTRUCTORAS %%%%%%%%%%%%%%%%%%

%----------------------------------------------------------------------------%
% completeConsCons(+ListIn,?Ac,-ListOut) donde Ac lo uso de contador de
% aridades.
% Generamos una lista de constructoras como la original pero que ademas contenga
% todas las constructoras del mismo nombre y aridades de 0 a la original
%----------------------------------------------------------------------------%

completeConsCons([],_,[]).
completeConsCons([Cons/Ar|Rest],ArC,[Cons/ArC|RestComp]):-
	(
		Ar==ArC,
		completeConsCons(Rest,0,RestComp)
	;
		ArC1 is ArC+1,
		completeConsCons([Cons/Ar|Rest],ArC1,RestComp)
	).


%----------------------------------------------------------------------------%
% completeConsFuns(+ListIn,?Ac,-ListOut)
% idem con las funciones, pero llegamos hasta la aridad original - 1
%----------------------------------------------------------------------------%

completeConsFuns([],_,[]).

% comtemplamos el caso de funs de aridad 0	
completeConsFuns([_/0|Rest],_,RestComp):-
	completeConsFuns(Rest,0,RestComp).

completeConsFuns(['$apply'/2|Rest],_,RestCompl):-
	!,
	completeConsFuns(Rest,0,RestCompl).
completeConsFuns([Fun/Ar|Rest],ArC,[Fun/ArC|RestComp]):-
	(
		Ar=:=ArC+1,		% para quedarnos en uno menos
		completeConsFuns(Rest,0,RestComp)
	;
		ArC1 is ArC+1,
		completeConsFuns([Fun/Ar|Rest],ArC1,RestComp)
	).





%%%%%%%%%%%% ESCRITURA DE LAS LISTAS DE CONSTRUCTORAS, PRIMITIVAS %%%%%%%%%%%%
%%%%%%%%%%%%		Y FUNCIONES EN LA SALIDA		  %%%%%%%%%%%%


%----------------------------------------------------------------------------%
% writeListCons(+Handle,+ListCons)
% sacamos las contructoras en el codigo generado
%----------------------------------------------------------------------------%

writeListCons(_,[]).
writeListCons(Handle,[Cons/Ar|Rest]):-
	cdata(Cons,Ar,Type,_),
	translateType(Type,TypeT),
	extractDestinationType(TypeT,DestinationType),
	Cdata=..[constr,Cons,Ar,TypeT,DestinationType],
	my_write(Handle,[(Cdata,[])]),    % Cdata= cabeza de la clausula que
	writeListCons(Handle,Rest).  % escribo, []= cuerpo de la clausula
                                         % que escribo.


% En ejecucion una primitiva tiene el mismo comportamiento que las funciones
% La aridad de uso la hacemos coincidir con la declarada.

%----------------------------------------------------------------------------%
% writeListPrims(+Handle,+ListPrims)
% sacamos las primitivas en el codigo generado
%----------------------------------------------------------------------------%

writeListPrims(_,[]):-!.
writeListPrims(Handle,[Name/Ar|R]):-
	primitiveFunct(Name,Ar,Ar,Type,DestinationType),
	Ftype=..[funct,Name,Ar,Ar,Type,DestinationType],
	my_write(Handle,[(Ftype,[])]),
	writeListPrims(Handle,R).

	
%----------------------------------------------------------------------------%
% writeListFuns(+Handle,+ListFuns)
% sacamos las funciones en el codigo generado
%----------------------------------------------------------------------------%

writeListFuns(_,[]):-!.

writeListFuns(Handle,['$apply'/2|Rest]):-
	!,
	Ftype=..[funct,'$apply',2,2,'->'('->'('->'(A,B),A),B),B],
	my_write(Handle,[(Ftype,[])]),
	writeListFuns(Handle,Rest).

writeListFuns(Handle,['$eqFun'/2|Rest]):-
	!,
	Ftype=..[funct,'$eqFun',2,2,'->'(A,'->'(A,bool)),bool],
	my_write(Handle,[(Ftype,[])]),
	writeListFuns(Handle,Rest).

writeListFuns(Handle,['$notEqFun'/2|Rest]):-
	!,
	Ftype=..[funct,'$notEqFun',2,2,'->'(A,'->'(A,bool)),bool],
	my_write(Handle,[(Ftype,[])]),
	writeListFuns(Handle,Rest).

writeListFuns(Handle,[Fun/Ar|Rest]):-
	% Depu 25/10/00 mercedes
	(
	 % si estamos depurando hay que saltarse la comprobacion de tipos
	 debugando,
	 Ftype=..[funct,Fun,Ar,ArDecl,_TypeT,_DestinationType]
	; 
	 (ftype(Fun,ArDecl,_,_),!;true),		% puede no estar declarada
	 functiontype(Fun,TypeT),
	 extractDestinationType(TypeT,DestinationType),
	 Ftype=..[funct,Fun,Ar,ArDecl,TypeT,DestinationType]
	), 
	!,
	my_write(Handle,[(Ftype,[])]),
	writeListFuns(Handle,Rest).
	% Fin Depu



/****************************************************************************/
/*	PROCESADO DE LAS FORMAS NORMALES DE CABEZA PARA SUSPENSIONES	    */
/****************************************************************************/

% 3-3-97. Version expandida de los hnf de suspensiones para evitar el call
% que se hacia antes en hnf (en toycomm). Aqui se generan clausulas de la forma
% hnf_susp($>, _A, '.'(_B, '.'(_C, []))):- $>(_A, _B, _C).

%----------------------------------------------------------------------------%
% processHnfSusp(+Handle,+LstPrims,+LstFuns)
%----------------------------------------------------------------------------%

processHnfSusp(Handle,LstPrims,LstFuns):-
	processHnfSuspFun(Handle,LstPrims),
	write('.'),
	processHnfSuspFun(Handle,LstFuns),
	write('.').

%----------------------------------------------------------------------------%
% processHnfSuspFun(+Handle,+List) donde List es una lista con elementos de la
% forma Name/Ar.
% Escribe clausulas de la forma:
% Cabeza= hnf($Name,A1,...,AN,Res,Cin,Cout) siendo N la aridad de Name, A1,...,AN
% variables, Res el resultado de evaluar Name(A1,...,AN) y Cin, Cout los 
% almacenes de restricciones.
% Cuerpo= $Name(A1,...,AN,Res,Cin,Cout)
%----------------------------------------------------------------------------%

processHnfSuspFun(_,[]).
processHnfSuspFun(Handle,[Name/Ar|R]):-
	doListVars(Ar,LstVars),
	name(Name,Name1),
	name(NameN,[36|Name1]),	% 36 = $
	Head=..[hnf_susp,NameN,LstVars,Res,Cin,Cout],
	append(LstVars,[Res,Cin,Cout],ArgsRes),
	Body=..[NameN|ArgsRes],
	my_write(Handle,[(Head,[Body])]),
	processHnfSuspFun(Handle,R).


%----------------------------------------------------------------------------%
% doListVars(+N,-List): genera una List con N variables.
%----------------------------------------------------------------------------%

doListVars(0,[]):-!.
doListVars(N,[_|R]):-N1 is N-1,doListVars(N1,R).




/****************************************************************************/
/*		        PROCESADO DE LAS FUNCIONES			    */
/****************************************************************************/

%----------------------------------------------------------------------------%
% processListFunctions(+Handle,+Lstfuns): escribe el codigo asociado a cada
% funcion de Lstfuns, menos para las funciones apply, eqFun y notEqFun.
%----------------------------------------------------------------------------%

processListFunctions(_,[]).
processListFunctions(Handle,['$apply'/2|Rest]):-
	!,
	processListFunctions(Handle,Rest).

processListFunctions(Handle,['$eqFun'/2|Rest]):-
	!,
	processListFunctions(Handle,Rest).

processListFunctions(Handle,['$notEqFun'/2|Rest]):-
	!,
	processListFunctions(Handle,Rest).

processListFunctions(Handle,[Fun/_|L]):-
	%nl,write(Fun),write('...'),
	write('.'),%flush_output, 
	nl(Handle),
	write(Handle,'% '),
	writeq(Handle,Fun),
	processFunction(Fun,CodFun),
	my_write(Handle,CodFun),
	nl(Handle),
	%write('Done'),
	processListFunctions(Handle,L).





/****************************************************************************/
/*			PROCESADO DEL APPLY				    */
/****************************************************************************/

% apply se comporta como una funcion mas y el codigo para ella es similar al que
% se genera para otras funciones. Para apply_1, sin embargo, hemos cambiado el 
% orden de los argumentos, ya que se comprobo que en este punto la indexacion
% si que juega un papel importante debido a la gran cantidad de clausulas para
% apply_1 que se generan. apply_1 tiene 2 argumentos: la funcion parcial que se
% quiere aplicar y el argumento en cuestion al que queremos aplicarla. En el 
% codigo interno ademas lleva una variable para recoger el resultado. La 
% indexacion se hace sobre la funcion parcial que queremos aplicar y el orden
% queda:
% Funcion parcial a aplicar, resultado, argumento al que aplicamos
% Hemos intercambiado el primero con el cuarto con respecto al resto de 
% funciones.

%----------------------------------------------------------------------------%
% processApply(+Handle,+LstConsCons,+LstConsPrims,+LstConsFuns,+LstPrims,
%              +LstFuns)
%----------------------------------------------------------------------------%

processApply(Handle,LstConsCons,LstConsPrims,LstConsFuns,LstPrims,LstFuns):-
%0800199
% Problema de los applys
% F/=rectangle,X <<- F (1,2) (3,4) dejaba en el resultado rectangle /= rectangle
% F /= suc, F cero == suc cero,         dejaba suc /= suc
% Ahora se generan dos juegos de clausulas para apply_1. Uno como antes y el 
% otro especial para el caso de que la funcion que se aplica sea una variable. 
% Tambien se introduce la clausula applyHnf que discrimina (en tiempo de 
% ejecucion) si este argumento (en hnf) es o no variable.
	
	%my_write(Handle,[('$$apply'(F,X,H,Cin,Cout),
	%	[hnf(F,HF,Cin,Cout1),'$$apply_1'(HF,X,H,Cout1,Cout)])]),

	my_write(Handle,[('$$apply'(F,X,H,Cin,Cout),
		[hnf(F,HF,Cin,Cout1),'$$applyHnf'(HF,X,H,Cout1,Cout)])]),
	
	my_write(Handle,[('$$applyHnf'(F,X,H,Cin,Cout),
			 [var(F),!,'$$apply_1_var'(F,X,H,Cin,Cout)])]),
	
	my_write(Handle,[('$$applyHnf'(F,X,H,Cin,Cout),
			 ['$$apply_1'(F,X,H,Cin,Cout)])]),

		          
	write('.'),
	nl(Handle),nl(Handle),write(Handle,'% constructors'),
	processApplyCons(Handle,LstConsCons),
	write('.'),
	nl(Handle),nl(Handle),write(Handle,'% parcial aplictions of funs'),
	processApplyCons(Handle,LstConsFuns),
	write('.'),
	nl(Handle),nl(Handle),write(Handle,'% parcial aplictions of prims'),
	processApplyCons(Handle,LstConsPrims),
	write('.'),
	nl(Handle),nl(Handle),write(Handle,'% functions'),
	processApplyFuns(Handle,LstFuns),
	write('.'),
	nl(Handle),nl(Handle),write(Handle,'% primitives'),
	processApplyFuns(Handle,LstPrims),
	write('.').


%----------------------------------------------------------------------------%
% processApplyCons(+Handle,+LstCons)
%----------------------------------------------------------------------------%

processApplyCons(_,[]):-!.

% Las constructoras de aridad 0 no nos interesan porque no se pueden aplicar
% parcialmente.
processApplyCons(Handle,[_/0|Rest]):-
	!,
	processApplyCons(Handle,Rest).

% No nos interesan las aplicaciones parciales de la constructora de secuencias
% (',') ni de la constructora de tuplas (tup), ni de la constructora de 
% caracteres (char).

processApplyCons(Handle,[','/_|Rest]):-
	!,
	processApplyCons(Handle,Rest).

processApplyCons(Handle,['$$tup'/_|Rest]):-
	!,
	processApplyCons(Handle,Rest).

processApplyCons(Handle,['$char'/_|Rest]):-
	!,
	processApplyCons(Handle,Rest).





%080199
% Correcci�n de los applys con variables de orden superior
% F/=rectangle,X <<- F (1,2) (3,4) dejaba en el resultado rectangle /= rectangle
% F /= suc, F cero == suc cero,         dejaba suc /= suc
% Se generan dos clausulas, una como siempre y la otra apply_1_var para el caso 
% de que la funcion que se aplica sea una variable (de orden superior). En este 
% caso se utiliza unifyHnfs
processApplyCons(Handle,[Cons/Ar|Rest]):-
	Ar1 is Ar-1,
	functor(C1,Cons,Ar1),
	C1=..[Cons|Args1],
	append(Args1,[X],Args2),
	C2=..[Cons|Args2],

	nl(Handle),
	Rule1=..['$$apply_1',C1,X,C2,_Cin,_Cin],
	my_write(Handle,[(Rule1,[])]),

	Rule2=..['$$apply_1_var',V,X,C2,Cin,Cout],
	my_write(Handle,[(Rule2,[unifyHnfs(V,C1,Cin,Cout)])]),
	processApplyCons(Handle,Rest).


%----------------------------------------------------------------------------%
% processApplyFuns(+Handle,+LstFuns)
%----------------------------------------------------------------------------%

processApplyFuns(_,[]):-!.
processApplyFuns(Handle,['$apply'/2|Rest]):-!,processApplyFuns(Handle,Rest).
processApplyFuns(Handle,[_/0|Rest]):-!,processApplyFuns(Handle,Rest).


%080199
% Correcci�n de los applys con variables de orden superior
% F/= rectangle, X <<- F (1,2) (3,4)   dejaba en el resultado rectangle /= rectangle
% F /= suc, F cero == suc cero,         dejaba suc /= suc
% Se generan dos clausulas, una como siempre y la otra apply_1_var para el caso de que
% la funcion que se aplica sea una variable (de orden superior). En este caso se utiliza
% unifyHnfs
processApplyFuns(Handle,[Fun/Ar|Rest]):-
	Ar1 is Ar-1,
	functor(C1,Fun,Ar1),
	C1=..[Fun|Args1],
	append(Args1,[X,H,Cin,Cout],Args2),
        append(Args1,[X,H,Cout1,Cout],Args3),
	name(Fun,Fun1),
	name(FunN,[36|Fun1]),
	C2=..[FunN|Args2],
        C3=..[FunN|Args3],

%210499 Corregido error de multiples respuestas en un objetivo como F == (3+), F 2 == L
% Habia dos errores
    % - uno de los almacenes aparecia como una variable nueva
    % - una de las clausulas apply_1_var aparecia como apply_1. Esto provocaba 
    % multiples respuestas en el objetivo anterior (y se comeria respuestas en 
    % otros objetivos).
	nl(Handle),
	Head1=..['$$apply_1',C1,X,H,Cin,Cout],
	my_write(Handle,[(Head1,[C2])]),
	
	Head2=..['$$apply_1_var',V,X,H,Cin,Cout],
	my_write(Handle,[(Head2,[unifyHnfs(V,C1,Cin,Cout1),C3])]),
	processApplyFuns(Handle,Rest).



/****************************************************************************/
/*			ESCRITURA DE LOS INFIX				    */
/****************************************************************************/

%----------------------------------------------------------------------------%
% processInfix(+Handle)
%----------------------------------------------------------------------------%

processInfix(Handle):-
	findall((infix(Op,Asoc,Pred),[]),infix(Op,Asoc,Pred,_Lin),LI),
	my_write(Handle,LI).



/****************************************************************************/
/*			 PREDICADO AUXILIAR				    */
/****************************************************************************/

%----------------------------------------------------------------------------%
% deletePredsComp: Borra de la base de datos las clausulas que se han metido 
% durante la compilacion
%----------------------------------------------------------------------------%

deletePredsComp:-
	%my_abolish(data/3),
	my_abolish(cdata/4),
	%my_abolish(type/3),
	my_abolish(ftype/4),
	my_abolish(fun/4),
	my_abolish(infix/4),
	my_abolish(depends/2),
	my_abolish(primitive/3),
      my_abolish(annotate/1),       % Yoli YGR 05/12/05

% Estos dos predicados les ha generado el inferidor (el primero connected).
	my_abolish(depFun/2),
	my_abolish(functiontype/2).




/****************************************************************************/
/*		 ESCRITURA DEL FICHERO DE SALIDA			    */
/****************************************************************************/

%----------------------------------------------------------------------------%
% my_write(+Handle,+Clausulas): lo que hace es escribir las clausulas.
%----------------------------------------------------------------------------%

my_write(Handle,Clausulas):-writeName(Handle,Clausulas).
	

writeName(_,[]).
writeName(Handle,[(Head,Body)|L]):-
	nl(Handle),
	writeAtom(Handle,[]/R,Head),
	writeBodyName(Handle,R/_,Body),
	writeName(Handle,L).


/* Eso de ahi arriba se podria transformar por:
my_write(_,[]).
my_write(Handle,[(Head,Body)|L]):-
	nl(Handle),
	writeAtom(Handle,[]/R,Head),
	writeBodyName(Handle,R/_,Body),
	my_write(Handle,L).

Tengo que mirar si da algun problema.
*/


%----------------------------------------------------------------------------%
% writeBodyName(+Handle,+Lin/-Lout,+Body)
% Escribe el cuerpo (Body) de la clausula con :- por delante. Ademas va guardando
% en las listas las variables que van apareciendo en el Body para darle a las 
% variables repetidas el mismo nombre, y mostrarlas bonitas y no como las saca 
% prolog (_432525). Son listas de variables con elementos de la forma (Var,Name),
% donde Var seria _432525 y Name algo del estilo _C.
%----------------------------------------------------------------------------%

writeBodyName(Handle,_,[]):-!,write(Handle,'.').
writeBodyName(Handle,L/R,Body):-
	write(Handle,':-'),
	writeClBodyName(Handle,L/R,Body).


%----------------------------------------------------------------------------%
% writeClBodyName(+Handle,+L/-R,+Body): escribe el cuerpo de la clausula sin
% el :- por delante.
%----------------------------------------------------------------------------%
% Yoli YGR 01/10/2005 inicio ---------------
% se a�ade el siguiente predicado:
writeClBodyName(Handle,L/R1,[grupo(Uno,Dos)|RestoCl]):-
    !,
    nl(Handle),
    write(Handle,'        '),
      write(Handle,'('),
      writeAtom(Handle,L/R,Uno),
      write(Handle,','),
      nl(Handle),
    write(Handle,'          '),
      write(Handle,'!          %Corte din�mico'),
      nl(Handle),
    write(Handle,'        '),
      write(Handle,';'),
      nl(Handle),
    write(Handle,'          '),
    writeAtom(Handle,L/R,Dos),
      nl(Handle),
    write(Handle,'        '),
      write(Handle,')'),
      (RestoCl =[],
       !,
            write(Handle,'.')
       ;
        write(Handle,','),
            writeClBodyName(Handle,R/R1,RestCl)
      ).

% Yoli 01/10/2005 fin YGR --------

writeClBodyName(Handle,L/R,[Cl]):-
	!,
	nl(Handle),
	write(Handle,'        '),
	writeAtom(Handle,L/R,Cl),
	write(Handle,'.').

writeClBodyName(Handle,L/R1,[Cl|Rest]):-
	nl(Handle),
	write(Handle,'        '),
	writeAtom(Handle,L/R,Cl),
	write(Handle,','),
	writeClBodyName(Handle,R/R1,Rest).






%%% 15-09-99
/* Este predicado estaba aqui, porque Jaime lo habia puesto solo para depurar,
pero en realidad en este modulo no se usa. Sin embargo, si se usa en el modulo
initToy.pl, por eso lo he trasladado alli.
*/

/****************************************************************************/
/*				DEPURACION				    */
/****************************************************************************/
/*
tree(Fich,NameFun):-
	extractNameExtension(Fich,Name,_),
	name(F,Name),
	consult(F,".tmp.out"),
	(
		fun(NameFun,ArP,Reglas,Linea),
		!,		
		traslateCheckRules(Reglas,ReglasT,_),
		tree(fun(NameFun,ArP,ReglasT,Linea),Patron,Tree),
		paint(Patron,Tree),
		deletePredsComp
	;
		nl,
		write('Error: function '''),
		write(NameFun),
		write(''' is not defined in '''),
		write(Fich),write('''.'),nl
	).


tree(Fich,NameFun):-
	write('I need to compile before, please wait...'),
	do(Fich,E),
	nl,
	(E==false,
	%deletePredsComp,
	tree(Fich,NameFun)
	;
	true).
			



tree(_,_).
*/


% YGR 05/12/05 INICIO
%----------------------------------------------------------------------------%
% processListAnnotates(+H, +LstAnnotates)
% Se encarga de escribir en el fichero .pl la lista de annnotates
%----------------------------------------------------------------------------%
processListAnnotates(_,[]).

processListAnnotates(Handle,[NameFun|L]):-
    write('.'),%flush_output, 
    name(NameFun,Name1),
    introduceDollar(Name1,Name2),
    name(NewName,Name2),

    writeq(Handle,annotate(deterministic(NewName))),
    put(Handle,46),
    nl(Handle),
    processListAnnotates(Handle,L).

%----------------------------------------------------------------------------%
% generateTrees(+LstFuns,-LstTrees)
% Este predicado genera un �rbol definicional para cada una de
% las funciones de la lista LstFuns
% (menos para las funciones apply, eqFun y notEqFun) 
% y los guarda en una lista: LstTress.
% Adem�s, generamos (temporalmente) un fichero arbolitos.txt 
% para comprobar que los genera apropiadamente.
%----------------------------------------------------------------------------%
generateTrees([],[]).
generateTrees(['$apply'/2|Rest], LstTrees):-
    !,
    generateTrees(Rest, LstTrees).

generateTrees(['$eqFun'/2|Rest], LstTrees):-
    !,
    generateTrees(Rest, LstTrees).

generateTrees(['$notEqFun'/2|Rest],LstTrees):-
    !,
    generateTrees(Rest, LstTrees).

generateTrees([Fun/_|L], [(NameFun,DefTreeF)|RestLstTrees] ):-
    processFunctionCut(Fun,(NameFun,DefTreeF)),
    generateTrees(L, RestLstTrees ).

%----------------------------------------------------------------------------%
% (+Handle,+L).
% Genera c�digo para cada una de las funciones contenidas en la lista L a 
% partir del �rbol definicional
%----------------------------------------------------------------------------%

processListFunctionsCut(_,[],[], _,_).
processListFunctionsCut(Handle,[(Name,DefTree)|L],[(Name,Det,DefTreet)|Lt],LstAnnot, LstAnnotProg):-
    %nl,write(Fun),write('...'),
    write('.'),%flush_output, 
    nl(Handle),
    write(Handle,'% '),
    writeq(Handle,Name),
    name(Name,NameFunS),
    name(NameFun,[36|NameFunS]),  
    ( 
      (getCut(on), (member(Name, LstAnnot); member(Name, LstAnnotProg))),
      !,
         generateFinalCode(DefTreet,NameFun,CodFun)      % funci�n  determinista
      ;
         true= true,
         generateFinalCode(DefTree,NameFun,CodFun)     % funci�n no determinista
    ),
    my_write(Handle,CodFun),
    nl(Handle),
    %write('Done'),
    processListFunctionsCut(Handle,L,Lt, LstAnnot, LstAnnotProg),
    !.



writeFunctionsCut(Handle):-
    nl(Handle),
    write(Handle,'% varList(+List,-ListVars): ListVars is a list with all the variables from'),
        nl(Handle),
    write(Handle,'% terms in List  that can avoid the cut if they are bound'),
    nl(Handle),
    write(Handle,'% Each variable occurrs only once in ListVars.'),
    nl(Handle),
        write(Handle,'varList(ListTerms,ListVars) :- varList(ListTerms,[],ListVars),!.'),
    nl(Handle),
    nl(Handle),
    write(Handle,'% varList(+List,+LI, -LO): Analagous to varList/2 but with LI'),
    nl(Handle),
    write(Handle,'% the list of variables accumulated at the moment.'),
    nl(Handle),
    write(Handle,'varList([],ListVars,ListVars) :- !.'),
    nl(Handle),
    write(Handle,'varList([X|Xs],LI,LO) :- varListTerm(X,LI,LO1),'),
    nl(Handle),
    write(Handle,'                         varList(Xs,LO1,LO).'),
    nl(Handle),
    write(Handle,'% varListTerm(+Term,+LI,-LO) : Analogous to varList/3 but for a single term'),
    nl(Handle),
    write(Handle,'varListTerm(T,L,L)       :- atomic(T),!.'),
    nl(Handle),
    write(Handle,'varListTerm(V,LI,LI)     :- var(V), varInList(V,LI),!.'),
    nl(Handle),
    write(Handle,'varListTerm(V,LI,[V|LI]) :- var(V),!.'),
    nl(Handle),
    nl(Handle),
    write(Handle,'% evaluated suspension: check the result'),
    nl(Handle),
/*
varListTerm('$$susp'(_F,_Args,R,S),LI,LO) :- \+var(S),
                                             !,
                                             varListTerm(R,LI,LO).

*/
    write(Handle,'varListTerm(''$$susp''(_F,_Args,R,S),LI,LO) :- \\+var(S),'),
        nl(Handle),
    write(Handle,'                                             !,'),
    nl(Handle),
    write(Handle,'                                             varListTerm(R,LI,LO).'),
    nl(Handle),
    nl(Handle),
    write(Handle,'% non-evaluated suspension: collect the variables of the arguments, and'),
    nl(Handle),
    write(Handle,'% the variable determining if it is evaluated if it is non-deterministic'),
    nl(Handle),
    write(Handle,'varListTerm(''$$susp''(F,Args,_R,S),LI,LO) :- varList(Args,LI,LO1),'),
    nl(Handle),
    write(Handle,'                                           ('),
    nl(Handle),
%   write(Handle,'                                             \\+deterministic(F),'),
    write(Handle,'                                             \\+annotate(deterministic(F)),'),
    nl(Handle),
    write(Handle,'                                             \\+varInList(S,LO1),'),
    nl(Handle),
    write(Handle,'                                             LO=[S|LO1]'),
    nl(Handle),
    write(Handle,'                                               ;'),
    nl(Handle),
    write(Handle,'                                             LO = LO1'),
    nl(Handle),
    write(Handle,'                                           ),'),
    nl(Handle),
    write(Handle,'                                           !.'), 
    nl(Handle),
    write(Handle,'% rest of the possibilities'),
    nl(Handle),
    write(Handle,'varListTerm(Term,LI,LO):- Term =.. [F|Args],'),
    nl(Handle),
    write(Handle,'varListTerm(F,LI,LO1),'),
    nl(Handle),
    write(Handle,'varList(Args,LO1,LO).'),
    nl(Handle),
    nl(Handle),
    write(Handle,'% varInList(+V,+L)'),
    nl(Handle),
    write(Handle,'% Checks if the var V occurrs in the list L'),
    nl(Handle),
    write(Handle,'varInList(V,[R|_L]) :- V==R,!.'),
    nl(Handle),
    write(Handle,'varInList(V,[_R|L]) :- varInList(V,L).'),
    nl(Handle),
    write(Handle,'% checkVarList(L): Checks if the input list contains different variables'),
    nl(Handle),
    write(Handle,'checkVarList([]) :- !.'),
    nl(Handle),
    write(Handle,'checkVarList([X|Xs]) :- var(X), \\+varInList(X,Xs), checkVarList(Xs).'),
    nl(Handle),
    nl(Handle),
    nl(Handle).



%----------------------------------------------------------------------------%
% writeTreesTemp(+LstTrees,+LstTreesTransform, +LstAnnotProg, +LstNotDeter):-
% se escriben todos los �rboles definicionales generados, los �rboles Transformados, 
% la lista de funciones deterministas detectadas al analizar el �rbol,
% la lista de funciones no deterministas
% en un fichero "arbolitos.txt"
%----------------------------------------------------------------------------%

writeTreesTemp(LstTrees,LstTreesTransform, LstAnnotProg, LstNotDeter):-
     name(Ftree, "arbolitos.txt"),
     open(Ftree, write, TreeOut),
    write(TreeOut, '-Lista funciones deterministas programa --------'),
     nl(TreeOut),
     write(TreeOut, '------------------------------------------------'),
     nl(TreeOut),
     nl(TreeOut),
     processListAnnotates(TreeOut, LstAnnotProg),
     nl(TreeOut),
     write(TreeOut, '- Lista funciones no deterministas -------------'),
     nl(TreeOut),
     write(TreeOut, '------------------------------------------------'),
     nl(TreeOut),
     nl(TreeOut),
     processListAnnotates(TreeOut, LstNotDeter), 
     nl(TreeOut),
     nl(TreeOut),
     
     write(TreeOut, '---------------- ARBOLES DEFINICIONALES GENERADOS -------------'),
     nl(TreeOut),
     write(TreeOut, '---------------------------------------------------------------'),
     nl(TreeOut),
     nl(TreeOut),
     writeTrees(TreeOut, LstTrees),
     nl(TreeOut),
     nl(TreeOut),

     write(TreeOut, '---------------- ARBOLES DEFINICIONALES transformados -------------'),
     nl(TreeOut),
     write(TreeOut, '---------------------------------------------------------------'),
     nl(TreeOut),
     nl(TreeOut),
     writeTrees(TreeOut, LstTreesTransform),
     close(TreeOut).

writeTrees(Handle,[]).
writeTrees(Handle,[(NameFun,Tree)|RestoTrees]):-
     write(Handle,NameFun),
     nl(Handle),
     write(Handle,Tree),
     nl(Handle),
     write(Handle, '--------------------------------------'),
     nl(Handle),
     nl(Handle),
     writeTrees(Handle,RestoTrees).

% YGR 05/12/05 FIN ---------------------------------------------

