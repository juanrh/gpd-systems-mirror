

:- module(primitivCodGra,['$openWish'/4,'$writeWish'/5,'$readWish'/4,
      %'$readStreamLine'/4,'$readStreamChar'/4,'$end_offile'/4,
      %'$continu1'/5,'$continu2'/5,
          '$closeWish'/4,
          '$newVar'/4,'$newVar1'/4,'$newVar2'/4,'$readVar'/4,
          '$writeVar'/5,'$writeVar1'/4,
          '$strToint'/4,'$getNumber'/5,'$intTostr'/4,'$getString'/5,
          '$tkShowErrors'/3,'$tkRef2Label'/4,'$tkRef2Wtype'/4,
          '$tk2tcl'/6,'$tkConfCollection2tcl'/5,'$tkConf2tcl'/7,
          '$tksetlistelems'/5,'$tkMenu2tcl'/5,'$setmenuelems'/5,
          '$tkConfs2handler'/5,'$tkMenu2handler'/6,'$tkConfs2tcl'/7,
          '$tkcitems2tcl'/5,'$tkcitem'/5,'$tkShowCoords'/4,
          '$tkLabel2Refname'/4,'$aux'/4,'$tkRefname2Label'/4,'$aux1'/4,
          '$tks2tcl'/7,'$tkslabels'/6,'$tkmain2tcl'/5,'$aux4'/4,
          '$runWidget'/5,'$runWidgetInit'/6,'$runWidgetPassive'/5,
          '$forkWish'/5,'$initSchedule'/8,'$tkSchedule'/7,'$aux2'/8,
          '$tkTerminateWish'/5,'$tkSelectEvent'/7,'$tkGetVar'/6,
          '$tkGetVarMsg'/6,'$aux3'/7,'$tkGetVarValue'/6,'$tkParseInt'/5,
          '$checkWishConsistency'/5,'$escape_tcl'/4,
          '$tkVoid'/4,'$tkExit'/4,'$tkGetValue'/5,'$tkSetValue'/6,
          '$tkUpdate'/6,'$tkConfig'/6,'$tkFocus'/5,'$tkAddCanvas'/6
%          ,
%%% ::B Rafa           
%          '$dValToString'/4,'$dVal'/4,'$selectWhereVariableXi'/7,
%          '$getConstraintStore'/4,
%%% ::E
%
%% FALLO FINITO Y CORTE 
%% pacol 17-03-05
%           '$fails'/4, '$once'/4, '$collect'/4, '$collectN'/5
          ]).

:- load_files(primFunct,[if(changed),imports([errPrim/0])]).

:- load_files(primitivCod,[if(changed)]).


:- load_files(dyn,[if(changed)]). %,imports([assertfile/3,retractfile/3,file/3,assertio_active/0])]).
:- load_files(osystem,[if(changed),imports([loadFilesIo/3])]).
:- (
    io_active,
    !,
    load_files(primitivCodIo,[if(changed)])
   ;
    assertio_active,
    loadFilesIo(P,T1,B),
    load_files(P,[if(changed)]),
    load_files(T1,[if(changed)]),
    load_files(B,[if(changed)])
   ).
   
   
:- load_files(toycomm,[if(changed)]). %,imports([hnf/4,unifyHnfs/4,nf/4])]).

% :- load_files(basic,[if(changed),imports(['$$apply'/5])]).
% Esta dependencia se debia exclusivamente al codigo para 'flip',
% y generaba efectos indeseables al activar y desactivar /cflpr cuando estamos
% con la version con restricciones sobre los reales.
% Se ha eliminado, y para ello, el codigo de flip se ha llevado a
% basic.pl



% 11/05/00 mercedes
% Estos modulos se necesitan para la parte de entrada/salida

:- load_files(tools,[if(changed),imports([append/3])]).

:- load_files(codfun,[if(changed),imports([introduceSusp/3])]).


:- load_files(errortoy,[if(changed),imports([treat_error/2])]).

% 30/05/00 mercedes: se necesita para la e/s grafica
:- use_module(library(system)).   % exec/3

%:- use_module(library(tcltk)).


/*
    This module contains the code for primitives. This functions haves a
direct tranlation into Prolog. Cin and Cout are the stores of disequality 
constraints and must be placed as in the following examples. Before the Prolog
operation the hnf predicate must be called for each one argument.


Types for aritmethic functions are defined in a quite ad-hoc way here
in order to allow (a very limited) overloading of arithmetic operations.
The idea is the following: we represent the types 'int' and 'real'
by the terms 'num(int)' and 'num(real)', and we use 'num(A)' for
achieving overloading, when desired. 

Nota: Los tipos de las primitivas se toman de aqui (no del standard) para 
poder forzar el tipo de algunas funciones como / o sqrt y siempre devuelvan 
real (num(float))

P.e. el + respeta la declaracion + :: num(A) -> num(A) -> num(A), lo que quiere
 decir que si los dos argumentos son int el resultado es int y si alguno de los
dos es float el resultado es float.
En / tenemos / :: num(A) -> num(

*/


/******************************** E/S GRAFICA ********************************/

% 29/05/00 mercedes
% primitivas para la entrada/salida grafica

'$openWish'(Str,'$io'('$channel'(Win,Wout)),Cin,Cout):-
    nf(Str,HStr1,Cin,Cout),
    '$trans'(HStr1,[],HStr),
    name(FStr,HStr),
    %atom_to_chars(FStr,HStr),
    exec(wish,[pipe(Win),pipe(Wout),std],_),
    write(Win,'wm title . "'),
    write(Win,FStr),
    write(Win,'"'),
    nl(Win).


'$writeWish'('$channel'(Win,Wout),Str,'$io'(unit),Cin,Cout):-
    nf(Str,HStr1,Cin,Cout),
    '$trans'(HStr1,[],HStr),
    name(Msg,HStr),
    %atom_to_chars(Msg,HStr),
    write(Win,Msg),
    nl(Win).
    
    
'$readWish'('$channel'(Win,Wout),'$io'(Str),Cin,Cout):-
    %read(Wout,Str).
    '$getLineFile'(Wout,'$io'(Str),Cin,Cout).
    %'$trans'(Msg1,[],Msg),
    %name(Str,Msg).
    %atom_to_chars(Str,Msg).



'$closeWish'('$channel'(Win,Wout),'$io'(unit),Cin,Cin):-
    write(Win,'exit'),
    nl(Win),
    close(Win),
    close(Wout).


/*************************** VARIABLES MUTABLES ***************************/

'$newVar'(V,'$io'('$varmut'(N)),Cin,Cout):-
    nf(V,HV,Cin,Cout1),
    '$newVar1'(HV,N,Cout1,Cout).


'$newVar1'(HV,N,Cin,Cout):-
    ground(HV),
    !,
    '$newVar2'(HV,N,Cin,Cout).

'$newVar1'(HV,N,Cin,Cout):-
    errPrim1.


'$newVar2'(HV,N,Cin,Cin):-
    retractcontvar(C),
    !,
    N is C+1,
    assertacontvar(N),
    assertavarmut(N,HV).
    
'$newVar2'(HV,1,Cin,Cin):-
    assertacontvar(1),
    assertavarmut(1,HV).


'$readVar'('$varmut'(N),'$io'(V),Cin,Cin):-
    varmut(N,V).


'$writeVar'(V,'$varmut'(N),'$io'(unit),Cin,Cout):-
    nf(V,HV,Cin,Cout1),
    '$writeVar1'(HV,N,Cout1,Cout).
    

'$writeVar1'(HV,N,Cin,Cin):-
    ground(HV),
    !,
    retractvarmut(N,HA),
    assertavarmut(N,HV).
    
'$writeVar1'(HV,N,Cin,Cin):-
    errPrim1.


/******************************* LIBRERIA TCLTK ******************************/

% 13/09/00 mercedes
% primitivas para la libreria tcltk

% and
'$and'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$and_1'(_F, _B, _C, _G, _E).
'$and'(_A, _B, false, _C, _D):-
        hnf(_B, false, _C, _D).
'$and_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$and_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _E),
        hnf(_B, true, _E, _D).

% or
'$or'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$or_1'(_F, _B, _C, _G, _E).
'$or'(_A, _B, true, _C, _D):-
        hnf(_B, true, _C, _D).
'$or_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$or_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _E),
        hnf(_B, false, _E, _D).

% /\
$/\(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$/\\_1'(_F, _B, _C, _G, _E).
'$/\\_1'(_A, _B, false, _C, _D):-
        unifyHnfs(_A, false, _C, _D).
'$/\\_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, true, _D, _F),
        hnf(_B, _C, _F, _E).

% \/
$\/(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$\\/_1'(_F, _B, _C, _G, _E).
'$\\/_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, true, _C, _D).
'$\\/_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, false, _D, _F),
        hnf(_B, _C, _F, _E).


% not
'$not'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$not_1'(_E, _B, _F, _D).
'$not_1'(_A, false, _B, _C):-
        unifyHnfs(_A, true, _B, _C).
'$not_1'(_A, true, _B, _C):-
        unifyHnfs(_A, false, _B, _C).


% map
'$map'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$map_2'(_A, _F, _C, _G, _E).
'$map_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$map_2'(_A, _B, :('$$susp'( '$$apply',  [ _A, _C ], _D, _E ), '$$susp'( '$map',  [ _A, _F ], _G, _H )), _I, _J):-
        unifyHnfs(_B, :(_C, _F), _I, _J).

% ++
$++(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$++_1'(_F, _B, _C, _G, _E).
'$++_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, _C, _F, _E).
'$++_1'(_A, _B, :(_C, '$$susp'( $++,  [ _D, _B ], _E, _F )), _G, _H):-
        unifyHnfs(_A, :(_C, _D), _G, _H).


% take
'$take'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$take_2'(_A, _F, _C, _G, _E).
'$take_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$take_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, 0.0 ], _I, _J ), [], :(_F, '$$susp'( '$take',  [ '$$susp'( $-,  [ _A, 1.0 ], _K, _L ), _G ], _M, _N )), _C, _H, _E).

% drop
'$drop'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$drop_2'(_A, _F, _C, _G, _E).
'$drop_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$drop_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, 0.0 ], _I, _J ), :(_F, _G), '$$susp'( '$drop',  [ '$$susp'( $-,  [ _A, 1.0 ], _K, _L ), _G ], _M, _N ), _C, _H, _E).

% fst
'$fst'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_G, _B, _I, _D).

% snd
'$snd'(_A, _B, _C, _D):-
        hnf(_A, '$$tup'(_E), _C, _F),
        hnf(_E, ','(_G, _H), _F, _I),
        hnf(_H, _B, _I, _D).

% head
'$head'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_E, _B, _G, _D).


% tail
'$tail'(_A, _B, _C, _D):-
        hnf(_A, :(_E, _F), _C, _G),
        hnf(_F, _B, _G, _D).

% length
'$length'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$length_1'(_E, _B, _F, _D).
'$length_1'(_A, 0.0, _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$length_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $+(1.0, '$$susp'( '$length',  [ _F ], _H, _I ), _B, _G, _D).

% concat
'$concat'(foldr(++, []), _A, _A).

% foldr
'$foldr'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$foldr_3'(_A, _B, _G, _D, _H, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, [], _E, _G),
        hnf(_B, _D, _G, _F).
'$foldr_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        '$$apply'('$$susp'( '$$apply',  [ _A, _G ], _J, _K ), '$$susp'( '$foldr',  [ _A, _B, _H ], _L, _M ), _D, _I, _F).




% strToint
'$strToint'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ '$$susp'( '$head',  [ _A ], _E, _F ), '$char'(45) ], _G, _H ), '$$susp'( '$uminus',  [ '$$susp'( '$getNumber',  [ '$$susp'( '$tail',  [ _A ], _I, _J ), 0.0 ], _K, _L ) ], _M, _N ), '$$susp'( '$getNumber',  [ _A, 0.0 ], _O, _P ), _B, _C, _D).

% getNumber
'$getNumber'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$getNumber_1'(_F, _B, _C, _G, _E).
'$getNumber_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, _C, _F, _E).
'$getNumber_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        '$getNumber'(_G, '$$susp'( $+,  [ '$$susp'( $*,  [ _B, 10.0 ], _I, _J ), '$$susp'( $-,  [ '$$susp'( '$ord',  [ _F ], _K, _L ), '$$susp'( '$ord',  [ '$char'(48) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).

% intTostr
'$intTostr'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( $<,  [ _A, 0.0 ], _E, _F ), :('$char'(45), '$$susp'( '$getString',  [ '$$susp'( '$uminus',  [ _A ], _G, _H ), [] ], _I, _J )), '$$susp'( '$getString',  [ _A, [] ], _K, _L ), _B, _C, _D).

% getString
'$getString'(_A, _B, _C, _D, _E):-
        equal(_A, 0.0, _D, _F),
        hnf(_B, _C, _F, _E).
'$getString'(_A, _B, _C, _D, _E):-
        $>(_A, 0.0, true, _D, _F),
        equal(_G, '$$susp'( '$div',  [ _A, 10.0 ], _H, _I ), _F, _J),
        equal(_K, '$$susp'( '$mod',  [ _A, 10.0 ], _L, _M ), _J, _N),
        equal(_O, '$$susp'( '$chr',  [ '$$susp'( $+,  [ '$$susp'( '$ord',  [ '$char'(48) ], _P, _Q ), _K ], _R, _S ) ], _T, _U ), _N, _V),
        '$getString'(_G, :(_O, _B), _C, _V, _E).



% tkShowErrors
'$tkShowErrors'(false, _A, _A).

% tkRef2Label
'$tkRef2Label'(_A, _B, _C, _D):-
        hnf(_A, tkRefLabel(_E, _F, _G), _C, _H),
        '$tkRefname2Label'(_F, _B, _H, _D).

% tkRef2Wtype
'$tkRef2Wtype'(_A, _B, _C, _D):-
        hnf(_A, tkRefLabel(_E, _F, _G), _C, _H),
        hnf(_G, _B, _H, _D).

% tk2tcl
'$tk2tcl'(_A, _B, _C, '$$tup'(','(_D, _E)), _F, _G):-
        hnf(_C, _H, _F, _I),
        '$tk2tcl_3'(_A, _B, _H, '$$tup'(','(_D, _E)), _I, _G).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(32), []))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ) ], _MB, _NB ) ], _OB, _PB ), :('$$tup'(','(_B, _QB)), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))), _A, _B, _R ], _RB, _SB ) ], _TB, _UB )))), _VB, _WB):-
        unifyHnfs(_C, tkButton(_QB, _R), _VB, _WB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(99), :('$char'(97), :('$char'(110), :('$char'(118), :('$char'(97), :('$char'(115), :('$char'(32), []))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(97), :('$char'(110), :('$char'(118), :('$char'(97), :('$char'(115), [])))))), _A, _B, _D ], _E, _F ) ], _G, _H ) ], _I, _J ) ], _K, _L ) ], _M, _N ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(97), :('$char'(110), :('$char'(118), :('$char'(97), :('$char'(115), [])))))), _A, _B, _D ], _O, _P ) ], _Q, _R ))), _S, _T):-
        unifyHnfs(_C, tkCanvas(_D), _S, _T).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(32), [])))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkCheckButton(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkEntry(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), []))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), []))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkLabel(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(108), :('$char'(105), :('$char'(115), :('$char'(116), :('$char'(98), :('$char'(111), :('$char'(120), :('$char'(32), [])))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(111), :('$char'(114), :('$char'(116), :('$char'(115), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(99), :('$char'(116), :('$char'(105), :('$char'(111), :('$char'(110), :('$char'(32), :('$char'(102), :('$char'(97), :('$char'(108), :('$char'(115), :('$char'(101), :('$char'(10), [])))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(105), :('$char'(115), :('$char'(116), :('$char'(98), :('$char'(111), :('$char'(120), []))))))), _A, _B, _P ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(108), :('$char'(105), :('$char'(115), :('$char'(116), :('$char'(98), :('$char'(111), :('$char'(120), []))))))), _A, _B, _P ], _CB, _DB ) ], _EB, _FB ))), _GB, _HB):-
        unifyHnfs(_C, tkListBox(_P), _GB, _HB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), :('$char'(32), [])))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), []))))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), []))))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkMessage(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(32), []))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _L, _M ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))), _A, _B, _R ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))), _A, _B, _R ], _MB, _NB ) ], _OB, _PB ))), _QB, _RB):-
        unifyHnfs(_C, tkMenuButton(_R), _QB, _RB).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(114), :('$char'(111), :('$char'(109), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _D ], _E, _F ), '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(111), :('$char'(32), []))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _G ], _H, _I ), '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(122), :('$char'(111), :('$char'(110), :('$char'(116), :('$char'(97), :('$char'(108), :('$char'(32), :('$char'(45), :('$char'(108), :('$char'(101), :('$char'(110), :('$char'(103), :('$char'(116), :('$char'(104), :('$char'(32), :('$char'(50), :('$char'(48), :('$char'(48), :('$char'(10), [])))))))))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _D ], _L, _M ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(105), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(32), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _N, _O ), '$$susp'( $++,  [ :('$char'(10), []), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _P, _Q ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _R, _S ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(32), :('$char'(36), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _T, _U ), '$$susp'( $++,  [ :('$char'(32), :('$char'(125), :('$char'(10), []))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _V, _W ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(103), :('$char'(108), :('$char'(111), :('$char'(98), :('$char'(97), :('$char'(108), :('$char'(32), [])))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _X, _Y ), '$$susp'( $++,  [ :('$char'(32), :('$char'(59), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(32), []))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _Z, _AA ), '$$susp'( $++,  [ :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), []))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))), _A, _B, _BA ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ) ], _QA, _RA ) ], _SA, _TA ) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ) ], _GB, _HB ) ], _IB, _JB ) ], _KB, _LB ) ], _MB, _NB ) ], _OB, _PB ) ], _QB, _RB ) ], _SB, _TB ) ], _UB, _VB ) ], _WB, _XB ) ], _YB, _ZB ) ], _AC, _BC ) ], _CC, _DC ) ], _EC, _FC ) ], _GC, _HC ) ], _IC, _JC ) ], _KC, _LC ) ], _MC, _NC ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))), _A, _B, _BA ], _OC, _PC ) ], _QC, _RC ))), _SC, _TC):-
        unifyHnfs(_C, tkScale(_D, _G, _BA), _SC, _TC).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), :('$char'(32), [])))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(105), :('$char'(122), :('$char'(111), :('$char'(110), :('$char'(116), :('$char'(97), :('$char'(108), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), [])))))))))))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _E, _F ), '$$susp'( $++,  [ :('$char'(32), :('$char'(120), :('$char'(118), :('$char'(105), :('$char'(101), :('$char'(119), :('$char'(125), :('$char'(10), [])))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _G, _H ), '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(120), :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), [])))))))))))))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(125), :('$char'(10), [])))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _I, _J ), '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(119), :('$char'(114), :('$char'(97), :('$char'(112), :('$char'(32), :('$char'(110), :('$char'(111), :('$char'(110), :('$char'(101), :('$char'(10), [])))))))))))))))))))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _K ], _L, _M ) ], _N, _O ) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ) ], _FA, _GA ) ], _HA, _IA ) ], _JA, _KA ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _K ], _LA, _MA ) ], _NA, _OA ))), _PA, _QA):-
        unifyHnfs(_C, tkScrollH(_D, _K), _PA, _QA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), :('$char'(32), [])))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _E, _F ), '$$susp'( $++,  [ :('$char'(32), :('$char'(121), :('$char'(118), :('$char'(105), :('$char'(101), :('$char'(119), :('$char'(125), :('$char'(10), [])))))))), '$$susp'( $++,  [ '$$susp'( '$tkRef2Label',  [ _D ], _G, _H ), '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(121), :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), [])))))))))))))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(125), :('$char'(10), [])))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _I ], _J, _K ) ], _L, _M ) ], _N, _O ) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(115), :('$char'(99), :('$char'(114), :('$char'(111), :('$char'(108), :('$char'(108), :('$char'(98), :('$char'(97), :('$char'(114), []))))))))), _A, _B, _I ], _FA, _GA ) ], _HA, _IA ))), _JA, _KA):-
        unifyHnfs(_C, tkScrollV(_D, _I), _JA, _KA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(32), []))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(104), :('$char'(101), :('$char'(105), :('$char'(103), :('$char'(104), :('$char'(116), :('$char'(32), :('$char'(49), :('$char'(53), :('$char'(10), [])))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _D, _E ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(32), :('$char'(49), :('$char'(46), :('$char'(48), :('$char'(32), :('$char'(123), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(45), :('$char'(49), :('$char'(32), :('$char'(99), :('$char'(104), :('$char'(97), :('$char'(114), :('$char'(115), :('$char'(125), :('$char'(125), :('$char'(10), []))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), []))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _B ], _F, _G ), '$$susp'( $++,  [ :('$char'(32), :('$char'(123), :('$char'(115), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), []))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(100), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(49), :('$char'(46), :('$char'(48), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(59), :('$char'(32), [])))))))))))))))))), '$$susp'( $++,  [ _B, '$$susp'( $++,  [ :('$char'(32), :('$char'(105), :('$char'(110), :('$char'(115), :('$char'(101), :('$char'(114), :('$char'(116), :('$char'(32), :('$char'(49), :('$char'(46), :('$char'(48), :('$char'(32), :('$char'(36), :('$char'(115), :('$char'(125), :('$char'(10), [])))))))))))))))), '$$susp'( '$fst',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))), _A, _B, _H ], _I, _J ) ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ) ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ) ], _OA, _PA ), '$$susp'( '$snd',  [ '$$susp'( '$tkConfs2tcl',  [ :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))), _A, _B, _H ], _QA, _RA ) ], _SA, _TA ))), _UA, _VA):-
        unifyHnfs(_C, tkTextEdit(_H), _UA, _VA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ '$$susp'( '$if_then_else',  [ '$$susp'( '$$eqFun',  [ _B, [] ], _D, _E ), [], '$$susp'( $++,  [ :('$char'(102), :('$char'(114), :('$char'(97), :('$char'(109), :('$char'(101), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, :('$char'(10), []) ], _F, _G ) ], _H, _I ) ], _J, _K ), '$$susp'( $++,  [ '$$susp'( '$fst',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _M, _N ) ], _O, _P ), '$$susp'( $++,  [ :('$char'(112), :('$char'(97), :('$char'(99), :('$char'(107), :('$char'(32), []))))), '$$susp'( $++,  [ '$$susp'( '$tkslabels',  [ _B, 97.0, _L ], _Q, _R ), '$$susp'( $++,  [ '$$susp'( '$tkConfCollection2tcl',  [ :('$char'(114), :('$char'(111), :('$char'(119), []))), _S ], _T, _U ), :('$char'(45), :('$char'(115), :('$char'(105), :('$char'(100), :('$char'(101), :('$char'(32), :('$char'(108), :('$char'(101), :('$char'(102), :('$char'(116), :('$char'(10), []))))))))))) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$snd',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _FA, _GA ) ], _HA, _IA ))), _JA, _KA):-
        unifyHnfs(_C, tkRow(_S, _L), _JA, _KA).
'$tk2tcl_3'(_A, _B, _C, '$$tup'(','('$$susp'( $++,  [ '$$susp'( '$if_then_else',  [ '$$susp'( '$$eqFun',  [ _B, [] ], _D, _E ), [], '$$susp'( $++,  [ :('$char'(102), :('$char'(114), :('$char'(97), :('$char'(109), :('$char'(101), :('$char'(32), [])))))), '$$susp'( $++,  [ _B, :('$char'(10), []) ], _F, _G ) ], _H, _I ) ], _J, _K ), '$$susp'( $++,  [ '$$susp'( '$fst',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _M, _N ) ], _O, _P ), '$$susp'( $++,  [ :('$char'(112), :('$char'(97), :('$char'(99), :('$char'(107), :('$char'(32), []))))), '$$susp'( $++,  [ '$$susp'( '$tkslabels',  [ _B, 97.0, _L ], _Q, _R ), '$$susp'( $++,  [ '$$susp'( '$tkConfCollection2tcl',  [ :('$char'(99), :('$char'(111), :('$char'(108), []))), _S ], _T, _U ), :('$char'(10), []) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$snd',  [ '$$susp'( '$tks2tcl',  [ _A, _B, 97.0, _L ], _FA, _GA ) ], _HA, _IA ))), _JA, _KA):-
        unifyHnfs(_C, tkCol(_S, _L), _JA, _KA).

% tkConfCollection2tcl
'$tkConfCollection2tcl'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkConfCollection2tcl_2'(_A, _F, _C, _G, _E).
'$tkConfCollection2tcl_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$tkConfCollection2tcl_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        hnf(_F, _I, _H, _J),
        '$tkConfCollection2tcl_2_2.1_:'(_A, _I, _G, _C, _J, _E).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkCenter, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(99), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(101), :('$char'(114), :('$char'(32), []))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkLeft, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(119), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkRight, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(101), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkTop, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(110), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkBottom, _E, _G),
        $++(:('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), :('$char'(119), :('$char'(32), [])))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkExpand, _E, _G),
        $++(:('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(49), :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(105), :('$char'(108), :('$char'(108), :('$char'(32), :('$char'(98), :('$char'(111), :('$char'(116), :('$char'(104), :('$char'(32), []))))))))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkExpandX, _E, _G),
        $++(:('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(49), :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(105), :('$char'(108), :('$char'(108), :('$char'(32), :('$char'(120), :('$char'(32), [])))))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).
'$tkConfCollection2tcl_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkExpandY, _E, _G),
        $++(:('$char'(45), :('$char'(101), :('$char'(120), :('$char'(112), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(49), :('$char'(32), :('$char'(45), :('$char'(102), :('$char'(105), :('$char'(108), :('$char'(108), :('$char'(32), :('$char'(121), :('$char'(32), [])))))))))))))))))), '$$susp'( '$tkConfCollection2tcl',  [ _A, _C ], _H, _I ), _D, _G, _F).


% tkConf2tcl
'$tkConf2tcl'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_D, _H, _F, _I),
        '$tkConf2tcl_4'(_A, _B, _C, _H, _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkActive(_H), _F, _I),
        '$if_then'('$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))) ], _N, _O ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))) ], _P, _Q ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))) ], _R, _S ), '$$susp'( '$$eqFun',  [ _A, :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( '$if_then_else',  [ _H, '$$susp'( $++,  [ _C, :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(115), :('$char'(116), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(110), :('$char'(111), :('$char'(114), :('$char'(109), :('$char'(97), :('$char'(108), :('$char'(10), []))))))))))))))))))))))))) ], _FA, _GA ), '$$susp'( $++,  [ _C, :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(115), :('$char'(116), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(100), :('$char'(105), :('$char'(115), :('$char'(97), :('$char'(98), :('$char'(108), :('$char'(101), :('$char'(100), :('$char'(10), []))))))))))))))))))))))))))) ], _HA, _IA ) ], _JA, _KA ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkAnchor(_H), _F, _I),
        '$if_then'('$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(99), :('$char'(104), :('$char'(101), :('$char'(99), :('$char'(107), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), []))))))))))) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))) ], _N, _O ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))) ], _P, _Q ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))) ], _R, _S ), '$$susp'( '$$eqFun',  [ _A, :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(101), :('$char'(100), :('$char'(105), :('$char'(116), [])))))))) ], _T, _U ) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ) ], _DA, _EA ), '$$susp'( $++,  [ _C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(97), :('$char'(110), :('$char'(99), :('$char'(104), :('$char'(111), :('$char'(114), :('$char'(32), []))))))))))))))))))), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _FA, _GA ) ], _HA, _IA ) ], _JA, _KA ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkBackground(_H), _F, _I),
        $++(_J, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(98), :('$char'(97), :('$char'(99), :('$char'(107), :('$char'(103), :('$char'(114), :('$char'(111), :('$char'(117), :('$char'(110), :('$char'(100), :('$char'(32), []))))))))))))))))))))))), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _K, _L ) ], _M, _N ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkCmd(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, _O, _N, _P),
        '$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_O, _K, _B, _C, _H, _E, _P, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkHeight(_H), _F, _I),
        '$if_then'('$$susp'( '$not',  [ '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(114), :('$char'(121), []))))) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(97), :('$char'(103), :('$char'(101), []))))))) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _A, :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(98), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), [])))))))))) ], _N, _O ), '$$susp'( '$$eqFun',  [ _A, :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(108), :('$char'(101), []))))) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ), '$$susp'( $++,  [ _C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(104), :('$char'(101), :('$char'(105), :('$char'(103), :('$char'(104), :('$char'(116), :('$char'(32), []))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _H ], _Z, _AA ), :('$char'(10), []) ], _BA, _CA ) ], _DA, _EA ) ], _FA, _GA ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkInit(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 104, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 101, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 99, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 107, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 98, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 117, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 116, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 111, _PB, _QB),
        hnf(_MB, :(_RB, _SB), _QB, _TB),
        hnf(_RB, '$char'(_UB), _TB, _VB),
        hnf(_UB, 110, _VB, _WB),
        hnf(_SB, [], _WB, _XB),
        $++(:('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _C ], _YB, _ZB ), '$$susp'( $++,  [ :('$char'(32), :('$char'(34), [])), '$$susp'( $++,  [ _H, :('$char'(34), :('$char'(10), [])) ], _AC, _BC ) ], _CC, _DC ) ], _EC, _FC ), _E, _XB, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkItems(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 97, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 110, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 118, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 97, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 115, _RA, _SA),
        hnf(_OA, [], _SA, _TA),
        '$tkcitems2tcl'(_C, _H, _E, _TA, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkList(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 108, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 105, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 115, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 116, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 98, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 111, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 120, _XA, _YA),
        hnf(_UA, [], _YA, _ZA),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(100), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(48), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(10), [])))))))))))))), '$$susp'( '$setlistelems',  [ _H, _C ], _AB, _BB ) ], _CB, _DB ), _E, _ZA, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkMenu(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 109, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 101, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 110, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 117, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 98, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 117, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 116, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 111, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 110, _PB, _QB),
        hnf(_MB, [], _QB, _RB),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(32), []))))))))))))))))), '$$susp'( $++,  [ _C, '$$susp'( $++,  [ :('$char'(46), :('$char'(97), :('$char'(10), []))), '$$susp'( '$tkMenu2tcl',  [ '$$susp'( $++,  [ _C, :('$char'(46), :('$char'(97), [])) ], _SB, _TB ), _H ], _UB, _VB ) ], _WB, _XB ) ], _YB, _ZB ) ], _AC, _BC ), _E, _RB, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkRef(_H), _F, _I),
        '$if_then'('$$susp'( '$$eqFun',  [ _H, tkRefLabel(_B, '$$susp'( '$tkLabel2Refname',  [ _C ], _J, _K ), _A) ], _L, _M ), [], _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkText(_H), _F, _I),
        hnf(_A, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 104, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 101, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 99, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 107, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 98, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 117, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 116, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 111, _PB, _QB),
        hnf(_MB, :(_RB, _SB), _QB, _TB),
        hnf(_RB, '$char'(_UB), _TB, _VB),
        hnf(_UB, 110, _VB, _WB),
        hnf(_SB, [], _WB, _XB),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(120), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _H ], _YB, _ZB ), :('$char'(34), :('$char'(10), [])) ], _AC, _BC ) ], _CC, _DC ), _E, _XB, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkText(_H), _F, _I),
        $++(:('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))), '$$susp'( $++,  [ '$$susp'( '$tkLabel2Refname',  [ _C ], _J, _K ), '$$susp'( $++,  [ :('$char'(32), :('$char'(34), [])), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _H ], _L, _M ), :('$char'(34), :('$char'(10), [])) ], _N, _O ) ], _P, _Q ) ], _R, _S ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkWidth(_H), _F, _I),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(119), :('$char'(105), :('$char'(100), :('$char'(116), :('$char'(104), :('$char'(32), [])))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _H ], _J, _K ), :('$char'(10), []) ], _L, _M ) ], _N, _O ), _E, _I, _G).
'$tkConf2tcl_4'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_D, tkTcl(_H), _F, _I),
        $++(_C, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), []))))))))))), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _J, _K ) ], _L, _M ), _E, _I, _G).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 99, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 104, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 101, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 99, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 107, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 98, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 117, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 116, _XA, _YA),
        hnf(_UA, :(_ZA, _AB), _YA, _BB),
        hnf(_ZA, '$char'(_CB), _BB, _DB),
        hnf(_CB, 116, _DB, _EB),
        hnf(_AB, :(_FB, _GB), _EB, _HB),
        hnf(_FB, '$char'(_IB), _HB, _JB),
        hnf(_IB, 111, _JB, _KB),
        hnf(_GB, :(_LB, _MB), _KB, _NB),
        hnf(_LB, '$char'(_OB), _NB, _PB),
        hnf(_OB, 110, _PB, _QB),
        hnf(_MB, [], _QB, _RB),
        $++(_D, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))) ], _SB, _TB ) ], _UB, _VB ), _F, _RB, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 101, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 110, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 116, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 114, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 121, _FA, _GA),
        hnf(_CA, [], _GA, _HA),
        $++(:('$char'(98), :('$char'(105), :('$char'(110), :('$char'(100), :('$char'(32), []))))), '$$susp'( $++,  [ _D, '$$susp'( $++,  [ :('$char'(32), :('$char'(60), :('$char'(82), :('$char'(101), :('$char'(116), :('$char'(117), :('$char'(114), :('$char'(110), :('$char'(62), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))) ], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ), _F, _HA, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 115, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 99, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 97, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 108, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 101, _FA, _GA),
        hnf(_CA, [], _GA, _HA),
        $++(_IA, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(110), :('$char'(102), :('$char'(105), :('$char'(103), :('$char'(117), :('$char'(114), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(34), [])))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(125), :('$char'(10), []))) ], _JA, _KA ) ], _LA, _MA ), _F, _HA, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 108, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 105, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 115, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 116, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 98, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 111, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 120, _RA, _SA),
        hnf(_OA, [], _SA, _TA),
        $++(:('$char'(98), :('$char'(105), :('$char'(110), :('$char'(100), :('$char'(32), []))))), '$$susp'( $++,  [ _D, '$$susp'( $++,  [ :('$char'(32), :('$char'(60), :('$char'(66), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(80), :('$char'(114), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(45), :('$char'(49), :('$char'(62), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), []))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(125), :('$char'(10), []))) ], _UA, _VA ) ], _WA, _XA ) ], _YA, _ZA ), _F, _TA, _H).
'$tkConf2tcl_4_1_tkCmd_1.1_:_1.1.1_$char'(_A, _B, _C, _D, _E, _F, _G, _H):-
        unifyHnfs(_A, 116, _G, _I),
        hnf(_B, :(_J, _K), _I, _L),
        hnf(_J, '$char'(_M), _L, _N),
        hnf(_M, 101, _N, _O),
        hnf(_K, :(_P, _Q), _O, _R),
        hnf(_P, '$char'(_S), _R, _T),
        hnf(_S, 120, _T, _U),
        hnf(_Q, :(_V, _W), _U, _X),
        hnf(_V, '$char'(_Y), _X, _Z),
        hnf(_Y, 116, _Z, _AA),
        hnf(_W, :(_BA, _CA), _AA, _DA),
        hnf(_BA, '$char'(_EA), _DA, _FA),
        hnf(_EA, 101, _FA, _GA),
        hnf(_CA, :(_HA, _IA), _GA, _JA),
        hnf(_HA, '$char'(_KA), _JA, _LA),
        hnf(_KA, 100, _LA, _MA),
        hnf(_IA, :(_NA, _OA), _MA, _PA),
        hnf(_NA, '$char'(_QA), _PA, _RA),
        hnf(_QA, 105, _RA, _SA),
        hnf(_OA, :(_TA, _UA), _SA, _VA),
        hnf(_TA, '$char'(_WA), _VA, _XA),
        hnf(_WA, 116, _XA, _YA),
        hnf(_UA, [], _YA, _ZA),
        $++(:('$char'(98), :('$char'(105), :('$char'(110), :('$char'(100), :('$char'(32), []))))), '$$susp'( $++,  [ _D, '$$susp'( $++,  [ :('$char'(32), :('$char'(60), :('$char'(66), :('$char'(117), :('$char'(116), :('$char'(116), :('$char'(111), :('$char'(110), :('$char'(80), :('$char'(114), :('$char'(101), :('$char'(115), :('$char'(115), :('$char'(45), :('$char'(49), :('$char'(62), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), []))))))))))))))))))))))))))))))), '$$susp'( $++,  [ _D, :('$char'(34), :('$char'(125), :('$char'(10), []))) ], _AB, _BB ) ], _CB, _DB ) ], _EB, _FB ), _F, _ZA, _H).

% setlistelems
'$setlistelems'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$setlistelems_1'(_F, _B, _C, _G, _E).
'$setlistelems_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$setlistelems_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        $++(_B, '$$susp'( $++,  [ :('$char'(32), :('$char'(105), :('$char'(110), :('$char'(115), :('$char'(101), :('$char'(114), :('$char'(116), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(34), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _F ], _I, _J ), '$$susp'( $++,  [ :('$char'(34), :('$char'(10), [])), '$$susp'( '$setlistelems',  [ _G, _B ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).

% tkMenu2tcl
'$tkMenu2tcl'(_A, _B, _C, _D, _E):-
        $++(:('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(32), []))))), '$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(32), :('$char'(45), :('$char'(116), :('$char'(101), :('$char'(97), :('$char'(114), :('$char'(111), :('$char'(102), :('$char'(102), :('$char'(32), :('$char'(102), :('$char'(97), :('$char'(108), :('$char'(115), :('$char'(101), :('$char'(10), [])))))))))))))))), '$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(32), :('$char'(100), :('$char'(101), :('$char'(108), :('$char'(101), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(48), :('$char'(32), :('$char'(101), :('$char'(110), :('$char'(100), :('$char'(10), [])))))))))))))), '$$susp'( '$setmenuelems',  [ _B, 0.0 ], _F, _G ) ], _H, _I ) ], _J, _K ) ], _L, _M ) ], _N, _O ), _C, _D, _E).

% setmenuelems
'$setmenuelems'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$setmenuelems_1'(_F, _B, _C, _G, _E).
'$setmenuelems_1'(_A, _B, [], _C, _D):-
        unifyHnfs(_A, [], _C, _D).
'$setmenuelems_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, :(_F, _G), _D, _H),
        hnf(_F, _I, _H, _J),
        '$setmenuelems_1_1.1_:'(_I, _G, _B, _C, _J, _E).
'$setmenuelems_1_1.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, tkMButton(_G, _H), _E, _I),
        $++(_J, '$$susp'( $++,  [ :('$char'(32), :('$char'(97), :('$char'(100), :('$char'(100), :('$char'(32), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(45), :('$char'(76), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(34), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _H ], _K, _L ), '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(45), :('$char'(99), :('$char'(111), :('$char'(109), :('$char'(109), :('$char'(97), :('$char'(110), :('$char'(100), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(34), []))))))))))))))))))))))))), '$$susp'( $++,  [ _J, '$$susp'( $++,  [ :('$char'(46), []), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _C ], _M, _N ), '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))), '$$susp'( '$setmenuelems',  [ _B, '$$susp'( $+,  [ _C, 1.0 ], _O, _P ) ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ), _D, _I, _F).
'$setmenuelems_1_1.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, tkMSeparator, _E, _G),
        $++(_H, '$$susp'( $++,  [ :('$char'(32), :('$char'(97), :('$char'(100), :('$char'(100), :('$char'(32), :('$char'(115), :('$char'(101), :('$char'(112), :('$char'(97), :('$char'(114), :('$char'(97), :('$char'(116), :('$char'(111), :('$char'(114), :('$char'(10), []))))))))))))))), '$$susp'( '$setmenuelems',  [ _B, '$$susp'( $+,  [ _C, 1.0 ], _I, _J ) ], _K, _L ) ], _M, _N ), _D, _G, _F).
'$setmenuelems_1_1.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_A, tkMMenuButton(_G, _H), _E, _I),
        $++(_J, '$$susp'( $++,  [ :('$char'(32), :('$char'(97), :('$char'(100), :('$char'(100), :('$char'(32), :('$char'(99), :('$char'(97), :('$char'(115), :('$char'(99), :('$char'(97), :('$char'(100), :('$char'(101), :('$char'(32), :('$char'(45), :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(34), []))))))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _G ], _K, _L ), '$$susp'( $++,  [ :('$char'(34), :('$char'(32), :('$char'(45), :('$char'(109), :('$char'(101), :('$char'(110), :('$char'(117), :('$char'(32), [])))))))), '$$susp'( $++,  [ _J, '$$susp'( $++,  [ :('$char'(46), :('$char'(97), :('$char'(10), []))), '$$susp'( $++,  [ '$$susp'( '$tkMenu2tcl',  [ '$$susp'( $++,  [ _J, :('$char'(46), :('$char'(97), [])) ], _M, _N ), _H ], _O, _P ), '$$susp'( '$setmenuelems',  [ _B, '$$susp'( $+,  [ _C, 1.0 ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ) ], _Y, _Z ) ], _AA, _BA ) ], _CA, _DA ) ], _EA, _FA ), _D, _I, _F).

% tkConfs2handler
'$tkConfs2handler'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkConfs2handler_2'(_A, _F, _C, _G, _E).
'$tkConfs2handler_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$tkConfs2handler_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        hnf(_F, _I, _H, _J),
        '$tkConfs2handler_2_2.1_:'(_A, _I, _G, _C, _J, _E).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, :('$$tup'(','(_A, _D)), '$$susp'( '$tkConfs2handler',  [ _A, _C ], _E, _F )), _G, _H):-
        unifyHnfs(_B, tkCmd(_D), _G, _H).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkActive(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkAnchor(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkBackground(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkHeight(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkInit(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkItems(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkList(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkMenu(_G), _E, _H),
        $++('$$susp'( '$tkMenu2handler',  [ _A, _G, 0.0 ], _I, _J ), '$$susp'( '$tkConfs2handler',  [ _A, _C ], _K, _L ), _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkRef(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkText(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkWidth(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).
'$tkConfs2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, tkTcl(_G), _E, _H),
        '$tkConfs2handler'(_A, _C, _D, _H, _F).

% tkMenu2handler
'$tkMenu2handler'(_A, _B, _C, _D, _E, _F):-
        hnf(_B, _G, _E, _H),
        '$tkMenu2handler_2'(_A, _G, _C, _D, _H, _F).
'$tkMenu2handler_2'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_B, [], _D, _E).
'$tkMenu2handler_2'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_B, :(_G, _H), _E, _I),
        hnf(_G, _J, _I, _K),
        '$tkMenu2handler_2_2.1_:'(_A, _J, _H, _C, _D, _K, _F).
'$tkMenu2handler_2_2.1_:'(_A, _B, _C, _D, :('$$tup'(','('$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(46), :('$char'(97), :('$char'(46), []))), '$$susp'( '$intTostr',  [ _D ], _E, _F ) ], _G, _H ) ], _I, _J ), _K)), '$$susp'( '$tkMenu2handler',  [ _A, _C, '$$susp'( $+,  [ _D, 1.0 ], _L, _M ) ], _N, _O )), _P, _Q):-
        unifyHnfs(_B, tkMButton(_K, _R), _P, _Q).
'$tkMenu2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_B, tkMSeparator, _F, _H),
        '$tkMenu2handler'(_A, _C, '$$susp'( $+,  [ _D, 1.0 ], _I, _J ), _E, _H, _G).
'$tkMenu2handler_2_2.1_:'(_A, _B, _C, _D, _E, _F, _G):-
        unifyHnfs(_B, tkMMenuButton(_H, _I), _F, _J),
        $++('$$susp'( '$tkMenu2handler',  [ '$$susp'( $++,  [ _A, :('$char'(46), :('$char'(97), [])) ], _K, _L ), _I, 0.0 ], _M, _N ), '$$susp'( '$tkMenu2handler',  [ _A, _C, '$$susp'( $+,  [ _D, 1.0 ], _O, _P ) ], _Q, _R ), _E, _J, _G).

% tkConfs2tcl
'$tkConfs2tcl'(_A, _B, _C, _D, '$$tup'(','('$$susp'( '$$apply',  [ '$$susp'( '$concat',  [], _E, _F ), '$$susp'( '$map',  [ tkConf2tcl(_A, _B, _C), _D ], _G, _H ) ], _I, _J ), '$$susp'( '$tkConfs2handler',  [ _C, _D ], _K, _L ))), _M, _M).

% tkcitems2tcl
'$tkcitems2tcl'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkcitems2tcl_2'(_A, _F, _C, _G, _E).
'$tkcitems2tcl_2'(_A, _B, [], _C, _D):-
        unifyHnfs(_B, [], _C, _D).
'$tkcitems2tcl_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        $++('$$susp'( '$tkcitem',  [ _A, _F ], _I, _J ), '$$susp'( '$tkcitems2tcl',  [ _A, _G ], _K, _L ), _C, _H, _E).

% tkcitem
'$tkcitem'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$tkcitem_2'(_A, _F, _C, _G, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkLine(_F, _G), _D, _H),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(108), :('$char'(105), :('$char'(110), :('$char'(101), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ _F ], _I, _J ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _G, :('$char'(10), []) ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkPolygon(_F, _G), _D, _H),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(112), :('$char'(111), :('$char'(108), :('$char'(121), :('$char'(103), :('$char'(111), :('$char'(110), :('$char'(32), [])))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ _F ], _I, _J ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _G, :('$char'(10), []) ], _K, _L ) ], _M, _N ) ], _O, _P ) ], _Q, _R ), _C, _H, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkRectangle(_F, _G, _H), _D, _I),
        hnf(_F, '$$tup'(_J), _I, _K),
        hnf(_J, ','(_L, _M), _K, _N),
        hnf(_G, '$$tup'(_O), _N, _P),
        hnf(_O, ','(_Q, _R), _P, _S),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(114), :('$char'(101), :('$char'(99), :('$char'(116), :('$char'(97), :('$char'(110), :('$char'(103), :('$char'(108), :('$char'(101), :('$char'(32), [])))))))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ :('$$tup'(','(_L, _M)), :('$$tup'(','(_Q, _R)), [])) ], _T, _U ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ), _C, _S, _E).
'$tkcitem_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, tkOval(_F, _G, _H), _D, _I),
        hnf(_F, '$$tup'(_J), _I, _K),
        hnf(_J, ','(_L, _M), _K, _N),
        hnf(_G, '$$tup'(_O), _N, _P),
        hnf(_O, ','(_Q, _R), _P, _S),
        $++(_A, '$$susp'( $++,  [ :('$char'(32), :('$char'(99), :('$char'(114), :('$char'(101), :('$char'(97), :('$char'(116), :('$char'(101), :('$char'(32), :('$char'(79), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(32), []))))))))))))), '$$susp'( $++,  [ '$$susp'( '$tkShowCoords',  [ :('$$tup'(','(_L, _M)), :('$$tup'(','(_Q, _R)), [])) ], _T, _U ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ _H, :('$char'(10), []) ], _V, _W ) ], _X, _Y ) ], _Z, _AA ) ], _BA, _CA ), _C, _S, _E).

% tkShowCoords
'$tkShowCoords'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$tkShowCoords_1'(_E, _B, _F, _D).
'$tkShowCoords_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$tkShowCoords_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        hnf(_E, '$$tup'(_H), _G, _I),
        hnf(_H, ','(_J, _K), _I, _L),
        $++('$$susp'( '$intTostr',  [ _J ], _M, _N ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( $++,  [ '$$susp'( '$intTostr',  [ _K ], _O, _P ), '$$susp'( $++,  [ :('$char'(32), []), '$$susp'( '$tkShowCoords',  [ _F ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ), _B, _L, _D).

% tkLabel2Refname
'$tkLabel2Refname'(_A, _B, _C, _D):-
        '$map'(aux, _A, _B, _C, _D).

% aux
'$aux'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, '$char'(46) ], _E, _F ), '$char'(95), _A, _B, _C, _D).

% tkRefname2Label
'$tkRefname2Label'(_A, _B, _C, _D):-
        '$map'(aux1, _A, _B, _C, _D).

% aux1
'$aux1'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, '$char'(95) ], _E, _F ), '$char'(46), _A, _B, _C, _D).

% tks2tcl
'$tks2tcl'(_A, _B, _C, _D, '$$tup'(','(_E, _F)), _G, _H):-
        hnf(_D, _I, _G, _J),
        '$tks2tcl_4'(_A, _B, _C, _I, '$$tup'(','(_E, _F)), _J, _H).
'$tks2tcl_4'(_A, _B, _C, _D, '$$tup'(','([], [])), _E, _F):-
        unifyHnfs(_D, [], _E, _F).
'$tks2tcl_4'(_A, _B, _C, _D, '$$tup'(','('$$susp'( $++,  [ '$$susp'( '$fst',  [ '$$susp'( '$tk2tcl',  [ _A, '$$susp'( $++,  [ _B, :('$char'(46), :('$$susp'( '$chr',  [ _C ], _E, _F ), [])) ], _G, _H ), _I ], _J, _K ) ], _L, _M ), '$$susp'( '$fst',  [ '$$susp'( '$tks2tcl',  [ _A, _B, '$$susp'( $+,  [ _C, 1.0 ], _N, _O ), _P ], _Q, _R ) ], _S, _T ) ], _U, _V ), '$$susp'( $++,  [ '$$susp'( '$snd',  [ '$$susp'( '$tk2tcl',  [ _A, '$$susp'( $++,  [ _B, :('$char'(46), :('$$susp'( '$chr',  [ _C ], _W, _X ), [])) ], _Y, _Z ), _I ], _AA, _BA ) ], _CA, _DA ), '$$susp'( '$snd',  [ '$$susp'( '$tks2tcl',  [ _A, _B, '$$susp'( $+,  [ _C, 1.0 ], _EA, _FA ), _P ], _GA, _HA ) ], _IA, _JA ) ], _KA, _LA ))), _MA, _NA):-
        unifyHnfs(_D, :(_I, _P), _MA, _NA).

% tkslabels
'$tkslabels'(_A, _B, _C, _D, _E, _F):-
        hnf(_C, _G, _E, _H),
        '$tkslabels_3'(_A, _B, _G, _D, _H, _F).
'$tkslabels_3'(_A, _B, _C, [], _D, _E):-
        unifyHnfs(_C, [], _D, _E).
'$tkslabels_3'(_A, _B, _C, _D, _E, _F):-
        unifyHnfs(_C, :(_G, _H), _E, _I),
        $++('$$susp'( $++,  [ _A, :('$char'(46), :('$$susp'( '$chr',  [ _B ], _J, _K ), :('$char'(32), []))) ], _L, _M ), '$$susp'( '$tkslabels',  [ _A, '$$susp'( $+,  [ _B, 1.0 ], _N, _O ), _H ], _P, _Q ), _D, _I, _F).

% tkmain2tcl
'$tkmain2tcl'(_A, _B, '$$tup'(','('$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(123), :('$char'(108), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(115), :('$char'(32), :('$char'(34), :('$char'(58), :('$char'(69), :('$char'(86), :('$char'(84), :('$char'(36), :('$char'(108), :('$char'(34), :('$char'(32), :('$char'(125), :('$char'(10), [])))))))))))))))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(108), :('$char'(97), :('$char'(98), :('$char'(101), :('$char'(108), :('$char'(32), :('$char'(123), :('$char'(108), :('$char'(32), :('$char'(118), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(119), :('$char'(114), :('$char'(105), :('$char'(116), :('$char'(101), :('$char'(101), :('$char'(118), :('$char'(101), :('$char'(110), :('$char'(116), :('$char'(32), :('$char'(36), :('$char'(108), :('$char'(32), :('$char'(125), :('$char'(10), [])))))))))))))))))))))))))))))))))))))), '$$susp'( $++,  [ :('$char'(112), :('$char'(114), :('$char'(111), :('$char'(99), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(32), :('$char'(123), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(32), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(117), :('$char'(101), :('$char'(125), :('$char'(32), :('$char'(123), :('$char'(32), :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(115), :('$char'(32), :('$char'(34), :('$char'(58), :('$char'(86), :('$char'(65), :('$char'(82), :('$char'(36), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(37), :('$char'(91), :('$char'(115), :('$char'(116), :('$char'(114), :('$char'(105), :('$char'(110), :('$char'(103), :('$char'(32), :('$char'(108), :('$char'(101), :('$char'(110), :('$char'(103), :('$char'(116), :('$char'(104), :('$char'(32), :('$char'(36), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(117), :('$char'(101), :('$char'(93), :('$char'(42), :('$char'(36), :('$char'(118), :('$char'(97), :('$char'(108), :('$char'(117), :('$char'(101), :('$char'(34), :('$char'(125), :('$char'(10), []))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))), '$$susp'( '$fst',  [ '$$susp'( '$tk2tcl',  [ _A, [], _B ], _C, _D ) ], _E, _F ) ], _G, _H ) ], _I, _J ) ], _K, _L ), '$$susp'( '$snd',  [ '$$susp'( '$tk2tcl',  [ _A, [], _B ], _M, _N ) ], _O, _P ))), _Q, _Q).

% debugTcl
'$debugTcl'(_A, _B, _C, _D):-
        '$putStrLn'('$$susp'( '$fst',  [ '$$susp'( '$tkmain2tcl',  [ _E, _A ], _F, _G ) ], _H, _I ), _B, _C, _D).



% forkWish
'$forkWish'(_A, _B, _C, _D, _E):-
        '$do'( [ _F ], [ openWish(escape_tcl(_A)), writeWish(_F, _B) ],_C,_D,_E).

% runWidget
'$runWidget'(_A, _B, _C, _D, _E):-
        '$do'( [ _F ], [ openWish(escape_tcl(_A)), initSchedule(>>, done, _B, _F, aux4) ],_C,_D,_E).

% aux4
'$aux4'(_A, _B, _C, _D):-
        '$done'(_B, _C, _D).

% runWidgetInit
'$runWidgetInit'(_A, _B, _C, _D, _E, _F):-
        '$do'( [ _G ], [ openWish(escape_tcl(_A)), initSchedule(>>, done, _B, _G, _C) ],_D,_E,_F).

% runWidgetPassive
'$runWidgetPassive'(_A, _B, _C, _D, _E):-
        '$do'( [ _F, _G ], [ openWish(escape_tcl(_A)), writeWish(_F, fst(tkmain2tcl(_F, _B))), return(_F) ],_C,_D,_E).

% initSchedule
'$initSchedule'(_A, _B, _C, _D, _E, _F, _G, _H):-
        $>>('$$susp'( '$writeWish',  [ _D, '$$susp'( '$fst',  [ '$$susp'( '$tkmain2tcl',  [ _D, _C ], _I, _J ) ], _K, _L ) ], _M, _N ), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, '$$susp'( '$$apply',  [ _E, _D ], _O, _P ) ], _Q, _R ), '$$susp'( '$tkSchedule',  [ _A, _B, '$$susp'( '$snd',  [ '$$susp'( '$tkmain2tcl',  [ _D, _C ], _S, _T ) ], _U, _V ), _D ], _W, _X ) ], _Y, _Z ), _F, _G, _H).

% tkSchedule
'$tkSchedule'(_A, _B, _C, _D, _E, _F, _G):-
        $>>=('$$susp'( '$readWish',  [ _D ], _H, _I ), aux2(_A, _B, _C, _D), _E, _F, _G).

% aux2
'$aux2'(_A, _B, _C, _D, _E, _F, _G, _H):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _E, :('$char'(58), :('$char'(69), :('$char'(88), :('$char'(73), :('$char'(84), []))))) ], _I, _J ), '$$susp'( '$tkTerminateWish',  [ _B, _D ], _K, _L ), '$$susp'( '$if_then_else',  [ '$$susp'( '$$eqFun',  [ '$$susp'( '$take',  [ 4.0, _E ], _M, _N ), :('$char'(58), :('$char'(69), :('$char'(86), :('$char'(84), [])))) ], _O, _P ), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, '$$susp'( '$tkSelectEvent',  [ _B, '$$susp'( '$drop',  [ 4.0, _E ], _Q, _R ), _C, _D ], _S, _T ) ], _U, _V ), '$$susp'( '$tkSchedule',  [ _A, _B, _C, _D ], _W, _X ) ], _Y, _Z ), '$$susp'( '$$apply',  [ '$$susp'( '$$apply',  [ _A, '$$susp'( '$if_then',  [ '$$susp'( '$not',  [ '$$susp'( '$tkShowErrors',  [], _AA, _BA ) ], _CA, _DA ), _B ], _EA, _FA ) ], _GA, _HA ), '$$susp'( '$done',  [], _IA, _JA ) ], _KA, _LA ) ], _MA, _NA ), _F, _G, _H).

% tkTerminateWish
'$tkTerminateWish'(_A, _B, _C, _D, _E):-
        $>>('$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _B, :('$char'(101), :('$char'(120), :('$char'(105), :('$char'(116), [])))) ], _F, _G ), '$$susp'( '$closeWish',  [ _B ], _H, _I ) ], _J, _K ), _A, _C, _D, _E).

% tkSelectEvent
'$tkSelectEvent'(_A, _B, _C, _D, _E, _F, _G):-
        hnf(_C, :(_H, _I), _F, _J),
        hnf(_H, '$$tup'(_K), _J, _L),
        hnf(_K, ','(_M, _N), _L, _O),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _B, _M ], _P, _Q ), '$$susp'( '$$apply',  [ _N, _D ], _R, _S ), '$$susp'( '$tkSelectEvent',  [ _A, _B, _I, _D ], _T, _U ), _E, _O, _G).

% tkGetVar
'$tkGetVar'(_A, _B, _C, _D, _E, _F):-
        $>>('$$susp'( '$writeWish',  [ _B, '$$susp'( $++,  [ :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), :('$char'(32), []))))))), '$$susp'( $++,  [ _A, '$$susp'( $++,  [ :('$char'(32), :('$char'(91), :('$char'(103), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))))), '$$susp'( $++,  [ _A, :('$char'(93), []) ], _G, _H ) ], _I, _J ) ], _K, _L ) ], _M, _N ) ], _O, _P ), '$$susp'( '$tkGetVarMsg',  [ _A, _B, _C ], _Q, _R ), _D, _E, _F).

% tkGetVarMsg
'$tkGetVarMsg'(_A, _B, _C, _D, _E, _F):-
        '$do'( [ _G ], [ readWish(_B), aux3(_A, _B, _C, _G) ],_D,_E,_F).

% aux3
'$aux3'(_A, _B, _C, _D, _E, _F, _G):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ '$$susp'( '$takeWhile',  [ flip('$notEqFun', '$char'(37)), _D ], _H, _I ), '$$susp'( $++,  [ :('$char'(58), :('$char'(86), :('$char'(65), :('$char'(82), [])))), _A ], _J, _K ) ], _L, _M ), '$$susp'( '$do',  [ '.'(_C, []), '.'(tkGetVarValue(tkParseInt(tail(dropWhile(flip('$notEqFun', '$char'(37)), _D)), 0.0), tail(dropWhile(flip('$notEqFun', '$char'(42)), _D)), _B), '.'(done, [])) ], _N, _O ), '$$susp'( '$tkGetVarMsg',  [ _A, _B, _C ], _P, _Q ), _E, _F, _G).

% tkGetVarValue
'$tkGetVarValue'(_A, _B, _C, _D, _E, _F):-
        '$if_then_else'('$$susp'( $<,  [ '$$susp'( '$length',  [ _B ], _G, _H ), _A ], _I, _J ), '$$susp'( '$do',  [ '.'(_K, '.'(_L, [])), '.'(readWish(_C), '.'(tkGetVarValue(-(_A, +(length(_B), 1.0)), _K, _C), '.'(return(++(_B, ++(:('$char'(10), []), _L))), []))) ], _M, _N ), '$$susp'( '$if_then',  [ '$$susp'( '$not',  [ '$$susp'( '$and',  [ '$$susp'( $>,  [ '$$susp'( '$length',  [ _B ], _O, _P ), _A ], _Q, _R ), '$$susp'( '$tkShowErrors',  [], _S, _T ) ], _U, _V ) ], _W, _X ), '$$susp'( '$return',  [ _B ], _Y, _Z ) ], _AA, _BA ), _D, _E, _F).

% tkParseInt
'$tkParseInt'(_A, _B, _C, _D, _E):-
        hnf(_A, :(_F, _G), _D, _H),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _F, '$char'(42) ], _I, _J ), _B, '$$susp'( '$tkParseInt',  [ _G, '$$susp'( $-,  [ '$$susp'( $+,  [ '$$susp'( $*,  [ _B, 10.0 ], _K, _L ), '$$susp'( '$ord',  [ _F ], _M, _N ) ], _O, _P ), '$$susp'( '$ord',  [ '$char'(48) ], _Q, _R ) ], _S, _T ) ], _U, _V ), _C, _H, _E).

% checkWishConsistency
'$checkWishConsistency'(_A, _B, _C, _D, _E):-
        '$if_then'('$$susp'( '$$eqFun',  [ _A, _B ], _F, _G ), true, _C, _D, _E).

% escape_tcl
'$escape_tcl'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$escape_tcl_1'(_E, _B, _F, _D).
'$escape_tcl_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$escape_tcl_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        '$if_then_else'('$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(91) ], _H, _I ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(93) ], _J, _K ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(36) ], _L, _M ), '$$susp'( $\/,  [ '$$susp'( '$$eqFun',  [ _E, '$char'(34) ], _N, _O ), '$$susp'( '$$eqFun',  [ _E, '$char'(92) ], _P, _Q ) ], _R, _S ) ], _T, _U ) ], _V, _W ) ], _X, _Y ), :('$char'(92), :(_E, '$$susp'( '$escape_tcl',  [ _F ], _Z, _AA ))), :(_E, '$$susp'( '$escape_tcl',  [ _F ], _BA, _CA )), _B, _G, _D).

% tkVoid
'$tkVoid'(_A, _B, _C, _D):-
        '$done'(_B, _C, _D).

% tkExit
'$tkExit'(_A, _B, _C, _D):-
        $>>('$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _A, :('$char'(112), :('$char'(117), :('$char'(116), :('$char'(115), :('$char'(32), :('$char'(34), :('$char'(58), :('$char'(69), :('$char'(88), :('$char'(73), :('$char'(84), :('$char'(34), [])))))))))))) ], _E, _F ), '$$susp'( '$writeWish',  [ _A, :('$char'(101), :('$char'(120), :('$char'(105), :('$char'(116), [])))) ], _G, _H ) ], _I, _J ), '$$susp'( '$done',  [], _K, _L ), _B, _C, _D).

% tkGetValue
'$tkGetValue'(_A, _B, _C, _D, _E):-
        hnf(_A, tkRefLabel(_F, _G, _H), _D, _I),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _F, _B ], _J, _K ), '$$susp'( $>>,  [ '$$susp'( '$tkGetVar',  [ _G, _B, _L ], _M, _N ), '$$susp'( '$return',  [ _L ], _O, _P ) ], _Q, _R ), _C, _I, _E).

% tkSetValue
'$tkSetValue'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, tkRefLabel(_G, _H, _I), _E, _J),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _G, _C ], _K, _L ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _C, '$$susp'( $++,  [ :('$char'(115), :('$char'(101), :('$char'(116), :('$char'(118), :('$char'(97), :('$char'(114), [])))))), '$$susp'( $++,  [ _H, '$$susp'( $++,  [ :('$char'(32), :('$char'(34), [])), '$$susp'( $++,  [ '$$susp'( '$escape_tcl',  [ _B ], _M, _N ), :('$char'(34), []) ], _O, _P ) ], _Q, _R ) ], _S, _T ) ], _U, _V ) ], _W, _X ), '$$susp'( '$done',  [], _Y, _Z ) ], _AA, _BA ), _D, _J, _F).

% tkUpdate
'$tkUpdate'(_A, _B, _C, _D, _E, _F):-
        '$do'( [ _G ], [ tkGetValue(_B, _C), tkSetValue(_B, '$apply'(_A, _G), _C) ],_D,_E,_F).

% tkConfig
'$tkConfig'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, tkRefLabel(_G, _H, _I), _E, _J),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _G, _C ], _K, _L ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _C, '$$susp'( '$tkConf2tcl',  [ _I, _G, '$$susp'( '$tkRefname2Label',  [ _H ], _M, _N ), _B ], _O, _P ) ], _Q, _R ), '$$susp'( '$done',  [], _S, _T ) ], _U, _V ), _D, _J, _F).

% tkFocus
'$tkFocus'(_A, _B, _C, _D, _E):-
        hnf(_A, tkRefLabel(_F, _G, _H), _D, _I),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _F, _B ], _J, _K ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _B, '$$susp'( $++,  [ :('$char'(102), :('$char'(111), :('$char'(99), :('$char'(117), :('$char'(115), :('$char'(32), [])))))), '$$susp'( '$tkRefname2Label',  [ _G ], _L, _M ) ], _N, _O ) ], _P, _Q ), '$$susp'( '$done',  [], _R, _S ) ], _T, _U ), _C, _I, _E).

% tkAddCanvas
'$tkAddCanvas'(_A, _B, _C, _D, _E, _F):-
        hnf(_A, tkRefLabel(_G, _H, _I), _E, _J),
        '$if_then'('$$susp'( '$checkWishConsistency',  [ _G, _C ], _K, _L ), '$$susp'( $>>,  [ '$$susp'( '$writeWish',  [ _C, '$$susp'( '$tkConf2tcl',  [ _I, _G, '$$susp'( '$tkRefname2Label',  [ _H ], _M, _N ), tkItems(_B) ], _O, _P ) ], _Q, _R ), '$$susp'( '$done',  [], _S, _T ) ], _U, _V ), _D, _J, _F).


% 14/09/00 mercedes
% Es un nuevo error para las variables mutables. No se puede crear una variable
% sin instanciar y no se puede escribir en una variable algo que no este
%instanciado.
errPrim1:-
    nl,
    write('RUNTIME ERROR: The variable must be instantiated.'),
    nl,
    !,
    fail.
