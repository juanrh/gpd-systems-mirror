


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%  BEGIN OF CFLPFDFILE %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% B Sonia
%:- load_files(dyn,[if(changed),imports([ prop_active/0 ])]).
%:- load_files(toycomm,[if(changed)]). %,imports([toSolverFD/3,listToSolverFD/3])]).

:- tools:complete_root_filename(dyn,F),load_files(F,[if(changed),imports([ prop_active/0 ])]).
:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed),imports([toSolverFD/3,listToSolverFD/3])]).
:- dyn:clpr_active, !, tools:complete_root_filename(cooperation,F),load_files(F,[if(changed)]).

%% E Sonia

%%%%%%%%%%%%%%%%  CFLPFD CONSTRAINTS   %%%%%%%%%%%%%%%%%%%%%%%%

:- use_module(library(clpfd)).
:- use_module(library(ordsets)).
:- use_module(library(lists)).

%%  B :: Sonia
:- assert(clpfd:full_answer).
:- use_module(library(clpr)).
%%  E :: Sonia

% Determining the maximum upper and minimum lower bounds of
% finite domains, 
% independent of SICStus version and platform.

narrow(Val0, Val) :-
    clpfd:fd_integer(Val0), !,
    Val = Val0.
narrow(Val0, Val) :-
    Val1 is Val0>>1,
    narrow(Val1, Val).

:-  Min0 is -1<<64,
    narrow(Min0, Min),
    Max0 is (1<<64)-1,
    narrow(Max0, Max),
    assert(cflpfd:inf(Min)),
    assert(cflpfd:sup(Max)).



/**************    CODE FOR FUNCTIONS    **************/

%%%%%%%%%%%%%%%%%%% MEMBERSHIP CONSTRAINTS %%%%%%%%%%%%%%%%%%%%%%

% Sonia B

% comento todo el domain y lo escribo de nuevo con las modificaciones

/*

% domain :: [int] -> int -> int -> bool
% domain :=: [in] -> in -> in -> inout
'$domain'(VL, Low, Upp, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error(domain,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
        hnf(Low, HLow, Cout1, Cout2), 
        hnf(Upp, HUpp, Cout2, Cout), 
        HLow1 is integer(HLow), 
        HUpp1 is integer(HUpp), 
        ((Out=true, domain(PrologHVL, HLow1, HUpp1))
         ;
         (Out=false, HLow2 is integer(HLow1 - 1), HUpp2 is integer(HUpp1 + 1), 
          domain_remove(PrologHVL, HLow2, HUpp2))). 
*/

% domain :: [int] -> int -> int -> bool
% domain :=: [in] -> in -> in -> inout
'$domain'(VL, Low, Upp, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        toyListToPrologList(HVL, PrologHVL), 
        hnf(Low, HLow, Cout1, Cout2), 
        hnf(Upp, HUpp, Cout2, Cout3), 
        HLow1 is integer(HLow), 
        HUpp1 is integer(HUpp), 
        HLowR is float(HLow1), 
        HUppR is float(HUpp1),
        listToSolverFD(PrologHVL,Cout3,Cout4),
        ((Out=true, domain(PrologHVL, HLow1, HUpp1),
        (prop_active -> (changeDomainR(PrologHVL, HLowR, HUppR,Cout4,Cout),!); Cout = Cout4))
         ;
         (Out=false, HLow2 is integer(HLow1 - 1), HUpp2 is integer(HUpp1 + 1), 
          domain_remove(PrologHVL, HLow2, HUpp2) )). 

changeDomainR([], HLowR, HUppR,C, C).

changeDomainR([H|Rest], HLowR, HUppR,Cin, Cout):-
    searchVarsR(H,Cin,Cout1,HR), 
    {HR >= HLowR, HR =< HUppR},
    changeDomainR(Rest, HLowR, HUppR,Cout1, Cout).
% Sonia E

domain_remove([], _HLow2, _HUpp2). 
domain_remove([X|Xs], HLow2, HUpp2) :- 
        X in (inf..HLow2) \/ (HUpp2..sup), 
        domain_remove(Xs, HLow2, HUpp2).


subset(X, Y) +:
  X in dom(Y)/\dom(X).

setcomplement(X, Y) +:
  X in \dom(Y).

% subset :: int -> int -> bool
% subset :=: inout -> inout -> inout
'$subset'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, subset(HL, HR));
         (Out=false, setcomplement(HL, HR))). 
 
% inset :: int -> int -> bool
% inset :=: inout -> inout -> inout
'$inset'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, fd_set(HR, SR), HL in_set SR);
         (Out=false, fd_set(HR, SR), fdset_complement(SR, CSR), HL in_set CSR)). 
 
% setcomplement :: int -> int -> bool
% setcomplement :=: inout -> inout -> inout
'$setcomplement'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, setcomplement(HL, HR));
         (Out=false, subset(HL, HR))). 

% intersect :: int -> int -> int
% intersect :=: inout -> inout -> inout
'$intersect'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        fd_set(HR, SR), 
        fd_set(HL, SL), 
        fdset_intersection(SR, SL, SI), 
        Out in_set SI.
 
% sonia B
/* 

% belongs :: int -> [int] -> bool
% belongs :=: inout -> [in] -> inout
'$belongs'(V, L, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(L, HL, Cout1, Cout), 
        (var(HL) -> raise_exception(instatiation_error(belongs,2)); true),
        toyListToPrologList(HL, PL), 
        list_to_fdset(PL, PS), 
        ((Out=true, HV in_set PS);
         (Out=false, fdset_complement(PS, CPS), HV in_set CPS)).
*/

'$belongs'(V, L, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(L, HL, Cout1, Cout2), 
        toyListToPrologList(HL, PL), 
        list_to_fdset(PL, PS), 
        toSolverFD(HV,Cout2,Cout3),
        listToSolverFD(PL,Cout3,Cout4),
        (( Out=true, HV in_set PS, 
         (prop_active -> (searchVarsR(HV,Cout4,Cout,HVR), 
                     min_list(PL, HLowR),
                     max_list(PL,HUppR),
                     {HVR >= HLowR}, {HVR =< HUppR},!
                   )
                   ;
                   Cout =Cout4
        )
        )
        ;
          ( Out=false, fdset_complement(PS, CPS), HV in_set CPS)
       ).
% sonia E
         

%%%%%%%%%%%%%%%%%%% ENUMERATION FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% labeling :: [labelingType] -> [int] -> bool
% labeling :=: inout -> [inout] -> inout
'$labeling'(OL, VL, true, Cin, Cout) :- 
        nf(OL, HOL, Cin, Cout1), 
        toyListToPrologList(HOL, PrologHOL), 
%B::Sonia        
%        nf(VL, HVL, Cout1, Cout), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
        listToSolverFD(PrologHVL,Cout2,Cout),
%E::Sonia        
        processLabelingOptions(PrologHOL, LabPrologHOL), 
        labeling(LabPrologHOL, PrologHVL), 
        translateLabOptions(LabToyHOL, LabPrologHOL), 
        toyNonVarListToPrologList(OL, LabToyHOL).


processLabelingOptions(TLs, PLs) :- 
        setof(TLs, validLabOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateLabOptions(TLs, PLs).


memberU(X, [X|Xs]).
memberU(X, [Y|Xs]) :- memberU(X, Xs).

removeU_duplicates(L, S) :- 
        removeU_duplicates(L, [], S). % List, GrowingNonDuplicatesList, Set

removeU_duplicates([], In, In).
removeU_duplicates([X|Xs], In, Set) :- 
        nonU_member(X, In), !, append(In, [X], NIn), !, 
        removeU_duplicates(Xs, NIn, Set).
removeU_duplicates([_|Xs], In, Set) :- 
        removeU_duplicates(Xs, In, Set).


nonU_member(_, []) :- !.
nonU_member(X, [X|_]) :- 
        !, fail.
nonU_member(X, [Y|Ys]) :- 
        \+ X=Y, 
        nonU_member(X, Ys).


validLabOptions(Opts) :- 
        (groundL1(Opts) -> buildGroundLabOptSet(OptSet) ; buildLabOptSet(OptSet)), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).

groundL1(L) :- 
        L == [], !.
groundL1([H|T]) :- 
        ((ground(H) ; nonvar(H)) -> groundL1(T)).


ordU_subset([], _).
ordU_subset([H|T1], [H|T2]) :- ordU_subset(T1, T2).
ordU_subset([H1|T1], [H2|T2]) :- lt(H2, H1), ordU_subset([H1|T1], T2).

lt(X, Y) :- var(X); var(Y).
lt(X, Y) :- nonvar(X), nonvar(Y), X @< Y.


buildLabOptSet(OptSet) :- 
        ordU_member(G1, [ff, ffc, leftmost, maxi, mini]), 
        ordU_member(G2, [bisect, down, enum, step, up]), 
        ordU_member(G3, [assumptions(K)]), 
        list_to_ord_set([G1, G2, G3], OptSet).

buildGroundLabOptSet(OptSet) :- 
        ordU_member(G1, [ff, ffc, leftmost, maxi, mini]), 
        ordU_member(G2, [bisect, down, enum, step, up]), 
        ordU_member(G3, [each(X), toMaximize(Y), toMinimize(Z)]), 
        ordU_member(G4, [assumptions(K)]), 
        list_to_ord_set([G1, G2, G3, G4], OptSet).


ordU_member(X, [X|_T]).
ordU_member(X, [Y|T]) :- lt(Y, X), ordU_member(X, T).

translateLabOptions([], []) :- !.
translateLabOptions([mini|As], [min|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([maxi|As], [max|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([toMinimize(X)|As], [minimize(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([toMaximize(X)|As], [maximize(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
   %%Antonio Ojo, 'each' se traduce a 'all'
translateLabOptions([each(X)|As], [all(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([Option|As], [Option|Bs]) :- 
        !, translateLabOptions(As, Bs).


% indomain :: int -> bool
% indomain :=: inout -> inout
'$indomain'(I, true, Cin, Cout) :- 
%B::Sonia
%         hnf(I, HI, Cin, Cout), 
         hnf(I, HI, Cin, Cout1), 
         toSolverFD(HI,Cout1,Cout),
%E::Sonia
         indomain(HI).

% fdminimize
'$fdminimize'(B, I, true, Cin, Cout) :- 
         hnf(B, HB, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         minimize(HB, HI).

%%%%Antonio 17/01/02 20:00
%%%%%%%%%%%%% OJO, no funciona exactamente como en SICSTus (comprobar)
% fdmaximize
'$fdmaximize'(B, I, true, Cin, Cout) :- 
         hnf(B, HB, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         maximize(HB, HI).


%%%%%%%%%%%%%% RELATIONAL CONSTRAINTS  %%%%%%%%%%%%%%%%%

%% B Sonia
/*      comento todo y lo reescribo de nuevo   
        
% #= :: int -> int -> bool
% #= :=: inout -> inout -> inout
$#=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #=  HR);
         (Out=false, HL #\= HR)). 
       
% #\= :: int -> int -> bool
% #\= :=: inout -> inout -> inout
$#\=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #\= HR);
         (Out=false, HL #=  HR)). 
      
% #< :: int -> int -> bool
% #< :=: inout -> inout -> inout
$#<(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #<  HR);
         (Out=false, HL #>= HR)). 

% #<= :: int -> int -> bool
% #<= :=: inout -> inout -> inout
$#<=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #=< HR);
         (Out=false, HL #> HR)). 
    
% #> :: int -> int -> bool
% #> :=: inout -> inout -> inout
$#>(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #> HR);
         (Out=false, HL #=< HR)). 

% #>= :: int -> int -> bool
% #>= :=: inout -> inout -> inout
$#>=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #>= HR);
         (Out=false, HL #< HR)). 

FIN DE LA PARTE COMENTADA */

% #>
% #>
$#>(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #>  HR);
       (Out=false, HL #=< HR)), 
    (prop_active -> (
         searchVarsR(HL,Cout4,Cout5,HLR), 
         searchVarsR(HR,Cout5,Cout,HRR),
         ((Out == true, { HLR > HRR },!);
          (Out == false, { HLR =< HRR },!)
         )
        ); Cout=Cout4
    ). 


% #<
$#<(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #<  HR);
       (Out=false, HL #>= HR)),       
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR < HRR },!);
         (Out == false, { HLR >= HRR },!)
        )
        ); Cout=Cout4
    ). 


% #>=
$#>=(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #>= HR);
       (Out=false, HL #< HR)),
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR >= HRR },!);
         (Out == false, { HLR < HRR },!)
        )
        ); Cout=Cout4
    ). 

% #<=
$#<=(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #=< HR);
       (Out=false, HL #> HR)),
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR =< HRR },!);
         (Out == false, { HLR > HRR },!)
        )
        ); Cout=Cout4
    ). 

%% E Sonia

  
%%%%%%%%%%%%%%%% ARITHMETIC CONSTRAINT OPERATORS %%%%%%%%%%%%%%%%%%%%%%

%% B Sonia
/*  comento todo y lo reescribo de nuevo  

% #+ :: int -> int -> int
% #+ :=: inout -> inout -> inout
$#+(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL + HR #= O.
 
% #- :: int -> int -> int
% #- :=: inout -> inout -> inout
$#-(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL - HR #= O.       

% #* :: int -> int -> int
% #* :=: inout -> inout -> inout
$#*(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL * HR #= O.
        
% #/ :: int -> int -> int
% #/ :=: inout -> inout -> inout
$#/(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL / HR #= O.

% #& :: int -> int -> int
% #& :=: inout -> inout -> inout
$#&(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL mod HR #= O. 

FIN DE LA PARTE COMENTADA*/
    
% #+
$#+(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL + HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR + HRR = OR }
        ); Cout=Cout5 
    ).

% #-
$#-(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL - HR #= O,   
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR - HRR = OR }
        ); Cout=Cout5 
    ).

% #*
$#*(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL * HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR * HRR = OR }
        ); Cout=Cout5 
    ).

% #/
$#/(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL / HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR / HRR = OR }
        ); Cout=Cout5 
    ).

%% E Sonia   

% #& :: int -> int -> int
% #& :=: inout -> inout -> inout
$#&(L, R, O, Cin, Cout) :- 
     hnf(L, HL, Cin, Cout1), 
     hnf(R, HR, Cout1, Cout2), 
     toSolverFD(HL,Cout2,Cout3),
     toSolverFD(HR,Cout3,Cout4),
     toSolverFD(O,Cout4,Cout),
     HL mod HR #= O.

%%%%%%%%%%%%%%%%%%% ARITHMETIC CONSTRAINTS  %%%%%%%%%%%%%%%%%%%%%

% sum :: [int] -> (int -> int -> bool) -> int -> bool
% sum :=: [inout] -> inout -> inout
'$sum'(VL, Op, O, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error(sum,1)); true),
        hnf(Op, HOp, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%::B Sonia
%        nf(O,HO,Cout2,Cout),    
        nf(O,HO,Cout2,Cout3),    
        toSolverFD(HO,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout),
%::E Sonia
        ((Out=true, relOp(Op), sum(PrologHVL, HOp, HO));
         (Out=false, negRelOp(HOp, HNOp), sum(PrologHVL, HNOp, HO))). 

% scalar_product :: [int] -> [int] -> (int -> int -> bool) -> int -> bool
% scalar_product :=: [inout] -> [inout] -> inout -> inout -> inout
'$scalar_product'(VL1, VL2, Op, O, Out, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        (var(HVL1) -> raise_exception(instatiation_error(scalar_product,1)); true),
        nf(VL2, HVL2, Cout1, Cout2), 
        (var(HVL2) -> raise_exception(instatiation_error(scalar_product,2)); true),
        hnf(Op, HOp, Cout2, Cout3), 
%B:: Sonia        
%        nf(O, HO, Cout3, Cout), 
        nf(O, HO, Cout3, Cout4), 
%E:: Sonia        
        toyListToPrologList(HVL1, PrologHVL1), 
        toyListToPrologList(HVL2, PrologHVL2), 
%B:: Sonia        
        listToSolverFD(PrologHVL1,Cout4,Cout5),
        listToSolverFD(PrologHVL2,Cout5,Cout6),
        toSolverFD(HO,Cout6,Cout),
%E:: Sonia        
        ((Out=true, relOp(Op), scalar_product(PrologHVL1, PrologHVL2, HOp, HO));
         (Out=false, negRelOp(HOp, HNOp), scalar_product(PrologHVL1, PrologHVL2, HNOp, HO))). 
        
        
        
%%%%%%%%%%%%%%%%%%% COMBINATORIAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%

% all_different :: [int] ->  bool
% all_different :=: [inout] ->  inout
'$all_different'(VL, true, Cin, Cout) :- 
%B:: Sonia        
%        nf(VL, HVL, Cin, Cout), 
        nf(VL, HVL, Cin, Cout1), 
%E:: Sonia        
        (var(HVL) -> raise_exception(instatiation_error(all_different,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout1,Cout),
%E:: Sonia        

        all_different(PrologHVL).


% all_different' :: [int] -> [options] -> bool
% all_different' :=: [inout] ->  inout ->  inout
'$all_different\''(VL, OL, true, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error('all_different\'',1)); true),
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
%        nf(OL, HOL, Cout1, Cout), 
        nf(OL, HOL, Cout1, Cout2), 
%E:: Sonia        
        toyListToPrologList(HOL, PrologHOL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout2,Cout),
%E:: Sonia        
        processDiffOptions(PrologHOL, DiffPrologHOL), 
        all_different(PrologHVL, DiffPrologHOL), 
        translateDiffOptions(DiffToyHOL, DiffPrologHOL), 
        toyNonVarListToPrologList(OL, DiffToyHOL).

processDiffOptions(TLs, PLs) :- 
        setof(TLs, validDiffOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateDiffOptions(TLs, PLs).

validDiffOptions(Opts) :- 
        buildDiffOptSet(OptSet), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).

buildDiffOptSet(OptSet) :- 
        ordU_member(G1, [on(value), on(domain), on(range)]), 
        ordU_member(G2, [complete(true), complete(false)]), 
        list_to_ord_set([G1, G2], OptSet).

translateDiffOptions([], []) :- !.
translateDiffOptions([domains|As], [domain|Bs]) :- 
        !, translateDiffOptions(As, Bs).
translateDiffOptions([Option|As], [Option|Bs]) :- 
        !, translateDiffOptions(As, Bs).


       
% assignment :: [int] -> [int] -> bool
% assignment :=: [inout] -> [inout] -> inout
'$assignment'(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        (var(HVL1) -> raise_exception(instatiation_error(assignment,1)); true),
        toyListToPrologList(HVL1, PrologHVL1), 
%B:: Sonia        
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
%B:: Sonia        
        (var(HVL2) -> raise_exception(instatiation_error(assignment,2)); true),
        toyListToPrologList(HVL2, PrologHVL2), 
%B:: Sonia        
        listToSolverFD(PrologHVL1,Cout2,Cout3),
        listToSolverFD(PrologHVL2,Cout3,Cout),
%E:: Sonia        
        assignment(PrologHVL1, PrologHVL2).
        

% circuit :: [int] -> bool
% circuit :=: [inout] -> inout
'$circuit'(VL, true, Cin, Cout) :- 
%B:: Sonia        
%        nf(VL, HVL, Cin, Cout), 
        nf(VL, HVL, Cin, Cout1), 
%E:: Sonia        
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout1,Cout),
%E:: Sonia        
        circuit(PrologHVL).

% circuit' :: [int] -> [int] -> bool
% circuit' :=: [inout] -> [inout] -> inout
'$circuit\''(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
%B:: Sonia        
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
        listToSolverFD(PrologHVL1,Cout2,Cout),
%E:: Sonia        
        toyListToPrologList(HVL2, PrologHVL2), 
        circuit(PrologHVL1, PrologHVL2).


% count :: int -> [int] -> (int -> int -> bool) ->  int -> bool
% count :: in -> inout -> inout -> inout -> inout
'$count'(V, VL, Op, O, true, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        (var(HV) -> raise_exception(instatiation_error(count,1)); true),
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(Op, HOp, Cout2, Cout), 
        hnf(Op, HOp, Cout2, Cout3),
        toSolverFD(HV,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout5),
        toSolverFD(O,Cout5,Cout),
%E::Sonia
        relOp(HOp), 
        count(HV, PrologHVL, HOp, O),
        toyListToPrologList(HVL, PrologHVL).

       
% element :: int -> [int] -> int -> bool
% element :=: inout -> [inout] -> inout -> inout
'$element'(I, VL, V, true, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout1), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(V, HV, Cout2, Cout), 
        hnf(V, HV, Cout2, Cout3),
        toSolverFD(HI,Cout3,Cout4),
        toSolverFD(HV,Cout4,Cout5),
        listToSolverFD(PrologHVL,Cout5,Cout),
%E::Sonia
        element(HI, PrologHVL, HV).
        
% exactly :: int -> [int] -> int -> bool
% exactly :=: inout -> inout -> inout -> inout
'$exactly'(NEle, VL, N, true, Cin, Cout) :- 
        hnf(NEle, HNEle, Cin, Cout1), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(N, HN, Cout2, Cout), 
        hnf(N, HN, Cout2, Cout3), 
        toSolverFD(HNEle,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout5),
        toSolverFD(HNEle,Cout5,Cout),        
%E::Sonia
        exactly(HNEle, PrologHVL, HN),
        toyListToPrologList(HVL, PrologHVL). 

exactly(_, [], 0).
exactly(X, [Y|L], N) :- 
        X #=Y #<=> B, 
        N #= M + B, 
        exactly(X, L, M).


% serialized :: [int] -> [int] -> bool
% serialized :=: [inout] -> [inout] -> inout
'$serialized'(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
%B::Sonia
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
%E::Sonia
        toyListToPrologList(HVL2, PrologHVL2), 
%B::Sonia
        listToSolverFD(PrologHVL1,Cout2,Cout3),
        listToSolverFD(PrologHVL2,Cout3,Cout),
%E::Sonia
        serialized(PrologHVL1, PrologHVL2).


% 'serialized\'' :: [int] -> [int] -> [serialOptions] -> bool
% 'serialized\'' :=: [inout] -> [inout] -> inout -> inout
'$serialized\''(VL1, VL2, OL, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
        nf(VL2, HVL2, Cout1, Cout2), 
        toyListToPrologList(HVL2, PrologHVL2), 
        nf(OL, HOL, Cout2, Cout3), 
        toyListToPrologList(HOL, PrologHOL), 
        processSchedulingOptions(PrologHOL, SchedPrologHOL, Cout3, Cout4), 
        serialized(PrologHVL1, PrologHVL2, SchedPrologHOL), 
%B::Sonia
%        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout4, Cout), 
        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout4, Cout5),       
        listToSolverFD(PrologHVL1,Cout5,Cout6),
        listToSolverFD(PrologHVL2,Cout6,Cout),
%E::Sonia
        toyNonVarListToPrologList(OL, SchedToyHOL).


% cumulative :: [int] ->  [int] ->  [int] -> int  -> bool
% cumulative :=: [inout] -> [inout] -> [inout] -> inout -> inout
'$cumulative'(SL, DL, RL, LIM, true, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout1), 
        toyListToPrologList(HSL, PrologHSL), 
        nf(DL, HDL, Cout1, Cout2), 
        toyListToPrologList(HDL, PrologHDL), 
        nf(RL, HRL, Cout2, Cout3), 
        toyListToPrologList(HRL, PrologHRL), 
        hnf(LIM, HLIM, Cout3, Cout4), 
%B::Sonia
%        hnf(LIM, HLIM, Cout3, Cout), 
        hnf(LIM, HLIM, Cout3, Cout4), 
        listToSolverFD(PrologHSL,Cout4,Cout5),
        listToSolverFD(PrologHDL,Cout5,Cout6),
        listToSolverFD(PrologHRL,Cout6,Cout7),
        toSolverFD(HLIM,Cout7,Cout),
%E::Sonia
        cumulative(PrologHSL, PrologHDL, PrologHRL, HLIM).

% 'cumulative\'' :: [int] ->  [int] ->  [int] -> int  -> [serialOptions] -> bool
% 'cumulative\'' :=: [inout] -> [inout] -> [inout] -> inout -> inout -> inout
'$cumulative\''(SL, DL, RL, Lim, OL, true, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout1), 
        toyListToPrologList(HSL, PrologHSL), 
        nf(DL, HDL, Cout1, Cout2), 
        toyListToPrologList(HDL, PrologHDL), 
        nf(RL, HRL, Cout2, Cout3), 
        toyListToPrologList(HRL, PrologHRL), 
        hnf(Lim, HLim, Cout3, Cout4), 
        nf(OL, HOL, Cout4, Cout5), 
        toyListToPrologList(HOL, PrologHOL), 
        processSchedulingOptions(PrologHOL, SchedPrologHOL, Cout5, Cout6), 
        cumulative(PrologHSL, PrologHDL, PrologHRL, HLim, SchedPrologHOL), 
%B::Sonia
%        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout6, Cout), 
        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout6, Cout7), 
        listToSolverFD(PrologHSL,Cout7,Cout8),
        listToSolverFD(PrologHDL,Cout8,Cout9),
        listToSolverFD(PrologHRL,Cout9,Cout10),
        toSolverFD(HLim,Cout10,Cout),
%E::Sonia
        toyNonVarListToPrologList(OL, SchedToyHOL).

 
processSchedulingOptions(TLs, PLs, Cin, Cout) :- 
        setof(TLs, validSchedOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateSchedOptions(TLs, PLs, Cin, Cout).


validSchedOptions(Opts) :- 
        (groundL1(Opts) -> buildGroundSchedOptSet(OptSet) ; buildSchedOptSet(OptSet)), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).


buildSchedOptSet(OptSet) :- 
        OptSet = [
                  decomposition(true), 
                  edge_finder(true), 
                  path_consistency(true), 
                  static_sets(true)
                 ]. % This must be an ordered list

buildGroundSchedOptSet(OptSet) :- 
        OptSet = [
                  decomposition(true), 
                  edge_finder(true), 
                  path_consistency(true), 
                  precedences(L), 
                  static_sets(true)
                 ]. % This must be an ordered list


translateSchedOptions([], [], C, C) :- !.
translateSchedOptions([precedences(T)|Ls], [precedences(T1)|Lss], Cin, Cout) :- 
        !, hnf(T, TT, Cin, Cout1), 
        toyListToPrologList(TT, TTT), 
        process_precedences(TTT, T1), 
        translateSchedOptions(Ls, Lss, Cout1, Cout).
translateSchedOptions([Option|As], [Option|Bs], Cin, Cout) :- 
        !, translateSchedOptions(As, Bs, Cin, Cout).


process_precedences([], []).
process_precedences([d('$$tup'((I1, I2, I3)))|Ls], [d(I1, I2, O3)|Lss]) :- 
        !, process_value(I3, O3), 
        process_precedences(Ls, Lss).
process_precedences([X|Ls], [X|Lss]) :- process_precedences(Ls, Lss).

process_value(lift(I3), I3).
process_value(superior, sup).


%%%%%%%%%%%%%%%%%%% PROPOSITIONAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%

% #\/  :: bool -> bool -> bool
% #\/  :=: inout -> inout -> inout
$#\/(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #\/ HRINT.

% #<=> :: bool -> bool -> bool
% #<=> :=: inout -> inout -> inout
$#<=>(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #<=> HRINT.

% #=> :: bool -> bool -> bool
% #=> :=: inout -> inout -> inout
$#=>(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #=> HRINT.


%%%%%%%%%%%%%%%%%%% REFLECTION FUNCTIONS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% fd_var :: int -> bool
% fd_var :=: inout -> inout
'$fd_var'(V, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        (fd_var(HV) -> Out = true; Out=false).
        
% fd_min :: int -> int
% fd_min :=: inout -> inout
'$fd_min'(I, Min, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout), 
        fd_min(HI, Min).

% fd_max :: int -> int
% fd_max :=: inout -> inout
'$fd_max'(I, Max, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout), 
        fd_max(HI, Max).

% fd_size :: int -> int
% fd_size :=: inout -> inout
'$fd_size'(V, S, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_size(HV, S).

% fd_set :: int -> fdset
% fd_set :=: inout -> inout
'$fd_set'(V, S, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_set(HV, PS), 
        toySetToPrologSet(S, PS).

% fd_dom :: int -> range
% fd_dom :=: inout -> inout
'$fd_dom'(V, R, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_dom(HV, PR), 
        toyRangeToPrologRange(R, PR).

% fd_degree :: int -> int
% fd_degree :=: inout -> inout
'$fd_degree'(V, I, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_degree(HV, I).
       
% fd_neighbors :: int -> [int]
% fd_neighbors :=: inout -> inout
'$fd_neighbors'(V, L, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_neighbors(HV, PL),
        toyListToPrologList(L, PL).          
        
% fd_closure :: [int] -> [int]
% fd_neighbors :=: [inout] -> [inout]
'$fd_closure'(L1, L2, Cin, Cout) :- 
        nf(L1, HL1, Cin, Cout), 
        (var(HL1) -> raise_exception(instatiation_error(fd_closure,1)); true),
        toyListToPrologList(HL1, PHL1), 
        fd_closure(PHL1, PL2), 
        toyListToPrologList(L2, PL2).
        
% sup :: int
% sup :=: {}
'$sup'(X, Cin, Cin) :- cflpfd:sup(X).

% inf :: int
% inf :: {}
'$inf'(X, Cin, Cin) :- cflpfd:inf(X).


%%%%%%%%%%%%%%%%%%% FD SET FUNCTIONS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% is_fdset :: fdset -> bool
% is_fdset :=: in -> inout
'$is_fdset'(S, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS,PS),
        (is_fdset(PS) -> Out = true; Out = false).     
        
% empty_fdset :: fdset -> bool
% empty_fdset :=: inout -> inout
'$empty_fdset'(S, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        ((Out=true, empty_fdset(HS), Cout1=Cout); 
         (Out=false, (var(HS) -> notEqualVar(HS,[],Cout1,Cout) ) ) ).

% fdset_parts :: int -> int -> fdset -> fdset
% fdset_parts :=: in  -> in  -> in  -> inout
'$fdset_parts'(Min, Max, P, S, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout2), 
        nf(P, HP, Cout2, Cout), 
        toySetToPrologSet(HP, PP),
        fdset_parts(PS, HMin, HMax, PP),
        toySetToPrologSet(S, PS).

% fdset_split :: fdset -> (int -> int -> fdset)
% fdset_split :=: in  -> (inout -> inout -> inout)
'$fdset_split'(S, '$$tup'(','(Min, ','(Max, P))), Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        toySetToPrologSet(HS, PS),
        fdset_parts(PS, Min, Max, PP),
        toySetToPrologSet(P, PP).

% empty_interval :: int -> int -> bool
% empty_interval :=: in -> in -> inout
'$empty_interval'(Min, Max, Out, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout), 
        (var(HMin) -> raise_exception(instatiation_error(empty_interval,1)); true),
        (var(HMax) -> raise_exception(instatiation_error(empty_interval,2)); true),
        (empty_interval(HMin, HMax) -> Out = true; Out = false).

% fdset_to_interval :: fdset -> (int, int)
% fdset_to_interval :=: in -> (inout, inout)
'$fdset_to_interval'(S, '$$tup'(','(Min, Max)), Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_interval(PS, Min, Max).

% interval_to_fdset :: int -> int -> fdset
% interval_to_fdset :=: in -> in -> inout
'$interval_to_fdset'(Min, Max, S, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout), 
        (var(HMin) -> raise_exception(instatiation_error(interval_to_fdset,1)); true),
        (var(HMax) -> raise_exception(instatiation_error(interval_to_fdset,2)); true),
        fdset_interval(PS, HMin, HMax), 
        toySetToPrologSet(S, PS).

% fdset_singleton :: fdset -> int -> bool
% fdset_singleton :=: {in -> out -> out, out -> in -> out}
'$fdset_singleton'(S, E, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(E, HE, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        (fdset_singleton(PS, HE) -> 
         (Out = true, toySetToPrologSet(HS, PS)); 
         Out = false).

% fdset_min :: fdset -> int 
% fdset_min :=: in -> inout
'$fdset_min'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_min(PS, I).
        
% fdset_max :: fdset -> int
% fdset_max :=: in -> inout
'$fdset_max'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_max(PS, I).

% fdset_size :: fdset -> int
% fdset_size :=: in -> inout
'$fdset_size'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_size(PS, I).
     
% list_to_fdset :: [int] -> fdset
% list_to_fdset :=: in -> inout
'$list_to_fdset'(L, S, Cin, Cout) :- 
        nf(L, HL, Cin, Cout),
        toyListToPrologList(HL, PHL), 
        list_to_fdset(PHL, PS), 
        toySetToPrologSet(S, PS).
        
% fdset_to_list :: fdset -> [int]
% fdset_to_list :=: in -> inout
'$fdset_to_list'(S, L, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS), 
        fdset_to_list(PS, PL), 
        toyListToPrologList(L, PL).

% range_to_fdset :: range -> fdset
% range_to_fdset :=: in -> inout
'$range_to_fdset'(R, S, Cin, Cout) :- 
        nf(R, HR, Cin, Cout), 
        toyRangeToPrologRange(HR, PR), 
        range_to_fdset(PR, PS), 
        toySetToPrologSet(S, PS).

% fdset_to_range :: fdset -> range
% fdset_to_range :=: in -> inout
'$fdset_to_range'(S, R, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS), 
        fdset_to_range(PS, PR), 
        toyRangeToPrologRange(R, PR).

% fdset_add_element :: fdset -> int -> fdset 
% fdset_add_element :=: in -> in -> inout
'$fdset_add_element'(S, I, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(I, HI, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_add_element(PS, HI, PO),
        toySetToPrologSet(O, PO). 

% fdset_del_element :: fdset -> int -> fdset 
% fdset_del_element :=: in -> in -> inout
'$fdset_del_element'(S, I, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(I, HI, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_del_element(PS, HI, PO),
        toySetToPrologSet(O, PO). 

% fdset_intersection :: fdset -> fdset -> fdset
% fdset_intersection :=: in -> in -> inout
'$fdset_intersection'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_intersection(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_subtract :: fdset -> fdset -> fdset
% fdset_subtract :=: in -> in -> inout
'$fdset_subtract'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_subtract(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_union :: fdset -> fdset -> fdset
% fdset_union :=: in -> in -> inout
'$fdset_union'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_union(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_complement :: fdset -> fdset
% fdset_complement :=: in -> inout
'$fdset_complement'(S, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_complement(PS, PO),
        toySetToPrologSet(O, PO). 

% fdsets_intersection :: [fdset] -> fdset
% fdsets_intersection :=: in -> inout
'$fdsets_intersection'(SL, O, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout), 
        toyListSetToPrologListSet(HSL, PSL),
        fdset_intersection(PSL, PO),
        toySetToPrologSet(O, PO). 

% fdsets_union :: [fdset] -> fdset
% fdsets_union :=: in -> inout
'$fdsets_union'(SL, O, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout), 
        toyListSetToPrologListSet(HSL, PSL),
        fdset_union(PSL, PO),
        toySetToPrologSet(O, PO).

% fdset_equal :: fdset -> fdset-> bool
% fdset_equal :=: in -> in -> inout
'$fdset_equal'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_eq(PS1, PS2) -> Out = true; Out = false).

% fdset_subset :: fdset -> fdset-> bool
% fdset_subset :=: in -> in -> inout
'$fdset_subset'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_subset(PS1, PS2) -> Out = true; Out = false).

% fdset_disjoint :: fdset -> fdset-> bool
% fdset_disjoint :=: in -> in -> inout
'$fdset_disjoint'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_disjoint(PS1, PS2) -> Out = true; Out = false).
  
% fdset_intersect :: fdset -> fdset-> bool
% fdset_intersect :=: in -> in -> inout
'$fdset_intersect'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_intersect(PS1, PS2) -> Out = true; Out = false).

% fdset_member :: int -> fdset -> bool
% fdset_member :=: inout -> in -> inout
'$fdset_member'(V, S, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(S, HS, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        ((Out = true, fdset_member(HV, PS)); 
         Out = false).

% fdset_belongs :: int -> int -> bool
% fdset_belongs :=: inout -> in -> inout
'$fdset_belongs'(X, Y, Out, Cin, Cout) :- 
        hnf(X, HX, Cin, Cout1), 
        hnf(Y, HY, Cout1, Cout), 
        fd_set(HY, PS),
        ((Out = true, fdset_member(HX, PS)); 
         Out = false).


traduction(domm(X), dom(X)).
traduction(minn(X), min(X)).
traduction(maxx(X), max(X)).
traduction(vall(X), val(X)).
traduction(minmax(X), minmax(X)).

traduce_list([], []).
traduce_list([X|Xs], [Y|Ys]) :- traduction(X, Y), traduce_list(Xs, Ys).

traduce_args([], []).
traduce_args([X:Xs|Rs], [Y|Ys]) :- toyListToPrologList(X:Xs, Y), !, 
        traduce_args(Rs, Ys).
traduce_args([X|Rs], [X|Ys]) :- traduce_args(Rs, Ys).

% fd_global
%'$fd_global'(_A, _B, _C, true, _D, _E) :- 
%        hnf(_A, _A1, _D, _F), 
%
%        hnf(_B, _BB, _F, _I), %%_B = st('$$tup'((Args)))
%        _BB=..[st, Tuple], 
%         printf("\n Tuple = %w \n", [Tuple]), 
%        Tuple =..['$$tup', Ar], %% Tuple = '$$tup'(Args)
%        printf("\n Ar = %w \n", [Ar]), 
%        Ar =..[C|Args], %% C = '.', 
%         printf("\n Args = %w \n", [Args]), 
%        traduce_args(Args, PrologArgs), 
%         printf("\n PrologArgs = %w \n", [PrologArgs]), 
%        _B1  =..[st|PrologArgs], 
%        
%        hnf(_C, _CC, _I, _E), 
%        toyListToPrologList(_CC, CCC), 
%        printf("\n Las variables son _AA = %w \n  _BB = %w \n  _CC = %w \n", [_AA, _BB, _CC]), 
%        printf("\n                                        PrologCC = %w \n", [PrologCC]), 
%        traduce_list(CCC, C1), 
%        printf("\n Las variables son _A1 = %w \n  _B1 = %w \n  _C1 = %w \n", [_A1, _B1, C1]), 
%        fd_global(_A1, _B1, C1).   

% fd_global
'$fd_global'(_A, _B, _C, _O, _D, _E) :- 
        hnf(_A, _A1, _D, _F), 
        hnf(_B, _BB, _F, _I), %%_B = st('$$tup'((Args)))
        _BB=..[st, Tuple], 
        Tuple =..['$$tup', Ar], %% Tuple = '$$tup'(Args)
        Ar =..[C|Args], %% C = '.', 
        traduce_args(Args, PrologArgs), 
        _B1  =..[st|PrologArgs], 
        hnf(_C, _CC, _I, _E), 
        toyListToPrologList(_CC, CCC), 
        traduce_list(CCC, C1), 
        printf("\n Las variables son _A1 = %w \n  _B1 = %w \n  _C1 = %w \n", [_A1, _B1, C1]), 
        fd_global(A1, _B1, C1).   


%%%%%%%%%%%%%%%%%%% INDEXICAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%%%%%

% isin
'$isin'(_A, _B, true, _C, _D) :- 
        hnf(_B, '$$tup'(_E), _C, _F), 
        hnf(_E, ', '(_G, _H), _F, _F1), 
        hnf(_G, _GG, _F1, _F2), 
        hnf(_H, _HH, _F2, _F3), 
        hnf(_A, _AA, _F3, _D), 
        lanzar(_AA, _GG, _HH).
        
lanzar(_AA, _GG, _HH)+:        
        _GG=..[min, _YY], 
        _AA in min(_YY).._HH.
        
%%:- use_module(library(charsio)).        

%infixl mini  
%infix(<<<, left, 11).
%%

% minimum
'$minimum'(_A, min(_AA), _C, _D) :- 
        hnf(_A, _AA, _C, _C1), 
        printf("\n Las variables son _AA = %w\n", [_AA]).


%%%%%%%%%%%%%%%%%%% STATISTICS FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%

% fd_statistics' :: statistics -> int
% fd_statistics' :=: inout -> inout
'$fd_statistics\''(S, I, Cin, Cout) :- 
         hnf(S, HS, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         fd_statistics(HS, HI).

% 'fd_statistics' :: bool
% 'fd_statistics' :=: inout
'$fd_statistics'(true, Cin, Cin) :- 
         fd_statistics.


%%%%%%%%%%%% Auxiliary Predicates   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%float_to_int(F,I) :- freeze(F, I is integer(F)), freeze(I, F is float(I)).

bool_to_int(B, I) :- 
        freeze(B, (B = false -> I = 0 ; I = 1)), 
        freeze(I, (I = 0 -> B = false ; B = true)).


relOp(Op) :- negRelOp(Op, _).

negRelOp(#=, #\=).
negRelOp(#\=, #=).
negRelOp(#<, #>=).
negRelOp(#<=, #>).
negRelOp(#>, #<=).
negRelOp(#>=, #<).



/*
hnfList(L, HL, Cin, Cout) :- 
        (var(L) -> L = HL, Cin = Cout; hnfListR(L, HL, Cin, Cout)).

hnfListR([], [], C, C).
hnfListR(H:T, NH:NT, Cin, Cout) :- 
        hnf(H, NH, Cin, Cout1), 
        hnfListR(T, NT, Cout1, Cout).


%% Prolog FD Sets come implemented as lists of [Min|Max] elements
%% Toy FD Sets are implemented as Toy lists of (interval Min Max) elements


hnfSet(S, HS, Cin, Cout) :- 
        (var(S) -> S = HS, Cin = Cout; hnfSetR(S, HS, Cin, Cout)).

hnfSetR([], [], C, C) :- !.
hnfSetR(:(interval(Min,Max), T), :(interval(HMin,HMax), HT), Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout2), 
        hnfSetR(T, HT, Cout2, Cout).


% Prolog FD Ranges come implemented as conjunctions (R1/\R2), disjunctions (R1\/R2), 
%   and complement (\R) of ranges, where a range can also be a constant range (Min..Max)
% Toy FD Ranges are implemented as unions (uni(R1,R2)), intersections (inter(R1,R2)), 
%   and complement (compl(R)) of ranges, where a range can also be a constant range (cte(Min,Max))

hnfRange(R, HR, Cin, Cout) :- 
        (var(R) -> R = HR, Cin = Cout; hnfRangeR(R, HR, Cin, Cout)).

hnfRangeR(cte(Min, Max), cte(HMin, HMax), Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1),
        hnf(Max, HMax, Cout1, Cout), !.
hnfRangeR(uni(R1, R2), uni(HR1, HR2), Cin, Cout) :- 
        hnfRange(R1, HR1, Cin, Cout1), 
        hnfRange(R2, HR2, Cout1, Cout), !.
hnfRangeR(inter(R1, R2), inter(HR1, HR2), Cin, Cout) :- 
        hnfRange(R1, HR1, Cin, Cout1), 
        hnfRange(R2, HR2, Cout1, Cout), !.
hnfRangeR(compl(R), compl(HR), Cin, Cout) :- 
        hnfRange(R, HR, Cin, Cout), !.

*/


toyListSetToPrologListSet(TSL, PSL) :-
        (var(TSL), var(PSL) -> true; toyNonVarListSetToPrologListSet(TSL, PSL)).

toyNonVarListSetToPrologListSet([], []) :- !.
toyNonVarListSetToPrologListSet(TS:R, [PS|RR]) :- 
        toyNonVarSetToPrologSet(TS, PS),
        toyNonVarListSetToPrologListSet(R, RR).


toySetToPrologSet(TS, PS) :- 
        (var(TS), var(PS) -> true; toyNonVarSetToPrologSet(TS, PS)).
toyNonVarSetToPrologSet([], []) :- !.
toyNonVarSetToPrologSet(:(interval(Min,Max),TT), [[IMin|IMax]|PT]) :- 
        IMin = Min,
        IMax = Max,
        toyNonVarSetToPrologSet(TT, PT).

hnf_recursive(S, HS, Cin, Cout) :-
        (var(S) -> Cin=Cout; hnf_recursiveNonVar(S, HS, Cin, Cout)).

hnf_recursiveNonVar([], [], C, C) :- !.
hnf_recursiveNonVar(_B, [[_F|_G] | _Resto], Cin, Cout) :- 
        hnf(_T, interval(_F, _G), Cin, Cout1), 
        hnf_recursive(_R, _Resto, Cout1, Cout2), !, 
        hnf(_B, :(_T, _R), Cout2, Cout).
        

toyRangeToPrologRange(TR, PR) :- 
        (var(TR), var(PR) -> true; toyNonVarRangeToPrologRange(TR, PR)).
toyNonVarRangeToPrologRange(cte(Min, Max), Min..Max) :- !.
toyNonVarRangeToPrologRange(uni(TR1, TR2), PR1 \/ PR2) :- 
        toyRangeToPrologRange(TR1, PR1), 
        toyRangeToPrologRange(TR2, PR2), !.
toyNonVarRangeToPrologRange(inter(TR1, TR2), PR1 /\ PR2) :- 
        toyRangeToPrologRange(TR1, PR1), 
        toyRangeToPrologRange(TR2, PR2), !.
toyNonVarRangeToPrologRange(compl(TR), PC, Cin, Cout) :- 
        PC=..[\, PR],
        toyRangeToPrologRange(TR, PR), !.



%------      LISTS              ---------------------------------

%% Translates a Toy list (such as 1:2:3:[]) into a Prolog list ([1, 2, 3])
toyListToPrologList(Ts, Ps) :- (var(Ts), var(Ps) -> true; toyNonVarListToPrologList(Ts, Ps)).

toyNonVarListToPrologList([], []) :- !.
toyNonVarListToPrologList(A:R, [A|RR]) :- toyNonVarListToPrologList(R, RR).


% nonmember/2
nonmember(_X, []).
nonmember(X, [X|_Ys]) :- !, fail.
nonmember(X, [_Y|Ys]) :- !, nonmember(X, Ys).

%-----------------------------------------------------------------------
%-----------------------------------------------------------------------
%-----------------------------------------------------------------------
%------      INPUT/OUTPUT              ---------------------------------


%------------------- Predicates for I/O ---------------------------------------------

%------------------- Predicates for formatting ---------------------------------------

%------------------- printf: formatted ouput ----------------------------------------

% All the output generated by the program uses this printf
% procedure.

% control chars '\.'



printf([92, 110|F], Ts) :- !, nl, printf(F, Ts).  % 92, 110 = \n
printf([92, 116|F], Ts) :- !, put(9), printf(F, Ts).  % 92, 116 = \t
printf([92, 92|F], Ts) :- !, put(92), printf(F, Ts).  % 92, 92 = \\
printf([92, 37|F], Ts) :- !, put(37), printf(F, Ts).  % 92, 37 = \%
printf([92, 34|F], Ts) :- !, put(34), printf(F, Ts).  % 92, 34 = \"

% format chars '%.'

printf([37, 119|F], [T|Ts]) :- !, write_term(T, [portrayed(true)]), printf(F, Ts).  % 37, 119 = %w
printf([37, 113|F], [T|Ts]) :- !, writeq(T, [portrayed(true)]), printf(F, Ts).  % 37, 113 = %q
printf([37, 100|F], [T|Ts]) :- !, display(T), printf(F, Ts).  % 37, 100 = %d
printf([37, 115|F], [T|Ts]) :- !, puts(T), printf(F, Ts).  % 37, 115 = %s
printf([37, 118|F], [V, T|Ts]) :- !, nameTermVars(T, V, Tn), printf(F, [Tn|Ts]). % 37, 118 = %v

% plain chars '.'

printf([Ch|F], Ts) :- !, put(Ch), printf(F, Ts).

printf([], _).

printf(F) :- printf(F, []).

puts([]).
puts([Ch|S]) :- put(Ch), puts(S).


%%NEW11 To print the list L (including elements as 'X'=A) in the predicate solve.
print_list([]) :- !.
%%print_list([X=A|L]) :- X\==A, printf("    %w = %w \n", [X, A]), print_list(L).
%%print_list([X=A|L]) :- X==A, print_list(L).
print_list([(X=A)|L]) :- ground(A), 
        printf("    %w = %w \n", [X, A]), 
        print_list(L), !, 
        assert(sol(true)).   %% Indicates that a semi-solution is found
print_list([(_X=_A)|L]) :- print_list(L).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  END OF CFLPFDFILE %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
