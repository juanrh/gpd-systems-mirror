%-----------------------------------------------------------------------------%
% initToy.pl
%-----------------------------------------------------------------------------%
/*
- Author: Jaime
- Description: Reconoce lo que se escribe en el prompt: objetivos, comandos o 
  una expresion para evaluar.
  Se implementa el proceso de lanzamiento de un objetivo una vez que este ha 
  sido analizado sintacticamente.
- Modules which import it: toy
- Imported modules:
    > process: con el predicado 'do' (si el comando es run(File) o 
      load(File), se hace un do(File,Error) que procesa el fichero), con
      'deletePredsComp' y con 'consult'.
    > goals (con el predicado 'writeFail', 'writeSolution' y
      'askIfMore').
    > transob (con 'readGoal'): en initToy se lee lo que se escribe en
      el prompt, por tanto se llama a readGoal que devuelve $Command si
      el primer caracter es una / (lo que hay en el prompt es un comando, no
      un objetivo). En este caso solo se deja leida la /. En otro caso se
      lee el objetivo entero.
    > tools (con 'eliminateWhites', 'smooth', 'append', 'extractNameExtension').
    > dyn.
    > plgenerated (con 'funct', 'hnf_susp', '$$apply', 'infix' y las funciones
      nuevas que se generan).
    > evalexp (con 'tryExpression').
    > dds (con 'tree' y 'paint').
    > 'toy.ini' (con 'command').
    > inferrer.pl (con 'goalType'): antes de nada, hay que tipar el 
      objetivo.
    > transfun.pl: con 'transCheckConstra' (antes de lanzar el objetivo hay que
      hacer una traduccion de este para transformar los terminos de la forma 
      '$var'('X') a X. Como el objetivo son restricciones de igualdad o de 
      desigualdad, eso se hace con transCheckConstra) y con 
      'traslateCheckRules'.
    > codfun.pl (con 'doConstra'): las restricciones de igualdad y desigualdad 
      se traducen en los predicados equal y notEqual respectivamente. Para 
      hacer esto se usa doConstra. Tambien con 'optimizeEq'.
    > toycomm.
    > writing (con 'writeAtom/1').
    > outgenerated (con 'fun').
    > osystem (con 'saveState').
        
- Modified:
     30/09/99 mercedes (the predicates have been commented)
     05/10/99 mercedes (Separacion de las restricciones 
                           sobre reales del nucleo).
         26/10/99 mercedes (modules).
         17/11/99 mercedes (Se ha introducido la opcion de ejecucion en modo de 
                   evaluacion simple (para expresiones deterministas 
                   cerradas). Es decir, TOY ahora ademas de executer 
                   comandos y resolver objetivos, tambien evalua 
                   expresiones. Para evaluar una expresion en TOY se
                   pone: > expresion
                   Para ello los cambios que se han hecho son: en 
                   'processCommand' he puesto:
                   Type=='$Expression', !, tryExpression(Goal);
                   Ademas 'processCommand' ahora tiene 3 argumentos.
         22/11/99 mercedes (Se ha llevado a cabo la optimizacion de la igualdad 
                   propuesta por Rafa. Hasta ahora, si teniamos:
                   f(X) = g(Y) <== Y == h(X)
                   lo que hacia Y == h(X) era ira calculando las fnc de 
                   Y y de h(X) e ir comparandolas poco a poco.
                   Se ha comprobado que si tenemos
                   f(Args1) = g(Args2) <== Condiciones, Y==T (o T==Y)
                   donde Y es una variable, Y no aparece en Args1, 
                   tampoco aparece en Condiciones y tampoco aparece en T,
                   entonces es mas eficiente resolver esa igualdad 
                   haciendo la forma normal de T y compararla con Y.
                   Y si podria aparacer en Args2.
                   Esta optimizacion tambien hay que hacerla en los 
                   objetivos.
                   Para hacer esta optimizacion en los objetivos los 
                   cambios que se han hecho son: en 'processGoal' 
                   despues de doConstra, se llama a un predicado 
                   optimizeEq que lo que hace es comprobar si es una de 
                   las igualdades que se pueden optimizar y si es asi 
                   cambia la restriccion equal por equalnf que lo que 
                   hace es llevar a cabo la igualdad de la nueva forma.
                   Esto es para optimizar la igualdad en los objetivos.
     26/11/99 mercedes (Introduccion de las restricciones sobre los reales 
               al nucleo. Para ello se han introducido como posibles
               comandos: /cflpr. y /nocflpr. Ademas se han 
               introducido los predicados loadClpr y unloadClpr.
               Ademas en saveState se ha vuelto a meter 
               primitivesClpr.pl).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(initToy,[initiate/0,convertGoalToExecutableCode/5,throwConstraints/1,
          removeWhereVars/3,eval/1,solve/1,typeOf/1,process/1,debug/1,showHelp/0]).


:- load_files(process,[if(changed),imports([do/2,check/2,deletePredsComp/0,consult/2])]).

:- load_files(goals,[if(changed),imports([writeFail/0,writeSolution/3,
          askIfMore/4])]).

:- load_files(transob,[if(changed),imports([readGoal/3,transGoal/4])]).

:- load_files(tools,[if(changed),imports([eliminateWhites/2, append/3,
              extractNameExtension/3, concatLsts/2, member/2,endFile/2
%F010204
              ,complete_root_filename/2,root_path/1,include_path/1
             ])]).

:- load_files(dyn,[if(changed),imports([incNAnswer/0,resetNAnswer/0,debugando/0,
                   createRunTimeStatistics/0,typeError/0,clpr_active/0,varmut/2,
                   getLastCommand/1,putLastCommand/1, io_active/0,iographic_active/0,
                   retractfile/3,getRunTimeStatisticsLevel/1,assertRunTimeStatisticsLevel/1,
                   cflpfd_active/0,assertcflpfd_active/0, assertclpr_active/0,
%% B Sonia
                   prop_active/0,assertprop_active/0,
%% E Sonia
                   assertio_active/0,retractio_active/0, my_abolish/1,assertiographic_active/0,
                   development_version/0, setTot/1,setCut/1, retractalltypeError/0])]).


:- load_files(basic,[if(changed),imports([funct/5,hnf_susp/5,'$$apply'/5,
              infix/3,sourceFileNameStr/1])]).
% Depu 02/11/00 mercedes
% Importamos sourceFileNameStr para poder sacar el nombre del fichero que lo 
% necesitamos para la depuracion
% Fin Depu
             
:- load_files(evalexp,[if(changed),imports([tryExpression/1])]).

/*              
Lo que se hace es cargar inicialmente el fichero basic.pl que contiene el modulo
plgenerated inicial, pero cuando se genere un fichero.pl y se cargue (en el modulo
process), como lo generamos como modulo plgenerated, se borra el modulo 
plgenerated antiguo y se carga este nuevo.
*/

:- load_files(dds,[if(changed),imports([tree/3,paint/2])]).
              
          
:- load_files('toy.ini',[if(changed),imports([command/4])]).
              
:- load_files(transfun,[if(changed),imports([traslateCheckRules/3,
          transCheckConstra/4,transCheckWhere/4,change_wheres/4])]).

:- load_files(codfun,[if(changed),imports([doConstra/5,optimizeEq/3,
                       doWhere/3,
                       extract_left_hand_side_Where/3])]).
                    

:- load_files(inferrer,[if(changed),imports([goalType/2,expressionType/4])]).

:- load_files(toycomm,[if(changed)]).

%F0606 For giving access to the Toy version number
:- load_files(toy,[if(changed),imports([toyversion/1])]).

:- load_files(writing,[if(changed),imports([writeAtom/1])]).

:- load_files(newout,[if(changed),imports([fun/4])]).

/* Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.
*/

:- load_files(osystem,[if(changed),imports([ /*saveState/1,*/ goodFiles/0,
               loadFilesIo/3,loadFilesGra/3,loadFilesClpr/3,loadFilesDefault/3])]).

:- load_files(transdebug,[if(changed),imports([startDebuggingProcess/4])]).

:- (
    clpr_active,!,load_files(primitivCodClpr,[if(changed)])
   ;
    load_files(primitivCod,[if(changed)])
   ).

:- (
    io_active,!,load_files(primitivCodIo,[if(changed)])
   ;
    1==1
   ).

:- (
    iographic_active,!,load_files(primitivCodGra,[if(changed)])
   ;
    1==1
   ).



:- use_module(library(system)).

:- use_module(library(clpr)).

% F016062006 The following is for building prolog terms from strings (needed by the new command /prolog(String))
:- use_module(library(charsio),[read_from_chars/2]). 

/*

    MODULO PPAL DEL COMPILADOR

    En este modulo se describe el interfaz con el usuario que puede lanzar
objetivos y comandos (para compilar, executer, etc).

Desde el prompt se reconocen dos tipos de ordenes:
    - Las que empiezan por /. Son opciones para compilar y executer 
programas. Para salir es /q. Deben acabar en punto, puesto que se tratan como 
predicados prolog.
    - El resto se entienden como objetivos del programa. Rafa les analiza
sintacticamente, se les meten las suspensiones correspondientes y se lanzan.

*/



% Hacemos una captura de las posibles excepciones de Sicstus para que el sistema
% no aborte ante ellas 

initiate:-
    !, 
    on_exception(A,execute,message(A)).

% 26/05/00 mercedes. He puesto retractfile(_,_,_) para que si hay una excepcion
% de Sicstus despues de abrir algun fichero y antes de que este se cierre, el
% fichero quede cerrado

message(A):- 
    retractfile(_,_,_),
    nl,write('SYSTEM ERROR: '),
        write(A),
        nl,
        initiate.

message(A):- 
        nl,
        write('SYSTEM ERROR: '),
        write(A),
        nl,
        initiate.


%-----------------------------------------------------------------------------%
% la llamada a readGoal hace el analisis sintactico del objetivo o devuelve
% Goal=$Command si la entrada comienza con /.
%-----------------------------------------------------------------------------%

execute:-
    !,
%F010204 Cambio el prompt seg�n la biblioteca cargada
      write_prompt,
    readln(S), 
        (process(S) -> execute;
                   halt(0)).

%SONIA::B 
write_prompt :-
      clpr_active, 
      cflpfd_active, !,
    write('Toy(R+FD)> ').
%SONIA::E

%F010204 ::B
write_prompt :-
      cflpfd_active, !,
    write('Toy(FD)> ').
write_prompt :-
      clpr_active, !,
    write('Toy(R)> ').
write_prompt :-
    write('Toy> ').
%::E
%-----------------------------------------------------------------------------%
% readln(-String)
% Read a line at input
%-----------------------------------------------------------------------------%
readln(S) :-
    !,
    current_input(HIn),
    readln(HIn,S).

readln(HIn,Cs) :-
    !,
    get0(HIn,C),
    filterEOL(HIn,C,Cs).

filterEOL(HIn,C,[]) :-
    endFile(HIn,C),
    !.

filterEOL(HIn,C,[C|Cs]) :-
    !,
    readln(HIn,Cs).


%-----------------------------------------------------------------------------%
% process(+String)
% Processing the input line at Toy's command
%-----------------------------------------------------------------------------%
process([47|Command]):- % /Command
    !,
    ( append(Command2,".",Command)
         ;
          Command2 = Command
        ),
    processCom(Command2).

process([62|Expr]):- % > Expression
    !,
    parseGoal('Goal.tmp',Expr,Goal,Error),
        ( Error==true
         ;
       tryExpression(Goal)
        ),
    !.

%F 062006 The following is already done by /type
%process([58|Expr]):- % : Expression
%    !,
%    parseGoal('Goal.tmp',Expr,Goal,Error),
%        ( Error==true
%         ;
%     lookTypeExpression(Goal)
%        ),
%    !.

process([63|Expr]):- % ? Expression
    !,
    resetNAnswer, % rafa 06/06/05   
    parseGoal('Goal.tmp',Expr,Goal,Error),
        ( Error==true
         ;
      % Depu 02/11/00 mercedes
      % para la depuracion necesitamos pasar a processGoal 
      % el nombre (como cadena) del fichero fuente.
      % este dato se obtiene del hecho sourceFileNameStr, que 
      % se supone esta en memoria, porque aparece en el fich.pl
      % Fin Depu
      sourceFileNameStr(FileSourceName),
      name(FileSourceName,FileStr),
      debugExpression(Goal,FileStr)
        ),
    !.


process(String):- % Rest of the commands
    !,
    parseGoal('Goal.tmp',String,Goal,Error),
        ( Error==true
         ;
      % Depu 02/11/00 mercedes
      % para la depuracion necesitamos pasar a processGoal 
      % el nombre (como cadena) del fichero fuente.
      % este dato se obtiene del hecho sourceFileNameStr, que 
      % se supone esta en memoria, porque aparece en el fich.pl
      % Fin Depu
      sourceFileNameStr(FileSourceName),
      name(FileSourceName,FileStr),
      processGoal(Goal,FileStr)
         ),
    !.


parseGoal(Temp,String,Goal,Error) :-
    !,
    writeCommandTmp(Temp,String),
    readGoalTmp(Temp,Goal,Error).

writeCommandTmp(Temp,String) :-
        open(Temp,write,H), % abrimos para escritura el fichero temporal
        writeString(H,String),
    close(H).

writeString(H,[]).
writeString(H,[X|Xs]):-
    !,
    put(H,X),
    writeString(H,Xs).

readGoalTmp(Temp,Goal,Error):-
    !,
        open(Temp,read,H), % abrimos para escritura el fichero temporal
        get(H,Char),
    transGoal(H,Char,Goal,Error),
    close(H).



%---------------------------------------------------------------------------
processCom(Command):-
        name(Func,Command),
        (Func==halt;
         Func==quit;
         Func==q;
         Func==exit;
         Func==e),
    !,
        fail.

processCom(Command):-
    !,
    processC(Command).


processC("cflpr") :-
    !,
        loadClpr.

processC("nocflpr") :-
    !,
        unloadClpr.

processC("cflpfd") :-
    !,
        loadCflpfd.

processC("nocflpfd") :-
    !,
        unloadCflpfd.

%%::B Sonia
processC("prop") :-
    !,
        enable_prop.

processC("noprop") :-
    !,
        disable_prop.
%%::E Sonia

processC("io_file") :-
    !,
        loadIo.

processC("noio_file") :-
    !,
        unloadIo.

processC("io_graphic") :-
    !,
        loadIoGra.

processC("noio_graphic") :-
    !,
        unloadIoGra.

processC("help") :-
    !,
        showHelp.
processC("h") :-
    !,
        showHelp.

processC(Command) :-
    append("cd(",Rest,Command),
    !,
      (append(FileName,")",Rest), name(File,FileName),
%F010204 cd informativo
    (file_exists(File),file_property(File,type(directory)),!,
       working_directory(A,File),nl,working_directory(D,D),
       write('Current working directory is '),write(D),nl,nl;
     nl,write('Directory not found.'),nl,nl)
    ;
    nl,write('Error: cd needs one argument.'),nl,nl),
    !.

%F010204 Nuevo comando cd sin argumento
processC("cd") :-
      !, root_path(Path), name(Path,SPath), concatLsts(["cd(",SPath,")"],Command), processC(Command).

%F010204 Nuevo comando pwd
processC("pwd") :-
    !, nl, working_directory(D,D),write('Current working directory is '),write(D),nl,nl.

%F010204 Nuevo comando ls
processC("ls") :-
        !,
        processC("ls(.)").

processC(Command) :-
        append("ls(",Rest,Command),
        !,
        append(SRelativePath,")",Rest),working_directory(WD,WD),name(WD,SWD),
        concatLsts([SWD,"/",SRelativePath],SPath),name(Path,SPath),
        directory_files(Path, UnorderedList), sort(UnorderedList, List),
        nl, write('Contents of '), write(Path), 
        nl, nl, write('Files:'), write_dir_files(List, Path), 
        nl, nl, write('Directories:'), write_dir_directories(List, Path), nl.

% R25062005: I think we don't need the options for saving and loading the state  any longer
/*
processC(Command) :-
    append("save(",Rest,Command),
    !,
        (append(FileName,")",Rest), name(File,FileName), saveState(File)
    ;
    nl,write('Error: save needs one argument.'),nl),
    !.

*/
processC(Command) :-
    append("load(",Rest,Command),
    !,
        (append(FileName,")",Rest), name(File,FileName), loadFile(File)
    ;
    nl,write('Error: load needs one argument.'),nl),
    !.



processC(Command) :-
    append("compile(",Rest,Command),
    !,
        (append(FileName,")",Rest), name(File,FileName), do(File,_)
    ;
    nl,write('Error: compile needs one argument.'),nl),
    !.


processC(Command) :-
    append("run(",Rest,Command),
    !,
        (append(FileName,")",Rest), name(File,FileName), 
         do(File,E),(E==true,!;flush_output,loadFile(File))
    ;
    nl,write('Error: run needs one argument.'),nl),
    !.

processC(Command) :-
    append("type(",Rest,Command),
    !,
    (
        (append(ExprStr,")",Rest), name(Expr,ExprStr),
         parseGoal('Goal.tmp',ExprStr,Goal,Error),
         (Error==true
          ;
          lookTypeExpression(Goal)
         )
        )
    ;
    nl,write('Error: type needs one argument.'), nl),
    !.

processC(Command) :-
    append("system(",Rest,Command),
    !,
        (append(LstComm,")",Rest),  
    name(CommSys,LstComm),
    eliminateWhites(LstComm,LstCommN),
        (LstCommN=[99,100,32|LstDir],!,
                name(Dir,LstDir),!,
                (
                (working_directory(A,Dir);
                    nl,write('Directory not found.'),nl)

                )
            ;       
                shell(CommSys,Status)
            )
    ;
    nl,write('Error: system needs one argument.'),nl),
    !.

processC(Command) :-
    append("tree(",Rest,Command),
    !,
        (concatLsts([FileStr,",",FunStr,")"],Rest),  
    name(File,FileStr),
    name(Fun,FunStr),
    tree(File,Fun)
    ;
    nl,write('Error: tree needs two arguments.'),nl),
    !.

    
processC(Command) :-
    append("statistics(",Rest,Command),
    !,
        (append(ExprStr,")",Rest),  name(Expr,ExprStr),
        assertRunTimeStatisticsLevel(Expr),
       write('Statistics level changed to: '),
       write(Expr),
       nl,    nl
    ;
    nl,write('Error: statistics needs one argument.'),nl),
    !.

processC("statistics") :-
    !,
       getRunTimeStatisticsLevel(X),
       write('Current statistics level: '),
       write(X),
       nl,
       nl.

processC("tot") :-
    !,
    setTot(on),
    write('Totality constraints will be shown'),
    nl,nl.

processC("notot") :-
    !,
    setTot(off),
    write('Totality constraints will not be shown'),
    nl,nl.

processC("cut") :-
    !,
    setCut(on),
    write('Dynamic cut compilation on (recompile)'),
    nl,nl.

processC("nocut") :-
    !,
    setCut(off),
    write('Dynamic cut compilation off (recompile) '),
    nl,nl.

processC(Command) :-
    append("spy(",Rest,Command),
    !,
    (
       concatLsts([Module,":",Predicate,")"],Rest),
       name(ModuleName,Module), name(PredicateName,Predicate),
       system:spy(ModuleName:PredicateName)

    ;
    nl,write('Error processing spy command.'),nl
    ),
    !.


%F0606 New command for displaying the Toy version number
processC("version") :-
    !,
       toyversion(X),
       write(X),
       nl,nl.
       
%F0606 New command for displaying the Toy version number
processC("status") :-
    !,
       nl, 
       write('Libraries'),nl,
       write('========='),nl,
       write('CFLP(R)    : '),(clpr_active -> write(loaded) ; write('not loaded')), nl,
       write('CFLP(FD)   : '),(cflpfd_active -> write(loaded) ; write('not loaded')), nl,
       write('IO File    : '),(io_active -> write(loaded) ; write('not loaded')), nl,
       write('IO Graphic : '),(iographic_active -> write(loaded) ; write('not loaded')), nl,
       nl.
       
%F0606 New command for executing Prolog goals. They may end with a dot
% So, both /prolog(write(ok)) and /prolog(write(ok).) are valid
processC(Command) :-
    append("prolog(",Rest,Command),
    !,
        (append(PStr,")",Rest),  
         ((append(_Str,".",PStr), PrologStr=PStr) ; append(PStr,".",PrologStr)), !,
         read_from_chars(PrologStr,Prolog),
         nl,(call(Prolog) -> write(yes) ; write(no)),
         nl
    ;
    nl,write('Error: prolog needs one argument.'),nl),
    !.

       
%F0606
% User-Defined Commands

processC(Command) :-
    command(CString, Arity, OSArgs, OSList),
    (Arity = 0 -> 
     (CString=Command, [OSString] = OSList)
      ; 
     (concatLsts([CString, "(", StrArgs, ")"], Command),
      readArgs(StrArgs, Arity, OSArgs),
      concatLsts(OSList,OSString))
    ), 
    name(OSCommand,OSString), 
    nl, 
    write('Executing OS command: '), write(OSCommand), write(' ... '), 
    (system(OSCommand) -> write('Suceeded.'); write('Failed.')), 
    nl, nl.

readArgs("", 0, [""]) :- !.
readArgs(StrArg, 1, [StrArg]) :- !.
readArgs(StrArgs, IntArg, [OSArg|OSArgs]) :-
    IntArg > 1,
    concatLsts([OSArg, ",", Rest], StrArgs), !,
    IntArgM1 is IntArg-1,
    readArgs(Rest, IntArgM1, OSArgs).
    

% This last chance corresponds to trying the given (not recognised as a Toy) command on the underlying OS
processC(Command) :- !,name(Name, Command), shell(Name,Status),
%F010204
        (Status = 0 -> 
         (nl, write('Operating system command executed.'), nl); 
         (nl, write('Unknown command or operating system command failed.'), nl)).



%F010204 Predicados para el comando ls
% Writing each File in a Directory. Path comes without final slash

write_dir_files([], _Path).
write_dir_files([F|Fs], Path) :-
  name(Path,SPath), name(F,SF), concatLsts([SPath,"/",SF],SFN), name(FN,SFN),
  file_property(FN, type(regular)), !, nl, write('  '), write(F), write_dir_files(Fs, Path).
write_dir_files([F|Fs], Path) :-
  write_dir_files(Fs, Path).


% Writing each Directory in a Directory

write_dir_directories([], _Path).
write_dir_directories([F|Fs], Path) :-
  name(Path,SPath), name(F,SF), concatLsts([SPath,"/",SF],SFN), name(FN,SFN),
  file_property(FN, type(directory)), F \== '.', F \== '..', !, nl, write('  '), write(F), write_dir_directories(Fs, Path).
write_dir_directories([F|Fs], Path) :-
  write_dir_directories(Fs, Path).

%-----------------------------------------------------------------------------%
% Carga clpfd para poder usar las restricciones sobre dominios finitos. La activacion de
% restricciones sobre dominios finitos en TOY (mediante el comando /cflpfd.) prepara al
% sistema del modo siguiente:
% - se carga en memoria el resolutor proporcionado por Sicstus
% (use_module(library(clpfd))),
% - tambien se carga el nuevo juego de primitivas(primitivesCflpfd.pl),
% - se activa un flag que informa al sistema de modo de uso en el que se 
% encuentra, asertando el hecho cflpfd_active (assert(cflpfd_active)).
%-----------------------------------------------------------------------------%

%SONIA :: B COMENTO EL SIGUIENTE C�DIGO
%loadCflpfd:-
%      clpr_active, !,
%      nl, write('Cannot load both Real Domain Constraints and Finite Domain Constraints libraries.'), nl.
%SONIA :: E COMENTO EL SIGUIENTE C�DIGO


loadCflpfd:-
      cflpfd_active, !,
      nl, write('Finite Domain Constraints library already loaded.'), nl.

%Sonia B
loadCflpfd:-
      assertcflpfd_active, !,
%      complete_root_filename(nadacflpfd,F), name(F,FS), 
%      concatLsts(["/run(",FS,")"], Command),
%      process(Command),
      processLoadFD,
      nl, write('Finite Domain Constraints library loaded.'), nl.
processLoadFD:-
      complete_root_filename(nadacflpfd,F), name(F,FS), 
      concatLsts(["/run(",FS,")"], Command),
      process(Command).    
%Sonia E
  
    
%-----------------------------------------------------------------------------%
% Descarga clpfd para dejar de usar las restricciones sobre dominios finitos. La 
% desactivacion de las restricciones sobre dominios finitos en TOY (mediante el comando
% /cflpfd.) prepara al sistema del modo siguiente:
% - se carga el antiguo juego de primitivas(primitives.pl),
% - se desactiva el flag que informa al sistema de modo de uso en el que se 
% encuentra, borrando el hecho cflpfd_active (my_abolish(cflpfd_active/0)).
%-----------------------------------------------------------------------------%

unloadCflpfd :-
      cflpfd_active, !,
      my_abolish(cflpfd_active/0),
      complete_root_filename(nada,F), name(F,FS), 
      concatLsts(["/run(",FS,")"], Command),
      process(Command),
      nl, write('Finite Domain Constraints library unloaded.'), nl.

unloadCflpfd :-
      nl, write('Cannot unload: Finite Domain Constraints library is not loaded.'), nl.  


%-----------------------------------------------------------------------------%
% Loading and unloading the library CFLPR 
%-----------------------------------------------------------------------------%

%F16062006 New loading and unloading scheme for IO Files, IO Graphic, and CFLPR libraries
% The code below for such libraries has been reworked

%---------------- Loading CFLPR --------------------%

loadClpr:-
      clpr_active, !,
      nl, write('Real Domain Constraints library already loaded.'), nl.

%SONIA :: B Si est� la libreria de dominios finitos cargada se debe cargar otra vez
% despues de cargar la librer�a de reales para que queden definidas las 
% primitivas de dominios finitos
%loadClpr:-
%      cflpfd_active, !,
%      nl, write('Cannot load both Real and Finite Domain Constraints libraries.'), nl.

loadClpr:-
      cflpfd_active, !,
      loadFilesClpr,     %carga reales
      assertclpr_active,
      processLoadFD,
      nl, write('Real Domain Constraints library loaded.'), nl.

%SONIA :: E 


loadClpr:-
%     use_module(library(clpr)),
     loadFilesClpr,
     assertclpr_active,
     nl, write('Real Domain Constraints library loaded.'), nl.

loadFilesClpr:-
    loadFilesClpr(P,T1,B),
    loadFiles(P,T1,B).
    
%---------------- Unloading CFLPR --------------------%

%% Sonia, si descargamos los reales desde "Toy(R+FD)>" hay que cargar los dominios finitos
%% justo depues de "reloadActiveLibraries", si no va mal
unloadClpr:-
      clpr_active, !,
      my_abolish(clpr_active/0),
      reloadActiveLibraries,
%B Sonia  
      (cflpfd_active -> processLoadFD ; true),
%E Sonia    
      nl, write('Real Domain Constraints library unloaded.'), nl.

unloadClpr:-
      nl, write('Cannot unload: Real Domain Constraints library is not loaded.'), nl.  


%-----------------------------------------------------------------------------%
% Loading and unloading the library IO Files 
%-----------------------------------------------------------------------------%

%---------------- Loading IO Files --------------------%

loadIo:-
    (
     io_active,
     !,
     nl, write('IO Files library already loaded.'), nl
    ;
     loadFilesIo,
     assertio_active,
     complete_root_filename(nada,F), name(F,FS), 
     concatLsts(["/run(",FS,")"], Command),
     process(Command),
     nl, write('IO Files library loaded.'), nl
    ).
    
loadFilesIo:-
    loadFilesIo(P,T1,B),
    loadFiles(P,T1,B).


%---------------- Unloading IO Files --------------------%

unloadIo:-
      io_active, !,
      my_abolish(io_active/0),
      reloadActiveLibraries,
      nl, write('IO Files library unloaded.'), nl.

unloadIo:-
      nl, write('Cannot unload: IO Files library is not loaded.'), nl.  
      
      
%-----------------------------------------------------------------------------%
% Loading and unloading the library IO Graphic 
%-----------------------------------------------------------------------------%

%---------------- Loading IO Graphic --------------------%

loadIoGra:-
    (
     iographic_active,
     !,
     nl, write('IO Graphic library already loaded.'), nl
    ;
     loadFilesGra,
     assertiographic_active,
     complete_root_filename(nada,F), name(F,FS), 
     concatLsts(["/run(",FS,")"], Command),
     process(Command),
     nl, write('IO Graphic library loaded.'), nl
    ).
    
loadFilesGra:-    
    loadFilesGra(P,T1,B),
    loadFiles(P,T1,B).

%---------------- Unloading IO Graphic --------------------%

unloadIoGra:-
      iographic_active, !,
      my_abolish(iographic_active/0),
      reloadActiveLibraries,
      nl, write('IO Graphic library unloaded.'), nl.

unloadIoGra:-
      nl, write('Cannot unload: IO Graphic library is not loaded.'), nl.  
      

%---------------------------------------------------------------%
% Reloading active libraries                                    %
%---------------------------------------------------------------%
    
reloadActiveLibraries:-
    loadFilesDefault(P,T1,B), % The startup files (primFunct.pl, basic.pl and primitivCod.pl) are restored
    ((\+((io_active;iographic_active;clpr_active)) -> 
       loadFiles(P,T1,B)) ;
       ((clpr_active -> loadFilesClpr ; true),
        (iographic_active -> loadFilesGra ; true),
        (io_active -> loadFilesIo ; true))).

loadFilesDefault:-
    loadFilesDefault(P,T1,B),
    loadFiles(P,T1,B).

%------------------------------------------------------------------------------%
% Loading the current versions of primFunct.pl, basic.pl and primitivCod.pl,   %
% corresponding to the startup files which might be appended with code for     %
% IO File, IO Graphic or CFLPR libraries (taken from primFunct<L>.pl,          %
% basic<L>.pl and primitivCod<L>.pl, where <L> can be Io, Gra or Clpr,         %
% respectively)                                                                %
%------------------------------------------------------------------------------%

loadFiles(P,T1,B):-
     (
      development_version,!,
%      load_files(P,[if(changed)]), % primFunct.pl is loaded by basic.pl
      load_files(B,[if(changed)]), % basic.pl loads primFunct.pl and primitivCod.pl
      load_files(T1,[if(true)]) % primitivCod.pl, primitivCodIo.pl, primitivCodGra.pl or primitivCodClpr.pl
     ;
      load(P),
      load(B),
      load(T1)
     ).
%    (
%     development_version,!,
%     load_files(P,[if(changed)]),
%     load_files(T1,[if(changed)]),
%     load_files(B,[if(changed)])
%    ;
%     load(P),
%     load(T1),
%     load(B)
%    ).




%% B Sonia
%-----------------------------------------------------------------------------%
% Para activar y desactivar la propagaci�n aserto y borro  prop_active
%-----------------------------------------------------------------------------%

enable_prop:-
      prop_active, !,
      nl, write('Prop already enabled.'), nl.

enable_prop:-
      cflpfd_active, clpr_active, !, 
    assertprop_active, 
      nl, write('Propagation enabled.'), nl.

enable_prop:-
      nl, write('Finite Domain Constraints library or Real Domain Constraints library is not loaded.'), nl.

disable_prop:-
      prop_active, !,
      my_abolish(prop_active/0),
      nl, write('Propagation disabled.'), nl.

disable_prop:-
      nl, write('Cannot disabled: propagation is not enabled.'), nl.  

%% E Sonia


%-----------------------------------------------------------------------------%
% processGoal(+Goal) donde Goal es una lista de listas. Se le pasa un
% objetivo parseado por Rafa.
%Rafa devuelve la traduccion del objetivo en forma de lista de listas, por eso
%lo primero que se hace es aplanar estas listas. Luego chequeamos los tipos y si 
%no se produce error, hacemos la traduccion a equal y notEqual para lanzarlo y 
%por ultimo lo lanzamos 
%-----------------------------------------------------------------------------%

processGoal(where(GoalP,Where),FileStr):-
    (
     % solo se comprueban los tipos si no se esta en depuracion
     debugando  %quien se encarga de cortar las alternativas restantes?
                % hab 
    ;
     goalType(GoalP,Where),
     resetNAnswer % rafa 06-06-2005 reset de counter of answers computed for a goal
    ), 
     
    % Fin Depu  
    
    (
     typeError
    ;

     % Depu 03/11/00 mercedes
     % el objetivo (GoalP,Where), que viene del analisis sintactico, 
     % se convierte en codigo Prolog ejecutable (GoalS)
     convertGoalToExecutableCode(GoalP,Where,GoalS, Vars,Cout),
     % Fin Depu
    
    % inicializamos las estad�sticas
     createRunTimeStatistics,


     % a throwGoal se le pasan como var. del objetivo solo las de la cond, 
     % no las del where, porque son las unicas que nos interesa que muestre
     % en la respuesta
     throwGoal(GoalS,where(GoalP,Where),Vars,FileStr,Cout)
    ),
    !. 
            
processGoal(_,_).




convertGoalToExecutableCode(GoalP,Where,GoalS, Vars,Cout) :-
    !,
    transCheckConstra(GoalP,[]/Vars1,GoalT,_),

    % Depu 21/11/00 mercedes
    change_wheres(Where,Where1,1,_ContOut),
    % Fin Depu


    % Depu 28/10/00 mercedes
    % eliminamos where
    transCheckWhere(Where1,Vars1/Vars2,WhereT,_),
    extract_left_hand_side_Where(WhereT,[],ListOpt),        
    doWhere(WhereT,Code,execution),
    
        % construimos las restricciones que forman el objetivo
    doConstra(GoalT,GoalS1,[],Cout,execution),
    optimizeEq(ListOpt,GoalS1,GoalS2),
    
    % el codigo del where se traduce como flechas; condiciones que 
    % preceden a las condiciones de la regla
    append(Code,GoalS2,GoalS),

    
    
    % 16/11/00 rafa
    % eliminamos la variables del objetivo que han sido instanciadas
    % por el where; estas no deben aparecer en la respuesta 
    removeWhereVars(Vars2,WhereT,Vars).
    % Fin Depu

% Depu 11/04/01 rafa
removeWhereVars(VarsIn,WhereT,VarsOut) :-
  extractWhereVars(WhereT,WhereVars),
  removeWhereVarsBis(VarsIn,WhereVars,VarsOut).

removeWhereVarsBis([],_WhereVars,[]) :-
    !.
removeWhereVarsBis([(X,V)|R],WhereVars,NewR) :-
    % si V es una variable de la parte izq. de un where la quitamos
    member(V,WhereVars) ,
    !,
    removeWhereVarsBis(R,WhereVars,NewR).

% en otro caso la dejamos
removeWhereVarsBis([H|R],WhereVars,[H|NewR]) :-
    !,
    removeWhereVarsBis(R,WhereVars,NewR).

% extrae las variables where a partir de una lista de elementos
% de la forma =(V,R,N), donde V es la variable que nos interesa 
extractWhereVars([],[]) :-
    !.
extractWhereVars([=(V,_R,_N)|Rest], [V|RestWhereVars]):-
    !,
    extractWhereVars(Rest,RestWhereVars).


% Fin Depu

%-----------------------------------------------------------------------------%
% throwGoal(+ListaRestricciones,+GoalP, +Vars del Objetivo,+FileStr,+Cout).
% La lista de restricciones es una lista terminos equal o notEqual que deben
% ser resueltos, e.d., lanzados y esto es lo que se hace. Cuando no quedan 
% restricciones por lanzar es porque hemos alcanzado una respuesta. La mostramos
% y si se solicitan mas se fuerza el fallo para provocar backtracking. Cuando
% estas dos clausulas fallan es porque se han agotado todas las posibilidades
% se ha explorado completamente el espacio de busqueda e informamos al usuario
% de este hecho en la tercera clausula. Si el resolutor esta activo nos quedamos
% con el residuo porque las variables relevantes incluyen a aquellas que 
% aparecen en restricciones no lineales.
%-----------------------------------------------------------------------------%


%SONIA ::B

%   Toda esta parte la comento y escribo de nuevo el "throwGoal"

/*
throwGoal(Goal,GoalTmp,Vars,FileStr,Cout):-
    clpr_active,
    !,
    (
%080199
% A partir de la version 36 de Sicstus ya no es necesario hacer chapuzas con los
% residuos my_call_residue queda obsoleto       
        %my_call_residue(throwConstraints(Goal),Residue),
        call_residue(throwConstraints(Goal),Residue),
        
        continueGoal(GoalTmp,Vars,FileStr,Cout,clpr(Residue)),
        !
    ;
        writeFail
    ).


throwGoal(Goal,GoalTmp,Vars,FileStr,Cout):-
    throwConstraints(Goal),
    % Depu 02/11/00 mercedes
    % pasamos el Goal que hace falta para depurar
    continueGoal(GoalTmp,Vars,FileStr,Cout,noclpr),
    % Fin Depu
    !                            
    ;                            
    writeFail.

*/


throwGoal(Goal,GoalTmp,Vars,FileStr,Cout):-
    (
        call_residue(throwConstraints(Goal),Residue),    
        continueGoal(GoalTmp,Vars,FileStr,Cout,clpr(Residue)),
        !
    ;
        writeFail
    ).


%SONIA ::E



%-----------------------------------------------------------------------------%
% throwConstraints(+Goal): va lanzando las restricciones que hay en Goal.
%-----------------------------------------------------------------------------%

throwConstraints([]).

% 14/09/00 mercedes
% Al final del computo se eliminan de la BD todas las clausulas contvar y varmut
throwConstraints([C|Rest]):-
    call(C),
    (
     varmut(_,_),
     !,
     retractallvarmut(_,_),
     (
      contvar(_),
      !,
      retractallcontvar(_),
      throwConstraints(Rest)
     ;
      throwConstraints(Rest)
     )
    ;
     throwConstraints(Rest)
    ).

%-----------------------------------------------------------------------------%
% continueGoal(+Goal,+Vars,+FileStr,+Cout,+Residue) 
% Depu 02/11/00 mercedes
% El predicado tambien necesita el objetivo, y el nombre del fichero
% para la depuracion
%-----------------------------------------------------------------------------%

continueGoal(Goal,Vars,FileStr,Cout,Residue) :- 
   % 06/06/05 Rafa: increment the counter of produced answers for a goal
    incNAnswer,
    writeSolution(Vars,Cout,Residue),
    !,
    askIfMore(Goal,Vars,FileStr,Cout). % rafa 30/05/05: now Cout is needed as parameter


% Depu 13/11/00 mercedexxx

%-----------------------------------------------------------------------------%
% debugExpression(Goal,FileStr)
% Depura el objetivo Goal en modo Eval, es decir, con la primera respuesta que
% se obtiene y sin considerar respuestas en las variables
%-----------------------------------------------------------------------------%
debugExpression(where([Goal],Where),FileStr):-
    !,
   startDebuggingProcess(where([Goal=='$var'('$WhatEver')],Where),[],FileStr,[]).
   
% Fin Depu


%-----------------------------------------------------------------------------%
% tree(+File,+NameFun) donde:
% +File: fichero donde se encuentra la funcion NameFun
% +NameFun: Nombre de la funcion de la que queremos obtener el arbol definitorio
% Muestra por pantalla el arbol definitorio asociado a la funcion NameFun que se
% encuentra en el fichero File.
%-----------------------------------------------------------------------------%

tree(File,NameFun):-
    extractNameExtension(File,Name,_),
    name(F,Name),
    consult(F,".tmp.out"),
    (
        fun(NameFun,ArP,Rules,Line),
        !,      
        traslateCheckRules(Rules,RulesT,_),
        tree(fun(NameFun,ArP,RulesT,Line),Patron,Tree),
        paint(Patron,Tree),
        deletePredsComp
    ;
        nl,
        write('Error: function '''),
        write(NameFun),
        write(''' is not defined in '''),
        write(File),write('''.'),nl
    ).




tree(File,NameFun):-
    write('I need to compile before, please wait...'),
    do(File,E),
    nl,
    (E==false,
    %deletePredsComp,
    tree(File,NameFun)
    ;
    true).
            



tree(_,_).








%-----------------------------------------------------------------------------%
% doLstNames(+listanombres,-listacaracteres) donde:
%   +listanombres: es una lista de nombres
%   -listacaracteres: es la lista de las cadenas de caracteres 
%   correspondientes a los nombres de listanombres. 
% Tengo una lista de nombres, y transformo cada nombre en una cadena de 
% caracteres.
%-----------------------------------------------------------------------------% 

doLstNames([],[]).
doLstNames([C|R],[CN|RN]):-name(C,CN),doLstNames(R,RN).






%-----------------------------------------------------------------------------%
% loadFile(+File) donde +File:nombre del fichero que quiero cargar. 
% Carga el archivo File y le pone la extension .pl. Devuelve error en caso de
% no encontrar el fichero.
%-----------------------------------------------------------------------------%

loadFile(File):-    
    %my_abolish(constr/4),
    %my_abolish(funct/5),
    %my_abolish(hnf_susp/3),
    %my_abolish('$$apply_1'/3),
    %my_abolish(infix/3),
    extractNameExtension(File,Name,_Ext),
    append(Name,".pl",N1),
    name(NF,N1),
    (file_exists(NF),!,(load_files(NF,[if(changed)])
%%::B
,loadCflpfdFiles)
%%::E

;
    nl,write('Error: file '),write(File),write('.pl does not exist.'),nl).
    

%%::B

%-----------------------------------------------------------------------------%
% loadCflpfdFiles. 
% Carga los archivos Prolog de dominio finito que est�n indicados
% en los flags cflpfdfile(X), donde X es el nombre del archivo Prolog.
%-----------------------------------------------------------------------------%

loadCflpfdFiles :-
       retract(cflpfdfile(X)), 
       [plgenerated:X],
       loadCflpfdFiles.

loadCflpfdFiles.

%%::E


%-----------------------------------------------------------------------------%
% lookTypeExpression(+Expresion) donde +Expression: expresion de la que quiero 
% saber el tipo. 
% Escribe por pantalla el tipo de la expresion E.
%-----------------------------------------------------------------------------%

lookTypeExpression(where([E],Where)):- 
    retractalltypeError,
    statistics(runtime,_),
    expressionType(E,goal,[]/_,TE),
    statistics(runtime,[_,T]),
    (typeError,!
     ;
     write(E),write('::'),writeAtom(TE),
     nl,nl,
     write('Elapsed time: '),
     write(T),
     write(' ms.'),nl,nl
    ).



%-----------------------------------------------------------------------------%
% lookTypeFunction(+Function) donde +Funtion: funcion de la que quiero saber el
% tipo. 
% Escribe por pantalla el tipo de la funcion F. En caso de que la funcion no
% exista, devuelve error.
%-----------------------------------------------------------------------------%

lookTypeFunction(F):-
    (funct(F,_,_,T,_),!,nl,write(F),write(' :: '),writeAtom(T),nl;
    nl,write('Error: Can not find function '),write(F),nl).








/*****************************************************************************/
/*                      AYUDA                        */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% Escribe el menu de ayuda por pantalla.
%-----------------------------------------------------------------------------%

%F010204 <Dir> no se encierra entre comillas simples y los comandos no terminan en '.'
showHelp:-
    nl,
    nl,
    write(
'     HELP MENU

        The following are the available commands (note that all start with "/"):

      Interaction with the OS
        - /q /quit              Quits TOY
          /e /exit
        - /cd(<Dir>)            Changes the current working directory to <Dir>
        - /cd                   Changes the current working directory to the distribution root                           
        - /pwd                  Displays the current working directory
        - /ls                   Displays the contents of the working directory
        - /ls(<Dir>)            Displays the contents of the given directory <Dir>
        - /system(<Comm>)       Sends the system command <Comm> to the operating system shell
          /<Comm>               (Alternative form wherever <Comm> is not a Toy command)

      Compiling and Loading Programs
        - /compile(<File>)      Compiles the file <File>.toy
        - /load(<File>)         Loads the file <File>.pl provided <File>.toy was compiled
        - /run(<File>)          Compiles and loads the file <File>.toy
        - /cut, /nocut          Enables/Disables compilation with dynamic cut optimization

      Information about Programs
        - /type(<Expr>)         Shows the type of the expression <Expr>
        - /tot, /notot          Enables/Disables totality constraints as part of the system answers
        - /tree(<File>,<Funct>) Shows the dpt-tree of <Funct> defined in <File> if <File> has 
                                been compiled, else compiles <File>.toy and then shows the tree
      Commands for Constraint Solvers
        - /cflpr, /nocflpr      Loads/Unloads the constraint solver over reals
        - /cflpfd, /nocflpfd    Loads/Unloads the constraint solver over finite domains

      Commands for Propagation
        - /prop, /noprop        Enables/Disables propagation
      
      Miscellanea
        - /io_file, /noio_file  Loads/Unloads the library of i/o with files
        - /io_graphic           Loads/Unloads the library of graphic i/o
          /noio_graphic
        - /statistics(<Level>)  Sets the level <Level> of statistics:
                                  0: no statistics
                                  1: runtime
                                  2: runtime & hnf counter
                                  3: full statistics
        - /statistics           Displays the current level of statistics
        - /prolog(Goal)         Executes the Prolog goal Goal
        - /status               Informs about the loaded libraries
        - /version              Displays the Toy software version
        - /h /help              Shows this help

      To evaluate deterministic expressions, they must be preceded by >

      To debug an expression, it must be preceded by ?
    
      Any other sentence will be interpreted as an OS command to execute'),
    nl,nl.
            
