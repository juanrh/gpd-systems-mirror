:- module(gramma_toy,[section/7, conditionWhere/7,res/1,sep_res/1,tip_res/1,sep/1]).

:- load_files(errortoy,[if(changed),imports([terminal/7])]).

:- load_files(compil,[if(changed),imports([extractTable/3,priorityOperator/4])]).

:- load_files(tools,[if(changed),imports([lookandput/4,member/2])]).  % 06/06/00 mercedes

:- load_files(newout,[if(changed),imports([infix/4,ftype/4,fun/4,primitive/3])]).


