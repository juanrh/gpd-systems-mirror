%---------------------------------------------------------------------------%
% writing.pl
%---------------------------------------------------------------------------%
/* 
- Author: Jaime

- Description: es el modulo encargado de la escritura de atomos.

- Modules which import it: goals, inferrer, initToy, process.

- Imported modules:
    > plgenerated (con 'infix/3').
    > outgenerated (con 'infix/4').

- Modified: 
    26/10/99 mercedes (modularizacion).
    03/11/99 mercedes (He cambiado cada aparicion de num que hay en el 
               codigo y la he sustituido por '$num'. Esto es 
               porque num era una palabra reservada y podia 
               colisionar con nombres de usuario. Por ejemplo:
               programa: data chungo = num real
               objetivo: num 3 == X
               resultado: X == real
               Eso era lo que pasaba antes de cambiarlo).

*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(writing,[writeAtom/1,writeAtom/3,searchInsertVar/3,isOpInfix/3,extractName/2]).


% 16/05/00 mercedes. Para cuando usamos la libreria de e/s de ficheros.
/*
:- load_files(dyn,[if(changed)]).
:- (
    io_active,!,load_files(basicIo,[if(changed)])
   ;
    (iographic_active;ioclpr_active),!,load_files(basicGra,[if(changed)])  %29/05/00 e/s grafica
   ;
    load_files(basic,[if(changed)])
   ).
*/

:- load_files(basic,[if(changed),imports([infix/3])]).

/* Lo que se hace es cargar inicialmente el fichero basic.pl que contiene el modulo
plgenerated inicial, pero cuando se genere un fichero.pl y se cargue (en el modulo
process), como lo generamos como modulo plgenerated, se borra el modulo 
plgenerated antiguo y se carga este nuevo.
*/

:- load_files(newout,[if(changed),imports([infix/4])]).

/*Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.
*/

% current_output




/*****************************************************************************
    ESCRIBE ATOMO
Aqui atomo no es un atomo en sentido prolog, sino una unidad minima que puedo 
escribir. Se le puede llamar de dos modos: 
    writeAtom(T)   ->  toma el handle de la pantalla
    writeAtom(Handle,T)  -> usa el que le pasamos

Tambien modifica su comportamiento el hecho de escribir a un fichero o escribir 
a pantalla, porque es distinto lo que le presentamos al usuario del codigo que 
generamos.

*****************************************************************************/



%----------------------------------------------------------------------------%
% writeAtom(+T)
% para escribir en la salida estandard, se puede llamar a escribe Atomo con
% un argumento: lo que hay que escribir (T). Entonces toma
% el handle de la salida estandard y llama a writeAtom/3, con el acumulador
% de entrada vacio (el acumulador de variables)
%----------------------------------------------------------------------------%

writeAtom(T):-
        current_output(Handle),writeAtom(Handle,[]/_,T).

%----------------------------------------------------------------------------%
% writeAtom(+Handle,+L/-R,+T)
%----------------------------------------------------------------------------%

writeAtom(Handle,L/R,V):-
    var(V),
    !,
    searchInsertVar(V,L/R,Name),
    write(Handle,Name).


% writeAtom tambien se usa para dar salida de errores de tipo y warnings
% de compilacion. Las tres clausulas siguientes son para quitar los prefijos
% $var, $int y $float de las expresiones. Esto no afecta a la salida que se
% manda a archivo porque no tiene este tipo de expresiones

writeAtom(Handle,L/L,'$var'(X)):-!,write(Handle,X).
writeAtom(Handle,L/L,'$int'(X)):-!,write(Handle,X).
writeAtom(Handle,L/L,'$float'(X)):-!,write(Handle,X).
writeAtom(Handle,L/L,'$num'(F)):-
% Si estamos escribiendo en pantalla no ponemos num(int), sino int, y en vez
% de num(_) ponemos real. Si estamos escribiendo en el archivo de salida, lo
% respetamos porque el inferidor entiende esta notacion de tipos.
    %mercedes 28/09/99
    % current_output(COHandle),  
    % COHandle==Handle,
    % He sustituido eso por screenOut(Handle) que hace lo mismo.
    screenOut(Handle),
    !,
    (F==int,!,write(Handle,'int')
    ;
    write(Handle,'real')).



%char
writeAtom(Handle,L/L,'$char'(N)):-
    screenOut(Handle),
    !,
    name(C,[N]),
    write(''''),
    write(C),
    write('''').


% 17/05/00 mercedes
writeAtom(Handle,L/R,'$io'(N)):-
    screenOut(Handle),
    !,
    write('io '),
    writeAtom(Handle,L/R,N).

% 06/06/00 mercedes (el codigo del do que escribimos en el plgenerado lo 
% escribimos como '$do'([Vs],[Ps],H,Cin,Cout) para que concuerde con el
% codigo que hay del do en el toycomm.pl
writeAtom(Handle,L/R,'$do'(V,P,H,Cin,Cout)):-
    !,
    writeq(Handle,'$do'),
    write(Handle,'('),
    writeListProlog(Handle,L/L1,V),
    write(Handle,','),
    writeListProlog(Handle,L1/L2,P),
    write(Handle,','),
    writeListAtoms(Handle,L2/R,[H,Cin,Cout],','),
    write(Handle,')').

% 09/06/00 mercedes (el codigo de la lista intensional que escribimos en el
% plgenerado lo escribimos como '$intensional'(E,['->'(V,L),B|R],H,Cin,Cout)
% para que concuerde con el codigo que hay de la lista intensional en el
% toycomm.pl    [<-(V,L)|R]
writeAtom(Handle,L/R,'$intensional'(E,P,H,Cin,Cout)):-
    !,
    writeq(Handle,'$intensional'),
    write(Handle,'('),
    writeAtom(Handle,L/L1,E),
    write(Handle,','),
    writeListProlog(Handle,L1/L2,P),
    write(Handle,','),
    writeListAtoms(Handle,L2/R,[H,Cin,Cout],','),
    write(Handle,')').



writeAtom(Handle,L/R,T):-
    functor(T,Name,Ar),
    (
    screenOut(Handle),
    !,
        (
        % Nuestra constructora de listas ':', si la salida es a 
        % pantalla se escribe como una lista prolog, si no como 
        % una constructora mas
        (Name==':';Name='.'),!,writeList(Handle,L/R,T)  % 13/06/00 mercedes
        ;
        %Name==',',!,writeTuple(Handle,L/R,T)
        (Name=='$$tup';Name=='$$tuple'),!,writeTuple(Handle,L/R,T)
        ;
        % Si la salida es a pantalla y es infijo lo escribimos como 
        % infijo
        isOpInfix(Name,P,Asoc),
        !,
        writeAtomInfix(Handle,L/R,T,Name,Ar,P,Asoc)
        ;
        % En caso contrario lo escribimos como prefija
        writeAtomPrefix(Handle,L/R,T)
        )
    ;
    writeAtomPrefix(Handle,L/R,T)
    ).



%tuplas
writeTuple(Handle,L/R,T):-
    T=..[_,Sec],
    write('('),
    writeSecuence(Handle,L/R,Sec),
    write(')').

writeSecuence(Handle,L/R,T):-
    var(T),
    !,
    writeAtom(Handle,L/R,T).



writeSecuence(Handle,L/R,','(A,B)):-
    !,
    writeAtom(Handle,L/R1,A),
    write(', '),
    writeSecuence(Handle,R1/R,B).
    
writeSecuence(Handle,L/R,A):-
    writeAtom(Handle,L/R,A).







writeAtomPrefix(Handle,L/R,T):-
    (screenOut(Handle),!,writeAplicationScreen(Handle,L/R,T)
    ;
    writeAplicationFile(Handle,L/R,T)).

writeAplicationScreen(Handle,L/R,T):-
    T=..[Name|Args],
    (Args\==[],!,write('('),writeFun(Name),write(' ');writeFun(Name)),
    writeListAtoms(Handle,L/R,Args,' '),
    (Args\==[],!,write(')');true).


writeAplicationFile(Handle,L/R,T):-
    T=..[Name|Args],
    writeq(Handle,Name),
    (
        % Si es una suspension, entonces tenemos que escribir una lista
        % prolog de verdad en el segundo argumento

% 07/10/00  rafa Error PONIA:
%       Name=='$$susp',!,Args=[F,Lista,R,S],write(Handle,'( '),
%  La 'R' se confunde con el argumento de la cabecera en L/R
%  Lo cambio por Res
        Name=='$$susp',!,Args=[F,Lista,Res,S],write(Handle,'( '),

        writeq(Handle,F),write(Handle,', '),
        writeList(Handle,L/R1,Lista),

% 07/10/00 cambiada R por Res en el ultimo argumento
        write(Handle,', '),writeAtom(Handle,R1/R2,Res),
        write(Handle,', '),writeAtom(Handle,R2/R,S),
        write(Handle,' )')
    ;
        Args\==[],
        !,
        write(Handle,'('),
        writeListAtoms(Handle,L/R,Args,', '),
        write(Handle,')')
    ;
        L=R
    ).


%----------------------------------------------------------------------------%
% writeListAtoms(+Handle,+L/-R,+ListaAtomos,+Separator)
% Escribe la lista de atomos metiendo entre cada atomo un Separator.
%----------------------------------------------------------------------------%

writeListAtoms(_,L/L,[],_):-!.
writeListAtoms(Handle,L/R2,[At|Rest],Separator):-
    writeAtom(Handle,L/R1,At),
    (Rest\==[],write(Handle,Separator),
        writeListAtoms(Handle,R1/R2,Rest,Separator)
    ;
    R2=R1).



%----------------------------------------------------------------------------%
% writeAtomInfix: solo se usa para escritura por pantalla de expresiones
% con operadore infijos o de tipos de funciones.
% Parametros:
%   +Handle: handle donde tiene que escribir, que es la pantalla, pero se
%       lo pasamos porque a su vez debe pasarlo y asi no lo recalculamos
%   +L/-R:  Acumuladores de variables, para sacar las vars bonitas y no 
%       como las saca prolog (_432525). Son listas de variables con 
%               elementos de la forma (Var,Name), donde Var seria _432525 y Name
%               algo del estilo _C.
%   +T:     expresion a escribir
%   +Name:  functor principal de T
%   +Ar:    Aridad de T
%   +Prior: prioridad del functor principal de T
%   +Asoc:  asiciatividad del functor de T (right,left o noasoc)
%
%   Si la aridad es 0 ponemos el operador entre parentesis. Si es 1, ponemos
% el operando y el operador entre parentesis.
% Si es 2, esto es, si tiene sus dos operandos hay que hacer un analisis mas
% fino sobre sus argumentos: si son variable llamamos a writeAtom que se
% encarga de escribirla. Si no, miramos si su functor es un op infijo que habra
% que parentizar en los siguientes casos:
%   - Si la prioridad del mas extermo es mayor que la del mas interno
%   - Si tienen la misma prioridad y:
%       - ambos asocian por la dcha si es el operando izdo, o por la
%         izda si el el dcho.
%       - no tienen la misma asociatividad
%----------------------------------------------------------------------------%

writeAtomInfix(Handle,L/R,T,Name,Ar,Prior,Asoc):-
    (
        Ar==0,!,write(Handle,'('),writeFun(Name),
            write(Handle,')'),L=R
    ;
        Ar==1,!,arg(1,T,A1),
        write('('),
        writeAtom(Handle,L/R,A1),
        write(' '),writeFun(Name),write(')')        
    ;
        arg(1,T,A1),arg(2,T,A2),
        (   
            var(A1),
            !,  
            writeAtom(Handle,L/R1,A1)
            ;
            functor(A1,Name1,Ar1),
            (
                isOpInfix(Name1,Prior1,Asoc1),
                (Prior>Prior1;
                    Prior==Prior1,
                    (Asoc==Asoc1,Asoc==right;Asoc\==Asoc1)),
                !,
                write('('),
                writeAtomInfix(Handle,L/R1,A1,
                    Name1,Ar1,Prior1,Asoc1),
                write(')')
            ;
                writeAtom(Handle,L/R1,A1)
            )
        ),
        write(' '),writeFun(Name),write(' '),
        (
            var(A2),
            !,
            writeAtom(Handle,R1/R,A2)
            ;
            functor(A2,Name2,Ar2),
            (
                isOpInfix(Name2,Prior2,Asoc2),
                (Prior>Prior2;
                    Prior==Prior1,
                    (Asoc==Asoc2,Asoc==left;Asoc\==Asoc2)),
                !,
                write('('),
                writeAtomInfix(Handle,R1/R,A2,
                    Name2,Ar2,Prior2,Asoc2),
                write(')')
                ;
                writeAtom(Handle,R1/R,A2)
            )
        )
    ).
    




%char

/* Escritura de listas (incluye la escritura de cadenas de cararacteres)
Se hace al modo Prolog, pero con un tratamiento especial para las cadenas de
caracteres que se escriben entre " . Cuando en una de estas cadenas aparecen 
variables se usa la notacion ++.

Ojo: este predicado tambien se usa para escribir listas prolog de verdad con el 
operador . (en fichero en tiempo de compilacion)

*/

%----------------------------------------------------------------------------%
% writeList(+Handle,+L/-R,+T) con T expresion a escribir y L/R acumulador de
% variables
%----------------------------------------------------------------------------%

writeList(Handle,L/L,[]):-!,write(Handle,' []').

writeList(Handle,L/L,':'):-!,write(Handle,'(:)').

writeList(Handle,L/R,':'(A)):-
    !,
    write(Handle,'('),
    writeAtom(Handle,L/R,A),
    write(Handle,':)').

writeList(Handle,L/R,Ls):-writeListProlog(Handle,L/R,Ls).



writeListProlog(Handle,L/L,[]):-!,write(Handle,' []').

writeListProlog(Handle,L/R,Ls):-
    Ls=..[_,Head,Tail], % puede ser el operador : o .
    (
        var(Head),
        !,
%        write(Handle,' [ '),
        write(Handle,'[ '),
        writeAtom(Handle,L/R1,Head),
        writeTail(Handle,R1/R,Tail)
    ;
        Head='$char'(N),
        screenOut(Handle),
        !,
        write(Handle,' "'),
        name(Ch,[N]),
        write(Handle,Ch),
        writeChain(Handle,L/R,Tail)
    ;
%        write(Handle,' [ '),
        write(Handle,'[ '),
        writeAtom(Handle,L/R1,Head),
        writeTail(Handle,R1/R,Tail)
    ).


writeTail(Handle,L/R,Ls):-
    var(Ls),
    !,
    write(Handle,' | '),
    writeAtom(Handle,L/R,Ls),
    write(Handle,' ]').

writeTail(Handle,L/L,[]):-!,write(Handle,' ]').

writeTail(Handle,L/R,Ls):-
    Ls=..[_,Head,Tail],
    (
        var(Head),
        !,
        write(Handle,', '),
        writeAtom(Handle,L/R1,Head),
        writeTail(Handle,R1/R,Tail)
    ;
        Head='$char'(N),
        screenOut(Handle),
        !,
        write(Handle,' ] ++ "'),
        name(Ch,[N]),
        write(Handle,Ch),
        writeChain(Handle,L/R,Tail)
    ;
        write(Handle,', '),
        writeAtom(Handle,L/R1,Head),
        writeTail(Handle,R1/R,Tail)
    ).


writeChain(Handle,L/R,Chain):-
    var(Chain),
    !,
    write(Handle,'" ++ '),
    writeAtom(Handle,L/R,Chain).
    %write(Handle,' ]').
 
writeChain(Handle,L/L,[]):-
    !,
    write(Handle,'"').

writeChain(Handle,L/R,Ls):-
    Ls=..[_,Head,Tail],
    (
        var(Head),
        !,
        write(Handle,'" ++ [ '),
        writeAtom(Handle,L/R1,Head),
        writeTail(Handle,R1/R,Tail)
    ;
        Head='$char'(N),
        !,
        name(Ch,[N]),
        write(Handle,Ch),
        writeChain(Handle,L/R,Tail)
    ;
        write(Handle,'" ++ ['),
        writeAtom(Handle,L/R1,Head),
        writeTail(Handle,R1/R,Tail)
    ).
    

         


/*

writeList(Handle,L/L,Ls):-Ls==[],!,write(Handle,' []').

writeList(Handle,L/L,':'):-!,write(Handle,'(:)').

writeList(Handle,L/R,':'(A)):-
    !,
    write(Handle,'('),
    writeAtom(Handle,L/R,A),
    write(Handle,' :)').

writeList(Handle,L/R,Ls):-
    Ls=..[_,Head,Tail],
    write(Handle,'[ '),
    writeAtom(Handle,L/R1,Head),
    writeTail(Handle,R1/R,Tail),
    write(Handle,' ]').


writeTail(Handle,L/R,Tail):-
    var(Tail),
    !,
    write(Handle,' | '),
    writeAtom(Handle,L/R,Tail).

writeTail(_,L/L,[]):-!.
writeTail(Handle,L/R,Tail):-
    Tail=..[_,Head2,Tail2],
    !,
    write(Handle,', '),
    writeAtom(Handle,L/R1,Head2),
    writeTail(Handle,R1/R,Tail2).   
    
writeTail(Handle,L/R,Tail):-
    write(Handle,' | '),
    writeAtom(Handle,L/R,Tail).



*/

%----------------------------------------------------------------------------%
% screenOut(+Handle)
% comprueba si estamos escribiendo en pantalla, por comparacion de handles
%----------------------------------------------------------------------------%

screenOut(Handle):-current_output(COHandle),!,Handle==COHandle.


%----------------------------------------------------------------------------%
% isOpInfix(+Op,-Prior,-Asoc)
% Mira si es un operador infijo, ya que no todos estan declarados (como = y ->),
% y devuelve su prioridad y su asociatividad.
%----------------------------------------------------------------------------%

isOpInfix(Op,Prior,Asoc):-
    
    (Op=='->',!,Prior=0,Asoc=right)
    ;
    infix(Op,Asoc,Prior)  % escritura de infijos en tiempo de ejecucion
    ;
    infix(Op,Asoc,Prior,_).  % escritura de infijos en tiempo de compilacion


%----------------------------------------------------------------------------%
% writeFun(+Name)
% Saca en pantalla el nombre de una funcion. Si la funcion es $eqFun o $notEqFun
% saca == o /== respectivamente. Si es $apply no saca nada. En otro caso saca el
% nombre que le llega
%----------------------------------------------------------------------------%

writeFun(Name):-
    (Name=='$eqFun',!,writeq('(==)')
    ;
    Name=='$notEqFun',!,writeq('(/=)')
    ;
    Name=='$apply',!
    ;
    number(Name),!,
    (X is integer(Name),X=:=Name,!,write(X);write(Name))
    ;
    writeq(Name)).


%----------------------------------------------------------------------------%
% searchInsertVar(+V,+L/-R,-Name)
% L y R son listas de variables con elementos de la forma (V,Name)
% busca la var V en L. Si esta devuelve su nombre en Name y L=R, si no, la 
% inserta y devuelve R y en Name su nombre
%----------------------------------------------------------------------------%

searchInsertVar(V,L/R,Name):-
    searchInsertVar2(V,L/R,0,Name).


%----------------------------------------------------------------------------%
% searchInsertVar2(+V,+L/-R,+Num,-Name) donde Num es un contador que sirve para
% darle nombre a la variable V si es que V no habia aparecido antes (i.e. no
% estaba en R).
%----------------------------------------------------------------------------%

searchInsertVar2(V,[]/[(V,Name)],Num,Name):-
    !,
    extractName(Num,NameList),
    name(Name,[95|NameList]).   % 95 es el ascii de _

searchInsertVar2(V1,[(V2,Name)|Rest]/[(V2,Name)|Rest],_,Name):-
    V1==V2,
    !.

searchInsertVar2(V,[P|Rest]/[P|Rest1],Num,Name):-
    Num1 is Num+1,
    searchInsertVar2(V,Rest/Rest1,Num1,Name).


%----------------------------------------------------------------------------%
% extractName(+Num,-Name)
% generacion de nombres de las variables
%----------------------------------------------------------------------------%

extractName(0,[65]):-!.
extractName(Num,[Code|L]):-
    Rest is Num mod 26,
    Code is Rest + 65,
    Quotient is Num // 26,
    (Quotient > 0, P is Quotient-1,extractName(P,L);
    L=[]).
