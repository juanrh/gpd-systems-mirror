%Ya no es necesario: el parche se ha metido en codfun.pls

% Parche que arregla el funcionamiento de collect en Toy
% abreviatura para pruebas
%File dado como string sin la extension .pl
pp(File) :- procesa_collect(File).

:- use_module(library(lists)).

procesa_collect(File):-  %File dado como string sin la extension .pl
   append(File,".pl",FIn),
   append(File,"-collect.pl",FOut),
   name(NIn,FIn),
   name(NOut,FOut),
   open(NIn,read,HIn),
   open(NOut,write,HOut),
   procesa(HIn,HOut),
   close(HIn),close(HOut).

procesa(HIn,HOut):- 
 read(HIn,T),
 continua_procesa(T,HIn,HOut).

continua_procesa(end_of_file,_HIn,_HOut) :- !.
continua_procesa(Item,HIn,HOut) :- 
  write('.'),
  cambia(Item,Item1),
  escribe(HOut,Item1),
  procesa(HIn,HOut).

% Solo hay que cambiar clausulas con codigo de funciones de programa
% que llamen a collect. 
% Hay que proteger del cambio otras clausulas
% que menionan a collect
% El codigo de funciones de usuario se reconoce porque los predicados
% son de la forma '$<char>...' donde <char> no es $ (ya que $$ corresponde
% a primitivas que no hay que tocar
cambia(X,X):-   % corresponde al codigo a no tocar
  funtor_principal(X,F), name(F,S), 
  (S\=[36|_] ; S = [36,36|_]), % 36 es $
  !.
cambia((H:-B),(H1:-B1)) :- !,cambiaG(H,H1),cambiaB(B,B1).
cambia(X,X1) :- cambiaG(X,X1).

funtor_principal(X,F):-
 (X=':-'(H,_) ; H=X),!,
  H =.. [F|_].
  
cambiaB((G,Gs),(G1,Gs1)) :- !, cambiaG(G,G1),cambiaB(Gs,Gs1).
cambiaB(G,G1) :- cambiaG(G,G1).

cambiaG(X,X) :- sencillo(X),!.
cambiaG('$collect'(E,H,Cin,COut),'$collect'(Vs^E1,H,Cin,COut)) :- !,cambiaC(E,E1,[],Vs).
cambiaG('$$susp'(F,[E],R,S),'$$susp'('$collect',[Vs^E1],R,S)) :- F=='$collect',!,cambiaC(E,E1,[],Vs).
cambiaG(X,Y) :- X =.. [F|Xs],cambiaGL(Xs,Ys),Y=..[F|Ys].

cambiaGL([],[]).
cambiaGL([X|Xs],[Y|Ys]) :- cambiaG(X,Y),cambiaGL(Xs,Ys).

cambiaC(X,X,Vs,Vs) :- sencillo(X),!.
cambiaC('$$susp'(F,Args,R,S),'$$susp'(F,Args1,R,S),Vs,Vs1) :- !,cambiaCL(Args,Args1,[R,S|Vs],Vs1).
cambiaC(X,Y,Vs,Vs1) :- X =.. [F|Xs],cambiaCL(Xs,Ys,Vs,Vs1),Y=..[F|Ys].

cambiaCL([],[],Vs,Vs).
cambiaCL([X|Xs],[Y|Ys],Vs,Vs1) :- cambiaC(X,Y,Vs,Vs2),cambiaCL(Xs,Ys,Vs2,Vs1).

sencillo(X) :- (var(X);atomic(X)),!.

escribe(H,T) :- writeq(H,T),write(H,'.'),nl(H).


