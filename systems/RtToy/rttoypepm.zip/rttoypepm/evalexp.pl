%----------------------------------------------------------------------------%
% evalexp.pl
%----------------------------------------------------------------------------%
/*
- Author: Mercedes
- Created: 17/11/99
- Description: This module is necesary for the evaluation of expresions. It 
  shows de evaluation in the screen. 
  It's created because we have introduced the option: simple evaluation (for
  closed deterministic expressions). Now, TOY in addition to execute commands
  and solve goals, it evatuates expressions too.
- Modules which they import it: initToy
- Modules imported into it:
    > dds (with 'isNumber').
    > writing (with 'writeAtom').
    > tools (with 'smooth').
    > inferrer (wite 'goalType', 'expressionType').
    > dyn
    > toycomm (with 'hnf').
    > codfun (with 'introduceSusp').
    >transfun (with 'transCheckExp').
    
- Modified: 
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




:- module(evalexp,[tryExpression/1]).

:- load_files(dds,[if(changed),imports([isNumber/2])]).

:- load_files(writing,[if(changed),imports([writeAtom/1])]).

:- load_files(inferrer,[if(changed),imports([expressionType/4])]).

:- load_files(dyn,[if(changed)]).

:- load_files(toycomm,[if(changed),imports([hnf/4,
                                            %%pacol 05-01-2009
                                            introduceSuspCt/3])]).

:- load_files(tools,[if(changed),imports([append/3])]).


% 20-02-01 rafa ponia doWhere/2
:- load_files(codfun,[if(changed),imports([introduceSusp/3,doWhere/3])]).

:- load_files(transfun,[if(changed),imports([transCheckExp/4,transCheckWhere/4])]).

% Depu 31/10/00 mercedotas
:- load_files(initToy,[if(changed),imports([throwConstraints/1,
% 20-02-01 rafa a�adido porque se usa
    removeWhereVars/3])]).
% Fin Depu



% Depu 31/10/00 mercedes
% Lo quitamos no sabemos por que, pero como tampoco sabiamos por que estaba...
% tryExpression([]):-!.
% Fin Depu

tryExpression(WhereCond):-
    % Depu 28/10/00 mercedes

        % quitamos el smoooth, ya no viene la cond. como lista de listas
    % smooth(Goal,GoalP),
    
    throwExpression(WhereCond).
    
    
throwExpression(where([E],Where)):-
    retractalltypeError,
    (
     % solo se comprueban los tipos si no se esta en depuracion
     debugando
    ;
         expressionType(E,goal,[]/_,TE)
        ),
        % Fin Depu
        
    (
     typeError,!
    ; 
    
     % Depu 08/11/00 mercedes
     % el objetivo ([E],Where), que viene del analisis sintactico, 
     % se convierte en codigo Prolog ejecutable (ETSusp)
     convertGoalToExecutableCodeEval(E,Where,ETSusp,Vars),
     % Fin Depu
     
     statistics(runtime,_),
     % Depu 31/10/00 mercedes
     % el codigo generado para el where (hnf's) no escribe nada en pantalla
% Ya no hace falta: 16/11/00     throwConstraints(WhereCode),
     % Fin Depu
     
     tab(6),
     
     % Depu 08/11/00 mercedes
     % Antes el almacen de entrada de $eval era []. Ahora se le pasa CoutWhere
     '$evalList'(ETSusp,Vars,[],Cout),
     % Fin Depu
     
     statistics(runtime,[_,T]),
     nl,tab(6),
     write('Elapsed time: '),
     write(T),
     write(' ms.'),
     nl
    ).


tryExpression(_).


convertGoalToExecutableCodeEval(E,Where,Code,Vars):-
    !,
    transCheckExp(E,[]/Vars1,ET,_),
    
    % Depu 28/10/00 mercedes
    transCheckWhere(Where,Vars1/Vars2,Where1,_),        
    % eliminamos las decl. where
    doWhere(Where1,WhereT,execution),
    %Fin Depu   
    
    introduceSusp(ET,ETSusp,execution),
         
        append(WhereT,[ETSusp],Code),
    

    % 16/11/00 rafa
    % eliminamos la variables del objetivo que han sido instanciadas
    % por el where; estas no deben aparecer en la respuesta 
    removeWhereVars(Vars2,Where1,Vars).
    % Fin Depu

% vamos ejecutando el codigo del where anterior a la evaluaci�n de la 
% expresion
'$evalList'([A,B|R],Vars,Cin,Cout) :-
    !,
    call(A),
    '$evalList'([B|R],Vars,Cin,Cout).

'$evalList'([Single],Vars,Cin,Cout) :-
    !,
        '$eval'(Single,Vars,Cin,Cout).  

'$eval'(ETSusp,Vars,Cin,Cout):- 
    hnf(ETSusp,HE,Cin,Cout1), 
    cont_eval(HE,Vars,Cout1,Cout).
    
    
cont_eval(HE,Vars,Cin,Cout):- 
    var(HE),
    !,
    extractNameVar(HE,Vars,Name),
    write(Name).
    

cont_eval(HE,Vars,Cin,Cout):- 
    isNumber(HE,Name/Arity),
    !,
    write(Name).
    

cont_eval(T,Vars,Cin,Cout):- 
    T=..[Name|Args], 
    (
     Name=='$$tup',!,
     cont_eval_list(Args,Vars,Cin,Cout)
    ;
     Name==',',!,
     write('('),
     cont_eval_tup(Args,Vars,Cin,Cout),
     write(')')
    ;
     (Name==':';Name=='.'),!,   % 13/06/00 mercedes
     writePrologListEval(T,Vars,Cin,Cout)
    ;
     Name=='$char',!,
     cont_eval_char(Args,Vars,Cin,Cout)
    ;
     Name=='$io',!, % 17/05/00 mercedes
     nl,nl,
     write('      io '),
     cont_eval_io(Args,Vars,Cin,Cout)
    ;
     (Args==[],!,writeAtom(Name)
     ;
      write('( '),
      writeAtom(Name),write(' '),
      cont_eval_list(Args,Vars,Cin,Cout),
      write(' )'))
    ).
    

% 17/05/00 mercedes
cont_eval_char([E],Vars,Cin,Cout):-
    writeAtom('$char'(E)).

cont_eval_io([E],Vars,Cin,Cout):-
    cont_eval(E,Vars,Cin,Cout).
    

cont_eval_list([],Vars,Cin,Cout):- !.
cont_eval_list([E],Vars,Cin,Cout):- '$eval'(E,Vars,Cin,Cout).
cont_eval_list([E|Rest],Vars,Cin,Cout):- 
    '$eval'(E,Vars,Cin,Cout1), 
    write(' '),
    cont_eval_list(Rest,Vars,Cout1,Cout).


cont_eval_tup([],Vars,Cin,Cout):- !.
cont_eval_tup([E],Vars,Cin,Cout):- '$eval'(E,Vars,Cin,Cout).
cont_eval_tup([E|Rest],Vars,Cin,Cout):- 
    '$eval'(E,Vars,Cin,Cout1), 
    write(', '),
    cont_eval_tup(Rest,Vars,Cout1,Cout).




writePrologListEval([],Vars,Cin,Cout):-!,write(Handle,' []').

% 13/06/00 mercedes: Se ha modificado porque las listas pueden llegar de
% la forma ':'(X,Xs) o '.'(X,Xs), y en ambos casos hay que tratarlas.
writePrologListEval(Ls,Vars,Cin,Cout):-
    Ls=..[_,Head,Tail],  % puede ser el operador : o .
    (
        nonvar(Head),
        Head='$char'(N),!,
        write(' "'),
        name(Ch,[N]),
        write(Ch),
        hnf(Tail,TailOut,Cin,Cout1),
        writeChainEval(TailOut,Vars,Cout1,Cout)
    ;
        write(' [ '),
        hnf(Head,HeadOut,Cin,Cout1),
        cont_eval(HeadOut,Vars,Cout1,Cout2),
        %writeAtom(Handle,L/R1,Head),
        hnf(Tail,TailOut,Cout2,Cout3),
        writeTailEval(TailOut,Vars,Cout3,Cout)
    ).

/*
writePrologListEval((Head:Tail),Vars,Cin,Cout):-
    (
        nonvar(Head),
        Head='$char'(N),!,
        write(' "'),
        name(Ch,[N]),
        write(Ch),
        hnf(Tail,TailOut,Cin,Cout1),
        writeChainEval(TailOut,Vars,Cout1,Cout)
    ;
        write(' [ '),
        hnf(Head,HeadOut,Cin,Cout1),
        cont_eval(HeadOut,Vars,Cout1,Cout2),
        %writeAtom(Handle,L/R1,Head),
        hnf(Tail,TailOut,Cout2,Cout3),
        writeTailEval(TailOut,Vars,Cout3,Cout)
    ).
*/

writeTailEval(Ls,Vars,Cin,Cout):-
    var(Ls),
    !,
    write(' | '),
    extractNameVar(Ls,Vars,Name),
    write(Name),
    %writeAtom(Handle,L/R,Ls),
    write(' ]').

writeTailEval([],Vars,Cin,Cout):-!,write(' ]').

% 13/06/00 mercedes: Se ha modificado porque las listas pueden llegar de
% la forma ':'(X,Xs) o '.'(X,Xs), y en ambos casos hay que tratarlas.
writeTailEval(Ls,Vars,Cin,Cout):-
    Ls=..[_,Head,Tail],   % puede ser el operador : o .
    (
        nonvar(Head),
        Head='$char'(N),!,
        write(' ] ++ "'),
        name(Ch,[N]),
        write(Ch),
        hnf(Tail,TailOut,Cin,Cout1),
        writeChainEval(TailOut,Vars,Cout1,Cout)
    ;
        write(', '),
        hnf(Head,HeadOut,Cin,Cout1),
        cont_eval(HeadOut,Vars,Cout1,Cout2),
        %writeAtom(Handle,L/R1,Head),
        hnf(Tail,TailOut,Cout2,Cout3),
        writeTailEval(TailOut,Vars,Cout3,Cout)
    ).


/*
writeTailEval((Head:Tail),Vars,Cin,Cout):-
    (
        nonvar(Head),
        Head='$char'(N),!,
        write(' ] ++ "'),
        name(Ch,[N]),
        write(Ch),
        hnf(Tail,TailOut,Cin,Cout1),
        writeChainEval(TailOut,Vars,Cout1,Cout)
    ;
        write(', '),
        hnf(Head,HeadOut,Cin,Cout1),
        cont_eval(HeadOut,Vars,Cout1,Cout2),
        %writeAtom(Handle,L/R1,Head),
        hnf(Tail,TailOut,Cout2,Cout3),
        writeTailEval(TailOut,Vars,Cout3,Cout)
    ).
*/


writeChainEval(Cad,Vars,Cin,Cout):-
    var(Cad),
    !,
    write('" ++ '),
    extractNameVar(Cad,Vars,Name),
    write(Name).
    %writeAtom(Handle,L/R,Cad).
    %write(' ]').
 
writeChainEval([],Vars,Cin,Cout):-
    !,
    write('"').

% 13/06/00 mercedes: Se ha modificado porque las listas pueden llegar de
% la forma ':'(X,Xs) o '.'(X,Xs), y en ambos casos hay que tratarlas.
writeChainEval(Ls,Vars,Cin,Cout):-
    Ls=..[_,Head,Tail],   % puede ser el operador : o .
    (
        nonvar(Head),
        Head='$char'(N),!,
        name(Ch,[N]),
        write(Ch),
        hnf(Tail,TailOut,Cin,Cout1),
        writeChainEval(TailOut,Vars,Cout1,Cout)
    ;
        write('" ++ ['),
        hnf(Head,HeadOut,Cin,Cout1),
        cont_eval(HeadOut,Vars,Cout1,Cout2),
        %writeAtom(Handle,L/R1,Head),
        hnf(Tail,TailOut,Cout2,Cout3),
        writeTailEval(TailOut,Vars,Cout3,Cout)
    ).


/*
writeChainEval((Head:Tail),Vars,Cin,Cout):-
    (
        nonvar(Head),
        Head='$char'(N),!,
        name(Ch,[N]),
        write(Ch),
        hnf(Tail,TailOut,Cin,Cout1),
        writeChainEval(TailOut,Vars,Cout1,Cout)
    ;
        write('" ++ ['),
        hnf(Head,HeadOut,Cin,Cout1),
        cont_eval(HeadOut,Vars,Cout1,Cout2),
        %writeAtom(Handle,L/R1,Head),
        hnf(Tail,TailOut,Cout2,Cout3),
        writeTailEval(TailOut,Vars,Cout3,Cout)
    ).
*/
    
extractNameVar(Var,[(Name,Var1)],Name):- Var==Var1.
extractNameVar(Var,[(Name,Var1)|Rest],Name):- Var==Var1,!.
extractNameVar(Var,[X|Rest],Name):- extractNameVar(Var,Rest,Name).
