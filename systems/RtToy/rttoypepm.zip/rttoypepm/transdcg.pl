%----------------------------------------------------------------------------%
% transdcg.pl
%----------------------------------------------------------------------------%
/*
- Author: Rafa Caballero
- Fecha: 21-02-1996 
- Description: Programa que hace la traslacion de dcg's a clausulas Prolog, es 
  decir, es el programa que sirve para hacer la traslacion de gramma_dcg.pl en 
  gramma_toy.pl. Basado en el traductor de W.F.Clocksin y C.S. Mellish: 
  Programaci�n en Prolog.
  Por tanto, en gramma_toy.pl esta la gramatica precompilada. Si se quiere cambiar
  la gramatica hay que:
  1) Modificar el fichero 'gramma_dcg'
  2) Desde sicstus cargar 'transdcg'
  3) Lanzar el objetivo: trans_dcg('gramma_dcg.pl','gramma_toy.pl').
  4) Incluir al principio de gramma_toy.pl la declaracion de modulo y la carga de
  los modulos de los que necesita importar predicados, i.e. hay que incluir:

:- module(gramma_toy,[section/7, conditionWhere/7,res/1,sep_res/1,tip_res/1,sep/1]).

:- load_files(errortoy,[if(changed),imports([terminal/7])]).

:- load_files(compil,[if(changed),imports([extractTable/3,priorityOperator/4])]).

:- load_files(tools,[if(changed),imports([lookandput/4,member/2])]).  % 06/06/00 mercedes

:- load_files(newout,[if(changed),imports([infix/4,ftype/4,fun/4,primitive/3])]).

- Modified:
	1) Se ha eliminado la cla�sula or. Debido a 3) ya no es necesario.
        2) En la edici�n en castellano faltan las llaves ({}) en la cla�sula
           right_hand({P},S,S,P) :- !.
        3) Con el traductor de Clocksin y Mellish la dcg a-->[b],c se traduce por
           a([b|Ini],Fin):- c(Ini,Fin).
           Esto puede dar problemas en dcg's que incluyan cortes (ver O'Keefe:
           "The Craft of Prolog", cap�tulo 8).
           Con el presente traductor la traducci�n de la dcg anterior ser�a:
           a(Ini,Fin):- terminal(b,Ini,Fin1), c(Fin1,Fin)
           lo que salva el problema se�alado, adem�s de facilitar el tratamiento
           de errores que se ha decidido.
        4) Se ha suprimido la cla�sula left_hand que permit�a el a�adir terminales
           a la derecha del no terminal. Complica demasiado la trauducci�n una 
           vez realizado el cambio 3).
        5) Adem�s de las habituales listas de E/S se han a�adido 4 par�metros:
           El primero  'TablesComp' tupla con las tablas utilizadas
           El segundo  'CI' con el n�mero de terminales le�dos hasta ahora.
           El segundo  'CO' con el n�mero de terminales le�dos tras la producc.
           El tercero  'M' indica si se est� analizando (true) o se est� buscando
           el error m�s profundo (false).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





translate( (P0-->Q0), (P:-Q)) :-  left_hand(P0,S0,S,TablesComp,CI,CO,M,P),
                                right_hand(Q0,S0,S,TablesComp,CI,CO,M,Q1),
                                repass(Q1,Q).

left_hand(NT,S0,S,TablesComp,CI,CO,M,P) :-
                nonvar(NT),
                goal(NT,S0,S,TablesComp,CI,CO,M,P).

right_hand((X1,X2),S0,S,TablesComp,CI,CO,M,P) :-
                !,
                right_hand(X1,S0,S1,TablesComp,CI,CO1,M,P1),
                right_hand(X2,S1,S,TablesComp,CO1,CO,M,P2),
                and(P1,P2,P).

right_hand((X1;X2),S0,S,TablesComp,CI,CO,M,(P1;P2)) :-
                !,
                right_hand(X1,S0,S,TablesComp,CI,CO,M,P1),
                right_hand(X2,S0,S,TablesComp,CI,CO,M,P2).

right_hand((X1|X2),S0,S,TablesComp,CI,CO,M,(P1;P2)) :-
                right_hand((X1;X2),S0,S,TablesComp,CI,CO,M,(P1;P2)).

% cla�sulas prolog
% a�adimos el paso de las tablas a la cla�sula comprobaci�n
right_hand({comprobation(tablescomp,X,Y)},S,S,TablesComp,CI,CI,M,
         comprobation(TablesComp,X,Y))            :- !.

% una cla�sula normal
right_hand({P},S,S,TablesComp,CI,CI,M,P)            :- !.
right_hand(!,S,S,TablesComp,CI,CI,M,!)              :- !.

% Si es un terminal hay que llamar a la funci�n que comprueba si S0
% empieza por Ts. Adem�s alli se hacen las comprobationes de error si se
% est� buscando el mayor error.
right_hand(Ts,S0,S,TablesComp,CI,CO,M,terminal(Ts,S0,S,TablesComp,CI,CO,M)) :-
                islist(Ts),
                !.

% es un no terminal. Se crea una estructura con �l como functor.
right_hand(X,S0,S,TablesComp,CI,CO,M,P) :- goal(X,S0,S,TablesComp,CI,CO,M,P).

% a�adir (o construir) los argumentos S0, S, I, O a la estructura de functor X
goal(X,S0,S,TablesComp,CI,CO,M,P) :- X =.. [F|A],
                                         append(A,[S0,S,TablesComp,CI,CO,M],AX),
                                         P =.. [F|AX].

and(true,P,P)                         :- !.
and(P,true,P)                         :- !.
and(P,Q,(P,Q)).

repass(A,A)                           :- var(A),
                                         !.
repass((A,B),C)                       :- !,
                                         repass1(A,C,R),
                                         repass(B,R).
repass(A,A).

repass1(A,(A,R),R)                    :- var(A),
                                         !.
repass1((A,B),C,R)                    :- !,
                                         repass1(A,C,R1),
                                         repass1(B,R1,R).
repass1(A,(A,R),R).


%-----------------------------------------------------------------------------%
% append(?L1,?L2,?L3) donde L1, L2, L3 son listas de elementos del mismo tipo.
% L3 es el resultado de concatenar L1 con L2.  
%-----------------------------------------------------------------------------%

append([A|B],C,[A|D]) :- append(B,C,D).
append([],X,X).


%-----------------------------------------------------------------------------%
% islist(+L): indica si L es una lista o no.
%-----------------------------------------------------------------------------%

islist([]) :- !.
islist([_|_]).



concatenation([[]|B], C)                  :- !,concatenation(B,C).
concatenation([A],    A)                  :- !.
concatenation([[A|B]|C],[A|D])            :- !,concatenation([B|C],D).




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clausulas para el tratamiento de errores y la comprobaci�n de tokens
% s�lo se las llamar� cuando realmente se est� analizando un programa

% 1.- Cuando la diferencia de listas es el token buscado (�xito)

% 1.a  si el token a comprobar es [], la lista de entrada y la de salida ser�n
%      la misma. No considero el 'modo error', porque la lista vacia como
%      token siempre debe tener una alternativa. Se dar� error en la alternativa.

terminal([],Ini,Ini,_,CI,CI,_).

% 1.b .- El caso normal: �xito durante la ejecuci�n (no 'modo error')

terminal([T],[T|R],R,_,_,_,true).

% 1.c .- si el token a comprobar no es [], y se cumple, en caso de 'modo error'
%        indicar que se ha reconocido un token m�s satisfactoriamente.

terminal([T],[T|R],R,_,CI,CO,false)  :- !, CO is CI + 1.

% 2. Cuando la diferencia no es el token buscado (fallo).
%    S�lo se ofreecen posibilidades para 'modo error'.Si no, fallar es correcto

% 2.a si lo que ocurre es que faltan caracteres en la entrada

terminal(T,[],I,O,CI,CO,false)       :- ( T \== []
                                        ; nonvar(I) , I \== []) ,
                                        error_terminal(CI,T,[]).

% en otro caso se pasa la longitud de lo que queda por tratar

terminal([T],[K|R],S,_,CI,CO,false) :- T \== K ,!, error_terminal(CI,T,K).

error_terminal(Length,Exp,Find)         :-
         (clause(biggest_sintactic_error(L,_,_),_)
         ;
         L = -1
         ),
         !,
         % si queda menos entrada por tratar
         Length >= L,
         % sustituimos el antiguo por el nuevo
         functor(Exp,Type,_),
         arg(1,Exp,Token),
         (
          Length == L , Repe = true
         ;
          Repe = false
         ),
         Exp2 =.. [Type,Token,Repe],
         deleteError,
         assert(biggest_sintactic_error(Length,Find,Exp2)),
         % de todas formas ha habido error
         fail.

deleteError :- retract(biggest_sintactic_error(_,_,_)),!,deleteError.
deleteError :- !.


% algunas funciones para leer ficheros con dcg's
consult_dcg(File)          :- consult_dcg(File,consul,_).
reconsult_dcg(File)        :- consult_dcg(File,reconsul,_),
                              % incluir los nuevos t�rminos
                              end_reconsult.
trans_dcg(File,OutFile)     :- open(OutFile,write,H),
                              consult_dcg(File,file,H),
                              close(H).

%----------------------------------------------------------------------------%
% Nombre: consult_dcg/3(+File,+Mode,+FileOut)
% Arg.  : - File: Nombre del fichero del que se quiere leer
%         - Mode: consul para hacer 'consult' , reconsul para 'reconsult'
%                 y 'file' para dejar escrita la salida en un fichero
%         - FileOut: Handle del fichero de salida si modo = 'file'
% Descr.: consulta o reconsulta (seg�n 'modo') el fichero con cla�sulas dcg
%----------------------------------------------------------------------------%

consult_dcg(File,Mode,FileOut)   :- open(File,read,H),
                                    repeat,
                                      read(H,Term),
                                      process(Term,Mode,FileOut),
                                      Term = end_of_file,
                                    !,
                                    close(H).


%----------------------------------------------------------------------------%
% Nombre: process/2/3(+Term,+Mode[,*FileOut])
% Arg.  : - Term: Un t�rmio que se ha leido de un fichero de dcg's
%         - Mode: 'consul','reconsul' o 'file'
% Descr.: A�ade o sustituye (si modo=reconsul y el t�rmino es una dcg o una
%         cla�sula Prolog) el termino en la B.D. Si modo='file' no altera
%         la B.D. y simplemente escribe la salida a fichero
%----------------------------------------------------------------------------%

process(Term,Mode,_)        :- process(Term,Mode),
                               !.
process(Term,Mode,F)        :- proce(Term,Mode,F),
                               !.
process(Term,_)             :- proce(Term),
                               !.
process(Term,Mode)          :- proce(Term,Mode),
                              !.
user:term_expansion(ClauseE,ClauseS) :- translate(ClauseE,ClauseS).


%----------------------------------------------------------------------------%
% Nombre: proce/1/2(+Term[,+Mode])
% Arg.  : - Term: Un t�rmio que se ha leido de un fichero de dcg's
%         - Mode: S�lo si se trata de una cla�sula Prolog o dcg
%                 Ver 'process/2'
% Descr.: A�ade el t�rmino a la B.D. seg�n su tipo
%         Copiado de Paco L�pez Fraguas y modificado para reconsultar.
%----------------------------------------------------------------------------%

proce(end_of_file)             :- !.

proce(Directive)               :- directive(Directive),
                                    call(Directive).

proce(PrologClause,consul)   :- prolog_clause(PrologClause),
                                    !,
                                    assert(PrologClause).

proce(GrammarRule,consul)    :- grammar_rule(GrammarRule),
                                    translate(GrammarRule,PrologRule),
                                    !,
                                    assert(PrologRule).

proce(PrologClause,reconsul) :- prolog_clause(PrologClause),
                                    substitute(PrologClause),
                                    !.

proce(GrammarRule,reconsul)  :- grammar_rule(GrammarRule),
                                    translate(GrammarRule,PrologClause),
                                    substitute(PrologClause),
                                    !.

proce(PrologClause,file,F)  :- prolog_clause(PrologClause),
                                    !,
                                    write_clause(F,PrologClause).

proce(GrammarRule,file,F)   :- grammar_rule(GrammarRule),
                                    translate(GrammarRule,PrologRule),
                                    !,
                                    write_clause(F,PrologRule).


% tipos de clausulas
directive((:- _))            :- !.
prolog_clause((_ :- _))      :- !.
prolog_clause(Fact)          :- \+ (Fact = (_ --> _)).
grammar_rule((_ --> _)).

% escritura de una cla�sula en fichero en formato legible para Prolog
write_clause(F,Clause)      :- writeq(F,Clause), write(F,'.'), nl(F).


%----------------------------------------------------------------------------%
% Nombre: substitute/1(+PrologRule)
% Arg.  : - PrologRule: Nueva regla a incluir en la B.D.
% Descr.: Busca todas las reglas cuya cabeza coincida con la de la regla y las
%         borra. A continuaci�n incluye la regla nueva en la forma:
%                       new_prolog_rule_reconsult(PrologRule)
%         Al final de la reconsulta habr� que llama a un predicado que
%         cambie estas 'seudo-reglas' por reglas aut�nticas
%----------------------------------------------------------------------------%

substitute(X)                 :- !,
                                retract_complete(X),
                                assert(new_prolog_rule_reconsult(X)).

retract_complete((X:-Z))     :- retract((X:-Z)),retract_complete((X:-Z)).
retract_complete(X)          :- retract((X:-Y)),retract_complete(X).
retract_complete(_).


%----------------------------------------------------------------------------%
% Nombre: end_reconsult/0
% Descr.: Cambia las cla�sulas de la forma 'new_prolog_rule_reconsult(X))'
%         por la cla�sula X.
%----------------------------------------------------------------------------%

end_reconsult               :- clause(new_prolog_rule_reconsult(Y),_),
                                assert(Y),
                                fail.

end_reconsult               :- retract_complete(new_prolog_rule_reconsult(_)).

