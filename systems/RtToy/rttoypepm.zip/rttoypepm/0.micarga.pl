%% Dejo marcas con preguntas con %ppacol
/**********************************************
%El fichero a compilar es toy.pl, pero lo cambio a mitoy.pl
%porque le quito la carga autom�tica
%para hacer copy and paste
use_module(library(system)),working_directory(Old,'f:/0.trabajo/0.juanrhortala/svn/wlpe2008-1/rttoy').
compile(rttoy).
/cd(bancopruebas)
spy(initToy:process/1).
spy(initToy:convertGoalToExecutableCode).
spy(initToy:throwGoal/5).
spy(initToy:call_residue).
spy(initToy:continueGoal).
spy(initToy:throwConstraints).
spy(initToy:askIfMore).
**************************************/

/*------------- primera caza ---------
Lanzo 
X /= (1,2),X==(Y,Z) y solo da una respuesta
Pillada: 19-02-07. Hab�a un corte de mas en initToy:notEqualTerm/4

Pero a pesar de todo mantengo estos comentarios:

* Que co�o son las variables mutables (varmut) de dyn.pl?
Al hacer una igualdad se llama a varmut.
No me extra�a que con estas cosas vayamos lentos...

Representacion de las tuplas: se hace a veces con $$tup, y otras con ','.
No me parece l�gico. Se dan vueltas y vueltas sobre lo mismo

spy(initToy:convertGoalToExecutableCode).

La salida (muestra de respuestas en goals.pl) es inmanejable ahora mismo.
Sonia no deber�a tocar as�.

-------------fin primera caza --------*/
