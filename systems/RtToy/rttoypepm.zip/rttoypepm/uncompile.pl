

%-----------------------------------------------------------------------------%
% uncompile.pl
%-----------------------------------------------------------------------------%
/*
- Author: Rafa
- Description: Produces a file .toy from a file .tmp.out
*/

:- module(uncompile,[uncompile/1]).

:- use_module(library(system)).  % file_exists
:- load_files(tools,[if(changed),imports([eliminateWhites/2, append/3,
              extractNameExtension/3, concatLsts/2, member/2,endFile/1])]).
:- load_files(writing,[if(changed),imports([writeAtom/3])]).

uncompile(File) :-
  append(File,".tmp.out",FileTmpString),        name(FileTmp,FileTmpString),
  append(File,".tmp.out.toy",FileToyString),    name(FileToy,FileToyString),
  (
   file_exists(FileTmp),
   open(FileTmp,read,HTmp), % open for reading
   open(FileToy,write,HToy),
   uncompile(HTmp,HToy),
   close(HTmp), close(HToy)
   ;
    concatLsts(["Cannot open file ",FileTmpString," for reading"], ErrorString),
    name(Error,ErrorString),
    nl, write(Error), nl
   ),
   !.


uncompile(HTmp,HToy) :-
       skipPrologue(HTmp),
        writeFile(HTmp,HToy) ,
        !.

writeFile(HTmp,HToy) :-
        read(HTmp,Clause),
        % asegurarse de que no es fin de fichero
        \+ endFile(Clause),
        % asegurarse de que no se ha terminado el codigo el programa
%        \+ (Clause = cdata(true, _, _, _) ),

        writeClause(HToy,Clause),
        !,
        writeFile(HTmp,HToy).

writeFile(HTmp,HToy) :- !.

skipPrologue(HTmp) :-
        read(HTmp,Clause),
        % asegurarse de que no es fin de fichero
        \+ endFile(Clause),
        % asegurarse de que no es el fin del prologo (cdata('$ValApp...))
        \+ (Clause = cdata('pValApp', _, _, _) ),
        !,
        skipPrologue(HTmp).

skipPrologue(HTmp) :- !.


% writes a clause of the .tmp.out file in Toy's syntax

% function
writeClause(HToy, fun(Name,_Arity,Rules,_Line)) :-
          !,
          name(Name,NameStr),
          append("% function ",NameStr,Comment),
          writeList(HToy,Comment), nl(HToy),
          writeRules(HToy,Rules).

% otherwise skip it
writeClause(HToy,Clause) :- !.

% a list of program rules
writeRules(HToy,[]) :- !, nl(HToy).

writeRules(HToy,[Rule|Rest]) :-
  !,
  writeRule(HToy,Rule),
  writeRules(HToy,Rest).

writeRule(HToy,rule(Head,Body,Conditions,Where,Line)) :-
  !,
  writeHead(HToy,Head),
  write(HToy,'= '),
  writeExp(HToy,Body),
  (Conditions=[]
   ;
   write(HToy,'<== '),
   writeConds(HToy,Conditions)
  ),
  (Where=[]
   ;
   nl(HToy),
   write(HToy,'     where '),
   nl(HToy),
   writeWhere(HToy,Where)
  ),
  nl(HToy).



%----------------------------------------------------------------------------%
% writeWhere(?H,+List)
% Writes to the file the list of conds
%----------------------------------------------------------------------------%
writeWhere(H,[]) :-!.

writeWhere(H,[X|Xs]) :- !,
  write(H,'            '),
  writeExp(H,X),
  nl(H),
  writeWhere(H,Xs).

%----------------------------------------------------------------------------%
% writeConds(?H,+List)
% Writes to the file the list of conds
%----------------------------------------------------------------------------%
writeConds(H,[]) :-!.

writeConds(H,[X|Xs]) :- !,
  writeExp(H,X),
  (Xs = []
  ;
  write(H,', ')
  ),
  !,
  writeConds(H,Xs).


%----------------------------------------------------------------------------%
% writeExp(?H,+Exp)
% Writes to the file and expression
%----------------------------------------------------------------------------%
writeExp(H,E) :-
  E =.. [F,E1,E2],
  (F = '=='; F='/=', F='+'; F='-'; F='*'; F='/'),
  !,
  writeExp(H,E1),
  write(H,' '),
  write(H,F),
  write(H,' '),
  writeExp(H,E2).

writeExp(H,=(E1,E2,_Line)) :-
  !,
  writeExp(H,E1),
  write(H,' = '),
  writeExp(H,E2).

writeExp(H,'$apply'(E1,E2)) :-
  !,
  writeExp(H,E1),
  write(H,' '),
  writeExp(H,E2).


writeExp(H,'$var'(A)) :-
  !,
  writeExp(H,A).

writeExp(H,'$int'(A)) :-
  !,
  writeExp(H,A).


% common types of lists
writeExp(H,:(A, '$var'(B))) :-
        !,
        write(H,'['),
        writeExp(H,A),
        write(H,'|'),
        writeExp(H,B),
        write(H,']').

writeExp(H,('$char'(A):R)):-
        toyStringToList(('$char'(A):R),List),
        !,
        name(Atom,List),
        write(H,'"'),
        write(H,Atom),
        write(H,'"').

writeExp(H,(A:R)):-
        flat_list(R,[],LR),
        !,
        write(H,'['),
        writeExpList(H,[A|LR]),
        write(H,']').



writeExp(H,'$$tup'(','(E1, E2))) :-
        !,
        write(H,'('),
        writeExp(H,E1),
        write(H,', '),
        writeExp(H,E2),
        write(H,')').

writeExp(H,E) :-
  E =.. [F|Args],
  writeAtom(H,F),
  ( Args = []
   ;
    write(H,'('),
    writeExpList(H,Args),
    write(H,')')
  ),
  !.

writeExp(H,E) :-
        !,
        writeAtom(H,E).

writeExpList(H,[]):-!.
writeExpList(H,[X|Xs]):-
     writeExp(H,X),
     (Xs = []
     ;
      write(H,', '),
      writeExpList(H,Xs)
     ),
     !.

writeAtom(H,F) :-
        !,
        name(F,FName),
        remove(39,FName,FName2), % eliminate quotes '
        remove(36,FName2,FName3), % eliminate '$'
        name(F2,FName3),
        writeList(H,FName3).

remove(_N,[],[]):-!.
remove(N,[N|Xs],Xs2) :-
        !,
        remove(N,Xs,Xs2).
remove(N,[X|Xs],[X|Xs2]) :-
        !,
        remove(N,Xs,Xs2).

flat_list([],Ac,Ac):-!.
flat_list((X:Xs),Ac,AcOut) :-
        !,
        append(Ac,[X],Ac2),
        flat_list(Xs,Ac2,AcOut).

%----------------------------------------------------------------------------%
% writeHead(?H,+Head)
% Writes hte lhs to H
%----------------------------------------------------------------------------%

writeHead(HToy,Head):-
  !,
  writeExp(HToy,Head).


%----------------------------------------------------------------------------%
% writeArgs(?H,+List)
% Writes to the file the list of arguments
%----------------------------------------------------------------------------%
writeArgs(H,[]) :-!.
writeArgs(H,[X|Xs]) :- !,
  writeExp(H,X),
  write(H,' '),
  writeArgs(H,Xs).



%----------------------------------------------------------------------------%
% writeList(?H,+string)
% Writes to the file the string
%----------------------------------------------------------------------------%
writeList(H,[]) :- !.
writeList(H,[X|Xs]) :- put(H,X), writeList(H,Xs).

%----------------------------------------------------------------------------%
% toyStringToList(+ToyS,-List)
%
%----------------------------------------------------------------------------%
toyStringToList([],[]):-!.
toyStringToList(('$char'(A):RIn),[A|ROut]):-
	!,
%        name(AS,[A]),
	toyStringToList(RIn,ROut).
