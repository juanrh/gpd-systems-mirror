

user:portray_message(warning,_):- write('').

:- module(plgenerated,[sourceFileNameStr/1,hnf_susp/5,constr/4,funct/5,infix/3,'$$apply'/5,'$flip'/6,'$,$2' /5,'$,$1' /4,'$$$tup$1' /4,'$:$2' /5,'$:$1' /4,'$$char$1' /4,'$$io$1' /4,'$$stream$1' /4,'$$channel$2' /5,'$$channel$1' /4,'$$varmut$1' /4,'$uminus$1' /4,'$abs$1' /4,'$sqrt$1' /4,'$ln$1' /4,'$exp$1' /4,'$sin$1' /4,'$cos$1' /4,'$tan$1' /4,'$cot$1' /4,'$asin$1' /4,'$acos$1' /4,'$atan$1' /4,'$acot$1' /4,'$sinh$1' /4,'$cosh$1' /4,'$tanh$1' /4,'$coth$1' /4,'$asinh$1' /4,'$acosh$1' /4,'$atanh$1' /4,'$acoth$1' /4,'$+$2' /5,'$+$1' /4,'$-$2' /5,'$-$1' /4,'$*$2' /5,'$*$1' /4,'$min$2' /5,'$min$1' /4,'$max$2' /5,'$max$1' /4,'$/$2' /5,'$/$1' /4,'$**$2' /5,'$**$1' /4,'$log$2' /5,'$log$1' /4,'$^$2' /5,'$^$1' /4,'$div$2' /5,'$div$1' /4,'$mod$2' /5,'$mod$1' /4,'$gcd$2' /5,'$gcd$1' /4,'$round$1' /4,'$trunc$1' /4,'$floor$1' /4,'$ceiling$1' /4,'$toReal$1' /4,'$<$2' /5,'$<$1' /4,'$<=$2' /5,'$<=$1' /4,'$>$2' /5,'$>$1' /4,'$>=$2' /5,'$>=$1' /4,'$==$2' /5,'$==$1' /4,'$/=$2' /5,'$/=$1' /4,'$ord$1' /4,'$chr$1' /4,'$putChar$1' /4,'$return$1' /4,'$>>$2' /5,'$>>$1' /4,'$>>=$2' /5,'$>>=$1' /4,'$putStr$1' /4,'$putStrLn$1' /4,'$cont1$1' /4,'$cont2$2' /5,'$cont2$1' /4,'$writeFile$2' /5,'$writeFile$1' /4,'$readFile$1' /4,'$readFileContents$1' /4,'$pVal$1' /4,'$selectWhereVariableXi$4' /7,'$selectWhereVariableXi$3' /6,'$selectWhereVariableXi$2' /5,'$selectWhereVariableXi$1' /4,'$if_then_else$3' /6,'$if_then_else$2' /5,'$if_then_else$1' /4,'$if_then$2' /5,'$if_then$1' /4,'$flip$3' /6,'$flip$2' /5,'$flip$1' /4,'$$returnResult' /8,'$$clean' /4]).

:- dynamic $== /5, $/= /5.

/*  AF0503
:- load_files('$TOYDIR/toycomm',[if(changed)]).

:- load_files('$TOYDIR/primFunct',[if(changed)]).

:- load_files('$TOYDIR/primitivCod',[if(changed)]).
*/
%F010204
:- load_files(tools,[if(changed),imports([complete_root_filename/2])]).

:- complete_root_filename(toycomm,F),load_files(F,[if(changed)]).

:- complete_root_filename(primFunct,F),load_files(F,[if(changed)]).

:- complete_root_filename(primitivCod,F),load_files(F,[if(changed)]).





% nombre del fichero fuente
sourceFileNameStr(basic).


/**************    CODE FOR FUNCTIONS    **************/


% ',$2'
'$,$2'(_A, _B, '$$tup'(','(','(_A, _A), '$void')), _C, _D):-
        equal(_A, _B, _C, _D).

% ',$1'
'$,$1'(_A, '$$tup'(','(',$2'(_A), '$void')), _B, _B).

% '$$tup$1'
'$$$tup$1'(_A, '$$tup'(','('$$tup'(_A), '$void')), _B, _B).

% ':$2'
'$:$2'(_A, _B, '$$tup'(','(:(_A, _A), '$void')), _C, _D):-
        equal(_A, _B, _C, _D).

% ':$1'
'$:$1'(_A, '$$tup'(','(':$2'(_A), '$void')), _B, _B).

% '$char$1'
'$$char$1'(_A, '$$tup'(','('$char'('$$susp'( '$$var',  [ '$$susp'( '$A',  [], _B, _C ) ], _D, _E )), '$void')), _F, _F).

% '$io$1'
'$$io$1'(_A, '$$tup'(','('$io'(_A), '$void')), _B, _B).

% '$stream$1'
'$$stream$1'(_A, '$$tup'(','('$stream'(_A), '$void')), _B, _B).

% '$channel$2'
'$$channel$2'(_A, _B, '$$tup'(','('$channel'(_A, _A), '$void')), _C, _D):-
        equal(_A, _B, _C, _D).

% '$channel$1'
'$$channel$1'(_A, '$$tup'(','('$channel$2'(_A), '$void')), _B, _B).

% '$varmut$1'
'$$varmut$1'(_A, '$$tup'(','('$varmut'(_A), '$void')), _B, _B).

% 'uminus$1'
'$uminus$1'(_A, '$$tup'(','('$$susp'( '$uminus',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'abs$1'
'$abs$1'(_A, '$$tup'(','('$$susp'( '$abs',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'sqrt$1'
'$sqrt$1'(_A, '$$tup'(','('$$susp'( '$sqrt',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'ln$1'
'$ln$1'(_A, '$$tup'(','('$$susp'( '$ln',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'exp$1'
'$exp$1'(_A, '$$tup'(','('$$susp'( '$exp',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'sin$1'
'$sin$1'(_A, '$$tup'(','('$$susp'( '$sin',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'cos$1'
'$cos$1'(_A, '$$tup'(','('$$susp'( '$cos',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'tan$1'
'$tan$1'(_A, '$$tup'(','('$$susp'( '$tan',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'cot$1'
'$cot$1'(_A, '$$tup'(','('$$susp'( '$cot',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'asin$1'
'$asin$1'(_A, '$$tup'(','('$$susp'( '$asin',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'acos$1'
'$acos$1'(_A, '$$tup'(','('$$susp'( '$acos',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'atan$1'
'$atan$1'(_A, '$$tup'(','('$$susp'( '$atan',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'acot$1'
'$acot$1'(_A, '$$tup'(','('$$susp'( '$acot',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'sinh$1'
'$sinh$1'(_A, '$$tup'(','('$$susp'( '$sinh',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'cosh$1'
'$cosh$1'(_A, '$$tup'(','('$$susp'( '$cosh',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'tanh$1'
'$tanh$1'(_A, '$$tup'(','('$$susp'( '$tanh',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'coth$1'
'$coth$1'(_A, '$$tup'(','('$$susp'( '$coth',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'asinh$1'
'$asinh$1'(_A, '$$tup'(','('$$susp'( '$asinh',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'acosh$1'
'$acosh$1'(_A, '$$tup'(','('$$susp'( '$acosh',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'atanh$1'
'$atanh$1'(_A, '$$tup'(','('$$susp'( '$atanh',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'acoth$1'
'$acoth$1'(_A, '$$tup'(','('$$susp'( '$acoth',  [ _A ], _B, _C ), '$void')), _D, _D).

% '+$2'
'$+$2'(_A, _B, '$$tup'(','('$$susp'( $+,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '+$1'
'$+$1'(_A, '$$tup'(','('+$2'(_A), '$void')), _B, _B).

% '-$2'
'$-$2'(_A, _B, '$$tup'(','('$$susp'( $-,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '-$1'
'$-$1'(_A, '$$tup'(','('-$2'(_A), '$void')), _B, _B).

% '*$2'
'$*$2'(_A, _B, '$$tup'(','('$$susp'( $*,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '*$1'
'$*$1'(_A, '$$tup'(','('*$2'(_A), '$void')), _B, _B).

% 'min$2'
'$min$2'(_A, _B, '$$tup'(','('$$susp'( '$min',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'min$1'
'$min$1'(_A, '$$tup'(','('min$2'(_A), '$void')), _B, _B).

% 'max$2'
'$max$2'(_A, _B, '$$tup'(','('$$susp'( '$max',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'max$1'
'$max$1'(_A, '$$tup'(','('max$2'(_A), '$void')), _B, _B).

% '/$2'
'$/$2'(_A, _B, '$$tup'(','('$$susp'( $/,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '/$1'
'$/$1'(_A, '$$tup'(','('/$2'(_A), '$void')), _B, _B).

% '**$2'
'$**$2'(_A, _B, '$$tup'(','('$$susp'( $**,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '**$1'
'$**$1'(_A, '$$tup'(','('**$2'(_A), '$void')), _B, _B).

% 'log$2'
'$log$2'(_A, _B, '$$tup'(','('$$susp'( '$log',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'log$1'
'$log$1'(_A, '$$tup'(','('log$2'(_A), '$void')), _B, _B).

% '^$2'
'$^$2'(_A, _B, '$$tup'(','('$$susp'( $^,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '^$1'
'$^$1'(_A, '$$tup'(','('^$2'(_A), '$void')), _B, _B).

% 'div$2'
'$div$2'(_A, _B, '$$tup'(','('$$susp'( '$div',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'div$1'
'$div$1'(_A, '$$tup'(','('div$2'(_A), '$void')), _B, _B).

% 'mod$2'
'$mod$2'(_A, _B, '$$tup'(','('$$susp'( '$mod',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'mod$1'
'$mod$1'(_A, '$$tup'(','('mod$2'(_A), '$void')), _B, _B).

% 'gcd$2'
'$gcd$2'(_A, _B, '$$tup'(','('$$susp'( '$gcd',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'gcd$1'
'$gcd$1'(_A, '$$tup'(','('gcd$2'(_A), '$void')), _B, _B).

% 'round$1'
'$round$1'(_A, '$$tup'(','('$$susp'( '$round',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'trunc$1'
'$trunc$1'(_A, '$$tup'(','('$$susp'( '$trunc',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'floor$1'
'$floor$1'(_A, '$$tup'(','('$$susp'( '$floor',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'ceiling$1'
'$ceiling$1'(_A, '$$tup'(','('$$susp'( '$ceiling',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'toReal$1'
'$toReal$1'(_A, '$$tup'(','('$$susp'( '$toReal',  [ _A ], _B, _C ), '$void')), _D, _D).

% '<$2'
'$<$2'(_A, _B, '$$tup'(','('$$susp'( $<,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '<$1'
'$<$1'(_A, '$$tup'(','('<$2'(_A), '$void')), _B, _B).

% '<=$2'
'$<=$2'(_A, _B, '$$tup'(','('$$susp'( $<=,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '<=$1'
'$<=$1'(_A, '$$tup'(','('<=$2'(_A), '$void')), _B, _B).

% '>$2'
'$>$2'(_A, _B, '$$tup'(','('$$susp'( $>,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '>$1'
'$>$1'(_A, '$$tup'(','('>$2'(_A), '$void')), _B, _B).

% '>=$2'
'$>=$2'(_A, _B, '$$tup'(','('$$susp'( $>=,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '>=$1'
'$>=$1'(_A, '$$tup'(','('>=$2'(_A), '$void')), _B, _B).

% '==$2'
'$==$2'(_A, _B, '$$tup'(','('$$susp'( '$$eqFun',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '==$1'
'$==$1'(_A, '$$tup'(','('==$2'(_A), '$void')), _B, _B).

% '/=$2'
'$/=$2'(_A, _B, '$$tup'(','('$$susp'( '$$notEqFun',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '/=$1'
'$/=$1'(_A, '$$tup'(','('/=$2'(_A), '$void')), _B, _B).

% 'ord$1'
'$ord$1'(_A, '$$tup'(','('$$susp'( '$ord',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'chr$1'
'$chr$1'(_A, '$$tup'(','('$$susp'( '$chr',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'putChar$1'
'$putChar$1'(_A, '$$tup'(','('$$susp'( '$putChar',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'return$1'
'$return$1'(_A, '$$tup'(','('$$susp'( '$return',  [ _A ], _B, _C ), '$void')), _D, _D).

% '>>$2'
'$>>$2'(_A, _B, '$$tup'(','('$$susp'( $>>,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '>>$1'
'$>>$1'(_A, '$$tup'(','('>>$2'(_A), '$void')), _B, _B).

% '>>=$2'
'$>>=$2'(_A, _B, '$$tup'(','('$$susp'( $>>=,  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% '>>=$1'
'$>>=$1'(_A, '$$tup'(','('>>=$2'(_A), '$void')), _B, _B).

% 'putStr$1'
'$putStr$1'(_A, '$$tup'(','('$$susp'( '$putStr',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'putStrLn$1'
'$putStrLn$1'(_A, '$$tup'(','('$$susp'( '$putStrLn',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'cont1$1'
'$cont1$1'(_A, '$$tup'(','('$$susp'( '$cont1',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'cont2$2'
'$cont2$2'(_A, _B, '$$tup'(','('$$susp'( '$cont2',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'cont2$1'
'$cont2$1'(_A, '$$tup'(','('cont2$2'(_A), '$void')), _B, _B).

% 'writeFile$2'
'$writeFile$2'(_A, _B, '$$tup'(','('$$susp'( '$writeFile',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'writeFile$1'
'$writeFile$1'(_A, '$$tup'(','('writeFile$2'(_A), '$void')), _B, _B).

% 'readFile$1'
'$readFile$1'(_A, '$$tup'(','('$$susp'( '$readFile',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'readFileContents$1'
'$readFileContents$1'(_A, '$$tup'(','('$$susp'( '$readFileContents',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'pVal$1'
'$pVal$1'(_A, '$$tup'(','('$$susp'( '$pVal',  [ _A ], _B, _C ), '$void')), _D, _D).

% 'selectWhereVariableXi$4'
'$selectWhereVariableXi$4'(_A, _B, _C, _D, '$$tup'(','('$$susp'( '$selectWhereVariableXi',  [ _A, _A, _A, _A ], _E, _F ), '$void')), _G, _H):-
        equal(_A, _D, _G, _I),
        equal(_A, _C, _I, _J),
        equal(_A, _B, _J, _H).

% 'selectWhereVariableXi$3'
'$selectWhereVariableXi$3'(_A, _B, _C, '$$tup'(','('selectWhereVariableXi$4'(_A, _A, _A), '$void')), _D, _E):-
        equal(_A, _C, _D, _F),
        equal(_A, _B, _F, _E).

% 'selectWhereVariableXi$2'
'$selectWhereVariableXi$2'(_A, _B, '$$tup'(','('selectWhereVariableXi$3'(_A, _A), '$void')), _C, _D):-
        equal(_A, _B, _C, _D).

% 'selectWhereVariableXi$1'
'$selectWhereVariableXi$1'(_A, '$$tup'(','('selectWhereVariableXi$2'(_A), '$void')), _B, _B).

% 'if_then_else$3'
'$if_then_else$3'(_A, _B, _C, '$$tup'(','('$$susp'( '$if_then_else',  [ _A, _A, _A ], _D, _E ), '$void')), _F, _G):-
        equal(_A, _C, _F, _H),
        equal(_A, _B, _H, _G).

% 'if_then_else$2'
'$if_then_else$2'(_A, _B, '$$tup'(','('if_then_else$3'(_A, _A), '$void')), _C, _D):-
        equal(_A, _B, _C, _D).

% 'if_then_else$1'
'$if_then_else$1'(_A, '$$tup'(','('if_then_else$2'(_A), '$void')), _B, _B).

% 'if_then$2'
'$if_then$2'(_A, _B, '$$tup'(','('$$susp'( '$if_then',  [ _A, _A ], _C, _D ), '$void')), _E, _F):-
        equal(_A, _B, _E, _F).

% 'if_then$1'
'$if_then$1'(_A, '$$tup'(','('if_then$2'(_A), '$void')), _B, _B).

% 'flip$3'
'$flip$3'(_A, _B, _C, '$$tup'(','('$$susp'( '$flip',  [ _A, _A, _A ], _D, _E ), '$void')), _F, _G):-
        equal(_A, _C, _F, _H),
        equal(_A, _B, _H, _G).

% 'flip$2'
'$flip$2'(_A, _B, '$$tup'(','('flip$3'(_A, _A), '$void')), _C, _D):-
        equal(_A, _B, _C, _D).

% 'flip$1'
'$flip$1'(_A, '$$tup'(','('flip$2'(_A), '$void')), _B, _B).

% '$returnResult'
'$$returnResult'(_A, _B, _C, _D, _E, '$$tup'(','(_C, '$cTreeNode'(_A, _B, '$$susp'( '$pVal',  [ _C ], _F, _G ), _D, _E))), _H, _H).

% '$clean'
'$$clean'(_A, _B, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$$clean_1'(_E, _B, _F, _D).
'$$clean_1'(_A, [], _B, _C):-
        unifyHnfs(_A, [], _B, _C).
'$$clean_1'(_A, _B, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        '$if_then_else'('$$susp'( '$$eqFun',  [ _E, '$void' ], _H, _I ), '$$susp'( '$$clean',  [ _F ], _J, _K ), :(_E, '$$susp'( '$$clean',  [ _F ], _L, _M )), _B, _G, _D).
/***********   CONSTRUCTORS AND FUNCTIONS   ***********/

constr(',', 2, ->(_A, ->(_B, ','(_A, _B))), ','(_A, _B)).
constr('$$tup', 1, ->(','(_A, _B), '$$tuple'(','(_A, _B))), '$$tuple'(','(_A, _B))).
constr([], 0, :(_A, []), :(_A, [])).
constr(:, 2, ->(_A, ->(:(_A, []), :(_A, []))), :(_A, [])).
constr('$char', 1, ->(_A, char), char).
constr('$io', 1, ->(_A, '$io'(_A)), '$io'(_A)).
constr('$stream', 1, handle, handle).
constr(readMode, 0, ioMode, ioMode).
constr(writeMode, 0, ioMode, ioMode).
constr(appendMode, 0, ioMode, ioMode).
constr('$channel', 2, channel, channel).
constr('$varmut', 1, varmut, varmut).
constr(true, 0, bool, bool).
constr(false, 0, bool, bool).
constr('$cTreeNode', 5, ->(:(char, []), ->(:(:(char, []), []), ->(:(char, []), ->(:(char, []), ->(:('$cTree', []), '$cTree'))))), '$cTree').
constr('$void', 0, '$cTree', '$cTree').

funct(uminus, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(abs, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(sqrt, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(ln, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(exp, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(coth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acoth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(+, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(-, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(*, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(min, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(max, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(/, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(float))), '$num'(float)).
funct(**, 2, 2, ->('$num'(_A), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(log, 2, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(^, 2, 2, ->('$num'(_A), ->('$num'(int), '$num'(_A))), '$num'(_A)).
funct(div, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(mod, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(gcd, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(round, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(trunc, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(floor, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(ceiling, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(toReal, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(<, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(<=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(==, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(/=, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(ord, 1, 1, ->(char, '$num'(int)), '$num'(int)).
funct(chr, 1, 1, ->('$num'(int), char), char).
funct(putChar, 1, 1, ->(char, io(unit)), io(unit)).
funct(done, 0, 0, io(unit), io(unit)).
funct(getChar, 0, 0, io(char), io(char)).
funct(return, 1, 1, ->(_A, io(_A)), io(_A)).
funct(>>, 2, 2, ->(io(_A), ->(io(_B), io(_B))), io(_B)).
funct(>>=, 2, 2, ->(io(_A), ->(->(_A, io(_B)), io(_B))), io(_B)).
funct(putStr, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(putStrLn, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(getLine, 0, 0, io(:(char, [])), io(:(char, []))).
funct(cont1, 1, 1, ->(char, io(:(char, []))), io(:(char, []))).
funct(cont2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).
funct(writeFile, 2, 2, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(readFile, 1, 1, ->(:(char, []), io(:(char, []))), io(:(char, []))).
funct(readFileContents, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(pVal, 1, 1, ->(_A, :(char, [])), :(char, [])).
funct(selectWhereVariableXi, 4, 4, ->(_A, ->('$num'(int), ->('$num'(int), ->(_B, _C)))), _C).
funct(if_then_else, 3, 3, ->(bool, ->(_A, ->(_A, _A))), _A).
funct(if_then, 2, 2, ->(bool, ->(_A, _A)), _A).
funct(flip, 3, 3, ->(->(_A, ->(_B, _C)), ->(_B, ->(_A, _C))), _C).

funct('$apply', 2, 2, ->(->(->(_A, _B), _A), _B), _B).
funct('$eqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct('$notEqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct(',$2', 2, _A, _B, _C).
funct(',$1', 1, _A, _B, _C).
funct('$$tup$1', 1, _A, _B, _C).
funct(':$2', 2, _A, _B, _C).
funct(':$1', 1, _A, _B, _C).
funct('$char$1', 1, _A, _B, _C).
funct('$io$1', 1, _A, _B, _C).
funct('$stream$1', 1, _A, _B, _C).
funct('$channel$2', 2, _A, _B, _C).
funct('$channel$1', 1, _A, _B, _C).
funct('$varmut$1', 1, _A, _B, _C).
funct('uminus$1', 1, _A, _B, _C).
funct('abs$1', 1, _A, _B, _C).
funct('sqrt$1', 1, _A, _B, _C).
funct('ln$1', 1, _A, _B, _C).
funct('exp$1', 1, _A, _B, _C).
funct('sin$1', 1, _A, _B, _C).
funct('cos$1', 1, _A, _B, _C).
funct('tan$1', 1, _A, _B, _C).
funct('cot$1', 1, _A, _B, _C).
funct('asin$1', 1, _A, _B, _C).
funct('acos$1', 1, _A, _B, _C).
funct('atan$1', 1, _A, _B, _C).
funct('acot$1', 1, _A, _B, _C).
funct('sinh$1', 1, _A, _B, _C).
funct('cosh$1', 1, _A, _B, _C).
funct('tanh$1', 1, _A, _B, _C).
funct('coth$1', 1, _A, _B, _C).
funct('asinh$1', 1, _A, _B, _C).
funct('acosh$1', 1, _A, _B, _C).
funct('atanh$1', 1, _A, _B, _C).
funct('acoth$1', 1, _A, _B, _C).
funct('+$2', 2, _A, _B, _C).
funct('+$1', 1, _A, _B, _C).
funct('-$2', 2, _A, _B, _C).
funct('-$1', 1, _A, _B, _C).
funct('*$2', 2, _A, _B, _C).
funct('*$1', 1, _A, _B, _C).
funct('min$2', 2, _A, _B, _C).
funct('min$1', 1, _A, _B, _C).
funct('max$2', 2, _A, _B, _C).
funct('max$1', 1, _A, _B, _C).
funct('/$2', 2, _A, _B, _C).
funct('/$1', 1, _A, _B, _C).
funct('**$2', 2, _A, _B, _C).
funct('**$1', 1, _A, _B, _C).
funct('log$2', 2, _A, _B, _C).
funct('log$1', 1, _A, _B, _C).
funct('^$2', 2, _A, _B, _C).
funct('^$1', 1, _A, _B, _C).
funct('div$2', 2, _A, _B, _C).
funct('div$1', 1, _A, _B, _C).
funct('mod$2', 2, _A, _B, _C).
funct('mod$1', 1, _A, _B, _C).
funct('gcd$2', 2, _A, _B, _C).
funct('gcd$1', 1, _A, _B, _C).
funct('round$1', 1, _A, _B, _C).
funct('trunc$1', 1, _A, _B, _C).
funct('floor$1', 1, _A, _B, _C).
funct('ceiling$1', 1, _A, _B, _C).
funct('toReal$1', 1, _A, _B, _C).
funct('<$2', 2, _A, _B, _C).
funct('<$1', 1, _A, _B, _C).
funct('<=$2', 2, _A, _B, _C).
funct('<=$1', 1, _A, _B, _C).
funct('>$2', 2, _A, _B, _C).
funct('>$1', 1, _A, _B, _C).
funct('>=$2', 2, _A, _B, _C).
funct('>=$1', 1, _A, _B, _C).
funct('==$2', 2, _A, _B, _C).
funct('==$1', 1, _A, _B, _C).
funct('/=$2', 2, _A, _B, _C).
funct('/=$1', 1, _A, _B, _C).
funct('ord$1', 1, _A, _B, _C).
funct('chr$1', 1, _A, _B, _C).
funct('putChar$1', 1, _A, _B, _C).
funct('return$1', 1, _A, _B, _C).
funct('>>$2', 2, _A, _B, _C).
funct('>>$1', 1, _A, _B, _C).
funct('>>=$2', 2, _A, _B, _C).
funct('>>=$1', 1, _A, _B, _C).
funct('putStr$1', 1, _A, _B, _C).
funct('putStrLn$1', 1, _A, _B, _C).
funct('cont1$1', 1, _A, _B, _C).
funct('cont2$2', 2, _A, _B, _C).
funct('cont2$1', 1, _A, _B, _C).
funct('writeFile$2', 2, _A, _B, _C).
funct('writeFile$1', 1, _A, _B, _C).
funct('readFile$1', 1, _A, _B, _C).
funct('readFileContents$1', 1, _A, _B, _C).
funct('pVal$1', 1, _A, _B, _C).
funct('selectWhereVariableXi$4', 4, _A, _B, _C).
funct('selectWhereVariableXi$3', 3, _A, _B, _C).
funct('selectWhereVariableXi$2', 2, _A, _B, _C).
funct('selectWhereVariableXi$1', 1, _A, _B, _C).
funct('if_then_else$3', 3, _A, _B, _C).
funct('if_then_else$2', 2, _A, _B, _C).
funct('if_then_else$1', 1, _A, _B, _C).
funct('if_then$2', 2, _A, _B, _C).
funct('if_then$1', 1, _A, _B, _C).
funct('flip$3', 3, _A, _B, _C).
funct('flip$2', 2, _A, _B, _C).
funct('flip$1', 1, _A, _B, _C).
funct('$returnResult', 5, _A, _B, _C).
funct('$clean', 1, _A, _B, _C).

/************    CODE FOR FUNCIONS HNF    ************/

hnf_susp('$uminus', '.'(_A, []), _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
hnf_susp('$abs', '.'(_A, []), _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
hnf_susp('$sqrt', '.'(_A, []), _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
hnf_susp('$ln', '.'(_A, []), _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
hnf_susp('$exp', '.'(_A, []), _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
hnf_susp('$sin', '.'(_A, []), _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
hnf_susp('$cos', '.'(_A, []), _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
hnf_susp('$tan', '.'(_A, []), _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
hnf_susp('$cot', '.'(_A, []), _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
hnf_susp('$asin', '.'(_A, []), _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
hnf_susp('$acos', '.'(_A, []), _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
hnf_susp('$atan', '.'(_A, []), _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
hnf_susp('$acot', '.'(_A, []), _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
hnf_susp('$sinh', '.'(_A, []), _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
hnf_susp('$cosh', '.'(_A, []), _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
hnf_susp('$tanh', '.'(_A, []), _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
hnf_susp('$coth', '.'(_A, []), _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
hnf_susp('$asinh', '.'(_A, []), _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
hnf_susp('$acosh', '.'(_A, []), _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
hnf_susp('$atanh', '.'(_A, []), _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
hnf_susp('$acoth', '.'(_A, []), _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
hnf_susp($+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
hnf_susp($-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
hnf_susp($*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
hnf_susp('$min', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
hnf_susp('$max', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
hnf_susp($/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
hnf_susp($**, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
hnf_susp('$log', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
hnf_susp($^, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
hnf_susp('$div', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
hnf_susp('$mod', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
hnf_susp('$gcd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
hnf_susp('$round', '.'(_A, []), _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
hnf_susp('$trunc', '.'(_A, []), _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
hnf_susp('$floor', '.'(_A, []), _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
hnf_susp('$ceiling', '.'(_A, []), _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
hnf_susp('$toReal', '.'(_A, []), _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
hnf_susp($<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
hnf_susp($<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
hnf_susp($>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
hnf_susp($>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
hnf_susp($==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
hnf_susp($/=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
hnf_susp('$ord', '.'(_A, []), _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
hnf_susp('$chr', '.'(_A, []), _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
hnf_susp('$putChar', '.'(_A, []), _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
hnf_susp('$done', [], _A, _B, _C):-
        '$done'(_A, _B, _C).
hnf_susp('$getChar', [], _A, _B, _C):-
        '$getChar'(_A, _B, _C).
hnf_susp('$return', '.'(_A, []), _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
hnf_susp($>>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
hnf_susp($>>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
hnf_susp('$putStr', '.'(_A, []), _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
hnf_susp('$putStrLn', '.'(_A, []), _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
hnf_susp('$getLine', [], _A, _B, _C):-
        '$getLine'(_A, _B, _C).
hnf_susp('$cont1', '.'(_A, []), _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
hnf_susp('$cont2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
hnf_susp('$writeFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
hnf_susp('$readFile', '.'(_A, []), _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
hnf_susp('$readFileContents', '.'(_A, []), _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
hnf_susp('$pVal', '.'(_A, []), _B, _C, _D):-
        '$pVal'(_A, _B, _C, _D).
hnf_susp('$selectWhereVariableXi', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$if_then_else', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
hnf_susp('$if_then', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
hnf_susp('$flip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$$apply', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$apply'(_A, _B, _C, _D, _E).
hnf_susp('$$eqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
hnf_susp('$$notEqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
hnf_susp('$,$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$,$2'(_A, _B, _C, _D, _E).
hnf_susp('$,$1', '.'(_A, []), _B, _C, _D):-
        '$,$1'(_A, _B, _C, _D).
hnf_susp('$$$tup$1', '.'(_A, []), _B, _C, _D):-
        '$$$tup$1'(_A, _B, _C, _D).
hnf_susp('$:$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$:$2'(_A, _B, _C, _D, _E).
hnf_susp('$:$1', '.'(_A, []), _B, _C, _D):-
        '$:$1'(_A, _B, _C, _D).
hnf_susp('$$char$1', '.'(_A, []), _B, _C, _D):-
        '$$char$1'(_A, _B, _C, _D).
hnf_susp('$$io$1', '.'(_A, []), _B, _C, _D):-
        '$$io$1'(_A, _B, _C, _D).
hnf_susp('$$stream$1', '.'(_A, []), _B, _C, _D):-
        '$$stream$1'(_A, _B, _C, _D).
hnf_susp('$$channel$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$channel$2'(_A, _B, _C, _D, _E).
hnf_susp('$$channel$1', '.'(_A, []), _B, _C, _D):-
        '$$channel$1'(_A, _B, _C, _D).
hnf_susp('$$varmut$1', '.'(_A, []), _B, _C, _D):-
        '$$varmut$1'(_A, _B, _C, _D).
hnf_susp('$uminus$1', '.'(_A, []), _B, _C, _D):-
        '$uminus$1'(_A, _B, _C, _D).
hnf_susp('$abs$1', '.'(_A, []), _B, _C, _D):-
        '$abs$1'(_A, _B, _C, _D).
hnf_susp('$sqrt$1', '.'(_A, []), _B, _C, _D):-
        '$sqrt$1'(_A, _B, _C, _D).
hnf_susp('$ln$1', '.'(_A, []), _B, _C, _D):-
        '$ln$1'(_A, _B, _C, _D).
hnf_susp('$exp$1', '.'(_A, []), _B, _C, _D):-
        '$exp$1'(_A, _B, _C, _D).
hnf_susp('$sin$1', '.'(_A, []), _B, _C, _D):-
        '$sin$1'(_A, _B, _C, _D).
hnf_susp('$cos$1', '.'(_A, []), _B, _C, _D):-
        '$cos$1'(_A, _B, _C, _D).
hnf_susp('$tan$1', '.'(_A, []), _B, _C, _D):-
        '$tan$1'(_A, _B, _C, _D).
hnf_susp('$cot$1', '.'(_A, []), _B, _C, _D):-
        '$cot$1'(_A, _B, _C, _D).
hnf_susp('$asin$1', '.'(_A, []), _B, _C, _D):-
        '$asin$1'(_A, _B, _C, _D).
hnf_susp('$acos$1', '.'(_A, []), _B, _C, _D):-
        '$acos$1'(_A, _B, _C, _D).
hnf_susp('$atan$1', '.'(_A, []), _B, _C, _D):-
        '$atan$1'(_A, _B, _C, _D).
hnf_susp('$acot$1', '.'(_A, []), _B, _C, _D):-
        '$acot$1'(_A, _B, _C, _D).
hnf_susp('$sinh$1', '.'(_A, []), _B, _C, _D):-
        '$sinh$1'(_A, _B, _C, _D).
hnf_susp('$cosh$1', '.'(_A, []), _B, _C, _D):-
        '$cosh$1'(_A, _B, _C, _D).
hnf_susp('$tanh$1', '.'(_A, []), _B, _C, _D):-
        '$tanh$1'(_A, _B, _C, _D).
hnf_susp('$coth$1', '.'(_A, []), _B, _C, _D):-
        '$coth$1'(_A, _B, _C, _D).
hnf_susp('$asinh$1', '.'(_A, []), _B, _C, _D):-
        '$asinh$1'(_A, _B, _C, _D).
hnf_susp('$acosh$1', '.'(_A, []), _B, _C, _D):-
        '$acosh$1'(_A, _B, _C, _D).
hnf_susp('$atanh$1', '.'(_A, []), _B, _C, _D):-
        '$atanh$1'(_A, _B, _C, _D).
hnf_susp('$acoth$1', '.'(_A, []), _B, _C, _D):-
        '$acoth$1'(_A, _B, _C, _D).
hnf_susp('$+$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$+$2'(_A, _B, _C, _D, _E).
hnf_susp('$+$1', '.'(_A, []), _B, _C, _D):-
        '$+$1'(_A, _B, _C, _D).
hnf_susp('$-$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$-$2'(_A, _B, _C, _D, _E).
hnf_susp('$-$1', '.'(_A, []), _B, _C, _D):-
        '$-$1'(_A, _B, _C, _D).
hnf_susp('$*$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$*$2'(_A, _B, _C, _D, _E).
hnf_susp('$*$1', '.'(_A, []), _B, _C, _D):-
        '$*$1'(_A, _B, _C, _D).
hnf_susp('$min$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$min$2'(_A, _B, _C, _D, _E).
hnf_susp('$min$1', '.'(_A, []), _B, _C, _D):-
        '$min$1'(_A, _B, _C, _D).
hnf_susp('$max$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$max$2'(_A, _B, _C, _D, _E).
hnf_susp('$max$1', '.'(_A, []), _B, _C, _D):-
        '$max$1'(_A, _B, _C, _D).
hnf_susp('$/$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$/$2'(_A, _B, _C, _D, _E).
hnf_susp('$/$1', '.'(_A, []), _B, _C, _D):-
        '$/$1'(_A, _B, _C, _D).
hnf_susp('$**$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$**$2'(_A, _B, _C, _D, _E).
hnf_susp('$**$1', '.'(_A, []), _B, _C, _D):-
        '$**$1'(_A, _B, _C, _D).
hnf_susp('$log$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$log$2'(_A, _B, _C, _D, _E).
hnf_susp('$log$1', '.'(_A, []), _B, _C, _D):-
        '$log$1'(_A, _B, _C, _D).
hnf_susp('$^$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$^$2'(_A, _B, _C, _D, _E).
hnf_susp('$^$1', '.'(_A, []), _B, _C, _D):-
        '$^$1'(_A, _B, _C, _D).
hnf_susp('$div$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div$2'(_A, _B, _C, _D, _E).
hnf_susp('$div$1', '.'(_A, []), _B, _C, _D):-
        '$div$1'(_A, _B, _C, _D).
hnf_susp('$mod$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mod$2'(_A, _B, _C, _D, _E).
hnf_susp('$mod$1', '.'(_A, []), _B, _C, _D):-
        '$mod$1'(_A, _B, _C, _D).
hnf_susp('$gcd$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$gcd$2'(_A, _B, _C, _D, _E).
hnf_susp('$gcd$1', '.'(_A, []), _B, _C, _D):-
        '$gcd$1'(_A, _B, _C, _D).
hnf_susp('$round$1', '.'(_A, []), _B, _C, _D):-
        '$round$1'(_A, _B, _C, _D).
hnf_susp('$trunc$1', '.'(_A, []), _B, _C, _D):-
        '$trunc$1'(_A, _B, _C, _D).
hnf_susp('$floor$1', '.'(_A, []), _B, _C, _D):-
        '$floor$1'(_A, _B, _C, _D).
hnf_susp('$ceiling$1', '.'(_A, []), _B, _C, _D):-
        '$ceiling$1'(_A, _B, _C, _D).
hnf_susp('$toReal$1', '.'(_A, []), _B, _C, _D):-
        '$toReal$1'(_A, _B, _C, _D).
hnf_susp('$<$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$<$2'(_A, _B, _C, _D, _E).
hnf_susp('$<$1', '.'(_A, []), _B, _C, _D):-
        '$<$1'(_A, _B, _C, _D).
hnf_susp('$<=$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$<=$2'(_A, _B, _C, _D, _E).
hnf_susp('$<=$1', '.'(_A, []), _B, _C, _D):-
        '$<=$1'(_A, _B, _C, _D).
hnf_susp('$>$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$>$2'(_A, _B, _C, _D, _E).
hnf_susp('$>$1', '.'(_A, []), _B, _C, _D):-
        '$>$1'(_A, _B, _C, _D).
hnf_susp('$>=$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$>=$2'(_A, _B, _C, _D, _E).
hnf_susp('$>=$1', '.'(_A, []), _B, _C, _D):-
        '$>=$1'(_A, _B, _C, _D).
hnf_susp('$==$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$==$2'(_A, _B, _C, _D, _E).
hnf_susp('$==$1', '.'(_A, []), _B, _C, _D):-
        '$==$1'(_A, _B, _C, _D).
hnf_susp('$/=$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$/=$2'(_A, _B, _C, _D, _E).
hnf_susp('$/=$1', '.'(_A, []), _B, _C, _D):-
        '$/=$1'(_A, _B, _C, _D).
hnf_susp('$ord$1', '.'(_A, []), _B, _C, _D):-
        '$ord$1'(_A, _B, _C, _D).
hnf_susp('$chr$1', '.'(_A, []), _B, _C, _D):-
        '$chr$1'(_A, _B, _C, _D).
hnf_susp('$putChar$1', '.'(_A, []), _B, _C, _D):-
        '$putChar$1'(_A, _B, _C, _D).
hnf_susp('$return$1', '.'(_A, []), _B, _C, _D):-
        '$return$1'(_A, _B, _C, _D).
hnf_susp('$>>$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$>>$2'(_A, _B, _C, _D, _E).
hnf_susp('$>>$1', '.'(_A, []), _B, _C, _D):-
        '$>>$1'(_A, _B, _C, _D).
hnf_susp('$>>=$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$>>=$2'(_A, _B, _C, _D, _E).
hnf_susp('$>>=$1', '.'(_A, []), _B, _C, _D):-
        '$>>=$1'(_A, _B, _C, _D).
hnf_susp('$putStr$1', '.'(_A, []), _B, _C, _D):-
        '$putStr$1'(_A, _B, _C, _D).
hnf_susp('$putStrLn$1', '.'(_A, []), _B, _C, _D):-
        '$putStrLn$1'(_A, _B, _C, _D).
hnf_susp('$cont1$1', '.'(_A, []), _B, _C, _D):-
        '$cont1$1'(_A, _B, _C, _D).
hnf_susp('$cont2$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$cont2$2'(_A, _B, _C, _D, _E).
hnf_susp('$cont2$1', '.'(_A, []), _B, _C, _D):-
        '$cont2$1'(_A, _B, _C, _D).
hnf_susp('$writeFile$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeFile$2'(_A, _B, _C, _D, _E).
hnf_susp('$writeFile$1', '.'(_A, []), _B, _C, _D):-
        '$writeFile$1'(_A, _B, _C, _D).
hnf_susp('$readFile$1', '.'(_A, []), _B, _C, _D):-
        '$readFile$1'(_A, _B, _C, _D).
hnf_susp('$readFileContents$1', '.'(_A, []), _B, _C, _D):-
        '$readFileContents$1'(_A, _B, _C, _D).
hnf_susp('$pVal$1', '.'(_A, []), _B, _C, _D):-
        '$pVal$1'(_A, _B, _C, _D).
hnf_susp('$selectWhereVariableXi$4', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$selectWhereVariableXi$4'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$selectWhereVariableXi$3', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$selectWhereVariableXi$3'(_A, _B, _C, _D, _E, _F).
hnf_susp('$selectWhereVariableXi$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$selectWhereVariableXi$2'(_A, _B, _C, _D, _E).
hnf_susp('$selectWhereVariableXi$1', '.'(_A, []), _B, _C, _D):-
        '$selectWhereVariableXi$1'(_A, _B, _C, _D).
hnf_susp('$if_then_else$3', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$if_then_else$3'(_A, _B, _C, _D, _E, _F).
hnf_susp('$if_then_else$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then_else$2'(_A, _B, _C, _D, _E).
hnf_susp('$if_then_else$1', '.'(_A, []), _B, _C, _D):-
        '$if_then_else$1'(_A, _B, _C, _D).
hnf_susp('$if_then$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then$2'(_A, _B, _C, _D, _E).
hnf_susp('$if_then$1', '.'(_A, []), _B, _C, _D):-
        '$if_then$1'(_A, _B, _C, _D).
hnf_susp('$flip$3', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$flip$3'(_A, _B, _C, _D, _E, _F).
hnf_susp('$flip$2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$flip$2'(_A, _B, _C, _D, _E).
hnf_susp('$flip$1', '.'(_A, []), _B, _C, _D):-
        '$flip$1'(_A, _B, _C, _D).
hnf_susp('$$returnResult', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$$returnResult'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$$clean', '.'(_A, []), _B, _C, _D):-
        '$$clean'(_A, _B, _C, _D).




/***************     CODE FOR APPLY     ***************/

'$$apply'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$$applyHnf'(_F, _B, _C, _G, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        var(_A),
        !,
        '$$apply_1_var'(_A, _B, _C, _D, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        '$$apply_1'(_A, _B, _C, _D, _E).

% constructors

'$$apply_1'(:, _A, :(_A), _B, _B).
'$$apply_1_var'(_A, _B, :(_B), _C, _D):-
        unifyHnfs(_A, :, _C, _D).

'$$apply_1'(:(_A), _B, :(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, :(_C, _B), _D, _E):-
        unifyHnfs(_A, :(_C), _D, _E).

'$$apply_1'('$io', _A, '$io'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$io'(_B), _C, _D):-
        unifyHnfs(_A, '$io', _C, _D).

'$$apply_1'('$stream', _A, '$stream'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$stream'(_B), _C, _D):-
        unifyHnfs(_A, '$stream', _C, _D).

'$$apply_1'('$channel', _A, '$channel'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$channel'(_B), _C, _D):-
        unifyHnfs(_A, '$channel', _C, _D).

'$$apply_1'('$channel'(_A), _B, '$channel'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$channel'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$channel'(_C), _D, _E).

'$$apply_1'('$varmut', _A, '$varmut'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$varmut'(_B), _C, _D):-
        unifyHnfs(_A, '$varmut', _C, _D).

'$$apply_1'('$cTreeNode', _A, '$cTreeNode'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$cTreeNode'(_B), _C, _D):-
        unifyHnfs(_A, '$cTreeNode', _C, _D).

'$$apply_1'('$cTreeNode'(_A), _B, '$cTreeNode'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$cTreeNode'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$cTreeNode'(_C), _D, _E).

'$$apply_1'('$cTreeNode'(_A, _B), _C, '$cTreeNode'(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, '$cTreeNode'(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, '$cTreeNode'(_C, _D), _E, _F).

'$$apply_1'('$cTreeNode'(_A, _B, _C), _D, '$cTreeNode'(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, '$cTreeNode'(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, '$cTreeNode'(_C, _D, _E), _F, _G).

'$$apply_1'('$cTreeNode'(_A, _B, _C, _D), _E, '$cTreeNode'(_A, _B, _C, _D, _E), _F, _F).
'$$apply_1_var'(_A, _B, '$cTreeNode'(_C, _D, _E, _F, _B), _G, _H):-
        unifyHnfs(_A, '$cTreeNode'(_C, _D, _E, _F), _G, _H).

% parcial aplictions of funs

'$$apply_1'('$eqFun', _A, '$eqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$eqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$eqFun', _C, _D).

'$$apply_1'('$notEqFun', _A, '$notEqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$notEqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$notEqFun', _C, _D).

'$$apply_1'(',$2', _A, ',$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, ',$2'(_B), _C, _D):-
        unifyHnfs(_A, ',$2', _C, _D).

'$$apply_1'(':$2', _A, ':$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, ':$2'(_B), _C, _D):-
        unifyHnfs(_A, ':$2', _C, _D).

'$$apply_1'('$channel$2', _A, '$channel$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$channel$2'(_B), _C, _D):-
        unifyHnfs(_A, '$channel$2', _C, _D).

'$$apply_1'('+$2', _A, '+$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '+$2'(_B), _C, _D):-
        unifyHnfs(_A, '+$2', _C, _D).

'$$apply_1'('-$2', _A, '-$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '-$2'(_B), _C, _D):-
        unifyHnfs(_A, '-$2', _C, _D).

'$$apply_1'('*$2', _A, '*$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '*$2'(_B), _C, _D):-
        unifyHnfs(_A, '*$2', _C, _D).

'$$apply_1'('min$2', _A, 'min$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'min$2'(_B), _C, _D):-
        unifyHnfs(_A, 'min$2', _C, _D).

'$$apply_1'('max$2', _A, 'max$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'max$2'(_B), _C, _D):-
        unifyHnfs(_A, 'max$2', _C, _D).

'$$apply_1'('/$2', _A, '/$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '/$2'(_B), _C, _D):-
        unifyHnfs(_A, '/$2', _C, _D).

'$$apply_1'('**$2', _A, '**$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '**$2'(_B), _C, _D):-
        unifyHnfs(_A, '**$2', _C, _D).

'$$apply_1'('log$2', _A, 'log$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'log$2'(_B), _C, _D):-
        unifyHnfs(_A, 'log$2', _C, _D).

'$$apply_1'('^$2', _A, '^$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '^$2'(_B), _C, _D):-
        unifyHnfs(_A, '^$2', _C, _D).

'$$apply_1'('div$2', _A, 'div$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'div$2'(_B), _C, _D):-
        unifyHnfs(_A, 'div$2', _C, _D).

'$$apply_1'('mod$2', _A, 'mod$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'mod$2'(_B), _C, _D):-
        unifyHnfs(_A, 'mod$2', _C, _D).

'$$apply_1'('gcd$2', _A, 'gcd$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'gcd$2'(_B), _C, _D):-
        unifyHnfs(_A, 'gcd$2', _C, _D).

'$$apply_1'('<$2', _A, '<$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '<$2'(_B), _C, _D):-
        unifyHnfs(_A, '<$2', _C, _D).

'$$apply_1'('<=$2', _A, '<=$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '<=$2'(_B), _C, _D):-
        unifyHnfs(_A, '<=$2', _C, _D).

'$$apply_1'('>$2', _A, '>$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '>$2'(_B), _C, _D):-
        unifyHnfs(_A, '>$2', _C, _D).

'$$apply_1'('>=$2', _A, '>=$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '>=$2'(_B), _C, _D):-
        unifyHnfs(_A, '>=$2', _C, _D).

'$$apply_1'('==$2', _A, '==$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '==$2'(_B), _C, _D):-
        unifyHnfs(_A, '==$2', _C, _D).

'$$apply_1'('/=$2', _A, '/=$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '/=$2'(_B), _C, _D):-
        unifyHnfs(_A, '/=$2', _C, _D).

'$$apply_1'('>>$2', _A, '>>$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '>>$2'(_B), _C, _D):-
        unifyHnfs(_A, '>>$2', _C, _D).

'$$apply_1'('>>=$2', _A, '>>=$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '>>=$2'(_B), _C, _D):-
        unifyHnfs(_A, '>>=$2', _C, _D).

'$$apply_1'('cont2$2', _A, 'cont2$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'cont2$2'(_B), _C, _D):-
        unifyHnfs(_A, 'cont2$2', _C, _D).

'$$apply_1'('writeFile$2', _A, 'writeFile$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'writeFile$2'(_B), _C, _D):-
        unifyHnfs(_A, 'writeFile$2', _C, _D).

'$$apply_1'('selectWhereVariableXi$4', _A, 'selectWhereVariableXi$4'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'selectWhereVariableXi$4'(_B), _C, _D):-
        unifyHnfs(_A, 'selectWhereVariableXi$4', _C, _D).

'$$apply_1'('selectWhereVariableXi$4'(_A), _B, 'selectWhereVariableXi$4'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'selectWhereVariableXi$4'(_C, _B), _D, _E):-
        unifyHnfs(_A, 'selectWhereVariableXi$4'(_C), _D, _E).

'$$apply_1'('selectWhereVariableXi$4'(_A, _B), _C, 'selectWhereVariableXi$4'(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, 'selectWhereVariableXi$4'(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, 'selectWhereVariableXi$4'(_C, _D), _E, _F).

'$$apply_1'('selectWhereVariableXi$3', _A, 'selectWhereVariableXi$3'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'selectWhereVariableXi$3'(_B), _C, _D):-
        unifyHnfs(_A, 'selectWhereVariableXi$3', _C, _D).

'$$apply_1'('selectWhereVariableXi$3'(_A), _B, 'selectWhereVariableXi$3'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'selectWhereVariableXi$3'(_C, _B), _D, _E):-
        unifyHnfs(_A, 'selectWhereVariableXi$3'(_C), _D, _E).

'$$apply_1'('selectWhereVariableXi$2', _A, 'selectWhereVariableXi$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'selectWhereVariableXi$2'(_B), _C, _D):-
        unifyHnfs(_A, 'selectWhereVariableXi$2', _C, _D).

'$$apply_1'('if_then_else$3', _A, 'if_then_else$3'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'if_then_else$3'(_B), _C, _D):-
        unifyHnfs(_A, 'if_then_else$3', _C, _D).

'$$apply_1'('if_then_else$3'(_A), _B, 'if_then_else$3'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'if_then_else$3'(_C, _B), _D, _E):-
        unifyHnfs(_A, 'if_then_else$3'(_C), _D, _E).

'$$apply_1'('if_then_else$2', _A, 'if_then_else$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'if_then_else$2'(_B), _C, _D):-
        unifyHnfs(_A, 'if_then_else$2', _C, _D).

'$$apply_1'('if_then$2', _A, 'if_then$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'if_then$2'(_B), _C, _D):-
        unifyHnfs(_A, 'if_then$2', _C, _D).

'$$apply_1'('flip$3', _A, 'flip$3'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'flip$3'(_B), _C, _D):-
        unifyHnfs(_A, 'flip$3', _C, _D).

'$$apply_1'('flip$3'(_A), _B, 'flip$3'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'flip$3'(_C, _B), _D, _E):-
        unifyHnfs(_A, 'flip$3'(_C), _D, _E).

'$$apply_1'('flip$2', _A, 'flip$2'(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'flip$2'(_B), _C, _D):-
        unifyHnfs(_A, 'flip$2', _C, _D).

'$$apply_1'('$returnResult', _A, '$returnResult'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$returnResult'(_B), _C, _D):-
        unifyHnfs(_A, '$returnResult', _C, _D).

'$$apply_1'('$returnResult'(_A), _B, '$returnResult'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$returnResult'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$returnResult'(_C), _D, _E).

'$$apply_1'('$returnResult'(_A, _B), _C, '$returnResult'(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, '$returnResult'(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, '$returnResult'(_C, _D), _E, _F).

'$$apply_1'('$returnResult'(_A, _B, _C), _D, '$returnResult'(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, '$returnResult'(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, '$returnResult'(_C, _D, _E), _F, _G).

% parcial aplictions of prims

'$$apply_1'(+, _A, +(_A), _B, _B).
'$$apply_1_var'(_A, _B, +(_B), _C, _D):-
        unifyHnfs(_A, +, _C, _D).

'$$apply_1'(-, _A, -(_A), _B, _B).
'$$apply_1_var'(_A, _B, -(_B), _C, _D):-
        unifyHnfs(_A, -, _C, _D).

'$$apply_1'(*, _A, *(_A), _B, _B).
'$$apply_1_var'(_A, _B, *(_B), _C, _D):-
        unifyHnfs(_A, *, _C, _D).

'$$apply_1'(min, _A, min(_A), _B, _B).
'$$apply_1_var'(_A, _B, min(_B), _C, _D):-
        unifyHnfs(_A, min, _C, _D).

'$$apply_1'(max, _A, max(_A), _B, _B).
'$$apply_1_var'(_A, _B, max(_B), _C, _D):-
        unifyHnfs(_A, max, _C, _D).

'$$apply_1'(/, _A, /(_A), _B, _B).
'$$apply_1_var'(_A, _B, /(_B), _C, _D):-
        unifyHnfs(_A, /, _C, _D).

'$$apply_1'(**, _A, **(_A), _B, _B).
'$$apply_1_var'(_A, _B, **(_B), _C, _D):-
        unifyHnfs(_A, **, _C, _D).

'$$apply_1'(log, _A, log(_A), _B, _B).
'$$apply_1_var'(_A, _B, log(_B), _C, _D):-
        unifyHnfs(_A, log, _C, _D).

'$$apply_1'(^, _A, ^(_A), _B, _B).
'$$apply_1_var'(_A, _B, ^(_B), _C, _D):-
        unifyHnfs(_A, ^, _C, _D).

'$$apply_1'(div, _A, div(_A), _B, _B).
'$$apply_1_var'(_A, _B, div(_B), _C, _D):-
        unifyHnfs(_A, div, _C, _D).

'$$apply_1'(mod, _A, mod(_A), _B, _B).
'$$apply_1_var'(_A, _B, mod(_B), _C, _D):-
        unifyHnfs(_A, mod, _C, _D).

'$$apply_1'(gcd, _A, gcd(_A), _B, _B).
'$$apply_1_var'(_A, _B, gcd(_B), _C, _D):-
        unifyHnfs(_A, gcd, _C, _D).

'$$apply_1'(<, _A, <(_A), _B, _B).
'$$apply_1_var'(_A, _B, <(_B), _C, _D):-
        unifyHnfs(_A, <, _C, _D).

'$$apply_1'(<=, _A, <=(_A), _B, _B).
'$$apply_1_var'(_A, _B, <=(_B), _C, _D):-
        unifyHnfs(_A, <=, _C, _D).

'$$apply_1'(>, _A, >(_A), _B, _B).
'$$apply_1_var'(_A, _B, >(_B), _C, _D):-
        unifyHnfs(_A, >, _C, _D).

'$$apply_1'(>=, _A, >=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >=(_B), _C, _D):-
        unifyHnfs(_A, >=, _C, _D).

'$$apply_1'(==, _A, ==(_A), _B, _B).
'$$apply_1_var'(_A, _B, ==(_B), _C, _D):-
        unifyHnfs(_A, ==, _C, _D).

'$$apply_1'(/=, _A, /=(_A), _B, _B).
'$$apply_1_var'(_A, _B, /=(_B), _C, _D):-
        unifyHnfs(_A, /=, _C, _D).

'$$apply_1'(>>, _A, >>(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>(_B), _C, _D):-
        unifyHnfs(_A, >>, _C, _D).

'$$apply_1'(>>=, _A, >>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>=(_B), _C, _D):-
        unifyHnfs(_A, >>=, _C, _D).

'$$apply_1'(cont2, _A, cont2(_A), _B, _B).
'$$apply_1_var'(_A, _B, cont2(_B), _C, _D):-
        unifyHnfs(_A, cont2, _C, _D).

'$$apply_1'(writeFile, _A, writeFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeFile(_B), _C, _D):-
        unifyHnfs(_A, writeFile, _C, _D).

'$$apply_1'(selectWhereVariableXi, _A, selectWhereVariableXi(_A), _B, _B).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_B), _C, _D):-
        unifyHnfs(_A, selectWhereVariableXi, _C, _D).

'$$apply_1'(selectWhereVariableXi(_A), _B, selectWhereVariableXi(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _B), _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_C), _D, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B), _C, selectWhereVariableXi(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, selectWhereVariableXi(_C, _D), _E, _F).

'$$apply_1'(if_then_else, _A, if_then_else(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then_else(_B), _C, _D):-
        unifyHnfs(_A, if_then_else, _C, _D).

'$$apply_1'(if_then_else(_A), _B, if_then_else(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, if_then_else(_C, _B), _D, _E):-
        unifyHnfs(_A, if_then_else(_C), _D, _E).

'$$apply_1'(if_then, _A, if_then(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then(_B), _C, _D):-
        unifyHnfs(_A, if_then, _C, _D).

'$$apply_1'(flip, _A, flip(_A), _B, _B).
'$$apply_1_var'(_A, _B, flip(_B), _C, _D):-
        unifyHnfs(_A, flip, _C, _D).

'$$apply_1'(flip(_A), _B, flip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, flip(_C, _B), _D, _E):-
        unifyHnfs(_A, flip(_C), _D, _E).

% functions

'$$apply_1'('$eqFun'(_A), _B, _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$eqFun'(_F), _D, _G),
        '$$eqFun'(_F, _B, _C, _G, _E).

'$$apply_1'('$notEqFun'(_A), _B, _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$notEqFun'(_F), _D, _G),
        '$$notEqFun'(_F, _B, _C, _G, _E).

'$$apply_1'(',$2'(_A), _B, _C, _D, _E):-
        '$,$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ',$2'(_F), _D, _G),
        '$,$2'(_F, _B, _C, _G, _E).

'$$apply_1'(',$1', _A, _B, _C, _D):-
        '$,$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ',$1', _D, _F),
        '$,$1'(_B, _C, _F, _E).

'$$apply_1'('$$tup$1', _A, _B, _C, _D):-
        '$$$tup$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$$tup$1', _D, _F),
        '$$$tup$1'(_B, _C, _F, _E).

'$$apply_1'(':$2'(_A), _B, _C, _D, _E):-
        '$:$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ':$2'(_F), _D, _G),
        '$:$2'(_F, _B, _C, _G, _E).

'$$apply_1'(':$1', _A, _B, _C, _D):-
        '$:$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ':$1', _D, _F),
        '$:$1'(_B, _C, _F, _E).

'$$apply_1'('$char$1', _A, _B, _C, _D):-
        '$$char$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$char$1', _D, _F),
        '$$char$1'(_B, _C, _F, _E).

'$$apply_1'('$io$1', _A, _B, _C, _D):-
        '$$io$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$io$1', _D, _F),
        '$$io$1'(_B, _C, _F, _E).

'$$apply_1'('$stream$1', _A, _B, _C, _D):-
        '$$stream$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$stream$1', _D, _F),
        '$$stream$1'(_B, _C, _F, _E).

'$$apply_1'('$channel$2'(_A), _B, _C, _D, _E):-
        '$$channel$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$channel$2'(_F), _D, _G),
        '$$channel$2'(_F, _B, _C, _G, _E).

'$$apply_1'('$channel$1', _A, _B, _C, _D):-
        '$$channel$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$channel$1', _D, _F),
        '$$channel$1'(_B, _C, _F, _E).

'$$apply_1'('$varmut$1', _A, _B, _C, _D):-
        '$$varmut$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$varmut$1', _D, _F),
        '$$varmut$1'(_B, _C, _F, _E).

'$$apply_1'('uminus$1', _A, _B, _C, _D):-
        '$uminus$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'uminus$1', _D, _F),
        '$uminus$1'(_B, _C, _F, _E).

'$$apply_1'('abs$1', _A, _B, _C, _D):-
        '$abs$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'abs$1', _D, _F),
        '$abs$1'(_B, _C, _F, _E).

'$$apply_1'('sqrt$1', _A, _B, _C, _D):-
        '$sqrt$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'sqrt$1', _D, _F),
        '$sqrt$1'(_B, _C, _F, _E).

'$$apply_1'('ln$1', _A, _B, _C, _D):-
        '$ln$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'ln$1', _D, _F),
        '$ln$1'(_B, _C, _F, _E).

'$$apply_1'('exp$1', _A, _B, _C, _D):-
        '$exp$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'exp$1', _D, _F),
        '$exp$1'(_B, _C, _F, _E).

'$$apply_1'('sin$1', _A, _B, _C, _D):-
        '$sin$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'sin$1', _D, _F),
        '$sin$1'(_B, _C, _F, _E).

'$$apply_1'('cos$1', _A, _B, _C, _D):-
        '$cos$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cos$1', _D, _F),
        '$cos$1'(_B, _C, _F, _E).

'$$apply_1'('tan$1', _A, _B, _C, _D):-
        '$tan$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'tan$1', _D, _F),
        '$tan$1'(_B, _C, _F, _E).

'$$apply_1'('cot$1', _A, _B, _C, _D):-
        '$cot$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cot$1', _D, _F),
        '$cot$1'(_B, _C, _F, _E).

'$$apply_1'('asin$1', _A, _B, _C, _D):-
        '$asin$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'asin$1', _D, _F),
        '$asin$1'(_B, _C, _F, _E).

'$$apply_1'('acos$1', _A, _B, _C, _D):-
        '$acos$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'acos$1', _D, _F),
        '$acos$1'(_B, _C, _F, _E).

'$$apply_1'('atan$1', _A, _B, _C, _D):-
        '$atan$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'atan$1', _D, _F),
        '$atan$1'(_B, _C, _F, _E).

'$$apply_1'('acot$1', _A, _B, _C, _D):-
        '$acot$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'acot$1', _D, _F),
        '$acot$1'(_B, _C, _F, _E).

'$$apply_1'('sinh$1', _A, _B, _C, _D):-
        '$sinh$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'sinh$1', _D, _F),
        '$sinh$1'(_B, _C, _F, _E).

'$$apply_1'('cosh$1', _A, _B, _C, _D):-
        '$cosh$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cosh$1', _D, _F),
        '$cosh$1'(_B, _C, _F, _E).

'$$apply_1'('tanh$1', _A, _B, _C, _D):-
        '$tanh$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'tanh$1', _D, _F),
        '$tanh$1'(_B, _C, _F, _E).

'$$apply_1'('coth$1', _A, _B, _C, _D):-
        '$coth$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'coth$1', _D, _F),
        '$coth$1'(_B, _C, _F, _E).

'$$apply_1'('asinh$1', _A, _B, _C, _D):-
        '$asinh$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'asinh$1', _D, _F),
        '$asinh$1'(_B, _C, _F, _E).

'$$apply_1'('acosh$1', _A, _B, _C, _D):-
        '$acosh$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'acosh$1', _D, _F),
        '$acosh$1'(_B, _C, _F, _E).

'$$apply_1'('atanh$1', _A, _B, _C, _D):-
        '$atanh$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'atanh$1', _D, _F),
        '$atanh$1'(_B, _C, _F, _E).

'$$apply_1'('acoth$1', _A, _B, _C, _D):-
        '$acoth$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'acoth$1', _D, _F),
        '$acoth$1'(_B, _C, _F, _E).

'$$apply_1'('+$2'(_A), _B, _C, _D, _E):-
        '$+$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '+$2'(_F), _D, _G),
        '$+$2'(_F, _B, _C, _G, _E).

'$$apply_1'('+$1', _A, _B, _C, _D):-
        '$+$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '+$1', _D, _F),
        '$+$1'(_B, _C, _F, _E).

'$$apply_1'('-$2'(_A), _B, _C, _D, _E):-
        '$-$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '-$2'(_F), _D, _G),
        '$-$2'(_F, _B, _C, _G, _E).

'$$apply_1'('-$1', _A, _B, _C, _D):-
        '$-$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '-$1', _D, _F),
        '$-$1'(_B, _C, _F, _E).

'$$apply_1'('*$2'(_A), _B, _C, _D, _E):-
        '$*$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '*$2'(_F), _D, _G),
        '$*$2'(_F, _B, _C, _G, _E).

'$$apply_1'('*$1', _A, _B, _C, _D):-
        '$*$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '*$1', _D, _F),
        '$*$1'(_B, _C, _F, _E).

'$$apply_1'('min$2'(_A), _B, _C, _D, _E):-
        '$min$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'min$2'(_F), _D, _G),
        '$min$2'(_F, _B, _C, _G, _E).

'$$apply_1'('min$1', _A, _B, _C, _D):-
        '$min$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'min$1', _D, _F),
        '$min$1'(_B, _C, _F, _E).

'$$apply_1'('max$2'(_A), _B, _C, _D, _E):-
        '$max$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'max$2'(_F), _D, _G),
        '$max$2'(_F, _B, _C, _G, _E).

'$$apply_1'('max$1', _A, _B, _C, _D):-
        '$max$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'max$1', _D, _F),
        '$max$1'(_B, _C, _F, _E).

'$$apply_1'('/$2'(_A), _B, _C, _D, _E):-
        '$/$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '/$2'(_F), _D, _G),
        '$/$2'(_F, _B, _C, _G, _E).

'$$apply_1'('/$1', _A, _B, _C, _D):-
        '$/$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '/$1', _D, _F),
        '$/$1'(_B, _C, _F, _E).

'$$apply_1'('**$2'(_A), _B, _C, _D, _E):-
        '$**$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '**$2'(_F), _D, _G),
        '$**$2'(_F, _B, _C, _G, _E).

'$$apply_1'('**$1', _A, _B, _C, _D):-
        '$**$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '**$1', _D, _F),
        '$**$1'(_B, _C, _F, _E).

'$$apply_1'('log$2'(_A), _B, _C, _D, _E):-
        '$log$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'log$2'(_F), _D, _G),
        '$log$2'(_F, _B, _C, _G, _E).

'$$apply_1'('log$1', _A, _B, _C, _D):-
        '$log$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'log$1', _D, _F),
        '$log$1'(_B, _C, _F, _E).

'$$apply_1'('^$2'(_A), _B, _C, _D, _E):-
        '$^$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '^$2'(_F), _D, _G),
        '$^$2'(_F, _B, _C, _G, _E).

'$$apply_1'('^$1', _A, _B, _C, _D):-
        '$^$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '^$1', _D, _F),
        '$^$1'(_B, _C, _F, _E).

'$$apply_1'('div$2'(_A), _B, _C, _D, _E):-
        '$div$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'div$2'(_F), _D, _G),
        '$div$2'(_F, _B, _C, _G, _E).

'$$apply_1'('div$1', _A, _B, _C, _D):-
        '$div$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'div$1', _D, _F),
        '$div$1'(_B, _C, _F, _E).

'$$apply_1'('mod$2'(_A), _B, _C, _D, _E):-
        '$mod$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'mod$2'(_F), _D, _G),
        '$mod$2'(_F, _B, _C, _G, _E).

'$$apply_1'('mod$1', _A, _B, _C, _D):-
        '$mod$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'mod$1', _D, _F),
        '$mod$1'(_B, _C, _F, _E).

'$$apply_1'('gcd$2'(_A), _B, _C, _D, _E):-
        '$gcd$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'gcd$2'(_F), _D, _G),
        '$gcd$2'(_F, _B, _C, _G, _E).

'$$apply_1'('gcd$1', _A, _B, _C, _D):-
        '$gcd$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'gcd$1', _D, _F),
        '$gcd$1'(_B, _C, _F, _E).

'$$apply_1'('round$1', _A, _B, _C, _D):-
        '$round$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'round$1', _D, _F),
        '$round$1'(_B, _C, _F, _E).

'$$apply_1'('trunc$1', _A, _B, _C, _D):-
        '$trunc$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'trunc$1', _D, _F),
        '$trunc$1'(_B, _C, _F, _E).

'$$apply_1'('floor$1', _A, _B, _C, _D):-
        '$floor$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'floor$1', _D, _F),
        '$floor$1'(_B, _C, _F, _E).

'$$apply_1'('ceiling$1', _A, _B, _C, _D):-
        '$ceiling$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'ceiling$1', _D, _F),
        '$ceiling$1'(_B, _C, _F, _E).

'$$apply_1'('toReal$1', _A, _B, _C, _D):-
        '$toReal$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'toReal$1', _D, _F),
        '$toReal$1'(_B, _C, _F, _E).

'$$apply_1'('<$2'(_A), _B, _C, _D, _E):-
        '$<$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '<$2'(_F), _D, _G),
        '$<$2'(_F, _B, _C, _G, _E).

'$$apply_1'('<$1', _A, _B, _C, _D):-
        '$<$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '<$1', _D, _F),
        '$<$1'(_B, _C, _F, _E).

'$$apply_1'('<=$2'(_A), _B, _C, _D, _E):-
        '$<=$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '<=$2'(_F), _D, _G),
        '$<=$2'(_F, _B, _C, _G, _E).

'$$apply_1'('<=$1', _A, _B, _C, _D):-
        '$<=$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '<=$1', _D, _F),
        '$<=$1'(_B, _C, _F, _E).

'$$apply_1'('>$2'(_A), _B, _C, _D, _E):-
        '$>$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>$2'(_F), _D, _G),
        '$>$2'(_F, _B, _C, _G, _E).

'$$apply_1'('>$1', _A, _B, _C, _D):-
        '$>$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>$1', _D, _F),
        '$>$1'(_B, _C, _F, _E).

'$$apply_1'('>=$2'(_A), _B, _C, _D, _E):-
        '$>=$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>=$2'(_F), _D, _G),
        '$>=$2'(_F, _B, _C, _G, _E).

'$$apply_1'('>=$1', _A, _B, _C, _D):-
        '$>=$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>=$1', _D, _F),
        '$>=$1'(_B, _C, _F, _E).

'$$apply_1'('==$2'(_A), _B, _C, _D, _E):-
        '$==$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '==$2'(_F), _D, _G),
        '$==$2'(_F, _B, _C, _G, _E).

'$$apply_1'('==$1', _A, _B, _C, _D):-
        '$==$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '==$1', _D, _F),
        '$==$1'(_B, _C, _F, _E).

'$$apply_1'('/=$2'(_A), _B, _C, _D, _E):-
        '$/=$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '/=$2'(_F), _D, _G),
        '$/=$2'(_F, _B, _C, _G, _E).

'$$apply_1'('/=$1', _A, _B, _C, _D):-
        '$/=$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '/=$1', _D, _F),
        '$/=$1'(_B, _C, _F, _E).

'$$apply_1'('ord$1', _A, _B, _C, _D):-
        '$ord$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'ord$1', _D, _F),
        '$ord$1'(_B, _C, _F, _E).

'$$apply_1'('chr$1', _A, _B, _C, _D):-
        '$chr$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'chr$1', _D, _F),
        '$chr$1'(_B, _C, _F, _E).

'$$apply_1'('putChar$1', _A, _B, _C, _D):-
        '$putChar$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'putChar$1', _D, _F),
        '$putChar$1'(_B, _C, _F, _E).

'$$apply_1'('return$1', _A, _B, _C, _D):-
        '$return$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'return$1', _D, _F),
        '$return$1'(_B, _C, _F, _E).

'$$apply_1'('>>$2'(_A), _B, _C, _D, _E):-
        '$>>$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>>$2'(_F), _D, _G),
        '$>>$2'(_F, _B, _C, _G, _E).

'$$apply_1'('>>$1', _A, _B, _C, _D):-
        '$>>$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>>$1', _D, _F),
        '$>>$1'(_B, _C, _F, _E).

'$$apply_1'('>>=$2'(_A), _B, _C, _D, _E):-
        '$>>=$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>>=$2'(_F), _D, _G),
        '$>>=$2'(_F, _B, _C, _G, _E).

'$$apply_1'('>>=$1', _A, _B, _C, _D):-
        '$>>=$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '>>=$1', _D, _F),
        '$>>=$1'(_B, _C, _F, _E).

'$$apply_1'('putStr$1', _A, _B, _C, _D):-
        '$putStr$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'putStr$1', _D, _F),
        '$putStr$1'(_B, _C, _F, _E).

'$$apply_1'('putStrLn$1', _A, _B, _C, _D):-
        '$putStrLn$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'putStrLn$1', _D, _F),
        '$putStrLn$1'(_B, _C, _F, _E).

'$$apply_1'('cont1$1', _A, _B, _C, _D):-
        '$cont1$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cont1$1', _D, _F),
        '$cont1$1'(_B, _C, _F, _E).

'$$apply_1'('cont2$2'(_A), _B, _C, _D, _E):-
        '$cont2$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cont2$2'(_F), _D, _G),
        '$cont2$2'(_F, _B, _C, _G, _E).

'$$apply_1'('cont2$1', _A, _B, _C, _D):-
        '$cont2$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cont2$1', _D, _F),
        '$cont2$1'(_B, _C, _F, _E).

'$$apply_1'('writeFile$2'(_A), _B, _C, _D, _E):-
        '$writeFile$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'writeFile$2'(_F), _D, _G),
        '$writeFile$2'(_F, _B, _C, _G, _E).

'$$apply_1'('writeFile$1', _A, _B, _C, _D):-
        '$writeFile$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'writeFile$1', _D, _F),
        '$writeFile$1'(_B, _C, _F, _E).

'$$apply_1'('readFile$1', _A, _B, _C, _D):-
        '$readFile$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'readFile$1', _D, _F),
        '$readFile$1'(_B, _C, _F, _E).

'$$apply_1'('readFileContents$1', _A, _B, _C, _D):-
        '$readFileContents$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'readFileContents$1', _D, _F),
        '$readFileContents$1'(_B, _C, _F, _E).

'$$apply_1'('pVal$1', _A, _B, _C, _D):-
        '$pVal$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'pVal$1', _D, _F),
        '$pVal$1'(_B, _C, _F, _E).

'$$apply_1'('selectWhereVariableXi$4'(_A, _B, _C), _D, _E, _F, _G):-
        '$selectWhereVariableXi$4'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'selectWhereVariableXi$4'(_F, _G, _H), _D, _I),
        '$selectWhereVariableXi$4'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'('selectWhereVariableXi$3'(_A, _B), _C, _D, _E, _F):-
        '$selectWhereVariableXi$3'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'selectWhereVariableXi$3'(_F, _G), _D, _H),
        '$selectWhereVariableXi$3'(_F, _G, _B, _C, _H, _E).

'$$apply_1'('selectWhereVariableXi$2'(_A), _B, _C, _D, _E):-
        '$selectWhereVariableXi$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'selectWhereVariableXi$2'(_F), _D, _G),
        '$selectWhereVariableXi$2'(_F, _B, _C, _G, _E).

'$$apply_1'('selectWhereVariableXi$1', _A, _B, _C, _D):-
        '$selectWhereVariableXi$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'selectWhereVariableXi$1', _D, _F),
        '$selectWhereVariableXi$1'(_B, _C, _F, _E).

'$$apply_1'('if_then_else$3'(_A, _B), _C, _D, _E, _F):-
        '$if_then_else$3'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'if_then_else$3'(_F, _G), _D, _H),
        '$if_then_else$3'(_F, _G, _B, _C, _H, _E).

'$$apply_1'('if_then_else$2'(_A), _B, _C, _D, _E):-
        '$if_then_else$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'if_then_else$2'(_F), _D, _G),
        '$if_then_else$2'(_F, _B, _C, _G, _E).

'$$apply_1'('if_then_else$1', _A, _B, _C, _D):-
        '$if_then_else$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'if_then_else$1', _D, _F),
        '$if_then_else$1'(_B, _C, _F, _E).

'$$apply_1'('if_then$2'(_A), _B, _C, _D, _E):-
        '$if_then$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'if_then$2'(_F), _D, _G),
        '$if_then$2'(_F, _B, _C, _G, _E).

'$$apply_1'('if_then$1', _A, _B, _C, _D):-
        '$if_then$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'if_then$1', _D, _F),
        '$if_then$1'(_B, _C, _F, _E).

'$$apply_1'('flip$3'(_A, _B), _C, _D, _E, _F):-
        '$flip$3'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'flip$3'(_F, _G), _D, _H),
        '$flip$3'(_F, _G, _B, _C, _H, _E).

'$$apply_1'('flip$2'(_A), _B, _C, _D, _E):-
        '$flip$2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'flip$2'(_F), _D, _G),
        '$flip$2'(_F, _B, _C, _G, _E).

'$$apply_1'('flip$1', _A, _B, _C, _D):-
        '$flip$1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'flip$1', _D, _F),
        '$flip$1'(_B, _C, _F, _E).

'$$apply_1'('$returnResult'(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$$returnResult'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$returnResult'(_F, _G, _H, _I), _D, _J),
        '$$returnResult'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'('$clean', _A, _B, _C, _D):-
        '$$clean'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$clean', _D, _F),
        '$$clean'(_B, _C, _F, _E).

% primitives

'$$apply_1'(uminus, _A, _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uminus, _D, _F),
        '$uminus'(_B, _C, _F, _E).

'$$apply_1'(abs, _A, _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, abs, _D, _F),
        '$abs'(_B, _C, _F, _E).

'$$apply_1'(sqrt, _A, _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sqrt, _D, _F),
        '$sqrt'(_B, _C, _F, _E).

'$$apply_1'(ln, _A, _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ln, _D, _F),
        '$ln'(_B, _C, _F, _E).

'$$apply_1'(exp, _A, _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exp, _D, _F),
        '$exp'(_B, _C, _F, _E).

'$$apply_1'(sin, _A, _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sin, _D, _F),
        '$sin'(_B, _C, _F, _E).

'$$apply_1'(cos, _A, _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cos, _D, _F),
        '$cos'(_B, _C, _F, _E).

'$$apply_1'(tan, _A, _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tan, _D, _F),
        '$tan'(_B, _C, _F, _E).

'$$apply_1'(cot, _A, _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cot, _D, _F),
        '$cot'(_B, _C, _F, _E).

'$$apply_1'(asin, _A, _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asin, _D, _F),
        '$asin'(_B, _C, _F, _E).

'$$apply_1'(acos, _A, _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acos, _D, _F),
        '$acos'(_B, _C, _F, _E).

'$$apply_1'(atan, _A, _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atan, _D, _F),
        '$atan'(_B, _C, _F, _E).

'$$apply_1'(acot, _A, _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acot, _D, _F),
        '$acot'(_B, _C, _F, _E).

'$$apply_1'(sinh, _A, _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sinh, _D, _F),
        '$sinh'(_B, _C, _F, _E).

'$$apply_1'(cosh, _A, _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cosh, _D, _F),
        '$cosh'(_B, _C, _F, _E).

'$$apply_1'(tanh, _A, _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tanh, _D, _F),
        '$tanh'(_B, _C, _F, _E).

'$$apply_1'(coth, _A, _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, coth, _D, _F),
        '$coth'(_B, _C, _F, _E).

'$$apply_1'(asinh, _A, _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asinh, _D, _F),
        '$asinh'(_B, _C, _F, _E).

'$$apply_1'(acosh, _A, _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acosh, _D, _F),
        '$acosh'(_B, _C, _F, _E).

'$$apply_1'(atanh, _A, _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atanh, _D, _F),
        '$atanh'(_B, _C, _F, _E).

'$$apply_1'(acoth, _A, _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acoth, _D, _F),
        '$acoth'(_B, _C, _F, _E).

'$$apply_1'(+(_A), _B, _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, +(_F), _D, _G),
        $+(_F, _B, _C, _G, _E).

'$$apply_1'(-(_A), _B, _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, -(_F), _D, _G),
        $-(_F, _B, _C, _G, _E).

'$$apply_1'(*(_A), _B, _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, *(_F), _D, _G),
        $*(_F, _B, _C, _G, _E).

'$$apply_1'(min(_A), _B, _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, min(_F), _D, _G),
        '$min'(_F, _B, _C, _G, _E).

'$$apply_1'(max(_A), _B, _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, max(_F), _D, _G),
        '$max'(_F, _B, _C, _G, _E).

'$$apply_1'(/(_A), _B, _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /(_F), _D, _G),
        $/(_F, _B, _C, _G, _E).

'$$apply_1'(**(_A), _B, _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, **(_F), _D, _G),
        $**(_F, _B, _C, _G, _E).

'$$apply_1'(log(_A), _B, _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, log(_F), _D, _G),
        '$log'(_F, _B, _C, _G, _E).

'$$apply_1'(^(_A), _B, _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ^(_F), _D, _G),
        $^(_F, _B, _C, _G, _E).

'$$apply_1'(div(_A), _B, _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, div(_F), _D, _G),
        '$div'(_F, _B, _C, _G, _E).

'$$apply_1'(mod(_A), _B, _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mod(_F), _D, _G),
        '$mod'(_F, _B, _C, _G, _E).

'$$apply_1'(gcd(_A), _B, _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, gcd(_F), _D, _G),
        '$gcd'(_F, _B, _C, _G, _E).

'$$apply_1'(round, _A, _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, round, _D, _F),
        '$round'(_B, _C, _F, _E).

'$$apply_1'(trunc, _A, _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trunc, _D, _F),
        '$trunc'(_B, _C, _F, _E).

'$$apply_1'(floor, _A, _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, floor, _D, _F),
        '$floor'(_B, _C, _F, _E).

'$$apply_1'(ceiling, _A, _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ceiling, _D, _F),
        '$ceiling'(_B, _C, _F, _E).

'$$apply_1'(toReal, _A, _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, toReal, _D, _F),
        '$toReal'(_B, _C, _F, _E).

'$$apply_1'(<(_A), _B, _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <(_F), _D, _G),
        $<(_F, _B, _C, _G, _E).

'$$apply_1'(<=(_A), _B, _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <=(_F), _D, _G),
        $<=(_F, _B, _C, _G, _E).

'$$apply_1'(>(_A), _B, _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >(_F), _D, _G),
        $>(_F, _B, _C, _G, _E).

'$$apply_1'(>=(_A), _B, _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >=(_F), _D, _G),
        $>=(_F, _B, _C, _G, _E).

'$$apply_1'(==(_A), _B, _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ==(_F), _D, _G),
        $==(_F, _B, _C, _G, _E).

'$$apply_1'(/=(_A), _B, _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /=(_F), _D, _G),
        $/=(_F, _B, _C, _G, _E).

'$$apply_1'(ord, _A, _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ord, _D, _F),
        '$ord'(_B, _C, _F, _E).

'$$apply_1'(chr, _A, _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, chr, _D, _F),
        '$chr'(_B, _C, _F, _E).

'$$apply_1'(putChar, _A, _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putChar, _D, _F),
        '$putChar'(_B, _C, _F, _E).

'$$apply_1'(return, _A, _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, return, _D, _F),
        '$return'(_B, _C, _F, _E).

'$$apply_1'(>>(_A), _B, _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>(_F), _D, _G),
        $>>(_F, _B, _C, _G, _E).

'$$apply_1'(>>=(_A), _B, _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>=(_F), _D, _G),
        $>>=(_F, _B, _C, _G, _E).

'$$apply_1'(putStr, _A, _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStr, _D, _F),
        '$putStr'(_B, _C, _F, _E).

'$$apply_1'(putStrLn, _A, _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLn, _D, _F),
        '$putStrLn'(_B, _C, _F, _E).

'$$apply_1'(cont1, _A, _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont1, _D, _F),
        '$cont1'(_B, _C, _F, _E).

'$$apply_1'(cont2(_A), _B, _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont2(_F), _D, _G),
        '$cont2'(_F, _B, _C, _G, _E).

'$$apply_1'(writeFile(_A), _B, _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeFile(_F), _D, _G),
        '$writeFile'(_F, _B, _C, _G, _E).

'$$apply_1'(readFile, _A, _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFile, _D, _F),
        '$readFile'(_B, _C, _F, _E).

'$$apply_1'(readFileContents, _A, _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFileContents, _D, _F),
        '$readFileContents'(_B, _C, _F, _E).

'$$apply_1'(pVal, _A, _B, _C, _D):-
        '$pVal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, pVal, _D, _F),
        '$pVal'(_B, _C, _F, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B, _C), _D, _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_F, _G, _H), _D, _I),
        '$selectWhereVariableXi'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(if_then_else(_A, _B), _C, _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then_else(_F, _G), _D, _H),
        '$if_then_else'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(if_then(_A), _B, _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then(_F), _D, _G),
        '$if_then'(_F, _B, _C, _G, _E).

'$$apply_1'(flip(_A, _B), _C, _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, flip(_F, _G), _D, _H),
        '$flip'(_F, _G, _B, _C, _H, _E).


/************   CODE FOR INFIX OPERATORS   ************/

infix(^, noasoc, 98).
infix(**, noasoc, 98).
infix(/, left, 90).
infix(*, right, 90).
infix(+, left, 50).
infix(-, left, 50).
infix(<, noasoc, 30).
infix(<=, noasoc, 30).
infix(>, noasoc, 30).
infix(>=, noasoc, 30).
infix(==, noasoc, 10).
infix(/=, noasoc, 10).
infix(>>, left, 11).
infix(>>=, left, 11).



'$flip'(F, A1, A2, H, Cin, Cout):-         '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).
