%-----------------------------------------------------------------------------%
% osystem.pl
%-----------------------------------------------------------------------------%
/*
- Author: Jaime
- Description: This module contains the predicates with calls to the system.
  This module is different acording to the platform where we are working: Linux,
  Windows... To change the plataform, we only have to modified this module.
- Modules which import it: process, initToy.
- Modules imported into it:
    > tools (with 'concatLsts' and 'append').
    > dyn.
- Modified:
    26/01/00 mercedes (ya no se usa pathToy para saber el path donde estan
               los fuentes de TOY, sino que se usa la variable
               de entorno: TOYDIR, por tanto se ha eliminado todo
               lo relativo a pathToy).

*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(osystem,[makeTemp/2,deleteTemps/1,/*saveState/1, */ goodFiles/0,
           loadFilesIo/3,loadFilesGra/3,loadFilesClpr/3,loadFilesDefault/3]).

:- load_files(tools,[if(changed),imports([concatLsts/2,append/3,copyFile/2,appendFile/2])]).

:- load_files(dyn,[if(changed)]).

:- use_module(library(system)).

%-----------------------------------------------------------------------------%
% makeTemp(+NF,+Extension): this predicate creates a new file NF.tmp.toy. This
% new file is NF.toy + basic.toy.
% Rafa 25062005: Version without using neither the shell nor the ToyDir environment variable
%-----------------------------------------------------------------------------%
makeTemp(Name,Ext) :-       
      !,
       % rename Name.Ext to Name.tmp.toy
       concatLsts([Name,Ext],SourceFile),
       name(SourceFileName,SourceFile),
       concatLsts([Name,".tmp.toy"],TargetFile),
       name(TargetFileName,TargetFile),
       copyFile(SourceFileName,TargetFileName),
       % append  basic.toy at the end of Name.tmp.toy
       toy:toydir(D),
       name(D,ToyDir),
       concatLsts([ToyDir,"basic.toy"],BasicFile),
       name(BasicFileName,BasicFile),
       appendFile(BasicFileName,TargetFileName).
        
%-----------------------------------------------------------------------------%
% deleteTemps(+File): This predicate deletes the temporal files which have been
% generated in compilation (File.tmp.toy, File.tmp.tmp).
% Rafa 01/06/05 eliminated references to the operating  system, using delete_file instead
%-----------------------------------------------------------------------------%

deleteTemps(F):-
    append(F,".tmp.toy",A),
    name(Nbab,A),
        (file_exists(Nbab),!,
        delete_file(Nbab,[ignore])
        ; true),
    append(F,".tmp.tmp",B),
    name(Ntemp,B),
        (file_exists(Ntemp),!,
        delete_file(Ntemp,[ignore])
       ;
        true),!.


% goodFiles: Restores the default files used at startup
%Rafa 25062005: Version using neither the environment variable TOYDIR nor the shell commands
goodFiles:-
       !,
       toy:toydir(D),       
       name(D,NPath),
       copyFile(NPath, "primitivCodcopia.pl", "primitivCod.pl"),
       copyFile(NPath, "primFunctcopia.pl", "primFunct.pl"),
       copyFile(NPath, "basiccopia.pl", "basic.pl"),
       copyFile(NPath, "basiccopia.toy", "basic.toy").

        
 % load the files corresponding to the i/o library
 loadFilesIo(P,T1,B):-
       !,
       toy:toydir(D),       
       name(D,NPath),
       
       % primFunct.pl will be primFunct.pl + primFunctIo.pl. 
       appendFile(NPath,"primFunctIo.pl","primFunct.pl"),
       % basic.toy will be basic.toy + basicIo.toy , and basic.pl will be basic.pl + basicIo.pl
       appendFile(NPath,"basicIo.toy","basic.toy"),
       appendFile(NPath,"basicIo.pl","basic.pl"),

       % complete the arguments
       append(NPath,"basic",NB),
       name(B,NB),
       append(NPath,"primFunct",NP),
       name(P,NP),       
       append(NPath,"primitivCodIo",T),
       name(T1,T).
    
% load the files corresponding to the graphics library
 loadFilesGra(P,T1,B):-
       !,
       toy:toydir(D),       
       name(D,NPath),
       
       % primFunct.pl will be primFunct.pl + primFunctIo.pl. 
       appendFile(NPath,"primFunctGra.pl","primFunct.pl"),
       % basic.toy will be basic.toy + basicIo.toy , and basic.pl will be basic.pl + basicIo.pl
       appendFile(NPath,"basicGra.toy","basic.toy"),
       appendFile(NPath,"basicGra.pl","basic.pl"),

       % complete the arguments
       append(NPath,"basic",NB),
       name(B,NB),
       append(NPath,"primFunct",NP),
       name(P,NP),       
       append(NPath,"primitivCodGra",T),
       name(T1,T).

% load the files corresponding to the clpr library
 loadFilesClpr(P,T1,B):-
       !,
       toy:toydir(D),       
       name(D,NPath),
       
       % primitivCod.pl will be primitivCodClpr.pl 
       copyFile(NPath, "primitivCodClpr.pl", "primitivCod.pl"),
       % primFunct.pl will be primFunct.pl + primFunctClpr.pl. 
       appendFile(NPath,"primFunctClpr.pl","primFunct.pl"),
       % basic.toy will be basic.toy + basicClpr.toy , and basic.pl will be basic.pl + basicClpr.pl
       appendFile(NPath,"basicClpr.toy","basic.toy"),
       appendFile(NPath,"basicClpr.pl","basic.pl"),

       % complete the arguments
       append(NPath,"basic",NB),
       name(B,NB),
       append(NPath,"primFunct",NP),
       name(P,NP),       
       append(NPath,"primitivCod",T),
       name(T1,T).

% load the default files 
 loadFilesDefault(P,T1,B):-
       !,
       toy:toydir(D),       
       name(D,NPath),
       
       % The default files primFunct.pl, basic.toy, and basic.pl will be restored 
       % by goodFiles from primFunctcopia.pl, basiccopia.toy, and basiccopia.pl, resp.
       goodFiles,
       
       % complete the arguments
       append(NPath,"basic",NB),
       name(B,NB),
       append(NPath,"primFunct",NP),
       name(P,NP),       
       append(NPath,"primitivCod",T),
       name(T1,T).

%%%%% auxiliary predicates
 % copy the source file over the target file,using the path NPath
copyFile(NPath,Source,Target)  :-
        !,
        append(NPath,Source,S),
        name(SN,S),
        append(NPath,Target,T),
        name(TN,T),
        copyFile(SN,TN).

% append F1 at the end of F2, using the path NPath        
appendFile(NPath,F1,F2) :- 
        % first, rename F2 to "filetemp.tmp"
       append(NPath,F2,PF2),
       append(NPath,"filetemp.tmp",PFT),
       name(PF2N,PF2), 
       name(PFTN,PFT),
       copyFile(PF2N,PFTN),       
       % second, append F1 at the end of "filetemp.tmp"
       append(NPath,F1,PF1),
       name(PF1N,PF1),
       appendFile(PF1N,PFTN),
       % thirth, copy "filetemp.tmp" to F2
       copyFile(PFTN,PF2N),        
       % fourth, delete temporal file
       delete_file(PFTN,[ignore]).
       

       
