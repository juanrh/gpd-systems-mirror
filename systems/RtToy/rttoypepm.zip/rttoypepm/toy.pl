%----------------------------------------------------------------------------%
% toy.pl
%----------------------------------------------------------------------------%
/*
- Description: Es el modulo que carga todo el sistema TOY.
- Modules that imports: 
    > initToy.pl (with 'initiate').
    > tools (with 'append').
    > dyn.
- Modified:
     26/10/99 mercedes (modules).
     26/01/00 mercedes (ya no se usa pathToy para saber el path donde estan
               los fuentes de TOY, sino que se usa la variable
               de entorno: TOYDIR, por tanto se ha eliminado todo
               lo relativo a pathToy).

*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    

:- module(toy,[initiate/0,toyversion/1]).

:- prolog_flag(redefine_warnings,_,off),
%F010204 Para eliminar los mensajes de reglas discontiguas
   prolog_flag(discontiguous_warnings,_,off).

% The next module is necesary to do calls to the system. 

:- use_module(library(system)).

%F010204
% Sets a flag indicating which OS we are running Toy on (windows, unix)
:-
    (retract(toy:os(X)); true),
    ((environ('COMSPEC',C), file_exists(C)) -> assert(toy:os(windows)); assert(toy:os(unix))).


%R20062005
% Sets a flag indicating the path to toy

%F062006
%append([A|B],C,[A|D]):- append(B,C,D).
%append([],X,X).
:- load_files(tools,[if(changed),imports([append/3])]).

:-     
%       (retract(toy:toydir(X)); true), %F062006 No parece ser �til
       working_directory(D,D), 
       name(D,A), 
       append(A,"/",AwithSlash), 
       name(DwithSlash,AwithSlash), 
       assert(toy:toydir(DwithSlash)).

% Restores the default files (no libraries loaded)
:- load_files(osystem,[if(changed),imports([goodFiles/0])]), 
   goodFiles.

:- load_files(initToy,[if(changed),imports([initiate/0])]).

:- load_files(dyn,[if(changed)]).

% The next module is necesary for Sicstus3 because it contains the predicate
% chk_subsumes(?General,?Specific) <-> specific is a instance of General.
% This predicate doesn't bind variables and it's used in inferrer.pl

:-use_module(library(terms)).

% This flag is necesary because we want that the distribution's versions do load
% (of the ql) and our versions do compile.
        
:- assertdevelopment_version.

% F0606 Software release version
%B Sonia
%toyversion('2.2.3').
toyversion('2.3.0').
%E Sonia

% System banner
:-
      nl,nl, toyversion(Version),
      write('Toy '),write(Version),write(': A Constraint Functional Logic Language.'), nl,
      write('(c) 1997-2006'), nl, nl,
      nl,write('Type "/h" for help.'),nl,nl.

% rafa: para que muestre s�lo el tiempo
:- assertRunTimeStatisticsLevel(1).


% Toy command-line entry point

:- initialization continue.

continue:-initiate,halt.
