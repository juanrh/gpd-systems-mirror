
%----------------------------------------------------------------------------%
%  basicFact.pl
%----------------------------------------------------------------------------%
/*
- Author: Rafa
- Created: 27-09-2003
- Description: Predicates for checking if a basic fact (approximation statement where the parameter are
                    partial patterns) can be deduced from the Toy program loaded currently without
		    instantiating the variables.
		    The bottom is represented through the constant pValBottom, included now as part of the language.
*/


:- module(basicFact,[basicFact/ 2 ]).


:-use_module(library(terms)).

:- load_files(tools,[if(changed),imports([append/3])]).
:- load_files(toycomm,[if(changed),imports([hnf/4])]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Lhs->Rhs must be a basic fact that can contain the symbol pValBottom

basicFact(Lhs,Rhs) :-
       % 1� Replace the vars of the Lhs by constants
	term_variables_bag(Lhs,VarsLhs),
	replaceVars(VarsLhs,1),

	% 2� convert the Lhs in a suspension
	Lhs =.. [F|Args],
	name(F,FString),
	name(F2,[36|FString]),
	proveArrow('$$susp'( F2,Args,R,S),Rhs),
	!.

% proveArrow(Lhs,Rhs) succeedes if the approximation statement Lhs-->Rhs can be proved in the semantic
% calculus. We assume that Lhs has no variables and that bootm is represented by means of the constant
% pValBottom. The algorithm is as follows:
%
% 1) Lhs -> pValBottom, is provable
% 2) Lhs -> V, with V a variable, is probable if hnf(Lhs,V') succeeds with V' a variable
%                     In this case we perform the unification V' = V = constant.
%			Otherwise the algorithm will violate the 'sharing property'  and will be erroneous.
%			Example: Program rule:  f X = (X,X)
%					 provableArrow(f(X),(Y,Z)) will succeed without the unification to a constant
% 3) Lhs -> c(arg1,...,argsn) is provable if hnf(Lhs,c(X1,...,XN)) and X1->arg1, ..., XN->argN are provable

proveArrow(Lhs,Rhs) :-
	Rhs == pValBottom,
	!.

proveArrow(Lhs,Var) :-
	var(Var),
	!,
	hnf(Lhs,H,CIn,COut),
	var(H),
	H = Var,
	H = '$$Constant'.

proveArrow(Lhs,Struct) :-
	!,
	Struct =.. [Functor|Args],
	functor(Struct,Functor,NArgs),
	% NewStruct is a structure with the same functor
	% and new variables as arguments
	functor(NewStruct,Functor,NArgs),
	hnf(Lhs,NewStruct,CIn,Cout),
	NewStruct =.. [Functor|NewArgs],
	mapProveArrow(NewArgs,Args).

mapProveArrow([],[]) :- !.
mapProveArrow([X|Xs],[Y|Ys]) :-
	!,
	proveArrow(X,Y),
	mapProveArrow(Xs,Ys).


replaceVars([],_N) :- !.
replaceVars([X|Xs],N) :-
	!,
	replaceVar(X,N),
	N2 is N+1,
	replaceVars(Xs,N2).

replaceVar(V,N) :-
	!,
	name(N,NString),
	append("$$constantBasicFact",NString,ValueString),
	name(Value,ValueString),
	V = Value.

