%----------------------------------------------------------------------------%
% cooperation.pl
%----------------------------------------------------------------------------%
/*
- Autores: Sonia, Fernando y Antonio.
- Descripcion: Este m�dulo contiene las funciones necesarias para la
cooperaci�n. Debe ser cargado cuando las librerias de dominios finitos y reales 
est�n cargadas al mismo tiempo.
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(cooperation,['$#=='/5,'$#/=='/5,searchVarsR/4,searchVarsFD/4,cleanBridgeStore/2]).

:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed),imports([hnf/4])]).


:- use_module(library(clpr)).
:- use_module(library(clpfd)).


%%%%%%%%%%%%%% FD+R COMMUNICATION CONSTRAINT %%%%%%%%%%%%%%%%%%%%

$#==(L, R, Out, Cin, Cout):-
        hnf(L, HL, Cin, Cout1),
        hnf(R, HRaux, Cout1, Cout2),
        (number(HRaux) -> HR is HRaux*1.0; HR = HRaux),
        ((Out=true,  Cout3 = ['#=='(HL,HR)|Cout2],
               freeze(HL, HR is float(HL)), 
                     freeze(HR, HL is integer(HR)));
         (Out=false, Cout3 = ['#/=='(HL,HR)|Cout2],
               freeze(HL, (F is float(HL), {HR =\= F})), 
                     freeze(HR, (0.0 is float_fractional_part(HR) -> 
                                 (I is integer(HR), HL #\= I); 
                                 true))
         )
        ),cleanBridgeStore(Cout3,Cout).

$#/==(L, R, Out, Cin, Cout):-
        hnf(L, HL, Cin, Cout1),
        hnf(R, HR, Cout1, Cout2),
        (
         (Out=true, Cout3 = ['#/=='(HL,HR)|Cout2],
               freeze(HL, (F is float(HL), {HR =\= F})), 
                     freeze(HR, (0.0 is float_fractional_part(HR) -> 
                                 (I is integer(HR), HL #\= I); 
                                 true))
         )
         ;
         (Out=false,  Cout3 = ['#=='(HL,HR)|Cout2],
               freeze(HL, HR is float(HL)), 
                     freeze(HR, HL is integer(HR))
         )
        ),cleanBridgeStore(Cout3,Cout).


% Sonia :: B

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% searchVarsR, recibe por par�metro una variable o un n�mero (HL), 
%%%  - Si es un n�mero entero se devuelve su correspondiente real en HLR
%%%  - Si es una variable se busca en la lista de entrada con la informaci�n, 
%%%    -  en el caso de encontrarla se devuelve su correspondiente variable entera en HLR  
%%%    -  en el caso de no encontrarla se le asigna una nueva variable y se guarda en el almac�n de salida, 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


searchVarsR(HL,Cin,Cout,HLR):-
   searchVarsR1(HL,Cin,Cin,Cout,HLR).

searchVarsR1(HL,Caux,Cin,Cout,HLR):-
   searchVarsR2(HL,Caux,Out1,HLR1),
   ((Out1 == true, Cout = Cin,HLR=HLR1),!;
    (Out1 == false, Cout = Cin,HLR=HLR1),!;
    ( $#==(HL,HLR,true,Cin,Cout) ) 
   ).


searchVarsR2(HL,[],Out,HLR):- !.
  
searchVarsR2(HL,[#==(L,R)|Rest],Out,HLR):-
   integer(HL) ->  (Out=false, HLR is float(HL)) 
                ;
           ( HL==L -> (Out=true,HLR=R)
                ;   
                    searchVarsR2(HL,Rest,Out,HLR)
           ).

searchVarsR2(HL,[H|Rest],Out,HLR):-   %Por las rest de totalidad
    searchVarsR2(HL,Rest,Out,HLR).

% Sonia :: E


%%%%% Sonia: searchVarsFD, recibe por el par�metro X una variable o un n�mero, 
%%%%%  - Si es un n�mero real de valor entero se devuelve su correspondiente entero en XFD y true en Out
%%%%%  - Si es un n�mero real de valor NO entero se devuelve su correspondiente entero en XFD y false en Out
%%%%%  - Si es una variable se busca en el Cin, 
%%%%%    -  en el caso de encontrarla se devuelve su correspondiente variable entera en XFD y true en Out 
%%%%%    -  en el caso de no encontrarla no se asigna nada en Out 

searchVarsFD(X,[],Out,XFD).
  
searchVarsFD(X,[#==(L,R)|Rest],Out,XFD):-
   !,
   (number(X) ->   (Xaux is floor(X), X2 is X*1.0,
              ( Xaux == X2 ->  ( Out=true,XFD is integer(X)); 
                        ( Out=false, (X >= 0 -> XFD is integer(X);XFD is integer(X-1)))
              )  
            )
                ;
           ( X==R -> (Out=true,XFD=L)
                ;   
                    searchVarsFD(X,Rest,Out,XFD)
           )
    ).

searchVarsFD(X,[_|Rest],Out,XFD):-
    searchVarsFD(X,Rest,Out,XFD).



% cleanBridgeStore(+Cin,-Cout) al unificar variables es posible que estas variables esten
% puenteadas, de ser as� se deben unificar tambi�n las correspondientes variables
% que se encuentran al otro extremo de los puente 
% Por ejemplo el objetivo Y #== RY, X #==RX, X == Y nos dar�a como
% respuesta { X -> Y } { Y #== RY, Y #== RX }, con cleanBridgeStore la respuesta es
% { X -> Y, RX -> RY } 


cleanBridgeStore([],[]).
cleanBridgeStore([#==(X,RX)|R1],[#==(X,RX)|R2]):-
   !,
   removeBridge(#==(X,RX),R1,RAux),
   cleanBridgeStore(RAux,R2).
   
cleanBridgeStore([Other|Rest],[Other|Rest2]) :-
   !,
   cleanBridgeStore(Rest,Rest2).
  

% removeBridge(+T,+Lin,-Lout)
removeBridge(T,[],[]).

removeBridge(#==(X,RX),[#==(Y,RY)|B],B2) :-
   ((X==Y,RX==RY),!,removeBridge(#==(X,RX),B,B2))
  ;(X==Y,!,RX=RY,removeBridge(#==(X,RX),B,B2))
  ;(RX==RY,!,X=Y,removeBridge(#==(X,RX),B,B2)).

removeBridge(T,[A|B],[A|B2]) :-
   !,
   removeBridge(T,B,B2).


