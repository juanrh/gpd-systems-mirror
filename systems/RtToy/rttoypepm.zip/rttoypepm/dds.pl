%----------------------------------------------------------------------------%
% dds.pl
%----------------------------------------------------------------------------%
/*
- Author: Jaime
- Description: this module generates the dds tree asociated to a function.
- Modules which import it: transfun, initToy
- Imported modules: 
	> tools (with 'inhead, 'insertAtTheEnd', 'append', 'substituteArg').
	> outgenerated (with 'cdata', 'fun', 'primitive', 'ftype').

- Modified: 
	30/09/99 mercedes (the predicates have been commented)
	26/10/99 mercedes (modules).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(dds, [tree/3,paint/2,isNumber/2]).

:- load_files(tools,[if(changed),imports([inhead/3,insertAtTheEnd/3,append/3,
             substituteArg/4])]).
             
:- load_files(newout,[if(changed),imports([cdata/4,fun/4,primitive/3,
              ftype/4])]).

/* Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.
*/




/*****************************************************************************/
/*                     CALCULATION OF THE DEFINITIONAL TREE		     */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% tree(	+Fun,-Patron,-Dds) where:
% +Fun: function in the format that the sintactic analisys returns but this
% function has the variables like real variables y no salida del a. sintactico. 
% This format is generated and checked semanticaly in the module transfun.
% -Patron: tree returns the call generic patron. Patron is used only to depurate.
% -Dds: tree returns the dds tree asociated to the entrance function.
%----------------------------------------------------------------------------% 

tree(fun(Name,ArP,Rules,_),Patron,Dds):-
        functor(Patron,Name,ArP),      % we form the call patron
        positionsPatron(0,ArP,Vpos),   % we calculate the positions of the patron
        dds(Patron,Rules,Vpos,Dds).    % we form the tree
	
        
%----------------------------------------------------------------------------%
% positionsPatron(+N,+ArP,-Vpos) where:
% +N: accountant of arguments (if the arity of the funcion is A then N = since 0
% to A).
% +ArP: arity of the program
% -Vpos: list of positions corresponding to a patron which hasn't been instanced.
% If the patron has N arguments the Vpos=[[1],[2],...,[N]] and if the patron
% has 0 argumentes then Vpos=[].
%----------------------------------------------------------------------------%

positionsPatron(N,N,[]):-!.
positionsPatron(N,M,[[N1]|R]):-
	N1 is N+1,
	positionsPatron(N1,M,R).       




/****************************************************************************/
/*                  CALCULATION OF DEMANDED POSITIONS			    */
/****************************************************************************/

%----------------------------------------------------------------------------%
% demanded(+Rules,+Vpos,-List) where:
% +Rules: list of rules asociated to a function.
% +Vpos: list of positions of the variables in the patron (posible demanded 
% positions).
% -List: list of pairs rule/listPC, where listPC is a list of pairs of the form
% Position/Constructor and Constructor is of the form Name/Arity.
% A position es in particular a list of naturals.
%----------------------------------------------------------------------------%

demanded([rule(Head,Body,Constra,Where,Lin)|Rrules],Vpos,
                        [(rule(Head,Body,Constra,Where,Lin),Dem)|Rdemanded]):-
        demand(Head,Vpos,Dem),
        !,
        demanded(Rrules,Vpos,Rdemanded).

demanded([],_,[]).


%----------------------------------------------------------------------------%
% demand(+Head,+Vpos,-Dem): this predicates returns Dem: list of pairs of the
% form (position,name_constructor/arity) which demand the head rule Head.
%----------------------------------------------------------------------------%

demand(Head,[Pos|Rpos],[(Pos,C)|Dem]):-
        consInPos(Head,Pos,C),          % we look if there is a constructor C
        !,                              % in that position.
        demand(Head,Rpos,Dem).

demand(Head,[_|Rpos],Dem):-
        demand(Head,Rpos,Dem).

demand(_,[],[]).


%----------------------------------------------------------------------------%
% consInPos(+Head,+Pos,-C) where:
% +Head: head rule where we look if there is a constructor in the position Pos.
% +Pos: position in the head rule where we want to know if there is a
%       constructor.
% -C: Name/Arity of the constructor.
% This predicate looks if there is a constructor in the position Pos and 
% it returns the name and the arity of that constructor in C. 
% We have to remember that a function parcialy applyed and a number are  
% constructors too.
%----------------------------------------------------------------------------%

consInPos(Head,[P],Name/Arity):-
	!,
        arg(P,Head,Arg),
	\+ var(Arg),
	(	
		isNumber(Arg,Name/Arity),!
	;
		functor(Arg,Name,Arity),
		(
			cdata(Name,_,_,_),!
		;
			fun(Name,ArP,_,_),!,Arity<ArP
		;
			primitive(Name,_,_),!,ftype(Name,ArP,_,_),Arity<ArP
		)
	).
		
consInPos(Head,[P|R],Name):-arg(P,Head,Arg),consInPos(Arg,R,Name).


% isNumber(+N,-Name/Arity): comprueba si N es un numero y devuelve en Name
% ese numero y en Arity 0.
isNumber(N,N/0):-number(N).


/************************************************************************/
% DDS
/************************************************************************/
        

% Algoritmo propio dds. Predicado ppal.
/* dds(+Patron,+Rules,+Vpos,-Dds) donde:
+Patron: patron generido de llamada a la funcion de la que vamos a calcular el
         arbol dds.
+Rules: lista de reglas asociadas a la funcion.
+Vpos: lista de posiciones de las variables en el patron
-Dds: arbol dds asociado a la funcion.
*/

dds(Patron,Rules,Vpos,Dds):-
        demanded(Rules,Vpos,Dem),    % calculamos las pos demandadas en Dem
        (                               % una alternativa dependiendo
% Yoli YGR 25/01/2006 inicio
    %   (notPosDem(Dem),!,doTry(Patron,Rules,Dds));   % lo quito
        (notPosDem(Dem),!,doTryMod(Patron,Rules,Dds)); %lo pongo
% Yoli YGR 25/01/2006 fin

        (uniformDem(Dem,Vpos,Pos),!,doCase(Patron,Dem,Pos,Dds));
        (doOr(Patron,Dem,Dds))
        ).


/* 
en Dem tenemos una lista de la forma:
 [(
        rule(Head,Body,Rest,_,Line),
        [(Position,Constructor/Arity)....]
  ),....
 ]
*/




% notPosDem(+Dem) donde Dem tiene las posiciones demandadas de cada regla.
% Recorre la lista Dem de pares Rules,PosDem y tiene exito si PosDem=[], para
% todas las reglas.
notPosDem([]).
notPosDem([(_,[])|Xs]):-notPosDem(Xs).


/* uniformDem(+Dem,+Vpos,-UDPos) donde:
+Dem: posiciones demandadas de cada regla
+Vpos: posiciones de las variables en el patron
-UDPos: devuelve en Pos la primera posicion unif demandada en caso de existir y
      falla en otro caso.
*/
% Hacemos un recorrido por todas las pos de Vpos hasta encontrar una que
% este demandada por todas las reglas y fallamos si no la encotramos.

% uniformDem(_,[],_):-!,fail.
        
uniformDem(Dem,[P|_],P):-
        belongToAll(P,Dem),!.

uniformDem(Dem,[_|Rest],UDPos):-
        uniformDem(Dem,Rest,UDPos).


/* belongToAll(+P,+Dem) donde:
+P es una lista de enteros que representa una posicion
+Dem es una lista de pares regla/listaPC, donde listaPc es a su vez una 
lista de pares posicion/constructora.
belongToAll tiene exito si P esta demandada en todas las reglas, i.e., si
P esta en listaPC en todas las reglas.
*/ 
belongToAll(_,[]).
belongToAll(Pos,[(_,ListPc)|Dem]):-
        belong(Pos,ListPc),
        belongToAll(Pos,Dem).

% belong(+Pos,+ListPC): tiene exito si el par (Pos,_) pertenece a ListPC.
belong(Pos,[(P,_)|R]):-
        (P==Pos,!);
        (belong(Pos,R)).

        




/***************************************************************************
	 CONSTRUCCION DEL CASE
***************************************************************************/

/* doCase(+Patron,+Dem,+Pos,-Dds): se construye el arbol Dds desarrollando
un Case.
*/
% Tenemos una pos uniformemente demandada Pos y desarrollamos el case.
% Primero asociamos las reglas con la constructora que demandan.
% QQ es una lista de la forma 
% [(Constructora/Arity,[Reglas que la demandan en Pos]),...]

doCase(Patron,Dem,Pos,Dds):-
        asocConsRules(Dem,Pos,[],QQ),      
        builtCase(Patron,Pos,QQ,Dds).    



% asocConsRules(+lista pares regla/listaPc,+Posicion,+In,-Out), 
% listaPc esta formada por pares Posicion/constructora 
% Busca el nodo correspondiente a la posicion Pos en cada regla, y lo inserta 
% en la lista In de modo que al final en out tengamos una lista de pares 
% constructora/lista de reglas que tienen esa constructora en la pos Pos.

asocConsRules([],_,L,L).
asocConsRules([(Rule,ListPc)|Rdem],UDPos,Asoc,Rasoc):-
        searchConsDem(ListPc,UDPos,Cons),       % buscamos la cons=Name/Ar asoc
        insertRule(Rule,Cons,Asoc,Asoc1),    % la insertamos al final por
                                                % mantener el orden en la trad
        asocConsRules(Rdem,UDPos,Asoc1,Rasoc).


/* searchConsDem(+ListPC,+UDPos,-Cons): busca la constructora (Name/Arity)
asociada a la posicion uniformemente demandada.
*/
searchConsDem([(Pos,Cons)|_],UDPos,Cons):-Pos==UDPos,!.
searchConsDem([_|Rest],UDPos,Cons):-searchConsDem(Rest,UDPos,Cons).   



% insertRule(+Rule,+Cons,+Asoc,-Asoc1)
% busca en la lista de reglas la constructora Cons. Si la encuentra, a�ade la
% nueva regla a Asoc (lista asociada a Cons), y si no, crea un nuevo par al 
% final.
insertRule(Rule,Cons,[],[(Cons,[Rule])]).  % nuevo par al final
insertRule(Rule,Cons,[(Cons,[L1|R1])|R],[(Cons,[L1|R11])|R]):-
        !,
        insertAtTheEnd(Rule,R1,R11). % mantenemos el orden de las reglas
                                    % por conservar el orden en la traduccion  

insertRule(Rule,Cons,[L|R],[L|R1]):-
        insertRule(Rule,Cons,R,R1).




/* builtCase(+Patron,+Pos,+Associations,-Dds) donde Associations es una
lista de la forma [(Constructora/Arity,[Reglas que la demandan en Pos]),...].
Construye la estructura case(Pos,Patron,ListaCasos), donde lista de casos
esta formada por pares Constructora/lista de reglas.
*/

builtCase(Patron,Pos,Associations,case(Pos,Patron,ListCases)):-
        doListCases(Patron,Pos,Associations,ListCases).

% doListCases(+Patron,+Pos,+Associations,-ListCases)
% devuelve la lista de ddt asociados a un case en forma de pares
% (constructora, ddt asociado).
doListCases(_,_,[],[]).
doListCases(Patron,Pos,[(C/Ar,Rules)|RestAsoc],[(C,Case)|RestCases]):-
        newPatron(Patron,Pos,C/Ar,NP),
% las posiciones son deducibles. Esto es bastante mejorable
        posVarsPatron(NP,Vpos),
        dds(NP,Rules,Vpos,Case),
        doListCases(Patron,Pos,RestAsoc,RestCases).


% newPatron(+Patron,+Pos,+Cons,-NP)
% genera un nuevo Patron (NP) a partir de uno dado (Patron), cambiando la 
% variable de la posicion Pos por la constructora Cons.
newPatron(Patron,[],C/Ar,NArg):-
        var(Patron),
	functor(NArg,C,Ar).

newPatron(Patron,[Pos|R],Cons,NP):-
        arg(Pos,Patron,Arg),
        newPatron(Arg,R,Cons,Narg),
        changeArg(Patron,Pos,Narg,NP).

% changeArg(+Patron,+Pos,+Narg,-NP): cambia el argumento  del Patron que ocupa 
% la posicion Pos por el nuevo argumento Narg, y devuelve en NP el nuevo patron
% que se obtiene.
% CambiaArg es como el argrep de Arity
changeArg(Patron,Pos,Narg,NP):-
	Patron=..[Name|Args],
	substituteArg(Pos,Args,Narg,Nargs),
	NP=..[Name|Nargs].



% posVarPatron(+Patron,-List)
% devuelve la lista de posiciones de las variables de Patron. Una posicion
% es una lista de naturales. Devuelve [[]] si Patron es variable y [] si
% el patron no tiene variables 
posVarsPatron(P,[[]]):-var(P),!.
posVarsPatron(P,Vpos):-
	P=..[_|Args],
	(Args==[],!,Vpos=[];
	listPosVarsPatron(Args,1,Vpos)).

% listPosVarsPatron(+Args,+N,-Vpos): devuelve en Vpos la lista de listas de
% variables que hay en cada argumento de la lista de argumentos Args. 
% Cada una de estas sublistas de variables lleva en cabeza el numero del 
% argumento al que pertenecen esas variables. Para hacer esto se usa el 
% contador N, que va contando por que argumento voy mirando sus variables.
listPosVarsPatron([],_,[]).
listPosVarsPatron([Ar|R],Nar,VposT):-
	posVarsPatron(Ar,Vpos),
	inhead(Nar,Vpos,VposAr),
	N1 is Nar+1,
	listPosVarsPatron(R,N1,R1),
	append(VposAr,R1,VposT).




/***************************************************************************
	 CONSTRUCCION DEL OR
***************************************************************************/

% construye un termino de la forma or(lista opciones).
% le pasamos el patron y la lista de pares rule/pos demandadas por ella

doOr(Patron,Dem,or(LAlts)):-

        % hacemos una particion del cto de reglas por la posicion que demandan
	% primero extraemos todas las que o no demandan ninguna posicion o su
	% cabeza no casa con el patron. Todas ellas las metemos en Reduce.
	% En Dem1 queda el resto de reglas

	extractReduce(Patron,Dem,Dem1,Reduce),

	% Con el resto de Ruleshacemos una particion por las posiciones que
	% demandan. En Partition tenemos una lista de pares (Pos,reglas que la
	% demandan). Realmente aparecen las reglas cuya primera posicion 
	% demandada es Pos; esto es equivalente por el orden que tenemos a 
	% tomar primero todas las que demandan la primera, luego todas las que
	% demandan la segunda...(siempre dentro de las posibles demandadas) y 
	% es mas eficiente.	

        doPartition(Patron,Dem1,Partition),

	% y ahora... generamos los arboles correspondientes a cada alternativa
	% y a Reduce.
	
        doListAlternatives(Patron,Partition,Reduce,LAlts).
        

% extractReduce(+Patron,+In,-Out1,-Out2). En In le pasamos todas las reglas con las
% posiciones que demandan. En out2 devuelve las que no demandan nada o las que
% tienen una cabeza que no casa con el patron. En Out1 devolvemos las restantes
extractReduce(_,[],[],[]).
extractReduce(Patron,[(Rule,LstPosDem)|R],[(Rule,LstPosDem)|R1],Reduce):-
	fit(Rule,Patron),
	LstPosDem\==[],
	!,
	extractReduce(Patron,R,R1,Reduce).
extractReduce(Patron,[(Rule,_)|R],R1,[Rule|Reduce]):-
	extractReduce(Patron,R,R1,Reduce).


% fit(+Rule,+Patron): tiene exito si la cabeza de la regla casa con el patron.
fit(rule(Head,_,_,_,_),Patron):- \+ (\+ Head=Patron).

/*
% comprueba que son unificables pero no les unifica.
fit(rule(Head,_,_,_,_),Patron):- \+ nofit(Head,Patron).

%&& guarreria con corte.
nofit(T1,T2):-T1=T2,!,fail.
nofit(_,_).
*/



% doPartition(+Patron,+In,-Out). Le pasamos en In1 todas las reglas que 
% demandan alguna posicion y cuya cabeza casa con el patron.En Out devolvemos
% la lista de pares Posicion/reglas que la demandan en primer lugar.
doPartition(_,[],[]).
doPartition(Patron,[(Rule,[(Pos,Cons)|Rpos])|R],
		[(Pos,[(Rule,[(Pos,Cons)|Rpos])|RDem])|Part]):-
	extractRulesPos(Pos,R,Rest,RDem),
	doPartition(Patron,Rest,Part).


% extractRulesPos(+Pos,+Demand,-Rest,-Out). Recorre la lista de Demanda y 
% devuelve en Out las que demandan Pos como primera poscion. Deja en Rest las 
% restantes.
extractRulesPos(_,[],[],[]).
extractRulesPos(Pos,[(Rule,[(Pos,Cons)|Rpos])|R],R1,
		[(Rule,[(Pos,Cons)|Rpos])|RDemPos]):-
	!,
	extractRulesPos(Pos,R,R1,RDemPos).
extractRulesPos(Pos,[Par|R],[Par|R1],DemPos):-
	extractRulesPos(Pos,R,R1,DemPos).





% doListAlternatives(+Patron,+Partition,+Reduce,-Laltns)
% hace los casos que tiene en Partition y luego hace el try que tiene en Reduce 
% -Laltns: lista de arboles dds de cada caso que hay en Partition.
doListAlternatives(_,[],[],[]).

doListAlternatives(Patron,[],Reduce,[Dds]):-
% Yoli YGR 25/01/2006 inicio
%	doTry(Patron,Reduce,Dds).        %Lo quito Yoli
	doTryMod(Patron,Reduce,Dds).     %Lo pongo Yoli
% Yoli YGR 25/01/2006 fin

doListAlternatives(Patron,[(Pos,Rules)|R],Reduce,[DdsP|DdsR]):-
	doCase(Patron,Rules,Pos,DdsP),
	doListAlternatives(Patron,R,Reduce,DdsR).

   




/************************************************************************/
% CONSTRUCCION DEL TRY
/************************************************************************/

% doTry(+Patron,+Rules,-Dds): construye un termino de la forma 
% try(Patron,Lista) donde Lista lleva cosas de la forma si(Restricciones,Cuerpo)
% de las reglas con las que el try tiene que probar. (Ver below).
% Yoli YGR 09/01/2006 inicio
/*
  doTry(+Patron,+Rules,-Dds): construye un termino de la forma 
  or(try1, try2, ..., TryN)
  con tryi(Patron,Lista)) donde Lista lleva cosas de la forma si(Restricciones,Cuerpo)
  de las reglas con las que el try tiene que probar. (Ver below).
*/

doTryMod(Patron,[Rule|RestRules],DDs):-
  ( RestRules = [],
    !,
      doTry(Patron,[Rule|RestRules],DDs)
    ;
      doOrTrys(Patron,[Rule|RestRules],DDs)
  ).

 doOrTrys(Patron,Rules,or(ListaTrys)):-
    hazListaT(Patron, Rules, ListaTrys).

 hazListaT(Patron,[],[]).
 hazListaT(Patron, [rule(Head,Body,Rest,Where,_)|Rr], [try(Patron,[si(Rest,Body,Where)])|Rtrys]):-
     Head = Patron,
     hazListaT(Patron, Rr,Rtrys).

% YGR 09/01/2006 fin 



doTry(Patron,Rules,try(Patron,L)):-
        hazListaTry(Patron,Rules,L).


% hazListaTry(+Patron,+Rules,-Lista)
hazListaTry(_,[],[]).
hazListaTry(Patron,[rule(Head,Body,Rest,Where,_)|Rr],
		    % Depu 04/10/00 mercedes
		    % se mete el Where dentro de si(...)
                   [si(Rest,Body,Where)|Rrsi]):-
		    % Fin Depu
        Head=Patron,
        hazListaTry(Patron,Rr,Rrsi).    
        
        






        




/************************************************************************/
% PREDICADOS PARA DEPURACION
/************************************************************************/

%% DIBUJITO DEL ARBOL

% Saca en pantalla una representacion "legible" (eso creo) del arbol.
% Hay que pasarle una llamada generica o patron inicial de la funcion y
% el propio arbol.
paint(Patron,Dds):-
    nl,write('Patron: '),write(Pattern),nl,nl,wrt(Dds,0).        

wrt(case(Pos,P,L),N):-!,
        tab(N),write('** case '),write(Pos),write(' Pattern '),
        write(P),nl,N1 is N+5,wrtListCase(L,N1).

wrt(or(L),N):-!,
        tab(N),write('** or '),nl,N1 is N+2,wrtListOr(L,N1).


wrt(try(Patron,L),N):-tab(N),write('Pattern: '),write(Patron),
                        nl,N1 is N+2,wrtListTry(L,N1),nl.

wrtListCase([],_):-!.
wrtListCase([(C,L)|R],N):-!,
        tab(N),write(C),write(': '),nl,N1 is N+3,esc(L,N1),wrtListCase(R,N).


wrtListOr([],_):-!.
wrtListOr([L|R],N):-
        tab(N),esc(L,N),wrtListOr(R,N).

% Depu 04/10/00 mercedes
wrtListTry([],_):-!.
wrtListTry([si(Con,Body,Where)|R],N):-!,
        tab(N),write(Body),write(' <= '),write(Con),nl,
               prettyWhere(Where,N), nl, wrtListTry(R,N).
        
% Fin Depu

%  Depu 04/10/00 prettymercedes
prettyWhere([],N) :- 
	!.
prettyWhere([C|R],N) :-
	!,
	tab(N),
        write('where'),
        nl,
	prettyWheres([C|R],N).
            
prettyWheres([],_N) :- 
	!. 
prettyWheres(['='(Pat,Expr,Lin)|R],N) :-
	!,
	tab(N), write('   '),
	write(Pat),
	write(' = '),
	write(Expr),
        nl,
	prettyWheres(R,N).
	
	
% Fin Depu
