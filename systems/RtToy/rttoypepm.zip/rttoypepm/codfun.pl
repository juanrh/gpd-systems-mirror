%----------------------------------------------------------------------------%
% codfun.pl
%----------------------------------------------------------------------------%
/* 
- Author: Jaime
- Description: This module generates the code of a function using the definitional
  tree.
- Modules that import it: transfun, initToy.
- Imported modules: 
    > tools (with 'insertLst', 'append' and 'insertAtTheEnd')
    > plgenerated (with 'constr' and 'funct')
    > outgenerated (with 'cdata', 'fun', 'primitive' and 'ftype').

- Modified:
    30/09/99 mercedes (the predicates have been commented)
    26/10/99 mercedes (modules)
    22/11/99 mercedes (Optimization of equality solving. 
              If a defining rule has the form 
              f(Args1) = g(Args2) <== <Conds>, Y==T (or T==Y)
              where Y is variable not occurring in Args1 nor in
              <Conds> then the following mechanism for solving
              Y==T is better than the usual one: 
              compute a normal form for T and bind Y with it.
              To this purpose the new predicate 'equalnf' has
              been defined. It is introduced (when possible) in
              the code generation for 'try' branches (more precisely,
              it is done by 'optimizeEq' in the clause for
              'generateCodeAlt').
    04-12-07 pacol: added a patch for fixing the generation of suspensions
              corresponding to the primitive function 'collect'.
              The new implementation of collect includes also
              a new code for 'collect' in primitivCodcopia.pl
    19-09-08 pacol: added a patch for achieving run-time choice support
             nested applications of rt and collect are not supported
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(codfun,[generateFinalCode/3,doConstra/5,introduceSusp/3, 
      optimizeEq/3,doWhere/3,extract_left_hand_side_Where/3,
      %% ppaco 19-09-2008
      parcheaCollect/2, parcheaMetaCollect/2, parcheaRuntime/2]).

%FSP 06-2006 To avoid NAME CLASH
% member cannot be removed because it behaves different from the one in the SICStus library lists
%:- load_files(tools,[if(changed),imports([insertLst/3,insertAtTheEnd/3,append/3,member/2])]).
:- load_files(tools,[if(changed),imports([insertLst/3,insertAtTheEnd/3,member/2,depura/1])]).

% 16/05/00 mercedes. Para cuando usamos la libreria de e/s de ficheros.
/*
:- load_files(dyn,[if(changed)]).
:- (
    io_active,!,load_files(basicIo,[if(changed)])
   ;
    (iographic_active;ioclpr_active),!,load_files(basicGra,[if(changed)])  % 29/05/00 e/s grafica
   ;
    load_files(basic,[if(changed)])
   ).
*/
:- load_files(basic,[if(changed),imports([constr/4,funct/5])]).

/* Este modulo llama al modulo plgenerated en el predicado isConstructor cuando
estamos en tiempo de ejecucion, es decir, cuando estamos con objetivos.
Lo que se hace es cargar inicialmente el fichero basic.pl que contiene el modulo
plgenerated inicial, pero cuando se genere un fichero.pl y se cargue (en el modulo
process), como lo generamos como modulo plgenerated, se borra el modulo 
plgenerated antiguo y se carga este nuevo.
*/


:- load_files(newout,[if(changed),imports([cdata/4,fun/4,primitive/3,
          ftype/4])]).

/* Este modulo llama al modulo outgenerated en el predicado isConstructor cuando
estamos en tiempo de compilacion.
Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.

*/

:- load_files(primFunct,[if(changed),imports([primitiveFunct/5])]).

:- use_module(library(terms)).
% Yoli YGR 26/01/2006 inicio
:- use_module(library(lists)).    


%:- load_files(toycomm,[if(changed),imports([equalnf/4])]).

/************************************************************************
LLAMADA AL MODULO:
    generateFinalCode(
        +Tree   % arbol generado con el modulo dds.pl
        +NameFun    % nombre de la funcion asociada al arbol
        -CodF   % Codigo asociado a la funcion en forma de lista
              de pares (Cabeza,cuerpo), donde cuerpo es una lista
              de atomos

    
*************************************************************************/  



/************************************************************************/
% GENERACION DE CODIGO.
/************************************************************************
Este modulo funciona con el arbol definitorio como entrada. Genera el codigo
asociado a la funcion que describe el arbol dds y funciona analizando la
estructura del arbol en profundidad, por lo que la salida que produce
esta solo parcialmente ordenada, en un principio, e.d., todo predicado (func)
que es llamado por otro aparece despues de este, pero dos predicados del mismo
nombre no tienen pq aparecer contiguos. Esto puede provocar problemas en algunos
prolog por lo que al final les ordenaremos. No obstante, aprovecharemos la 
propiedad antes citada para hacer el orden completo. 


Para "subir las constructoras" y generar un codigo mas eficiente muchos de 
los predicados llevan como ultimo argumento la "cascara". Una cascara 
asociada a un nodo puede tomar tres tipos de valor:
    - un termino formado con una constructora. Significa que todos los
nodos por debajo tienen una cascara comun que es la actual
    - on: hasta ahora no hay restricciones sobre la cascara, por lo que
al formar una nueva cascara con otra dada, automaticamente tomara el valor 
de la dada.
    - off: no hay cascara comun para los nodos que estan por debajo y por lo
tanto no es posible hacer esta optimizacion.
    
    Tambien se hace un unfolding de los predicados, e.d., si un predicado p 
llama a otro q y q solo tine una clausula, q desaparece y la llamada en p se 
sutituye por el cuerpo de q.

14-3-93
Ademas se realizan otras dos optimizaciones:
    - ** QUITADA (20-6-97) ** Indexacion por el argumento del que acabamos
    de hallar una forma normal de cabeza. P.e.
     f(X,Y,H):-hnf(Y,HY),f_2(HY,X,H).
    el orden de los argumentos se altera en la llamada a f_2 con el fin de 
    aprovechar la indexacion de Sicstus (por el functor del primer argumento).
    - Se quitan las constructoras inutiles. P.e:
        f(suc(X),Y,H):-hnf(Y,HY),f_2(HY,X,H).
    la constructora suc no se propaga a f_2, porque ya no aporta informacion
    en f_2 y nos ahorramos el trabajo de la unificacion.



20-6-96
Cuando una variable se unificaba al unificar la llamada a un predicado con la 
cabeza de este, no se comprobaba que dicha unificacion era posible de acuerdo 
con el almacen de restricciones. P.e.:

    f(X,H,Cin,Cout):-hnf(X,HX,Cin,Cout1),f_1(HX,H,Cout1,Cout).
    f_1(a,H,Cin,Cout):- ....

La forma normal de cabeza de X puede ser una variable y se unifica con la 
constructora a sin comprobar que esto es posible. Para corregirlo se genera el 
codigo:
    f(X,H,Cin,Cout):-hnf(X,HX,Cin,Cout1),f_1(HX,H,Cout1,Cout).
    f_1(X,H,Cin,Cout):-unifyHnfs(X,a,Cin,Cout1),....

El codigo de unifyHnfs esta en toycomm.pl


Con esto desaparece la indexacion. 

Otra cosilla: muchos predicados (los que contienen ramas or como el or paralelo)
pueden generar codigo de la forma:

    or....
    or(A,B,H,Cin,Cout):-hnf(B,HB,Cin,Cout1),unifyHnfs(HB,true,Cout1,Cout).
    ...

Esto ocurre al hacer unfolding y este codigo es reemplazable (y se reemplaza)
por:
    or....
    or(A,B,H,Cin,Cout):-hnf(B,true,Cin,Cout).

Esto se detecta al hacer los unfolding en las ramas case

************************************************************************/

% Devuelve el codigo asociado a la funcion NameFun con arbol Tree en CodFun
% generateFinalCode(+Tree,+NameFun,-CodF)
generateFinalCode(Tree,NameFun,CodF):-
        generateCode(Tree,NameFun,[],Cod,_),   
        putInOrderCode(Cod,CodF1),
        %%ppaco 19-09-2008
        parcheaRuntime(CodF1,CodF2),  % al final
        %%ppaco 19-09-2008
        %%ppaco 4-12-07
        parcheaCollect(CodF2,CodF),  % al final
        %%ppaco 4-12-07
        parcheaMetaCollect(CodF2,CodF)  % al final
        %%ppaco 7-10-08
        .




/* generateCode(+Tree,+NameFun,+LastPosDem,-Cod,?Sh) donde:
+Tree: es un arbol generado por dds.
+NameFun: es el nombre de la funcion para la que estamos generando codigo
+LastPosDem: es la ultima posicion que ha sido demandada. Inicialmente es
            [] y (*** YA NO SIRVE PARA ESTO 20-6-96 ***) sirve para hacer la 
            optimizacion de indexar por el argumento del que acabamos de hallar 
            una hnf.
-Cod: es la lista de clausulas generadas.
?Sh: es la cascara explicada arriba para optimizar */





/******************************************************************************/
%   RAMAS OR
/******************************************************************************/


% En el caso del or simplemente generamos codigo para cada una de las opciones
% La primera clausula nunca unificara inicialmente con un arbol pero puede 
% hacerlo en sucesivas llamadas recursivas.

generateCode(or([]),_,_,[],on):-!.
generateCode(or([Tree|R]),NameFun,LastPosDem,Cod,Sh):-
        !,
        generateCode(Tree,NameFun,LastPosDem,Cod1,Sh1),
        generateCode(or(R),NameFun,LastPosDem,Cod2,Sh2),
        doSh(Sh1,Sh2,Sh),
        append(Cod1,Cod2,Cod).


% Yoli YGR 10/01/2006 INICIO --------------------------------------------------------
/******************************************************************************/
%   RAMAS 

/******************************************************************************/

generateCode(orCut([]),_,_,[],on):-!.
generateCode(orCut([Tree|R]),NameFun,LastPosDem,Cod,Sh):-
        !,
        doNameFunCorte(NameFun,NameFunCorte),
        generateCode(Tree,NameFunCorte,LastPosDem,Cod1,Sh1),
        generateCode(orCut(R),NameFun,LastPosDem,Cod2,Sh2),
        doSh(Sh1,Sh2,Sh),
     (  R=[],
           !,
           generateCodeDos(Tree,NameFun,NameFunCorte,LastPosDem,Cod4,_),  
           append(Cod4,Cod1,Cod3),
           append(Cod3,Cod2,Cod)
           ;
           append(Cod1,Cod2,Cod)
        )
        .

 generateCodeDos(try(Patron,[siCut(Constr, Val,Where)]),NameFun,NameFunCorte,LastPosDem,
                [(Head,Body)],Sh):-  
          !,
          Patron=..[_|Args], 
          builtHead(NameFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,Head),
          builtCallCorte(NameFunCorte,Args,H,LastPosDem,Cons,Var,Cin,Cout,Call,LArgs),
        Body = [varList(LArgs,Milista),Call,grupo(checkVarList(Milista),true)],
  (var(Val),
   !,
      true = true  %%ppaco  Como??????????
   ;

      Val=..[Name|As],
      (
         (Name=do; Name=intensional),
       !,
          (
          isConstructor(Val,compilation),
          !,
             H=..[Name|As],
             Cout=Cout1
          ;
          true = true   %%ppaco  Como??????????
          )

       ;
        introduceSuspList(As,ValSusp,compilation),
        (
           isConstructor(Val,compilation),
         !,
           H=..[Name|ValSusp],
           Cout=Cout1
           ;
           true = true   %%ppaco  Como??????????
        )
      )
   )
.


%%ppaco  en que difiere esta clausula de la anterior???
generateCodeDos(try(Patron,[si(Constr, Val,Where)]),NameFun,NameFunCorte,LastPosDem,
                [(Head,Body)],Sh):-  
          !,
          Patron=..[_|Args], 
          builtHead(NameFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,Head),
          builtCallCorte(NameFunCorte,Args,H,LastPosDem,Cons,Var,Cin,Cout,Call,LArgs),
        Body = [varList(LArgs,Milista),Call,grupo(checkVarList(Milista),true)],
  (var(Val),
   !,
      true = true   
   ;

      Val=..[Name|As],
      (
         (Name=do; Name=intensional),
       !,
          (
          isConstructor(Val,compilation),
          !,
             H=..[Name|As],
             Cout=Cout1
          ;
          true = true
          )

       ;
        introduceSuspList(As,ValSusp,compilation),
        (
           isConstructor(Val,compilation),
         !,
           H=..[Name|ValSusp],
           Cout=Cout1
           ;
           true = true
        )
      )
   )
.


 generateCodeDos(case(Pos,Patron,ListCases),NameFun,NameFunCorte,LastPosDem,
                [(Head,Body)],Sh):-  
              
                
        !,                      % por si las moscas
        Patron=..[_Name|Args],            % destripamos el patron para sacar los
                                % argumentos
                                            %construimos la cabeza de la clausula.
      builtHead(NameFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,Head),
        %la llamada es igual que la funci�n builthead.
        builtCallCorte(NameFunCorte,Args,H,LastPosDem,Cons,Var,Cin,Cout,Call,LArgs),

        Body = [varList(LArgs,Milista),Call,grupo(checkVarList(Milista),true)]
        .


% YGR 10/01/2006 FIN -----------------------------------------------------------



/******************************************************************************/
%   RAMAS CASE
/******************************************************************************/



/*
generateCode(case(...),NameFun,LastPosDem,CodeOut,ShOut)
Aqui generamos codigo para un arbol (o subarbol) de la forma case(...). En 
Namefun llevamos el nombre del predicado que vamos a generar. Los sucesivos 
predicados tendran el nombre NameFun_Pos_Cons, donde Pos es la posicion demandada
que aparece en el case y Cons es la constructora inutil que hemos quitado (si es
que se ha hecho). En OutCodigo devolvemos el codigo generado. En este predicado 
se genera directamente solo una clausula, las demas se generan como resultado de
la llamada a generateCodeCases. Esta clausula en ppio. tiene la forma:
Head:-hnf(...),LLam. E.d. hacemos la fnc de la pos demandada y llamamos al 
predicado de Cabeza NameFun_Pos (Call).
    Despues estudiamos la posibilidad de hacer un unfolding, que sera 
factible cuando tengamos un case con un solo caso y ademas este caso sea:
    - otro case, o
    - un try con una sola alternativa.
En esta situacion en lugar de la llamada Call colocamos el cuerpo de la unica 
clausula cuya cabeza encaja con Call. Ademas unificamos Call=HeadCase, 
simplemente para unificar las variables que aparecen en ambos y hacer coherente 
el unfolding.

    Si podemos hacer el unfolding tenemos en cuenta que el cuerpo de la 
clausula puede comenzar por un unifyHnfs, en cuyo caso nos cargamos este 
unifyHnfs (ya hace el trabajo hnf) y hacemos coherentes los almacenes y resto de
variables.
    Si no tenemos la suerte de poder hacer el unfolding, respetamos las 
clausulas generadas en generateCodeCases y las dejamos tal cual.
*/


generateCode(case(Pos,Patron,ListCases),NameFun,LastPosDem,
                [(Head,Body)|RestCod],Sh):-  
                
        !,  % por si las moscas
        Patron=..[_Name|Args],             % destripamos el patron para sacar los
                      % argumentos



    %construimos la cabeza de la clausula.
    builtHead(NameFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,Head),

    % el nombre del predicado de la llamada
    doNameFun(NameFun,Pos,Cons,NameFunCall),

    % la llamada en si
    builtCall(NameFunCall,Args,H,Pos,VarPos,HnfPos,Cout2,Cout,Call),

    % vemos si tenemos que hacer alguna unificacion de variable con 
    % constructora, en cuyo caso metemos un unifyHnfs. Luego se hace la 
    % forma normal de cabeza del argumento demandado y luego... el      
    % RestoCuerpo
    (
        var(Var),
        !,
        Body=[unifyHnfs(Var,Cons,Cin,Cout1),
            hnf(VarPos,HnfPos,Cout1,Cout2)|RestBody]
    ;
        Body=[hnf(VarPos,HnfPos,Cin,Cout2)|RestBody]
    ),  

    % generamos el codigo para los subarboles del case
        generateCodeCases(ListCases,NameFunCall,Pos,[(HeadCase,BodyCase)|Rcod],Sh),
    (
            % aqui vemos si es posible hacer el unfolding
        (ListCases=[(_,case(_,_,_))];ListCases=[(_,try(_,[_]))]),
        !,
        (
            % Si al hacer el unfolding nos va a quedar unifyHnfs 
            % y luego un hnf, dejamos solo el hnf, que ya hace todo
            % el trabajo
            BodyCase=[unifyHnfs(_,L,_,CoutUnif)|RestBodyCase],
            !,

            % unificacion de variables para hacer coherente la 
            % eliminacion de unifyHnfs
            HnfPos=L,
            Cout2=CoutUnif,
            RestBody=RestBodyCase
        ;   
            RestBody=BodyCase   % en vez de la llamada ponemos
                        % el cuerpo de la clausula a la 
                        % que llama
        ),
            
        RestCod=Rcod,
        Call=HeadCase       % para unificar variables
    ;
        % no es posible el unfolding: somos respetuosos
        RestBody=[Call],
        RestCod=[(HeadCase,BodyCase)|Rcod]
    ),

    
    % si por debajo de este nodo tenemos una cascara comun, la ponemos en 
    % vez de H, si no, nos aguantamos sin subir la constructora

        ((Sh\==off,
          H=Sh)
        ;
          true
        ). 
 

%%%%builtHead(+NameFun,+Args,-H,+LastPosDem,-Cons,+Var,-Cin,-Cout,-Head)%%%
/* builtHead: la cabeza de una clausula tiene como nombre el nombre que 
llevamos construido hasta ahora (con el inicial, las posiciones que se han ido
demandando y las constructoras que se han ido quitando). Reemplazamos la 
constructora Cons que se demanda en el patron por una nueva variable Var, que
luego en el cuerpo de la clausula se unificaran mediante un unifyHnfs. 
substituteArgList extrae el termino (una constructora) que ocupa una 
poscion dada y genera una nueva lista de argumetos en la que se ha sustituido 
dicho termino por una nueva variable Var. Ademas en la cabeza aparece como 
ultimo argumento H, que es el resultado de la evaluacion de la funcion. 
builtHead devuelve ademas Cons que es el functor del termino por el que
se indexa y que servira para concatenar su functor  al predicado de llamada y
llevar cuenta asi de las constructoras que se han ido quitando y no haya 
ambiguedades en el nombre de los predicados */


% esta primera clausula solo se usa cuando el arbol correspondiente a una 
% funcion comienza por case y solo se usa una vez

builtHead(NameFun,Args,H,[],[],[],Cin,Cout,Head):-
    append(Args,[H,Cin,Cout],Aux),
    Head=..[NameFun|Aux].

builtHead(NameFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,Head):-
    substituteArgList(Args,LastPosDem,Var,Cons,Args1),
    variablesTerm(Args1,[]/LstVars),
    append(LstVars,[H,Cin,Cout],Aux),
    Head=..[NameFun|Aux].

/* builtCall es parecido a builtHead, salvo que ahora la posicion 
que interesa es aquella de la se acaba de hallar una hnf. */
builtCall(NameFunCall,Args,H,Pos,VarPos,HnfPos,Cin,Cout,Call):-
    substituteArgList(Args,Pos,HnfPos,VarPos,Args1),
    variablesTerm(Args1,[]/LstVars),
    append(LstVars,[H,Cin,Cout],Aux),
    Call=..[NameFunCall|Aux].


%-----------------------------------------------------------------------------%
% generateCodeCases(+Listacasos,+NameFun,+Pos,-Cod,-Sh)
% Hacemos un recorrido por la lista de casos y devolvemos en una lista el 
% codigo que genera cada uno de ellos
%-----------------------------------------------------------------------------%

generateCodeCases([],_,_,[],on).
generateCodeCases([(_,Tree)|R],NameFun,Pos,Cod,Sh):-
        generateCode(Tree,NameFun,Pos,CodT,Sh1),
        generateCodeCases(R,NameFun,Pos,Rcod,Sh2),
        append(CodT,Rcod,Cod),
        doSh(Sh1,Sh2,Sh).
          
          
%-----------------------------------------------------------------------------%
% substituteArgList(+Lst,+Pos,+ArgNew,-Arg,-LstNew)
% Reemplaza en una lista de terminos, la posicion Pos, que contiene una 
% termino Arg por un nuevo ArgNew. La nueva lista se devuelve en LstNew.
%-----------------------------------------------------------------------------%

substituteArgList([V|Rar],[1],NV,V,[NV|Rar]):-!.  

substituteArgList([Ar|Rar],[1|Rpos],NV,V,[Nar|Rar]):-
    !,
    Ar=..[Name|Args],
    substituteArgList(Args,Rpos,NV,V,Args1),
    Nar=..[Name|Args1].

substituteArgList([Ar|Rar],[N|Rpos],NV,V,[Ar|Rar1]):-
    N1 is N-1,
    substituteArgList(Rar,[N1|Rpos],NV,V,Rar1).

%-----------------------------------------------------------------------------%
% variablesTerm(+Term,+Vin/-Vout)
% saca la lista de variables distintas de un termino ordenadas por orden de 
% aparicion en dicho termino
%-----------------------------------------------------------------------------%

variablesTerm(T,Vin/Vout):-
    var(T),
    !,
    insertVar(T,Vin/Vout).
variablesTerm(T,Vin/Vout):-
    T=..[_|Args],
    variablesList(Args,Vin/Vout).
    
%-----------------------------------------------------------------------------%
% variablesList(+List,+Vin/-Vout)
% saca la lista de variables distintas de la lista Lista ordenadas por orden de 
% aparicion en dicha lista.
%-----------------------------------------------------------------------------%

variablesList([],Vin/Vin).
variablesList([H|R],Vin/Vout):-
    variablesTerm(H,Vin/Vout1),
    variablesList(R,Vout1/Vout).

%-----------------------------------------------------------------------------%
% insertVar(+Var,+Listin/-Listout)
% inserta en la lista la variable Var si esa variable no aparecia en la lista.
% Si ya aparecia, deja la lista igual.
%-----------------------------------------------------------------------------%

insertVar(V,[]/[V]).
insertVar(V,[H|R]/[H|R]):-
    V==H,!.
insertVar(V,[H|R]/[H|R1]):-
    insertVar(V,R/R1).





/******************************************************************************/
%   RAMAS TRY
/******************************************************************************/


% El codigo asociado al try es la union de los codigos asociados a sus 
% alternativas. 

generateCode(try(Patron,Alts),NameFun,LastPosDem,Cod,Sh):-
        generateCodeAlts(Patron,Alts,NameFun,LastPosDem,Cod,Sh).


%generateCodeAlts(+Patron,+Alts,+NameFun,+LastPosDem,-Cod,?Sh)
generateCodeAlts(_,[],_,_,[],on).


% Depu 05/10/00 mercedes
% Se mete el Where en si(...) para generar el codigo de los where
generateCodeAlts(Patron,[si(Constr,Val,Where)|R],NameFun,LastPosDem,
                 [(Head,Body)|Rcod],C):-
    generateCodeAlt(Patron,si(Constr,Val,Where),NameFun,LastPosDem,
                              (Head,Body)),
    generateCodeAlts(Patron,R,NameFun,LastPosDem,Rcod,C1),
    doSh(Val,C1,C).

% Fin Depu

% Yoli YGR 10/01/2006 inicio ---------------------------------------------------
% Genero el c�digo cuando en el �rbol definicional tengo un corte 
% en las condiciones (cote de tipo "siCut")

generateCodeAlts(Patron,[siCut(Constr,Val,Where)|R],NameFun,LastPosDem,
                 [(Head,Body)|Rcod],C):-
    generateCodeAlt(Patron,siCut(Constr,Val,Where),NameFun,LastPosDem,
                              (Head,Body)),
    generateCodeAlts(Patron,R,NameFun,LastPosDem,Rcod,C1),
    doSh(Val,C1,C).

% YGR 10/01/2006 fin ---------------------------------------------------

generateCodeAlt(Patron,si(Constr,Val,Where),NFun,LastPosDem,(Head,Body)):-
        Patron=..[_|Args],

    % constrimos la cabeza de la clausula igual que en el case

        builtHead(NFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,Head),

    % Depu 05/10/00 mercedes
    % extraemos la lista de  partes izq. (que son var.) del where 
        % para la optimizacion
        % y se annaden a los patrones de la cabeza de la funcion
        extract_left_hand_side_Where(Where,Args,ListOpt),
    
    % construimos el codigo asociado al where
    doWhere(Where,Code,compilation),
    
        % Fin Depu 

    % construimos el codigo asociado a las restricciones
    doConstra(Constr,ListEqs1,Cin1,Cout1,compilation),
    optimizeEq(ListOpt,ListEqs1,ListEqs2),
    
    % el codigo del where se traduce como flechas; condiciones que 
    % preceden a las condiciones de la regla
    append(Code,ListEqs2,ListEqs),
    
    
        
        (   
        % si lo que devuelve la funcion es una variable, hacemos su hnf
        var(Val),!,
                insertAtTheEnd(hnf(Val,H,Cout1,Cout),ListEqs,Body1) 
    ;
        % si no puede ser una constructora, que meteremos en H o una 
        % llamada a una funcion que ira al final 
                Val=..[Name|As],
        (
                 (Name=do;
                  Name=intensional),!,  
                         % 05/06/00 mercedes (si es un do no metemos las
                         % suspensiones para que el formato que queda del
                         % do en el plgenerado sea un do con sus dos
                         % primeros argumentos como listas y concuerde con
                         % el codigo del do que hay en el toycomm.pl
                 (
             % si es una constructora le metemos suspensiones y la
             % colocamos como ultimo argumento del predicado
            
             isConstructor(Val,compilation),!,
             H=..[Name|As],
                         Body1=ListEqs,
             Cout=Cout1
                 ;
             % si es una funcion colocamos la llamada al final del
             % predicado
             name(Name,NameN),
             %append(NameN,Cons,NameL),
             name(NameFun,[36|NameN]),  % 36 es el ascii de $
             append(As,[H,Cout1,Cout],Aux),
             Call=..[NameFun|Aux],
                         insertAtTheEnd(Call,ListEqs,Body1)
                 )
        
        ;
                 
         % en cualquier caso suspendemos las posibles llamadas a 
         % funciones que aparezcan por dentro.
                 introduceSuspList(As,ValSusp,compilation),
                 (
             % si es una constructora le metemos suspensiones y la
             % colocamos como ultimo argumento del predicado
            
             isConstructor(Val,compilation),!,
             H=..[Name|ValSusp],
                         Body1=ListEqs,
             Cout=Cout1
                 ;
             % si es una funcion colocamos la llamada al final del
             % predicado
             name(Name,NameN),
             %append(NameN,Cons,NameL),
             name(NameFun,[36|NameN]),  % 36 es el ascii de $
             append(ValSusp,[H,Cout1,Cout],Aux),
             Call=..[NameFun|Aux],
                         insertAtTheEnd(Call,ListEqs,Body1)
                 )
                )
        ),     
                 

    % si se necesita se mete por delante un unifyHnfs igual que en el case

    (var(Var),!,Body=[unifyHnfs(Var,Cons,Cin,Cin1)|Body1]
    ;
    Body=Body1,Cin1=Cin).

% YGR 10/01/2006 inicio ------------------------------------------------
% c�digo de corte en la condici�n para una alternativa

generateCodeAlt(Patron,siCut(Constr,Val,Where),NFun,LastPosDem,(Head,Body)):-
        Patron=..[_|Args],

    % constrimos la cabeza de la clausula igual que en el case

        builtHead(NFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,Head),

    % Depu 05/10/00 mercedes
    % extraemos la lista de  partes izq. (que son var.) del where 
        % para la optimizacion
        % y se annaden a los patrones de la cabeza de la funcion
        extract_left_hand_side_Where(Where,Args,ListOpt),
    
    % construimos el codigo asociado al where
    doWhere(Where,Code,compilation),
    
        % Fin Depu 

    % construimos el codigo asociado a las restricciones
    doConstra(Constr,ListEqs1,Cin1,Cout1,compilation),
    optimizeEq(ListOpt,ListEqs1,ListEqs2),
    
    % el codigo del where se traduce como flechas; condiciones que 
    % preceden a las condiciones de la regla
    append(Code,ListEqs2,ListEqs),   
/*      % YGR -------------
    append(Code,ListEqs2,Bodyaux),
      append(Bodyaux, [grupo(checkVarList(Milista),true)],Bodyaux1),
      append([varList(Args,Milista)],Bodyaux1,ListEqs),

      % YGR --------------
*/  
    
        
        (   
        % si lo que devuelve la funcion es una variable, hacemos su hnf
        var(Val),!,
                insertAtTheEnd(hnf(Val,H,Cout1,Cout),ListEqs,Body1) 
    ;
        % si no puede ser una constructora, que meteremos en H o una 
        % llamada a una funcion que ira al final 
                Val=..[Name|As],
        (
                 (Name=do;
                  Name=intensional),!,  
                         % 05/06/00 mercedes (si es un do no metemos las
                         % suspensiones para que el formato que queda del
                         % do en el plgenerado sea un do con sus dos
                         % primeros argumentos como listas y concuerde con
                         % el codigo del do que hay en el toycomm.pl
                 (
             % si es una constructora le metemos suspensiones y la
             % colocamos como ultimo argumento del predicado
            
             isConstructor(Val,compilation),!,
             H=..[Name|As],
                         Body1=ListEqs,
             Cout=Cout1
                 ;
             % si es una funcion colocamos la llamada al final del
             % predicado
             name(Name,NameN),
             %append(NameN,Cons,NameL),
             name(NameFun,[36|NameN]),  % 36 es el ascii de $
             append(As,[H,Cout1,Cout],Aux),
             Call=..[NameFun|Aux],
                         insertAtTheEnd(Call,ListEqs,Body1)
                 )
        
        ;
                 
         % en cualquier caso suspendemos las posibles llamadas a 
         % funciones que aparezcan por dentro.
                 introduceSuspList(As,ValSusp,compilation),
                 (
             % si es una constructora le metemos suspensiones y la
             % colocamos como ultimo argumento del predicado
            
             isConstructor(Val,compilation),!,
             H=..[Name|ValSusp],
                         Body1=ListEqs,
             Cout=Cout1
                 ;
             % si es una funcion colocamos la llamada al final del
             % predicado
             name(Name,NameN),
             %append(NameN,Cons,NameL),
             name(NameFun,[36|NameN]),  % 36 es el ascii de $
             append(ValSusp,[H,Cout1,Cout],Aux),
             Call=..[NameFun|Aux],
                         insertAtTheEnd(Call,ListEqs,Body1)
                 )
                )
        ),     
                 

    % si se necesita se mete por delante un unifyHnfs igual que en el case

    (
        var(Var),
        !,
         % Body=[unifyHnfs(Var,Cons,Cin,Cin1)|Body1]
           Bodycut=[unifyHnfs(Var,Cons,Cin,Cin1)|Body1]
      ;
       % Body=Body1,
         Bodycut=Body1,
         Cin1=Cin
      )
      % Yoli YGR inicio ---------------------
      ,
       append(Bodycut, [grupo(checkVarList(Milista),true)],Bodyaux1),
       % 26/01/2006 inicio
       variablesTerm(Val,[]/LstVale),
       append(Args,LstVale,Le1),
       remove_duplicates(Le1,Le),
       append([varList(Le,Milista)],Bodyaux1,Body)
  %     append([varList(Args,Milista)],Bodyaux1,Body)

    % Yoli YGR  fin -----------------------
      .




% YGR 10/01/2006 fin ---------------------------------------------------


% Depu 05/10/00 mercedes
extract_left_hand_side_Where([],Args,Args) :- 
    !.

extract_left_hand_side_Where(['='(Var,_Expr,_Lin)|R],Args,[Var|LOut]) :-
    !,
    extract_left_hand_side_Where(R,Args,LOut).

% Fin Depu


/*
Hasta ahora, si teniamos:
f(X) = g(Y) <== Y == h(X)
lo que hacia Y == h(X) era ir calculando las fnc de Y y de h(X) e ir comparandolas 
poco a poco.
Se ha comprobado que si tenemos f(Args1) = g(Args2) <== Condiciones, Y==T (o T==Y)
donde Y es una variable, Y no aparece en Args1, tampoco aparece en Condiciones y
tampoco aparece en T, entonces es mas eficiente resolver esa igualdad haciendo 
la forma normal de T y compararla con Y.
Y si podria aparacer en Args2. Esta optimizacion tambien hay que hacerla en los 
objetivos. Para hacer esta optimizacion los cambios que se han hecho son: en las
ramas try, en generateCodeAlt, despues de doConstra, se llama a un predicado 
optimizeEq que lo que hace es comprobar si es una de las igualdades que se 
pueden optimizar y si es asi cambia la restriccion equal por equalnf que lo 
que hace es llevar a cabo la igualdad de la nueva forma).
*/
    
optimizeEq(Args,ListEqs,NewList):-
    variablesTerm(Args,[]/LstVars),
    optimize(LstVars,ListEqs,NewList).
    
    


optimize(LstVars,[],[]).
optimize(LstVars,[equal(S,T,Cin,Cout)|Rest],[Constr|Rr]):-
    var(S),
    !,
    (
     member(S,LstVars),!,
     Constr= equal(S,T,Cin,Cout),
     term_variables(T,Vars),
     append(LstVars,Vars,List),
     optimize(List,Rest,Rr)
    ;
     term_variables(T,Vars),
     (
      member(S,Vars),!,
      Constr= equal(S,T,Cin,Cout),
      append(LstVars,Vars,List),
      optimize([S|List],Rest,Rr)
     ;
      append(LstVars,Vars,List),
      Constr= equalnf(S,T,Cin,Cout),
      optimize([S|List],Rest,Rr)
     )
    ).  
        
optimize(LstVars,[equal(S,T,Cin,Cout)|Rest],[Constr|Rr]):-
    var(T),
    !,
    (
     member(T,LstVars),!,
     Constr= equal(S,T,Cin,Cout),
     term_variables(S,Vars),
     append(LstVars,Vars,List),
     optimize(List,Rest,Rr)
    ;
     term_variables(S,Vars),
     (
      member(T,Vars),!,
      Constr= equal(S,T,Cin,Cout),
      append(LstVars,Vars,List),
      optimize([T|List],Rest,Rr)
     ;
      append(LstVars,Vars,List),
      Constr= equalnf(T,S,Cin,Cout),
      optimize([T|List],Rest,Rr)
     )
    ).
    
optimize(LstVars,[equal(S,T,Cin,Cout)|Rest],[equal(S,T,Cin,Cout)|Rr]):-
    !,
    term_variables(S,Vars1),
    term_variables(T,Vars2),
    append(Vars1,Vars2,Vars3),
    append(LstVars,Vars3,List),
    optimize(List,Rest,Rr).
    
optimize(LstVars,[notEqual(S,T,Cin,Cout)|Rest],[notEqual(S,T,Cin,Cout)|Rr]):-
    term_variables(S,Vars1),
    term_variables(T,Vars2),
    append(Vars1,Vars2,Vars3),
    append(LstVars,Vars3,List),
    optimize(List,Rest,Rr).

    
optimize(LstVars,['$$apply'(F,T,R,Cin,Cout)|Rest],  % En el caso de la funcion:
         ['$$apply'(F,T,R,Cin,Cout)|Rr]):-           % rId Filter X = X <== Filter X
                                                     % doConstra devuelve:
        var(T),                          % ['$$apply(Var1,Var2,true,
        !,                       % Cin,Cout)]
        optimize([T|LstVars],Rest,Rr).

    
optimize(LstVars,['$$apply'(F,T,R,Cin,Cout)|Rest],
         ['$$apply'(F,T,R,Cin,Cout)|Rr]):-

        !,
        term_variables(T,Lst),
        append(LstVars,Lst,List),
        optimize(List,Rest,Rr).
        
optimize(LstVars,[T|Rest],[T|Rest]):-       % En el caso de la funcion:
    term_variables(T,Lst),          % badsort Xs = Ys <== Ys==permut Xs,
    append(LstVars,Lst,List),       %             sorted Ys            
    optimize(List,Rest,Rr).     % doConstra devuelve:
                        % [equal(Var1,'$$susp'('$permut',
                        %  _,_,_),_,_),
                        %  '$sorted'(Var2,true,_,_)],
                        % por tanto para optimizar el 
                        % segundo elemento de esta lista
                        % entra por este optimize.  
       
    
%-----------------------------------------------------------------------------%
% introduceSusp(+Term,-TermSusp,+Time)
% TermSusp es el resultado de meter suspensiones en Term.
% El ultimo argumento (Time) nos indica si estamos en tiempo de ejecucion o de
% compilacion, puesto que los cdata de comp son constr en ejecucion y los ftype
% son funct
%-----------------------------------------------------------------------------%

introduceSusp(Term,Term,_):-var(Term),!.
introduceSusp(Term,TermSusp,Time):-
        Term=..[Name|Args],
        (
         (Name=do;
          Name=intensional),!,   
                  % 07/06/00 mercedes: cuando tenemos que suspender el do,
                  % dejamos los argumentos sin suspender, para que queden
                  % en foma de listas y luego concuerden con la funcion '$do'
                  % que hay en el toycomm.pl
                  % Lo mismo hacemos con las listas intensionales
         name(Name,L),name(NameF,[36|L]),   
     TermSusp=..['$$susp',NameF,Args,_,_]
    ;
     Name='$$susp',  % 12/07/00 mercedes
     !,
     TermSusp=Term   %%ppaco por que aqui no hay que hacer nada?
    ;
     introduceSuspList(Args,ArgsSusp,Time),
         (       
                 isConstructor(Term,Time),  % miramos si es Constructora
         !,              
                 TermSusp=..[Name|ArgsSusp]
         ;
                 % es una funcion
         name(Name,L),name(NameF,[36|L]),   
             TermSusp=..['$$susp',NameF,ArgsSusp,_,_]
         )
        ).
        
        
%-----------------------------------------------------------------------------%
% introduceSuspList(+List,-ListSusp,+Time)
% ListaSusp es el resustado de meter suspensiones en cada elemento de Lista.
%-----------------------------------------------------------------------------%

introduceSuspList([],[],_):-!.
introduceSuspList([L|R],[L1|R1],Time):-
        introduceSusp(L,L1,Time),
        introduceSuspList(R,R1,Time).
                

%-----------------------------------------------------------------------------%
% isConstructor(+Term,+Time)
% es constructora si es una constructora o si es una funcion aplicada
% parcialmente. El parametro Time indica si la llamada se realiza en tiempo
% de compilacion o de ejecucion. En compilacion tenemos cdata(...) y fun(...)
% y en ejecucion tenemos constr y funct. En este modulo se usa en tiempo de 
% compilacion pero cuando se lanzan objetivos, las suspensiones se meten en
% tiempo de ejecucion.
%-----------------------------------------------------------------------------%

isConstructor(Term,_):-number(Term).

isConstructor(Term,Time):-
    functor(Term,Name,Ar),
    (
        (Name=='$eqFun';Name=='$notEqFun'),Ar<2
    ;
        Time==compilation,
        (
            cdata(Name,_,_,_),!
            ;
            fun(Name,ArP,_,_),!,Ar<ArP
            ;
            primitive(Name,_,_),
            !,
            % Depu 25/10/00 mercedes
            % cambiamos ftype por primitiveFunct
            % ftype(Name,ArP,_,_),
            primitiveFunct(Name,_,ArP,_,_),
            Ar<ArP
         )
    ;
        Time==execution,
        (constr(Name,_,_,_),!
        ;
        funct(Name,ArP,_,_,_),!,Ar<ArP)
    ).  



% Depu 06/11/00 mercedes

%ppacol 05-01-2009: usamos doWhere para la gestion de ct
% Antes, en ambiente todo ct, una declaracion where X=E generaba el codigo X=E
%        eso iba bien porque E tenia sus suspensiones
% Ahora, en ambiente rt --conseguido a base de hacer rt todas las suspensiones--
%        una declaracion where X=E genera el codigo 
%            introduceSuspCt(E,E1,execution),X=E
%        introduceSuspCt(E,E1,execution) se encarga de meter las suspensiones adecuadas
%        Esta definido en toycomm.pl (para usarlo en tiempo de ejecucion)
%        Adem�s en toycomm.pl se ha combiado el computo de hnf (hnf2)
%        pues es necesario manejar din�micamente la introduccion de suspensiones 

%-----------------------------------------------------------------------------%
% doWhere(+Where,-Code, +Time)
% Trata las decl. where, que a partir de este predicado ya desaparecen.
% Para ello se supone que Where es una lista donde cada elemento tiene la
% forma: '='(Var,Expr,Lin), con Var una variable prolog. La forma de eliminar
% una declaracion de este tipo es introducir las suspensiones que sean necesarias
% en Expr y devolver el codigo que unifica la variable con la suspension.
%-----------------------------------------------------------------------------%
doWhere([],[],_):-
    !.
    
doWhere(['='(Var,Expr,Lin)|R],[introduceSuspCt(ExprSusp,E,execution),Var=E|Code],Time):-
    !,
    
    % Var es una variable --> unificamos con la suspension
    % introduceSusp(Expr,Var,Time),  
    introduceSusp(Expr,ExprSusp,Time),
    doWhere(R,Code,Time).   

% Fin Depu

/*************** CODIGO EN PRUEBAS  ******************/
% Por el momento las unicas restricciones permitidas son las de igualdad y 
% desigualdad, que se traducen en el predicado equal y notEqual resp.
% Se puede optimizar mas aun el codigo. El caso de que uno de los argumentos 
% sea true se puede generalizar a que sea una constructora cualquiera y se 
% puede hacer un hnf orientado

% Depu 05/10/00 mercedes


%-----------------------------------------------------------------------------%
% doWhere(+Where,-WhereCode,+Cin,-Cout,+Time)
% Devuelve en WhereCode el codigo asociado a las declaraciones que estan en la
% lista Where.
% Cin es el almacen de restricciones de entrada y Cout el de salida.
%-----------------------------------------------------------------------------%
 
%doWhere([],[],Cin,Cin,_):-
%   !.
%
%doWhere(['='(Pat,Expr,Lin)|R],[Where1|WhereR],Cin,Cout,Time):-
%   !,
%   introduceSusp(Expr,ExprSusp,Time),
%   % distinguimos 2 casos:
%   (
%    % el patron es una variable --> unificamos
%    var(Pat),
%    Pat = ExprSusp,
%    Where1 = [],
%    Cin1 = Cin
%   ; 
%    % el patron es un patron plano no variable --> hnf
%    Where1 = hnf(ExprSusp,Pat,Cin,Cin1)
%       ),
%   doWhere(R,WhereR,Cin1,Cout,Time).

% Fin Depu

%-----------------------------------------------------------------------------%
% doConstra(+Constr,-ListEqs,+Cin,-Cout,+Time)
% Devuelve en ListEqs el codigo asociado a las restricciones que estan en la
% lista Constr.
% Cin es el almacen de restricciones de entrada y Cout el de salida.
%-----------------------------------------------------------------------------%

doConstra([],[],Cin,Cin,_):-!.
doConstra([T1==T2|R],[Constr|Rr],Cin,Cout,Time):-
    !,
        introduceSusp(T1,T1Susp,Time),
        introduceSusp(T2,T2Susp,Time),
    (
        (T1Susp==true;T1Susp==false),
        nonvar(T2Susp),
        T2Susp=..['$$susp',NameFun,Args,_,_],
        !,
        append(Args,[T1Susp,Cin,Cout1],ArgsFun),
        Constr=..[NameFun|ArgsFun]
    ;
        (T2Susp==true;T2Susp==false),
        nonvar(T1Susp),
        T1Susp=..['$$susp',NameFun,Args,_,_],
        !,
        append(Args,[T2Susp,Cin,Cout1],ArgsFun),
        Constr=..[NameFun|ArgsFun]
    ;
        Constr=equal(T1Susp,T2Susp,Cin,Cout1)
    ),
        doConstra(R,Rr,Cout1,Cout,Time).

doConstra(['/='(T1,T2)|R],[notEqual(T1Susp,T2Susp,Cin,Cout1)|Rr],
                            Cin,Cout,Time):-
    !,
    introduceSusp(T1,T1Susp,Time),
        introduceSusp(T2,T2Susp,Time),
        doConstra(R,Rr,Cout1,Cout,Time).
    

/*************** FIN EN PRUEBAS  ******************/


/**************************** ANTIGUO CODIGO SIN LA OPTIMIZACION      

% Por el momento las unicas restricciones permitidas son las de igualdad y 
% desigualdad, que se traducen en el predicado equal y notEqual resp.
doConstra([],[],_):-!.
doConstra([T1==T2|R],[equal(T1Susp,T2Susp)|Rr],Time):-
    !,
        introduceSusp(T1,T1Susp,Time),
        introduceSusp(T2,T2Susp,Time),
        doConstra(R,Rr,Time).

doConstra(['/='(T1,T2)|R],[notEqual(T1Susp,T2Susp)|Rr],Time):-
    !,
    introduceSusp(T1,T1Susp,Time),
        introduceSusp(T2,T2Susp,Time),
        doConstra(R,Rr,Time).
    

******************************/



% CONSTRUCCION DE LAS CASCARAS
% estos predicados sacan la cascara comun a dos terminos, e.d., estudia las
% constructoras comunes de los dos terms. El flag on indica que el termino 
% admite cualquier cascara (depende del otro termino). Aparece como fin de
% algunas llamadas recursivas. El flag off indica que en las ramas que hay
% por debajo no ha sido posible construir cascara comun y por lo tanto ahora
% tampoco

%-----------------------------------------------------------------------------%
% doSh(+Sh1,+Sh2,-Sh) donde Sh1 y Sh2 son dos terminos y Sh es la cascara comun 
% a Sh1 y Sh2.
%-----------------------------------------------------------------------------%

doSh(Sh1,Sh2,off):-(var(Sh1);var(Sh2)),!.
doSh(off,_,off):-!.
doSh(_,off,off):-!.
doSh(Sh1,on,Sh):-
    !,
    (isConstructor(Sh1,compilation),Sh=Sh1;
    Sh=off).
doSh(on,Sh1,Sh):-
    !,
    (isConstructor(Sh1,compilation),Sh=Sh1;
    Sh=off).
doSh(Sh1,Sh2,Sh):-
    (   
        isConstructor(Sh1,compilation),
        isConstructor(Sh2,compilation),
        Sh1=..[Name|Args1],
        Sh2=..[Name|Args2],
        listSh(Args1,Args2,Ls),
        !,
        Sh=..[Name|Ls]
    ;
        Sh=off
    ).  

%-----------------------------------------------------------------------------%
% listSh(+L1,+L2,-L) donde L1 y L2 son listas de terminos y L es otra 
% lista que contiene las cascaras comunes a dos terminos (uno de L1 y otro de L2)
%-----------------------------------------------------------------------------%

listSh([],[],[]):-!.
listSh([L1|R1],[L2|R2],[Ls|Rs]):-
    sh(L1,L2,Ls),
    listSh(R1,R2,Rs).

%-----------------------------------------------------------------------------%
% sh(+Sh1,+Sh2,-Sh) donde Sh1 y Sh2 son terminos
% es igual que doSh, pero si doSh devuelve off (no tienen cascara
% comun) aqui devolvemos una nueva variable, pq en este punto ya sabemos que 
% tienen cascara comun, y si internamente no la tienen hay que meter una var
%-----------------------------------------------------------------------------%

sh(Sh1,Sh2,Sh):-
    doSh(Sh1,Sh2,Sh3),
    (
        Sh3==off,
        Sh=_
    ;
        Sh=Sh3
    ).






%-----------------------------------------------------------------------------%

% doNameFun(+NameFun,+Pos,+Cons,-Out)
% Concatena NameFun con la lista de n�s de Pos separados por .'s y precedida
% por _ . Tambien se concatena la constructora de Cons precedida por _.
%  Por ejemplo doNameFun(hola_1.2,[3,4,5],[suc],Out) nos devuelve en 
% Out hola_1.2_3.4.5_suc.
% Lo de meter al final del nombre la constructora, es una de las optimizaciones
% de codigo que se hacen (Ver libro Jaime, pag. 102).
%-----------------------------------------------------------------------------%

doNameFun(NameFun,Pos,Cons,NameFun1):-
        unePos(Pos,Res),
    name(NameFun,NameFunN),
    % 95 es el ascii de _
    (
        Cons==[],
        !,
        Aux=[95|Res]
    ;
        functor(Cons,F,_),
        name(F,ConsN),
        append([95|Res],[95|ConsN],Aux)
    ), 
    append(NameFunN,Aux,Aux1),
    name(NameFun1,Aux1).    

%-----------------------------------------------------------------------------%
% unePos(+List,-Out)
% Transforma una lista en la cadena formada por sus eltos separados por .'s
%-----------------------------------------------------------------------------%

unePos([P],S):-!,name(P,S).
unePos([P|R],Out):-
        name(P,S),
        unePos(R,Rest),
        append(S,".",R1),
        append(R1,Rest,Out).



/************************************************************************/
% ORDENACION DEL CODIGO.
%-----------------------------------------------------------------------------%
% putInOrderCode(+Cod,-CodOr)
% Cod es una lista de codigo con elementos de la forma (Head,Body)
%-----------------------------------------------------------------------------%

putInOrderCode(Cod,CodOr):-
        putInOrderCodePairs(Cod,[],CodPairs),
        smoothCode(CodPairs,CodOr).

%-----------------------------------------------------------------------------%
% putInOrderCodePairs(+Cod,?Ac,-CodPairs)
% CodPairs es una lista con elementos de la forma (Name,L), donde Name es
% el nombre de un predicado y L es la lista que lleva el codigo asociado a todas
% las clausulas que llevan ese nombre en cabeza.
% Ac es una lista que tambien tiene esa forma y sirve de acumulador.
%-----------------------------------------------------------------------------%

putInOrderCodePairs([],Ac,Ac).
putInOrderCodePairs([(Head,Body)|R],Ac,CodOr):-
        functor(Head,Name,_),
        insertPred((Head,Body),Name,Ac,Ac1),
        putInOrderCodePairs(R,Ac1,CodOr).

%-----------------------------------------------------------------------------%
% insertPred(+Cod,+Name,?Ac,-CodPairs)
% Tengo el codigo de una clausula del predicado Name en Cod. Si en Ac ya habia
% alguna clausula de ese predicado metida, i.e., ya habia un elemento de la 
% forma (Name,L), entonces se inserta Cod al final de L. En otro caso, se
% inserta en Ac un nuevo elemento de la forma (Name,[Cod]).
%-----------------------------------------------------------------------------%

insertPred((Head,Body),Name,[],[(Name,[(Head,Body)])]).
insertPred((Head,Body),Name,[(Name,L)|R],[(Name,L1)|R]):-
        !,
        insertAtTheEnd((Head,Body),L,L1).

insertPred(Pair,Name,[Pair2|R],[Pair2|R1]):-
        insertPred(Pair,Name,R,R1).

% smoothCode(+Cod,-Out)
% *********************
smoothCode([],[]).
smoothCode([(_,L)|R],Res):-smoothCode(R,R1),append(L,R1,Res).


/************************************************************************/





/************************************************************************/
% PREDICADOS PARA DEPURACION
/************************************************************************/

% SALIDA DEL CODIGO A PANTALLA DE FORMA + O - LEGIBLE


extractCodeFuns([]):-!.
extractCodeFuns([CodFun|R]):-extractCodeFunN(CodFun),extractCodeFuns(R).

extractCodeFunN([(Head,Body)|R]):-
    functor(Head,Name,_),
    write('% CODIGO PARA LA FUNCION '),write(Name),nl,
    extractCode([(Head,Body)|R]).

extractCode([]):-!.
extractCode([(Head,Body)|R]):-!,write(Head),write(' :- '),extractBody(Body),extractCode(R).
extractBody([]):-!,write('.'),nl.
extractBody([C|R]):-!,write(C),(R\==[],write(', ');true),extractBody(R).


/*************************************************************************************/
  % YGR 10/01/2006 INICIO
  % hace el nombre de la funci�n
/*************************************************************************************/

doNameFunCorte(NameFun,NameFunCall):-
      name(NameFun,NameFunN),
    Aux=[95|Res],
    name(or,Res),
    append(NameFunN,Aux,Aux1),
    name(NameFunCall,Aux1). 

%-----------------
% esta funcion es exactamente igual que la de builtHead


builtCallCorte(NameFun,Args,H,[],[],[],Cin,Cout,CallCorte,Args):-
    append(Args,[H,Cin,Cout],Aux),
    CallCorte=..[NameFun|Aux].

builtCallCorte(NameFun,Args,H,LastPosDem,Cons,Var,Cin,Cout,CallCorte,LstVars):-
    substituteArgList(Args,LastPosDem,Var,Cons,Args1),
    variablesTerm(Args1,[]/LstVars),
    append(LstVars,[H,Cin,Cout],Aux),
    CallCorte=..[NameFun|Aux].


  % YGR 10/01/2006 FIN

%------- Parche de codigo para collect ----
%-------      %ppaco  7-10-08  -----
parcheaMetaCollect(CodF,CodF).  % Provisional, obviously 
%-------      %ppaco  4-12-07  -----
parcheaCollect(CodF1,CodF) :- 
                          %        %%ppaco depura
                          %        write(callparchea(CodF1)),nl,
    cambiaG(CodF1,CodF)
                          %        %%ppaco depura
                          %        write(exitparchea(CodF)),nl
    .

cambiaG(X,X) :- sencillo(X),!.
cambiaG('$collect'(E,H,Cin,COut),'$collect'(Vs^E1,H,Cin,COut)) :- !,cambiaC(E,E1,[],Vs).
cambiaG('$$susp'(F,[E],R,S),'$$susp'('$collect',[Vs^E1],R,S)) :- F=='$collect',!,cambiaC(E,E1,[],Vs).
cambiaG(X,Y) :- X =.. [F|Xs],cambiaGL(Xs,Ys),Y=..[F|Ys].

cambiaGL([],[]).
cambiaGL([X|Xs],[Y|Ys]) :- cambiaG(X,Y),cambiaGL(Xs,Ys).

cambiaC(X,X,Vs,Vs) :- sencillo(X),!.
cambiaC('$$susp'(F,Args,R,S),'$$susp'(F,Args1,R,S),Vs,Vs1) :- !,cambiaCL(Args,Args1,[R,S|Vs],Vs1).
cambiaC(X,Y,Vs,Vs1) :- X =.. [F|Xs],cambiaCL(Xs,Ys,Vs,Vs1),Y=..[F|Ys].

cambiaCL([],[],Vs,Vs).
cambiaCL([X|Xs],[Y|Ys],Vs,Vs1) :- cambiaC(X,Y,Vs,Vs2),cambiaCL(Xs,Ys,Vs2,Vs1).

sencillo(X) :- (var(X);atomic(X)),!.

%------- Fin Parche de codigo para collect ----
%-------      %ppaco  4-12-07  -----

%------- Parche de codigo para rt (runtime choice) ----
%-------      %ppaco  19-09-2008  -----
%% Se contemplan dos posibilidades de introducir rt
%  Primera posibilidad: se ha assertado option(rt_all), para hacer que todo sea runtime
%  Para asertar setoption(rt_all), hay que haber hecho
%  Toy> /prolog(assert(option(rt_all)))
%  El predicado option/1 est� declarado como din�mico y exportado en dy.pl, e importado 
%  de dyn.pl por initToy.pl
%  Cuando se aserta desde el prompot de Toy, se aserta como initToy:option

%  Segunda posibilidad: solo se hace runtime lo escrito como (rt <expresion>)

%  En el primer caso, todas las suspensiones se marcan con el flag rt (en lugar de variable)
%  En el segundo, solo las de <expresion>
%  La evaluaci�n de suspensiones con flag rt est� en toycomm.pl
%  OJO: todo este cambio en el comportamiento de suspensiones no se realiza ahora mismo
%  en objetivos, sino solo en programas

parcheaRuntime(CodF1,CodF) :- 
     initToy:option(rt_all),!,   %% Primera posibilidad
     cambiaRTsinduda(CodF1,CodF)  
     ;                           %% Segunda posibilidad
     cambiaRT(CodF1,CodF)
    .

cambiaRT(X,X) :- sencillo(X),!.
cambiaRT('$rt'(E,H,Cin,COut),'$rt'(E1,H,Cin,COut)) :- !,cambiaRTsinduda(E,E1).
cambiaRT('$$susp'(F,[E],R,S),'$$susp'(F,[E1],R,rt)) :- F=='$rt',!, cambiaRTsinduda(E,E1).
cambiaRT(X,Y) :- X =.. [F|Xs],cambiaRTL(Xs,Ys),Y=..[F|Ys].

cambiaRTL([],[]).
cambiaRTL([X|Xs],[Y|Ys]) :- cambiaRT(X,Y),cambiaRTL(Xs,Ys).

cambiaRTsinduda(X,X) :- sencillo(X),!.
cambiaRTsinduda('$$susp'(F,Args,R,S),'$$susp'(F,Args1,R,rt)) :- !,cambiaRTLsinduda(Args,Args1).
cambiaRTsinduda(X,Y) :- X =.. [F|Xs],cambiaRTLsinduda(Xs,Ys),Y=..[F|Ys].

cambiaRTLsinduda([],[]).
cambiaRTLsinduda([X|Xs],[Y|Ys]) :- cambiaRTsinduda(X,Y),cambiaRTLsinduda(Xs,Ys).

%------- Fin Parche de codigo para rt (runtime choice) ----
%-------      %ppaco  19-09-2008  -----
