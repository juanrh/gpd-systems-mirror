constr(tkButton, 2, ->(->(channel, _A), ->(:(tkConfItem(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkCanvas, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkCheckButton, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkEntry, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkLabel, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkListBox, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkMessage, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkMenuButton, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkScale, 3, ->('$num'(int), ->('$num'(int), ->(:(tkConfItem(_A), []), tkWidget(_A)))), tkWidget(_A)).
constr(tkScrollV, 2, ->(tkRefType, ->(:(tkConfItem(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkScrollH, 2, ->(tkRefType, ->(:(tkConfItem(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkTextEdit, 1, ->(:(tkConfItem(_A), []), tkWidget(_A)), tkWidget(_A)).
constr(tkRow, 2, ->(:(tkConfCollection, []), ->(:(tkWidget(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkCol, 2, ->(:(tkConfCollection, []), ->(:(tkWidget(_A), []), tkWidget(_A))), tkWidget(_A)).
constr(tkActive, 1, ->(bool, tkConfItem(_A)), tkConfItem(_A)).
constr(tkAnchor, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkBackground, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkCmd, 1, ->(->(channel, _A), tkConfItem(_A)), tkConfItem(_A)).
constr(tkHeight, 1, ->('$num'(int), tkConfItem(_A)), tkConfItem(_A)).
constr(tkInit, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkItems, 1, ->(:(tkCanvasItem, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkList, 1, ->(:(:(char, []), []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkMenu, 1, ->(:(tkMenuItem(_A), []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkRef, 1, ->(tkRefType, tkConfItem(_A)), tkConfItem(_A)).
constr(tkText, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkWidth, 1, ->('$num'(int), tkConfItem(_A)), tkConfItem(_A)).
constr(tkTcl, 1, ->(:(char, []), tkConfItem(_A)), tkConfItem(_A)).
constr(tkCenter, 0, tkConfCollection, tkConfCollection).
constr(tkLeft, 0, tkConfCollection, tkConfCollection).
constr(tkRight, 0, tkConfCollection, tkConfCollection).
constr(tkTop, 0, tkConfCollection, tkConfCollection).
constr(tkBottom, 0, tkConfCollection, tkConfCollection).
constr(tkExpand, 0, tkConfCollection, tkConfCollection).
constr(tkExpandX, 0, tkConfCollection, tkConfCollection).
constr(tkExpandY, 0, tkConfCollection, tkConfCollection).
constr(tkMButton, 2, ->(->(channel, _A), ->(:(char, []), tkMenuItem(_A))), tkMenuItem(_A)).
constr(tkMSeparator, 0, tkMenuItem(_A), tkMenuItem(_A)).
constr(tkMMenuButton, 2, ->(:(char, []), ->(:(tkMenuItem(_A), []), tkMenuItem(_A))), tkMenuItem(_A)).
constr(tkLine, 2, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), ->(:(char, []), tkCanvasItem)), tkCanvasItem).
constr(tkPolygon, 2, ->(:('$$tuple'(','('$num'(int), '$num'(int))), []), ->(:(char, []), tkCanvasItem)), tkCanvasItem).
constr(tkRectangle, 3, ->('$$tuple'(','('$num'(int), '$num'(int))), ->('$$tuple'(','('$num'(int), '$num'(int))), ->(:(char, []), tkCanvasItem))), tkCanvasItem).
constr(tkOval, 3, ->('$$tuple'(','('$num'(int), '$num'(int))), ->('$$tuple'(','('$num'(int), '$num'(int))), ->(:(char, []), tkCanvasItem))), tkCanvasItem).
constr(tkRefLabel, 3, ->(channel, ->(:(char, []), ->(:(char, []), tkRefType))), tkRefType).

funct(openWish, 1, 1, ->(:(char, []), io(channel)), io(channel)).
funct(readWish, 1, 1, ->(channel, io(:(char, []))), io(:(char, []))).
funct(writeWish, 2, 2, ->(channel, ->(:(char, []), io(unit))), io(unit)).
funct(closeWish, 1, 1, ->(channel, io(unit)), io(unit)).
funct(strToint, 1, 1, ->(:(char, []), '$num'(int)), '$num'(int)).
funct(getNumber, 2, 2, ->(:(char, []), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(intTostr, 1, 1, ->('$num'(int), :(char, [])), :(char, [])).
funct(getString, 2, 2, ->('$num'(int), ->(:(char, []), :(char, []))), :(char, [])).
funct(tkShowErrors, 0, 0, bool, bool).
funct(tkRef2Label, 1, 1, ->(tkRefType, :(char, [])), :(char, [])).
funct(tkRef2Wtype, 1, 1, ->(tkRefType, :(char, [])), :(char, [])).
funct(tk2tcl, 3, 3, ->(channel, ->(:(char, []), ->(tkWidget(_A), ','(:(char, []), :(->(','(:(char, []), channel), _A), []))))), ','(:(char, []), :(->(','(:(char, []), channel), _A), []))).
funct(tkConfCollection2tcl, 2, 2, ->(:(char, []), ->(tkConfCollection, :(char, []))), :(char, [])).
funct(tkConf2tcl, 4, 4, ->(:(char, []), ->(channel, ->(:(char, []), ->(tkConfItem(_A), :(char, []))))), :(char, [])).
funct(setlistelems, 2, 2, ->(:(:(char, []), []), ->(:(char, []), :(char, []))), :(char, [])).
funct(tkMenu2tcl, 2, 2, ->(:(char, []), ->(:(tkMenuItem(_A), []), :(char, []))), :(char, [])).
funct(setmenuelems, 2, 2, ->(:(tkMenuItem(_A), []), ->('$num'(int), :(char, []))), :(char, [])).
funct(tkConfs2handler, 2, 2, ->(:(char, []), ->(:(tkConfItem(_A), []), :(->(','(:(char, []), channel), _A), []))), :(->(','(:(char, []), channel), _A), [])).
funct(tkMenu2handler, 3, 3, ->(:(char, []), ->(:(tkMenuItem(_A), []), ->('$num'(int), :(->(','(:(char, []), channel), _B), [])))), :(->(','(:(char, []), channel), _B), [])).
funct(tkConfs2tcl, 4, 4, ->(:(char, []), ->(channel, ->(:(char, []), ->(:(tkConfItem(_A), []), :(->(','(:(char, []), channel), _A), []))))), :(->(','(:(char, []), channel), _A), [])).
funct(tkcitems2tcl, 2, 2, ->(:(char, []), ->(:(tkCanvasItem, []), :(char, []))), :(char, [])).
funct(tkcitem, 2, 2, ->(:(char, []), ->(tkCanvasItem, :(char, []))), :(char, [])).
funct(tkShowCoords, 1, 1, ->(:(','(int, itn), []), :(char, [])), :(char, [])).
funct(tkLabel2Refname, 1, 1, ->(:(char, []), :(char, [])), :(char, [])).
funct(aux, 1, 1, ->(char, char), char).
funct(tkRefname2Label, 1, 1, ->(:(char, []), :(char, [])), :(char, [])).
funct(aux1, 1, 1, ->(char, char), char).
funct(tks2tcl, 4, 4, ->(channel, ->(:(char, []), ->('$num'(int), ->(:(tkWidget(_A), []), ','(:(char, []), :(->(','(:(char, []), channel), _A), [])))))), ','(:(char, []), :(->(','(:(char, []), channel), _A), []))).
funct(tkslabels, 3, 3, ->(:(char, []), ->('$num'(int), ->(:(tkWidget(_A), []), :(char, [])))), :(char, [])).
funct(tkmain2tcl, 2, 2, ->(channel, ->(tkWidget(_A), ','(:(char, []), :(->(','(:(char, []), channel), _A), [])))), ','(:(char, []), :(->(','(:(char, []), channel), _A), []))).
funct(runWidget, 2, 2, ->(:(char, []), ->(tkWidget(io(unit)), io(unit))), io(unit)).
funct(aux4, 1, 1, ->(_A, io(unit)), io(unit)).
funct(runWidgetInit, 3, 3, ->(:(char, []), ->(tkWidget(io(unit)), ->(->(channel, io(unit)), io(unit)))), io(unit)).
funct(runWidgetPassive, 2, 2, ->(:(char, []), ->(tkWidget(_A), io(channel))), io(channel)).
funct(forkWish, 2, 2, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(initSchedule, 5, 5, ->(->(_A, ->(_A, _A)), ->(_A, ->(tkWidget(_A), ->(channel, ->(->(channel, _A), _A))))), _A).
funct(tkSchedule, 4, 4, ->(->(_A, ->(_A, _A)), ->(_A, ->(:(->(','(:(char, []), channel), _A), []), ->(channel, _A)))), _A).
funct(aux2, 5, 5, ->(->(_A, ->(_A, _A)), ->(_A, ->(:(->(','(:(char, []), channel), _A), []), ->(channel, ->(:(char, []), _A))))), _A).
funct(tkTerminateWish, 2, 2, ->(_A, ->(channel, _A)), _A).
funct(tkSelectEvent, 4, 4, ->(_A, ->(:(char, []), ->(:(->(','(:(char, []), channel), _A), []), ->(channel, _A)))), _A).
funct(tkGetVar, 3, 3, ->(:(char, []), ->(channel, ->(:(char, []), io(unit)))), io(unit)).
funct(tkGetVarMsg, 3, 3, ->(:(char, []), ->(channel, ->(:(char, []), io(unit)))), io(unit)).
funct(aux3, 4, 4, ->(:(char, []), ->(channel, ->(:(char, []), ->(:(char, []), io(unit))))), io(unit)).
funct(tkGetVarValue, 3, 3, ->('$num'(int), ->(:(char, []), ->(channel, io(:(char, []))))), io(:(char, []))).
funct(tkParseInt, 2, 2, ->(:(char, []), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(checkWishConsistency, 2, 2, ->(channel, ->(channel, bool)), bool).
funct(escape_tcl, 1, 1, ->(:(char, []), :(char, [])), :(char, [])).
funct(tkVoid, 1, 1, ->(channel, io(unit)), io(unit)).
funct(tkExit, 1, 1, ->(channel, io(unit)), io(unit)).
funct(tkGetValue, 2, 2, ->(tkRefType, ->(channel, io(:(char, [])))), io(:(char, []))).
funct(tkSetValue, 3, 3, ->(tkRefType, ->(:(char, []), ->(channel, io(unit)))), io(unit)).
funct(tkUpdate, 3, 3, ->(->(:(char, []), :(char, [])), ->(tkRefType, ->(channel, io(unit)))), io(unit)).
funct(tkConfig, 3, 3, ->(tkRefType, ->(tkConfItem(_A), ->(channel, io(unit)))), io(unit)).
funct(tkFocus, 2, 2, ->(tkRefType, ->(channel, io(unit))), io(unit)).
funct(tkAddCanvas, 3, 3, ->(tkRefType, ->(:(tkCanvasItem, []), ->(channel, io(unit)))), io(unit)).


hnf_susp('$openWish', '.'(_A, []), _B, _C, _D):-
        '$openWish'(_A, _B, _C, _D).
hnf_susp('$readWish', '.'(_A, []), _B, _C, _D):-
        '$readWish'(_A, _B, _C, _D).
hnf_susp('$writeWish', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeWish'(_A, _B, _C, _D, _E).
hnf_susp('$closeWish', '.'(_A, []), _B, _C, _D):-
        '$closeWish'(_A, _B, _C, _D).
hnf_susp('$strToint', '.'(_A, []), _B, _C, _D):-
        '$strToint'(_A, _B, _C, _D).
hnf_susp('$getNumber', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$getNumber'(_A, _B, _C, _D, _E).
hnf_susp('$intTostr', '.'(_A, []), _B, _C, _D):-
        '$intTostr'(_A, _B, _C, _D).
hnf_susp('$getString', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$getString'(_A, _B, _C, _D, _E).
hnf_susp('$tkShowErrors', [], _A, _B, _C):-
        '$tkShowErrors'(_A, _B, _C).
hnf_susp('$tkRef2Label', '.'(_A, []), _B, _C, _D):-
        '$tkRef2Label'(_A, _B, _C, _D).
hnf_susp('$tkRef2Wtype', '.'(_A, []), _B, _C, _D):-
        '$tkRef2Wtype'(_A, _B, _C, _D).
hnf_susp('$tk2tcl', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tk2tcl'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkConfCollection2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkConfCollection2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$tkConf2tcl', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkConf2tcl'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$setlistelems', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$setlistelems'(_A, _B, _C, _D, _E).
hnf_susp('$tkMenu2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkMenu2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$setmenuelems', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$setmenuelems'(_A, _B, _C, _D, _E).
hnf_susp('$tkConfs2handler', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkConfs2handler'(_A, _B, _C, _D, _E).
hnf_susp('$tkMenu2handler', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkMenu2handler'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkConfs2tcl', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkConfs2tcl'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkcitems2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkcitems2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$tkcitem', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkcitem'(_A, _B, _C, _D, _E).
hnf_susp('$tkShowCoords', '.'(_A, []), _B, _C, _D):-
        '$tkShowCoords'(_A, _B, _C, _D).
hnf_susp('$tkLabel2Refname', '.'(_A, []), _B, _C, _D):-
        '$tkLabel2Refname'(_A, _B, _C, _D).
hnf_susp('$aux', '.'(_A, []), _B, _C, _D):-
        '$aux'(_A, _B, _C, _D).
hnf_susp('$tkRefname2Label', '.'(_A, []), _B, _C, _D):-
        '$tkRefname2Label'(_A, _B, _C, _D).
hnf_susp('$aux1', '.'(_A, []), _B, _C, _D):-
        '$aux1'(_A, _B, _C, _D).
hnf_susp('$tks2tcl', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tks2tcl'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkslabels', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkslabels'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkmain2tcl', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkmain2tcl'(_A, _B, _C, _D, _E).
hnf_susp('$runWidget', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$runWidget'(_A, _B, _C, _D, _E).
hnf_susp('$aux4', '.'(_A, []), _B, _C, _D):-
        '$aux4'(_A, _B, _C, _D).
hnf_susp('$runWidgetInit', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$runWidgetInit'(_A, _B, _C, _D, _E, _F).
hnf_susp('$runWidgetPassive', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$runWidgetPassive'(_A, _B, _C, _D, _E).
hnf_susp('$forkWish', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$forkWish'(_A, _B, _C, _D, _E).
hnf_susp('$initSchedule', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$initSchedule'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$tkSchedule', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkSchedule'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$aux2', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$aux2'(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp('$tkTerminateWish', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkTerminateWish'(_A, _B, _C, _D, _E).
hnf_susp('$tkSelectEvent', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$tkSelectEvent'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkGetVar', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkGetVar'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkGetVarMsg', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkGetVarMsg'(_A, _B, _C, _D, _E, _F).
hnf_susp('$aux3', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$aux3'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$tkGetVarValue', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkGetVarValue'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkParseInt', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkParseInt'(_A, _B, _C, _D, _E).
hnf_susp('$checkWishConsistency', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$checkWishConsistency'(_A, _B, _C, _D, _E).
hnf_susp('$escape_tcl', '.'(_A, []), _B, _C, _D):-
        '$escape_tcl'(_A, _B, _C, _D).
hnf_susp('$tkVoid', '.'(_A, []), _B, _C, _D):-
        '$tkVoid'(_A, _B, _C, _D).
hnf_susp('$tkExit', '.'(_A, []), _B, _C, _D):-
        '$tkExit'(_A, _B, _C, _D).
hnf_susp('$tkGetValue', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkGetValue'(_A, _B, _C, _D, _E).
hnf_susp('$tkSetValue', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkSetValue'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkUpdate', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkUpdate'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkConfig', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkConfig'(_A, _B, _C, _D, _E, _F).
hnf_susp('$tkFocus', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$tkFocus'(_A, _B, _C, _D, _E).
hnf_susp('$tkAddCanvas', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$tkAddCanvas'(_A, _B, _C, _D, _E, _F).



'$$apply_1'(tkButton, _A, tkButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkButton(_B), _C, _D):-
        unifyHnfs(_A, tkButton, _C, _D).

'$$apply_1'(tkButton(_A), _B, tkButton(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkButton(_C, _B), _D, _E):-
        unifyHnfs(_A, tkButton(_C), _D, _E).

'$$apply_1'(tkCanvas, _A, tkCanvas(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCanvas(_B), _C, _D):-
        unifyHnfs(_A, tkCanvas, _C, _D).

'$$apply_1'(tkCheckButton, _A, tkCheckButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCheckButton(_B), _C, _D):-
        unifyHnfs(_A, tkCheckButton, _C, _D).

'$$apply_1'(tkEntry, _A, tkEntry(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkEntry(_B), _C, _D):-
        unifyHnfs(_A, tkEntry, _C, _D).

'$$apply_1'(tkLabel, _A, tkLabel(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkLabel(_B), _C, _D):-
        unifyHnfs(_A, tkLabel, _C, _D).

'$$apply_1'(tkListBox, _A, tkListBox(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkListBox(_B), _C, _D):-
        unifyHnfs(_A, tkListBox, _C, _D).

'$$apply_1'(tkMessage, _A, tkMessage(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMessage(_B), _C, _D):-
        unifyHnfs(_A, tkMessage, _C, _D).

'$$apply_1'(tkMenuButton, _A, tkMenuButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenuButton(_B), _C, _D):-
        unifyHnfs(_A, tkMenuButton, _C, _D).

'$$apply_1'(tkScale, _A, tkScale(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkScale(_B), _C, _D):-
        unifyHnfs(_A, tkScale, _C, _D).

'$$apply_1'(tkScale(_A), _B, tkScale(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkScale(_C, _B), _D, _E):-
        unifyHnfs(_A, tkScale(_C), _D, _E).

'$$apply_1'(tkScale(_A, _B), _C, tkScale(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkScale(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkScale(_C, _D), _E, _F).

'$$apply_1'(tkScrollV, _A, tkScrollV(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkScrollV(_B), _C, _D):-
        unifyHnfs(_A, tkScrollV, _C, _D).

'$$apply_1'(tkScrollV(_A), _B, tkScrollV(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkScrollV(_C, _B), _D, _E):-
        unifyHnfs(_A, tkScrollV(_C), _D, _E).

'$$apply_1'(tkScrollH, _A, tkScrollH(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkScrollH(_B), _C, _D):-
        unifyHnfs(_A, tkScrollH, _C, _D).

'$$apply_1'(tkScrollH(_A), _B, tkScrollH(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkScrollH(_C, _B), _D, _E):-
        unifyHnfs(_A, tkScrollH(_C), _D, _E).

'$$apply_1'(tkTextEdit, _A, tkTextEdit(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkTextEdit(_B), _C, _D):-
        unifyHnfs(_A, tkTextEdit, _C, _D).

'$$apply_1'(tkRow, _A, tkRow(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRow(_B), _C, _D):-
        unifyHnfs(_A, tkRow, _C, _D).

'$$apply_1'(tkRow(_A), _B, tkRow(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkRow(_C, _B), _D, _E):-
        unifyHnfs(_A, tkRow(_C), _D, _E).

'$$apply_1'(tkCol, _A, tkCol(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCol(_B), _C, _D):-
        unifyHnfs(_A, tkCol, _C, _D).

'$$apply_1'(tkCol(_A), _B, tkCol(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkCol(_C, _B), _D, _E):-
        unifyHnfs(_A, tkCol(_C), _D, _E).

'$$apply_1'(tkActive, _A, tkActive(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkActive(_B), _C, _D):-
        unifyHnfs(_A, tkActive, _C, _D).

'$$apply_1'(tkAnchor, _A, tkAnchor(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkAnchor(_B), _C, _D):-
        unifyHnfs(_A, tkAnchor, _C, _D).

'$$apply_1'(tkBackground, _A, tkBackground(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkBackground(_B), _C, _D):-
        unifyHnfs(_A, tkBackground, _C, _D).

'$$apply_1'(tkCmd, _A, tkCmd(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkCmd(_B), _C, _D):-
        unifyHnfs(_A, tkCmd, _C, _D).

'$$apply_1'(tkHeight, _A, tkHeight(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkHeight(_B), _C, _D):-
        unifyHnfs(_A, tkHeight, _C, _D).

'$$apply_1'(tkInit, _A, tkInit(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkInit(_B), _C, _D):-
        unifyHnfs(_A, tkInit, _C, _D).

'$$apply_1'(tkItems, _A, tkItems(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkItems(_B), _C, _D):-
        unifyHnfs(_A, tkItems, _C, _D).

'$$apply_1'(tkList, _A, tkList(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkList(_B), _C, _D):-
        unifyHnfs(_A, tkList, _C, _D).

'$$apply_1'(tkMenu, _A, tkMenu(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenu(_B), _C, _D):-
        unifyHnfs(_A, tkMenu, _C, _D).

'$$apply_1'(tkRef, _A, tkRef(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRef(_B), _C, _D):-
        unifyHnfs(_A, tkRef, _C, _D).

'$$apply_1'(tkText, _A, tkText(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkText(_B), _C, _D):-
        unifyHnfs(_A, tkText, _C, _D).

'$$apply_1'(tkWidth, _A, tkWidth(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkWidth(_B), _C, _D):-
        unifyHnfs(_A, tkWidth, _C, _D).

'$$apply_1'(tkTcl, _A, tkTcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkTcl(_B), _C, _D):-
        unifyHnfs(_A, tkTcl, _C, _D).

'$$apply_1'(tkMButton, _A, tkMButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMButton(_B), _C, _D):-
        unifyHnfs(_A, tkMButton, _C, _D).

'$$apply_1'(tkMButton(_A), _B, tkMButton(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkMButton(_C, _B), _D, _E):-
        unifyHnfs(_A, tkMButton(_C), _D, _E).

'$$apply_1'(tkMMenuButton, _A, tkMMenuButton(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMMenuButton(_B), _C, _D):-
        unifyHnfs(_A, tkMMenuButton, _C, _D).

'$$apply_1'(tkMMenuButton(_A), _B, tkMMenuButton(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkMMenuButton(_C, _B), _D, _E):-
        unifyHnfs(_A, tkMMenuButton(_C), _D, _E).

'$$apply_1'(tkLine, _A, tkLine(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkLine(_B), _C, _D):-
        unifyHnfs(_A, tkLine, _C, _D).

'$$apply_1'(tkLine(_A), _B, tkLine(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkLine(_C, _B), _D, _E):-
        unifyHnfs(_A, tkLine(_C), _D, _E).

'$$apply_1'(tkPolygon, _A, tkPolygon(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkPolygon(_B), _C, _D):-
        unifyHnfs(_A, tkPolygon, _C, _D).

'$$apply_1'(tkPolygon(_A), _B, tkPolygon(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkPolygon(_C, _B), _D, _E):-
        unifyHnfs(_A, tkPolygon(_C), _D, _E).

'$$apply_1'(tkRectangle, _A, tkRectangle(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRectangle(_B), _C, _D):-
        unifyHnfs(_A, tkRectangle, _C, _D).

'$$apply_1'(tkRectangle(_A), _B, tkRectangle(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkRectangle(_C, _B), _D, _E):-
        unifyHnfs(_A, tkRectangle(_C), _D, _E).

'$$apply_1'(tkRectangle(_A, _B), _C, tkRectangle(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkRectangle(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkRectangle(_C, _D), _E, _F).

'$$apply_1'(tkOval, _A, tkOval(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkOval(_B), _C, _D):-
        unifyHnfs(_A, tkOval, _C, _D).

'$$apply_1'(tkOval(_A), _B, tkOval(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkOval(_C, _B), _D, _E):-
        unifyHnfs(_A, tkOval(_C), _D, _E).

'$$apply_1'(tkOval(_A, _B), _C, tkOval(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkOval(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkOval(_C, _D), _E, _F).

'$$apply_1'(tkRefLabel, _A, tkRefLabel(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkRefLabel(_B), _C, _D):-
        unifyHnfs(_A, tkRefLabel, _C, _D).

'$$apply_1'(tkRefLabel(_A), _B, tkRefLabel(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkRefLabel(_C, _B), _D, _E):-
        unifyHnfs(_A, tkRefLabel(_C), _D, _E).

'$$apply_1'(tkRefLabel(_A, _B), _C, tkRefLabel(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkRefLabel(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkRefLabel(_C, _D), _E, _F).


% parcial aplictions of prims

'$$apply_1'(writeWish, _A, writeWish(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeWish(_B), _C, _D):-
        unifyHnfs(_A, writeWish, _C, _D).

'$$apply_1'(getNumber, _A, getNumber(_A), _B, _B).
'$$apply_1_var'(_A, _B, getNumber(_B), _C, _D):-
        unifyHnfs(_A, getNumber, _C, _D).

'$$apply_1'(getString, _A, getString(_A), _B, _B).
'$$apply_1_var'(_A, _B, getString(_B), _C, _D):-
        unifyHnfs(_A, getString, _C, _D).

'$$apply_1'(tk2tcl, _A, tk2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tk2tcl(_B), _C, _D):-
        unifyHnfs(_A, tk2tcl, _C, _D).

'$$apply_1'(tk2tcl(_A), _B, tk2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tk2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tk2tcl(_C), _D, _E).

'$$apply_1'(tkConfCollection2tcl, _A, tkConfCollection2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfCollection2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkConfCollection2tcl, _C, _D).

'$$apply_1'(tkConf2tcl, _A, tkConf2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConf2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkConf2tcl, _C, _D).

'$$apply_1'(tkConf2tcl(_A), _B, tkConf2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkConf2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tkConf2tcl(_C), _D, _E).

'$$apply_1'(tkConf2tcl(_A, _B), _C, tkConf2tcl(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkConf2tcl(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkConf2tcl(_C, _D), _E, _F).

'$$apply_1'(setlistelems, _A, setlistelems(_A), _B, _B).
'$$apply_1_var'(_A, _B, setlistelems(_B), _C, _D):-
        unifyHnfs(_A, setlistelems, _C, _D).

'$$apply_1'(tkMenu2tcl, _A, tkMenu2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenu2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkMenu2tcl, _C, _D).

'$$apply_1'(setmenuelems, _A, setmenuelems(_A), _B, _B).
'$$apply_1_var'(_A, _B, setmenuelems(_B), _C, _D):-
        unifyHnfs(_A, setmenuelems, _C, _D).

'$$apply_1'(tkConfs2handler, _A, tkConfs2handler(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfs2handler(_B), _C, _D):-
        unifyHnfs(_A, tkConfs2handler, _C, _D).

'$$apply_1'(tkMenu2handler, _A, tkMenu2handler(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkMenu2handler(_B), _C, _D):-
        unifyHnfs(_A, tkMenu2handler, _C, _D).

'$$apply_1'(tkMenu2handler(_A), _B, tkMenu2handler(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkMenu2handler(_C, _B), _D, _E):-
        unifyHnfs(_A, tkMenu2handler(_C), _D, _E).

'$$apply_1'(tkConfs2tcl, _A, tkConfs2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfs2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkConfs2tcl, _C, _D).

'$$apply_1'(tkConfs2tcl(_A), _B, tkConfs2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkConfs2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tkConfs2tcl(_C), _D, _E).

'$$apply_1'(tkConfs2tcl(_A, _B), _C, tkConfs2tcl(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkConfs2tcl(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkConfs2tcl(_C, _D), _E, _F).

'$$apply_1'(tkcitems2tcl, _A, tkcitems2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkcitems2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkcitems2tcl, _C, _D).

'$$apply_1'(tkcitem, _A, tkcitem(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkcitem(_B), _C, _D):-
        unifyHnfs(_A, tkcitem, _C, _D).

'$$apply_1'(tks2tcl, _A, tks2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tks2tcl(_B), _C, _D):-
        unifyHnfs(_A, tks2tcl, _C, _D).

'$$apply_1'(tks2tcl(_A), _B, tks2tcl(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tks2tcl(_C, _B), _D, _E):-
        unifyHnfs(_A, tks2tcl(_C), _D, _E).

'$$apply_1'(tks2tcl(_A, _B), _C, tks2tcl(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tks2tcl(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tks2tcl(_C, _D), _E, _F).

'$$apply_1'(tkslabels, _A, tkslabels(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkslabels(_B), _C, _D):-
        unifyHnfs(_A, tkslabels, _C, _D).

'$$apply_1'(tkslabels(_A), _B, tkslabels(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkslabels(_C, _B), _D, _E):-
        unifyHnfs(_A, tkslabels(_C), _D, _E).

'$$apply_1'(tkmain2tcl, _A, tkmain2tcl(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkmain2tcl(_B), _C, _D):-
        unifyHnfs(_A, tkmain2tcl, _C, _D).

'$$apply_1'(runWidget, _A, runWidget(_A), _B, _B).
'$$apply_1_var'(_A, _B, runWidget(_B), _C, _D):-
        unifyHnfs(_A, runWidget, _C, _D).

'$$apply_1'(runWidgetInit, _A, runWidgetInit(_A), _B, _B).
'$$apply_1_var'(_A, _B, runWidgetInit(_B), _C, _D):-
        unifyHnfs(_A, runWidgetInit, _C, _D).

'$$apply_1'(runWidgetInit(_A), _B, runWidgetInit(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, runWidgetInit(_C, _B), _D, _E):-
        unifyHnfs(_A, runWidgetInit(_C), _D, _E).

'$$apply_1'(runWidgetPassive, _A, runWidgetPassive(_A), _B, _B).
'$$apply_1_var'(_A, _B, runWidgetPassive(_B), _C, _D):-
        unifyHnfs(_A, runWidgetPassive, _C, _D).

'$$apply_1'(forkWish, _A, forkWish(_A), _B, _B).
'$$apply_1_var'(_A, _B, forkWish(_B), _C, _D):-
        unifyHnfs(_A, forkWish, _C, _D).

'$$apply_1'(initSchedule, _A, initSchedule(_A), _B, _B).
'$$apply_1_var'(_A, _B, initSchedule(_B), _C, _D):-
        unifyHnfs(_A, initSchedule, _C, _D).

'$$apply_1'(initSchedule(_A), _B, initSchedule(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, initSchedule(_C, _B), _D, _E):-
        unifyHnfs(_A, initSchedule(_C), _D, _E).

'$$apply_1'(initSchedule(_A, _B), _C, initSchedule(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, initSchedule(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, initSchedule(_C, _D), _E, _F).

'$$apply_1'(initSchedule(_A, _B, _C), _D, initSchedule(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, initSchedule(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, initSchedule(_C, _D, _E), _F, _G).

'$$apply_1'(tkSchedule, _A, tkSchedule(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkSchedule(_B), _C, _D):-
        unifyHnfs(_A, tkSchedule, _C, _D).

'$$apply_1'(tkSchedule(_A), _B, tkSchedule(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkSchedule(_C, _B), _D, _E):-
        unifyHnfs(_A, tkSchedule(_C), _D, _E).

'$$apply_1'(tkSchedule(_A, _B), _C, tkSchedule(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkSchedule(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkSchedule(_C, _D), _E, _F).

'$$apply_1'(aux2, _A, aux2(_A), _B, _B).
'$$apply_1_var'(_A, _B, aux2(_B), _C, _D):-
        unifyHnfs(_A, aux2, _C, _D).

'$$apply_1'(aux2(_A), _B, aux2(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, aux2(_C, _B), _D, _E):-
        unifyHnfs(_A, aux2(_C), _D, _E).

'$$apply_1'(aux2(_A, _B), _C, aux2(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, aux2(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, aux2(_C, _D), _E, _F).

'$$apply_1'(aux2(_A, _B, _C), _D, aux2(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, aux2(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, aux2(_C, _D, _E), _F, _G).

'$$apply_1'(tkTerminateWish, _A, tkTerminateWish(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkTerminateWish(_B), _C, _D):-
        unifyHnfs(_A, tkTerminateWish, _C, _D).

'$$apply_1'(tkSelectEvent, _A, tkSelectEvent(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkSelectEvent(_B), _C, _D):-
        unifyHnfs(_A, tkSelectEvent, _C, _D).

'$$apply_1'(tkSelectEvent(_A), _B, tkSelectEvent(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkSelectEvent(_C, _B), _D, _E):-
        unifyHnfs(_A, tkSelectEvent(_C), _D, _E).

'$$apply_1'(tkSelectEvent(_A, _B), _C, tkSelectEvent(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, tkSelectEvent(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, tkSelectEvent(_C, _D), _E, _F).

'$$apply_1'(tkGetVar, _A, tkGetVar(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetVar(_B), _C, _D):-
        unifyHnfs(_A, tkGetVar, _C, _D).

'$$apply_1'(tkGetVar(_A), _B, tkGetVar(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkGetVar(_C, _B), _D, _E):-
        unifyHnfs(_A, tkGetVar(_C), _D, _E).

'$$apply_1'(tkGetVarMsg, _A, tkGetVarMsg(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetVarMsg(_B), _C, _D):-
        unifyHnfs(_A, tkGetVarMsg, _C, _D).

'$$apply_1'(tkGetVarMsg(_A), _B, tkGetVarMsg(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkGetVarMsg(_C, _B), _D, _E):-
        unifyHnfs(_A, tkGetVarMsg(_C), _D, _E).

'$$apply_1'(aux3, _A, aux3(_A), _B, _B).
'$$apply_1_var'(_A, _B, aux3(_B), _C, _D):-
        unifyHnfs(_A, aux3, _C, _D).

'$$apply_1'(aux3(_A), _B, aux3(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, aux3(_C, _B), _D, _E):-
        unifyHnfs(_A, aux3(_C), _D, _E).

'$$apply_1'(aux3(_A, _B), _C, aux3(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, aux3(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, aux3(_C, _D), _E, _F).

'$$apply_1'(tkGetVarValue, _A, tkGetVarValue(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetVarValue(_B), _C, _D):-
        unifyHnfs(_A, tkGetVarValue, _C, _D).

'$$apply_1'(tkGetVarValue(_A), _B, tkGetVarValue(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkGetVarValue(_C, _B), _D, _E):-
        unifyHnfs(_A, tkGetVarValue(_C), _D, _E).

'$$apply_1'(tkParseInt, _A, tkParseInt(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkParseInt(_B), _C, _D):-
        unifyHnfs(_A, tkParseInt, _C, _D).

'$$apply_1'(checkWishConsistency, _A, checkWishConsistency(_A), _B, _B).
'$$apply_1_var'(_A, _B, checkWishConsistency(_B), _C, _D):-
        unifyHnfs(_A, checkWishConsistency, _C, _D).

'$$apply_1'(tkGetValue, _A, tkGetValue(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkGetValue(_B), _C, _D):-
        unifyHnfs(_A, tkGetValue, _C, _D).

'$$apply_1'(tkSetValue, _A, tkSetValue(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkSetValue(_B), _C, _D):-
        unifyHnfs(_A, tkSetValue, _C, _D).

'$$apply_1'(tkSetValue(_A), _B, tkSetValue(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkSetValue(_C, _B), _D, _E):-
        unifyHnfs(_A, tkSetValue(_C), _D, _E).

'$$apply_1'(tkUpdate, _A, tkUpdate(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkUpdate(_B), _C, _D):-
        unifyHnfs(_A, tkUpdate, _C, _D).

'$$apply_1'(tkUpdate(_A), _B, tkUpdate(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkUpdate(_C, _B), _D, _E):-
        unifyHnfs(_A, tkUpdate(_C), _D, _E).

'$$apply_1'(tkConfig, _A, tkConfig(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkConfig(_B), _C, _D):-
        unifyHnfs(_A, tkConfig, _C, _D).

'$$apply_1'(tkConfig(_A), _B, tkConfig(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkConfig(_C, _B), _D, _E):-
        unifyHnfs(_A, tkConfig(_C), _D, _E).

'$$apply_1'(tkFocus, _A, tkFocus(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkFocus(_B), _C, _D):-
        unifyHnfs(_A, tkFocus, _C, _D).

'$$apply_1'(tkAddCanvas, _A, tkAddCanvas(_A), _B, _B).
'$$apply_1_var'(_A, _B, tkAddCanvas(_B), _C, _D):-
        unifyHnfs(_A, tkAddCanvas, _C, _D).

'$$apply_1'(tkAddCanvas(_A), _B, tkAddCanvas(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, tkAddCanvas(_C, _B), _D, _E):-
        unifyHnfs(_A, tkAddCanvas(_C), _D, _E).


'$$apply_1'(openWish, _A, _B, _C, _D):-
        '$openWish'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, openWish, _D, _F),
        '$openWish'(_B, _C, _F, _E).

'$$apply_1'(readWish, _A, _B, _C, _D):-
        '$readWish'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readWish, _D, _F),
        '$readWish'(_B, _C, _F, _E).

'$$apply_1'(writeWish(_A), _B, _C, _D, _E):-
        '$writeWish'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeWish(_F), _D, _G),
        '$writeWish'(_F, _B, _C, _G, _E).

'$$apply_1'(closeWish, _A, _B, _C, _D):-
        '$closeWish'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, closeWish, _D, _F),
        '$closeWish'(_B, _C, _F, _E).

'$$apply_1'(strToint, _A, _B, _C, _D):-
        '$strToint'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, strToint, _D, _F),
        '$strToint'(_B, _C, _F, _E).

'$$apply_1'(getNumber(_A), _B, _C, _D, _E):-
        '$getNumber'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getNumber(_F), _D, _G),
        '$getNumber'(_F, _B, _C, _G, _E).

'$$apply_1'(intTostr, _A, _B, _C, _D):-
        '$intTostr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, intTostr, _D, _F),
        '$intTostr'(_B, _C, _F, _E).

'$$apply_1'(getString(_A), _B, _C, _D, _E):-
        '$getString'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getString(_F), _D, _G),
        '$getString'(_F, _B, _C, _G, _E).


'$$apply_1'(tkRef2Label, _A, _B, _C, _D):-
        '$tkRef2Label'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkRef2Label, _D, _F),
        '$tkRef2Label'(_B, _C, _F, _E).

'$$apply_1'(tkRef2Wtype, _A, _B, _C, _D):-
        '$tkRef2Wtype'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkRef2Wtype, _D, _F),
        '$tkRef2Wtype'(_B, _C, _F, _E).

'$$apply_1'(tk2tcl(_A, _B), _C, _D, _E, _F):-
        '$tk2tcl'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tk2tcl(_F, _G), _D, _H),
        '$tk2tcl'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkConfCollection2tcl(_A), _B, _C, _D, _E):-
        '$tkConfCollection2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfCollection2tcl(_F), _D, _G),
        '$tkConfCollection2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(tkConf2tcl(_A, _B, _C), _D, _E, _F, _G):-
        '$tkConf2tcl'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConf2tcl(_F, _G, _H), _D, _I),
        '$tkConf2tcl'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(setlistelems(_A), _B, _C, _D, _E):-
        '$setlistelems'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, setlistelems(_F), _D, _G),
        '$setlistelems'(_F, _B, _C, _G, _E).

'$$apply_1'(tkMenu2tcl(_A), _B, _C, _D, _E):-
        '$tkMenu2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkMenu2tcl(_F), _D, _G),
        '$tkMenu2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(setmenuelems(_A), _B, _C, _D, _E):-
        '$setmenuelems'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, setmenuelems(_F), _D, _G),
        '$setmenuelems'(_F, _B, _C, _G, _E).

'$$apply_1'(tkConfs2handler(_A), _B, _C, _D, _E):-
        '$tkConfs2handler'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfs2handler(_F), _D, _G),
        '$tkConfs2handler'(_F, _B, _C, _G, _E).

'$$apply_1'(tkMenu2handler(_A, _B), _C, _D, _E, _F):-
        '$tkMenu2handler'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkMenu2handler(_F, _G), _D, _H),
        '$tkMenu2handler'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkConfs2tcl(_A, _B, _C), _D, _E, _F, _G):-
        '$tkConfs2tcl'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfs2tcl(_F, _G, _H), _D, _I),
        '$tkConfs2tcl'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkcitems2tcl(_A), _B, _C, _D, _E):-
        '$tkcitems2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkcitems2tcl(_F), _D, _G),
        '$tkcitems2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(tkcitem(_A), _B, _C, _D, _E):-
        '$tkcitem'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkcitem(_F), _D, _G),
        '$tkcitem'(_F, _B, _C, _G, _E).

'$$apply_1'(tkShowCoords, _A, _B, _C, _D):-
        '$tkShowCoords'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkShowCoords, _D, _F),
        '$tkShowCoords'(_B, _C, _F, _E).

'$$apply_1'(tkLabel2Refname, _A, _B, _C, _D):-
        '$tkLabel2Refname'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkLabel2Refname, _D, _F),
        '$tkLabel2Refname'(_B, _C, _F, _E).

'$$apply_1'(aux, _A, _B, _C, _D):-
        '$aux'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux, _D, _F),
        '$aux'(_B, _C, _F, _E).

'$$apply_1'(tkRefname2Label, _A, _B, _C, _D):-
        '$tkRefname2Label'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkRefname2Label, _D, _F),
        '$tkRefname2Label'(_B, _C, _F, _E).

'$$apply_1'(aux1, _A, _B, _C, _D):-
        '$aux1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux1, _D, _F),
        '$aux1'(_B, _C, _F, _E).

'$$apply_1'(tks2tcl(_A, _B, _C), _D, _E, _F, _G):-
        '$tks2tcl'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tks2tcl(_F, _G, _H), _D, _I),
        '$tks2tcl'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkslabels(_A, _B), _C, _D, _E, _F):-
        '$tkslabels'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkslabels(_F, _G), _D, _H),
        '$tkslabels'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkmain2tcl(_A), _B, _C, _D, _E):-
        '$tkmain2tcl'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkmain2tcl(_F), _D, _G),
        '$tkmain2tcl'(_F, _B, _C, _G, _E).

'$$apply_1'(runWidget(_A), _B, _C, _D, _E):-
        '$runWidget'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, runWidget(_F), _D, _G),
        '$runWidget'(_F, _B, _C, _G, _E).

'$$apply_1'(aux4, _A, _B, _C, _D):-
        '$aux4'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux4, _D, _F),
        '$aux4'(_B, _C, _F, _E).

'$$apply_1'(runWidgetInit(_A, _B), _C, _D, _E, _F):-
        '$runWidgetInit'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, runWidgetInit(_F, _G), _D, _H),
        '$runWidgetInit'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(runWidgetPassive(_A), _B, _C, _D, _E):-
        '$runWidgetPassive'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, runWidgetPassive(_F), _D, _G),
        '$runWidgetPassive'(_F, _B, _C, _G, _E).

'$$apply_1'(forkWish(_A), _B, _C, _D, _E):-
        '$forkWish'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, forkWish(_F), _D, _G),
        '$forkWish'(_F, _B, _C, _G, _E).

'$$apply_1'(initSchedule(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$initSchedule'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, initSchedule(_F, _G, _H, _I), _D, _J),
        '$initSchedule'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(tkSchedule(_A, _B, _C), _D, _E, _F, _G):-
        '$tkSchedule'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkSchedule(_F, _G, _H), _D, _I),
        '$tkSchedule'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(aux2(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$aux2'(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux2(_F, _G, _H, _I), _D, _J),
        '$aux2'(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(tkTerminateWish(_A), _B, _C, _D, _E):-
        '$tkTerminateWish'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkTerminateWish(_F), _D, _G),
        '$tkTerminateWish'(_F, _B, _C, _G, _E).

'$$apply_1'(tkSelectEvent(_A, _B, _C), _D, _E, _F, _G):-
        '$tkSelectEvent'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkSelectEvent(_F, _G, _H), _D, _I),
        '$tkSelectEvent'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkGetVar(_A, _B), _C, _D, _E, _F):-
        '$tkGetVar'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetVar(_F, _G), _D, _H),
        '$tkGetVar'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkGetVarMsg(_A, _B), _C, _D, _E, _F):-
        '$tkGetVarMsg'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetVarMsg(_F, _G), _D, _H),
        '$tkGetVarMsg'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(aux3(_A, _B, _C), _D, _E, _F, _G):-
        '$aux3'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, aux3(_F, _G, _H), _D, _I),
        '$aux3'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(tkGetVarValue(_A, _B), _C, _D, _E, _F):-
        '$tkGetVarValue'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetVarValue(_F, _G), _D, _H),
        '$tkGetVarValue'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkParseInt(_A), _B, _C, _D, _E):-
        '$tkParseInt'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkParseInt(_F), _D, _G),
        '$tkParseInt'(_F, _B, _C, _G, _E).

'$$apply_1'(checkWishConsistency(_A), _B, _C, _D, _E):-
        '$checkWishConsistency'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, checkWishConsistency(_F), _D, _G),
        '$checkWishConsistency'(_F, _B, _C, _G, _E).

'$$apply_1'(escape_tcl, _A, _B, _C, _D):-
        '$escape_tcl'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, escape_tcl, _D, _F),
        '$escape_tcl'(_B, _C, _F, _E).

'$$apply_1'(tkVoid, _A, _B, _C, _D):-
        '$tkVoid'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkVoid, _D, _F),
        '$tkVoid'(_B, _C, _F, _E).

'$$apply_1'(tkExit, _A, _B, _C, _D):-
        '$tkExit'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkExit, _D, _F),
        '$tkExit'(_B, _C, _F, _E).

'$$apply_1'(tkGetValue(_A), _B, _C, _D, _E):-
        '$tkGetValue'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkGetValue(_F), _D, _G),
        '$tkGetValue'(_F, _B, _C, _G, _E).

'$$apply_1'(tkSetValue(_A, _B), _C, _D, _E, _F):-
        '$tkSetValue'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkSetValue(_F, _G), _D, _H),
        '$tkSetValue'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkUpdate(_A, _B), _C, _D, _E, _F):-
        '$tkUpdate'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkUpdate(_F, _G), _D, _H),
        '$tkUpdate'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkConfig(_A, _B), _C, _D, _E, _F):-
        '$tkConfig'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkConfig(_F, _G), _D, _H),
        '$tkConfig'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(tkFocus(_A), _B, _C, _D, _E):-
        '$tkFocus'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkFocus(_F), _D, _G),
        '$tkFocus'(_F, _B, _C, _G, _E).

'$$apply_1'(tkAddCanvas(_A, _B), _C, _D, _E, _F):-
        '$tkAddCanvas'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tkAddCanvas(_F, _G), _D, _H),
        '$tkAddCanvas'(_F, _G, _B, _C, _H, _E).

