%%::B Optimization. 16/06/2006 Fernando        
funct(minimize, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(maximize, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(bb_minimize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).
funct(bb_maximize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).
%%::E   

%%::B Optimization. 16/06/2006 Fernando        
hnf_susp('$minimize', '.'(_A, []), _B, _C, _D):-
        '$minimize'(_A, _B, _C, _D).
hnf_susp('$maximize', '.'(_A, []), _B, _C, _D):-
        '$maximize'(_A, _B, _C, _D).
hnf_susp('$bb_minimize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$bb_minimize'(_A, _B, _C, _D, _E).
hnf_susp('$bb_maximize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$bb_maximize'(_A, _B, _C, _D, _E).
%%::E     

%%::B Optimization. 16/06/2006 Fernando        

'$$apply_1'(bb_minimize, _A, bb_minimize(_A), _B, _B).
'$$apply_1_var'(_A, _B, bb_minimize(_B), _C, _D):-
        unifyHnfs(_A, bb_minimize, _C, _D).

'$$apply_1'(bb_maximize, _A, bb_maximize(_A), _B, _B).
'$$apply_1_var'(_A, _B, bb_maximize(_B), _C, _D):-
        unifyHnfs(_A, bb_maximize, _C, _D).

'$$apply_1'(minimize, _A, _B, _C, _D):-
        '$minimize'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, minimize, _D, _F),
        '$minimize'(_B, _C, _F, _E).

'$$apply_1'(maximize, _A, _B, _C, _D):-
        '$maximize'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, maximize, _D, _F),
        '$maximize'(_B, _C, _F, _E).

'$$apply_1'(bb_minimize(_A), _B, _C, _D, _E):-
        '$bb_minimize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, bb_minimize(_F), _D, _G),
        '$bb_minimize'(_F, _B, _C, _G, _E).

'$$apply_1'(bb_maximize(_A), _B, _C, _D, _E):-
        '$bb_maximize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, bb_maximize(_F), _D, _G),
        '$bb_maximize'(_F, _B, _C, _G, _E).

%%::E     


