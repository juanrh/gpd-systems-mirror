

user:portray_message(warning,_):- write('').

:- module(plgenerated,[sourceFileNameStr/1,hnf_susp/5,constr/4,funct/5,infix/3,'$$apply'/5,'$flip'/6,'$init_fd' /3,'$write' /4,'$nl' /3,$#== /5,$#/== /5,'$domain' /6,'$subset' /5,'$inset' /5,'$setcomplement' /5,'$intersect' /5,'$belongs' /5,'$labeling' /5,'$indomain' /4,'$fdminimize' /5,'$fdmaximize' /5,$#= /5,$#\= /5,$#< /5,$#<= /5,$#> /5,$#>= /5,$#+ /5,$#- /5,$#* /5,$#/ /5,$#& /5,'$sum' /6,'$scalar_product' /7,'$all_different' /4,'$all_different\'' /5,'$assignment' /5,'$circuit' /4,'$circuit\'' /5,'$count' /7,'$element' /6,'$exactly' /6,'$serialized' /5,'$serialized\'' /6,'$cumulative' /7,'$cumulative\'' /8,$#\/ /5,$#<=> /5,$#=> /5,'$fd_var' /4,'$fd_min' /4,'$fd_max' /4,'$fd_size' /4,'$fd_set' /4,'$fd_dom' /4,'$fd_degree' /4,'$fd_neighbors' /4,'$fd_closure' /4,'$inf' /3,'$sup' /3,'$is_fdset' /4,'$empty_fdset' /4,'$fdset_parts' /6,'$fdset_split' /4,'$empty_interval' /5,'$fdset_to_interval' /4,'$interval_to_fdset' /5,'$fdset_singleton' /5,'$fdset_min' /4,'$fdset_max' /4,'$fdset_size' /4,'$list_to_fdset' /4,'$fdset_to_list' /4,'$range_to_fdset' /4,'$fdset_to_range' /4,'$fdset_add_element' /5,'$fdset_del_element' /5,'$fdset_intersection' /5,'$fdset_subtract' /5,'$fdset_union' /5,'$fdset_complement' /4,'$fdsets_intersection' /4,'$fdsets_union' /4,'$fdset_equal' /5,'$fdset_subset' /5,'$fdset_disjoint' /5,'$fdset_intersect' /5,'$fdset_member' /5,'$fdset_belongs' /5,'$isin' /5,'$minimum' /4,'$fd_statistics' /3,'$fd_statistics\'' /4,'$fd_global' /6,'$end_fd' /3,'$hasLength' /5,'$append' /5,'$golomb' /5,'$distances' /5,'$distancesB' /7]).

:- dynamic $== /5, $/= /5.

:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed)]).

:- tools:complete_root_filename(primFunct,F),load_files(F,[if(changed)]).

:- tools:complete_root_filename(primitivCodClpr,F),load_files(F,[if(changed)]).






:- use_module(library(clpfd)).

% nombre del fichero fuente
sourceFileNameStr('golomb').


/**************    CODE FOR FUNCTIONS    **************/


% init_f
% hasLength
'$hasLength'(_A, _B, true, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$hasLength_1'(_E, _B, true, _F, _D).
'$hasLength_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, [], _C, _E),
        hnf(_B, 0, _E, _F),
        equal(true, true, _F, _D).
'$hasLength_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        $#>(_B, 0, true, _G, _H),
        '$hasLength'(_F, '$$susp'( $#-, [ _B, 1 ], _I, _J ), true, _H, _D).

% append
'$append'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$append_1'(_F, _B, _C, _G, _E).
'$append_1'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, [], _D, _F),
        hnf(_B, _C, _F, _E).
'$append_1'(_A, _B, :(_C, _D), _E, _F):-
        unifyHnfs(_A, :(_C, _G), _E, _H),
        equalnf(_D, '$$susp'( '$append', [ _G, _B ], _I, _J ), _H, _F).

% golomb
'$golomb'(_A, _B, true, _C, _D):-
        '$hasLength'(_B, _A, true, _C, _E),
        equal(_F, '$$susp'( $-, [ '$$susp'( '$trunc', [ '$$susp'( $^, [ 2, '$$susp'( $-, [ _A, 1 ], _G, _H ) ], _I, _J ) ], _K, _L ), 1 ], _M, _N ), _E, _O),
        '$domain'(_B, 0, _F, true, _O, _P),
        equal('$$susp'( '$append', [ :(0, _Q), :(_R, []) ], _S, _T ), _B, _P, _U),
        '$distances'(_B, _V, true, _U, _W),
        '$domain'(_V, 1, _F, true, _W, _X),
        '$all_different'(_V, true, _X, _Y),
        equal('$$susp'( '$append', [ :(_Z, _AA), :(_BA, []) ], _CA, _DA ), _V, _Y, _EA),
        $#<(_Z, _BA, true, _EA, _FA),
        '$labeling'(:(toMinimize(_R), []), _B, true, _FA, _D).

% distances
'$distances'(_A, _B, true, _C, _D):-
        hnf(_A, _E, _C, _F),
        '$distances_1'(_E, _B, true, _F, _D).
'$distances_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, [], _C, _E),
        hnf(_B, [], _E, _D).
'$distances_1'(_A, _B, true, _C, _D):-
        unifyHnfs(_A, :(_E, _F), _C, _G),
        '$distancesB'(_E, _F, _B, _H, true, _G, _I),
        '$distances'(_F, _H, true, _I, _D).

% distancesB
'$distancesB'(_A, _B, _C, _D, true, _E, _F):-
        hnf(_B, _G, _E, _H),
        '$distancesB_2'(_A, _G, _C, _D, true, _H, _F).
'$distancesB_2'(_A, _B, _C, _D, true, _E, _F):-
        unifyHnfs(_B, [], _E, _G),
        equal(_C, _D, _G, _F).
'$distancesB_2'(_A, _B, _C, _D, true, _E, _F):-
        unifyHnfs(_B, :(_G, _H), _E, _I),
        hnf(_C, :(_J, _K), _I, _L),
        $#=(_J, '$$susp'( $#-, [ _G, _A ], _M, _N ), true, _L, _O),
        '$distancesB'(_A, _H, _K, _D, true, _O, _F).


/***********   CODE FOR DINAMIC CUT         ***********/

/*Lista de funciones deterministas indicadas por el usuario */

annotate(deterministic('$if_then_else')).


/*Lista de funciones deterministas por programa *************/

annotate(deterministic('$init_fd')).
annotate(deterministic('$write')).
annotate(deterministic('$nl')).
annotate(deterministic($#==)).
annotate(deterministic($#/==)).
annotate(deterministic('$domain')).
annotate(deterministic('$subset')).
annotate(deterministic('$inset')).
annotate(deterministic('$setcomplement')).
annotate(deterministic('$intersect')).
annotate(deterministic('$belongs')).
annotate(deterministic('$labeling')).
annotate(deterministic('$indomain')).
annotate(deterministic('$fdminimize')).
annotate(deterministic('$fdmaximize')).
annotate(deterministic($#=)).
annotate(deterministic($#\=)).
annotate(deterministic($#<)).
annotate(deterministic($#<=)).
annotate(deterministic($#>)).
annotate(deterministic($#>=)).
annotate(deterministic($#+)).
annotate(deterministic($#-)).
annotate(deterministic($#*)).
annotate(deterministic($#/)).
annotate(deterministic($#&)).
annotate(deterministic('$sum')).
annotate(deterministic('$scalar_product')).
annotate(deterministic('$all_different')).
annotate(deterministic('$all_different\'')).
annotate(deterministic('$assignment')).
annotate(deterministic('$circuit')).
annotate(deterministic('$circuit\'')).
annotate(deterministic('$count')).
annotate(deterministic('$element')).
annotate(deterministic('$exactly')).
annotate(deterministic('$serialized')).
annotate(deterministic('$serialized\'')).
annotate(deterministic('$cumulative')).
annotate(deterministic('$cumulative\'')).
annotate(deterministic($#\/)).
annotate(deterministic($#<=>)).
annotate(deterministic($#=>)).
annotate(deterministic('$fd_var')).
annotate(deterministic('$fd_min')).
annotate(deterministic('$fd_max')).
annotate(deterministic('$fd_size')).
annotate(deterministic('$fd_set')).
annotate(deterministic('$fd_dom')).
annotate(deterministic('$fd_degree')).
annotate(deterministic('$fd_neighbors')).
annotate(deterministic('$fd_closure')).
annotate(deterministic('$inf')).
annotate(deterministic('$sup')).
annotate(deterministic('$is_fdset')).
annotate(deterministic('$empty_fdset')).
annotate(deterministic('$fdset_parts')).
annotate(deterministic('$fdset_split')).
annotate(deterministic('$empty_interval')).
annotate(deterministic('$fdset_to_interval')).
annotate(deterministic('$interval_to_fdset')).
annotate(deterministic('$fdset_singleton')).
annotate(deterministic('$fdset_min')).
annotate(deterministic('$fdset_max')).
annotate(deterministic('$fdset_size')).
annotate(deterministic('$list_to_fdset')).
annotate(deterministic('$fdset_to_list')).
annotate(deterministic('$range_to_fdset')).
annotate(deterministic('$fdset_to_range')).
annotate(deterministic('$fdset_add_element')).
annotate(deterministic('$fdset_del_element')).
annotate(deterministic('$fdset_intersection')).
annotate(deterministic('$fdset_subtract')).
annotate(deterministic('$fdset_union')).
annotate(deterministic('$fdset_complement')).
annotate(deterministic('$fdsets_intersection')).
annotate(deterministic('$fdsets_union')).
annotate(deterministic('$fdset_equal')).
annotate(deterministic('$fdset_subset')).
annotate(deterministic('$fdset_disjoint')).
annotate(deterministic('$fdset_intersect')).
annotate(deterministic('$fdset_member')).
annotate(deterministic('$fdset_belongs')).
annotate(deterministic('$isin')).
annotate(deterministic('$minimum')).
annotate(deterministic('$fd_statistics')).
annotate(deterministic('$fd_statistics\'')).
annotate(deterministic('$fd_global')).
annotate(deterministic('$end_fd')).
annotate(deterministic('$hasLength')).
annotate(deterministic('$append')).
annotate(deterministic('$golomb')).
annotate(deterministic('$distances')).
annotate(deterministic('$distancesB')).


% varList(+List,-ListVars): ListVars is a list with all the variables from
% terms in List  that can avoid the cut if they are bound
% Each variable occurrs only once in ListVars.
varList(ListTerms,ListVars) :- varList(ListTerms,[],ListVars),!.

% varList(+List,+LI, -LO): Analagous to varList/2 but with LI
% the list of variables accumulated at the moment.
varList([],ListVars,ListVars) :- !.
varList([X|Xs],LI,LO) :- varListTerm(X,LI,LO1),
                         varList(Xs,LO1,LO).
% varListTerm(+Term,+LI,-LO) : Analogous to varList/3 but for a single term
varListTerm(T,L,L)       :- atomic(T),!.
varListTerm(V,LI,LI)     :- var(V), varInList(V,LI),!.
varListTerm(V,LI,[V|LI]) :- var(V),!.

% evaluated suspension: check the result
varListTerm('$$susp'(_F,_Args,R,S),LI,LO) :- \+var(S),
                                             !,
                                             varListTerm(R,LI,LO).

% non-evaluated suspension: collect the variables of the arguments, and
% the variable determining if it is evaluated if it is non-deterministic
varListTerm('$$susp'(F,Args,_R,S),LI,LO) :- varList(Args,LI,LO1),
                                           (
                                             \+annotate(deterministic(F)),
                                             \+varInList(S,LO1),
                                             LO=[S|LO1]
                                               ;
                                             LO = LO1
                                           ),
                                           !.
% rest of the possibilities
varListTerm(Term,LI,LO):- Term =.. [F|Args],
varListTerm(F,LI,LO1),
varList(Args,LO1,LO).

% varInList(+V,+L)
% Checks if the var V occurrs in the list L
varInList(V,[R|_L]) :- V==R,!.
varInList(V,[_R|L]) :- varInList(V,L).
% checkVarList(L): Checks if the input list contains different variables
checkVarList([]) :- !.
checkVarList([X|Xs]) :- var(X), \+varInList(X,Xs), checkVarList(Xs).


/***********   CONSTRUCTORS AND FUNCTIONS   ***********/

constr(',', 2, ->(_A, ->(_B, ','(_A, _B))), ','(_A, _B)).
constr('$$tup', 1, ->(','(_A, _B), '$$tuple'(','(_A, _B))), '$$tuple'(','(_A, _B))).
constr([], 0, :(_A, []), :(_A, [])).
constr(:, 2, ->(_A, ->(:(_A, []), :(_A, []))), :(_A, [])).
constr('$char', 1, ->(_A, char), char).
constr('$io', 1, ->(_A, '$io'(_A)), '$io'(_A)).
constr('$stream', 1, handle, handle).
constr(readMode, 0, ioMode, ioMode).
constr(writeMode, 0, ioMode, ioMode).
constr(appendMode, 0, ioMode, ioMode).
constr('$channel', 2, channel, channel).
constr('$varmut', 1, varmut, varmut).
constr(pValBottom, 0, pVal, pVal).
constr(pValChar, 1, ->(char, pVal), pVal).
constr(pValNum, 1, ->(:(char, []), pVal), pVal).
constr(pValVar, 1, ->(:(char, []), pVal), pVal).
constr(pValApp, 2, ->(:(char, []), ->(:(pVal, []), pVal)), pVal).
constr(constraint, 1, ->(:(atomicConstraint, []), constraint), constraint).
constr(atomicConstraint, 3, ->(:(char, []), ->(:(pVal, []), ->(pVal, atomicConstraint))), atomicConstraint).
constr(cTreeNode, 7, ->(:(char, []), ->(:(pVal, []), ->(pVal, ->(:(char, []), ->(:(pVal, []), ->(:(char, []), ->(:('$$tuple'(','(pVal, cTree)), []), cTree))))))), cTree).
constr(cTreeVoid, 0, cTree, cTree).
constr(ff, 0, labelingType, labelingType).
constr(ffc, 0, labelingType, labelingType).
constr(leftmost, 0, labelingType, labelingType).
constr(mini, 0, labelingType, labelingType).
constr(maxi, 0, labelingType, labelingType).
constr(step, 0, labelingType, labelingType).
constr(enum, 0, labelingType, labelingType).
constr(bisect, 0, labelingType, labelingType).
constr(up, 0, labelingType, labelingType).
constr(down, 0, labelingType, labelingType).
constr(each, 0, labelingType, labelingType).
constr(toMinimize, 1, ->('$num'(int), labelingType), labelingType).
constr(toMaximize, 1, ->('$num'(int), labelingType), labelingType).
constr(assumptions, 1, ->('$num'(int), labelingType), labelingType).
constr(value, 0, reasoning, reasoning).
constr(domains, 0, reasoning, reasoning).
constr(range, 0, reasoning, reasoning).
constr(on, 1, ->(reasoning, allDiffOptions), allDiffOptions).
constr(complete, 1, ->(bool, allDiffOptions), allDiffOptions).
constr(d, 1, ->('$$tuple'(','('$num'(int), ','('$num'(int), liftedInt))), typeprecedence), typeprecedence).
constr(superior, 0, liftedInt, liftedInt).
constr(lift, 1, ->('$num'(int), liftedInt), liftedInt).
constr(precedences, 1, ->(:(typeprecedence, []), serialOptions), serialOptions).
constr(path_consistency, 1, ->(bool, serialOptions), serialOptions).
constr(static_sets, 1, ->(bool, serialOptions), serialOptions).
constr(edge_finder, 1, ->(bool, serialOptions), serialOptions).
constr(decomposition, 1, ->(bool, serialOptions), serialOptions).
constr(cte, 2, ->('$num'(int), ->('$num'(int), range)), range).
constr(uni, 2, ->(range, ->(range, range)), range).
constr(inter, 2, ->(range, ->(range, range)), range).
constr(compl, 1, ->(range, range), range).
constr(interval, 2, ->('$num'(int), ->('$num'(int), fdinterval)), fdinterval).
constr(resumptions, 0, statistics, statistics).
constr(entailments, 0, statistics, statistics).
constr(prunings, 0, statistics, statistics).
constr(backtracks, 0, statistics, statistics).
constr(constraints, 0, statistics, statistics).
constr(domm, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(minn, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(maxx, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(minmax, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(vall, 1, ->('$num'(int), wakeOptions), wakeOptions).
constr(true, 0, bool, bool).
constr(false, 0, bool, bool).

funct(uminus, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(abs, 1, 1, ->('$num'(_A), '$num'(_A)), '$num'(_A)).
funct(sqrt, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(ln, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(exp, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asin, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acos, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atan, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acot, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(sinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(cosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(tanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(coth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(asinh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acosh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(atanh, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(acoth, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(evalfd, 2, 2, ->(:(char, []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(+, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(-, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(*, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(min, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(max, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(_A))), '$num'(_A)).
funct(/, 2, 2, ->('$num'(_A), ->('$num'(_A), '$num'(float))), '$num'(float)).
funct(**, 2, 2, ->('$num'(_A), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(log, 2, 2, ->('$num'(float), ->('$num'(float), '$num'(float))), '$num'(float)).
funct(^, 2, 2, ->('$num'(_A), ->('$num'(int), '$num'(_A))), '$num'(_A)).
funct(div, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(mod, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(gcd, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(round, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(trunc, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(floor, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(ceiling, 1, 1, ->('$num'(_A), '$num'(int)), '$num'(int)).
funct(toReal, 1, 1, ->('$num'(_A), '$num'(float)), '$num'(float)).
funct(<, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(<=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(>=, 2, 2, ->('$num'(_A), ->('$num'(_A), bool)), bool).
funct(==, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(/=, 2, 2, ->(_A, ->(_A, bool)), bool).
funct(ord, 1, 1, ->(char, '$num'(int)), '$num'(int)).
funct(chr, 1, 1, ->('$num'(int), char), char).
funct(putChar, 1, 1, ->(char, io(unit)), io(unit)).
funct(done, 0, 0, io(unit), io(unit)).
funct(getChar, 0, 0, io(char), io(char)).
funct(return, 1, 1, ->(_A, io(_A)), io(_A)).
funct(>>, 2, 2, ->(io(_A), ->(io(_B), io(_B))), io(_B)).
funct(>>=, 2, 2, ->(io(_A), ->(->(_A, io(_B)), io(_B))), io(_B)).
funct(putStr, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(putStrLn, 1, 1, ->(:(char, []), io(unit)), io(unit)).
funct(getLine, 0, 0, io(:(char, [])), io(:(char, []))).
funct(cont1, 1, 1, ->(char, io(:(char, []))), io(:(char, []))).
funct(cont2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).
funct(writeFile, 2, 2, ->(:(char, []), ->(:(char, []), io(unit))), io(unit)).
funct(readFile, 1, 1, ->(:(char, []), io(:(char, []))), io(:(char, []))).
funct(readFileContents, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(dVal, 1, 1, ->(_A, pVal), pVal).
funct(dValToString, 1, 1, ->(_A, :(char, [])), :(char, [])).
funct(getConstraintStore, 1, 1, ->(:(_A, []), constraint), constraint).
funct(selectWhereVariableXi, 4, 4, ->(_A, ->('$num'(int), ->('$num'(int), ->(_B, _C)))), _C).
funct(fails, 1, 1, ->(_A, bool), bool).
funct(once, 1, 1, ->(_A, _A), _A).
funct(collect, 1, 1, ->(_A, :(_A, [])), :(_A, [])).
funct(collectN, 2, 2, ->('$num'(int), ->(_A, :(_A, []))), :(_A, [])).
funct(if_then_else, 3, 3, ->(bool, ->(_A, ->(_A, _A))), _A).
funct(if_then, 2, 2, ->(bool, ->(_A, _A)), _A).
funct(flip, 3, 3, ->(->(_A, ->(_B, _C)), ->(_B, ->(_A, _C))), _C).
funct(minimize, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(maximize, 1, 1, ->('$num'(float), '$num'(float)), '$num'(float)).
funct(bb_minimize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).
funct(bb_maximize, 2, 2, ->('$num'(float), ->(:('$num'(float), []), '$num'(float))), '$num'(float)).

funct('$apply', 2, 2, ->(->(->(_A, _B), _A), _B), _B).
funct('$eqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct('$notEqFun', 2, 2, ->(_A, ->(_A, bool)), bool).
funct(init_fd, 0, 0, '$num'(int), '$num'(int)).
funct(write, 1, 1, ->(_A, bool), bool).
funct(nl, 0, 0, bool, bool).
funct(#==, 2, 2, ->('$num'(int), ->('$num'(float), bool)), bool).
funct(#/==, 2, 2, ->('$num'(int), ->('$num'(float), bool)), bool).
funct(domain, 3, 3, ->(:('$num'(int), []), ->('$num'(int), ->('$num'(int), bool))), bool).
funct(subset, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(inset, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(setcomplement, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(intersect, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(belongs, 2, 2, ->('$num'(int), ->(:('$num'(int), []), bool)), bool).
funct(labeling, 2, 2, ->(:(labelingType, []), ->(:('$num'(int), []), bool)), bool).
funct(indomain, 1, 1, ->('$num'(int), bool), bool).
funct(fdminimize, 2, 2, ->(bool, ->('$num'(int), bool)), bool).
funct(fdmaximize, 2, 2, ->(bool, ->('$num'(int), bool)), bool).
funct(#=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#\=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#<, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#<=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#>, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#>=, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(#+, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#-, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#*, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#/, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(#&, 2, 2, ->('$num'(int), ->('$num'(int), '$num'(int))), '$num'(int)).
funct(sum, 3, 3, ->(:('$num'(int), []), ->(->('$num'(int), ->('$num'(int), bool)), ->('$num'(int), bool))), bool).
funct(scalar_product, 4, 4, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(->('$num'(int), ->('$num'(int), bool)), ->('$num'(int), bool)))), bool).
funct(all_different, 1, 1, ->(:('$num'(int), []), bool), bool).
funct('all_different\'', 2, 2, ->(:('$num'(int), []), ->(:(allDiffOptions, []), bool)), bool).
funct(assignment, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct(circuit, 1, 1, ->(:('$num'(int), []), bool), bool).
funct('circuit\'', 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct(count, 4, 4, ->('$num'(int), ->(:('$num'(int), []), ->(->('$num'(int), ->('$num'(int), bool)), ->('$num'(int), bool)))), bool).
funct(element, 3, 3, ->('$num'(int), ->(:('$num'(int), []), ->('$num'(int), bool))), bool).
funct(exactly, 3, 3, ->('$num'(int), ->(:('$num'(int), []), ->('$num'(int), bool))), bool).
funct(serialized, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct('serialized\'', 3, 3, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:(serialOptions, []), bool))), bool).
funct(cumulative, 4, 4, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), bool)))), bool).
funct('cumulative\'', 5, 5, ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$num'(int), []), ->('$num'(int), ->(:(serialOptions, []), bool))))), bool).
funct(#\/, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(#<=>, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(#=>, 2, 2, ->(bool, ->(bool, bool)), bool).
funct(fd_var, 1, 1, ->('$num'(int), bool), bool).
funct(fd_min, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_max, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_size, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_set, 1, 1, ->('$num'(int), :(fdinterval, [])), :(fdinterval, [])).
funct(fd_dom, 1, 1, ->('$num'(int), range), range).
funct(fd_degree, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_neighbors, 1, 1, ->('$num'(int), :('$num'(int), [])), :('$num'(int), [])).
funct(fd_closure, 1, 1, ->(:('$num'(int), []), :('$num'(int), [])), :('$num'(int), [])).
funct(inf, 0, 0, '$num'(int), '$num'(int)).
funct(sup, 0, 0, '$num'(int), '$num'(int)).
funct(is_fdset, 1, 1, ->(:(fdinterval, []), bool), bool).
funct(empty_fdset, 1, 1, ->(:(fdinterval, []), bool), bool).
funct(fdset_parts, 3, 3, ->('$num'(int), ->('$num'(int), ->(:(fdinterval, []), :(fdinterval, [])))), :(fdinterval, [])).
funct(fdset_split, 1, 1, ->(:(fdinterval, []), '$$tuple'(','('$num'(int), ','('$num'(int), :(fdinterval, []))))), '$$tuple'(','('$num'(int), ','('$num'(int), :(fdinterval, []))))).
funct(empty_interval, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(fdset_to_interval, 1, 1, ->(:(fdinterval, []), '$$tuple'(','('$num'(int), '$num'(int)))), '$$tuple'(','('$num'(int), '$num'(int)))).
funct(interval_to_fdset, 2, 2, ->('$num'(int), ->('$num'(int), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_singleton, 2, 2, ->(:(fdinterval, []), ->('$num'(int), bool)), bool).
funct(fdset_min, 1, 1, ->(:(fdinterval, []), '$num'(int)), '$num'(int)).
funct(fdset_max, 1, 1, ->(:(fdinterval, []), '$num'(int)), '$num'(int)).
funct(fdset_size, 1, 1, ->(:(fdinterval, []), '$num'(int)), '$num'(int)).
funct(list_to_fdset, 1, 1, ->(:('$num'(int), []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdset_to_list, 1, 1, ->(:(fdinterval, []), :('$num'(int), [])), :('$num'(int), [])).
funct(range_to_fdset, 1, 1, ->(range, :(fdinterval, [])), :(fdinterval, [])).
funct(fdset_to_range, 1, 1, ->(:(fdinterval, []), range), range).
funct(fdset_add_element, 2, 2, ->(:(fdinterval, []), ->('$num'(int), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_del_element, 2, 2, ->(:(fdinterval, []), ->('$num'(int), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_intersection, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_subtract, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_union, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), :(fdinterval, []))), :(fdinterval, [])).
funct(fdset_complement, 1, 1, ->(:(fdinterval, []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdsets_intersection, 1, 1, ->(:(:(fdinterval, []), []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdsets_union, 1, 1, ->(:(:(fdinterval, []), []), :(fdinterval, [])), :(fdinterval, [])).
funct(fdset_equal, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_subset, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_disjoint, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_intersect, 2, 2, ->(:(fdinterval, []), ->(:(fdinterval, []), bool)), bool).
funct(fdset_member, 2, 2, ->('$num'(int), ->(:(fdinterval, []), bool)), bool).
funct(fdset_belongs, 2, 2, ->('$num'(int), ->('$num'(int), bool)), bool).
funct(isin, 2, 2, ->('$num'(int), ->('$$tuple'(','('$num'(int), '$num'(int))), bool)), bool).
funct(minimum, 1, 1, ->('$num'(int), '$num'(int)), '$num'(int)).
funct(fd_statistics, 0, 0, bool, bool).
funct('fd_statistics\'', 1, 1, ->(statistics, '$num'(int)), '$num'(int)).
funct(fd_global, 3, 3, ->(bool, ->(_A, ->(:(wakeOptions, []), bool))), bool).
funct(end_fd, 0, 0, '$num'(int), '$num'(int)).
funct(hasLength, 2, 2, ->(:(_A, []), ->('$num'(int), bool)), bool).
funct(append, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), :('$num'(int), []))), :('$num'(int), [])).
funct(golomb, 2, 2, ->('$num'(int), ->(:('$num'(int), []), bool)), bool).
funct(distances, 2, 2, ->(:('$num'(int), []), ->(:('$num'(int), []), bool)), bool).
funct(distancesB, 4, 4, ->('$num'(int), ->(:('$num'(int), []), ->(:('$num'(int), []), ->(:('$num'(int), []), bool)))), bool).

/************    CODE FOR FUNCIONS HNF    ************/

hnf_susp('$uminus', '.'(_A, []), _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
hnf_susp('$abs', '.'(_A, []), _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
hnf_susp('$sqrt', '.'(_A, []), _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
hnf_susp('$ln', '.'(_A, []), _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
hnf_susp('$exp', '.'(_A, []), _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
hnf_susp('$sin', '.'(_A, []), _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
hnf_susp('$cos', '.'(_A, []), _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
hnf_susp('$tan', '.'(_A, []), _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
hnf_susp('$cot', '.'(_A, []), _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
hnf_susp('$asin', '.'(_A, []), _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
hnf_susp('$acos', '.'(_A, []), _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
hnf_susp('$atan', '.'(_A, []), _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
hnf_susp('$acot', '.'(_A, []), _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
hnf_susp('$sinh', '.'(_A, []), _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
hnf_susp('$cosh', '.'(_A, []), _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
hnf_susp('$tanh', '.'(_A, []), _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
hnf_susp('$coth', '.'(_A, []), _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
hnf_susp('$asinh', '.'(_A, []), _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
hnf_susp('$acosh', '.'(_A, []), _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
hnf_susp('$atanh', '.'(_A, []), _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
hnf_susp('$acoth', '.'(_A, []), _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
hnf_susp('$evalfd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
hnf_susp($+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
hnf_susp($-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
hnf_susp($*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
hnf_susp('$min', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
hnf_susp('$max', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
hnf_susp($/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
hnf_susp($**, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
hnf_susp('$log', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
hnf_susp($^, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
hnf_susp('$div', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
hnf_susp('$mod', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
hnf_susp('$gcd', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
hnf_susp('$round', '.'(_A, []), _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
hnf_susp('$trunc', '.'(_A, []), _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
hnf_susp('$floor', '.'(_A, []), _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
hnf_susp('$ceiling', '.'(_A, []), _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
hnf_susp('$toReal', '.'(_A, []), _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
hnf_susp($<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
hnf_susp($<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
hnf_susp($>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
hnf_susp($>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
hnf_susp($==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
hnf_susp($/=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
hnf_susp('$ord', '.'(_A, []), _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
hnf_susp('$chr', '.'(_A, []), _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
hnf_susp('$putChar', '.'(_A, []), _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
hnf_susp('$done', [], _A, _B, _C):-
        '$done'(_A, _B, _C).
hnf_susp('$getChar', [], _A, _B, _C):-
        '$getChar'(_A, _B, _C).
hnf_susp('$return', '.'(_A, []), _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
hnf_susp($>>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
hnf_susp($>>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
hnf_susp('$putStr', '.'(_A, []), _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
hnf_susp('$putStrLn', '.'(_A, []), _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
hnf_susp('$getLine', [], _A, _B, _C):-
        '$getLine'(_A, _B, _C).
hnf_susp('$cont1', '.'(_A, []), _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
hnf_susp('$cont2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
hnf_susp('$writeFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
hnf_susp('$readFile', '.'(_A, []), _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
hnf_susp('$readFileContents', '.'(_A, []), _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
hnf_susp('$dVal', '.'(_A, []), _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
hnf_susp('$dValToString', '.'(_A, []), _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
hnf_susp('$getConstraintStore', '.'(_A, []), _B, _C, _D):-
        '$getConstraintStore'(_A, _B, _C, _D).
hnf_susp('$selectWhereVariableXi', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$fails', '.'(_A, []), _B, _C, _D):-
        '$fails'(_A, _B, _C, _D).
hnf_susp('$once', '.'(_A, []), _B, _C, _D):-
        '$once'(_A, _B, _C, _D).
hnf_susp('$collect', '.'(_A, []), _B, _C, _D):-
        '$collect'(_A, _B, _C, _D).
hnf_susp('$collectN', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$collectN'(_A, _B, _C, _D, _E).
hnf_susp('$if_then_else', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
hnf_susp('$if_then', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
hnf_susp('$flip', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
hnf_susp('$minimize', '.'(_A, []), _B, _C, _D):-
        '$minimize'(_A, _B, _C, _D).
hnf_susp('$maximize', '.'(_A, []), _B, _C, _D):-
        '$maximize'(_A, _B, _C, _D).
hnf_susp('$bb_minimize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$bb_minimize'(_A, _B, _C, _D, _E).
hnf_susp('$bb_maximize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$bb_maximize'(_A, _B, _C, _D, _E).
hnf_susp('$$apply', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$apply'(_A, _B, _C, _D, _E).
hnf_susp('$$eqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
hnf_susp('$$notEqFun', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
hnf_susp('$init_fd', [], _A, _B, _C):-
        '$init_fd'(_A, _B, _C).
hnf_susp('$write', '.'(_A, []), _B, _C, _D):-
        '$write'(_A, _B, _C, _D).
hnf_susp('$nl', [], _A, _B, _C):-
        '$nl'(_A, _B, _C).
hnf_susp($#==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#==(_A, _B, _C, _D, _E).
hnf_susp($#/==, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#/==(_A, _B, _C, _D, _E).
hnf_susp('$domain', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$domain'(_A, _B, _C, _D, _E, _F).
hnf_susp('$subset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$subset'(_A, _B, _C, _D, _E).
hnf_susp('$inset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$inset'(_A, _B, _C, _D, _E).
hnf_susp('$setcomplement', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$setcomplement'(_A, _B, _C, _D, _E).
hnf_susp('$intersect', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$intersect'(_A, _B, _C, _D, _E).
hnf_susp('$belongs', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$belongs'(_A, _B, _C, _D, _E).
hnf_susp('$labeling', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$labeling'(_A, _B, _C, _D, _E).
hnf_susp('$indomain', '.'(_A, []), _B, _C, _D):-
        '$indomain'(_A, _B, _C, _D).
hnf_susp('$fdminimize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdminimize'(_A, _B, _C, _D, _E).
hnf_susp('$fdmaximize', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdmaximize'(_A, _B, _C, _D, _E).
hnf_susp($#=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#=(_A, _B, _C, _D, _E).
hnf_susp($#\=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#\=(_A, _B, _C, _D, _E).
hnf_susp($#<, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#<(_A, _B, _C, _D, _E).
hnf_susp($#<=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#<=(_A, _B, _C, _D, _E).
hnf_susp($#>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#>(_A, _B, _C, _D, _E).
hnf_susp($#>=, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#>=(_A, _B, _C, _D, _E).
hnf_susp($#+, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#+(_A, _B, _C, _D, _E).
hnf_susp($#-, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#-(_A, _B, _C, _D, _E).
hnf_susp($#*, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#*(_A, _B, _C, _D, _E).
hnf_susp($#/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#/(_A, _B, _C, _D, _E).
hnf_susp($#&, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#&(_A, _B, _C, _D, _E).
hnf_susp('$sum', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$sum'(_A, _B, _C, _D, _E, _F).
hnf_susp('$scalar_product', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$scalar_product'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$all_different', '.'(_A, []), _B, _C, _D):-
        '$all_different'(_A, _B, _C, _D).
hnf_susp('$all_different\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$all_different\''(_A, _B, _C, _D, _E).
hnf_susp('$assignment', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$assignment'(_A, _B, _C, _D, _E).
hnf_susp('$circuit', '.'(_A, []), _B, _C, _D):-
        '$circuit'(_A, _B, _C, _D).
hnf_susp('$circuit\'', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$circuit\''(_A, _B, _C, _D, _E).
hnf_susp('$count', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$count'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$element', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$element'(_A, _B, _C, _D, _E, _F).
hnf_susp('$exactly', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$exactly'(_A, _B, _C, _D, _E, _F).
hnf_susp('$serialized', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$serialized'(_A, _B, _C, _D, _E).
hnf_susp('$serialized\'', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$serialized\''(_A, _B, _C, _D, _E, _F).
hnf_susp('$cumulative', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$cumulative'(_A, _B, _C, _D, _E, _F, _G).
hnf_susp('$cumulative\'', '.'(_A, '.'(_B, '.'(_C, '.'(_D, '.'(_E, []))))), _F, _G, _H):-
        '$cumulative\''(_A, _B, _C, _D, _E, _F, _G, _H).
hnf_susp($#\/, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#\/(_A, _B, _C, _D, _E).
hnf_susp($#<=>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#<=>(_A, _B, _C, _D, _E).
hnf_susp($#=>, '.'(_A, '.'(_B, [])), _C, _D, _E):-
        $#=>(_A, _B, _C, _D, _E).
hnf_susp('$fd_var', '.'(_A, []), _B, _C, _D):-
        '$fd_var'(_A, _B, _C, _D).
hnf_susp('$fd_min', '.'(_A, []), _B, _C, _D):-
        '$fd_min'(_A, _B, _C, _D).
hnf_susp('$fd_max', '.'(_A, []), _B, _C, _D):-
        '$fd_max'(_A, _B, _C, _D).
hnf_susp('$fd_size', '.'(_A, []), _B, _C, _D):-
        '$fd_size'(_A, _B, _C, _D).
hnf_susp('$fd_set', '.'(_A, []), _B, _C, _D):-
        '$fd_set'(_A, _B, _C, _D).
hnf_susp('$fd_dom', '.'(_A, []), _B, _C, _D):-
        '$fd_dom'(_A, _B, _C, _D).
hnf_susp('$fd_degree', '.'(_A, []), _B, _C, _D):-
        '$fd_degree'(_A, _B, _C, _D).
hnf_susp('$fd_neighbors', '.'(_A, []), _B, _C, _D):-
        '$fd_neighbors'(_A, _B, _C, _D).
hnf_susp('$fd_closure', '.'(_A, []), _B, _C, _D):-
        '$fd_closure'(_A, _B, _C, _D).
hnf_susp('$inf', [], _A, _B, _C):-
        '$inf'(_A, _B, _C).
hnf_susp('$sup', [], _A, _B, _C):-
        '$sup'(_A, _B, _C).
hnf_susp('$is_fdset', '.'(_A, []), _B, _C, _D):-
        '$is_fdset'(_A, _B, _C, _D).
hnf_susp('$empty_fdset', '.'(_A, []), _B, _C, _D):-
        '$empty_fdset'(_A, _B, _C, _D).
hnf_susp('$fdset_parts', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$fdset_parts'(_A, _B, _C, _D, _E, _F).
hnf_susp('$fdset_split', '.'(_A, []), _B, _C, _D):-
        '$fdset_split'(_A, _B, _C, _D).
hnf_susp('$empty_interval', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$empty_interval'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_to_interval', '.'(_A, []), _B, _C, _D):-
        '$fdset_to_interval'(_A, _B, _C, _D).
hnf_susp('$interval_to_fdset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$interval_to_fdset'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_singleton', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_singleton'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_min', '.'(_A, []), _B, _C, _D):-
        '$fdset_min'(_A, _B, _C, _D).
hnf_susp('$fdset_max', '.'(_A, []), _B, _C, _D):-
        '$fdset_max'(_A, _B, _C, _D).
hnf_susp('$fdset_size', '.'(_A, []), _B, _C, _D):-
        '$fdset_size'(_A, _B, _C, _D).
hnf_susp('$list_to_fdset', '.'(_A, []), _B, _C, _D):-
        '$list_to_fdset'(_A, _B, _C, _D).
hnf_susp('$fdset_to_list', '.'(_A, []), _B, _C, _D):-
        '$fdset_to_list'(_A, _B, _C, _D).
hnf_susp('$range_to_fdset', '.'(_A, []), _B, _C, _D):-
        '$range_to_fdset'(_A, _B, _C, _D).
hnf_susp('$fdset_to_range', '.'(_A, []), _B, _C, _D):-
        '$fdset_to_range'(_A, _B, _C, _D).
hnf_susp('$fdset_add_element', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_add_element'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_del_element', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_del_element'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_intersection', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_intersection'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_subtract', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_subtract'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_union', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_union'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_complement', '.'(_A, []), _B, _C, _D):-
        '$fdset_complement'(_A, _B, _C, _D).
hnf_susp('$fdsets_intersection', '.'(_A, []), _B, _C, _D):-
        '$fdsets_intersection'(_A, _B, _C, _D).
hnf_susp('$fdsets_union', '.'(_A, []), _B, _C, _D):-
        '$fdsets_union'(_A, _B, _C, _D).
hnf_susp('$fdset_equal', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_equal'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_subset', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_subset'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_disjoint', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_disjoint'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_intersect', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_intersect'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_member', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_member'(_A, _B, _C, _D, _E).
hnf_susp('$fdset_belongs', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$fdset_belongs'(_A, _B, _C, _D, _E).
hnf_susp('$isin', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$isin'(_A, _B, _C, _D, _E).
hnf_susp('$minimum', '.'(_A, []), _B, _C, _D):-
        '$minimum'(_A, _B, _C, _D).
hnf_susp('$fd_statistics', [], _A, _B, _C):-
        '$fd_statistics'(_A, _B, _C).
hnf_susp('$fd_statistics\'', '.'(_A, []), _B, _C, _D):-
        '$fd_statistics\''(_A, _B, _C, _D).
hnf_susp('$fd_global', '.'(_A, '.'(_B, '.'(_C, []))), _D, _E, _F):-
        '$fd_global'(_A, _B, _C, _D, _E, _F).
hnf_susp('$end_fd', [], _A, _B, _C):-
        '$end_fd'(_A, _B, _C).
hnf_susp('$hasLength', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$hasLength'(_A, _B, _C, _D, _E).
hnf_susp('$append', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$append'(_A, _B, _C, _D, _E).
hnf_susp('$golomb', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$golomb'(_A, _B, _C, _D, _E).
hnf_susp('$distances', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$distances'(_A, _B, _C, _D, _E).
hnf_susp('$distancesB', '.'(_A, '.'(_B, '.'(_C, '.'(_D, [])))), _E, _F, _G):-
        '$distancesB'(_A, _B, _C, _D, _E, _F, _G).




/***************     CODE FOR APPLY     ***************/

'$$apply'(_A, _B, _C, _D, _E):-
        hnf(_A, _F, _D, _G),
        '$$applyHnf'(_F, _B, _C, _G, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        var(_A),
        !,
        '$$apply_1_var'(_A, _B, _C, _D, _E).
'$$applyHnf'(_A, _B, _C, _D, _E):-
        '$$apply_1'(_A, _B, _C, _D, _E).

% constructors

'$$apply_1'(:, _A, :(_A), _B, _B).
'$$apply_1_var'(_A, _B, :(_B), _C, _D):-
        unifyHnfs(_A, :, _C, _D).

'$$apply_1'(:(_A), _B, :(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, :(_C, _B), _D, _E):-
        unifyHnfs(_A, :(_C), _D, _E).

'$$apply_1'('$io', _A, '$io'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$io'(_B), _C, _D):-
        unifyHnfs(_A, '$io', _C, _D).

'$$apply_1'('$stream', _A, '$stream'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$stream'(_B), _C, _D):-
        unifyHnfs(_A, '$stream', _C, _D).

'$$apply_1'('$channel', _A, '$channel'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$channel'(_B), _C, _D):-
        unifyHnfs(_A, '$channel', _C, _D).

'$$apply_1'('$channel'(_A), _B, '$channel'(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, '$channel'(_C, _B), _D, _E):-
        unifyHnfs(_A, '$channel'(_C), _D, _E).

'$$apply_1'('$varmut', _A, '$varmut'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$varmut'(_B), _C, _D):-
        unifyHnfs(_A, '$varmut', _C, _D).

'$$apply_1'(pValChar, _A, pValChar(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValChar(_B), _C, _D):-
        unifyHnfs(_A, pValChar, _C, _D).

'$$apply_1'(pValNum, _A, pValNum(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValNum(_B), _C, _D):-
        unifyHnfs(_A, pValNum, _C, _D).

'$$apply_1'(pValVar, _A, pValVar(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValVar(_B), _C, _D):-
        unifyHnfs(_A, pValVar, _C, _D).

'$$apply_1'(pValApp, _A, pValApp(_A), _B, _B).
'$$apply_1_var'(_A, _B, pValApp(_B), _C, _D):-
        unifyHnfs(_A, pValApp, _C, _D).

'$$apply_1'(pValApp(_A), _B, pValApp(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, pValApp(_C, _B), _D, _E):-
        unifyHnfs(_A, pValApp(_C), _D, _E).

'$$apply_1'(constraint, _A, constraint(_A), _B, _B).
'$$apply_1_var'(_A, _B, constraint(_B), _C, _D):-
        unifyHnfs(_A, constraint, _C, _D).

'$$apply_1'(atomicConstraint, _A, atomicConstraint(_A), _B, _B).
'$$apply_1_var'(_A, _B, atomicConstraint(_B), _C, _D):-
        unifyHnfs(_A, atomicConstraint, _C, _D).

'$$apply_1'(atomicConstraint(_A), _B, atomicConstraint(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, atomicConstraint(_C, _B), _D, _E):-
        unifyHnfs(_A, atomicConstraint(_C), _D, _E).

'$$apply_1'(atomicConstraint(_A, _B), _C, atomicConstraint(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, atomicConstraint(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, atomicConstraint(_C, _D), _E, _F).

'$$apply_1'(cTreeNode, _A, cTreeNode(_A), _B, _B).
'$$apply_1_var'(_A, _B, cTreeNode(_B), _C, _D):-
        unifyHnfs(_A, cTreeNode, _C, _D).

'$$apply_1'(cTreeNode(_A), _B, cTreeNode(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _B), _D, _E):-
        unifyHnfs(_A, cTreeNode(_C), _D, _E).

'$$apply_1'(cTreeNode(_A, _B), _C, cTreeNode(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, cTreeNode(_C, _D), _E, _F).

'$$apply_1'(cTreeNode(_A, _B, _C), _D, cTreeNode(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E), _F, _G).

'$$apply_1'(cTreeNode(_A, _B, _C, _D), _E, cTreeNode(_A, _B, _C, _D, _E), _F, _F).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _B), _G, _H):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F), _G, _H).

'$$apply_1'(cTreeNode(_A, _B, _C, _D, _E), _F, cTreeNode(_A, _B, _C, _D, _E, _F), _G, _G).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _G, _B), _H, _I):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F, _G), _H, _I).

'$$apply_1'(cTreeNode(_A, _B, _C, _D, _E, _F), _G, cTreeNode(_A, _B, _C, _D, _E, _F, _G), _H, _H).
'$$apply_1_var'(_A, _B, cTreeNode(_C, _D, _E, _F, _G, _H, _B), _I, _J):-
        unifyHnfs(_A, cTreeNode(_C, _D, _E, _F, _G, _H), _I, _J).

'$$apply_1'(toMinimize, _A, toMinimize(_A), _B, _B).
'$$apply_1_var'(_A, _B, toMinimize(_B), _C, _D):-
        unifyHnfs(_A, toMinimize, _C, _D).

'$$apply_1'(toMaximize, _A, toMaximize(_A), _B, _B).
'$$apply_1_var'(_A, _B, toMaximize(_B), _C, _D):-
        unifyHnfs(_A, toMaximize, _C, _D).

'$$apply_1'(assumptions, _A, assumptions(_A), _B, _B).
'$$apply_1_var'(_A, _B, assumptions(_B), _C, _D):-
        unifyHnfs(_A, assumptions, _C, _D).

'$$apply_1'(on, _A, on(_A), _B, _B).
'$$apply_1_var'(_A, _B, on(_B), _C, _D):-
        unifyHnfs(_A, on, _C, _D).

'$$apply_1'(complete, _A, complete(_A), _B, _B).
'$$apply_1_var'(_A, _B, complete(_B), _C, _D):-
        unifyHnfs(_A, complete, _C, _D).

'$$apply_1'(d, _A, d(_A), _B, _B).
'$$apply_1_var'(_A, _B, d(_B), _C, _D):-
        unifyHnfs(_A, d, _C, _D).

'$$apply_1'(lift, _A, lift(_A), _B, _B).
'$$apply_1_var'(_A, _B, lift(_B), _C, _D):-
        unifyHnfs(_A, lift, _C, _D).

'$$apply_1'(precedences, _A, precedences(_A), _B, _B).
'$$apply_1_var'(_A, _B, precedences(_B), _C, _D):-
        unifyHnfs(_A, precedences, _C, _D).

'$$apply_1'(path_consistency, _A, path_consistency(_A), _B, _B).
'$$apply_1_var'(_A, _B, path_consistency(_B), _C, _D):-
        unifyHnfs(_A, path_consistency, _C, _D).

'$$apply_1'(static_sets, _A, static_sets(_A), _B, _B).
'$$apply_1_var'(_A, _B, static_sets(_B), _C, _D):-
        unifyHnfs(_A, static_sets, _C, _D).

'$$apply_1'(edge_finder, _A, edge_finder(_A), _B, _B).
'$$apply_1_var'(_A, _B, edge_finder(_B), _C, _D):-
        unifyHnfs(_A, edge_finder, _C, _D).

'$$apply_1'(decomposition, _A, decomposition(_A), _B, _B).
'$$apply_1_var'(_A, _B, decomposition(_B), _C, _D):-
        unifyHnfs(_A, decomposition, _C, _D).

'$$apply_1'(cte, _A, cte(_A), _B, _B).
'$$apply_1_var'(_A, _B, cte(_B), _C, _D):-
        unifyHnfs(_A, cte, _C, _D).

'$$apply_1'(cte(_A), _B, cte(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, cte(_C, _B), _D, _E):-
        unifyHnfs(_A, cte(_C), _D, _E).

'$$apply_1'(uni, _A, uni(_A), _B, _B).
'$$apply_1_var'(_A, _B, uni(_B), _C, _D):-
        unifyHnfs(_A, uni, _C, _D).

'$$apply_1'(uni(_A), _B, uni(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, uni(_C, _B), _D, _E):-
        unifyHnfs(_A, uni(_C), _D, _E).

'$$apply_1'(inter, _A, inter(_A), _B, _B).
'$$apply_1_var'(_A, _B, inter(_B), _C, _D):-
        unifyHnfs(_A, inter, _C, _D).

'$$apply_1'(inter(_A), _B, inter(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, inter(_C, _B), _D, _E):-
        unifyHnfs(_A, inter(_C), _D, _E).

'$$apply_1'(compl, _A, compl(_A), _B, _B).
'$$apply_1_var'(_A, _B, compl(_B), _C, _D):-
        unifyHnfs(_A, compl, _C, _D).

'$$apply_1'(interval, _A, interval(_A), _B, _B).
'$$apply_1_var'(_A, _B, interval(_B), _C, _D):-
        unifyHnfs(_A, interval, _C, _D).

'$$apply_1'(interval(_A), _B, interval(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, interval(_C, _B), _D, _E):-
        unifyHnfs(_A, interval(_C), _D, _E).

'$$apply_1'(domm, _A, domm(_A), _B, _B).
'$$apply_1_var'(_A, _B, domm(_B), _C, _D):-
        unifyHnfs(_A, domm, _C, _D).

'$$apply_1'(minn, _A, minn(_A), _B, _B).
'$$apply_1_var'(_A, _B, minn(_B), _C, _D):-
        unifyHnfs(_A, minn, _C, _D).

'$$apply_1'(maxx, _A, maxx(_A), _B, _B).
'$$apply_1_var'(_A, _B, maxx(_B), _C, _D):-
        unifyHnfs(_A, maxx, _C, _D).

'$$apply_1'(minmax, _A, minmax(_A), _B, _B).
'$$apply_1_var'(_A, _B, minmax(_B), _C, _D):-
        unifyHnfs(_A, minmax, _C, _D).

'$$apply_1'(vall, _A, vall(_A), _B, _B).
'$$apply_1_var'(_A, _B, vall(_B), _C, _D):-
        unifyHnfs(_A, vall, _C, _D).

% parcial aplictions of funs

'$$apply_1'('$eqFun', _A, '$eqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$eqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$eqFun', _C, _D).

'$$apply_1'('$notEqFun', _A, '$notEqFun'(_A), _B, _B).
'$$apply_1_var'(_A, _B, '$notEqFun'(_B), _C, _D):-
        unifyHnfs(_A, '$notEqFun', _C, _D).

'$$apply_1'(#==, _A, #==(_A), _B, _B).
'$$apply_1_var'(_A, _B, #==(_B), _C, _D):-
        unifyHnfs(_A, #==, _C, _D).

'$$apply_1'(#/==, _A, #/==(_A), _B, _B).
'$$apply_1_var'(_A, _B, #/==(_B), _C, _D):-
        unifyHnfs(_A, #/==, _C, _D).

'$$apply_1'(domain, _A, domain(_A), _B, _B).
'$$apply_1_var'(_A, _B, domain(_B), _C, _D):-
        unifyHnfs(_A, domain, _C, _D).

'$$apply_1'(domain(_A), _B, domain(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, domain(_C, _B), _D, _E):-
        unifyHnfs(_A, domain(_C), _D, _E).

'$$apply_1'(subset, _A, subset(_A), _B, _B).
'$$apply_1_var'(_A, _B, subset(_B), _C, _D):-
        unifyHnfs(_A, subset, _C, _D).

'$$apply_1'(inset, _A, inset(_A), _B, _B).
'$$apply_1_var'(_A, _B, inset(_B), _C, _D):-
        unifyHnfs(_A, inset, _C, _D).

'$$apply_1'(setcomplement, _A, setcomplement(_A), _B, _B).
'$$apply_1_var'(_A, _B, setcomplement(_B), _C, _D):-
        unifyHnfs(_A, setcomplement, _C, _D).

'$$apply_1'(intersect, _A, intersect(_A), _B, _B).
'$$apply_1_var'(_A, _B, intersect(_B), _C, _D):-
        unifyHnfs(_A, intersect, _C, _D).

'$$apply_1'(belongs, _A, belongs(_A), _B, _B).
'$$apply_1_var'(_A, _B, belongs(_B), _C, _D):-
        unifyHnfs(_A, belongs, _C, _D).

'$$apply_1'(labeling, _A, labeling(_A), _B, _B).
'$$apply_1_var'(_A, _B, labeling(_B), _C, _D):-
        unifyHnfs(_A, labeling, _C, _D).

'$$apply_1'(fdminimize, _A, fdminimize(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdminimize(_B), _C, _D):-
        unifyHnfs(_A, fdminimize, _C, _D).

'$$apply_1'(fdmaximize, _A, fdmaximize(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdmaximize(_B), _C, _D):-
        unifyHnfs(_A, fdmaximize, _C, _D).

'$$apply_1'(#=, _A, #=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #=(_B), _C, _D):-
        unifyHnfs(_A, #=, _C, _D).

'$$apply_1'(#\=, _A, #\=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #\=(_B), _C, _D):-
        unifyHnfs(_A, #\=, _C, _D).

'$$apply_1'(#<, _A, #<(_A), _B, _B).
'$$apply_1_var'(_A, _B, #<(_B), _C, _D):-
        unifyHnfs(_A, #<, _C, _D).

'$$apply_1'(#<=, _A, #<=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #<=(_B), _C, _D):-
        unifyHnfs(_A, #<=, _C, _D).

'$$apply_1'(#>, _A, #>(_A), _B, _B).
'$$apply_1_var'(_A, _B, #>(_B), _C, _D):-
        unifyHnfs(_A, #>, _C, _D).

'$$apply_1'(#>=, _A, #>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, #>=(_B), _C, _D):-
        unifyHnfs(_A, #>=, _C, _D).

'$$apply_1'(#+, _A, #+(_A), _B, _B).
'$$apply_1_var'(_A, _B, #+(_B), _C, _D):-
        unifyHnfs(_A, #+, _C, _D).

'$$apply_1'(#-, _A, #-(_A), _B, _B).
'$$apply_1_var'(_A, _B, #-(_B), _C, _D):-
        unifyHnfs(_A, #-, _C, _D).

'$$apply_1'(#*, _A, #*(_A), _B, _B).
'$$apply_1_var'(_A, _B, #*(_B), _C, _D):-
        unifyHnfs(_A, #*, _C, _D).

'$$apply_1'(#/, _A, #/(_A), _B, _B).
'$$apply_1_var'(_A, _B, #/(_B), _C, _D):-
        unifyHnfs(_A, #/, _C, _D).

'$$apply_1'(#&, _A, #&(_A), _B, _B).
'$$apply_1_var'(_A, _B, #&(_B), _C, _D):-
        unifyHnfs(_A, #&, _C, _D).

'$$apply_1'(sum, _A, sum(_A), _B, _B).
'$$apply_1_var'(_A, _B, sum(_B), _C, _D):-
        unifyHnfs(_A, sum, _C, _D).

'$$apply_1'(sum(_A), _B, sum(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, sum(_C, _B), _D, _E):-
        unifyHnfs(_A, sum(_C), _D, _E).

'$$apply_1'(scalar_product, _A, scalar_product(_A), _B, _B).
'$$apply_1_var'(_A, _B, scalar_product(_B), _C, _D):-
        unifyHnfs(_A, scalar_product, _C, _D).

'$$apply_1'(scalar_product(_A), _B, scalar_product(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, scalar_product(_C, _B), _D, _E):-
        unifyHnfs(_A, scalar_product(_C), _D, _E).

'$$apply_1'(scalar_product(_A, _B), _C, scalar_product(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, scalar_product(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, scalar_product(_C, _D), _E, _F).

'$$apply_1'('all_different\'', _A, 'all_different\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'all_different\''(_B), _C, _D):-
        unifyHnfs(_A, 'all_different\'', _C, _D).

'$$apply_1'(assignment, _A, assignment(_A), _B, _B).
'$$apply_1_var'(_A, _B, assignment(_B), _C, _D):-
        unifyHnfs(_A, assignment, _C, _D).

'$$apply_1'('circuit\'', _A, 'circuit\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'circuit\''(_B), _C, _D):-
        unifyHnfs(_A, 'circuit\'', _C, _D).

'$$apply_1'(count, _A, count(_A), _B, _B).
'$$apply_1_var'(_A, _B, count(_B), _C, _D):-
        unifyHnfs(_A, count, _C, _D).

'$$apply_1'(count(_A), _B, count(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, count(_C, _B), _D, _E):-
        unifyHnfs(_A, count(_C), _D, _E).

'$$apply_1'(count(_A, _B), _C, count(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, count(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, count(_C, _D), _E, _F).

'$$apply_1'(element, _A, element(_A), _B, _B).
'$$apply_1_var'(_A, _B, element(_B), _C, _D):-
        unifyHnfs(_A, element, _C, _D).

'$$apply_1'(element(_A), _B, element(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, element(_C, _B), _D, _E):-
        unifyHnfs(_A, element(_C), _D, _E).

'$$apply_1'(exactly, _A, exactly(_A), _B, _B).
'$$apply_1_var'(_A, _B, exactly(_B), _C, _D):-
        unifyHnfs(_A, exactly, _C, _D).

'$$apply_1'(exactly(_A), _B, exactly(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, exactly(_C, _B), _D, _E):-
        unifyHnfs(_A, exactly(_C), _D, _E).

'$$apply_1'(serialized, _A, serialized(_A), _B, _B).
'$$apply_1_var'(_A, _B, serialized(_B), _C, _D):-
        unifyHnfs(_A, serialized, _C, _D).

'$$apply_1'('serialized\'', _A, 'serialized\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'serialized\''(_B), _C, _D):-
        unifyHnfs(_A, 'serialized\'', _C, _D).

'$$apply_1'('serialized\''(_A), _B, 'serialized\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'serialized\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'serialized\''(_C), _D, _E).

'$$apply_1'(cumulative, _A, cumulative(_A), _B, _B).
'$$apply_1_var'(_A, _B, cumulative(_B), _C, _D):-
        unifyHnfs(_A, cumulative, _C, _D).

'$$apply_1'(cumulative(_A), _B, cumulative(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, cumulative(_C, _B), _D, _E):-
        unifyHnfs(_A, cumulative(_C), _D, _E).

'$$apply_1'(cumulative(_A, _B), _C, cumulative(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, cumulative(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, cumulative(_C, _D), _E, _F).

'$$apply_1'('cumulative\'', _A, 'cumulative\''(_A), _B, _B).
'$$apply_1_var'(_A, _B, 'cumulative\''(_B), _C, _D):-
        unifyHnfs(_A, 'cumulative\'', _C, _D).

'$$apply_1'('cumulative\''(_A), _B, 'cumulative\''(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, 'cumulative\''(_C, _B), _D, _E):-
        unifyHnfs(_A, 'cumulative\''(_C), _D, _E).

'$$apply_1'('cumulative\''(_A, _B), _C, 'cumulative\''(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, 'cumulative\''(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, 'cumulative\''(_C, _D), _E, _F).

'$$apply_1'('cumulative\''(_A, _B, _C), _D, 'cumulative\''(_A, _B, _C, _D), _E, _E).
'$$apply_1_var'(_A, _B, 'cumulative\''(_C, _D, _E, _B), _F, _G):-
        unifyHnfs(_A, 'cumulative\''(_C, _D, _E), _F, _G).

'$$apply_1'(#\/, _A, #\/(_A), _B, _B).
'$$apply_1_var'(_A, _B, #\/(_B), _C, _D):-
        unifyHnfs(_A, #\/, _C, _D).

'$$apply_1'(#<=>, _A, #<=>(_A), _B, _B).
'$$apply_1_var'(_A, _B, #<=>(_B), _C, _D):-
        unifyHnfs(_A, #<=>, _C, _D).

'$$apply_1'(#=>, _A, #=>(_A), _B, _B).
'$$apply_1_var'(_A, _B, #=>(_B), _C, _D):-
        unifyHnfs(_A, #=>, _C, _D).

'$$apply_1'(fdset_parts, _A, fdset_parts(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_parts(_B), _C, _D):-
        unifyHnfs(_A, fdset_parts, _C, _D).

'$$apply_1'(fdset_parts(_A), _B, fdset_parts(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, fdset_parts(_C, _B), _D, _E):-
        unifyHnfs(_A, fdset_parts(_C), _D, _E).

'$$apply_1'(empty_interval, _A, empty_interval(_A), _B, _B).
'$$apply_1_var'(_A, _B, empty_interval(_B), _C, _D):-
        unifyHnfs(_A, empty_interval, _C, _D).

'$$apply_1'(interval_to_fdset, _A, interval_to_fdset(_A), _B, _B).
'$$apply_1_var'(_A, _B, interval_to_fdset(_B), _C, _D):-
        unifyHnfs(_A, interval_to_fdset, _C, _D).

'$$apply_1'(fdset_singleton, _A, fdset_singleton(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_singleton(_B), _C, _D):-
        unifyHnfs(_A, fdset_singleton, _C, _D).

'$$apply_1'(fdset_add_element, _A, fdset_add_element(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_add_element(_B), _C, _D):-
        unifyHnfs(_A, fdset_add_element, _C, _D).

'$$apply_1'(fdset_del_element, _A, fdset_del_element(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_del_element(_B), _C, _D):-
        unifyHnfs(_A, fdset_del_element, _C, _D).

'$$apply_1'(fdset_intersection, _A, fdset_intersection(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_intersection(_B), _C, _D):-
        unifyHnfs(_A, fdset_intersection, _C, _D).

'$$apply_1'(fdset_subtract, _A, fdset_subtract(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_subtract(_B), _C, _D):-
        unifyHnfs(_A, fdset_subtract, _C, _D).

'$$apply_1'(fdset_union, _A, fdset_union(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_union(_B), _C, _D):-
        unifyHnfs(_A, fdset_union, _C, _D).

'$$apply_1'(fdset_equal, _A, fdset_equal(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_equal(_B), _C, _D):-
        unifyHnfs(_A, fdset_equal, _C, _D).

'$$apply_1'(fdset_subset, _A, fdset_subset(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_subset(_B), _C, _D):-
        unifyHnfs(_A, fdset_subset, _C, _D).

'$$apply_1'(fdset_disjoint, _A, fdset_disjoint(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_disjoint(_B), _C, _D):-
        unifyHnfs(_A, fdset_disjoint, _C, _D).

'$$apply_1'(fdset_intersect, _A, fdset_intersect(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_intersect(_B), _C, _D):-
        unifyHnfs(_A, fdset_intersect, _C, _D).

'$$apply_1'(fdset_member, _A, fdset_member(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_member(_B), _C, _D):-
        unifyHnfs(_A, fdset_member, _C, _D).

'$$apply_1'(fdset_belongs, _A, fdset_belongs(_A), _B, _B).
'$$apply_1_var'(_A, _B, fdset_belongs(_B), _C, _D):-
        unifyHnfs(_A, fdset_belongs, _C, _D).

'$$apply_1'(isin, _A, isin(_A), _B, _B).
'$$apply_1_var'(_A, _B, isin(_B), _C, _D):-
        unifyHnfs(_A, isin, _C, _D).

'$$apply_1'(fd_global, _A, fd_global(_A), _B, _B).
'$$apply_1_var'(_A, _B, fd_global(_B), _C, _D):-
        unifyHnfs(_A, fd_global, _C, _D).

'$$apply_1'(fd_global(_A), _B, fd_global(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, fd_global(_C, _B), _D, _E):-
        unifyHnfs(_A, fd_global(_C), _D, _E).

'$$apply_1'(hasLength, _A, hasLength(_A), _B, _B).
'$$apply_1_var'(_A, _B, hasLength(_B), _C, _D):-
        unifyHnfs(_A, hasLength, _C, _D).

'$$apply_1'(append, _A, append(_A), _B, _B).
'$$apply_1_var'(_A, _B, append(_B), _C, _D):-
        unifyHnfs(_A, append, _C, _D).

'$$apply_1'(golomb, _A, golomb(_A), _B, _B).
'$$apply_1_var'(_A, _B, golomb(_B), _C, _D):-
        unifyHnfs(_A, golomb, _C, _D).

'$$apply_1'(distances, _A, distances(_A), _B, _B).
'$$apply_1_var'(_A, _B, distances(_B), _C, _D):-
        unifyHnfs(_A, distances, _C, _D).

'$$apply_1'(distancesB, _A, distancesB(_A), _B, _B).
'$$apply_1_var'(_A, _B, distancesB(_B), _C, _D):-
        unifyHnfs(_A, distancesB, _C, _D).

'$$apply_1'(distancesB(_A), _B, distancesB(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, distancesB(_C, _B), _D, _E):-
        unifyHnfs(_A, distancesB(_C), _D, _E).

'$$apply_1'(distancesB(_A, _B), _C, distancesB(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, distancesB(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, distancesB(_C, _D), _E, _F).

% parcial aplictions of prims

'$$apply_1'(evalfd, _A, evalfd(_A), _B, _B).
'$$apply_1_var'(_A, _B, evalfd(_B), _C, _D):-
        unifyHnfs(_A, evalfd, _C, _D).

'$$apply_1'(+, _A, +(_A), _B, _B).
'$$apply_1_var'(_A, _B, +(_B), _C, _D):-
        unifyHnfs(_A, +, _C, _D).

'$$apply_1'(-, _A, -(_A), _B, _B).
'$$apply_1_var'(_A, _B, -(_B), _C, _D):-
        unifyHnfs(_A, -, _C, _D).

'$$apply_1'(*, _A, *(_A), _B, _B).
'$$apply_1_var'(_A, _B, *(_B), _C, _D):-
        unifyHnfs(_A, *, _C, _D).

'$$apply_1'(min, _A, min(_A), _B, _B).
'$$apply_1_var'(_A, _B, min(_B), _C, _D):-
        unifyHnfs(_A, min, _C, _D).

'$$apply_1'(max, _A, max(_A), _B, _B).
'$$apply_1_var'(_A, _B, max(_B), _C, _D):-
        unifyHnfs(_A, max, _C, _D).

'$$apply_1'(/, _A, /(_A), _B, _B).
'$$apply_1_var'(_A, _B, /(_B), _C, _D):-
        unifyHnfs(_A, /, _C, _D).

'$$apply_1'(**, _A, **(_A), _B, _B).
'$$apply_1_var'(_A, _B, **(_B), _C, _D):-
        unifyHnfs(_A, **, _C, _D).

'$$apply_1'(log, _A, log(_A), _B, _B).
'$$apply_1_var'(_A, _B, log(_B), _C, _D):-
        unifyHnfs(_A, log, _C, _D).

'$$apply_1'(^, _A, ^(_A), _B, _B).
'$$apply_1_var'(_A, _B, ^(_B), _C, _D):-
        unifyHnfs(_A, ^, _C, _D).

'$$apply_1'(div, _A, div(_A), _B, _B).
'$$apply_1_var'(_A, _B, div(_B), _C, _D):-
        unifyHnfs(_A, div, _C, _D).

'$$apply_1'(mod, _A, mod(_A), _B, _B).
'$$apply_1_var'(_A, _B, mod(_B), _C, _D):-
        unifyHnfs(_A, mod, _C, _D).

'$$apply_1'(gcd, _A, gcd(_A), _B, _B).
'$$apply_1_var'(_A, _B, gcd(_B), _C, _D):-
        unifyHnfs(_A, gcd, _C, _D).

'$$apply_1'(<, _A, <(_A), _B, _B).
'$$apply_1_var'(_A, _B, <(_B), _C, _D):-
        unifyHnfs(_A, <, _C, _D).

'$$apply_1'(<=, _A, <=(_A), _B, _B).
'$$apply_1_var'(_A, _B, <=(_B), _C, _D):-
        unifyHnfs(_A, <=, _C, _D).

'$$apply_1'(>, _A, >(_A), _B, _B).
'$$apply_1_var'(_A, _B, >(_B), _C, _D):-
        unifyHnfs(_A, >, _C, _D).

'$$apply_1'(>=, _A, >=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >=(_B), _C, _D):-
        unifyHnfs(_A, >=, _C, _D).

'$$apply_1'(==, _A, ==(_A), _B, _B).
'$$apply_1_var'(_A, _B, ==(_B), _C, _D):-
        unifyHnfs(_A, ==, _C, _D).

'$$apply_1'(/=, _A, /=(_A), _B, _B).
'$$apply_1_var'(_A, _B, /=(_B), _C, _D):-
        unifyHnfs(_A, /=, _C, _D).

'$$apply_1'(>>, _A, >>(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>(_B), _C, _D):-
        unifyHnfs(_A, >>, _C, _D).

'$$apply_1'(>>=, _A, >>=(_A), _B, _B).
'$$apply_1_var'(_A, _B, >>=(_B), _C, _D):-
        unifyHnfs(_A, >>=, _C, _D).

'$$apply_1'(cont2, _A, cont2(_A), _B, _B).
'$$apply_1_var'(_A, _B, cont2(_B), _C, _D):-
        unifyHnfs(_A, cont2, _C, _D).

'$$apply_1'(writeFile, _A, writeFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, writeFile(_B), _C, _D):-
        unifyHnfs(_A, writeFile, _C, _D).

'$$apply_1'(selectWhereVariableXi, _A, selectWhereVariableXi(_A), _B, _B).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_B), _C, _D):-
        unifyHnfs(_A, selectWhereVariableXi, _C, _D).

'$$apply_1'(selectWhereVariableXi(_A), _B, selectWhereVariableXi(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _B), _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_C), _D, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B), _C, selectWhereVariableXi(_A, _B, _C), _D, _D).
'$$apply_1_var'(_A, _B, selectWhereVariableXi(_C, _D, _B), _E, _F):-
        unifyHnfs(_A, selectWhereVariableXi(_C, _D), _E, _F).

'$$apply_1'(collectN, _A, collectN(_A), _B, _B).
'$$apply_1_var'(_A, _B, collectN(_B), _C, _D):-
        unifyHnfs(_A, collectN, _C, _D).

'$$apply_1'(if_then_else, _A, if_then_else(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then_else(_B), _C, _D):-
        unifyHnfs(_A, if_then_else, _C, _D).

'$$apply_1'(if_then_else(_A), _B, if_then_else(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, if_then_else(_C, _B), _D, _E):-
        unifyHnfs(_A, if_then_else(_C), _D, _E).

'$$apply_1'(if_then, _A, if_then(_A), _B, _B).
'$$apply_1_var'(_A, _B, if_then(_B), _C, _D):-
        unifyHnfs(_A, if_then, _C, _D).

'$$apply_1'(flip, _A, flip(_A), _B, _B).
'$$apply_1_var'(_A, _B, flip(_B), _C, _D):-
        unifyHnfs(_A, flip, _C, _D).

'$$apply_1'(flip(_A), _B, flip(_A, _B), _C, _C).
'$$apply_1_var'(_A, _B, flip(_C, _B), _D, _E):-
        unifyHnfs(_A, flip(_C), _D, _E).

'$$apply_1'(bb_minimize, _A, bb_minimize(_A), _B, _B).
'$$apply_1_var'(_A, _B, bb_minimize(_B), _C, _D):-
        unifyHnfs(_A, bb_minimize, _C, _D).

'$$apply_1'(bb_maximize, _A, bb_maximize(_A), _B, _B).
'$$apply_1_var'(_A, _B, bb_maximize(_B), _C, _D):-
        unifyHnfs(_A, bb_maximize, _C, _D).

% functions

'$$apply_1'('$eqFun'(_A), _B, _C, _D, _E):-
        '$$eqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$eqFun'(_F), _D, _G),
        '$$eqFun'(_F, _B, _C, _G, _E).

'$$apply_1'('$notEqFun'(_A), _B, _C, _D, _E):-
        '$$notEqFun'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, '$notEqFun'(_F), _D, _G),
        '$$notEqFun'(_F, _B, _C, _G, _E).

'$$apply_1'(write, _A, _B, _C, _D):-
        '$write'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, write, _D, _F),
        '$write'(_B, _C, _F, _E).

'$$apply_1'(#==(_A), _B, _C, _D, _E):-
        $#==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #==(_F), _D, _G),
        $#==(_F, _B, _C, _G, _E).

'$$apply_1'(#/==(_A), _B, _C, _D, _E):-
        $#/==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #/==(_F), _D, _G),
        $#/==(_F, _B, _C, _G, _E).

'$$apply_1'(domain(_A, _B), _C, _D, _E, _F):-
        '$domain'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, domain(_F, _G), _D, _H),
        '$domain'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(subset(_A), _B, _C, _D, _E):-
        '$subset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, subset(_F), _D, _G),
        '$subset'(_F, _B, _C, _G, _E).

'$$apply_1'(inset(_A), _B, _C, _D, _E):-
        '$inset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, inset(_F), _D, _G),
        '$inset'(_F, _B, _C, _G, _E).

'$$apply_1'(setcomplement(_A), _B, _C, _D, _E):-
        '$setcomplement'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, setcomplement(_F), _D, _G),
        '$setcomplement'(_F, _B, _C, _G, _E).

'$$apply_1'(intersect(_A), _B, _C, _D, _E):-
        '$intersect'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, intersect(_F), _D, _G),
        '$intersect'(_F, _B, _C, _G, _E).

'$$apply_1'(belongs(_A), _B, _C, _D, _E):-
        '$belongs'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, belongs(_F), _D, _G),
        '$belongs'(_F, _B, _C, _G, _E).

'$$apply_1'(labeling(_A), _B, _C, _D, _E):-
        '$labeling'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, labeling(_F), _D, _G),
        '$labeling'(_F, _B, _C, _G, _E).

'$$apply_1'(indomain, _A, _B, _C, _D):-
        '$indomain'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, indomain, _D, _F),
        '$indomain'(_B, _C, _F, _E).

'$$apply_1'(fdminimize(_A), _B, _C, _D, _E):-
        '$fdminimize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdminimize(_F), _D, _G),
        '$fdminimize'(_F, _B, _C, _G, _E).

'$$apply_1'(fdmaximize(_A), _B, _C, _D, _E):-
        '$fdmaximize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdmaximize(_F), _D, _G),
        '$fdmaximize'(_F, _B, _C, _G, _E).

'$$apply_1'(#=(_A), _B, _C, _D, _E):-
        $#=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #=(_F), _D, _G),
        $#=(_F, _B, _C, _G, _E).

'$$apply_1'(#\=(_A), _B, _C, _D, _E):-
        $#\=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #\=(_F), _D, _G),
        $#\=(_F, _B, _C, _G, _E).

'$$apply_1'(#<(_A), _B, _C, _D, _E):-
        $#<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #<(_F), _D, _G),
        $#<(_F, _B, _C, _G, _E).

'$$apply_1'(#<=(_A), _B, _C, _D, _E):-
        $#<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #<=(_F), _D, _G),
        $#<=(_F, _B, _C, _G, _E).

'$$apply_1'(#>(_A), _B, _C, _D, _E):-
        $#>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #>(_F), _D, _G),
        $#>(_F, _B, _C, _G, _E).

'$$apply_1'(#>=(_A), _B, _C, _D, _E):-
        $#>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #>=(_F), _D, _G),
        $#>=(_F, _B, _C, _G, _E).

'$$apply_1'(#+(_A), _B, _C, _D, _E):-
        $#+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #+(_F), _D, _G),
        $#+(_F, _B, _C, _G, _E).

'$$apply_1'(#-(_A), _B, _C, _D, _E):-
        $#-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #-(_F), _D, _G),
        $#-(_F, _B, _C, _G, _E).

'$$apply_1'(#*(_A), _B, _C, _D, _E):-
        $#*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #*(_F), _D, _G),
        $#*(_F, _B, _C, _G, _E).

'$$apply_1'(#/(_A), _B, _C, _D, _E):-
        $#/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #/(_F), _D, _G),
        $#/(_F, _B, _C, _G, _E).

'$$apply_1'(#&(_A), _B, _C, _D, _E):-
        $#&(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #&(_F), _D, _G),
        $#&(_F, _B, _C, _G, _E).

'$$apply_1'(sum(_A, _B), _C, _D, _E, _F):-
        '$sum'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sum(_F, _G), _D, _H),
        '$sum'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(scalar_product(_A, _B, _C), _D, _E, _F, _G):-
        '$scalar_product'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, scalar_product(_F, _G, _H), _D, _I),
        '$scalar_product'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(all_different, _A, _B, _C, _D):-
        '$all_different'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, all_different, _D, _F),
        '$all_different'(_B, _C, _F, _E).

'$$apply_1'('all_different\''(_A), _B, _C, _D, _E):-
        '$all_different\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'all_different\''(_F), _D, _G),
        '$all_different\''(_F, _B, _C, _G, _E).

'$$apply_1'(assignment(_A), _B, _C, _D, _E):-
        '$assignment'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, assignment(_F), _D, _G),
        '$assignment'(_F, _B, _C, _G, _E).

'$$apply_1'(circuit, _A, _B, _C, _D):-
        '$circuit'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, circuit, _D, _F),
        '$circuit'(_B, _C, _F, _E).

'$$apply_1'('circuit\''(_A), _B, _C, _D, _E):-
        '$circuit\''(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'circuit\''(_F), _D, _G),
        '$circuit\''(_F, _B, _C, _G, _E).

'$$apply_1'(count(_A, _B, _C), _D, _E, _F, _G):-
        '$count'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, count(_F, _G, _H), _D, _I),
        '$count'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(element(_A, _B), _C, _D, _E, _F):-
        '$element'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, element(_F, _G), _D, _H),
        '$element'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(exactly(_A, _B), _C, _D, _E, _F):-
        '$exactly'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exactly(_F, _G), _D, _H),
        '$exactly'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(serialized(_A), _B, _C, _D, _E):-
        '$serialized'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, serialized(_F), _D, _G),
        '$serialized'(_F, _B, _C, _G, _E).

'$$apply_1'('serialized\''(_A, _B), _C, _D, _E, _F):-
        '$serialized\''(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'serialized\''(_F, _G), _D, _H),
        '$serialized\''(_F, _G, _B, _C, _H, _E).

'$$apply_1'(cumulative(_A, _B, _C), _D, _E, _F, _G):-
        '$cumulative'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cumulative(_F, _G, _H), _D, _I),
        '$cumulative'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'('cumulative\''(_A, _B, _C, _D), _E, _F, _G, _H):-
        '$cumulative\''(_A, _B, _C, _D, _E, _F, _G, _H).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'cumulative\''(_F, _G, _H, _I), _D, _J),
        '$cumulative\''(_F, _G, _H, _I, _B, _C, _J, _E).

'$$apply_1'(#\/(_A), _B, _C, _D, _E):-
        $#\/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #\/(_F), _D, _G),
        $#\/(_F, _B, _C, _G, _E).

'$$apply_1'(#<=>(_A), _B, _C, _D, _E):-
        $#<=>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #<=>(_F), _D, _G),
        $#<=>(_F, _B, _C, _G, _E).

'$$apply_1'(#=>(_A), _B, _C, _D, _E):-
        $#=>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, #=>(_F), _D, _G),
        $#=>(_F, _B, _C, _G, _E).

'$$apply_1'(fd_var, _A, _B, _C, _D):-
        '$fd_var'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_var, _D, _F),
        '$fd_var'(_B, _C, _F, _E).

'$$apply_1'(fd_min, _A, _B, _C, _D):-
        '$fd_min'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_min, _D, _F),
        '$fd_min'(_B, _C, _F, _E).

'$$apply_1'(fd_max, _A, _B, _C, _D):-
        '$fd_max'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_max, _D, _F),
        '$fd_max'(_B, _C, _F, _E).

'$$apply_1'(fd_size, _A, _B, _C, _D):-
        '$fd_size'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_size, _D, _F),
        '$fd_size'(_B, _C, _F, _E).

'$$apply_1'(fd_set, _A, _B, _C, _D):-
        '$fd_set'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_set, _D, _F),
        '$fd_set'(_B, _C, _F, _E).

'$$apply_1'(fd_dom, _A, _B, _C, _D):-
        '$fd_dom'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_dom, _D, _F),
        '$fd_dom'(_B, _C, _F, _E).

'$$apply_1'(fd_degree, _A, _B, _C, _D):-
        '$fd_degree'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_degree, _D, _F),
        '$fd_degree'(_B, _C, _F, _E).

'$$apply_1'(fd_neighbors, _A, _B, _C, _D):-
        '$fd_neighbors'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_neighbors, _D, _F),
        '$fd_neighbors'(_B, _C, _F, _E).

'$$apply_1'(fd_closure, _A, _B, _C, _D):-
        '$fd_closure'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_closure, _D, _F),
        '$fd_closure'(_B, _C, _F, _E).

'$$apply_1'(is_fdset, _A, _B, _C, _D):-
        '$is_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, is_fdset, _D, _F),
        '$is_fdset'(_B, _C, _F, _E).

'$$apply_1'(empty_fdset, _A, _B, _C, _D):-
        '$empty_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, empty_fdset, _D, _F),
        '$empty_fdset'(_B, _C, _F, _E).

'$$apply_1'(fdset_parts(_A, _B), _C, _D, _E, _F):-
        '$fdset_parts'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_parts(_F, _G), _D, _H),
        '$fdset_parts'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(fdset_split, _A, _B, _C, _D):-
        '$fdset_split'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_split, _D, _F),
        '$fdset_split'(_B, _C, _F, _E).

'$$apply_1'(empty_interval(_A), _B, _C, _D, _E):-
        '$empty_interval'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, empty_interval(_F), _D, _G),
        '$empty_interval'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_to_interval, _A, _B, _C, _D):-
        '$fdset_to_interval'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_to_interval, _D, _F),
        '$fdset_to_interval'(_B, _C, _F, _E).

'$$apply_1'(interval_to_fdset(_A), _B, _C, _D, _E):-
        '$interval_to_fdset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, interval_to_fdset(_F), _D, _G),
        '$interval_to_fdset'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_singleton(_A), _B, _C, _D, _E):-
        '$fdset_singleton'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_singleton(_F), _D, _G),
        '$fdset_singleton'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_min, _A, _B, _C, _D):-
        '$fdset_min'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_min, _D, _F),
        '$fdset_min'(_B, _C, _F, _E).

'$$apply_1'(fdset_max, _A, _B, _C, _D):-
        '$fdset_max'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_max, _D, _F),
        '$fdset_max'(_B, _C, _F, _E).

'$$apply_1'(fdset_size, _A, _B, _C, _D):-
        '$fdset_size'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_size, _D, _F),
        '$fdset_size'(_B, _C, _F, _E).

'$$apply_1'(list_to_fdset, _A, _B, _C, _D):-
        '$list_to_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, list_to_fdset, _D, _F),
        '$list_to_fdset'(_B, _C, _F, _E).

'$$apply_1'(fdset_to_list, _A, _B, _C, _D):-
        '$fdset_to_list'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_to_list, _D, _F),
        '$fdset_to_list'(_B, _C, _F, _E).

'$$apply_1'(range_to_fdset, _A, _B, _C, _D):-
        '$range_to_fdset'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, range_to_fdset, _D, _F),
        '$range_to_fdset'(_B, _C, _F, _E).

'$$apply_1'(fdset_to_range, _A, _B, _C, _D):-
        '$fdset_to_range'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_to_range, _D, _F),
        '$fdset_to_range'(_B, _C, _F, _E).

'$$apply_1'(fdset_add_element(_A), _B, _C, _D, _E):-
        '$fdset_add_element'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_add_element(_F), _D, _G),
        '$fdset_add_element'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_del_element(_A), _B, _C, _D, _E):-
        '$fdset_del_element'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_del_element(_F), _D, _G),
        '$fdset_del_element'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_intersection(_A), _B, _C, _D, _E):-
        '$fdset_intersection'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_intersection(_F), _D, _G),
        '$fdset_intersection'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_subtract(_A), _B, _C, _D, _E):-
        '$fdset_subtract'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_subtract(_F), _D, _G),
        '$fdset_subtract'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_union(_A), _B, _C, _D, _E):-
        '$fdset_union'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_union(_F), _D, _G),
        '$fdset_union'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_complement, _A, _B, _C, _D):-
        '$fdset_complement'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_complement, _D, _F),
        '$fdset_complement'(_B, _C, _F, _E).

'$$apply_1'(fdsets_intersection, _A, _B, _C, _D):-
        '$fdsets_intersection'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdsets_intersection, _D, _F),
        '$fdsets_intersection'(_B, _C, _F, _E).

'$$apply_1'(fdsets_union, _A, _B, _C, _D):-
        '$fdsets_union'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdsets_union, _D, _F),
        '$fdsets_union'(_B, _C, _F, _E).

'$$apply_1'(fdset_equal(_A), _B, _C, _D, _E):-
        '$fdset_equal'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_equal(_F), _D, _G),
        '$fdset_equal'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_subset(_A), _B, _C, _D, _E):-
        '$fdset_subset'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_subset(_F), _D, _G),
        '$fdset_subset'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_disjoint(_A), _B, _C, _D, _E):-
        '$fdset_disjoint'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_disjoint(_F), _D, _G),
        '$fdset_disjoint'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_intersect(_A), _B, _C, _D, _E):-
        '$fdset_intersect'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_intersect(_F), _D, _G),
        '$fdset_intersect'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_member(_A), _B, _C, _D, _E):-
        '$fdset_member'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_member(_F), _D, _G),
        '$fdset_member'(_F, _B, _C, _G, _E).

'$$apply_1'(fdset_belongs(_A), _B, _C, _D, _E):-
        '$fdset_belongs'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fdset_belongs(_F), _D, _G),
        '$fdset_belongs'(_F, _B, _C, _G, _E).

'$$apply_1'(isin(_A), _B, _C, _D, _E):-
        '$isin'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, isin(_F), _D, _G),
        '$isin'(_F, _B, _C, _G, _E).

'$$apply_1'(minimum, _A, _B, _C, _D):-
        '$minimum'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, minimum, _D, _F),
        '$minimum'(_B, _C, _F, _E).

'$$apply_1'('fd_statistics\'', _A, _B, _C, _D):-
        '$fd_statistics\''(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, 'fd_statistics\'', _D, _F),
        '$fd_statistics\''(_B, _C, _F, _E).

'$$apply_1'(fd_global(_A, _B), _C, _D, _E, _F):-
        '$fd_global'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fd_global(_F, _G), _D, _H),
        '$fd_global'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(hasLength(_A), _B, _C, _D, _E):-
        '$hasLength'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, hasLength(_F), _D, _G),
        '$hasLength'(_F, _B, _C, _G, _E).

'$$apply_1'(append(_A), _B, _C, _D, _E):-
        '$append'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, append(_F), _D, _G),
        '$append'(_F, _B, _C, _G, _E).

'$$apply_1'(golomb(_A), _B, _C, _D, _E):-
        '$golomb'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, golomb(_F), _D, _G),
        '$golomb'(_F, _B, _C, _G, _E).

'$$apply_1'(distances(_A), _B, _C, _D, _E):-
        '$distances'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, distances(_F), _D, _G),
        '$distances'(_F, _B, _C, _G, _E).

'$$apply_1'(distancesB(_A, _B, _C), _D, _E, _F, _G):-
        '$distancesB'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, distancesB(_F, _G, _H), _D, _I),
        '$distancesB'(_F, _G, _H, _B, _C, _I, _E).

% primitives

'$$apply_1'(uminus, _A, _B, _C, _D):-
        '$uminus'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, uminus, _D, _F),
        '$uminus'(_B, _C, _F, _E).

'$$apply_1'(abs, _A, _B, _C, _D):-
        '$abs'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, abs, _D, _F),
        '$abs'(_B, _C, _F, _E).

'$$apply_1'(sqrt, _A, _B, _C, _D):-
        '$sqrt'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sqrt, _D, _F),
        '$sqrt'(_B, _C, _F, _E).

'$$apply_1'(ln, _A, _B, _C, _D):-
        '$ln'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ln, _D, _F),
        '$ln'(_B, _C, _F, _E).

'$$apply_1'(exp, _A, _B, _C, _D):-
        '$exp'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, exp, _D, _F),
        '$exp'(_B, _C, _F, _E).

'$$apply_1'(sin, _A, _B, _C, _D):-
        '$sin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sin, _D, _F),
        '$sin'(_B, _C, _F, _E).

'$$apply_1'(cos, _A, _B, _C, _D):-
        '$cos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cos, _D, _F),
        '$cos'(_B, _C, _F, _E).

'$$apply_1'(tan, _A, _B, _C, _D):-
        '$tan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tan, _D, _F),
        '$tan'(_B, _C, _F, _E).

'$$apply_1'(cot, _A, _B, _C, _D):-
        '$cot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cot, _D, _F),
        '$cot'(_B, _C, _F, _E).

'$$apply_1'(asin, _A, _B, _C, _D):-
        '$asin'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asin, _D, _F),
        '$asin'(_B, _C, _F, _E).

'$$apply_1'(acos, _A, _B, _C, _D):-
        '$acos'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acos, _D, _F),
        '$acos'(_B, _C, _F, _E).

'$$apply_1'(atan, _A, _B, _C, _D):-
        '$atan'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atan, _D, _F),
        '$atan'(_B, _C, _F, _E).

'$$apply_1'(acot, _A, _B, _C, _D):-
        '$acot'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acot, _D, _F),
        '$acot'(_B, _C, _F, _E).

'$$apply_1'(sinh, _A, _B, _C, _D):-
        '$sinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, sinh, _D, _F),
        '$sinh'(_B, _C, _F, _E).

'$$apply_1'(cosh, _A, _B, _C, _D):-
        '$cosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cosh, _D, _F),
        '$cosh'(_B, _C, _F, _E).

'$$apply_1'(tanh, _A, _B, _C, _D):-
        '$tanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, tanh, _D, _F),
        '$tanh'(_B, _C, _F, _E).

'$$apply_1'(coth, _A, _B, _C, _D):-
        '$coth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, coth, _D, _F),
        '$coth'(_B, _C, _F, _E).

'$$apply_1'(asinh, _A, _B, _C, _D):-
        '$asinh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, asinh, _D, _F),
        '$asinh'(_B, _C, _F, _E).

'$$apply_1'(acosh, _A, _B, _C, _D):-
        '$acosh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acosh, _D, _F),
        '$acosh'(_B, _C, _F, _E).

'$$apply_1'(atanh, _A, _B, _C, _D):-
        '$atanh'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, atanh, _D, _F),
        '$atanh'(_B, _C, _F, _E).

'$$apply_1'(acoth, _A, _B, _C, _D):-
        '$acoth'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, acoth, _D, _F),
        '$acoth'(_B, _C, _F, _E).

'$$apply_1'(evalfd(_A), _B, _C, _D, _E):-
        '$evalfd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, evalfd(_F), _D, _G),
        '$evalfd'(_F, _B, _C, _G, _E).

'$$apply_1'(+(_A), _B, _C, _D, _E):-
        $+(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, +(_F), _D, _G),
        $+(_F, _B, _C, _G, _E).

'$$apply_1'(-(_A), _B, _C, _D, _E):-
        $-(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, -(_F), _D, _G),
        $-(_F, _B, _C, _G, _E).

'$$apply_1'(*(_A), _B, _C, _D, _E):-
        $*(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, *(_F), _D, _G),
        $*(_F, _B, _C, _G, _E).

'$$apply_1'(min(_A), _B, _C, _D, _E):-
        '$min'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, min(_F), _D, _G),
        '$min'(_F, _B, _C, _G, _E).

'$$apply_1'(max(_A), _B, _C, _D, _E):-
        '$max'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, max(_F), _D, _G),
        '$max'(_F, _B, _C, _G, _E).

'$$apply_1'(/(_A), _B, _C, _D, _E):-
        $/(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /(_F), _D, _G),
        $/(_F, _B, _C, _G, _E).

'$$apply_1'(**(_A), _B, _C, _D, _E):-
        $**(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, **(_F), _D, _G),
        $**(_F, _B, _C, _G, _E).

'$$apply_1'(log(_A), _B, _C, _D, _E):-
        '$log'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, log(_F), _D, _G),
        '$log'(_F, _B, _C, _G, _E).

'$$apply_1'(^(_A), _B, _C, _D, _E):-
        $^(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ^(_F), _D, _G),
        $^(_F, _B, _C, _G, _E).

'$$apply_1'(div(_A), _B, _C, _D, _E):-
        '$div'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, div(_F), _D, _G),
        '$div'(_F, _B, _C, _G, _E).

'$$apply_1'(mod(_A), _B, _C, _D, _E):-
        '$mod'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, mod(_F), _D, _G),
        '$mod'(_F, _B, _C, _G, _E).

'$$apply_1'(gcd(_A), _B, _C, _D, _E):-
        '$gcd'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, gcd(_F), _D, _G),
        '$gcd'(_F, _B, _C, _G, _E).

'$$apply_1'(round, _A, _B, _C, _D):-
        '$round'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, round, _D, _F),
        '$round'(_B, _C, _F, _E).

'$$apply_1'(trunc, _A, _B, _C, _D):-
        '$trunc'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, trunc, _D, _F),
        '$trunc'(_B, _C, _F, _E).

'$$apply_1'(floor, _A, _B, _C, _D):-
        '$floor'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, floor, _D, _F),
        '$floor'(_B, _C, _F, _E).

'$$apply_1'(ceiling, _A, _B, _C, _D):-
        '$ceiling'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ceiling, _D, _F),
        '$ceiling'(_B, _C, _F, _E).

'$$apply_1'(toReal, _A, _B, _C, _D):-
        '$toReal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, toReal, _D, _F),
        '$toReal'(_B, _C, _F, _E).

'$$apply_1'(<(_A), _B, _C, _D, _E):-
        $<(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <(_F), _D, _G),
        $<(_F, _B, _C, _G, _E).

'$$apply_1'(<=(_A), _B, _C, _D, _E):-
        $<=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, <=(_F), _D, _G),
        $<=(_F, _B, _C, _G, _E).

'$$apply_1'(>(_A), _B, _C, _D, _E):-
        $>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >(_F), _D, _G),
        $>(_F, _B, _C, _G, _E).

'$$apply_1'(>=(_A), _B, _C, _D, _E):-
        $>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >=(_F), _D, _G),
        $>=(_F, _B, _C, _G, _E).

'$$apply_1'(==(_A), _B, _C, _D, _E):-
        $==(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ==(_F), _D, _G),
        $==(_F, _B, _C, _G, _E).

'$$apply_1'(/=(_A), _B, _C, _D, _E):-
        $/=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, /=(_F), _D, _G),
        $/=(_F, _B, _C, _G, _E).

'$$apply_1'(ord, _A, _B, _C, _D):-
        '$ord'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, ord, _D, _F),
        '$ord'(_B, _C, _F, _E).

'$$apply_1'(chr, _A, _B, _C, _D):-
        '$chr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, chr, _D, _F),
        '$chr'(_B, _C, _F, _E).

'$$apply_1'(putChar, _A, _B, _C, _D):-
        '$putChar'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putChar, _D, _F),
        '$putChar'(_B, _C, _F, _E).

'$$apply_1'(return, _A, _B, _C, _D):-
        '$return'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, return, _D, _F),
        '$return'(_B, _C, _F, _E).

'$$apply_1'(>>(_A), _B, _C, _D, _E):-
        $>>(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>(_F), _D, _G),
        $>>(_F, _B, _C, _G, _E).

'$$apply_1'(>>=(_A), _B, _C, _D, _E):-
        $>>=(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, >>=(_F), _D, _G),
        $>>=(_F, _B, _C, _G, _E).

'$$apply_1'(putStr, _A, _B, _C, _D):-
        '$putStr'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStr, _D, _F),
        '$putStr'(_B, _C, _F, _E).

'$$apply_1'(putStrLn, _A, _B, _C, _D):-
        '$putStrLn'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLn, _D, _F),
        '$putStrLn'(_B, _C, _F, _E).

'$$apply_1'(cont1, _A, _B, _C, _D):-
        '$cont1'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont1, _D, _F),
        '$cont1'(_B, _C, _F, _E).

'$$apply_1'(cont2(_A), _B, _C, _D, _E):-
        '$cont2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, cont2(_F), _D, _G),
        '$cont2'(_F, _B, _C, _G, _E).

'$$apply_1'(writeFile(_A), _B, _C, _D, _E):-
        '$writeFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, writeFile(_F), _D, _G),
        '$writeFile'(_F, _B, _C, _G, _E).

'$$apply_1'(readFile, _A, _B, _C, _D):-
        '$readFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFile, _D, _F),
        '$readFile'(_B, _C, _F, _E).

'$$apply_1'(readFileContents, _A, _B, _C, _D):-
        '$readFileContents'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, readFileContents, _D, _F),
        '$readFileContents'(_B, _C, _F, _E).

'$$apply_1'(dVal, _A, _B, _C, _D):-
        '$dVal'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dVal, _D, _F),
        '$dVal'(_B, _C, _F, _E).

'$$apply_1'(dValToString, _A, _B, _C, _D):-
        '$dValToString'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, dValToString, _D, _F),
        '$dValToString'(_B, _C, _F, _E).

'$$apply_1'(getConstraintStore, _A, _B, _C, _D):-
        '$getConstraintStore'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getConstraintStore, _D, _F),
        '$getConstraintStore'(_B, _C, _F, _E).

'$$apply_1'(selectWhereVariableXi(_A, _B, _C), _D, _E, _F, _G):-
        '$selectWhereVariableXi'(_A, _B, _C, _D, _E, _F, _G).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, selectWhereVariableXi(_F, _G, _H), _D, _I),
        '$selectWhereVariableXi'(_F, _G, _H, _B, _C, _I, _E).

'$$apply_1'(fails, _A, _B, _C, _D):-
        '$fails'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, fails, _D, _F),
        '$fails'(_B, _C, _F, _E).

'$$apply_1'(once, _A, _B, _C, _D):-
        '$once'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, once, _D, _F),
        '$once'(_B, _C, _F, _E).

'$$apply_1'(collect, _A, _B, _C, _D):-
        '$collect'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, collect, _D, _F),
        '$collect'(_B, _C, _F, _E).

'$$apply_1'(collectN(_A), _B, _C, _D, _E):-
        '$collectN'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, collectN(_F), _D, _G),
        '$collectN'(_F, _B, _C, _G, _E).

'$$apply_1'(if_then_else(_A, _B), _C, _D, _E, _F):-
        '$if_then_else'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then_else(_F, _G), _D, _H),
        '$if_then_else'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(if_then(_A), _B, _C, _D, _E):-
        '$if_then'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, if_then(_F), _D, _G),
        '$if_then'(_F, _B, _C, _G, _E).

'$$apply_1'(flip(_A, _B), _C, _D, _E, _F):-
        '$flip'(_A, _B, _C, _D, _E, _F).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, flip(_F, _G), _D, _H),
        '$flip'(_F, _G, _B, _C, _H, _E).

'$$apply_1'(minimize, _A, _B, _C, _D):-
        '$minimize'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, minimize, _D, _F),
        '$minimize'(_B, _C, _F, _E).

'$$apply_1'(maximize, _A, _B, _C, _D):-
        '$maximize'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, maximize, _D, _F),
        '$maximize'(_B, _C, _F, _E).

'$$apply_1'(bb_minimize(_A), _B, _C, _D, _E):-
        '$bb_minimize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, bb_minimize(_F), _D, _G),
        '$bb_minimize'(_F, _B, _C, _G, _E).

'$$apply_1'(bb_maximize(_A), _B, _C, _D, _E):-
        '$bb_maximize'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, bb_maximize(_F), _D, _G),
        '$bb_maximize'(_F, _B, _C, _G, _E).


/************   CODE FOR INFIX OPERATORS   ************/

infix(#=, noasoc, 20).
infix(#\=, noasoc, 20).
infix(#<, noasoc, 30).
infix(#<=, noasoc, 30).
infix(#>, noasoc, 30).
infix(#>=, noasoc, 30).
infix(#+, left, 50).
infix(#-, left, 50).
infix(#*, right, 90).
infix(#/, left, 90).
infix(#&, left, 90).
infix(#\/, noasoc, 15).
infix(#<=>, noasoc, 15).
infix(#=>, noasoc, 15).
infix(^, noasoc, 98).
infix(**, noasoc, 98).
infix(/, left, 90).
infix(*, right, 90).
infix(+, left, 50).
infix(-, left, 50).
infix(<, noasoc, 30).
infix(<=, noasoc, 30).
infix(>, noasoc, 30).
infix(>=, noasoc, 30).
infix(==, noasoc, 10).
infix(/=, noasoc, 10).
infix(>>, left, 11).
infix(>>=, left, 11).



'$flip'(F, A1, A2, H, Cin, Cout):-         '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%  BEGIN OF CFLPFDFILE %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% B Sonia
%:- load_files(dyn,[if(changed),imports([ prop_active/0 ])]).
%:- load_files(toycomm,[if(changed)]). %,imports([toSolverFD/3,listToSolverFD/3])]).

:- tools:complete_root_filename(dyn,F),load_files(F,[if(changed),imports([ prop_active/0 ])]).
:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed),imports([toSolverFD/3,listToSolverFD/3])]).
:- dyn:clpr_active, !, tools:complete_root_filename(cooperation,F),load_files(F,[if(changed)]).

%% E Sonia

%%%%%%%%%%%%%%%%  CFLPFD CONSTRAINTS   %%%%%%%%%%%%%%%%%%%%%%%%

:- use_module(library(clpfd)).
:- use_module(library(ordsets)).
:- use_module(library(lists)).

%%  B :: Sonia
:- assert(clpfd:full_answer).
:- use_module(library(clpr)).
%%  E :: Sonia

% Determining the maximum upper and minimum lower bounds of
% finite domains, 
% independent of SICStus version and platform.

narrow(Val0, Val) :-
    clpfd:fd_integer(Val0), !,
    Val = Val0.
narrow(Val0, Val) :-
    Val1 is Val0>>1,
    narrow(Val1, Val).

:-  Min0 is -1<<64,
    narrow(Min0, Min),
    Max0 is (1<<64)-1,
    narrow(Max0, Max),
    assert(cflpfd:inf(Min)),
    assert(cflpfd:sup(Max)).



/**************    CODE FOR FUNCTIONS    **************/

%FSP 06-02-2007 ::B
%% Debugging
% write :: A -> bool
'$write'(A,true,C,C) :-
  (nonvar(A),A = :(_,_) -> toyListToPrologList(A,P); P=A),
  write(P).

%nl :: A -> bool
'$nl'(true,C,C) :-
  nl.
  
%::E


%%%%%%%%%%%%%%%%%%% MEMBERSHIP CONSTRAINTS %%%%%%%%%%%%%%%%%%%%%%

% Sonia B

% comento todo el domain y lo escribo de nuevo con las modificaciones

/*

% domain :: [int] -> int -> int -> bool
% domain :=: [in] -> in -> in -> inout
'$domain'(VL, Low, Upp, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error(domain,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
        hnf(Low, HLow, Cout1, Cout2), 
        hnf(Upp, HUpp, Cout2, Cout), 
        HLow1 is integer(HLow), 
        HUpp1 is integer(HUpp), 
        ((Out=true, domain(PrologHVL, HLow1, HUpp1))
         ;
         (Out=false, HLow2 is integer(HLow1 - 1), HUpp2 is integer(HUpp1 + 1), 
          domain_remove(PrologHVL, HLow2, HUpp2))). 
*/

% domain :: [int] -> int -> int -> bool
% domain :=: [in] -> in -> in -> inout
'$domain'(VL, Low, Upp, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
%FSP 26/02/2007 
        (var(HVL) -> raise_exception(instatiation_error(domain,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
        hnf(Low, HLow, Cout1, Cout2), 
        hnf(Upp, HUpp, Cout2, Cout3), 
        HLow1 is integer(HLow), 
        HUpp1 is integer(HUpp), 
        HLowR is float(HLow1), 
        HUppR is float(HUpp1),
        listToSolverFD(PrologHVL,Cout3,Cout4),
        ((Out=true, domain(PrologHVL, HLow1, HUpp1),
        (prop_active -> (changeDomainR(PrologHVL, HLowR, HUppR,Cout4,Cout),!); Cout = Cout4))
         ;
         (Out=false, HLow2 is integer(HLow1 - 1), HUpp2 is integer(HUpp1 + 1), 
          domain_remove(PrologHVL, HLow2, HUpp2),
%FSP 26/02/2007 
          Cout=Cout4          
           )). 

changeDomainR([], HLowR, HUppR,C, C).

changeDomainR([H|Rest], HLowR, HUppR,Cin, Cout):-
    searchVarsR(H,Cin,Cout1,HR), 
    {HR >= HLowR, HR =< HUppR},
    changeDomainR(Rest, HLowR, HUppR,Cout1, Cout).
% Sonia E

domain_remove([], _HLow2, _HUpp2). 
domain_remove([X|Xs], HLow2, HUpp2) :- 
        X in (inf..HLow2) \/ (HUpp2..sup), 
        domain_remove(Xs, HLow2, HUpp2).


subset(X, Y) +:
  X in dom(Y)/\dom(X).

setcomplement(X, Y) +:
  X in \dom(Y).

% subset :: int -> int -> bool
% subset :=: inout -> inout -> inout
'$subset'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, subset(HL, HR));
         (Out=false, setcomplement(HL, HR))). 
 
% inset :: int -> int -> bool
% inset :=: inout -> inout -> inout
'$inset'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, fd_set(HR, SR), HL in_set SR);
         (Out=false, fd_set(HR, SR), fdset_complement(SR, CSR), HL in_set CSR)). 
 
% setcomplement :: int -> int -> bool
% setcomplement :=: inout -> inout -> inout
'$setcomplement'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        ((Out=true, setcomplement(HL, HR));
         (Out=false, subset(HL, HR))). 

% intersect :: int -> int -> int
% intersect :=: inout -> inout -> inout
'$intersect'(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
%B::Sonia
%        hnf(R, HR, Cout1, Cout), 
        hnf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E::Sonia
        fd_set(HR, SR), 
        fd_set(HL, SL), 
        fdset_intersection(SR, SL, SI), 
        Out in_set SI.
 
% sonia B
/* 

% belongs :: int -> [int] -> bool
% belongs :=: inout -> [in] -> inout
'$belongs'(V, L, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(L, HL, Cout1, Cout), 
        (var(HL) -> raise_exception(instatiation_error(belongs,2)); true),
        toyListToPrologList(HL, PL), 
        list_to_fdset(PL, PS), 
        ((Out=true, HV in_set PS);
         (Out=false, fdset_complement(PS, CPS), HV in_set CPS)).
*/

'$belongs'(V, L, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(L, HL, Cout1, Cout2), 
%FSP 26/02/2007 
        (var(HL) -> raise_exception(instatiation_error(belongs,2)); true),
        toyListToPrologList(HL, PL), 
        list_to_fdset(PL, PS), 
        toSolverFD(HV,Cout2,Cout3),
        listToSolverFD(PL,Cout3,Cout4),
        (( Out=true, HV in_set PS, 
         (prop_active -> (searchVarsR(HV,Cout4,Cout,HVR), 
                     min_list(PL, HLowR),
                     max_list(PL,HUppR),
                     {HVR >= HLowR}, {HVR =< HUppR},!
                   )
                   ;
                   Cout =Cout4
        )
        )
        ;
          ( Out=false, fdset_complement(PS, CPS), HV in_set CPS,
%FSP 26/02/2007 
          Cout=Cout4)
       ).
% sonia E
         

%%%%%%%%%%%%%%%%%%% ENUMERATION FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% labeling :: [labelingType] -> [int] -> bool
% labeling :=: inout -> [inout] -> inout
'$labeling'(OL, VL, true, Cin, Cout) :- 
        nf(OL, HOL, Cin, Cout1), 
        toyListToPrologList(HOL, PrologHOL), 
%B::Sonia        
%        nf(VL, HVL, Cout1, Cout), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
        listToSolverFD(PrologHVL,Cout2,Cout),
%E::Sonia        
        processLabelingOptions(PrologHOL, LabPrologHOL), 
        labeling(LabPrologHOL, PrologHVL), 
        translateLabOptions(LabToyHOL, LabPrologHOL), 
        toyNonVarListToPrologList(OL, LabToyHOL).


processLabelingOptions(TLs, PLs) :- 
        setof(TLs, validLabOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateLabOptions(TLs, PLs).


memberU(X, [X|Xs]).
memberU(X, [Y|Xs]) :- memberU(X, Xs).

removeU_duplicates(L, S) :- 
        removeU_duplicates(L, [], S). % List, GrowingNonDuplicatesList, Set

removeU_duplicates([], In, In).
removeU_duplicates([X|Xs], In, Set) :- 
        nonU_member(X, In), !, append(In, [X], NIn), !, 
        removeU_duplicates(Xs, NIn, Set).
removeU_duplicates([_|Xs], In, Set) :- 
        removeU_duplicates(Xs, In, Set).


nonU_member(_, []) :- !.
nonU_member(X, [X|_]) :- 
        !, fail.
nonU_member(X, [Y|Ys]) :- 
        \+ X=Y, 
        nonU_member(X, Ys).


validLabOptions(Opts) :- 
        (groundL1(Opts) -> buildGroundLabOptSet(OptSet) ; buildLabOptSet(OptSet)), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).

groundL1(L) :- 
        L == [], !.
groundL1([H|T]) :- 
        ((ground(H) ; nonvar(H)) -> groundL1(T)).


ordU_subset([], _).
ordU_subset([H|T1], [H|T2]) :- ordU_subset(T1, T2).
ordU_subset([H1|T1], [H2|T2]) :- lt(H2, H1), ordU_subset([H1|T1], T2).

lt(X, Y) :- var(X); var(Y).
lt(X, Y) :- nonvar(X), nonvar(Y), X @< Y.


buildLabOptSet(OptSet) :- 
        ordU_member(G1, [ff, ffc, leftmost, maxi, mini]), 
        ordU_member(G2, [bisect, down, enum, step, up]), 
        ordU_member(G3, [assumptions(K)]), 
        list_to_ord_set([G1, G2, G3], OptSet).

buildGroundLabOptSet(OptSet) :- 
        ordU_member(G1, [ff, ffc, leftmost, maxi, mini]), 
        ordU_member(G2, [bisect, down, enum, step, up]), 
        ordU_member(G3, [each(X), toMaximize(Y), toMinimize(Z)]), 
        ordU_member(G4, [assumptions(K)]), 
        list_to_ord_set([G1, G2, G3, G4], OptSet).


ordU_member(X, [X|_T]).
ordU_member(X, [Y|T]) :- lt(Y, X), ordU_member(X, T).

translateLabOptions([], []) :- !.
translateLabOptions([mini|As], [min|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([maxi|As], [max|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([toMinimize(X)|As], [minimize(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([toMaximize(X)|As], [maximize(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
   %%Antonio Ojo, 'each' se traduce a 'all'
translateLabOptions([each(X)|As], [all(X)|Bs]) :- 
        !, translateLabOptions(As, Bs).
translateLabOptions([Option|As], [Option|Bs]) :- 
        !, translateLabOptions(As, Bs).


% indomain :: int -> bool
% indomain :=: inout -> inout
'$indomain'(I, true, Cin, Cout) :- 
%B::Sonia
%         hnf(I, HI, Cin, Cout), 
         hnf(I, HI, Cin, Cout1), 
         toSolverFD(HI,Cout1,Cout),
%E::Sonia
         indomain(HI).

% fdminimize
'$fdminimize'(B, I, true, Cin, Cout) :- 
         hnf(B, HB, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         minimize(HB, HI).

%%%%Antonio 17/01/02 20:00
%%%%%%%%%%%%% OJO, no funciona exactamente como en SICSTus (comprobar)
% fdmaximize
'$fdmaximize'(B, I, true, Cin, Cout) :- 
         hnf(B, HB, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         maximize(HB, HI).


%%%%%%%%%%%%%% RELATIONAL CONSTRAINTS  %%%%%%%%%%%%%%%%%

%% B Sonia
/*      comento todo y lo reescribo de nuevo   
        
% #= :: int -> int -> bool
% #= :=: inout -> inout -> inout
$#=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #=  HR);
         (Out=false, HL #\= HR)). 
       
% #\= :: int -> int -> bool
% #\= :=: inout -> inout -> inout
$#\=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #\= HR);
         (Out=false, HL #=  HR)). 
      
% #< :: int -> int -> bool
% #< :=: inout -> inout -> inout
$#<(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #<  HR);
         (Out=false, HL #>= HR)). 

% #<= :: int -> int -> bool
% #<= :=: inout -> inout -> inout
$#<=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #=< HR);
         (Out=false, HL #> HR)). 
    
% #> :: int -> int -> bool
% #> :=: inout -> inout -> inout
$#>(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #> HR);
         (Out=false, HL #=< HR)). 

% #>= :: int -> int -> bool
% #>= :=: inout -> inout -> inout
$#>=(L, R, Out, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        ((Out=true, HL #>= HR);
         (Out=false, HL #< HR)). 

FIN DE LA PARTE COMENTADA */

%FSP06-02-2007 ::B
$#=(L, R, Out, Cin, Cout) :- 
      '$$eqFun'(L, R, Out, Cin, Cout).
       
% #\= :: int -> int -> bool
% #\= :=: inout -> inout -> inout
$#\=(L, R, Out, Cin, Cout) :- 
      '$$notEqFun'(L, R, Out, Cin, Cout).
%::E         
         
% #>
% #>
$#>(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #>  HR);
       (Out=false, HL #=< HR)), 
    (prop_active -> (
         searchVarsR(HL,Cout4,Cout5,HLR), 
         searchVarsR(HR,Cout5,Cout,HRR),
         ((Out == true, { HLR > HRR },!);
          (Out == false, { HLR =< HRR },!)
         )
        ); Cout=Cout4
    ). 


% #<
$#<(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #<  HR);
       (Out=false, HL #>= HR)),       
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR < HRR },!);
         (Out == false, { HLR >= HRR },!)
        )
        ); Cout=Cout4
    ). 


% #>=
$#>=(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #>= HR);
       (Out=false, HL #< HR)),
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR >= HRR },!);
         (Out == false, { HLR < HRR },!)
        )
        ); Cout=Cout4
    ). 

% #<=
$#<=(L, R, Out, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      ((Out=true,  HL #=< HR);
       (Out=false, HL #> HR)),
    (prop_active -> (
        searchVarsR(HL,Cout4,Cout5,HLR), 
        searchVarsR(HR,Cout5,Cout,HRR),
        ((Out == true, { HLR =< HRR },!);
         (Out == false, { HLR > HRR },!)
        )
        ); Cout=Cout4
    ). 

%% E Sonia

  
%%%%%%%%%%%%%%%% ARITHMETIC CONSTRAINT OPERATORS %%%%%%%%%%%%%%%%%%%%%%

%% B Sonia
/*  comento todo y lo reescribo de nuevo  

% #+ :: int -> int -> int
% #+ :=: inout -> inout -> inout
$#+(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL + HR #= O.
 
% #- :: int -> int -> int
% #- :=: inout -> inout -> inout
$#-(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL - HR #= O.       

% #* :: int -> int -> int
% #* :=: inout -> inout -> inout
$#*(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL * HR #= O.
        
% #/ :: int -> int -> int
% #/ :=: inout -> inout -> inout
$#/(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL / HR #= O.

% #& :: int -> int -> int
% #& :=: inout -> inout -> inout
$#&(L, R, O, Cin, Cout) :- 
        hnf(L, HL, Cin, Cout1), 
        hnf(R, HR, Cout1, Cout), 
        HL mod HR #= O. 

FIN DE LA PARTE COMENTADA*/
    
% #+
$#+(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL + HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR + HRR = OR }
        ); Cout=Cout5 
    ).

% #-
$#-(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL - HR #= O,   
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR - HRR = OR }
        ); Cout=Cout5 
    ).

% #*
$#*(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL * HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR * HRR = OR }
        ); Cout=Cout5 
    ).

% #/
$#/(L, R, O, Cin, Cout):-
      hnf(L, HL, Cin, Cout1),
      hnf(R, HR, Cout1, Cout2),
      toSolverFD(HL,Cout2,Cout3),
      toSolverFD(HR,Cout3,Cout4),
      toSolverFD(O,Cout4,Cout5),
      HL / HR #= O,
    (prop_active -> (
        searchVarsR(HL,Cout5,Cout6,HLR), 
        searchVarsR(HR,Cout6,Cout7,HRR),
        $#==(O, OR, true, Cout7, Cout), 
        { HLR / HRR = OR }
        ); Cout=Cout5 
    ).

%% E Sonia   

% #& :: int -> int -> int
% #& :=: inout -> inout -> inout
$#&(L, R, O, Cin, Cout) :- 
     hnf(L, HL, Cin, Cout1), 
     hnf(R, HR, Cout1, Cout2), 
     toSolverFD(HL,Cout2,Cout3),
     toSolverFD(HR,Cout3,Cout4),
     toSolverFD(O,Cout4,Cout),
     HL mod HR #= O.

%%%%%%%%%%%%%%%%%%% ARITHMETIC CONSTRAINTS  %%%%%%%%%%%%%%%%%%%%%

% sum :: [int] -> (int -> int -> bool) -> int -> bool
% sum :=: [inout] -> inout -> inout
'$sum'(VL, Op, O, Out, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error(sum,1)); true),
        hnf(Op, HOp, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%::B Sonia
%        nf(O,HO,Cout2,Cout),    
        nf(O,HO,Cout2,Cout3),    
        toSolverFD(HO,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout),
%::E Sonia
        ((Out=true, relOp(Op), sum(PrologHVL, HOp, HO));
         (Out=false, negRelOp(HOp, HNOp), sum(PrologHVL, HNOp, HO))). 

% scalar_product :: [int] -> [int] -> (int -> int -> bool) -> int -> bool
% scalar_product :=: [inout] -> [inout] -> inout -> inout -> inout
'$scalar_product'(VL1, VL2, Op, O, Out, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        (var(HVL1) -> raise_exception(instatiation_error(scalar_product,1)); true),
        nf(VL2, HVL2, Cout1, Cout2), 
        (var(HVL2) -> raise_exception(instatiation_error(scalar_product,2)); true),
        hnf(Op, HOp, Cout2, Cout3), 
%B:: Sonia        
%        nf(O, HO, Cout3, Cout), 
        nf(O, HO, Cout3, Cout4), 
%E:: Sonia        
        toyListToPrologList(HVL1, PrologHVL1), 
        toyListToPrologList(HVL2, PrologHVL2), 
%B:: Sonia        
        listToSolverFD(PrologHVL1,Cout4,Cout5),
        listToSolverFD(PrologHVL2,Cout5,Cout6),
        toSolverFD(HO,Cout6,Cout),
%E:: Sonia        
        ((Out=true, relOp(Op), scalar_product(PrologHVL1, PrologHVL2, HOp, HO));
         (Out=false, negRelOp(HOp, HNOp), scalar_product(PrologHVL1, PrologHVL2, HNOp, HO))). 
        
        
        
%%%%%%%%%%%%%%%%%%% COMBINATORIAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%

% all_different :: [int] ->  bool
% all_different :=: [inout] ->  inout
'$all_different'(VL, true, Cin, Cout) :- 
%B:: Sonia        
%        nf(VL, HVL, Cin, Cout), 
        nf(VL, HVL, Cin, Cout1), 
%E:: Sonia        
        (var(HVL) -> raise_exception(instatiation_error(all_different,1)); true),
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout1,Cout),
%E:: Sonia        

        all_different(PrologHVL).


% all_different' :: [int] -> [options] -> bool
% all_different' :=: [inout] ->  inout ->  inout
'$all_different\''(VL, OL, true, Cin, Cout) :- 
        nf(VL, HVL, Cin, Cout1), 
        (var(HVL) -> raise_exception(instatiation_error('all_different\'',1)); true),
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
%        nf(OL, HOL, Cout1, Cout), 
        nf(OL, HOL, Cout1, Cout2), 
%E:: Sonia        
        toyListToPrologList(HOL, PrologHOL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout2,Cout),
%E:: Sonia        
        processDiffOptions(PrologHOL, DiffPrologHOL), 
        all_different(PrologHVL, DiffPrologHOL), 
        translateDiffOptions(DiffToyHOL, DiffPrologHOL), 
        toyNonVarListToPrologList(OL, DiffToyHOL).

processDiffOptions(TLs, PLs) :- 
        setof(TLs, validDiffOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateDiffOptions(TLs, PLs).

validDiffOptions(Opts) :- 
        buildDiffOptSet(OptSet), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).

buildDiffOptSet(OptSet) :- 
        ordU_member(G1, [on(value), on(domain), on(range)]), 
        ordU_member(G2, [complete(true), complete(false)]), 
        list_to_ord_set([G1, G2], OptSet).

translateDiffOptions([], []) :- !.
translateDiffOptions([domains|As], [domain|Bs]) :- 
        !, translateDiffOptions(As, Bs).
translateDiffOptions([Option|As], [Option|Bs]) :- 
        !, translateDiffOptions(As, Bs).


       
% assignment :: [int] -> [int] -> bool
% assignment :=: [inout] -> [inout] -> inout
'$assignment'(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        (var(HVL1) -> raise_exception(instatiation_error(assignment,1)); true),
        toyListToPrologList(HVL1, PrologHVL1), 
%B:: Sonia        
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
%B:: Sonia        
        (var(HVL2) -> raise_exception(instatiation_error(assignment,2)); true),
        toyListToPrologList(HVL2, PrologHVL2), 
%B:: Sonia        
        listToSolverFD(PrologHVL1,Cout2,Cout3),
        listToSolverFD(PrologHVL2,Cout3,Cout),
%E:: Sonia        
        assignment(PrologHVL1, PrologHVL2).
        

% circuit :: [int] -> bool
% circuit :=: [inout] -> inout
'$circuit'(VL, true, Cin, Cout) :- 
%B:: Sonia        
%        nf(VL, HVL, Cin, Cout), 
        nf(VL, HVL, Cin, Cout1), 
%E:: Sonia        
        toyListToPrologList(HVL, PrologHVL), 
%B:: Sonia        
        listToSolverFD(PrologHVL,Cout1,Cout),
%E:: Sonia        
        circuit(PrologHVL).

% circuit' :: [int] -> [int] -> bool
% circuit' :=: [inout] -> [inout] -> inout
'$circuit\''(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
%B:: Sonia        
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
        listToSolverFD(PrologHVL1,Cout2,Cout),
%E:: Sonia        
        toyListToPrologList(HVL2, PrologHVL2), 
        circuit(PrologHVL1, PrologHVL2).


% count :: int -> [int] -> (int -> int -> bool) ->  int -> bool
% count :: in -> inout -> inout -> inout -> inout
'$count'(V, VL, Op, O, true, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        (var(HV) -> raise_exception(instatiation_error(count,1)); true),
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(Op, HOp, Cout2, Cout), 
        hnf(Op, HOp, Cout2, Cout3),
        toSolverFD(HV,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout5),
        toSolverFD(O,Cout5,Cout),
%E::Sonia
        relOp(HOp), 
        count(HV, PrologHVL, HOp, O),
        toyListToPrologList(HVL, PrologHVL).

       
% element :: int -> [int] -> int -> bool
% element :=: inout -> [inout] -> inout -> inout
'$element'(I, VL, V, true, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout1), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(V, HV, Cout2, Cout), 
        hnf(V, HV, Cout2, Cout3),
        toSolverFD(HI,Cout3,Cout4),
        toSolverFD(HV,Cout4,Cout5),
        listToSolverFD(PrologHVL,Cout5,Cout),
%E::Sonia
        element(HI, PrologHVL, HV).
        
% exactly :: int -> [int] -> int -> bool
% exactly :=: inout -> inout -> inout -> inout
'$exactly'(NEle, VL, N, true, Cin, Cout) :- 
        hnf(NEle, HNEle, Cin, Cout1), 
        nf(VL, HVL, Cout1, Cout2), 
        toyListToPrologList(HVL, PrologHVL), 
%B::Sonia
%        hnf(N, HN, Cout2, Cout), 
        hnf(N, HN, Cout2, Cout3), 
        toSolverFD(HNEle,Cout3,Cout4),
        listToSolverFD(PrologHVL,Cout4,Cout5),
        toSolverFD(HNEle,Cout5,Cout),        
%E::Sonia
        exactly(HNEle, PrologHVL, HN),
        toyListToPrologList(HVL, PrologHVL). 

exactly(_, [], 0).
exactly(X, [Y|L], N) :- 
        X #=Y #<=> B, 
        N #= M + B, 
        exactly(X, L, M).


% serialized :: [int] -> [int] -> bool
% serialized :=: [inout] -> [inout] -> inout
'$serialized'(VL1, VL2, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
%B::Sonia
%        nf(VL2, HVL2, Cout1, Cout), 
        nf(VL2, HVL2, Cout1, Cout2), 
%E::Sonia
        toyListToPrologList(HVL2, PrologHVL2), 
%B::Sonia
        listToSolverFD(PrologHVL1,Cout2,Cout3),
        listToSolverFD(PrologHVL2,Cout3,Cout),
%E::Sonia
        serialized(PrologHVL1, PrologHVL2).


% 'serialized\'' :: [int] -> [int] -> [serialOptions] -> bool
% 'serialized\'' :=: [inout] -> [inout] -> inout -> inout
'$serialized\''(VL1, VL2, OL, true, Cin, Cout) :- 
        nf(VL1, HVL1, Cin, Cout1), 
        toyListToPrologList(HVL1, PrologHVL1), 
        nf(VL2, HVL2, Cout1, Cout2), 
        toyListToPrologList(HVL2, PrologHVL2), 
        nf(OL, HOL, Cout2, Cout3), 
        toyListToPrologList(HOL, PrologHOL), 
        processSchedulingOptions(PrologHOL, SchedPrologHOL, Cout3, Cout4), 
        serialized(PrologHVL1, PrologHVL2, SchedPrologHOL), 
%B::Sonia
%        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout4, Cout), 
        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout4, Cout5),       
        listToSolverFD(PrologHVL1,Cout5,Cout6),
        listToSolverFD(PrologHVL2,Cout6,Cout),
%E::Sonia
        toyNonVarListToPrologList(OL, SchedToyHOL).


% cumulative :: [int] ->  [int] ->  [int] -> int  -> bool
% cumulative :=: [inout] -> [inout] -> [inout] -> inout -> inout
'$cumulative'(SL, DL, RL, LIM, true, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout1), 
        toyListToPrologList(HSL, PrologHSL), 
        nf(DL, HDL, Cout1, Cout2), 
        toyListToPrologList(HDL, PrologHDL), 
        nf(RL, HRL, Cout2, Cout3), 
        toyListToPrologList(HRL, PrologHRL), 
        hnf(LIM, HLIM, Cout3, Cout4), 
%B::Sonia
%        hnf(LIM, HLIM, Cout3, Cout), 
        hnf(LIM, HLIM, Cout3, Cout4), 
        listToSolverFD(PrologHSL,Cout4,Cout5),
        listToSolverFD(PrologHDL,Cout5,Cout6),
        listToSolverFD(PrologHRL,Cout6,Cout7),
        toSolverFD(HLIM,Cout7,Cout),
%E::Sonia
        cumulative(PrologHSL, PrologHDL, PrologHRL, HLIM).

% 'cumulative\'' :: [int] ->  [int] ->  [int] -> int  -> [serialOptions] -> bool
% 'cumulative\'' :=: [inout] -> [inout] -> [inout] -> inout -> inout -> inout
'$cumulative\''(SL, DL, RL, Lim, OL, true, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout1), 
        toyListToPrologList(HSL, PrologHSL), 
        nf(DL, HDL, Cout1, Cout2), 
        toyListToPrologList(HDL, PrologHDL), 
        nf(RL, HRL, Cout2, Cout3), 
        toyListToPrologList(HRL, PrologHRL), 
        hnf(Lim, HLim, Cout3, Cout4), 
        nf(OL, HOL, Cout4, Cout5), 
        toyListToPrologList(HOL, PrologHOL), 
        processSchedulingOptions(PrologHOL, SchedPrologHOL, Cout5, Cout6), 
        cumulative(PrologHSL, PrologHDL, PrologHRL, HLim, SchedPrologHOL), 
%B::Sonia
%        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout6, Cout), 
        translateSchedOptions(SchedToyHOL, SchedPrologHOL, Cout6, Cout7), 
        listToSolverFD(PrologHSL,Cout7,Cout8),
        listToSolverFD(PrologHDL,Cout8,Cout9),
        listToSolverFD(PrologHRL,Cout9,Cout10),
        toSolverFD(HLim,Cout10,Cout),
%E::Sonia
        toyNonVarListToPrologList(OL, SchedToyHOL).

 
processSchedulingOptions(TLs, PLs, Cin, Cout) :- 
        setof(TLs, validSchedOptions(TLs), Os), 
        removeU_duplicates(Os, Ss), 
        memberU(TLs, Ss), 
        translateSchedOptions(TLs, PLs, Cin, Cout).


validSchedOptions(Opts) :- 
        (groundL1(Opts) -> buildGroundSchedOptSet(OptSet) ; buildSchedOptSet(OptSet)), 
        ordU_subset(OptSubSet, OptSet), 
        permutation(OptSubSet, Opts).


buildSchedOptSet(OptSet) :- 
        OptSet = [
                  decomposition(true), 
                  edge_finder(true), 
                  path_consistency(true), 
                  static_sets(true)
                 ]. % This must be an ordered list

buildGroundSchedOptSet(OptSet) :- 
        OptSet = [
                  decomposition(true), 
                  edge_finder(true), 
                  path_consistency(true), 
                  precedences(L), 
                  static_sets(true)
                 ]. % This must be an ordered list


translateSchedOptions([], [], C, C) :- !.
translateSchedOptions([precedences(T)|Ls], [precedences(T1)|Lss], Cin, Cout) :- 
        !, hnf(T, TT, Cin, Cout1), 
        toyListToPrologList(TT, TTT), 
        process_precedences(TTT, T1), 
        translateSchedOptions(Ls, Lss, Cout1, Cout).
translateSchedOptions([Option|As], [Option|Bs], Cin, Cout) :- 
        !, translateSchedOptions(As, Bs, Cin, Cout).


process_precedences([], []).
process_precedences([d('$$tup'((I1, I2, I3)))|Ls], [d(I1, I2, O3)|Lss]) :- 
        !, process_value(I3, O3), 
        process_precedences(Ls, Lss).
process_precedences([X|Ls], [X|Lss]) :- process_precedences(Ls, Lss).

process_value(lift(I3), I3).
process_value(superior, sup).


%%%%%%%%%%%%%%%%%%% PROPOSITIONAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%

% #\/  :: bool -> bool -> bool
% #\/  :=: inout -> inout -> inout
$#\/(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #\/ HRINT.

% #<=> :: bool -> bool -> bool
% #<=> :=: inout -> inout -> inout
$#<=>(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #<=> HRINT.

% #=> :: bool -> bool -> bool
% #=> :=: inout -> inout -> inout
$#=>(L, R, true, Cin, Cout) :- 
        nf(L, HL, Cin, Cout1), 
%B:: Sonia
%        nf(R, HR, Cout1, Cout), 
        nf(R, HR, Cout1, Cout2), 
        toSolverFD(HL,Cout2,Cout3),
        toSolverFD(HR,Cout3,Cout),
%E:: Sonia
        bool_to_int(HL, HLINT), 
        bool_to_int(HR, HRINT), 
        HLINT #=> HRINT.


%%%%%%%%%%%%%%%%%%% REFLECTION FUNCTIONS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% fd_var :: int -> bool
% fd_var :=: inout -> inout
'$fd_var'(V, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        (fd_var(HV) -> Out = true; Out=false).
        
% fd_min :: int -> int
% fd_min :=: inout -> inout
'$fd_min'(I, Min, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout), 
        fd_min(HI, Min).

% fd_max :: int -> int
% fd_max :=: inout -> inout
'$fd_max'(I, Max, Cin, Cout) :- 
        hnf(I, HI, Cin, Cout), 
        fd_max(HI, Max).

% fd_size :: int -> int
% fd_size :=: inout -> inout
'$fd_size'(V, S, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_size(HV, S).

% fd_set :: int -> fdset
% fd_set :=: inout -> inout
'$fd_set'(V, S, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_set(HV, PS), 
        toySetToPrologSet(S, PS).

% fd_dom :: int -> range
% fd_dom :=: inout -> inout
'$fd_dom'(V, R, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_dom(HV, PR), 
        toyRangeToPrologRange(R, PR).

% fd_degree :: int -> int
% fd_degree :=: inout -> inout
'$fd_degree'(V, I, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_degree(HV, I).
       
% fd_neighbors :: int -> [int]
% fd_neighbors :=: inout -> inout
'$fd_neighbors'(V, L, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout), 
        fd_neighbors(HV, PL),
        toyListToPrologList(L, PL).          
        
% fd_closure :: [int] -> [int]
% fd_neighbors :=: [inout] -> [inout]
'$fd_closure'(L1, L2, Cin, Cout) :- 
        nf(L1, HL1, Cin, Cout), 
        (var(HL1) -> raise_exception(instatiation_error(fd_closure,1)); true),
        toyListToPrologList(HL1, PHL1), 
        fd_closure(PHL1, PL2), 
        toyListToPrologList(L2, PL2).
        
% sup :: int
% sup :=: {}
'$sup'(X, Cin, Cin) :- cflpfd:sup(X).

% inf :: int
% inf :: {}
'$inf'(X, Cin, Cin) :- cflpfd:inf(X).


%%%%%%%%%%%%%%%%%%% FD SET FUNCTIONS  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% is_fdset :: fdset -> bool
% is_fdset :=: in -> inout
'$is_fdset'(S, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS,PS),
        (is_fdset(PS) -> Out = true; Out = false).     
        
% empty_fdset :: fdset -> bool
% empty_fdset :=: inout -> inout
'$empty_fdset'(S, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        ((Out=true, empty_fdset(HS), Cout1=Cout); 
         (Out=false, (var(HS) -> notEqualVar(HS,[],Cout1,Cout) ) ) ).

% fdset_parts :: int -> int -> fdset -> fdset
% fdset_parts :=: in  -> in  -> in  -> inout
'$fdset_parts'(Min, Max, P, S, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout2), 
        nf(P, HP, Cout2, Cout), 
        toySetToPrologSet(HP, PP),
        fdset_parts(PS, HMin, HMax, PP),
        toySetToPrologSet(S, PS).

% fdset_split :: fdset -> (int -> int -> fdset)
% fdset_split :=: in  -> (inout -> inout -> inout)
'$fdset_split'(S, '$$tup'(','(Min, ','(Max, P))), Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        toySetToPrologSet(HS, PS),
        fdset_parts(PS, Min, Max, PP),
        toySetToPrologSet(P, PP).

% empty_interval :: int -> int -> bool
% empty_interval :=: in -> in -> inout
'$empty_interval'(Min, Max, Out, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout), 
        (var(HMin) -> raise_exception(instatiation_error(empty_interval,1)); true),
        (var(HMax) -> raise_exception(instatiation_error(empty_interval,2)); true),
        (empty_interval(HMin, HMax) -> Out = true; Out = false).

% fdset_to_interval :: fdset -> (int, int)
% fdset_to_interval :=: in -> (inout, inout)
'$fdset_to_interval'(S, '$$tup'(','(Min, Max)), Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_interval(PS, Min, Max).

% interval_to_fdset :: int -> int -> fdset
% interval_to_fdset :=: in -> in -> inout
'$interval_to_fdset'(Min, Max, S, Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout), 
        (var(HMin) -> raise_exception(instatiation_error(interval_to_fdset,1)); true),
        (var(HMax) -> raise_exception(instatiation_error(interval_to_fdset,2)); true),
        fdset_interval(PS, HMin, HMax), 
        toySetToPrologSet(S, PS).

% fdset_singleton :: fdset -> int -> bool
% fdset_singleton :=: {in -> out -> out, out -> in -> out}
'$fdset_singleton'(S, E, Out, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(E, HE, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        (fdset_singleton(PS, HE) -> 
         (Out = true, toySetToPrologSet(HS, PS)); 
         Out = false).

% fdset_min :: fdset -> int 
% fdset_min :=: in -> inout
'$fdset_min'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_min(PS, I).
        
% fdset_max :: fdset -> int
% fdset_max :=: in -> inout
'$fdset_max'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_max(PS, I).

% fdset_size :: fdset -> int
% fdset_size :=: in -> inout
'$fdset_size'(S, I, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_size(PS, I).
     
% list_to_fdset :: [int] -> fdset
% list_to_fdset :=: in -> inout
'$list_to_fdset'(L, S, Cin, Cout) :- 
        nf(L, HL, Cin, Cout),
        toyListToPrologList(HL, PHL), 
        list_to_fdset(PHL, PS), 
        toySetToPrologSet(S, PS).
        
% fdset_to_list :: fdset -> [int]
% fdset_to_list :=: in -> inout
'$fdset_to_list'(S, L, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS), 
        fdset_to_list(PS, PL), 
        toyListToPrologList(L, PL).

% range_to_fdset :: range -> fdset
% range_to_fdset :=: in -> inout
'$range_to_fdset'(R, S, Cin, Cout) :- 
        nf(R, HR, Cin, Cout), 
        toyRangeToPrologRange(HR, PR), 
        range_to_fdset(PR, PS), 
        toySetToPrologSet(S, PS).

% fdset_to_range :: fdset -> range
% fdset_to_range :=: in -> inout
'$fdset_to_range'(S, R, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS), 
        fdset_to_range(PS, PR), 
        toyRangeToPrologRange(R, PR).

% fdset_add_element :: fdset -> int -> fdset 
% fdset_add_element :=: in -> in -> inout
'$fdset_add_element'(S, I, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(I, HI, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_add_element(PS, HI, PO),
        toySetToPrologSet(O, PO). 

% fdset_del_element :: fdset -> int -> fdset 
% fdset_del_element :=: in -> in -> inout
'$fdset_del_element'(S, I, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout1), 
        hnf(I, HI, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_del_element(PS, HI, PO),
        toySetToPrologSet(O, PO). 

% fdset_intersection :: fdset -> fdset -> fdset
% fdset_intersection :=: in -> in -> inout
'$fdset_intersection'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_intersection(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_subtract :: fdset -> fdset -> fdset
% fdset_subtract :=: in -> in -> inout
'$fdset_subtract'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_subtract(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_union :: fdset -> fdset -> fdset
% fdset_union :=: in -> in -> inout
'$fdset_union'(S1, S2, SO, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        fdset_union(PS1, PS2, PSO),
        toySetToPrologSet(SO, PSO). 

% fdset_complement :: fdset -> fdset
% fdset_complement :=: in -> inout
'$fdset_complement'(S, O, Cin, Cout) :- 
        nf(S, HS, Cin, Cout), 
        toySetToPrologSet(HS, PS),
        fdset_complement(PS, PO),
        toySetToPrologSet(O, PO). 

% fdsets_intersection :: [fdset] -> fdset
% fdsets_intersection :=: in -> inout
'$fdsets_intersection'(SL, O, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout), 
        toyListSetToPrologListSet(HSL, PSL),
        fdset_intersection(PSL, PO),
        toySetToPrologSet(O, PO). 

% fdsets_union :: [fdset] -> fdset
% fdsets_union :=: in -> inout
'$fdsets_union'(SL, O, Cin, Cout) :- 
        nf(SL, HSL, Cin, Cout), 
        toyListSetToPrologListSet(HSL, PSL),
        fdset_union(PSL, PO),
        toySetToPrologSet(O, PO).

% fdset_equal :: fdset -> fdset-> bool
% fdset_equal :=: in -> in -> inout
'$fdset_equal'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_eq(PS1, PS2) -> Out = true; Out = false).

% fdset_subset :: fdset -> fdset-> bool
% fdset_subset :=: in -> in -> inout
'$fdset_subset'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_subset(PS1, PS2) -> Out = true; Out = false).

% fdset_disjoint :: fdset -> fdset-> bool
% fdset_disjoint :=: in -> in -> inout
'$fdset_disjoint'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_disjoint(PS1, PS2) -> Out = true; Out = false).
  
% fdset_intersect :: fdset -> fdset-> bool
% fdset_intersect :=: in -> in -> inout
'$fdset_intersect'(S1, S2, Out, Cin, Cout) :- 
        nf(S1, HS1, Cin, Cout1), 
        nf(S2, HS2, Cout1, Cout), 
        toySetToPrologSet(HS1, PS1),
        toySetToPrologSet(HS2, PS2),
        (fdset_intersect(PS1, PS2) -> Out = true; Out = false).

% fdset_member :: int -> fdset -> bool
% fdset_member :=: inout -> in -> inout
'$fdset_member'(V, S, Out, Cin, Cout) :- 
        hnf(V, HV, Cin, Cout1), 
        nf(S, HS, Cout1, Cout), 
        toySetToPrologSet(HS, PS),
        ((Out = true, fdset_member(HV, PS)); 
         Out = false).

% fdset_belongs :: int -> int -> bool
% fdset_belongs :=: inout -> in -> inout
'$fdset_belongs'(X, Y, Out, Cin, Cout) :- 
        hnf(X, HX, Cin, Cout1), 
        hnf(Y, HY, Cout1, Cout), 
        fd_set(HY, PS),
        ((Out = true, fdset_member(HX, PS)); 
         Out = false).


traduction(domm(X), dom(X)).
traduction(minn(X), min(X)).
traduction(maxx(X), max(X)).
traduction(vall(X), val(X)).
traduction(minmax(X), minmax(X)).

traduce_list([], []).
traduce_list([X|Xs], [Y|Ys]) :- traduction(X, Y), traduce_list(Xs, Ys).

traduce_args([], []).
traduce_args([X:Xs|Rs], [Y|Ys]) :- toyListToPrologList(X:Xs, Y), !, 
        traduce_args(Rs, Ys).
traduce_args([X|Rs], [X|Ys]) :- traduce_args(Rs, Ys).

% fd_global
%'$fd_global'(_A, _B, _C, true, _D, _E) :- 
%        hnf(_A, _A1, _D, _F), 
%
%        hnf(_B, _BB, _F, _I), %%_B = st('$$tup'((Args)))
%        _BB=..[st, Tuple], 
%         printf("\n Tuple = %w \n", [Tuple]), 
%        Tuple =..['$$tup', Ar], %% Tuple = '$$tup'(Args)
%        printf("\n Ar = %w \n", [Ar]), 
%        Ar =..[C|Args], %% C = '.', 
%         printf("\n Args = %w \n", [Args]), 
%        traduce_args(Args, PrologArgs), 
%         printf("\n PrologArgs = %w \n", [PrologArgs]), 
%        _B1  =..[st|PrologArgs], 
%        
%        hnf(_C, _CC, _I, _E), 
%        toyListToPrologList(_CC, CCC), 
%        printf("\n Las variables son _AA = %w \n  _BB = %w \n  _CC = %w \n", [_AA, _BB, _CC]), 
%        printf("\n                                        PrologCC = %w \n", [PrologCC]), 
%        traduce_list(CCC, C1), 
%        printf("\n Las variables son _A1 = %w \n  _B1 = %w \n  _C1 = %w \n", [_A1, _B1, C1]), 
%        fd_global(_A1, _B1, C1).   

% fd_global
'$fd_global'(_A, _B, _C, _O, _D, _E) :- 
        hnf(_A, _A1, _D, _F), 
        hnf(_B, _BB, _F, _I), %%_B = st('$$tup'((Args)))
        _BB=..[st, Tuple], 
        Tuple =..['$$tup', Ar], %% Tuple = '$$tup'(Args)
        Ar =..[C|Args], %% C = '.', 
        traduce_args(Args, PrologArgs), 
        _B1  =..[st|PrologArgs], 
        hnf(_C, _CC, _I, _E), 
        toyListToPrologList(_CC, CCC), 
        traduce_list(CCC, C1), 
        printf("\n Las variables son _A1 = %w \n  _B1 = %w \n  _C1 = %w \n", [_A1, _B1, C1]), 
        fd_global(A1, _B1, C1).   


%%%%%%%%%%%%%%%%%%% INDEXICAL CONSTRAINTS %%%%%%%%%%%%%%%%%%%%%%%

% isin
'$isin'(_A, _B, true, _C, _D) :- 
        hnf(_B, '$$tup'(_E), _C, _F), 
        hnf(_E, ', '(_G, _H), _F, _F1), 
        hnf(_G, _GG, _F1, _F2), 
        hnf(_H, _HH, _F2, _F3), 
        hnf(_A, _AA, _F3, _D), 
        lanzar(_AA, _GG, _HH).
        
lanzar(_AA, _GG, _HH)+:        
        _GG=..[min, _YY], 
        _AA in min(_YY).._HH.
        
%%:- use_module(library(charsio)).        

%infixl mini  
%infix(<<<, left, 11).
%%

% minimum
'$minimum'(_A, min(_AA), _C, _D) :- 
        hnf(_A, _AA, _C, _C1), 
        printf("\n Las variables son _AA = %w\n", [_AA]).


%%%%%%%%%%%%%%%%%%% STATISTICS FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%

% fd_statistics' :: statistics -> int
% fd_statistics' :=: inout -> inout
'$fd_statistics\''(S, I, Cin, Cout) :- 
         hnf(S, HS, Cin, Cout1), 
         hnf(I, HI, Cout1, Cout), 
         fd_statistics(HS, HI).

% 'fd_statistics' :: bool
% 'fd_statistics' :=: inout
'$fd_statistics'(true, Cin, Cin) :- 
         fd_statistics.


%%%%%%%%%%%% Auxiliary Predicates   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%float_to_int(F,I) :- freeze(F, I is integer(F)), freeze(I, F is float(I)).

bool_to_int(B, I) :- 
        freeze(B, (B = false -> I = 0 ; I = 1)), 
        freeze(I, (I = 0 -> B = false ; B = true)).


relOp(Op) :- negRelOp(Op, _).

negRelOp(#=, #\=).
negRelOp(#\=, #=).
negRelOp(#<, #>=).
negRelOp(#<=, #>).
negRelOp(#>, #<=).
negRelOp(#>=, #<).



/*
hnfList(L, HL, Cin, Cout) :- 
        (var(L) -> L = HL, Cin = Cout; hnfListR(L, HL, Cin, Cout)).

hnfListR([], [], C, C).
hnfListR(H:T, NH:NT, Cin, Cout) :- 
        hnf(H, NH, Cin, Cout1), 
        hnfListR(T, NT, Cout1, Cout).


%% Prolog FD Sets come implemented as lists of [Min|Max] elements
%% Toy FD Sets are implemented as Toy lists of (interval Min Max) elements


hnfSet(S, HS, Cin, Cout) :- 
        (var(S) -> S = HS, Cin = Cout; hnfSetR(S, HS, Cin, Cout)).

hnfSetR([], [], C, C) :- !.
hnfSetR(:(interval(Min,Max), T), :(interval(HMin,HMax), HT), Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1), 
        hnf(Max, HMax, Cout1, Cout2), 
        hnfSetR(T, HT, Cout2, Cout).


% Prolog FD Ranges come implemented as conjunctions (R1/\R2), disjunctions (R1\/R2), 
%   and complement (\R) of ranges, where a range can also be a constant range (Min..Max)
% Toy FD Ranges are implemented as unions (uni(R1,R2)), intersections (inter(R1,R2)), 
%   and complement (compl(R)) of ranges, where a range can also be a constant range (cte(Min,Max))

hnfRange(R, HR, Cin, Cout) :- 
        (var(R) -> R = HR, Cin = Cout; hnfRangeR(R, HR, Cin, Cout)).

hnfRangeR(cte(Min, Max), cte(HMin, HMax), Cin, Cout) :- 
        hnf(Min, HMin, Cin, Cout1),
        hnf(Max, HMax, Cout1, Cout), !.
hnfRangeR(uni(R1, R2), uni(HR1, HR2), Cin, Cout) :- 
        hnfRange(R1, HR1, Cin, Cout1), 
        hnfRange(R2, HR2, Cout1, Cout), !.
hnfRangeR(inter(R1, R2), inter(HR1, HR2), Cin, Cout) :- 
        hnfRange(R1, HR1, Cin, Cout1), 
        hnfRange(R2, HR2, Cout1, Cout), !.
hnfRangeR(compl(R), compl(HR), Cin, Cout) :- 
        hnfRange(R, HR, Cin, Cout), !.

*/


toyListSetToPrologListSet(TSL, PSL) :-
        (var(TSL), var(PSL) -> true; toyNonVarListSetToPrologListSet(TSL, PSL)).

toyNonVarListSetToPrologListSet([], []) :- !.
toyNonVarListSetToPrologListSet(TS:R, [PS|RR]) :- 
        toyNonVarSetToPrologSet(TS, PS),
        toyNonVarListSetToPrologListSet(R, RR).


toySetToPrologSet(TS, PS) :- 
        (var(TS), var(PS) -> true; toyNonVarSetToPrologSet(TS, PS)).
toyNonVarSetToPrologSet([], []) :- !.
toyNonVarSetToPrologSet(:(interval(Min,Max),TT), [[IMin|IMax]|PT]) :- 
        IMin = Min,
        IMax = Max,
        toyNonVarSetToPrologSet(TT, PT).

hnf_recursive(S, HS, Cin, Cout) :-
        (var(S) -> Cin=Cout; hnf_recursiveNonVar(S, HS, Cin, Cout)).

hnf_recursiveNonVar([], [], C, C) :- !.
hnf_recursiveNonVar(_B, [[_F|_G] | _Resto], Cin, Cout) :- 
        hnf(_T, interval(_F, _G), Cin, Cout1), 
        hnf_recursive(_R, _Resto, Cout1, Cout2), !, 
        hnf(_B, :(_T, _R), Cout2, Cout).
        

toyRangeToPrologRange(TR, PR) :- 
        (var(TR), var(PR) -> true; toyNonVarRangeToPrologRange(TR, PR)).
toyNonVarRangeToPrologRange(cte(Min, Max), Min..Max) :- !.
toyNonVarRangeToPrologRange(uni(TR1, TR2), PR1 \/ PR2) :- 
        toyRangeToPrologRange(TR1, PR1), 
        toyRangeToPrologRange(TR2, PR2), !.
toyNonVarRangeToPrologRange(inter(TR1, TR2), PR1 /\ PR2) :- 
        toyRangeToPrologRange(TR1, PR1), 
        toyRangeToPrologRange(TR2, PR2), !.
toyNonVarRangeToPrologRange(compl(TR), PC, Cin, Cout) :- 
        PC=..[\, PR],
        toyRangeToPrologRange(TR, PR), !.



%------      LISTS              ---------------------------------

%% Translates a Toy list (such as 1:2:3:[]) into a Prolog list ([1, 2, 3])
toyListToPrologList(Ts, Ps) :- (var(Ts), var(Ps) -> true; toyNonVarListToPrologList(Ts, Ps)).

toyNonVarListToPrologList([], []) :- !.
toyNonVarListToPrologList(A:R, [A|RR]) :- toyNonVarListToPrologList(R, RR).


% nonmember/2
nonmember(_X, []).
nonmember(X, [X|_Ys]) :- !, fail.
nonmember(X, [_Y|Ys]) :- !, nonmember(X, Ys).

%-----------------------------------------------------------------------
%-----------------------------------------------------------------------
%-----------------------------------------------------------------------
%------      INPUT/OUTPUT              ---------------------------------


%------------------- Predicates for I/O ---------------------------------------------

%------------------- Predicates for formatting ---------------------------------------

%------------------- printf: formatted ouput ----------------------------------------

% All the output generated by the program uses this printf
% procedure.

% control chars '\.'



printf([92, 110|F], Ts) :- !, nl, printf(F, Ts).  % 92, 110 = \n
printf([92, 116|F], Ts) :- !, put(9), printf(F, Ts).  % 92, 116 = \t
printf([92, 92|F], Ts) :- !, put(92), printf(F, Ts).  % 92, 92 = \\
printf([92, 37|F], Ts) :- !, put(37), printf(F, Ts).  % 92, 37 = \%
printf([92, 34|F], Ts) :- !, put(34), printf(F, Ts).  % 92, 34 = \"

% format chars '%.'

printf([37, 119|F], [T|Ts]) :- !, write_term(T, [portrayed(true)]), printf(F, Ts).  % 37, 119 = %w
printf([37, 113|F], [T|Ts]) :- !, writeq(T, [portrayed(true)]), printf(F, Ts).  % 37, 113 = %q
printf([37, 100|F], [T|Ts]) :- !, display(T), printf(F, Ts).  % 37, 100 = %d
printf([37, 115|F], [T|Ts]) :- !, puts(T), printf(F, Ts).  % 37, 115 = %s
printf([37, 118|F], [V, T|Ts]) :- !, nameTermVars(T, V, Tn), printf(F, [Tn|Ts]). % 37, 118 = %v

% plain chars '.'

printf([Ch|F], Ts) :- !, put(Ch), printf(F, Ts).

printf([], _).

printf(F) :- printf(F, []).

puts([]).
puts([Ch|S]) :- put(Ch), puts(S).


%%NEW11 To print the list L (including elements as 'X'=A) in the predicate solve.
print_list([]) :- !.
%%print_list([X=A|L]) :- X\==A, printf("    %w = %w \n", [X, A]), print_list(L).
%%print_list([X=A|L]) :- X==A, print_list(L).
print_list([(X=A)|L]) :- ground(A), 
        printf("    %w = %w \n", [X, A]), 
        print_list(L), !, 
        assert(sol(true)).   %% Indicates that a semi-solution is found
print_list([(_X=_A)|L]) :- print_list(L).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%  END OF CFLPFDFILE %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
