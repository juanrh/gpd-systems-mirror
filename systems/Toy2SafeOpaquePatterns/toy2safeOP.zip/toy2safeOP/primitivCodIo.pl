
:- module(primitivCodIo,['$openFile'/5,'$closeFile'/4,'$end_of_file'/4,'$getCharFile'/4,
          '$putCharFile'/5,'$putStrFile'/5,'$putStrLnFile'/5,'$getLineFile'/4,
          '$contin1'/5,'$contin2'/5
%          ,
%%% ::B Rafa           
%          '$dValToString'/4,'$dVal'/4,'$selectWhereVariableXi'/7,
%          '$getConstraintStore'/4,
%%% ::E
%
%% FALLO FINITO Y CORTE 
%% pacol 17-03-05
%           '$fails'/4, '$once'/4, '$collect'/4, '$collectN'/5
          ]).

:- load_files(primFunct,[if(changed),imports([errPrim/0])]).

:- load_files(primitivCod,[if(changed)]).

:- load_files(toycomm,[if(changed)]). %,imports([hnf/4,unifyHnfs/4,nf/4])]).

% :- load_files(basic,[if(changed),imports(['$$apply'/5])]).
% Esta dependencia se debia exclusivamente al codigo para 'flip',
% y generaba efectos indeseables al activar y desactivar /cflpr cuando estamos
% con la version con restricciones sobre los reales.
% Se ha eliminado, y para ello, el codigo de flip se ha llevado a
% basic.pl



% 11/05/00 mercedes
% Estos modulos se necesitan para la parte de entrada/salida

:- load_files(tools,[if(changed),imports([append/3])]).

:- load_files(codfun,[if(changed),imports([introduceSusp/3])]).

:- load_files(dyn,[if(changed),imports([assertfile/3,retractfile/3,file/3])]).

:- load_files(errortoy,[if(changed),imports([treat_error/2])]).

:- use_module(library(system)).


/*
    This module contains the code for primitives. This functions haves a
direct tranlation into Prolog. Cin and Cout are the stores of disequality 
constraints and must be placed as in the following examples. Before the Prolog
operation the hnf predicate must be called for each one argument.


Types for aritmethic functions are defined in a quite ad-hoc way here
in order to allow (a very limited) overloading of arithmetic operations.
The idea is the following: we represent the types 'int' and 'real'
by the terms 'num(int)' and 'num(real)', and we use 'num(A)' for
achieving overloading, when desired. 

Nota: Los tipos de las primitivas se toman de aqui (no del standard) para 
poder forzar el tipo de algunas funciones como / o sqrt y siempre devuelvan 
real (num(float))

P.e. el + respeta la declaracion + :: num(A) -> num(A) -> num(A), lo que quiere
 decir que si los dos argumentos son int el resultado es int y si alguno de los
dos es float el resultado es float.
En / tenemos / :: num(A) -> num(

*/

/***************     CODE PRIMITIVE FUNCTIONS     ***************/


%12/05/00 mercedes
% operaciones con ficheros propias de la libreria de entrada/salida

'$openFile'(NF,Mode,'$io'(Handle),Cin,Cout):-
    nf(NF,Name_File1,Cin,Cout1),
    '$trans'(Name_File1,[],Name_File),
    hnf(Mode,IoMode,Cout1,Cout2),
    name(Name,Name_File),
    %name(OpenMode,IoMode),
    (               % 05/09/00 mercedes
     file_exists(Name),!,
     '$control_open'(Name,Cout2,Cout3),
     (
      IoMode == readMode,
      open(Name,read,Handle)
     ;
      IoMode == writeMode,
      open(Name,write,Handle)
     ;
      IoMode == appendMode,
      open(Name,append,Handle)
     ),
     '$add_control'(Name,OpenMode,Handle,Cout3,Cout)
    ;
     treat_error(39,Name),fail
    ).
    
    
'$closeFile'(Handle,'$io'(unit),Cin,Cout):-
    close(Handle),
    '$remove_control'(Handle,Cin,Cout).
    
    
'$end_of_file'(Handle,'$io'(true),Cin,Cin):-
    at_end_of_stream(Handle),!.
        
'$end_of_file'(Handle,'$io'(false),Cin,Cin).


'$getCharFile'(Handle,'$io'('$char'(C)),Cin,Cin):-
    get0(Handle,C).
    
    
'$putCharFile'(Handle,C,'$io'(unit),Cin,Cout):-
    hnf(C,'$char'(HC),Cin,Cout),
    put(Handle,HC).
    

% 18/05/00 mercedes

'$putStrFile'(_A, _B, _C, _D, _E):-
        hnf(_B, _F, _D, _G),
        '$putStrFile_2'(_A, _F, _C, _G, _E).
'$putStrFile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, [], _D, _F),
        '$done'(_C, _F, _E).
'$putStrFile_2'(_A, _B, _C, _D, _E):-
        unifyHnfs(_B, :(_F, _G), _D, _H),
        $>>('$$susp'( '$putCharFile',  [ _A, _F ], _I, _J ), '$$susp'( '$putStrFile',  [ _A, _G ], _K, _L ), _C, _H, _E).


'$putStrLnFile'(_A, _B, _C, _D, _E):-
        $>>('$$susp'( '$putStrFile',  [ _A, _B ], _F, _G ), '$$susp'( '$putCharFile',  [ _A, '$char'(10) ], _H, _I ), _C, _D, _E).



'$getLineFile'(_A, _B, _C, _D):-
        $>>=('$$susp'( '$getCharFile',  [ _A ], _E, _F ), contin1(_A), _B, _C, _D).


'$contin1'(_A, _B, _C, _D, _E):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _B, '$char'(10) ], _F, _G ), '$$susp'( '$return',  [ [] ], _H, _I ), '$$susp'( '$if_then_else',  [ '$$susp'( '$$eqFun',  [ '$$susp'( '$end_of_file',  [ _A ], _J, _K ), '$$susp'( '$return',  [ true ], _L, _M ) ], _N, _O ), '$$susp'( '$return',  [ :(_B, []) ], _P, _Q ), '$$susp'( $>>=,  [ '$$susp'( '$getLineFile',  [ _A ], _R, _S ), contin2(_B) ], _T, _U ) ], _V, _W ), _C, _D, _E).

'$contin2'(_A, _B, _C, _D, _E):-
        '$return'(:(_A, _B), _C, _D, _E).




/*
primitiveFunct(getLineFile,1,1,(handle -> io(':'(char,[]))),io(':'(char,[]))).
'$getLineFile'(_A, _B, _C, _D):-
        $>>=('$$susp'( '$getCharFile',  [ _A ], _E, _F ), contin1, _B, _C, _D).

primitiveFunct(contin1,1,1,(char -> io(':'(char,[]))),io(':'(char,[]))).
'$contin1'(_A, _B, _C, _D):-
        '$if_then_else'('$$susp'( '$$eqFun',  [ _A, '$char'(10) ], _E, _F ), '$$susp'( '$return',  [ [] ], _G, _H ), '$$susp'( $>>=,  [ '$$susp'( '$getLineFile',  [ _I ], _J, _K ), contin2(_A) ], _L, _M ), _B, _C, _D).

primitiveFunct(contin2,2,2,(char -> ':'(char,[]) -> io(':'(char,[]))),io(':'(char,[]))).
'$contin2'(_A, _B, _C, _D, _E):-
        '$return'(:(_A, _B), _C, _D, _E).
*/
