:- module(primFunct,[primInfix/3,primitiveFunct/5,errPrim/0]).



% primInfix(Name,asociativity,precedence)
primInfix(/, left, 90).
primInfix(*, right, 90).
primInfix(+, left, 50).
primInfix(-, left, 50).
primInfix(^, noasoc, 98).
primInfix(**, noasoc, 98).
primInfix(<, noasoc, 30).
primInfix(<=, noasoc, 30).
primInfix(>, noasoc, 30).
primInfix(>=, noasoc, 30).
primInfix(==, noasoc, 10).
primInfix(/=, noasoc, 10).
primInfix(:,right,15).

% 05/11/99 mercedes
% Se ha quitado esta declaracion, porque las tuplas se tratan explicitamente en
% la gramatica y por tanto no hacen falta declaraciones "infix".
%primInfix(',',right,12).


% primitiveFunct(Name,Ar,ArP,type,destinationtype)
primitiveFunct(==, 2, 2, (A -> (A -> bool)), bool).
primitiveFunct(/=, 2, 2, (A -> (A -> bool)), bool).



% 28/04/00 mercedes (se introducen operadores infijos para los secuencializadores
% de la E/S).

primInfix(>>,left,11).
primInfix(>>=,left,11).





primitiveFunct(if_then_else, 3, 3, (bool -> (A -> (A -> A))), A).

primitiveFunct(if_then, 2, 2, (bool -> (A -> A)), A).

primitiveFunct(flip, 3, 3, ((A -> B -> C) -> (B -> (A -> C))), C).

%%::B
primitiveFunct(evalfd, 2, 2, (':'(char,[]) -> (':'('$num'(int),[]) -> ':'('$num'(int),[]))), ':'('$num'(int),[])).
%%::E

primitiveFunct(uminus, 1, 1, ('$num'(A) -> '$num'(A)), '$num'(A)).
primitiveFunct(abs, 1, 1, ('$num'(A) -> '$num'(A)), '$num'(A)).
primitiveFunct(sqrt, 1, 1, ('$num'(_A) -> '$num'(float)), '$num'(float)).
primitiveFunct(ln, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(exp, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(sin, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(cos, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(tan, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(cot, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(asin, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(acos, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(atan, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(acot, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(sinh, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(cosh, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(tanh, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(coth, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(asinh, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(acosh, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(atanh, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(acoth, 1, 1, ('$num'(float) -> '$num'(float)), '$num'(float)).
primitiveFunct(+, 2, 2, ('$num'(A) -> ('$num'(A) -> '$num'(A))), '$num'(A)).
primitiveFunct(-, 2, 2, ('$num'(A) -> ('$num'(A) -> '$num'(A))), '$num'(A)).
primitiveFunct(*, 2, 2, ('$num'(A) -> ('$num'(A) -> '$num'(A))), '$num'(A)).
primitiveFunct(min, 2, 2, ('$num'(A) -> ('$num'(A) -> '$num'(A))), '$num'(A)).
primitiveFunct(max, 2, 2, ('$num'(A) -> ('$num'(A) -> '$num'(A))), '$num'(A)).
primitiveFunct(/, 2, 2, ('$num'(A) -> ('$num'(A) -> '$num'(float))), '$num'(float)).
primitiveFunct('**', 2, 2, ('$num'(_A) -> ('$num'(float) -> '$num'(float))), '$num'(float)).
primitiveFunct(log, 2, 2, ('$num'(float) -> ('$num'(float) -> '$num'(float))), '$num'(float)).
primitiveFunct(^, 2, 2, ('$num'(A) -> ('$num'(int) -> '$num'(A))), '$num'(A)).
primitiveFunct(div, 2, 2, ('$num'(int) -> ('$num'(int) -> '$num'(int))), '$num'(int)).
primitiveFunct(mod, 2, 2, ('$num'(int) -> ('$num'(int) -> '$num'(int))), '$num'(int)).
primitiveFunct(gcd, 2, 2, ('$num'(int) -> ('$num'(int) -> '$num'(int))), '$num'(int)).
primitiveFunct(round, 1, 1, ('$num'(_A) -> '$num'(int)), '$num'(int)).
primitiveFunct(trunc, 1, 1, ('$num'(_A) -> '$num'(int)), '$num'(int)).
primitiveFunct(floor, 1, 1, ('$num'(_A) -> '$num'(int)), '$num'(int)).
primitiveFunct(ceiling, 1, 1, ('$num'(_A) -> '$num'(int)), '$num'(int)).
primitiveFunct(toReal, 1, 1, ('$num'(_A) -> '$num'(float)), '$num'(float)).
primitiveFunct(<, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
primitiveFunct(>, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
primitiveFunct(<=, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
primitiveFunct(>=, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
primitiveFunct(ord, 1, 1, (char -> '$num'(int)), '$num'(int)).
primitiveFunct(chr, 1, 1, ('$num'(int) -> char), char).



primitiveFunct(putChar,1,1,(char -> io(unit)),io(unit)).
primitiveFunct(done,0,0,(io(unit)),io(unit)).
primitiveFunct(getChar,0,0,io(char),io(char)).
primitiveFunct(return,1,1,(A -> io(A)),io(A)).
primitiveFunct(>>,2,2,(io(A) -> io(B) -> io(B)), io(B)).
primitiveFunct(>>=,2,2,(io(A) -> (A -> io(B)) -> io(B)),io(B)).
primitiveFunct(putStr,1,1,(':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(putStrLn,1,1,(':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(getLine,0,0,io(':'(char,[])), io(':'(char,[]))).
primitiveFunct(cont1,1,1,(char -> io(':'(char,[]))),io(':'(char,[]))).
primitiveFunct(cont2,2,2,(char -> ':'(char,[]) -> io(':'(char,[]))),io(':'(char,[]))).
primitiveFunct(writeFile,2,2,(':'(char,[]) -> ':'(char,[]) -> io(unit)),io(unit)).
primitiveFunct(readFile,1,1,(':'(char,[]) -> io(':'(char,[]))),io(':'(char,[]))).
primitiveFunct(readFileContents,1,1,(handle -> io(':'(char,[]))),io(':'(char,[]))).


% Depu 10/10/00 mercedes
% 09/08/01 rafa
primitiveFunct(dValToString,1,1,(A -> ':'(char,[])), ':'(char,[]) ).
primitiveFunct(dVal,1,1,(A -> pVal), pVal ).
primitiveFunct(getConstraintStore,1,1,  (':'(A,[])->constraint), constraint ).
% Fin Depu



% Fin Depu

% Depu 16/11/00 mercedes
primitiveFunct(selectWhereVariableXi,4,4,(A -> ('$num'(int) -> ('$num'(int) -> (B -> C)))),C).
% Fin Depu


/**********************  FALLO FINITO Y CORTE ********************************/
% pacol 17-03-05
primitiveFunct(fails,1,1, (A -> bool), bool).
primitiveFunct(once,1,1,(A -> A),A).
primitiveFunct(collect, 1, 1, ->(A,:(A,[])),:(A,[])). 
primitiveFunct(collectN, 2, 2, ->('$num'(int), ->(A,:(A,[]))),:(A,[])). 
/**********************  FIN FALLO FINITO Y CORTE ****************************/


errPrim:-
    nl,
    write('RUNTIME ERROR: Variables are not allowed in arithmetical operations.'),
    nl,
    !,
    fail.
