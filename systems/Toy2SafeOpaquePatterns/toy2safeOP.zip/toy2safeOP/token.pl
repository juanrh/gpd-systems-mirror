%----------------------------------------------------------------------------%
% token.pl
%----------------------------------------------------------------------------%
/*
- Autores: Paco L�pez Fraguas y Rafael Caballero.
- Description: Archivo que contiene los predicados principales para el analisis 
  lexicografico.
- Modules which import it: compil, transob.
- Imported modules: 
	> tools (con 'endFile').
	> dyn.
	> gramma_toy (con 'res','sep_res','tip_res' y 'sep').
	
- Modified: 
	30/05/96 (End of line is recognized as end of file if input is standard input).
 	08/06/97 (If a section ends with a character }, do not add automathically '}').
	20/06/97 (Anonymous variables are includedInclusion de variables anonimas)
	03/06/97 (characters are represented as '$$ch'(cod_ascii) and strings as
                  lists of characters)
     	30/09/99 mercedes (comments)
        26/10/99 mercedes (modules).
        07/04/00 mercedes y rafa ('after_chr' has been modified to avoid an 
        			  error).
 
*/


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



:- module(token,[searchToken/3,readSection/6]).

:- load_files(tools,[if(changed),imports([endFile/2])]).

:- load_files(dyn,[if(changed)]).

:- load_files(gramma_toy,[if(changed),imports([res/1,sep_res/1,tip_res/1,sep/1])]).

:- prolog_flag(single_var_warnings,_,off).

% get0

/*
  los par�metros que se pasan a lo largo del aut�mata son siempre un
  subconjunto de los que aqu� se describen:

    ?H       : handle del fichero de entrada.
   [+Past] : Pareja (L�nea,Pos) con las coordenadas del inicio del id. leido
               S�lo se usa en 'after_word'
    +Present: Triada con los valores del car�cter actual:
               (L�nea en la que nos encontramos, Posici�n dentro de la l�nea,
               Ultimo car�cter le�do).
    -Future  : Triada con los datos del caracter de salida. Ser�n necesarios
               para la lectura de la siguiente secci�n.
    ?Keys  : Pila de posiciones en las que comienza cada llave.
    ?U       : Ultimo token insertado. Representa el estado anterior del 
               aut�mata y se utiliza cuando no es suficiente el �ltimo
               car�cter le�do.
    -Tokens  : Lista de Tokens con la l�nea y car�cter de comienzo de cada uno,
               adem�s de su valor asociado. Los functores son:

               res    : palabra reservada
	       tres   : tipo reservado
               var    : variable
               id     : identificador
               sep    : Separadores, {, } , ; , [ , ] , ','
               op     : operadores no reservados
               constr : constructora
               op_res : operador reservado del lenguaje
               chr    : car�cter
               str    : string
               int    : entero
               float  : float
*/



%----------------------------------------------------------------------------%
% lectura de una secci�n, guardando la posici�n que marca el l�mite por la
% izquierda de la secci�n (la llave de abrir).
%----------------------------------------------------------------------------%

readSection(H, (Line,Pos,Ch), Future, Keys, U, [sep("{",Line)|Tokens]) :-
        !,
        read_token(H, (Line,Pos,Ch), Future, [(automatical_key,Pos)|Keys],
                   sep("{"), Tokens).


% fin de fichero en separaci�n de tokens
read_token(H,(Line,Pos,Ch), Future, Keys, U, Tokens) :-
        % si estamos dentro de un comentario se trata en el apartado COMENTARIO
        endFile(H,Ch),
        !,
        close_keys((Line,Pos,Ch),Future,Keys,ff, Tokens).


% si encontramos un blanco o un cambio de l�nea, a saltar
read_token(H,(Line,Pos,Ch), Future, Keys, U, Tokens) :-
        (Ch=32; Ch=10; Ch=13; Ch=9),
        !,
        leap_no_valid(H,(Line,Pos,Ch),NewPresent,Ch),
        read_token(H,NewPresent,Future,Keys,U,Tokens).

% si encontranmos % en cualquier parte (excepto dentro de un id,str u op)
% es un comentario
read_token(H,(Line,Pos,37), Future, Keys, U, Tokens) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        leap_no_valid(H,(Line,Pos2,Ch2),NewPresent,comment_line),
        read_token(H,NewPresent,Future,Keys,U,Tokens).

% especial: En caso de estar saltando blancos (U==searching_token),el car�cter /
% siempre se supone que es el principio de un comentario. Esto se hace as�
% para evitar devolver como primer token de la secci�n un comentario
read_token(H,(Line,Pos,47),Future, Keys, searching_token, Tokens) :-
        !,
        get0(H,Ch2),
        Pos2 is Pos+1,
        leap_no_valid(H,(Line,Pos2,Ch2),NewPresent,(comment,1,' ')),
        read_token(H,NewPresent, Future, Keys,U,Tokens).

% si estamos saltando blancos y comentarios, y llega hasta aqu� es que ya se
% ha encontrado algo distinto de blanco y comentario
% esta cla�sula debe ser la �ltima de este grupo
read_token(H,Present,Present,Keys,searching_token,Tokens) :- !.


% a partir de aqu� se supone que se ha leido un car�cter distinto de blanco

/* ------------------------------------------------------------------------- */
/* 1.- miramos a ver si hay que meter alg�n ; o cerrar llave                 */
/* ------------------------------------------------------------------------- */

% 1.1 miramos a ver si hemos terminado la seccion
% si es llave automatica basta con encontrar algo a la misma altura para 
% desapilar llave
read_token(H,(Line,Pos,Ch), (Line,Pos,Ch), [(automatical_key,Posl)], U, 
          [sep("}",Line)]):-
        U \== sep("{"),
        Pos =< Posl,
        Ch \== 47,      % asegurarse de que no es un comentario
        Ch \== 37,
        !.

% si ya no hay llaves hemos terminado
read_token(H,ChrIn,ChrIn,[],U,[]) :-
	!.

% 1.2 Miramos a ver si hay que cerrar una llave

% Si el usuario ha metido }, dos posibilidades
% a) Esta cerrando una llave que el propio usuario habia abierto 
read_token(H, (Line,Pos,Ch), Future,
          [(user_key,Posl)|Rest], U, [sep("}",Line)|Tokens]) :-
        Ch  == 125,  % }
	!,
	get0(H,Ch2),
	Pos2 is Pos+1,
	read_token(H,(Line,Pos2,Ch2),Future,Rest,sep("}"),Tokens).

% b) Esta cerrando una llave abierta por el sistema, error
read_token(H, (Line,Pos,Ch), Future,
          [(automatical_key,Posl)|Rest], U, []) :-
        Ch  == 125,  % }
	!,
	treat_lex_error(Line,29).

% si esta igual o mas al la izquierda que el principio de seccion
% cerrar llave, si es que estamos en una llave 'automatica' 
read_token(H, (Line,Pos,Ch), Future,
          [(automatical_key,Posl)|Rest], U, [sep("}",Line)|Tokens]) :-
        U  \== sep("{"),
        Pos <  Posl,
        Ch \== 47,     % asegurarse de que no es un comentario
        Ch \== 37,     % `%
        !,
        read_token(H,(Line,Pos,Ch), Future,  Rest,sep("}"), Tokens).

% 1.3 Miramos a ver si hay que poner un ;, o si lo ha puesto el usuario
read_token(H, (Line,Pos,Ch), Future,
          [(TypeKey,Posl)|Rest], U, [sep(";",Line)|Tokens]) :-
        U     \== sep(";"),      % si esto dar�a lugar a infinitos ;
        U     \== sep("{"),      % no se pone ; tras una llave.
        Pos    == Posl,
        Ch    \== 47,     % asegurarse de que no es un comentario
        Ch    \== 37,     % `%
        !,
        read_token(H,(Line,Pos,Ch), Future, [(TypeKey,Posl)|Rest],sep(";"), 
                  Tokens).

% si lo ha puesto a mano, respetarlo
read_token(H, (Line,Pos,Ch), Future,
          Keys, U, [sep(";",Line)|Tokens]) :-
	U    \== sep(";"),
        Ch    == 59,     % ;
        !,
	get0(H,Ch2),
	Pos2 is Pos+1,
        read_token(H,(Line,Pos2,Ch2), Future, Keys,sep(";"), Tokens).


% 1.4 miramos a ver si es una llave de abrir
read_token(H, (Line,Pos,Ch), Future,
          Pile, U, [sep("{",Line)|Tokens]) :-
	Ch == 123, % {
	!,
	get0(H,Ch2),
	Pos2 is Pos+1,
        % comienzo de seccion definido por el usuario
        leap_no_valid(H,(Line,Pos2,Ch2),(Line3,Pos3,Ch3),sep("{")),
        read_token(H,(Line3,Pos3,Ch3),Future,[(user_key,Pos3)|Pile],
                  sep("{"),Tokens).

/* ------------------------------------------------------------------------- */
/*              2.- entero a la vista                                        */
/* ------------------------------------------------------------------------- */
read_token(H, (Line, Pos, Ch), Future, Keys, U, Tokens) :-
        Ch >= 48, Ch =< 57,  % 0..9
        !,
        read_number(H,(Line,Pos,Ch), Future,Keys,U,Tokens).


%----------------------------------------------------------------------------%
% lee un numero y continua leyendo el siguiente caracter para ver si forma
% parte de ese numero.
%----------------------------------------------------------------------------%

read_number(H,(Line, Pos, Ch),Future,Keys,U,Tokens) :-
        !,
        E is Ch-48,
        get0(H,Ch2),
        Pos2 is Pos+1,
        read_integer(H,(Line,Pos),(Line,Pos2,Ch2),Future,Keys,int,Tokens,E).


%----------------------------------------------------------------------------%
% El predicado read_integer va leyendo caracteres mientras formen parte de un
% entero. 
%----------------------------------------------------------------------------%

% si se encuentra un '.' y estamos leyendo un entero, puede ser un float
% o bien que ha terminado un n�mero y empieza un operador
read_integer(H, Begin,(Line, Pos, 46), Future,Keys,U,Tokens,E) :-
        !,
        get0(H,Ch2),
        Pos2 is Pos+1,
        after_point(H,Begin,(Line,Pos2,Ch2),Future,Keys,int,Tokens,E).


%----------------------------------------------------------------------------%
% El predicado after_point mira el caracter que viene detras del punto, y actua
% segun sea este caracter. 
%----------------------------------------------------------------------------%

% Si tras '.' va un d�gito, empieza un float
after_point(H,Begin,(Line,Pos,Ch),Future,Keys,U,Tokens,E) :-
        Ch >= 48, Ch =< 57,  % 0..9
        F is Ch-48,
        get0(H,Ch2),
        Pos2 is Pos+1,
        read_float(H,Begin,(Line,Pos2,Ch2),Future,Keys,float,Tokens,E,F,10).

% En otro caso es un operador, y lo le�do hasta ahora era un entero
after_point(H,(LinIni,PosIni),(Line,Pos,Ch),Future,Keys,U,
           [int(E,LinIni)|Tokens],E) :-
        (Ch < 48 ; Ch > 57),
        !,
        read_symop(H,(Line,Pos,Ch),NewPresent,Ch,A),
        after_symop(H,[46|A],(Line,Pos),NewPresent,Future,Keys,U,Tokens).


% si se encuentra un caracter no v�lido se acabo el entero
read_integer(H, (LinIni,PosIni), (Line, Pos, Ch), Future,Keys,U,
           [int(E,LinIni)|Tokens],E) :-
        (Ch < 48 ; Ch > 57; Ch = 46), %Ch<0, Ch>9, Ch='.'
        !,
        read_token(H,(Line,Pos,Ch),Future,Keys,int,Tokens).

% si es un d�gito, seguimos leyendo entero
read_integer(H, Begin, (Line, Pos, Ch), Future, Keys,U,Tokens,E) :-
        Ch >= 48, Ch =< 57,    % 0..9
        !,
        E2 is 10*E + Ch-48,  % une el nuevo caracter leido al entero que
        get0(H, Ch2),        %  llevabamos en E y lo convierte en el nuevo
        Pos2 is Pos +1,      %  entero E2.  
        read_integer(H, Begin,(Line,Pos2,Ch2),Future,Keys,U,Tokens,E2).

% si se encuentra un caracter no v�lido se acabo el float
read_float(H, (LinIni,PosIni), (Line, Pos, Ch), Future,Keys,U,
           [float(Value,LinIni)|Tokens],E,F,Potency) :-
        (Ch < 48 ; Ch > 57),   % Ch < 0, Ch > 9
        !,
        Value is E + F/Potency,
        read_token(H,(Line,Pos,Ch),Future,Keys,int,Tokens).

% si es un d�gito, seguimos leyendo la parte decimal
read_float(H, Begin, (Line, Pos, Ch), Future, Keys,U,Tokens,E,F,Pot) :-
        Ch >= 48, Ch =< 57,    % 0..9
        !,
        F2 is 10*F + Ch-48,
	% incrementamos en 1 el exponente de la potencia de 10
        Pot2 is Pot*10,
        get0(H, Ch2),
        Pos2 is Pos +1,
        read_float(H, Begin,(Line,Pos2,Ch2),Future,Keys,U,Tokens,E,F2,Pot2).

/* ------------------------------------------------------------------------- */
/*              3.- palabra (identificador, palabra reservada o variable)    */
/* ------------------------------------------------------------------------- */
read_token(H, (Line, Pos, Ch), Future, Keys, U, Tokens) :-
        ( 
	Ch >= 97, Ch =< 122                       % a..z
        ; 
	Ch >= 65, Ch =< 90                        % A..Z
	;
	Ch = 95                                   % _ (var. anonimas)
        ),
        !,
        read_word(H,(Line,Pos,Ch), NewPresent, A),
%        write_word(A),nl,
        after_word(H,A,(Line,Pos),NewPresent,Future,Keys,U,Tokens).

%----------------------------------------------------------------------------%
% after_word
% se acaba de leer la palabra A. Ver como continuar
%----------------------------------------------------------------------------%

% si es where, palabra reservada para abrir secci�n, pues ala.
after_word(H,"where", (Lini,Posini),Present, Future, Keys, U,
             [res(where,Lini)|Tokens]):-
        !,
        leap_no_valid(H,Present,Present2,U),
        readSection(H,Present2, Future,  Keys,res,Tokens).

% si es otra palabra reservada, apuntarla en la lista de Tokens
after_word(H, A, (Lini,Posini),Present, Future,  Keys, U,
             [res(A2,Lini)|Tokens]):-
        res(A),
        !,
        name(A2,A),
        read_token(H,Present, Future, Keys,res,Tokens).

% 08/07/97
% Si es un tipo reservado, apuntarlo como tal
% si es otra palabra reservada, apuntarla en la lista de Tokens
after_word(H, A, (Lini,Posini),Present, Future,  Keys, U,
             [tres(A2,Lini)|Tokens]):-
        tip_res(A),
        !,
        name(A2,A),
        read_token(H,Present, Future, Keys,res,Tokens).


% si es una variable apuntarla en la lista de Tokens
after_word(H,[P|R],(Lini,Posini),Present,Future,Keys,U,
             [var(A2,Lini)|Tokens]) :-
        P >= 65, P =< 90,  	 % empieza por may�scula A..Z
        !,
        name(A2,[P|R]),
        read_token(H, Present, Future, Keys, var, Tokens).

% si empieza por _ es una variable anonima
after_word(H,[P|R],(Lini,Posini),Present,Future,Keys,U,
             [var(A2,Lini)|Tokens]) :-
	P = 95,				% P = _
	!,
	% intentamos darle un nombre de variable nuevo.
	% Para eso 'codifico' la linea y la columna, suponiendo que no hay
	% mas de 500 caracteres por linea. Ademas como un numero no es un
	% nombre de variable valido no puede coincidir con ninguna var. del
	% usuario. 
	NameCodif is (Lini-1)*500 + Posini,
	name(NameCodif,Aux),
	% le pegamos el '_' al principio
	name(A2,[95|Aux]),
	read_token(H,Present,Future,Keys,var,Tokens).

% si empieza por min�sculas, identificador
after_word(H,[P|R],(Lini,Posini),Present,Future,Keys,U,
             [id(A2,Lini)|Tokens]) :-
        P >= 97, P =< 122,   % empieza por min�scula: a..z
        !,
        name(A2,[P|R]),
        read_token(H,Present, Future,  Keys, id, Tokens).

% si no es variable ni identificador �Qu� es?. No lo s�.
after_word(H,A,(Lini,Posini),Present,Future,Keys,U,
             [unknown(A,Lini)|Tokens]) :-
        !,
        treat_lex_error(Lini,4),
        read_token(H, Present, Future,  Keys, unknown, Tokens).


% read_word
% lee una palabra formada por min�sculas, may�sculas, d�gitos, _ y '
read_word(H,(Line,Pos,Ch), Future, [Ch|Rest]) :-
        ( Ch >= 97, Ch =< 122                       % a..z
        ; Ch >= 65, Ch =< 90                        % A..Z
        ; Ch >= 48, Ch =< 57                        % 0..9
        ; Ch = 95                                   % _
        ; Ch = 39                                   % '
        ), !,
        get0(H,Ch2),
        Pos2 is Pos+1,
        read_word(H, (Line,Pos2,Ch2), Future, Rest).

read_word(H, (Line,Pos,Ch),(Line,Pos,Ch), []):-!.


/* ------------------------------------------------------------------------- */
/*              4.- operadores                                               */
/* ------------------------------------------------------------------------- */

% la / no se sabe si es un operador o un comentario. Esperar para decirlo
% de momento no metemos el corte
read_token(H, (Line,Pos,47), Future, Keys, U, Tokens):-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        after_bar(H,(Line,Pos2,Ch2), Future,Keys,U,Tokens).


%----------------------------------------------------------------------------%
% El predicado after_bar mira el caracter que viene a continuacion, y actua
% en funcion de si es un * o si no lo es. 
%----------------------------------------------------------------------------%

% Se ha leido una '/' pero detr�s no hay '*', as� que es un operador
after_bar(H,(Line,Pos,Ch),Future,Keys,U,Tokens):-
        Ch \== 42,  % *
        !,
        read_symop(H,(Line,Pos,Ch),NewPresent,Ch,A),
        after_symop(H,[47|A],(Line,Pos),NewPresent,Future,Keys,U,Tokens).

% es un comentario de los de '/' , '*'
after_bar(H,(Line,Pos,42),Future,Keys,U,Tokens) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        % seguimos leyendo, pero pasando a 'modo comentario'
        leap_no_valid(H,(Line,Pos2,Ch2),NewPresent,(comment,1,Ch2)),
        read_token(H,NewPresent,Future,Keys,U,Tokens).


/* Comprobar si es un operador. No consideramos que el operador empiece por
'/'  porque ya est� tratado este caso. Tampoco se consideran $ ni % al principio
de operador, aunque s� dentro. */

read_token(H, (Line,Pos,Ch), Future, Keys, U, Tokens):-
%         !      #      &      *      +      .      :
     (Ch=33; Ch=35; Ch=38; Ch=42; Ch=43; Ch=46; Ch=58;
%         <      =      >      ?      @      \      ^      |       -       �
      Ch=60; Ch=61; Ch=62; Ch=63; Ch=64; Ch=92; Ch=94; Ch=124; Ch=45; Ch=168),
     !,
     read_symop(H,(Line,Pos,Ch),NewPresent,Ch,A),
     after_symop(H,A,(Line,Pos),NewPresent,Future,Keys,U,Tokens).


% leer operador
read_symop(H, (Line,Pos,Ch), Future,  U, [Ch|Rest]):-
%         !      #      $      %      &      *      +      .      :      /
     (Ch=33; Ch=35; Ch=36; Ch=37; Ch=38; Ch=42; Ch=43; Ch=46; Ch=58; Ch=47;
%         <      =      >      ?      @      \      ^      |       -       �
      Ch=60; Ch=61; Ch=62; Ch=63; Ch=64; Ch=92; Ch=94; Ch=124; Ch=45; Ch=168),
     !,
     get0(H,Ch2),
     Pos2 is Pos+1,
     read_symop(H,(Line,Pos2,Ch2),Future,Ch,Rest).

read_symop(H, (Line,Pos,Ch), (Line,Pos,Ch), _, []):- !.



% hay algunas construcciones que tienen forma de operador pero en realidad
% se consideran separadores de la gram�tica. Ver si estamos en uno de esos
% casos
after_symop(H,Ope,(Lini,Posini),Present,Future,Keys,U,
           [sep(Ope,Lini)|Tokens]):-
        sep_res(Ope),
        !,
        read_token(H,Present,Future,Keys,sep(Ope),Tokens).

% ver si es un operador reservado del lenguaje
/* 23-07-96 ya no se consideran op.reservados, se han cambiado por primitives
after_symop(H,A,(Lini,Posini),Present,Future,Keys,U,
          [op_res(A2,Lini)|Tokens]):-
        op_res(A),
        !,
        name(A2,A),
        read_token(H,Present,Future,Keys,op_res,Tokens).
*/

% ver si es un constructor
after_symop(H,[58|A],(Lini,Posini),Present,Future,Keys,U,
           [constr(A2,Lini)|Tokens]):-
        !,
        name(A2,[58|A]),
        read_token(H,Present,Future,Keys,U,Tokens).

% en otro caso es un simple operador
after_symop(H,A,(Lini,Posini),Present,Future,Keys,U,
           [op(A2,Lini)|Tokens]):-
        !,
        name(A2,A),
        read_token(H,Present,Future,Keys,U,Tokens).

% operadores de funci�n usados como infijos: empiezan por `

read_token(H,(Line,Pos,96),Future,Keys,U, Tokens) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        read_chain(H,(Line,Pos2,Ch2),NewPresent,96,Chain),
        after_symop(H,Chain,(Line,Pos),NewPresent,Future,Keys,U,Tokens).


/* ------------------------------------------------------------------------- */
/*              5.- separadores                                              */
/* ------------------------------------------------------------------------- */
% asegurarnos de no meter dos { seguidas
read_token(H,(Line,Pos,123),Future,Keys,sep("{"),Tokens) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        read_token(H,(Line,Pos2,Ch2),Future,Keys,sep("{"),Tokens).

read_token(H,(Line,Pos,Ch),Future,Keys,U,[sep([Ch],Line)|Tokens]) :-
        sep([Ch]),
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        read_token(H,(Line,Pos2,Ch2),Future,Keys,sep([Ch]),Tokens).

/* ------------------------------------------------------------------------- */
/*              6.- cadenas y caracteres sueltos                             */
/* ------------------------------------------------------------------------- */
% a ver si es una cadena " ... "
read_token(H,(Line,Pos,34),Future,Keys,U,
	[sep("[",Line)|Tokens]) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        read_chain(H,(Line,Pos2,Ch2),NewPresent,34,A),
	after_chain(H,NewPresent,Future,Keys,Line,A,Tokens).
%        read_token(H, NewPresent,Future, Keys,chain,Tokens).


%----------------------------------------------------------------------------%
% after_chain
% va incluyendo en la lista de tokens los caracteres leidos uno a uno,
% separados por comas y poniendo al final el parentesis de cerrar.
% el de abrir se supone ya puesto
%----------------------------------------------------------------------------%

% no quedan caracteres, cerrar el corchete
after_chain(H,Present,Future,Keys,Line,[],[sep("]",Line)|Tokens]) :-
	!,
	read_token(H,Present,Future,Keys,chain,Tokens).

after_chain(H,Present,Future,Keys,Line,[A],
	[chr(A,Line),sep("]",Line)|Tokens]) :-
	!,
	read_token(H,Present,Future,Keys,chain,Tokens).

% queda mas de un caracter por tratar, incluir la coma
after_chain(H,Present,Future,Keys,Line,[A,B|R],
	[chr(A,Line),sep(",",Line)|Tokens]) :-
	!,
	after_chain(H,Present,Future,Keys,Line,[B|R],Tokens).

% a ver si es un caracter 'c'
read_token(H,(Line,Pos,39),Future,Keys,U,[chr(Cht,Line)|Tokens]) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        treat_ch(H,(Line,Pos2,Ch2),(Linen,Posn,Cht),Error),
        ( Error = error,
          read_token(H, (Linen,Posn,Ch2),Future, Keys,chr,Tokens)
         ;
          Pos3 is Posn+1,
          get0(H,Ch3),
          after_chr(H,(Linen,Pos3,Ch3),Future,Keys,U,Tokens)
        ).

% el �ltimo car�cter ha de ser '. Si no , error
after_chr(H,(Line,Pos,39),Future,Keys,U,Tokens) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        read_token(H,(Line,Pos2,Ch2),Future,Keys,chr,Tokens).
        
after_chr(H,(Line,Pos,Ch),Future,Keys,U,[unknown(Chain,Line)|Tokens]) :-
        !,
        treat_lex_error(Line,5),
	% intenatamos cerrar la cadena
	read_chain(H,(Line,Pos,Ch),Future,39,Chain),
	% 07-04-00
        % Mercedes & Rafa
        % Para corregir (intentar corregir) el error que daba en la
        % lectura de objetivos al escribir operadores infijos con la '
        % de los caracteres. Antes de arreglarlo, daba el error:
        % TOY> 10 'div' 5
        %
        % Line 1. Error 5: Character too long.
        %
        % TOY>
        %      yes
        %      X == 5
        %
        %      Elapsed time: 0 ms.
        %
        % Ahora, despues de arreglarlo, pasa esto:
        % TOY> 10 'div' 5
        %
        % Line 1. Error 5: Character too long.
        %
        % TOY>
	% 
	% Para arreglarlo, se ha aniadido lo siguiente:
        read_token(H,NextPresent,Future,Keys,chr,Tokens).



% si el caracter leido es el de fin cadena hemos terminado
read_chain(H,(Line,Pos,Quote), (Line,Pos2,Ch2), Quote,[]) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2).

read_chain(H,(Line,Pos,Ch), Future, Quote,[Ch_treated|Rest]) :-
        !,
        treat_ch(H,(Line,Pos,Ch),(Linen,Posn,Ch_treated),Error),
        continue_chain(H,(Linen,Posn,Ch_treated),Future,Quote,Rest,Error).

% si no ha habido error seguimos leyendo
continue_chain(H,(Line,Pos,Ch),Future,Quote,Chain,not_error):-
         !,
         Pos2 is Pos+1,
         get0(H,Ch2),
         read_chain(H,(Line,Pos2,Ch2),Future,Quote,Chain).

% si ha habido error no seguimos leyendo la cadena
continue_chain(H,Present,Present,Quote,[],error):- !.


%----------------------------------------------------------------------------%
% treat_ch mira a ver si el caracter encontrado puede ser parte de una
% cadena. Detecta error con fin de fichero  y fin de l�nea y trata
% secuencias de escape.
%----------------------------------------------------------------------------%

% fin de fichero en cadena
treat_ch(H,(Line,Pos,Ch),(Line,Pos,Ch),error) :-
	% solo se mira si estamos leyendo de fichero 09/07/97
	\+ endFile(H,10),
        endFile(H,Ch),
        !,
        treat_lex_error(Line,2).

% fin de l�nea en cadena
% a partir de hoy permitimos fin de linea en cadena 09/07/97
treat_ch(H,(Line,Pos,Ch),(Line,Pos,Ch),Error) :-
        (
          Ch=13  % Ch= '\r' (cr)
        ;
          Ch=10  % Ch= '\n' (nl)
        ),
        !.

%        treat_lex_error(Line,3).


% secuencias de escape '\'
treat_ch(H,(Line,Pos,92), (Line,Pos2,Ch_treated),Error) :-
        !,
        Pos2 is Pos+1,
        get0(H,Ch2),
        (
         Ch2 = 92  -> Ch_treated = 92, Error = not_error ;  % backslash
         Ch2 = 39  -> Ch_treated = 39, Error = not_error ;  % '
         Ch2 = 34  -> Ch_treated = 34, Error = not_error ;  % "
         Ch2 =110  -> Ch_treated = 10, Error = not_error ;  % nl
         Ch2 =114  -> Ch_treated = 13, Error = not_error ;  % cr
         Ch2 =116  -> Ch_treated =  9, Error = not_error ;  % tab
         Ch2 =118  -> Ch_treated = 11, Error = not_error ;  % vtab
         Ch2 = 97  -> Ch_treated =  7, Error = not_error ;  % bell
         Ch2 = 98  -> Ch_treated =  8, Error = not_error ;  % backspace
         Ch2 =102  -> Ch_treated = 12, Error = not_error ;  % ff
         Ch2 =101  -> Ch_treated = 27, Error = not_error ;  % Esc
         Ch2 =100  -> Ch_treated = 127,Error = not_error ;  % delete
         % the character itself
         Ch_treated = Ch2
% it isn't error anymore         treat_lex_error(Line,5)
        ).

% en cualquier otro caso el car�cter le�do es absoltamente normal.
treat_ch(H,(Line,Pos,Ch),(Line,Pos,Ch),not_error) :- !.

/* ------------------------------------------------------------------------- */
/*              7.- no se que es                                             */
/* ------------------------------------------------------------------------- */

% recogedor de sobrantes
% si aparecen varios unknown's consecutivos en el fichero, s�lo se guarda el
% primero. Esto se peude ver como un mecanismo de recuperaci�n de errores
% o de 'estabilizaci�n'.
read_token(H, (Line,Pos,Ch), Future, Keys, unknown, Tokens) :-
        !,
        get0(H, Ch2),
        Pos2 is Pos+1,
        read_token(H, (Line,Pos2,Ch2),Future,Keys,unknown,Tokens).
        
% si es el primer unknown, guardarlo pra que el l�xico de error
read_token(H, (Line,Pos,Ch), Future, Keys, U,
           [unknown(Ch,Line)|Tokens]) :-
        U \== unknown,
        !,
        get0(H, Ch2),
        Pos2 is Pos+1,
        treat_lex_error(Line,4),
        read_token(H, (Line,Pos2,Ch2),Future,Keys,unknown,Tokens).


/* ------------------------------------------------------------------------- */
/*           8.-    leap_no_valid                                         */
/* ------------------------------------------------------------------------- */

%----------------------------------------------------------------------------%
% leap_no_valid : Va saltando comentarios, blancos, tab y fines de l�nea
% hasta que se encuentra el principio de alg�n token.
% No se usa read_token porque as� no hay que arrastrar las pilas de llaves y
% de tokens.
%----------------------------------------------------------------------------%

% cambio de l�nea
leap_no_valid(H,(Line,Pos,10), Future,U) :-
        % si estamos leyendo de teclado, el 10 es fin de fichero
	\+ endFile(H,10),
        !,
        Line2 is Line+1,
        Pos2   is 1,
        get0(H,Ch2),
        leap_no_valid(H,(Line2,Pos2,Ch2),Future,U).

% al 13 ni se le considera.
leap_no_valid(H,(Line,Pos,13), Future,U) :-
        % si estamos leyendo de teclado, el 13 es fin de fichero
	\+ endFile(H,13),
        !,
        get0(H,Ch),
        leap_no_valid(H,(Line,Pos,Ch),Future,U).

% control por si estamos leyendo un comentario de los de fin de l�nea
% y ya hemos llegado al fin de l�nea
% esta cla�sula debe ir antes de las que avanzan la posici�n
leap_no_valid(H,(Line,1,Ch),Future,comment_line) :-
        !,
        leap_no_valid(H,(Line,1,Ch), Future, Ch).

% el tabulador aumenta en 9 la posici�n actual
leap_no_valid(H,(Line,Pos,9), Future,U) :-
        !,
        Pos2 is Pos+8,
        get0(H,Ch2),
        leap_no_valid(H,(Line,Pos2,Ch2), Future,U).
   	      	    	      	       	    	 	     	   	  	
% quitamos los blancos
leap_no_valid(H,(Line,Pos,32), Future,U) :-
        !,
        Pos2 is Pos+1,
        get0(H, Ch2),
        leap_no_valid(H,(Line,Pos2,Ch2),Future,U).

% control por si estamos leyendo un comentario de los que se anidan.
% si ya ha terminado el comentario (nivel 0) seguir normal
leap_no_valid(H,Present,Future,(comment,0,_)):-
        !,
        leap_no_valid(H,Present,Future,' ').

% si se encuentra un fin de fichero en medio de un comentario, malo, malo
leap_no_valid(H,(Line,Pos,Ch),(Line,Pos,Ch),(comment,N,_)) :-
        N>0,
        endFile(H,Ch),
        !,
        treat_lex_error(Line,1).

% hay que controlar los caracteres '*' y '/' por si abren o cierran m�s niveles
leap_no_valid(H,(Line,Pos,47),Future,(comment,N,42)) :-
        !,
        get0(H,Ch2),
        Pos2 is Pos+1,
        N2 is N-1,  % comentario cerrado
        leap_no_valid(H,(Line,Pos2,Ch2), Future,(comment,N2,Ch2)).

% un '*' tras un '/'
leap_no_valid(H,(Line,Pos,42),Future, (comment,N,47)) :-
        !,
        get0(H,Ch2),
        Pos2 is Pos+1,
        N2 is N+1,  % nuevo nivel abierto
        leap_no_valid(H,(Line,Pos2,Ch2), Future, (comment,N2,Ch2)).

% en otro caso, simplemente saltar caracteres
leap_no_valid(H,(Line,Pos,Ch),Future, (comment,N,_)) :-
        !,
        get0(H,Ch2),
        Pos2 is Pos+1,
        leap_no_valid(H,(Line,Pos2,Ch2), Future,(comment,N,Ch)).

% igual si estamos leyendo un comentario de l�nea
leap_no_valid(H,(Line,Pos,Ch),Future, comment_line) :-
	\+ endFile(H,Ch),
        !,
        get0(H,Ch2),
        Pos2 is Pos+1,
        leap_no_valid(H,(Line,Pos2,Ch2), Future,comment_line).

% cuando llega aqu� se ha le�do alguno distinto de blanco y no estamos
% en un comentario. Debe ser la �ltima cla�sula de 'leap_no_valid'
leap_no_valid(H,Present, Present, U) :- !.


/* ------------------------------------------------------------------------- */
/*           cla�sulas auxiliares                                            */
/* ------------------------------------------------------------------------- */

%----------------------------------------------------------------------------%
% cerrar todas las llaves que quedan abiertas
% s�lo se le llamar� si es fin de fichero o se ha terminado la secci�n
%----------------------------------------------------------------------------%

close_keys( Present, Present, [], _, []) :- !.
close_keys( (Line,Pos,Ch), Future, [(automatical_key,_)|RestPile], U,
               [sep("}",Line)|Tokens]) :-
        !,
        close_keys((Line,Pos,Ch),Future, RestPile,sep("}") , Tokens).

% no se pueden cerrar automaticamente llaves del usuario
close_keys( (Line,Pos,Ch), Future, [(user_key,_)|RestPile], U,
               []) :-
        !,
        treat_lex_error(Line,28). 


%----------------------------------------------------------------------------%
% searchToken
% devuelve el primer caracter distinto de blanco que se encuentra a partir de
% la posicion actual. Entre el blanco se incluyen los fines de l�nea y
% comentarios
%----------------------------------------------------------------------------%

searchToken(H, Present,Future) :-
        !,
        read_token(H, Present, Future,  _,searching_token,_).



treat_lex_error(Line,N) :-
        !,
        assertlexicon_error(N,Line).



