/*
File: stronglycc.pl

  Description:
  	Calculates the strongly connected components (SCC) of a graph. 
  	The graph is stored with facts edge/2 and a list with the vertices.
  	  
  Author:  
  	Enrique Martin (emartinm@fdi.ucm.es)
      
  Date: 
  	21 September 2009
  
  Comments:
    Strongly connected components using Tarjan's algorithm O(|V|+|E|)
    ----------------------------------------------------
    Based on the pseudocode written on the wikipedia
    http://en.wikipedia.org/wiki/Tarjan%27s_strongly_connected_components_algorithm

    Computes and stores as facts the strongly connected components of a graph. The graph is 
    represented using facts for the edges:
            types_edge(A,B) 
    This fact means that there is an edge between A and B (arrow from A to B)

    The main predicate is scc/1, which takes a list of verteces and stores a fact scc_list(SCC)
    with a list of the strongly connected components

    We need to store persistent information about the verteces: index, lowlink and whether 
    the vertex is in the stack or not. For this purpose we use facts of the form:
     - index( Vertex, Index ),
     - lowlink( Vertex, LowLink ),
     - instack( Vertex )
     
  Efficiency note:
    The algorithm asserts and retracts some facts during execution. Retracts can generate 
    time penalizations, as is explained in the Sicstus Manual 4.12.5.1 A Note on Effcient Use of retract/1 (page 156).
    If the performance is poor, try changing instack, lowlink and index facts by explicit lists.
     
  Works in:
  
  Imports:
    - Nothing.
  
  Requires:
    - Lib. system/lists.
    - Lib. system/db.
*/

/*
:- l_requires_sysutil(lists).
:- l_requires_sysutil(db).
*/
:- module(connected, [connected_comp/1]).

:- load_files(tools,[if(changed),imports([member/2,append/3])]).

:- load_files(dyn,[if(changed)]).

:- load_files(newout,[if(changed),imports([fun/4,depends/2,primitive/3])]).

% predicates used to store persistent information
:- dynamic types_index/2, types_lowlink/2, types_instack/1, types_scc_list/1.


% ------------------------------------------------------------------------------
%    P U B L I C   I N T E R F A C E
% ------------------------------------------------------------------------------

/*  Predicate: connected_comp( +VertexList )

    Description:
      This predicate computes all the Strongly Connected Components, given the list with all the verteces. 
      It uses Tarjan's algorithm, that finds only the SCC that are reachable from the start vertex, so we 
      need to apply the algorithm starting in every unvisited node. 
      
    Parameters:
      VertexList - List containing all the verteces in the graph.
*/
connected_comp( List ) :-
  findall( F, fun(F,_,_,_), FunList ),
  %write( FunList ), nl,
  
  types_initialize_scc,
  % En el .out tenemos hechos depends que recogen las dependencias entre
  % funciones incluidas las primitivas. Para este modulo nos interesan
  % solo las dependencias entre funciones no primitivas. Este predicado
  % mete en la BD hechos depFun que criban el total de dependencias 
  % excluyendo las de primitivas. 
  assertFunctionalDependences, 
  
  findall( depFun(Vertex,X), depFun(Vertex,X), ListSuccessors ),
  %write( ListSuccessors ),nl,
  %write( FunList ), nl,
  
  types_tarjan_list( FunList, 0, [], _IndexOut, _StackOut ),
  types_scc_list( List ), !.
  

  
% ------------------------------------------------------------------------------
%    P R I V A T E   P R E D I C A T E S
% ------------------------------------------------------------------------------

/********************** Auxiliar predicates************************/

assertFunctionalDependences:-
	findall(depFun(F,G),depends(F,G),LstDepFun),
	assertLstClausules(LstDepFun).

assertLstClausules([]).
assertLstClausules([depFun(F,G)|R]):-
	(primitive(G,_,_),!,true;
	assertdepFun(F,G)),
	assertLstClausules(R).

/******************************************************************/

/*  Predicate: types_initialize_scc

    Description:
      This predicate is used to initialize the state needed by the Tarjan's algorithm. This state is composed by the 
      types_index/2, types_lowlink/2, types_instack/1 and types_scc_list/1 facts.
*/
types_initialize_scc :- 
	retractall( types_index(_,_) ),
	retractall( types_lowlink(_,_) ),
	retractall( types_instack(_) ),
	retractall( types_scc_list(_) ),
	assertz( types_scc_list([]) ).


/*  Predicate: types_tarjan_list( +VertexList, +Index, +Stack, -NIndex, -NStack )

    Description:
      Applies tarjan's algorithm starting in all the nodes of the list which have not already been visited
      
    Parameters:
      VertexList - List containing all the verteces in the graph.
      Index  - Last index assigned to a vertex.
      Stack  - Actual stack of nodes.
      NIndex - Stack after the execution of the algorithm.
      NStack - Index of the last vertex used in the algorithm.
*/
types_tarjan_list( [], Index, Stack, Index, Stack ).
types_tarjan_list( [X|R], IndexIn, StackIn, IndexOut, StackOut ) :-
  types_index(X,_),!, % X has been previously visited
  types_tarjan_list( R, IndexIn, StackIn, IndexOut, StackOut ).
types_tarjan_list( [X|R], IndexIn, StackIn, IndexOut, StackOut ) :-
	types_tarjan( X, IndexIn, StackIn, NIndex, NStack ),
	types_tarjan_list( R, NIndex, NStack, IndexOut, StackOut ).


/*  Predicate: types_tarjan( +Vertex, +Index, +Stack, -NIndex, -NStack )

    Description:
      Computes the strongly connected components starting from Vertex, being Stack the actual stack of nodes.
      It follows the pseudocode of the Wikipedia: 
      http://en.wikipedia.org/wiki/Tarjan%27s_strongly_connected_components_algorithm
      
    Parameters:
      Vertex - Starting vertex 
      Index  - Last index assigned to a vertex
      Stack  - Actual stack of nodes
      NIndex - Stack after the execution of the algorithm
      NStack - Index of the last vertex used in the algorithm
       

*/
types_tarjan( Vertex, Index, Stack, NIndex, NStack ) :-
	types_mark_push( Vertex, Index ),
	Stack1 = [Vertex|Stack],
	Index1 is Index + 1,
	% findall( X, types_edge(Vertex,X), ListSuccessors ),
	findall( X, depFun(Vertex,X), ListSuccessors ),
	% we cannot use 'bagof' because it fails instead of returning the empty list when the
	% vertex hasn't got any successor
	types_visit_successors( Vertex, ListSuccessors, Index1, Stack1, NIndex, NStack1 ),
	types_index( Vertex, IndexVertex ),
	types_lowlink( Vertex, LowLinkVertex ),
	( IndexVertex == LowLinkVertex -> types_extract_nodes( Vertex, NStack1, [], NStack ) ; NStack = NStack1 ).
	

/*  Predicate: types_visit_successors( +Vertex, +SuccessorList, +Index, +Stack, -NewIndex, -NewStack )

    Description:
      Visits the verteces in SuccessorList and treats them
      depending on if they have been previosuly discovered, are in the stack or not.
      
    Parameters:
      Vertex        - Actual vertex
      SuccesorList  - List containing all the direct successors of Vertex
      Index         - Index of the last vertex treated
      Stack         - Actual stack of verteces
      NewIndex      - Index of the last vertex used in the algorithm
      NewStack      - Stack after the execution of the algorithm

*/
types_visit_successors( _Vertex, [], Index, Stack, Index, Stack ).
types_visit_successors( Vertex, [X|R], Index, Stack, NIndex, NStack ) :-
   \+ types_index(X,_), !,	% X has not been visited before
	types_tarjan( X, Index, Stack, Index1, Stack1 ),
	types_lowlink( Vertex, LowLinkVertex ),
	types_lowlink( X, LowLinkX ),
	types_min( LowLinkVertex, LowLinkX, NLowLinkVertex ),
	types_update_lowlink( Vertex, NLowLinkVertex ),
	types_visit_successors( Vertex, R, Index1, Stack1, NIndex, NStack ).
types_visit_successors( Vertex, [X|R], Index, Stack, NIndex, NStack ) :-
  types_instack( X ), !, % X is in the stack
	types_index( X, IndexX ),
	types_lowlink( Vertex, LowLinkVertex ),
	types_min( IndexX, LowLinkVertex, NLowLinkVertex ),
	types_update_lowlink( Vertex, NLowLinkVertex ),
	types_visit_successors( Vertex, R, Index, Stack, NIndex, NStack ).
types_visit_successors(  Vertex, [_X|R], Index, Stack, NIndex, NStack ) :-
  % Continues with the rest of successors
  types_visit_successors( Vertex, R, Index, Stack, NIndex, NStack ).


/*  Predicate: types_extract_nodes( +Vertex, +Stack, +ActualSCC, -NewStack )
    Description:
       Extracts the nodes in the stack that are inside the same strongly connected component (SCC). When 
       it obtains the complete list, it asserts it using types_insert_scc/1.
       
    Parameters:
      Vertex    - Actual vertex
      Stack     - Actual stack of verteces
      ActualSCC - Accumulator of list of verteces in the SCC
      NewStack  - The stack after extracting the nodes
*/
types_extract_nodes( Vertex, [X|S], SCC, S ) :-
	Vertex == X, !,
	types_mark_pop( X ),
	types_insert_scc( [X|SCC] ).
types_extract_nodes( Vertex, [X|S], SCC, NStack ) :-
	types_mark_pop( X ),
	types_extract_nodes( Vertex, S, [X|SCC], NStack ).




% ------------------------------------------------------------------------------
%    A U X I L I A R Y   P R E D I C A T E S
% ------------------------------------------------------------------------------


% types_mark_push( +Vertex, +Index )
% Asserts the necessary information of a vertex that is about to be pushed in the stack.
types_mark_push( Vertex, Index ) :-
  assertz( types_index( Vertex, Index ) ),
  assertz( types_lowlink( Vertex, Index ) ),
  assertz( types_instack( Vertex ) ).
  
  
% types_mark_pop( +Vertex )
% mark a vertex X popped from the stack, i.e., retracts the fact types_instack(X)
types_mark_pop( X ) :-
	retract( types_instack( X ) ).
	
% types_insert_scc( +SCC )
% Inserts the SCC in the database, using the fact types_scc_list
types_insert_scc( SCC ) :-
	types_scc_list( L ),
	retractall( types_scc_list(_L) ),
	append( L, [SCC], NL ),
	assertz( types_scc_list(NL) ).


% types_update_lowlink( +Vertex, +LowLink )
% updates the value of lowlink related with Vertex
types_update_lowlink( Vertex, LowLink ) :-
	retract( types_lowlink( Vertex, _ ) ),
	assertz( types_lowlink( Vertex, LowLink ) ).


% types_min( +A, +B, -Min )
% Calculates the minimum value of A and B
types_min( A, B, A ) :-
	A =< B, !.
types_min( _, B, B ).



