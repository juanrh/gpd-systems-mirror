%----------------------------------------------------------------------------%
% toycomm.pl
%----------------------------------------------------------------------------%
/*
- Author: Paco y Jaime
- Created: 3/6/96
- Description: Este modulo es necesario para ejecutar programas en TOY. El
  sistema lo carga automaticamente al principio. Contiene todos los predicados
  comunes a todos los programas TOY. (This module is neccesary for executing
  programs in Toy. The system loads it automatically at the begining. It
  contains all the common predicates to all toy-programs).
- Modules which import it: primitives, plgenerated, initToy.
- Imported modules:
    > plgenerated (con 'constr', 'funct', 'hnf_susp').
- Modified:
    18.6.97
        30/09/99 mercedes (se han comentado los predicados)
        05/10/99 mercedes (separacion de las restricciones sobre los reales
                          del nucleo).
        26/10/99 mercedes (modularizacion).
        22/11/99 mercedes (Se ha llevado a cabo la optimizacion de la
                       igualdad propuesta por Rafa. Hasta ahora, si
                       teniamos:
                       f(X) = g(Y) <== Y == h(X)
                       lo que hacia Y == h(X) era ira calculando las fnc
                       de Y y de h(X) e ir comparandolas poco a poco.
                       Se ha comprobado que si tenemos
                       f(Args1) = g(Args2) <== Condiciones, Y==T (o T==Y)
                       donde Y es una variable, Y no aparece en Args1,
                       tampoco aparece en Condiciones y tampoco aparece
                       en T, entonces es mas eficiente resolver esa
                       igualdad haciendo la forma normal de T y
                       compararla con Y.
                       Y si podria aparacer en Args2.
                       Esta optimizacion tambien hay que hacerla en los
                       objetivos.
                       Para hacer esta optimizacion los cambios que se
                       han hecho son: se crea el predicado equalnf y nf.
        26/11/99 mercedes (Introduccion de las restricciones sobre reales al
                   nucleo. Para ello se han introducido los predicados
                   isReal, toSolver y passToSolver).
    14/02/00 mercedes (the positions of the fist and the second argument
              of the predicates: propagate and extractCtr have been
              changed).
        06/02/03 rafa: paso del ingles. A�ado el contador de estad�sticas
        26/09/03 rafa: Incluyo c�digo especializado para el c�lculo de forma normal del �rbol para el depurador.
                Esto no debe incluir en el resto de los predicados del m�dulo.

*/


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% rafa 6-02-05: exported cleanTotCtrStore/2 
:- module(toycomm,[hnf/4,unifyHnfs/4,equal/4,notEqual/4,'$$eqFun'/5,
      '$$notEqFun'/5,equalnf/4,toSolver/3,
%B::Sonia
      isReal/1, isVarReal/1,isVarFD/1,toSolverFD/3,listToSolverFD/3,      
%E::Sonia
      passToSolver/4,
      '$do'/5,'$intensional'/5,nf/4, equalDebug/4,  nfDebug/2,cleanTotCtrStore/2,notEqualVar/4 ]).


% 16/05/00 mercedes. Para cuando usamos la libreria de e/s de ficheros.
:- load_files(dyn,[if(changed)]).

:- load_files(basic,[if(changed),imports([constr/4,funct/5,hnf_susp/5])]).

% 06/06/00 mercedes
:- load_files(codfun,[if(changed),imports([introduceSusp/3])]).

% 08/06/00 mercedes
:- load_files(tools,[if(changed),imports([append/3,member/2])]).

% 12/06/00 mercedes: se necesita para el '$if_then_else'
:- load_files(primFunct,[if(changed)]).

:- (
    clpr_active,!,load_files(primitivCodClpr,[if(changed)])
   ;
    load_files(primitivCod,[if(changed)])
   ).

:- (
    io_active,!,load_files(primitivCodIo,[if(changed)])
   ;
    true
   ).

:- (
    iographic_active,!,load_files(primitivCodGra,[if(changed)])
   ;
    true
   ).


%%::B Sonia 2.3.1
:- (
    clpr_active, cflpfd_active,!,load_files(cooperation,[if(changed)],imports(['$#=='/5,'$#/=='/5,searchVarsR/4,searchVarsFD/4,cleanBridgeStore/2]))
   ;
    true
   ).

:- use_module(library(clpfd)).
%%::E Sonia



% rafa 27-08-03: Para escribir estad�sticas en equalDebug
:- load_files(goals,[if(changed),imports([writeSolution/3,writeStatistics/0])]).

:-  load_files(pVal,[if(changed),imports([toyStringToList/2])]).

:- use_module(library(clpr)).



/*****************************************************************************/
/*               CODE FOR HNF                        */
/*****************************************************************************/


%:-dynamic hnf/4.

%----------------------------------------------------------------------------%
% hnf(+E,?H,+Cin,-Cout)
%  H es el resultado de evaluar una forma normal de cabeza para E tomando como
% restricciones de entrada Cin. Cout son las restricciones resultantes de este
% computo.
% H es una variable nueva o un termino de la forma c(X1,...,Xn) con X1,...,Xn
% variables nuevas (lo importante es que las variables de H no tengan asociadas
% desigualdades y que el propio H sea una forma normal de cabeza).
%----------------------------------------------------------------------------%

% 29/10/02 Rafa: Renombro todos los hnf a hnf2
% e introduzco una sola cl�usula para hnf que incrementa el contador
% para eliminar el contador renombrar los hnf2 a hnf, y quitar la clausula siguiente
hnf(E,H,Cin,Cout):-
    hnfRunTimeStatistics,
    hnf2(E,H,Cin,Cout).


hnf2(E,H,Cin,Cout):-
    var(E),
    !,
    (
        var(H),
        !,
        H=E,
        Cin=Cout
    ;
        extractCtr(Cin,E,Cout1,CE),
        H=E,
        propagate(CE,H,Cout1,Cout)
    ).

% 07/06/00: como hemos puesto el do como una funcion especial, para calcular
% la forma normal de cabeza de la funcion do, hay que llamar a la funcion '$do'
% que tenemos definida aqui en el toycomm.pl
hnf2('$$susp'('$do',[L1,L2],R,S),H,Cin,Cout):-
    '$do'(L1,L2,H,Cin,Cout).


% 12/06/00: como hemos puesto intensional como una funcion especial, para
% calcular la forma normal de cabeza de la funcion intensional, hay que llamar
% a la funcion '$intensional' que tenemos definida aqui en el toycomm.pl
hnf2('$$susp'('$intensional',[E,L],R,S),H,Cin,Cout):-
    '$intensional'(E,L,H,Cin,Cout).



hnf2('$$susp'(Fun,Args,R,S),H,Cin,Cout):-
    !,
    (S==hnf,!,hnf(R,H,Cin,Cout)
    ;
    H=R,
    S=hnf,
    hnf_susp(Fun,Args,H,Cin,Cout)
    ).

hnf2(T,H,Cin,Cin):-H=T.


%----------------------------------------------------------------------------%
% unifyHnfs(+H,+L,+Cin,-Cout): unifica formas normales de cabeza (H y L) sin
% occurs-check.
% H acaba de calcularse y L es una expresion que comienza por constructora
%----------------------------------------------------------------------------%

unifyHnfs(H,L,Cin,Cout):-
    var(H),
    !,
    extractCtr(Cin,H,Cout1,CH),
    H=L,
    propagate(CH,H,Cout1,Cout).

unifyHnfs(H,H,Cin,Cin).




/*****************************************************************************/
/*               CODE FOR EQUAL                      */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% equal(+L,+R,+cin,-Cout): resuelve la igualdad entre L y R siendo L y R dos
% expresiones cualesquiera. Para resolver la igualdad L==R, hay que hacer las
% f.n.c.'s t1 y t2 de L y R respectivamente y ver que t1 es exactamente igual
% a t2. La forma de operar para equal no es exactamente esta, sino otra mas
% sofisticada para mejorar la eficiencia. (Ver libro de Jaime, pag. 113)
%----------------------------------------------------------------------------%

equal(L,R,Cin,Cout):-
    var(L),
    !,
    hnf(R,HR,Cin,Cout1),
    equalHnf(L,HR,Cout1,Cout).

equal(R,L,Cin,Cout):-
    var(L),
    !,
    hnf(R,HR,Cin,Cout1),
    equalHnf(L,HR,Cout1,Cout).


%FSP 19-02-2007 ::B
% Las dos cl�usulas siguientes tratan el caso de que uno de los miembros sea
% un n�mero (caso especial de constructora de aridad 0). Cuando s�lo 
% est� cargada la biblioteca de reales, el n�mero se convierte 


equal(L,R,Cin,Cout):-
    number(L),
    !,
    hnf(R,T,Cin,Cout),
    (number(T)->testEqNumber(L,T);
%     (clpr_active, \+ cflpfd_active -> 
%       T is L*1.0; 
%       L=T)).
     L=T).

equal(R,L,Cin,Cout):-
    number(L),
    !,
    hnf(R,T,Cin,Cout),
    (number(T)->testEqNumber(L,T);
%     (clpr_active, \+ cflpfd_active -> 
%       T is L*1.0; 
%       L=T)).
     L=T).
      
%::E
    
% Las dos clausulas siguientes tratan el caso de que uno de los miembros sea
% una constructora. En este caso se construye una nueva expresion con el mismo
% nombre de constructora y con variables nuevas como argumentos, i.e., se imita
% la estructura externa de la constructora inicial. Despues se hace una reduccion
% orientada a f.n.c. del otro miembre: se solicita la evaluacion a f.n.c.
% forzando la forma del resultado. Esta orientacion sirve para anticipar un
% posible fallo (se poda el arbol de busqueda) con lo que se incrementa la
% eficiencia.Despues de esto se tiene la certeza de que ambos miembros comienzan
% por constructora: uno de ellos ya tenia esta forma y para el otro se ha
% forzado en la reduccion. Ademas las constructoras mas externas deben coincidir
% en ambos miembros, pero de las internas aun no conocemos nada. Nuevamente
% se puede intentar anticipar un fallo calculando la forntera. Si tal fallo no
% se produce, el computo continua resolviendo la lista de igualdades que ha
% dejado pendientes el estudio de la frontera mediante el predicado equalList.

equal(L,R,Cin,Cout):-
    constructor(L,C/N),
    !,
    functor(T,C,N),
    hnf(R,T,Cin,Cout1),
    eqFrontier(L,T,FL/[],FR/[]),
    equalList(FL,FR,Cout1,Cout).

equal(R,L,Cin,Cout):-
    constructor(L,C/N),
    !,
    functor(T,C,N),
    hnf(R,T,Cin,Cout1),
    eqFrontier(L,T,FL/[],FR/[]),
    equalList(FL,FR,Cout1,Cout).




% Las dos clausulas siguientes estudian el caso de que uno de los miembros sea
% una suspension evaluada. Si es asi hace una desreferenciacion, para acceder a
% la  variable o constructora que se obtuvo de la evaluacion y se llama
% recursivamente a equal. Esta nueva llamada se resolvera necesariamente por una
%  de las clausulas anteriores.
% Both are suspended forms, but we don't know if they are solved or not.

equal('$$susp'(_,_,R,S),L,Cin,Cout):-
    S==hnf,
    !,
    equal(R,L,Cin,Cout).

equal(L,'$$susp'(_,_,R,S),Cin,Cout):-
    S==hnf,
    !,
    equal(R,L,Cin,Cout).

% La ultima calusula trata el caso de suspensiones no evaluadas. Entonces se
% reduce una de ellas a f.n.c. y se llama recursivamente a equal. Esta nueva
% igualdad se resolvera por una de las clausulas anteriores.
equal(L,R,Cin,Cout):-
    hnf(L,HL,Cin,Cout1),
    equal(HL,R,Cout1,Cout).


%----------------------------------------------------------------------------%
% equalHnf(+L,+R,+Cin,-Cout): estudia la igualdad estricta entre f.n.c.'s (L y R)
%----------------------------------------------------------------------------%

equalHnf(L,R,Cin,Cout):-var(L),!,binding(L,R,Cin,Cout).

equalHnf(R,L,Cin,Cout):-var(L),!,binding(L,R,Cin,Cout).

equalHnf(R,L,Cin,Cout):-
    eqFrontier(R,L,FR/[],FL/[]),!,
    equalList(FR,FL,Cin,Cout).




/*****************************************************************************/
/*             CODE FOR BINDING                      */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% binding(+X,+Y,+Cin.-Cout): resuelve la igualdad estricta entre la variable X y
% la f.n.c. Y, tomando como almacen de entrada Cin y devolviendo Cout como
% almacen de salida.
%----------------------------------------------------------------------------%

binding(X,Y,Cin,Cout):-
    var(Y),
    !,
%B Sonia
    (proj_active -> 
       ((isVarFD(X);isVarFD(Y))->
           (
             cooperation:searchVarsR(X,Cin,Cout1,XR),
             cooperation:searchVarsR(Y,Cout1,Cout2,YR),!,
             XR = YR
           )
           ;
           ((isVarReal(X);isVarReal(Y))->
             (cooperation:searchVarsFD(X,Cin,Out1,XFD), 
              cooperation:searchVarsFD(Y,Cin,Out2,YFD),!,
              ((Out1 == true, Out2 == true) -> XFD = YFD;true),
              Cout2=Cin
              ); Cout2=Cin
           )
       );Cout2=Cin
     ),
%    unifyVar(X,Y,Cin,Cout).
    unifyVar(X,Y,Cout2,Cout3),
% Sonia 2.3.1
    ((clpr_active, cflpfd_active) -> cooperation:cleanBridgeStore(Cout3,Cout);Cout=Cout3).
%E Sonia


binding(X,Y,Cin,Cout):-
    !,
    occursNot(X,Y,ShY,Lst),
    extractCtr(Cin,X,Cout1,CX),
    % rafa 10/07/05: ensure that  Shy is a real number if cflpr is loaded
    % before this change a goal like X/=1, X==2 threw an exception

%FSP 26-02-2007 ::B 
    (
     clpr_active, 
     (\+ cflpfd_active), 
     number(ShY),
     R is ShY*1.0, 
     X = R
    ; 
     X=ShY 
     ),
%::E 

    !,
    propagate(CX,X,Cout1,Cout2), % rafa 10/07/05 The parameter X was ShY before 
    equalList(Lst,Cout2,Cout).


% It may be improved because propagate has the information of ShY is a hnf and
% all elements in CX are hnf's



/*****************************************************************************/
/*             CODE FOR NOT EQUAL                    */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% notEqual(+X,+Y,+Cin,-Cout): resuelve la desigualdad entre dos expresiones
% cualesquiera X e Y tomando como almacen de entrada Cin y devolviendo como 
% almacen de salida Cout. Para resolver la desigualdad X/=Y, hay que hacer las 
% f.n.c's t1 y t2 de X e Y respectivamente y ver que son inconsistentes, i.e.,
% presentan conflictos de constructoras (tienen distintas constructora en la 
% misma posicion).
%----------------------------------------------------------------------------%

notEqual(X,Y,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),hnf(Y,HY,Cout1,Cout2),
    notEqualHnf(HX,HY,Cout2,Cout).


%----------------------------------------------------------------------------%
% notEqualHnf(+C,+Y,+Cin,-Cout): resuelve la desigualdad entre dos f.n.c.'s X e
% Y, tomando como almacen de entrada Cin y devolviendo como almacen de salida 
% Cout.
% First of all, we check if the solver is activated. In such case the
% the disequality constraint is over real numbers, we send it to the the solver
% and forget it.
%----------------------------------------------------------------------------%

% &clpr

%B:: Sonia
notEqualHnf(X,Y,Cin,Cout):-
    (   (cflpfd_active,(isVarFD(X);isVarFD(Y)),!,X#\=Y),
        (proj_active -> 
           (
             cooperation:searchVarsR(X,Cin,Cout1,XR), 
             cooperation:searchVarsR(Y,Cout1,Cout,YR),
             {XR=\=YR}
           ); Cout=Cin
        )     
    )
    ;
    (   (clpr_active,(isVarReal(X);isVarReal(Y)),!,{X=\=Y}),
        (proj_active -> 
           (
             cooperation:searchVarsFD(X,Cin,Out1,XFD), 
             cooperation:searchVarsFD(Y,Cin,Out2,YFD),
            ((Out1 == true, Out2 == true) -> XFD #\= YFD;true)
           );true
        ),     
        Cout=Cin
    ).

%notEqualHnf(X,Y,Cin,Cin):-
%    clpr_active,
%    (isReal(X);isReal(Y)),!,{X=\=Y}.

%E:: Sonia

notEqualHnf(X,Y,Cin,Cout):-var(X),!,notEqualVar(X,Y,Cin,Cout).
notEqualHnf(Y,X,Cin,Cout):-var(X),!,notEqualVar(X,Y,Cin,Cout).
notEqualHnf(R,L,Cin,Cout):-
    eqFrontier(R,L,FR/[],FL/[]),!,
    notEqualList(FR,FL,Cin,Cout)
        ;  % eqFrontier fallo
        Cin=Cout.

%----------------------------------------------------------------------------%
% notEqualVar(+X,+Y,+Cin,-Cout): resuelve la desigualdad entre la variable X y
% la f.n.c. Y tomando Cin y Cout como almacenes de entrada y salida
% respectivamente.
% If Y is a variable (both are variables), we simply put the constraint into
% the store
%----------------------------------------------------------------------------%

notEqualVar(X,Y,Cin,Cout):-
    var(Y),
    !,
    X\==Y,
    addCtr(X,Y,Cin,Cout1),
    addCtr(Y,X,Cout1,Cout).


% These two clauses allow to bind X=false in presence of a contraint of the form
% X/=true (and X=true in presence of X/=false) without do anything more

notEqualVar(X,true,Cin,Cout):-!,hnf(X,false,Cin,Cout).
notEqualVar(X,false,Cin,Cout):-!,hnf(X,true,Cin,Cout).



% In other case we make an occursNot in order to discover if it is a hnf or if
% it has function calls (this is an artificial use of occursNot)

notEqualVar(X,Y,Cin,Cout):-
    occursNot(X,Y,ShY,Lst),
    !,
    contNotEqual(X,Y,ShY,Lst,Cin,Cout).

% It occursNot fail, then they are distinct automatically
notEqualVar(_X,_Y,Cin,Cin).


%----------------------------------------------------------------------------%
% contNotEqual(+X,+Y,+ShY,+Lst,+Cin,-Cout): resuelve la desigualdad entre la
% variable X y la expresion Y que comienza por constructora, utilizando la
% cascara ShY de Y y la lista de restricciones pendientes Lst y tomando como
% almacenes Cin y Cout.
% If the list produced by occursNot unifies with []/[], that is because Y is a
% hnf, and we only add the constraint
%----------------------------------------------------------------------------%

contNotEqual(X,_Y,ShY,[]/[],Cin,Cout):-
    !,
    addCtr(X,ShY,Cin,Cout).


% Y is not a hnf: we generate constructor symbols of the same type ensuring that
% the disequality is satisfied
contNotEqual(X,Y,_,_,Cin,Cout):-
    constructor(Y,C/_N,ArgsY),
    !,
    constr(C,_,_,Dest),
    (genConstructor(Dest,Z,C1,_ArgsZ), % const with <>name and the same 
                       % destination type
    C\==C1, 
    hnf(X,Z,Cin,Cout)
    ;
    genConstructor(Dest,Z,C,ArgsZ),   % The same name and  <>'s Args
    hnf(X,Z,Cin,Cout1),
    notEqualList(ArgsZ,ArgsY,Cout1,Cout)).  



/*****************************************************************************/
/*             CODE FOR FUNCTION ==                      */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% '$$eqFun'(+X,+Y,?H,+Cin,-Cout): H es true si la restriccion X==Y es cierta y 
% false si la restriccion es falsa, tomando como almacenes Cin y Cout.
%----------------------------------------------------------------------------%



% Las dos primeras clausulas operan cuando el resultado viene dado, en cuyo
% caso no hay inconveniente en resolver las restricciones correspondientes.
'$$eqFun'(X,Y,H,Cin,Cout):-H==true,!,equal(X,Y,Cin,Cout).
'$$eqFun'(X,Y,H,Cin,Cout):-H==false,!,notEqual(X,Y,Cin,Cout).

% Las dos siguientes calusulas son operativas cuando uno de los argumentos es
% variable, en cuyo caso se estudian los dos posibles resultados de la funcion
% mediante una disyuncion.
'$$eqFun'(X,Y,H,Cin,Cout):-
    var(X),!,
    (H=true,equal(X,Y,Cin,Cout)
    ;
    H=false,notEqual(X,Y,Cin,Cout)).

'$$eqFun'(X,Y,H,Cin,Cout):-
    var(Y),!,
    (H=true,equal(X,Y,Cin,Cout)
    ;
    H=false,notEqual(Y,X,Cin,Cout)).

% La ultima clausula es la que trata el caso de que ninguno de los argumentos
% sea variable ( pueden ser llamadas a funcion o expresiones que comienzan por 
% un simbolo de constructora). En particular, pueden ser ambos llamadas a 
% funcion y es aqui cuando se intentan evitar las reevaluaciones. 
'$$eqFun'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    eqFunHnf(HX,HY,H,Cout2,Cout).


%----------------------------------------------------------------------------%
% eqFunHnf(+X,+Y,?H,+Cin,-Cout): hace lo mismo que eqFun excepto que solo opera
% con f.n.c.'s.
%----------------------------------------------------------------------------%

eqFunHnf(X,Y,H,Cin,Cout):-
    (var(X);var(Y)),!,'$$eqFun'(X,Y,H,Cin,Cout).

eqFunHnf(X,Y,H,Cin,Cout):-
        eqFrontier(X,Y,FrontierX/[],FrontierY/[]),!,
    eqFunAnd(FrontierX,FrontierY,H,Cin,Cout)
        ;  % eqFrontier fallo
        H=false,
    Cin=Cout.


%----------------------------------------------------------------------------%
% eqFunAnd(+Lst1,+Lst2,?H,+Cin.-Cout): Lst1 y Lst2 son listas de expresiones
% de la misma longitul. H es true si todas las parejas de igualdades entre los
% elementos de ambas listas se evaluan a true y false si alguna de ellas se
% evalua a false.
%----------------------------------------------------------------------------%

eqFunAnd([],[],true,Cin,Cin):-!.


% Non deterministic choice: a conjunction of equalities is true if all of them
% are true and it is false if it is false one of them

eqFunAnd([X1|Rest1],[Y1|Rest2],H,Cin,Cout):-
    '$$eqFun'(X1,Y1,H1,Cin,Cout1),
    eqFunAnd_1(Rest1,Rest2,H1,H,Cout1,Cout).

eqFunAnd([_|Rest1],[_|Rest2],false,Cin,Cout):-
    notEqualList(Rest1,Rest2,Cin,Cout).

eqFunAnd_1(_,_,false,false,Cin,Cin).
eqFunAnd_1(Rest1,Rest2,true,true,Cin,Cout):-
    equalList(Rest1,Rest2,Cin,Cout).





/*****************************************************************************/
/*            CODE FOR FUNCTION /=                   */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% '$$notEqFun'(+X,+Y,?H,+Cin,-Cout): H es false si la restriccion X==Y se evalua
% a true y H es false si la restriccion se evalua a true, tomando como almacenes
% Cin y Cout.
%----------------------------------------------------------------------------%

'$$notEqFun'(X,Y,H,Cin,Cout):-H==true,!,notEqual(X,Y,Cin,Cout).
'$$notEqFun'(X,Y,H,Cin,Cout):-H==false,!,equal(X,Y,Cin,Cout).
%{paco}29-11-96
'$$notEqFun'(X,Y,H,Cin,Cout):-
    '$$eqFun'(X,Y,Z,Cin,Cout),
        negate(Z,H).

negate(true,false) :- !.
negate(false,true).




/*****************************************************************************/
/*            CODE FOR OCCURS CHECK                      */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% occursNot(+X,+Y,-ShY,-LstEqs): X es una variable que no aparece en la cascara
% del termino Y, que se devolvera en ShY. En LstEqs se devuelve la lista de
% igualdades pendientes (es una lista diferencia).
%----------------------------------------------------------------------------%

occursNot(X,Y,ShY,L/L):-var(Y),!,X\==Y,Y=ShY.
occursNot(_,'$$susp'(E,Args,R,S),Z,[Z=='$$susp'(E,Args,R,S)|L]/L):-var(S),!.
occursNot(X,'$$susp'(_,_,R,_),ShR,L/M):-!,occursNot(X,R,ShR,L/M).
occursNot(X,T,ShT,L/M):-
    T=..[Name|Args],
    lstOccursNot(X,Args,ShArgs,L/M),
    ShT=..[Name|ShArgs].

%----------------------------------------------------------------------------%
% lstOccursNot(+X,+LstTerm,-LstSh,-LstEqs): hace el mismo chequeo que occursNot
% pero sobre una lista de terminos en vez de uno solo y devuelve una lista de 
% cascaras. Por ultimo se reconstruye la cascara del termino original a partir
% de las obtenidas para los argumentos y el nombre de la constructora original.
%----------------------------------------------------------------------------%

lstOccursNot(_,[],[],L/L).
lstOccursNot(X,[Ar|Rest],[ShAr|RSh],L/M):-
    occursNot(X,Ar,ShAr,L/L1),
    lstOccursNot(X,Rest,RSh,L1/M).




/*****************************************************************************/
/*               AUXILIAR CODE                       */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% equalList(+L1,+L2,+Cin,-Cout): va resolviendo las igualdades que resultan de
% emparejar los elementos de las listas L1 y L2 donde L1 y L2 son listas de
% igual longitud.
%----------------------------------------------------------------------------%

equalList([],[],Cin,Cin):-!.
equalList([Ar1|R1],[Ar2|R2],Cin,Cout):-
    equal(Ar1,Ar2,Cin,Cout1),
    equalList(R1,R2,Cout1,Cout).


%----------------------------------------------------------------------------%
% equalList(+L/-R,+Cin,-Cout): resuelve las igualdades que se encuentran en la 
% lista, porque la lista contiene elementos de la forma Z==Y.
%----------------------------------------------------------------------------%

equalList([]/[],Cin,Cin):-!.
equalList([(Z==Y)|L]/M,Cin,Cout):-
    equal(Z,Y,Cin,Cout1),
    equalList(L/M,Cout1,Cout).


%----------------------------------------------------------------------------%
% notEqualList(+Lst1,+Lst2,+Cin,-Cout): Lst1 y Lst2 son listas de expresiones
% de la misma longitud y existe alguna desugaldad cierta entre las que resultan 
% de emparejar los elementos de ambas, tomando Cin como almaden de entrada y
% Cout como el de salida.
% Indeterministic choice for doing a pair false with independence of the rest
%----------------------------------------------------------------------------%

notEqualList([X|R1],[Y|R2],Cin,Cout):-
    notEqual(X,Y,Cin,Cout)
    ;
    notEqualList(R1,R2,Cin,Cout).



%----------------------------------------------------------------------------%
% eqFrontier(+X,+Y,-Ls1,-Ls2): existe la frontera de los terminos X e Y y
% Ls1, Ls2 son las listas (diferencia) de terminos entre cuyos elelmentos se
% deben resolver las igualdades (dos a dos) para satisfacer la igualdad X==Y.
% Frontier of two terms. The predicate eqFrontier(T1,T2,L1/R1,L2/R2) extract the
% shell of common constructors of T1 and T2. In the differece lists it puts the
% common part. If the shell contains some distinct constructor for the terms, 
% eqFrontier fails automatically
%----------------------------------------------------------------------------%

eqFrontier(X,Y,[X|L1]/L1,[Y|L2]/L2) :-
        (var(X);var(Y)),!.

eqFrontier(X,Y,FX,FY) :-
    constructor(X,NameX,ArgsX),
    constructor(Y,NameY,ArgsY),!,
%FSP 15-02-2007 
    testEqFunctor(NameX,NameY),
%    NameX==NameY,
    eqFrontierList(ArgsX,ArgsY,FX,FY).

eqFrontier('$$susp'(Fun,Args,R,S),Y,FX,FY) :-
        !,
        (S==hnf,!,
         eqFrontier(R,Y,FX,FY)
         ;
         FX = ['$$susp'(Fun,Args,R,S)|L1]/L1,
         FY = [Y|L2] / L2
        ).

eqFrontier(X,'$$susp'(Fun,Args,R,S),FX,FY) :-
        !,
        (S==hnf,!,
         eqFrontier(X,R,FX,FY)
         ;
         FY = ['$$susp'(Fun,Args,R,S)|L1]/L1,
         FX = [X|L2] / L2
         ).

%----------------------------------------------------------------------------%
% eqFrontierList(+L1,+L2,-Ls1,-Ls2): hace el estudio de la frontera sobre cada 
% par de elementos tomados de L1 y L2. Ls1 y Ls2 son iguales que en eqFrontier.
%----------------------------------------------------------------------------%

eqFrontierList([],[],L1/L1,L2/L2).
eqFrontierList([X|Xs],[Y|Ys],LX/MX,LY/MY) :-
         eqFrontier(X,Y,LX/L1,LY/L2),
         eqFrontierList(Xs,Ys,L1/MX,L2/MY).

 
%FSP 15-02-2007 ::B         
%----------------------------------------------------------------------------%
% testEqFunctor(+X,+Y): Comprueba la igualdad de dos funtores. 
% Si son n�meros, se comprueba si casan 
%----------------------------------------------------------------------------%

testEqFunctor(X/A,Y/A) :-
  (number(X) ->
   testEqNumber(X,Y);
   X==Y).   
   
%----------------------------------------------------------------------------%
% testEqNumber(+X,+Y): Comprueba la igualdad de dos n�meros. 
% Aqu� es donde se decide que dos n�meros, aunque tengan tipos diferentes para 
% Prolog (real vs. int) son iguales o no.
%----------------------------------------------------------------------------%

testEqNumber(X,Y) :-
  RX is X*1.0, RY is Y*1.0, RX==RY.   

%----------------------------------------------------------------------------%
% testEq(+X,+Y): Comprueba la igualdad de dos literales. 
% Asume que dos literales son iguales si los n�meros que aparezcan son 
% compatibles, e.g., testEq(s(0),s(0.0)) tiene �xito
%----------------------------------------------------------------------------%

testEq(X,Y) :-
  number(X),
  !,
  testEqNumber(X,Y).
testEq(X,Y) :-
  var(X),
  !,
  X==Y.
testEq(X,Y) :-
  X=..[NameX|AX],
  !,
  Y=..[NameX|AY],
  testEqList(AX,AY).
  
testEqList([],[]):-!.
testEqList([X|Xs],[Y|Ys]) :-
  testEq(X,Y),
  testEqList(Xs,Ys).
%::E
        
%----------------------------------------------------------------------------%
% constructor(+T,-Nom/-Ar): sirve para ver en tiempo de ejecucion si la 
% catagoria sintactica a la que pertenece la expresion T es una constructora
% (simbolo de constructora o simbolo de funcion aplicado parcialmente).
% We have two constructor (one of arity two and the other of arity three). The
% firts one simply check if what we pass is a hnf and then it returns its name
% and arity. The second one returns the list of arguments two.
%----------------------------------------------------------------------------%

constructor(C,C/0):-number(C),!.
constructor(T,C/N):-
    functor(T,C,N),
    !,
    (constr(C,_,_,_),!
    ;
        funct(C,Ar,_,_,_),!,N<Ar).



constructor(C,C/0,[]):-number(C),!.

constructor(T,C/N,Args):-
    functor(T,C,N),
    !,
    (constr(C,_,_,_),!
    ;
        funct(C,Ar,_,_,_),!,N<Ar), % Arreglado
    T=..[_|Args].


%----------------------------------------------------------------------------%
% genConstructor(+DestType,-Cons,+Name,-Args): Cons es una expresion de tipo
% DestType construida con el nombre de constructora Name y Args es la lista de
% argumentos (variables nuevas) utilizados para su construccion.
%----------------------------------------------------------------------------%

genConstructor(TipDest,Cons,Name,Args):-
    constr(Name,Ar,_,TipDest),  % We look for the same destination type
    functor(Cons,Name,Ar),      % build the term
    Cons=..[Name|Args].     % extract the arguments (new vars.)






%%%%%%%%%%%%%%%%%%%%%%%%%%%%% STORE DEAL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----------------------------------------------------------------------------%
% propagate(+Lst,+H,+Cin,-Cout)
% Cout es el almacen de desigualdades resultante de resolver todas las
% desigualdades entre H y los elementos de Lst, tomando como almacen de entrada
% Cin.
%----------------------------------------------------------------------------%

propagate([],_,Cin,Cin):-!.
propagate([C|R],Y,Cin,Cout):-
    (
        var(C),  % We don't need to solve Y /= C,
                         % because C is a variable and it already had,
                         % the disequality C /= Y.
                         % Notice that C can not be Y
        !,
        Cout1=Cin
    ;
        notEqualTerm(Y,C,Cin,Cout1)),
    propagate(R,Y,Cout1,Cout).


%----------------------------------------------------------------------------%
% notEqualTerm(+T1,+T2,+Cin,-Cout): notEqual especialized for terms only with 
% contructors. Because of eficience, we don't make any kind of occur-check, and
% then notEqualTerm(X,s(X)), instead of be trivially satisfiable as in the
% notEqual(X,s(X)) case, inserts the constraint X /= s(X)
%----------------------------------------------------------------------------%

notEqualTerm(T1,T2,Cin,Cout):-
    var(T1),
    !,
    notEqualVarTerm(T1,T2,Cin,Cout).
notEqualTerm(T1,T2,Cin,Cout):-
    var(T2),
    !,
    notEqualVarTerm(T2,T1,Cin,Cout).
notEqualTerm(N1,N2,Cin,Cout):-
    number(N1),
    !,
    \+ testEqNumber(N1,N2), Cin=Cout.
notEqualTerm(T1,T2,Cin,Cout):-
    constructor(T1,C1/A1,Args1),
    constructor(T2,C2/A2,Args2),
    (C1/A1\==C2/A2,!,Cout=Cin
    ;
    notEqualTermList(Args1,Args2,Cin,Cout)),
    % rafa 09/07/05: The goal X/=(1,1), X==(2,2) returned the answer X-->(2,2)  twice
    % The next cut is introduced to avoid such repetition
    !   
    .


%----------------------------------------------------------------------------%
% notEqualVarTerm(+X,+Y,+Cin,-Cout): resuelve la desigualdad entre una variable
% y una forma normal.
%----------------------------------------------------------------------------%

notEqualVarTerm(X,Y,Cin,Cout):-
    var(Y),
    !,
    X\==Y,
    addCtr(X,Y,Cin,Cout1),
    addCtr(Y,X,Cout1,Cout).
notEqualVarTerm(X,Y,Cin,Cout):-
    !,
    addCtr(X,Y,Cin,Cout).

%----------------------------------------------------------------------------%
% notEqualTermList(+L1,+L2,+Cin,-Cout): hace el notEqualTerm para cada par de
% argumentos tomados de L1 y L2, donde L1 y L2 son de la misma longitud.
%----------------------------------------------------------------------------%

notEqualTermList([X|R1],[Y|R2],Cin,Cout):-
    (notEqualTerm(X,Y,Cin,Cout)
    ;
    notEqualTermList(R1,R2,Cin,Cout)).




%%%%%%%%%%%%%%%%%%%%%%%%% CONSTRAINT HANDLING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%----------------------------------------------------------------------------%
% addCtr(+X,+Term,+Cin,-Cout)
% Insertion of a new constraint Var/=Term
% Cout es el almacen resultante de anyadir la desigualdad X/=Term al almacen de
% entrada Cin, donde X es una variable y Term una forma normal.
%----------------------------------------------------------------------------%

addCtr(X,Term,[],[X:[Term]]):-!.
addCtr(X,Term,[Y:Ctr|R],[Y:[Term|Ctr]|R]):-
    X==Y,
    !.
addCtr(X,Term,[F|R],[F|R1]):-
    addCtr(X,Term,R,R1).


%----------------------------------------------------------------------------%
% extractCtr(+Cin,+X,-Cout,-CX): CX es la lista de restricciones asociadas a la
% variable X en el almacen Cin, y Cout es el almacen resultante de eliminar
% X:CX de Cin.
% Extraction of constraints asociated to a variable. We extract the constraints
% asociated from the store and return them in the last argument
%----------------------------------------------------------------------------%

extractCtr([],_,[],[]):-!.
extractCtr([V:W|R],X,R,W):-
    X==V,
    !.

% rafa 6-02-05: pon�a
% extractCtr([V:W|R],X,[V:W|R1],L):-
% he cambiado V:W por Other  para que no se rompa al incluir nuevas restricciones
extractCtr([Other|R],X,[Other|R1],L):-
    extractCtr(R,X,R1,L).


%----------------------------------------------------------------------------%
% unifyVar(+X,+Y,+Cin,-Cout)
% Unification on two vars X Y: if they are not the same var, nothing. Else we
% unify them and do the union of their constraints
%----------------------------------------------------------------------------%
unifyVar(X,Y,Cin,Cout):-
    X==Y,
    !,
        % rafa, 6 de Febrero de 2005: se a�ade la restriccion tot(X)
    newCtrTot(X,Cin,Cout). 

unifyVar(X,Y,Cin,Cout):-
    extractTwoCtr(X,Y,Cin,Cout1,CX,CY),
    X=Y,
    !,
    update(X,CX,CY,Cout1,Cout2),
        newCtrTot(X,Cout2,Cout).

%----------------------------------------------------------------------------%
% extractTwoCtr(+X,+Y,+Cin,-Cout,-CX,-CY)
% extracting constraints of two vars X Y in CX CY. This form of operation in
% inify is equivalent to perform two extracCtr, but improves the way, because
% we have got both Stores in one pass
%----------------------------------------------------------------------------%
extractTwoCtr(_,_,[],[],[],[]).
extractTwoCtr(X,Y,[Z:CZ|R],Cout,CX,CY):-
    (
        X==Z,
        !,
        CX=CZ,
        extractCtr(R,Y,Cout,CY)
    ;
        Y==Z,
        !,
        CY=CZ,
        extractCtr(R,X,Cout,CX)
    ).
extractTwoCtr(X,Y,[Ctr|R],[Ctr|R1],CX,CY):-extractTwoCtr(X,Y,R,R1,CX,CY).


%----------------------------------------------------------------------------%
% update(+X,+CX,+CY,+Cin,-Cout): genera la nueva lista de desigualdades
% asociada a una variable X que se ha ligado con otra Y. Esta lista es el
% resultado de unir las desigualdades de X con las de Y (concatenacion de
% listas), pero ademas en el recorrido se comprueba que no existia la
% restriccion X/=Y, que tras la ligadura X=Y apareceria como X/+Y.
% Union of constraints asociated to vars X Y checking that beteween these
% constraints is not X/=Y
%----------------------------------------------------------------------------%

update(Y,[],CY,Cin,Cout):-
    insertCtrs(Y,CY,Cin,Cout).
update(Y,[T|Ts],CY,Cin,Cout):-
    Y\==T,      % comprobacion de no existe una restriccion X/=Y
    !,
    update(Y,Ts,[T|CY],Cin,Cout).


%----------------------------------------------------------------------------%
% insertCtrs(+Y,+CY,+Cin,-Cout): introduce en Cin la variable Y con sus
% restricciones asociadas CY.
%----------------------------------------------------------------------------%

insertCtrs(_,[],Cin,Cin):-!.    % esta clausula solo sirve para no meter
                % listas de restricciones vacias
insertCtrs(Y,CY,Cin,[Y:CY|Cin]).


/*****************************************************************************/
/*              CODE FOR EQUALNF                     */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% equalnf(+S,+T,+Cin,-Cout): devuelve la igualdad entre la variable nueva S y la
% fn T siendo los almacenes de restricciones Cin y Cout.
%----------------------------------------------------------------------------%

equalnf(S,T,Cin,Cout):- nf(T,S,Cin,Cout).

/* Realmente ese predicado seria:
equalnf(S,T,Cin,Cout):-
    nf(T,TE,Cin,Cout),
    S=TE.
pero en el predicado de arriba se ha hecho directamente la unificacion.
*/


/*****************************************************************************/
/*               CODE FOR NF                         */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% nf(+E,-H,+Cin,-Cout): H es el resultado de evaluar una forma normal de cabeza
% para E tomando como restricciones de entrada Cin. Cout son las restricciones
% resultantes de este computo.
%----------------------------------------------------------------------------%

nf(E,H,Cin,Cout):-
        var(E),
        !,
        (
                var(H),
                !,
                H=E,
                newCtrTot(E,Cin,Cout)
        ;
                extractCtr(Cin,E,Cout1,CE),
                H=E,
                propagate(CE,H,Cout1,Cout)
        ).

nf('$$susp'(Fun,Args,R,S), H,Cin,Cout):-
        !,
        hnf('$$susp'(Fun,Args,R,S), H1,Cin,Cout1),
        nf(H1,H,Cout1,Cout).

nf(T,H,Cin,Cout):-
      !,
      functor(T,C,N),
      functor(H,C,N),
      examine_args(1,N,T,H,Cin,Cout).

examine_args(I,N,T,H,Cin,Cout):-
      I =< N,
      !,
      arg(I,T,A),
      nf(A,A2,Cin,Cout1),
      arg(I,H,A2),
      I2 is I+1,
      examine_args(I2,N,T,H,Cout1,Cout).

examine_args(_I,_N,_T,_H,Cin,Cin).

%::B Sonia
/*****************************************************************************/
/*              FINITE DOMAIN CONSTRAINTS                 */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% isVarFD(X) success iff X is a var affected by some finite constraint
%----------------------------------------------------------------------------%

isVarFD(X):- var(X),fd_var(X).

isVarReal(X):- 
    var(X),
    clpr:get_atts(X,L),
    !,
    L\==[].

%::E Sonia

/*****************************************************************************/
/*              REAL CONSTRAINTS                 */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% isReal(X) success iff X is a number or X is a var affected by some constraint
%----------------------------------------------------------------------------%

isReal(X):-number(X),!.
isReal(X):-
    var(X),


%080199
% el dump ya esta incorporado a la libreria clpr.
    %linear:dump([X],_,L),
% La llamada dump([X],_,L) devuelve en la lista L todas las restricciones sobre
% reales en las que interviene la variable X mediante proyeccion. Este
% predicado no esta disponible en la version 3.5 de Sicstus Prolog, pero la
% version 3.6 lo incluye como parte del interface del resolutor.

% 26/11/99 mercedes
% En la version 3.7.1 de Sicstus Prolog en L aparecen todas las restricciones
% sobre reales en las que interviene la variable X mediante proyeccion pero solo
% las restricciones en las que interviene unicamente la variable X, es decir,
% que si tenemos la restriccion {X = Y +3} y queremos que nos salga esa
% restriccion, debemos hacer dump([X,Y],_,L).
% Por tanto ahora no nos vale el dump para esto porque para saber si X es real
% cuando X no es un numero debemos saber si X es una variable afectada por
% alguna restriccion aunque en esa restriccion aparezcan mas variables.
% Para solucionarlo usamos get_atts. Esto es porque el resolutor usa variables
% con atributos, por tanto si una variable tiene restricciones asociadas esta
% en el resolutor y por tanto tendra atributos. Asi, para saber si una variable
% aparece en alguna restriccion sobre reales hay que ver si la lista de atributos
% es o no vacia.
    %dump([X],_,L),
    clpr:get_atts(X,L),
    !,
    L\==[].





% CONVERSION OF DISEQUALITY CONSTRAINTS (SYNTACTIC) TO REAL CONSTRAINTS
% THIS CODE IS ONLY USED WHEN THE SYSTEM IS RUNNING WITH REALS

/*
Disequality constraints beteween vars are dealt as syntactic ones. They are 
stored as any other one. When we throw a constraint to the solver that involves
one of this vars, the disequality constraints that were affecting it pass to be
real constraints instead of syntactic ones. At this point all disequality 
contraints that affect this var must be passed to solver, in order to allow it
to look for inconsistences that may do it to fail.
*/

% rafa 30/01/06
% The old version of toSolver is renamed to toSolverContinue
% the new toSolver simply calls to toSolverContinue if the debugging switch is off
% If it is on, it collects all the variables in the term X, storing them in the constraint store in the form real(Var)
% This is done in order to keep the information about all the variables implied in debugging with real numbers 

% toSolver(+X,+Cin,-Cout)
toSolver(X,Cin,Cout):-
   (ddtFlag, 
    addRealVariables(X,Cin,Cout)
    ;
    toSolverContinue(X,Cin,Cout)
    ),!.

%----------------------------------------------------------------------------%
% toSolverContinue(+X,+Cin,-Cout): si X es una variable entonces toda desigualdad
% Y/=Z de Cin para la que Cin contiene una secuencia (posiblemente unitaria)
% X/=X1,X1/=X2,...,Xn/=Y,Y/=Z es lanzada al resolutor en la forma {Y=\=Z}.
% Cout es el resultado de eliminar de Cin todas las desigualdades que han
% pasado al resolutor. Si X no es variable deja el almacen intacto y no pasa 
% nada al resolutor.
%----------------------------------------------------------------------------%

toSolverContinue(X,Cin,Cin):-nonvar(X),!.

toSolverContinue(X,Cin,Cout):-
    extractCtr(Cin,X,Cout1,CX),
    passToSolver(X,CX,Cout1,Cout).


%----------------------------------------------------------------------------%
% passToSolver(+X,+CX,+Cin,-Cout): este predicado lanza al resolutor, una a una,
% las desigualdades asociadas a la variable X, pero ademas, si el otro miembro
% es tambien una variable, llama recursivamente a toSolver con esta nueva
% variable para propagar la cesion de restricciones.
%----------------------------------------------------------------------------%

passToSolver(_,[],Cin,Cin).
passToSolver(X,[Y|R],Cin,Cout):-
    {X=\=Y},
%B Sonia
    (proj_active -> 
           (
             cooperation:searchVarsFD(X,Cin,Out1,XFD), 
             cooperation:searchVarsFD(Y,Cin,Out2,YFD),
            ((Out1 == true, Out2 == true) -> XFD #\= YFD;true)
           );true
     ),     
     Cout=Cin,
%E Sonia
    (
        var(Y),
        !,
        toSolver(Y,Cin,Cout1),
        passToSolver(X,R,Cout1,Cout)
    ;
        passToSolver(X,R,Cin,Cout)
    ).

%::B rafa 30/01/06
addRealVariables(X,Cin,[real(X)|Cin]) :- 
    var(X),
    !.
addRealVariables(X,Cin,Cin) :- 
    atom(X),
    !.
addRealVariables(X,Cin,Cout) :- 
    X =.. [_F,Args],
    !,
    mapAddRealVariables(Args,Cin,Cout).
    
mapAddRealVariables([],Cin,Cin).
mapAddRealVariables([X|Xs],Cin,Cout) :-
    !,
    addRealVariables(X,Cin,Cout1),
    mapAddRealVariables(Xs,Cout1,Cout).
%::E rafa 30/01/06


%::B Sonia Hacemos el /= para FD igual que para reales
% No hace falta guardar las variables para la depuraci�n
% todav�a no est� implementada la depuraci�n en FD

listToSolverFD([],Cin,Cin).
listToSolverFD([H|R],Cin,Cout):-
    toSolverFD(H,Cin,Cin1),
    listToSolverFD(R,Cin1,Cout).
 
toSolverFD(X,Cin,Cin):-nonvar(X),!.

toSolverFD(X,Cin,Cout):-
    extractCtr(Cin,X,Cout1,CX),
    passToSolverFD(X,CX,Cout1,Cout).


%----------------------------------------------------------------------------%
% passToSolverFD(+X,+CX,+Cin,-Cout): este predicado lanza al resolutor, una a una,
% las desigualdades asociadas a la variable X, pero ademas, si el otro miembro
% es tambien una variable, llama recursivamente a toSolverFD con esta nueva
% variable para propagar la cesion de restricciones.
%----------------------------------------------------------------------------%

passToSolverFD(_,[],Cin,Cin).
passToSolverFD(X,[Y|R],Cin,Cout):-
    X#\=Y,
    (proj_active -> 
           (
             cooperation:searchVarsR(X,Cin,Cout1,XR), 
             cooperation:searchVarsR(Y,Cout1,Cout,YR),
             {XR=\=YR}
           ); Cout=Cin
    ),
    (
        var(Y),
        !,
        toSolverFD(Y,Cin,Cout1),
        passToSolverFD(X,R,Cout1,Cout)
    ;
        passToSolverFD(X,R,Cin,Cout)
    ).
%::E Sonia



% 02/06/00 mercedes: regla operacional del do para la e/s

/*****************************************************************************/
/*               CODE FOR DO                         */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% do(+[V1,...,Vk],+[P1,...,Pk,R],-H,+Cin,-Cout): H es el resultado de evaluar:
% do{V1 <- P1;
%    ........
%    Vk <- Pk;
%    R}
%----------------------------------------------------------------------------%

'$do'([],[R],'$io'(H),Cin,Cout):-
    introduceSusp(R,R1,execution),
    hnf(R1,'$io'(H),Cin,Cout).

'$do'([V|Vs],[P|Ps],H,Cin,Cout):-
    introduceSusp(P,P1,execution),
    hnf(P1,'$io'(V),Cin,Cout1),
    '$do'(Vs,Ps,H,Cout1,Cout).


% 08/06/00 mercedes: se mete el codigo para las listas intensionales

/*****************************************************************************/
/*               CODE FOR INTENSIONAL                        */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% intensional(+Exp,+['<-'(V,L),B|R],-H,+Cin,-Cout): H es el resultado de evaluar:
% la lista intensional [e || V <- L, B,...]
%----------------------------------------------------------------------------%

'$intensional'(E,[],':'(H,[]),Cin,Cout):-
    !,
    introduceSusp(E,E1,execution),
    hnf(E1,H,Cin,Cout).


'$intensional'(E,['<-'(V,L)|R],H,Cin,Cout):-
    !,
    '$mapgen'(funciona(E,R,V),L,H1,Cin,Cout1),
    '$concat'(H1,H,Cout1,Cout).


% 08/09/00 mercedes (Se ha tenido que modificar el codigo para las listas
% intensionales para arreglar el error:
% f 1 = 1
% f 2 = 2
% g 2 = 1
% g 5 = 2
% Objetivo: [X || X <- [1,2], f X == g Y] == L
% devolvia como solucion [1] en vez de [1,2]

'$intensional'(E,[B|Q],H,Cin,Cout):-
    introduceSusp(B,H1,execution),
    introduceSusp(intensional(E,Q),H2,execution),
    hnf(H1,true,Cin,Cout1),
    hnf(H2,H,Cout1,Cout).
    
    %'$if_then_else'(H1,H2,[],H,Cin,Cout).


'$intensional'(E,[B|Q],[],Cin,Cout):-
    introduceSusp(B,H1,execution),
    introduceSusp(intensional(E,Q),H2,execution),
    hnf(H1,false,Cin,Cout1).



'$concat'([],[],Cin,Cin):- !.

'$concat'(':'(X,Xs),NL,Cin,Cout):-
    !,
    '$concat'(Xs,NXs,Cin,Cout),
    '$newappend'(X,NXs,NL).
    

'$newappend'([],X,X):- !.

'$newappend'(':'(A,B),C,':'(A,D)):- !,'$newappend'(B,C,D).


'$mapgen'(F,L,H,Cin,Cout):-
    map(_,C),
    !,
    C1 is C+1,
    assertamap(F,C1),
    (
     L= ':'(X,Y),
     !,
     hnf(L,HL,Cin,Cout1)
    ;
     introduceSusp(L,L1,execution),   % Este es el caso en el que hay una
     hnf(L1,HL,Cin,Cout1)         % funcion o una lista intensional
    ),
    '$mapgen_aux'(HL,C1,H,Cout1,Cout).

'$mapgen'(F,L,H,Cin,Cout):-
    assertamap(F,1),
    (
     L= ':'(X,Y),
     !,
     hnf(L,HL,Cin,Cout1)
    ;
     introduceSusp(L,L1,execution),   % Este es el caso en el que hay una
     hnf(L1,HL,Cin,Cout1)         % funcion o una lista intensional
    ),
    '$mapgen_aux'(HL,1,H,Cout1,Cout).
    

'$mapgen_aux'([],C,[],Cin,Cin):- !,retractmap(F,C).

'$mapgen_aux'(':'(X,Xs),C,':'(NX,NXs),Cin,Cout):-
    !,
    map(F,C),
    hnf(X,X1,Cin,Cout1),
    '$aplicar'(F,X1,NX,Cout1,Cout2),
    hnf(Xs,Xs1,Cout2,Cout3),
    '$mapgen_aux'(Xs1,C,NXs,Cout3,Cout).



'$aplicar'(F,X,NX,Cin,Cout):-
    F=..[Name|Args],
    !,
    append(Args,[X,NX,Cin,Cout],NArgs),
    F1=..[Name|NArgs],
    F1.



funciona(E,Q,V,A,H,Cin,Cout):- V=A,'$intensional'(E,Q,H,Cin,Cout).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%
% Rafa: optimizacion de equal para el depurador.
%
% 27/08/03
%
%
equalDebug(R,L,Cin,Cout):-
    ddtFlag,
    constructor(L,C/N),
    !,
    functor(T,C,N),
    hnf(R,T,Cin,Cout1), % 20-11-04 Cout en lugar de Cout1
    eqFrontierDebug(L,T,Cout1,Cout).

equalDebug(R,L,Cin,Cout):-
    equal(R,L,Cin,Cout).

eqFrontierDebug('$$tup'((true,V)), '$$tup'((true,R)),Cin,Cout) :-
      !,
%      writeStatistics,
%     createRunTimeStatistics,
%      write('Generating the Computation Tree ...'),nl,
      nfDebug(R,V,Cin,Cout).
%        write('done .'),nl.





%----------------------------------------------------------------------------%
% nf(+E,-H,+Cin,-Cout): H es el resultado de evaluar una forma normal de cabeza
% para E tomando como restricciones de entrada Cin. Cout son las restricciones
% resultantes de este computo.
%----------------------------------------------------------------------------%

%----------------------------------------------------------------------------%
% nfDebug(+E,-H,+Cin,-Cout): H es el resultado de evaluar una forma normal de cabeza
% para E tomando como restricciones de entrada Cin. Cout son las restricciones
% resultantes de este computo.
%----------------------------------------------------------------------------%

nfDebug(E,H,Cin,Cout):-
    hnfRunTimeStatistics,
    nfDebug2(E,H,Cin,Cout).

nfDebug2(E,H,Cin,Cin):-
        var(E),
        !,
        H=E.


nfDebug2('$$susp'(Fun,Args,R,S), H,Cin,Cout):-
    !,
    (S==hnf,!,nfDebug(R,H,Cin,Cout)
    ;
    S = hnf,
    R = H,
    nfDebugSusp(Fun,Args,H,Cin,Cout)
    ),
    !.

nfDebugSusp('$cTreeClean',Args, H,Cin,Cout):-
    !,
    nfDebugClean(Args,H,Cin,Cout).


nfDebugSusp(Fun,Args, H,Cin,Cout):-
        !,
%   write(Fun),
    hnf_susp(Fun,Args,H1,Cin,Cout1),
    nfDebug(H1,H,Cout1,Cout).


% cTrees
nfDebug2(cTreeNode(Name,Args,Result,Body,Conds,NumRule,WeAre),
          ct(Lhs,Result2,"0",NumRule2,WeAre2),Cin,Cout):-
          !,
          toyStringToList(Name,Name3),
          name(Name2,Name3),
          toyStringToList(NumRule,NumRule2),
          toyListToNfList(Args,Args2,Cin,Cout1),
          nfDebug(Result,Result2,Cout1,Cout2),
          Lhs =.. [Name2 |  Args2],
          nfDebug(WeAre,WeAre2,Cout2,Cout).

% lists
nfDebug2([],[],Cin,Cin):-!.

% otras estructuras
nfDebug2(T,H,Cin,Cout):-
      !,
      functor(T,C,N),
      functor(H,C,N),
      examine_argsDebug(1,N,T,H,Cin,Cout).

examine_argsDebug(I,N,T,H,Cin,Cout):-
      I =< N,
      !,
      arg(I,T,A),
      nfDebug(A,A2,Cin,Cout1),
      arg(I,H,A2),
      I2 is I+1,
      examine_argsDebug(I2,N,T,H,Cout1,Cout).

examine_argsDebug(_I,_N,_T,_H,Cin,Cin).


nfDebugClean([[]],[],Cin,Cin) :- !.
nfDebugClean(['$$tup'((A,B)):Xs],H,Cin,Cout) :-
    hnf(A,ANF,Cin,Cout1),
    !,
    nfDebugCleandVal(ANF,B,Xs,H,Cout1,Cout).

nfDebugCleandVal(pValBottom,B,Xs,H,Cin,Cout) :-
    !,
     nfDebugClean([Xs],H,Cin,Cout).

nfDebugCleandVal(_,B,Xs,H,Cin,Cout) :-
     nfDebug(B,Y,Cin,Cout1),
     !,
     nfDebugCleanTree(Y,Xs,H,Cout1,Cout).

nfDebugCleanTree(cTreeVoid,Xs,H,Cin,Cout) :-
        !,
        nfDebugClean([Xs],H,Cin,Cout).

nfDebugCleanTree(Y,Xs,[Y|Ys],Cin,Cout) :-
        !,
        nfDebugClean([Xs],Ys,Cin,Cout).

toyListToNfList([],[],Cin,Cin):-!.
toyListToNfList(X:Xs,[XNf|XsNf],Cin,Cout):-
    !,
    nfDebug(X,XNf,Cin,Cout1),
    toyListToNfList(Xs,XsNf,Cout1,Cout).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% tot constraint %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%----------------------------------------------------------------------------%
% newCtrTot(+X,+Cin,-Cout)
% adds a new constraint tot(X) to cin storing the result in Cout
% If tot(X)  is already in Cin it is not repeated and Cout will be Cin
%----------------------------------------------------------------------------%
newCtrTot(X,Cin,Cin ):- member(X,Cin), !.
newCtrTot(X,Cin,[tot(X)|Cin] ):-  !.

mapNewCtrTot([],Cin,Cin).
mapNewCtrTot([X|Xs],Cin,Cout) :- 
     !,
     newCtrTot(X,Cin,Cout1),
     mapNewCtrTot(Xs,Cout1,Cout).

%----------------------------------------------------------------------------%
% cleanTotCtrStore(+Cin,-Cout)
% Cout will be Cin with all the tot(X) constraints consistent.
%
% The tot constraints in Cin can become inconsistent because some variables
% can become bounded during the computation. Hence we can find nonsense constraint
% as "tot(suc(zero))" which must be cleaned. 
% The cleaning will not only delete inconsistent tot-constraints but it will also
% include new ones. For instance tot(a(X,b(Y))) must be replaced by tot(X) and tot(Y)
% (provinding that tot(X) and tot(Y)  are not already in the store).
% Observation: and inconsistency of repetition cannot occur. Before including
% any new tot-constraint this is checked. Therefore now we do not check it
%----------------------------------------------------------------------------%
cleanTotCtrStore(Cin,Cout) :-
     !,
     eliminateNonVarTotCtr(Cin,Cout1,[],L),
     mapNewCtrTot(L,Cout1,Cout2), 
     eliminateTotDuplicates(Cout2,Cout).


%----------------------------------------------------------------------------%
% eliminateNonVarTotCtr(+Cin,-Cout,+Lin,-Lout)
% Removes from Cin all the constraints tot(t) with t a non-var, and stores the
% result in Cout. The variables in such terms t will be stored in Lout. 
% Precond.: Lin must be [] in the first call
%----------------------------------------------------------------------------%
eliminateNonVarTotCtr([],[],L,L).

eliminateNonVarTotCtr([tot(X)|Cin],[tot(X)|Cout],Lin,Lout) :- 
     var(X),
     !,
     eliminateNonVarTotCtr(Cin,Cout,Lin,Lout).

% if X is not a variable ....
eliminateNonVarTotCtr([tot(X)|Cin],Cout,Lin,Lout) :- 
    !,
    extractVariables(X,Lin,Lout1),
    eliminateNonVarTotCtr(Cin,Cout,Lout1,Lout).

% if it is another constraint, it is simply skipped 
eliminateNonVarTotCtr([Other|Cin],[Other|Cout],Lin,Lout):-
        !,
    eliminateNonVarTotCtr(Cin,Cout,Lin,Lout).




%----------------------------------------------------------------------------%
% eliminateTotDuplicates(+Cin,-Cout)
% remove the repeated tot(X) elements of Cin
% Cout will be Cin without repeated tot constraints
%----------------------------------------------------------------------------%
eliminateTotDuplicates([],[]).
eliminateTotDuplicates([tot(X)|R],[tot(X)|R2]) :-
   !,
   removeElement(tot(X),R,RAux),
   eliminateTotDuplicates(RAux,R2).
   
eliminateTotDuplicates([Other|Rest],[Other|Rest2]) :-
   !,
   eliminateTotDuplicates(Rest,Rest2).


%----------------------------------------------------------------------------%
% removeElement(+T,+Lin,-Lout)
% removes all the occurrences of T fromLin. The result is Lout
% The == is used for equality
%----------------------------------------------------------------------------%
removeElement(T,[],[]).
removeElement(T,[A|B],B2) :-
   T==A,
   !,
   removeElement(T,B,B2).

removeElement(T,[A|B],[A|B2]) :-
   !,
   removeElement(T,B,B2).

%----------------------------------------------------------------------------%
% extractVariables(+T,+Lin,-Lout)
% Extracts the list Lt of vars in t.
% PostCond: Lout = Lt++Lin
%----------------------------------------------------------------------------%
extractVariables(T,Lin,[T|Lin]) :-
    var(T), % this cannot happen in the first call but in the recursive calls
    !.

extractVariables(T,Lin,Lin) :-
    atomic(T),
    !.

extractVariables([],Lin,Lin) :-
    !.

extractVariables([X|Xs],Lin,Lout) :-
    !,
    extractVariables(X,Lin,Lout1),
    extractVariables(Xs,Lout1,Lout).

extractVariables(T,Lin,Lout) :-
    !,
    T =.. [F|Args],
    extractVariables(Args,Lin,Lout).




