%-----------------------------------------------------------------------------%
% navigating.pl
%-----------------------------------------------------------------------------%
/*
- Author: Mercedes

- Description: Este modulo contiene el algoritmo para navegar el arbol de
depuracion.

- Modules which import it:

- Modules imported into it:

- Modified:
    26/10/99 mercedes (modules).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(navigating,[graphicalInterface/2, navigateText/2, rootBasicFact/2,whoAreMyChildren/2,
                                      getOracleAnswer/1]).

:- load_files(tools,[if(changed),imports([concatLsts/2,deleteElement/3,append/3,
                      insertLst/3,member/2,member_relax/2])]).

:- load_files(goals,[if(changed),imports([eliminateSweepings/1])]).

:- load_files(pVal,[if(changed),imports([pValToPrologString/2,atomToPrologString/3,
                                listAtomsToString/2,toyStringToList/2,simpleValue/2,
                       constraintToPrologString/2])]).

:- load_files(entailment,[if(changed),imports([entails/2,  entails/3, totalTerm/1])]).

:- load_files(dyn,[if(changed)]).

% rafa 27-09-03
:- load_files(basicFact,[if(changed),imports([basicFact/2])]).

:- load_files(toycomm,[if(changed),imports([hnf/4, nf/4, nfDebug/2])]).

:- use_module(library(system)).

:- use_module(library(terms)).


navigateText(Tree,Store) :-
    navigate(Tree,Result),
    (
     Result=weAreOkDaddy,
     nl,
     write('Any wrong rule has been found'),
    write(' Press Enter to continue '),
    get0(_),
    nl
    ;
     true
    ),
        nl,
    nl,
    !.

navigate(Tree,Result) :-
    !,
    (
     specificationOption,
     Specification=yes
     ;
     Specficication=no
     ),
    navigate(Tree,Result, [],TrustedOut, [],ConsideredOut, Specification) .


navigate(Tree,Result,TrustedIn,TrustedOut,ConsideredIn,ConsideredOut,Specification) :-
    !,
    hnf(Tree,Tree2),
    whoAreMyChildren(Tree,WeAre,TrustedIn,TrustedOut1,ConsideredIn, ConsideredOut1,Specification),
    navigateChildren(WeAre,TrustedOut1,TrustedOut,ConsideredOut1,ConsideredOut,Specification,Result).

hnf(A,B) :-
    !,
    hnf(A,B1,[],[]),
    value(B1,B).

value(A,B):-
      A = '$$susp'(Fun,Args,R,S),
       !,
       value(R,B).

value(R,R):-
    !.

nf(A,B) :-
    !,
    nf(A,R,[],_),
       value(R,B).

navigateChild(Child,TrustedIn,TrustedOut,ConsideredIn, ConsideredOut,Specification,Surprise):-
    !,
    whoAreMyChildren(Child,WeAre,TrustedIn,TrustedOut1,ConsideredIn, ConsideredOut1,Specification),
        navigateChildren(WeAre,TrustedOut1,TrustedOut,ConsideredOut1, ConsideredOut,Specification,Surprise),
        (
         Surprise==weAreOkDaddy,
         !,
         showBuggyNode(Child)
    ;
         true
        ).

% Surprise puede ser
% - weAreOkDaddy
% - weAreSickDaddy
% - stopDaddy

navigateChildren([],I,I,NotI,NotI,Specification,weAreOkDaddy):-
    !.
navigateChildren(L,I,IOut,NotI,NotIOut,Specification,Surprise):-
    !,
    nl,
        write('Consider the following facts: '),
       nl,
        writeArrowsList(L,0,NumArrows),
        nl,
        write('Are all of them valid? ([y]es / [n]ot) / [a]bort) '),
    getOracleAnswer(Answer1),
%        getOracleInformation(Answer),
        (
     (Answer1==121; Answer1==98),
     !,
     Surprise = weAreOkDaddy,
     insertOks(L,I,IOut),
     NotIOut=NotI
    ;
         % no
     (Answer1==110; Answer1==78),
     !,
     % Navegar el hijo; la respuesta que devuelva sera tb la del padre
          getErroneousChild(NumArrows,L,Child),
        (Error == error,
         navigateChildren(L,I,IOut,NotI,NotIOut,Specification,Surprise)
        ;
            rootArrow(Child,Arrow),
            insertNos(Arrow,NotI,NotI2),
            Surprise= weAreSickDaddy,
            navigateChild(Child,I,IOut,NotI2,NotIOut,Specification,_)
        )
    ;
         % abort
     (Answer1==97; Answer1==65),
     !,
     Surprise = stopDaddy,
     IOut = I,
     NotIOut = NotI,
     write('Debugging session quited by the used')
    ),
    !.

displayHelpTopDown :-
    !,
    nl,
    write('--------------------------------------------------------------------- '), nl,
    write(' Provide one of the following commands: '), nl,nl,
    write('     q: quits the navigator'), nl,
    write('     h: shows this help'), nl,
    write('     a: indicates that all the nodes in the list are valid'), nl,
    nl,
    write(' or enter a sequence of comma-separated commands ending in a full stop.  '), nl,
    write(' Each command  can be of the form:'), nl,nl,
    write('     vN:  The Nth element of the list  is  valid.'), nl,
    write('     nN:  The Nth element of the list  is  non-valid.'), nl,
    write('     tN:  The function used in the Nth element of the list is "trusted".'), nl,
    write('     cN:  The Nth element of the list  is  non-valid and  '),nl,
    write('             the navegation must proceed descending by this node.'), nl,
    write('             Only one cN command must be included'), nl,
        write('--------------------------------------------------------------------- '), nl.




% navega un arbol cuya raiz es erronea
erroneousChild(1,[Child],Child):-
    !.

erroneousChild(NumArrows,Number,L,Child,Error):-
     !,
     %write('Enter the number of a non-valid fact followed by a fullstop: '),
     checkOracleNumber(NumArrows,Number,Error),
     getNthElement(L,Number,Child).

% Selecciona un hijo err�neo
getErroneousChild(1,[Child],Child):-
    !.

getErroneousChild(NumArrows,L,Child):-
     !,
     write('Enter the number of a non-valid fact followed by a fullstop: '),
         readNumber(0, Number,Error,LastChar),
     (
        Error == error,
        getErroneousChild(NumArrows,L,Child)

      ;
        checkOracleNumber(NumArrows,Number,Error),
        (
            Error == error,
            getErroneousChild(NumArrows,L,Child)
        ;
            getNthElement(L,Number,Child)
        )
         ),
     !.

getOracleInformation(Information) :-
       write('Please, provide information about the validy of these facts ( h for help) '),nl,
    getAnswer([],Information),
    !.

% getAnswer(+ListaComandosHastaAhora,-ListaComandosTotal)
% lee una lista de comandos indicados por el usuario y separados por espacios
getAnswer(InputList,OutputList) :-
        get(NextChar),
    (
     NextChar = 46, % '.'
        OutputList = InputList,
        eliminateSweepings(NextChar)
     ;
     NextChar = 104, % h
        OutputList = [help],
        eliminateSweepings(NextChar)
     ;
      NextChar   = 97, % a
        OutputList = [allvalid],
        eliminateSweepings(NextChar)
    ;
      NextChar   = 113, % q
        OutputList = [stop],
        eliminateSweepings(NextChar)
    ;
         (NextChar   = 118 ; % v
       NextChar = 110; % n
        NextChar  =116; % t
         NextChar  = 99  % c
         ),
        readNumber(0,N,Result,LastChar),
        (Result==error,
        OutputList = [error],
        eliminateSweepings(LastChar)
        ;
        append(InputList,[(NextChar,N)],OutputList1),
            ( LastChar = 46, % '.'
              OutputList = OutputList1,
              eliminateSweepings(LastChar)
             ;
              LastChar= 44, %','
              getAnswer(OutputList1,OutputList)
             ;
              nl,
              name(R,LastChar),
              write(R), write(' is not a valid separator'),
              OutputList = [error],
              eliminateSweepings(LastChar)
            )
            )
     ;
        nl,
        name(R,[NextChar]),
        write(R), write(' is not a valid command'),
        nl,
        OutputList = [error],
        eliminateSweepings(R)
     ),
     !.


readNumber(InputNumber, OutputNumber,Error,LastChar) :-
    get(C),
    (
     C >47, C<58,
     NewInputNumber is  (C-48)+(10*InputNumber),
     readNumber(NewInputNumber,OutputNumber,Error,LastChar)
     ;
     LastChar = C,
     OutputNumber = InputNumber,
     ( OutputNumber >0,
       Error = no
       ;
       write('Non-valid number'),
       Error=error
       )
      ),
      !.





getOracleAnswer(Answer) :-
    get(Answer1),
    eliminateSweepings(Answer1),
    (
         % yes
     (Answer1==121; Answer1==98),
     Answer=Answer1
    ;
         % no
     (Answer1==110; Answer1==78),
     Answer=Answer1
    ;
         % abort
     (Answer1==97; Answer1==65),
     Answer=Answer1
        ;
     nl,
     write('Please, answer y, n or a: '),
     getOracleAnswer(Answer)
    ),
    !.


showBuggyNode(X):-
    !,
    getRuleData(X,Name,Number,Node),
    name(NameNumber,Number),
    name(NameNode,Node),
    nl,
    write('Rule number '),
    write(NameNumber),
    write(' of the function '),
    write(Name),
    write(' is wrong.'),
    nl,
    write('Buggy node: '),
    write(NameNode),
    nl,
    nl,
    write(' Press Enter to continue '),
    get0(_),
    nl.




insertOks([],List,List):-
    !.

insertOks([X|Xs],ListIn,ListOut):-
    !,
    insertLst(X,ListIn,ListOut1),
    insertOks(Xs,ListOut1,ListOut).


insertNos(X,ListIn,ListOut):-
    !,
    insertLst(X,ListIn,ListOut).



checkOracleNumber(NumArrows,Choice,Error) :-
    (
     number(Choice),
     Choice>0,
     Choice=<NumArrows,
     Choice=Choice
    ;
     nl,
     write('Please, provide  valid arrow numbers: '),
     write(Choice),
     nl,
     Error = error
    ),
    !.

writeArrowsList([],Num,Num) :-
    !.

writeArrowsList([T|Ts],N,NOut) :-
    !,
    N2 is N+1,
    write(N2),
    write(': '),
    rootArrow(T,Arrow),
    name(NameArrow,Arrow),
    write(NameArrow),
    nl,
    writeArrowsList(Ts,N2,NOut).



/*****************************************************************************/
/*  Predicados auxiliares para extraer las componentes del arbol         */
/*****************************************************************************/


whoAreMyChildren('cTreeNode'(_Name,_Args,_Result,_Body,_Conds,_NumRule,WeAre),
                                      ListWeAre,
                 TrustedIn,TrustedOut,ConsideredIn, ConsideredOut, Specification) :-
    !,
    hnf(WeAre,WeAre2),
    toyListToPrologList(WeAre2,WeAre3),
    processChildren(WeAre3,TrustedIn,TrustedOut,ConsideredIn, ConsideredOut, Specification,ListWeAre).

processChildren([],TrustedIn,TrustedOut,ConsideredIn, ConsideredOut, Specification,[]).
processChildren([X|Xs],TrustedIn,TrustedOut,ConsideredIn, ConsideredOut, Specification,[Y|Ys]) :-
    !,
    hnf(X,X2),
    hnfChild(X2,Y),
    % aqu� deber�an ir las comprobaciones sobre trusted, entailed, etc.
    hnf(Xs,Xs2),
    processChildren(Xs2,TrustedIn,TrustedOut,ConsideredIn, ConsideredOut, Specification,Ys).

hnfChild('cTreeNode'(Name,Args,Result,_Body,_Conds,NumRule,_WeAre),
               'cTreeNode'(NameOut,ArgsOut,ResultOut,_Body,_Conds,NumRuleOut,_WeAre)) :-
           !,
          toyStringToList(Name,Name3),
          name(NameOut,Name3),
          toyStringToList(NumRule,NumRuleOut),
          toyListToNfList(Args,ArgsOut),
          nfDebug(Result,ResultOut).
/*
                 nfDebug(Name,NameNf),
                 nfDebug(NumRule,NumRuleNf),
                 nfDebug(Args,ArgsNf),
                 nfDebug(Result,ResultNf),
          toyStringToList(NameNf,Name3),
          name(NameOut,Name3),
          toyStringToList(NumRuleNf,NumRuleOut),
          toyListToNfList(ArgsNf,Args2),
          nfDebug(ResultNf,Result2),
                  pValToPrologString(Result2,ResultOut),
          mappValToPrologString(Args2,ArgsOut).*/


rootArrow('cTreeNode'(Name,Args,Result,_Body,_Conds,NumRule,_WeAre), Arrow):-
          Lhs =..[ Name |  Args],
          !,
          basicFactToString(Lhs,Result, Arrow).

toyListToNfList([],[]):-!.
toyListToNfList(X:Xs,[XNf|XsNf]):-
    !,
    nfDebug(X,XNf),
    toyListToNfList(Xs,XsNf).

mappValToPrologString([],[]) .
mappValToPrologString([X|Xs],[Y|Ys])  :-
    !,
    pValToPrologString(X,Y),
       mappValToPrologString(Xs,Ys).

rootBasicFact('cTreeNode'(Name,Args,Result,_Body,_Conds,_NumRule,_WeAre),
                       arrow(Name,Args,Result,Representation)):-
        !,
       rootArrow('cTreeNode'(Name,Args,Result,_Body,_Conds,_NumRule,_WeAre), Representation).




getRuleData('cTreeNode'(Name,Args,Result,Body,Conds,NumRule,_WeAre),
        Name,NumRule,Arrow):-
    !,
    rootArrow('cTreeNode'(Name,Args,Result,Body,Conds,NumRule,_WeAre),Arrow).


argsToPrologString([],""):-!.
argsToPrologString(':'(X,Xs),Result):-
    !,
        pValToPrologString(X,XProlog),
        argsToPrologString(Xs,Xs2),
        concatLsts([XProlog," ",Xs2],Result).


% Si la expresion es la lista vacia tenemos que escribir "[]"
% en otro caso es una lista de char
toyExprToPrologString(Expr,PrologString):-
    (
     Expr=[],
     PrologString="[]"
    ;
     toyStringToPrologString(Expr,PrologString)
    ),
    !.



getNthElement([X|Xs],1,X):-
    !.

getNthElement([X|Xs],N,Element):-
    !,
    N2 is N-1,
    getNthElement(Xs,N2,Element).



toyStringToPrologString([],[]):-
       !.

% rafa 31-08-03 Caso especial. La cadena '.$' se traduce por '.'
toyStringToPrologString('$char'(46):'$char'(36):[],[46]):- !.

toyStringToPrologString(':'('$char'(X),Xs2),[X|Xs]):-
       !,
       toyStringToPrologString(Xs2,Xs).

toyListToPrologList([],[]) :-
    !.
toyListToPrologList(A:B, [A2|Bs]) :-
    !,
    hnf(A,A2),
    hnf(B,B2),
    toyListToPrologList(B2,Bs).
 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

graphicalInterface(Tree,Store) :-
    !,
    % entailment(Tree),
    % specification(Tree,Tree2),
    Tree2 = Tree, % quitar para poner la especificaci�n y el entailment
        startDDT(Tree2,Store).



entailment(ct(Lhs,Result,State,NumRule,WeAre)) :-
    !,
    nl,
    write('Checking entailment...'),
    mapPreorderList(WeAre,LO),
        entailmentData(LO,LO,[],Data),
        name(NameTree,"treeEntail.txt"),
    writeDataEntailment(NameTree,Data), write('done'), nl.

entailmentData([],LO,Data,Data).
entailmentData([(F,Args,Result,Ground,Total)|Xs],LO,DataI,DataO) :-
      entails((F,Args,Result,Ground,Total),LO,L),
      ( L=[One], %  reflexive entailment
        entailmentData(Xs,LO,DataI,DataO)
      ;
      DataO1 = [((F,Args,Result),L)|DataI],
      entailmentData(Xs,LO,DataO1,DataO)
      ), !.


writeDataEntailment(File,Data) :-
        open(File,write,H), % abrimos para escritura el fichero
        writeListEntailment(H,Data),
        close(H).

writeListEntailment(H,[]) :- !.
writeListEntailment(H,[((F,Args,Result),[])|Xs]) :-
    !,
    writeListEntailment(H,Xs).
writeListEntailment(H,[((F,Args,Result),L)|Xs]) :-
   !,
    put(H,35),
    writeArrow(H,F,Args,Result),
    put(H,35),
    writeListEntailed(H,L),
   writeListEntailment(H,Xs).

writeListEntailed(H,[]).
writeListEntailed(H,[(F,Args,Result)|Xs]) :-
    writeArrow(H,F,Args,Result),
    put(H,35),
    writeListEntailed(H,Xs).


writeArrow(H,F,Args,Result) :-
    !,
    Lhs =.. [F|Args],
    basicFactToString(Lhs,Result,Arrow),
    writeString(H,Arrow).


% returns the basic facts of the ct in a list  of elements of the form (Name,Args,Rhs,Ground,Total)
preorderList(ct(Lhs,Result,State,NumRule,WeAre),[ (F,Args,Result,Ground,Total)|LO1]) :-
    !,
    Lhs =.. [F|Args],
        introVars((F,Args,Result),(F2,Args2,Result2), [], _L),
        (
          ground((F2,Args2,Result2)),
          Ground=yes
         ;
          Ground=no
         ),
        (
          totalTerm((F2,Args2,Result2)),
          Total =yes
         ;
          Total=no
        ),
    mapPreorderList(WeAre,LO1).

mapPreorderList([],[]) :- !.
mapPreorderList([X|Xs],L) :-
    !,
    preorderList(X,L1),
    mapPreorderList(Xs,L2),
    append(L1,L2,L).

introVars(A,X,LI,LO) :-
    variableName(A),
    (
      member_relax((A,X),LI),
      LO= LI
     ;
      LO = [(A,X)|LI]
     ),
     !.
introVars(Term,Term,L,L) :-
    atom(Term),
    !.

introVars(Term,Term,L,L) :-
    listAtoms(Term),
    !.

introVars([X|Xs],[Y|Ys],LI, LO) :-
    !,
    introVars(X,Y,LI,LO1),
    introVars(Xs,Ys,LO1,LO).

introVars(Term,Term2, LI, LO) :-
    Term =.. [ F | Args],
    !,
    introVars(Args,Args2,LI,LO),
    Term2 =.. [F | Args2].


listAtoms([]).
listAtoms([X|Xs]) :- isAtom(X),!, listAtoms(Xs).
listAtoms(':'(X,Xs)) :- isAtom(X),!, listAtoms(Xs).

isAtom('$char'(N)) :- !.
isAtom(A) :- atom(A).

variableName([X|Xs]) :-
    integer(X),
    X >= 65,
    X =< 90,
    !.




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




specification(T1,T2) :-
     (
        specificationOption,
    simplifySpec(T1,T2,N1,N2),
    write(N1), write(' nodes found valid (deleted)'), nl,
    write(N2), write(' nodes found nonvalid (marked)'), nl
      ;
     T2 = T1
     ),
     !.

specificationOption :-
    nl,
         write('Use a trusted specification? ([y]es / [n]ot) '),
    getAnswer(Ans),
    Ans == 121,
        write('Name of the specification (without extension and followed by a fullstop)? '),
        read(File),
    name(File,FileString),
    append(FileString,".pl",FileStringExtension),
    name(FileName,FileStringExtension),
     (
        file_exists(FileName),
        open('err.txt',write,H), prolog_flag(user_error,N,H),
        load_files(FileName,[if(changed)]),
        prolog_flag(user_error,M,N),
        close(H)
        ;
         write(' File '), write(FileName), write(' not found'), nl,
         fail
      ),
     !.


simplifySpec(ct(Lhs,Result,State,NumRule,WeAre),
            ct(Lhs,Result,State,NumRule,WeAre2),N1,N2) :-
    !,
    mapSimplifySpec(WeAre,WeAre2,0,N1,0,N2).

mapSimplifySpec([],[],Valid,Valid, NonValid,NonValid) :- !.
mapSimplifySpec([ct(Lhs,Result,State,NumRule,WeAre)|Xs],T,ValidI,ValidO, NonValidI,NonValidO) :-
    Lhs =.. [F|Args],
    name(F,Name),
    name(F2,[36|Name]),
    (
%       write(Lhs), write(' -> '), write(Result),
        defined(F2),
        (
            basicFact(Lhs,Result),
            !,
            % is valid
%           write(' valid'),nl,
            append(WeAre,Xs,Total),
            NewValid is ValidI+1,
            mapSimplifySpec(Total,T,NewValid,ValidO,NonValidI,NonValidO)
        ;
            % nonvalid
            !,
%           write(' nonvalid'),nl,
            NewNonValid is NonValidI+1,
            mapSimplifySpec(WeAre,WeAre2,ValidI,ValidO1,NewNonValid,NonValidO1),
            mapSimplifySpec(Xs,Ys,ValidO1,ValidO,NonValidO1,NonValidO),
            T = [ct(Lhs,Result,"2",NumRule,WeAre2)|Ys]
        )

    ;
%       write( ' undefined'),nl,
        mapSimplifySpec(WeAre,WeAre2,ValidI,ValidO1,NonValidI,NonValidO1),
        mapSimplifySpec(Xs,Ys,ValidO1,ValidO,NonValidO1,NonValidO),
        T = [ct(Lhs,Result,State,NumRule,WeAre2)|Ys]

    ),
    !.

defined(F2) :- current_predicate(F2,plgenerated:A).





getAnswer(Answer) :-
    get(Answer1),
    eliminateSweepings(Answer1),
    (
         % yes
     (Answer1==121; Answer1==98),
     Answer=121
    ;
         % no
     (Answer1==110; Answer1==78),
     Answer=110
        ;
     nl,
     write('Please, answer y or n: '),
     getAnswer(Answer)
    ),
    !.

%
startDDT(Tree,Store) :-
    !,
    % change to the javaTree directory
    toy:toydir(D),
    name(D,NPath),    
    name(NameTree,"tree.txt"),
    concatLsts([NPath, "javaTree/"],DirName),
    name(Dir,DirName),
    working_directory(Old,Dir),
    nl,working_directory(CD,CD),
    %   write('Current working directory is '),write(CD),nl,nl,

    % write the tree    
    name(NameTree,"tree.txt"),
    name(NameTree,StringName),
    writeTree(NameTree,Tree,Store),

    % connect to Java
    write('Connecting to Java...'),nl,
    concatLsts(["java -jar pt.jar . tree  treeEntail & " ],Command),    
    name(NameCommand,Command),
%    write(NameCommand),nl,
    system(NameCommand,Status),
    (Status=0
    ;
     write('Error: Command "java" not found in the system path or Java version not valid'),nl
     ),
    % restore working directory 
     working_directory(_,Old)
     .


graphicalInterface(Tree) :- !.


writeTree(File,Tree,Store) :-
        open(File,write,H), % abrimos para escritura el fichero
%   writeTree2(Tree),
        writeTreeInFile(H,Tree,Store,0),
        close(H).

writeTree2(Tree) :-
    !,
    write('writting the whole tree ...'),nl,
        name(File,"tree2.txt"),
        open(File,write,H), % abrimos para escritura el fichero
        write(H,Tree),
        close(H),
    write('done!'),nl.

% we need both the subtree we are working on and the complete tree for
% the entailment algorithm
writeTreeInFile(H,Tree,Store,NI) :-
    !,
    put(H,10),
    writeBlanks(H,NI),
    NO1 is NI+5,
        writeRoot(H,Tree,Store),
        whoAreMyChildrenDDT(Tree,WeAre),
        mapWrite(H,WeAre,Store,NO1),
    put(H,36).

mapWrite(H,[],_Store,N)     :- !.
mapWrite(H,[X|Xs],Store,NI) :- !,
        writeTreeInFile(H,X,Store,NI),
        mapWrite(H,Xs,Store,NI).

% Tree is the complete tree, while T is the subtree whose root
% we are going to write
writeRoot(H,T,Store) :-
    !,
       rootArrowDDT(T,Store,Arrow,Name,Number,State),
       put(H,35),
       writeString(H,Arrow),
       put(H,35),
       writeString(H,Name),
       put(H,35),
       writeString(H,Number),
       put(H,35),
       writeString(H,State),
       put(H,35),
      % rootBasicFactDDT(T,BasicFact),
       % entails(BasicFact,Tree,L),
       % writeEntails(H,L),
       put(H,35).

writeString(H,[]).
writeString(H,[X|Xs]):-
    !,
    put_code(H,X),
    writeString(H,Xs).

writeBlanks(H,0) :- !.
writeBlanks(H,N) :-
     put(H,32),
     N2 is N-1,
     writeBlanks(H,N2).

writeEntails(H,[]) :- !.
writeEntails(H,[X|Xs]) :-
    !,
    put(H,123),
    writeString(H,X),
    put(H,125),
    writeEntails(H,Xs).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Predicados para tratar el �rbol DDT
rootArrowDDT(ct(Lhs,Result,State,NumRule,_WeAre),
                       Store,Arrow,Name,NumRule,State):-
      !,
      functor(Lhs,NameName,N),
      name(NameName,Name),
      basicFactToString(Lhs,Result,Store,Arrow).

whoAreMyChildrenDDT(ct(_Lhs,_Result,_State,_NumRule,WeAre), WeAre):- !.


%%%%%%%%% Auxiliary functions for DDTs
%atomicDDTToString(pValBottom,"_") :- !.

basicFactToString(Lhs,Result,Arrow) :-
      !,
      atomicToString(Lhs,Lhs2),
      atomicToString(Result,Result2),
      atomicToString(Store,Store2),
      concatLsts([Lhs2,"  ->  ",Result2],Arrow).

basicFactToString(Lhs,Result,constraint([]),Arrow) :-
    !,
    basicFactToString(Lhs,Result,Arrow).

basicFactToString(Lhs,Result,Store,Arrow) :-
      !,
      atomicToString(Lhs,Lhs2),
      atomicToString(Result,Result2),
      constraintToPrologString(Store,Store2),
      concatLsts([Lhs2,"  ->  ",Result2,"  <== ", Store2],Arrow).

atomicToString(A,B) :- !,atomToPrologString(atomToString,A,B).

extractStore(S,S):-!.
extractStore([],true).
extractStore(':'(S,[]),false).
extractStore(':'(A,':'(B,C)), and(S1,S2)) :-
    !,
    extractStore(':'(A,[]),S1),
    extractStore(':'(B,C),S2).
