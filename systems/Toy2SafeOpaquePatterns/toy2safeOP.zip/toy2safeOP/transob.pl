%-----------------------------------------------------------------------------%
% transob.pl
%-----------------------------------------------------------------------------%
/*
- Author: Jaime.
- Created: 30/05/96
- Description: Este modulo coge el primer caracter de teclado. Si es /, devuelve
  el token 'Comando'. Si no, se llama al tokenizer para que lea el objetivo.
  Es un lector de objetivos a partir de teclado.
- Modules which import it: initToy.
- Imported modules:
	> token (con 'searchToken'): en transob hay que leer el objetivo. Para
	  ello, con searchToken me salto todos los blancos del principio del
	  prompt y devuelvo el primer caracter distinto de blanco. Tambien salto
	  los fines de linea y comentarios.
	> errortoy (con 'treatLexiconError' y 'treatSintacticError'): al
	  leer el objetivo muestra por pantalla los errores lexicos y sintanticos
	  que se han producido.
	> compil: a este modulo se le llama con varios predicados: con
	  'lexicon' (para sacar la lista de tokens del objetivo), con 
	  'createTablesCompilation' (para crear las tablas que se usaran durante 
	  la compilacion), con 'semantic' (prepara para imprimir el resultado 
	  del analisis del objetivo) y con 'eliminateApply' (se encarga de 
	  eliminar los apply innecesarios de la clausula (en formato del fichero
	  temporal) del objetivo).
	> gramma_toy (con 'condition'): para analizar sintacticamente el 
	  objetivo, se ve si es una condicion y se devuelve su representacion en 
	  codigo intermedio.
	> tools (con 'eliminateExtremes').
- Modified:03/0696, POR PACO Y JAIME: En la llamada a semantic no se exige
                    que lo que devuelva sea una lista unitaria, porque esto 
                    daba problemas a la hora de reconocer restricciones 
                    multiples.
           30/09/99 mercedes: Se han comentado los predicados.
           26/10/99 mercedes: modularizacion. 
           17/11/99 mercedes: Se ha introducido la opcion de ejecucion en modo 
           	    de evaluacion simple (para expresiones deterministas 
           	    cerradas). Es decir, TOY ahora ademas de ejecutar comandos y
           	    resolver objetivos, tambien evalua expresiones.
           	    Para evaluar una expresion en TOY se pone:
           	    > expresion
           	    Para ello los cambios que se han hecho son:en 'readGoal'
           	    he puesto:
           	    FirstChar=62, Goal='$Expression';
           	    Ademas 'readGoal' ahora tiene 3 argumentos.
       
	
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



:- module(transob,[readGoal/3
%F010204 Se necesita en initToy
                   ,transGoal/4
]).


:- load_files(token,[if(changed),imports([searchToken/3])]).

:- load_files(errortoy,[if(changed),imports([treatLexiconError/1,
              treatSintacticError/1])]).

:- load_files(compil,[if(changed),imports([lexicon/5,semantic/7,
              createTablesCompilation/1, eliminateApply/8])]).
              
:- load_files(gramma_toy,[if(changed),imports([conditionWhere/7])]).

:- load_files(tools,[if(changed),imports([eliminateExtremes/2])]).


% current_input



%-----------------------------------------------------------------------------%
% readGoal(-Type,-List,-Error)
% Type: '$Command' si el primer caracter es una /. En este caso solo se 
%       deja leida la /.
%       '$Expression' si el primer caracter es >.En este caso se lee la 
%	expresion entera y se devuelve en List.
%	'$Goal' en otro caso. En este caso se lee el objetivo entero y se
%	devuelve en List.
%-----------------------------------------------------------------------------%

readGoal(Type,Goal,Error) :- 
	% cogemos el handle de la entrada estandar
	current_input(HIn),
	% cogemos el primer caracter de teclado.
	% si es una / devolvemos el token 'comando'
	% si no lo que hacemos es llamar al tokenizer para que lea el objetivo
	get(HIn,FirstChar),
	( FirstChar=47, Type='$Command'   % 47='/'
	 ;
	  FirstChar=62, Type='$Expression',  % 62='>'
	  get(HIn,SecondChar),
	  transGoal(HIn,SecondChar,Goal,Error)
	 ; 
	  % Depu 13/11/00 mercedes
	  FirstChar=63, Type='$Debug',  % 63='?'
	  get(HIn,SecondChar),
	  transGoal(HIn,SecondChar,Goal,Error)
	  % Fin Depu
	 ; 
	  % Depu 29/11/01 JC & Rafa
	  FirstChar=58, Type='$TypeExpression',  % 58=':'
	  get(HIn,SecondChar),
	  transGoal(HIn,SecondChar,Goal,Error)

	 ;
	  Type='$Goal',
	  transGoal(HIn,FirstChar,Goal,Error)
	),
	% asegurarnos de dejar la variable de error instanciada
        ( Error = false ; Error = true),
        !.




transGoal(HIn,Char,Goal,Error):-
	  !,
	  % nos saltamos los blancos del principio, buscando un inicio de secc.
	  searchToken(HIn,(1,1,Char),DataChar),
          treatLexiconError(Error),
          lexicon(HIn,DataChar,ListTokens,LatestChar,Error), 
          treatLexiconError(Error),
	  % crear las tablas que se usar�n durante el proceso de compilaci�n
          createTablesCompilation(Tab),
          % quitamos las llaves del principio y del final porque no son parte
          % de la sintaxis de una condicion, pero el lexico, que no sabe nada
	  % de todo esto, las devuelve igualmente
          % la llave del principio la quita goal_sintactic
          eliminateExtremes(ListTokens,List2),

          goal_sintactic(Tab,List2,S,Error),
          semantic(HOut,S,S2,DataSin,NewSin,Tables,Error),
	  eliminateApply(without_table,_,_,(no,1),S2,Goal,_,Error).
	  




%-----------------------------------------------------------------------------%
% goal_sintactic(?Tables,+Tokens,-S,-Error)
% Analiza sint�cticamente 'Tokens' y devuelve su representaci�n en S
% Si hay errores los muestra
% Si ya hubo errores l�xicos, no hacemos nada
%-----------------------------------------------------------------------------%

goal_sintactic(_,Tokens,[],Error) :- Error==true,!.

% si solo mete un enter, no hacemos nada
goal_sintactic(_,[],[],Error) :- !.


goal_sintactic(Tables,Tokens, S, Error) :-
        !,
        ( 
          % Depu 27/10/00 mercedes
          conditionWhere(S,Tokens,[],Tables,0,_,true)
          % Fin Depu
         ;
          % si llega aqu� es que hubo error; buscar el m�s profundo
          Error = true, nl,conditionWhere(S,Tokens,[],Tables,0,_,false)
         ;
          % mostrarlo
          Error=true,
          S = error,
          treatSintacticError(_)
        ).



