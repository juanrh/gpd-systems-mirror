%----------------------------------------------------------------------------%
% inferrer.pl
%----------------------------------------------------------------------------%
/*
- Author: Jaime
- Description: Este modulo deja en la BD clausulas de la forma functiontype(F,T) 
  para cada funcion F, donde T es el tipo inferido (si F no tiene declaracion de 
  tipos) o el tipo declarado (si el tipo inferido es unificable con el declarado).
  Si se han producido errores en la inferencia, informa en pantalla de los mismos
  y deja en memoria una clausula typeError, para poder parar el proceso de 
  compilacion. En resumen, este modulo infiere los tipos del programa que 
  tenemos en este momento en la BD ( el .out correspondiente).
- Modules which import it: process, initToy.
- Imported modules:
	> connected (con 'connected_comp'): para inferir los tipos del programa, 
	  sacamos todas las componentes conexas con las clausulas depende(_,_) 
	  del .out).
	> primitives: con 'primitiveFunct' (para inferir los tipos del programa,
	  necesitamos los tipos de las primitivas, y estos tipos se toman de 
	  aqui).
	> plgenerated (con 'constr' y 'funct').
	> outgenerated (con 'cdata', 'ftype' y 'fun').
	> tools (con 'append' y 'searchVar').
	> dyn
	> writing (con 'writeAtom/1').

- Modified:
	30/09/99 mercedes (se han comentado los predicados).
	26/10/99 mercedes (modularizacion).
	03/11/99 mercedes (He cambiado cada aparicion de num que hay en el 
			   codigo y la he sustituido por '$num'. Esto es 
			   porque num era una palabra reservada y podia 
			   colisionar con nombres de usuario. Por ejemplo:
			   programa: data chungo = num real
			   objetivo: num 3 == X
			   resultado: X == real
			   Eso era lo que pasaba antes de cambiarlo).
	10/11/99 mercedes (Si tengo el programa:
			   f:: int -> bool
			   f 0 = true
			   y pongo el objetivo: f X == 0, la respuesta de TOY 
			   era:
			   TYPE ERROR: Uncomparable expresions in goal: 
			   (f X) == 0
			   Variable type is assumed to go on the inference.
			   Eso es porque f X tiene tipo bool y 0 tiene tipo real.
			   Ahora aparece:
			   TYPE ERROR: Uncomparable expresions in goal: 
			   (f X) == 0.
			   Contradictories types:
			   (f X): bool
			   0: real
			   Variable type is assumed to go on the inference.
			   Para ello en el inferrer se ha modificado 
			   describeError(6:...) y se ha introducido un nuevo
			   predicado errorType/5 que se usa cuando el error es 
			   de tipo 6).           

*/



/*	INFERIDOR DE TIPOS
	LLAMADA:	infTypes.
	En la BD. se supone reconsultado el .out que genera el analizador lexico

	Como resultado deja en la BD clausulas de la forma functiontype(F,T),
para cada funcion F, donde T es el tipo inferido (si F no tiene declaracion de 
tipo) o el tipo declarado (si el tipo inferido es unificable con el declarado).
Si se han producido errores en la inferencia informa en pantalla de los mismos y
deja en memoria una clausula typeError, para poder parar el proceso de 
compilacion. 
	Cuando se produce un error al inferir el tipo de una expresion o funcion
se informa y para continuar el proceso de inferencia se deja dicho tipo como 
variable, para que este error no tenga repercusion en lo sucesivo (al dejarlo 
como variable unificara con cualquier otro tipo).

	Nota: En la funcion  f [X|Xs] = X <== g[Z|Zs]==W, se considera que la
f depende de g. Esto puede, en algunas situaciones, provocar efectos no 
deseados, porque considerar que la definicion de f depende de g. El problema es 
que las variables de g son existenciales. Sin embargo en otros casos el efecto
producido si que es el esperado. No esta totalmente claro como solucionar este 
problema aun.
*/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(inferrer,[goalType/2,infTypes/0,translateType/2,expressionType/4]).

:- load_files(connected, [if(changed),imports([connected_comp/1])]).

:- load_files(dyn,[if(changed)]).

%:-load_files(primitives,[if(changed)]).

% 12/05/00 mercedes. Para cuando usamos la libreria de e/s de ficheros.
/*
:- (
    io_active,!,load_files(primitivesIo,[if(changed)])
   ;
    iographic_active,!,load_files(primitivesGra,[if(changed)])  % 29/05/00 e/s grafica
   ;
    clpr_active,!,load_files(primitivesClpr,[if(changed)])
   ;
    load_files(primitives,[if(changed)])
   ).
*/

:- load_files(primFunct,[if(changed)]).

:- (
    clpr_active,!,load_files(primitivCodClpr,[if(changed)])
   ;
    load_files(primitivCod,[if(changed)])
   ).

:- (
    io_active,!,load_files(primitivCodIo,[if(changed)])
   ;
    1==1
   ).

:- (
    iographic_active,!,load_files(primitivCodGra,[if(changed)])
   ;
    1==1
   ).

% 16/05/00 mercedes. Para cuando usamos la libreria de e/s de ficheros.
/*
:- (
    io_active,!,load_files(basicIo,[if(changed)])
   ;
    (iographic_active;ioclpr_active),!,load_files(basicGra,[if(changed)])  % 29/05/00 e/s grafica
   ;
    load_files(basic,[if(changed)])
   ).
*/

:- load_files(basic,[if(changed),imports([constr/4,funct/5])]).

/* Lo que se hace es cargar inicialmente el fichero basic.pl que contiene el modulo
plgenerated inicial, pero cuando se genere un fichero.pl y se cargue (en el modulo
process), como lo generamos como modulo plgenerated, se borra el modulo 
plgenerated antiguo y se carga este nuevo.
*/

:- load_files(newout,[if(changed),imports([cdata/4,ftype/4,fun/4])]).

/* Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.
*/

:- load_files(tools,[if(changed),imports([append/3,searchVar/3])]).

:- load_files(writing,[if(changed),imports([writeAtom/1])]).

:- use_module(library(terms)).  % subsumes_chk, copy_term




%----------------------------------------------------------------------------%
% infTypes: predicado principal del inferidor de tipos TOY     
% Infiere los tipos del programa que tenemos en este momento en la BD (el .out 
% correspondiente).
%----------------------------------------------------------------------------%


/*
infTypes:-
 	nl,nl,nl,
	write('Checking types'),

  	my_abolish(functiontype/2),
	my_abolish(typeError/0),

	insertTypesPrimitives,		% asertamos a la BD los tipos de las

   assertfunctiontype(f,bool),
   write('Done'),nl.   
*/


infTypes:-
		
	nl,nl,nl,
	write('Checking types'),
	%retractall(functiontype(_,_)),  % eliminamos los tipos que pudiese
	%retractall(typeError),		      % haber en la base para empezar con 
					                     % todo limpio.
	my_abolish(functiontype/2),
	my_abolish(typeError/0),

	insertTypesPrimitives,		% asertamos a la BD los tipos de las
					               % primitivas

	connected_comp(L), 		% sacamos todas las componentes conexas
					            % con las clausulas depende(_,_) del 
					            % .out. Esto lo hace el modulo connected
	%nl, write('BLOCKS: '),nl,write(L),nl,nl,
	typesProgram(L),      		% inferimos los tipos del programa.
	write('Done'),nl.


%----------------------------------------------------------------------------%
% insertTypesPrimitives: asertamos en la BD los tipos de las primitivas
%----------------------------------------------------------------------------%

insertTypesPrimitives:-
	findall(functiontype(Name,Type),
	primitiveFunct(Name,_Ar,_ArP,Type,_TypeD),LstPrims),
	assertListPrimitives(LstPrims).

/*
% En ejecucion una primitiva tiene el mismo comportamiento que las funciones
% La aridad de uso la hacemos coincidir con la declarada.

assertListPrimitives([]):-!.
assertListPrimitives([C|R]):-
	assert(C),
	assertListPrimitives(R).
*/

% En ejecucion una primitiva tiene el mismo comportamiento que las funciones
% La aridad de uso la hacemos coincidir con la declarada.

assertListPrimitives([]):-!.


assertListPrimitives([functiontype(Name,Type)|R]):-
	assertfunctiontype(Name,Type),
	assertListPrimitives(R).


/*
	translateType(Type,TypeT),
	% esta llamada es para que instancie el tipo destino en caso de ser
	% num(_) a num(float).
	% extractDestinationType(TypeT,_),
	assertfunctiontype(Name,TypeT),
	assertListPrimitives(R).
*/	




/*****************************************************************************/
/*			     TIPO DEL OBJETIVO                               */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% el segundo parametro sirve unicamente para precisar los posibles errores que
% se produzcan. Pasamos un entorno vacio.
%----------------------------------------------------------------------------%

goalType(Goal,Where):-
	retractalltypeError,
	typeConstraints(Goal,goal,[]/Out),
	typeWhere(Where,goal,Out/_).


/*****************************************************************************/
/*			     TIPOS  DEL PROGRAMA                             */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% typesProgram(+List)
% infiere los tipos bloque a bloque. Por el analisis de dependendencia que hemos
% hecho sabemos que toda funcion que esta en un bloque solo usa funciones que
% ya se han tipado anteriormente, o bien, que estan en su mismo bloque. El tipo
% de las que han sido tipadas se encuentra en la BD (clausulas functiontype) y
% puede ser accedido para inferir el tipo de otras (de otro bloque). Las del 
% bloque que se esta tipando tienen su tipo en un entorno (lista de tipos) que
% se ira instanciando durante el proceso.
%----------------------------------------------------------------------------%

typesProgram([]):-!. 

typesProgram([BL|RB]):- 
   typeOfTheBlock(BL), 	
	typesProgram(RB). 



/****************************************************************************/
/*			     TIPOS DE UN BLOQUE                             */
/****************************************************************************/

%----------------------------------------------------------------------------%
% typeOfTheBlock(+Block)
%----------------------------------------------------------------------------%

typeOfTheBlock(LE):-
	
	%write('Infering types for '),write(LE),write(...),
	write('.'),flush_output,
	
	% creamos un entorno con todas las funciones del bloque y con tipos 
	% asociados variables (aun no sabemos nada).
	
	includeTypes(LE,EN),	
	%write( 'assumptions: '), write( EN ), nl,

	% En el entorno quedan los tipos de las funciones inferidos por su
	% aparicion en otras funciones (por llamadas). En LT quedan los tipos
	% inferidos por la propia definicion de las funciones.

	typeMembersBlock(EN,LE,[]/CL),
	%write('Cosas a comprobar '), write(CL), nl,
	check_variant_list( CL, EN ),
	
	% unificamos los tipos inferidos para las funciones a partir de
	% sus reglas con los tipos inferidos a partir de sus aparciones
	% en otras funciones del mismo bloque, que tambien sirven para
	% inferir el tipo (puesto que no son usos).
	% EN es el entorno que almacena los tipos inferidos por llamadas,LT 
	% almacena los t.i. por la propia definicion de la funcion, ENF almacena
	% el resultado de la unificacion: si no unifican dos tipos daremos el
	% error correspondiente y dejaremos el tipo resultado variable como 
	% politica de recuperacion de errores, para seguir con la inferencia. 
	% LE lo pasamos por si se produce algun error para informar al usuario
	% del bloque en el que se encuentra.

	%unify_env(EN,LT,ENF,LE),!,
	
	keepTypes(EN).
	%keepTypes(ENF).
	%write('Done'),nl.



/*****************************************************************************/
/*	     TIPOS PARA LAS DEFINICIONES DE FUNCIONES  DE UN BLOQUE          */
/*****************************************************************************/


typeMembersBlock(_,[],CL/CL):-!.

typeMembersBlock(EN,[F|RF],CL/CL2):-	
	typeOfTheFunction(EN,F,CL/CL1),
	typeMembersBlock(EN,RF,CL1/CL2).



/*****************************************************************************/
/*			  TIPOS PARA UNA FUNCION                             */
/*****************************************************************************/


%----------------------------------------------------------------------------%
% para inferir el tipo de una funcion, sacamos el tipo de la misma segun cada
% una de las reglas y luego comprobamos que los tipos inferidos a partir de 
% todas las reglas son unificables
%----------------------------------------------------------------------------%

typeOfTheFunction(EN,F,CL/CL1):-
	fun(F,_,LRULES,_),	

	% le pasamos F/1, el nombre de la funcion y un contador de reglas,para
	% que en si se produce algun error poder informar con mas precision del
	% lugar donde ha ocurrido
			
	typeRulesFunction(EN,F/1,LRULES,CL/CL1).

	% unificamos los tipos inferidos para cada una de las reglas
%	unifyLstTypes(F,TLRULES,TF).



/****************************************************************************/
/*		     TIPO PARA LAS REGLAS DE UNA FUNCION                    */
/****************************************************************************/


typeRulesFunction(_,_,[],CL/CL):-!.

typeRulesFunction(EN,F/N,[Rule|RR],CL/CL2):-
	typeRule(EN,F/N,Rule,CL/CL1),
	N1 is N+1,
	typeRulesFunction(EN,F/N1,RR,CL1/CL2).



/****************************************************************************/
/*			     TIPO DE UNA REGLA                              */
/****************************************************************************/

%----------------------------------------------------------------------------%
% Para inferir el tipo de una funcion segun una de sus reglas, sacamos el tipo
% de cada uno de sus argumentos y del cuerpo. P.e. si tenemos f X1 ... Xn = C
% f tendra el tipo T1 -> ... -> Tn -> Tc, donde Ti es el tipo de Xi y Tc es el
% tipo de C. Luego tipamos las restricciones pq. es posible que esto nos aporte
% mas informacion sobre algunas variables (esto se refleja en el entorno). 
%----------------------------------------------------------------------------%

typeRule(EN,F/N,rule(Head,Body,Cond,Where,_),CL/CL1):-

	Head=..[Name|Args],
	append(Args,[Body],ArgsBody),

	% colocamos tipo variable a la funcion en estudio, para inferir el tipo
	% que nos da la regla independientemente de la informacion previa que
	% tuviesemos. Los demas tipos del entorno se quedan tal cual. En TEN1 
	% nos quedamos con la variable de tipo para luego unificarla con el 
	% tipo inferido para la funcion. Esto sirve para detectar errores en
	% funciones recursivas (probar f X = f).

	%%substituteTypeEnvironment(Name,TEN1,EN,EN1),
	
	typePattern(ArgsBody,F/N,EN/EN2,TP), %Tipo obtenido por la regla
	typeConstraints(Cond,F/N,EN2/EN3), %Tipamos la condicion
	%Enrique:Nuevo
	typeWhere(Where,F/N,EN3/EN4),
	%
	% 	gamma(Name,EN3/EN3,TF), %Tipo actual de la funcion
	gamma(Name,EN4/EN4,TF), %Tipo actual de la funcion
	
	%functiontype(Name,Tipo),
	%write(F), write(' : '), write(Tipo), nl,
	%write( 'Inferido '), write(TP), nl,

	%write( 'TP: ' ), write(TP), nl,
	%write( 'TF: ' ), write(TF), nl,
	
	( unify_with_occurs_check( TP, TF ) -> true 
	;  (  functiontype(Name, _TDecl) -> errorType(22:[Name/N,TP,TF])
	      ;  errorType(23:[Name/N,TP,TF])
	   )
	),
	%%typeConstraints(Cond,F/N,EN2/EN3),
	%write( 'TP: ' ), write(TP), nl,
	%write( 'TF: ' ), write(TF), nl,
	
	% Enrique: comprobar que no hay variables opacas en la regla
	check_critical_vars( EN, Args, Body, Where, F/N ),

	% Enrique: si tiene declaracion de tipos, anadir la comprobacion de variante
	( functiontype(Name,_) -> CL1 = [(TP,F/N)|CL] ; CL1 = CL ).

	% Depu 04/10/00 mercedes
	%%typeWhere(Where,F/N,EN3/_),
        % Fin Depu

	%%(my_unify_with_occurs_check(TEN1,TP),!,TR=TP;

	% si hay error dejamos el tipo variable.
%	errorType(4:[Name/N,TP,TEN1])).


%----------------------------------------------------------------------------%
% Mete una variable fresca como tipo de la funcion F en el entorno y devuelve
% en el segundo argumento esta misma variable para no tener que buscarla despues
%----------------------------------------------------------------------------%
	
substituteTypeEnvironment(F,TEN1,[F:_|R],[F:TEN1|R]):-!.
substituteTypeEnvironment(F,TEN1,[G:T|R],[G:T|R1]):-
	substituteTypeEnvironment(F,TEN1,R,R1).





/****************************************************************************/
/*		 TIPO DE LA CABEZA Y EL CUERPO DE UNA REGLA                 */
/****************************************************************************/

%----------------------------------------------------------------------------%
% Mediante llamadas recursivas inferimos el tipo de la funcion en forma currifi
% cada
%----------------------------------------------------------------------------%

typePattern([Body],F/N,EN/EN1,TE):-
	!,
	expressionType(Body,F/N,EN/EN1,TE).

typePattern([E|R],F/N,EN/EN2,->(TE,TR)):-
	expressionType(E,F/N,EN/EN1,TE),
	typePattern(R,F/N,EN1/EN2,TR).



/*****************************************************************************/
/*		  TIPO DE LAS RESTRICCIONES DE UNA REGLA                     */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% el tipado de las restricciones sirve para dos cosas: para ver que estas estan
% bien tipadas (era de esperar, no?), y para aniadir informacion al tipo de la
% funcion, pq en el lado izdo o en el cuerpo puden aparecer variables o 
% expresiones en general cuyo tipo quede mas cualificado al analizar 
% restricciones en las que tb aparezcan. p.e. f X Y = Y <== X==2*Y. Al analizar
% la cabeza y el cpo solo sabemos que f tiene un tipo de la forma A->B->A,
% mientras que al analizar las restricciones podemos inferir para f el tipo
% int->int->int.
% Pos puede tomar los valores goal (si estamos tipando un objetivo) o F/N 
% (funcion/regla) si estamos tipando la regla num N de la funcion F
%----------------------------------------------------------------------------%

typeConstraints([],_,EN/EN).
typeConstraints([E1 == E2 | R],Pos,EN/EN3):-
	!,
	expressionType(E1,Pos,EN/EN1,TR1),
	expressionType(E2,Pos,EN1/EN2,TR2),
	(my_unify_with_occurs_check(TR1,TR2),!
	 ;
	 errorType(6:[Pos,E1 == E2],E1,TR1,E2,TR2)),
	typeConstraints(R,Pos,EN2/EN3).

typeConstraints(['/='(E1,E2) | R],Pos,EN/EN3):-
	!,
	expressionType(E1,Pos,EN/EN1,TR1),
	expressionType(E2,Pos,EN1/EN2,TR2),
	(my_unify_with_occurs_check(TR1,TR2),!
	 ;
	 errorType(6:[Pos,'/='(E1,E2)],E1,TR1,E2,TR2)),
	typeConstraints(R,Pos,EN2/EN3).

% cuando nos encontramos una restriccion R sin == ni /= interpretamos R==true

typeConstraints([E | R],Pos,EN/EN2):-
	expressionType(E,Pos,EN/EN1,TR),
	(my_unify_with_occurs_check(TR,bool),!
	 ;
	 errorType(6:[Pos,E==true],E1,TR1,true,bool)),
	typeConstraints(R,Pos,EN1/EN2).



%--------------------------------------------------------------------------
% Depu 04/10/00 mercedes
% tipado de los where

typeWhere([],_,EN/EN).
typeWhere(['='(E1,E2,Lin) | R],Pos,EN/EN3):-
	!,
	expressionType(E1,Pos,EN/EN1,TR1),
	expressionType(E2,Pos,EN1/EN2,TR2),
	(my_unify_with_occurs_check(TR1,TR2),!
	 ;
	 errorType(6:[Pos,E1 = E2],E1,TR1,E2,TR2)),
	typeWhere(R,Pos,EN2/EN3).

% Fin Depu

/*****************************************************************************/
/*			   TIPO DE UNA EXPRESION                             */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% el segundo argumento es la funcion que estamos estudiando (o goal si es un 
% objetivo) y sirve unicamente para poder decirle al usuario donde se ha 
% producido un error en caso de producirse.
%----------------------------------------------------------------------------%

% si la expresion es una variable, consulta el entorno.Si est'a devuelve su tipo
% y si no, mete la var en el entorno con tipo variable y devuelve este tipo.
% En conclusion: gamma devuelve el tipo de la variable este o no en el entorno
% y deja este en estado consistente.

expressionType('$var'(X),_,EN/EN1,T):-!,
	gamma('$var'(X),EN/EN1,T).


% Un real (float) esta forzado a ser float porque no puede (salvo funciones de
% conversion especifica) considerarse entero. Pero no hay inconveniente en 
% considerar a un entero como de tipo float, por eso se deja la variable que
% lo indica como variable.

expressionType('$int'(_A),_,EN/EN,'$num'(_B)):-!.

expressionType('$float'(_),_,EN/EN,'$num'(float)):-!.

%char
expressionType('$char'(_),_,EN/EN,char):-!.


/*
%tuplas
expressionType('$tup'(T),Pos,EN/EN1,tuple(Tt)):-
	expressionType(T,Pos,EN/EN1,Tt).
*/


/*
%tuplas
expressionType('$tup'(Ls),Pos,EN/EN1,tuple(TLs)):-
	!,
	typeTuple(Ls,Pos,EN/EN1,TLs).

typeTuple([],_,EN/EN,[]).
typeTuple([C|R],Pos,EN/EN2,[TC|TR]):-
	expressionType(C,Pos,EN/EN1,TC),
	typeTuple(R,Pos,EN1/EN2,TR).
*/


% este es el caso especial de una funcion aplicada parcialmente, que no tiene
% mayor dificultad

expressionType('$apply'(E1,E2),Pos,EN/EN2,TR):-
	!,
	expressionType(E1,Pos,EN/EN1,T1),
	expressionType(E2,Pos,EN1/EN2,T2),
	(my_unify_with_occurs_check(T1,->(T2,TR)),!;
		errorType(5:[Pos,E1,T1,E2,T2])).


% 05/06/00 mercedes: metemos la regla de tipo para la expresion do

expressionType(do([],[R]),Pos,EN/EN1,TR):-
	!,
	expressionType(R,Pos,EN/EN1,TR).
	
expressionType(do([V|Vs],[P|Ps]),Pos,EN/ENR,TR):-
	!,
	expressionType(V,Pos,EN/EN1,T1),
	expressionType(P,Pos,EN1/EN2,T2),
	(
	 my_unify_with_occurs_check(io(T1),T2),!
	;
	 errorType(5:[Pos,V,T1,P,T2])
	),
	expressionType(do(Vs,Ps),Pos, EN2/ENR,TR).


% 08/06/00 mercedes: metemos la regla de tipo para las listas intensionales

expressionType(intensional(E,[]),Pos,EN/EN1,TR:[]):-
	!,
	expressionType(E,Pos,EN/EN1,TR).
	
expressionType(intensional(E,['<-'(V,L)|R]),Pos,EN/ENR,TR):-
	!,
	expressionType(V,Pos,EN/EN1,T1),
	expressionType(L,Pos,EN1/EN2,T2),
	(
	 my_unify_with_occurs_check(T1:[],T2),!
	;
	 errorType(5:[Pos,V,T1,L,T2])
	),
	expressionType(intensional(E,R),Pos, EN2/ENR,TR).


expressionType(intensional(E,[B|R]),Pos,EN/ENR,TR):-
	!,
	expressionType(B,Pos,EN/EN1,T1),
	(
	 my_unify_with_occurs_check(T1,bool),!
	;
	 errorType(5:[Pos,V,T1,L,T2])
	),
	expressionType(intensional(E,R),Pos, EN1/ENR,TR).


% Esta clausula estudia el caso de que la expr. sea una llamada a una funcion
% o una constructora. Ambos casos tienen un tratamiento similar. La llamada a
% gamma devuelve el tipo que llevamos inferido de la funcion o el tipo de la
% constructora. Esto tiene como consecuencia la posibilidad de que aparezcan
% constructoras aplicadas parcialmente


expressionType(Term,Pos,EN/EN1,TI):-
	Term=..[Name|Args],
	gamma(Name,EN/EN,TF),
	typeCallFunction(Args,err(1,Pos,Term),EN/EN1,TF,TI).



%----------------------------------------------------------------------------%
% Saca el tipo de una llamada a una funcion y a la vez comprueba que la propia
% llamada a la funcion esta bien tipada de acuerdo con el tipo que llevamos 
% inferido para la propia funcion. 
%----------------------------------------------------------------------------%

typeCallFunction([],_,EN/EN,TF,TF):-!.
typeCallFunction([A|R],err(N,Pos,Term),EN/EN2,TF,TR):-
	expressionType(A,Pos,EN/EN1,TA),
	TF=..[->,T1,T2],
	
	(my_unify_with_occurs_check(TA,T1),!;errorType(8:[Pos,N,Term,TA,T1])),
	N1 is N+1,
	typeCallFunction(R,err(N1,Pos,Term),EN1/EN2,T2,TR).



/*****************************************************************************/
/*		          TRADUCCION DE TIPOS                                */
/*****************************************************************************/

%----------------------------------------------------------------------------%
% translateType(+Type,-TypeT)
% +Type de la forma '->'('$var'('A'),'$var'('B'))
% -TypeT de la forma '->'(A,B).
%----------------------------------------------------------------------------%

translateType(A,B):-translateType(A,[]/_,B).


%----------------------------------------------------------------------------%
% translateType(+Type,+Ac/-Ac1,-TypeT)
% Ac es el acumulador de variables
%----------------------------------------------------------------------------%

translateType('$var'(X),Ac/Ac1,Y):-
	!,
	searchVar(X,Ac/Ac1,V),
	(	
		var(V),
		!,
		Y=V
	;
		V=is_not(Y)
	).

translateType(int,Ac/Ac,'$num'(int)):-!.

%080199
% el segunto argumento, num(float) antes era num(_)
translateType(real,Ac/Ac,'$num'(float)):-!.

%char
translateType(char,Ac/Ac,char):-!.


/*
%tuplas
translateType(tuple(T),Ac/Ac1,tuple(Tt)):-
	!,
	translateType(T,Ac/Ac1,Tt).
*/



translateType(T,Ac/Ac1,Tt):-
	T=..[Name|Args],
	translateListTypes(Args,Ac/Ac1,Argst),
	Tt=..[Name|Argst].


%----------------------------------------------------------------------------%
% translateListTypes(+ListaTipos,+Ac/-Ac1,-ListaTiposT)
%----------------------------------------------------------------------------%

translateListTypes([],Ac/Ac,[]):-!.
translateListTypes([T|Rest],Ac/Ac2,[Tt|RestT]):-
	translateType(T,Ac/Ac1,Tt),
	translateListTypes(Rest,Ac1/Ac2,RestT).



%----------------------------------------------------------------------------%
% gamma: devuelve el tipo de una variable,constructora o funcion del entorno o 
% de la base de datos   
%----------------------------------------------------------------------------%



gamma('$var'(X),[P:A|R]/[P:A|R],A):-
	P=='$var'(X),!.

gamma('$var'(X),[P:A|R]/[P:A|R1],B):-!,
	gamma('$var'(X),R/R1,B).

gamma('$var'(X),[]/['$var'(X):T],T):-!.

gamma(C,EN/EN,TD):-
	(cdata(C,_,TC,_),!,translateType(TC,TD)
	;
	constr(C,_,TD,_),!).


gamma(F,EN/EN,T):-gammaFun(F,EN,T).

gammaFun(F,[G:A|R],B):-
	(F==G,!,B=A;gammaFun(F,R,B)).

% Si la funcion no esta en el mismo bloque, su tipo ya habra sido inferido antes
% y entonces lo buscamos en la base de datos.

gammaFun(F,_,TF):-
        functiontype(F,TF),!.


% Esta ultima clausula nunca se usa en tiempo de compilacion, se usa en tiempo
% de ejecution para sacar el tipo de los objetivos

gamma(F,_,TF):-
        (funct(F,_,_,TF,_);constr(F,_,TF,_)),!.

gamma(F,EN/EN,_):-!,errorType(10:[F]).


%----------------------------------------------------------------------------%
% rename: renombra las variables de un termino (se usa para renombrar las 
% variables de los tipos).
%----------------------------------------------------------------------------%

/*

rename(X,_):-var(X),!.
rename(T,TR):-	
	T=..[Name|Args],
	renameLst(Args,ArgsR),
	TR=..[Name|ArgsR].

renameLst([],[]).
renameLst([A|R],[AR|RR]):-
	rename(A,AR),
	renameLst(R,RR).
	

*/


/*
%----------------------------------------------------------------------------%
% proving(+EN,+EXP) Comprobador de tipos. Siempre falla .
% proving comprueba que cuando nos encontramos con una llamada a una 
% funcion el tipo inferido para esta llamada es una instancia del tipo de la
% funcion, si ambas no son mutuamente recursivas. Si son mutuamente recursivas
% no tenemos nada que hacer porque el tipo de la llamada esta en proceso de 
% inferencia y no tenemos con quien comprobar
%----------------------------------------------------------------------------%


proving(F,Pos,TLLA):-
	functiontype(F,TF),
	!,
	(subsumes_chk(TF,TLLA),!;errorType(9:[F,Pos,TF,TLLA])).

% si no es del mismo bloque, no hay nada que comprobar.

proving(_,_,_).	



%----------------------------------------------------------------------------%
% Cuando se han inferido los tipos para las funciones de un bloque, se 
% comprueba que los (posibles) tipos declarados son instancias de los inferidos
%----------------------------------------------------------------------------%

proving_declared_types([F:TINF|TRF]):-
	ftype(F,_,TF,_),
	!,
	translateType(TF,TD),
	(subsumes_chk(TINF,TD),!;
	errorType(2:[F,TD,TINF])),
	proving_declared_types(TRF).


% si no esta declarada, no hay nada que hacer

proving_declared_types(_).


*/

%----------------------------------------------------------------------------%
% mete en la BD los tipos de las funciones siguiendo la politica de respetar
% el tipo declarado, e.d., si el usuario ha declarado tipo para una funcion
% se comprueba que el tipo inferido es mas general que el declarado y se deja
% como tipo el declarado. Si no ha declarado tipo dejamos el inferido.
% los tipos se asertan a la BD como functiontype(Funcion,tipo).
%----------------------------------------------------------------------------%

% Enrique: aserta todos los tipos inferidos, ya que no pueden ser m�s generales
% ni mas concretos que el declarado
keepTypes([]).
keepTypes([F:TINF|RTF]):-
   assertfunctiontype(F,TINF),
   keepTypes(RTF).


/*
keepTypes([]).
keepTypes([F:TINF|RTF]):-
	(
		ftype(F,_,TF,_),
		!,
		translateType(TF,TD),
		(
			% si hay tipo declarado, comprobamos que es mas 
			% particular que el inferido

		        subsumes_chk(TINF,TD),
			%my_subsumes(TINF,TD),
    			!,
			% si no es identico damos un warning
			(
			    my_subsumes(TD,TINF),!
			    ;
			    warning_type(1:[F,TD,TINF])
			),
			assertfunctiontype(F,TD)

		;
			errorType(2:[F,TD,TINF]),
			% Si hay error le ponemos tipo variable
			assertfunctiontype(F,_)
		)
	;
		assertfunctiontype(F,TINF)
	),
	keepTypes(RTF).
*/

%----------------------------------------------------------------------------%
% my_subsumes(T1,T2) chequea si el tipo T2 es una instancia de T1
%----------------------------------------------------------------------------%

%080199
% La funcion
%   pega :: real -> [B] -> [C]
%   pega X L = [X|L]
% Declared type: real ->  [ _A ] ->  [ _B ]
% Inferred type: _A ->  [ _A ] ->  [ _A ]   
% esto es un error porque el tipo inferido no es mas general que el declarado,
% pero no se detectaba.

% Ahora antes de nada se hace una copia (renamemiento de variables) y
% luego se trabaja con las copias, sobre las que se puede hacer unificacion
% sin tocar los originales.
% El subsumes_chk de Prolog no sirve porque el caso de los numeros es particular
% (vease mas abajo).

my_subsumes(X,Y):-copy_term(X,CX),copy_term(Y,CY),my_subsumes_chk(CX,CY).


my_subsumes_chk(V,X):-var(V),!,V=X.
my_subsumes_chk(_,V):-var(V),!,fail.

% los enteros se representan como num(int), los reales como num(float) y si
% puede ser tanto un entero como un real se notara como num(A). Las unicas
% colisiones posibles se producen al comparar num(int) con num(real) o viceversa.

% IMPORTANTE: Notese que un tipo numerico declarado siempre sera de la forma num(int) o
% num(float); nunca sera num(A).

% La unica clausula de my_subsumes_chk para num es compleja aunque lo unico que hace
% es unificar los argumentos de num:
%     - Si el primer argumento es num(X), el segundo sera una instancia en cualquier caso
%     - Si es num(int) el segundo debe ser num(int), pero la clausula tambien tiene exito si
% el segundo es num(A). Realmente num(A) no es una instancia de num(int) pero nos interesa
% considerar que si lo es: el segundo argumento tiene que provenir de un tipo inferido (los
% declarados nunca tienen esta forma). Entonces este caso se puede dar en la llamada
% my_subsumes(TD,TINF), cuando comprobamos si el tipo inferido es una instancia del declarado.
% Si no es instancia dariamos un warning, pero queremos obviar este warning porque de lo
% contrario apareceria por ejemplo en:
%       g :: int -> int 	
%       g X = X+10 
% que es poco aclaratorio.
% Esto es una peque�a "trampa" que facilita las cosas y no saca warnings en casos como el
% anterior. POR ESO NO SE PUEDE USAR EL SUBSUMES DE SICSTUS.
%     - Si es num(float) tiene exito tanto si el segundo argumento es num(float) como si es
% num(Y). Aqui tambien se hace una peque�a trampa: num(Y) no es instancia de num(float) pero
% nos interesa considerarlo como tal.



my_subsumes_chk('$num'(A),'$num'(B)):-!,A=B.


my_subsumes_chk(T1,T2):-
	T1=..[C|Args1],
	T2=..[C|Args2],
	my_subsumes_chkLst(Args1,Args2).

my_subsumes_chkLst([],[]).
my_subsumes_chkLst([C1|R1],[C2|R2]):-
	my_subsumes_chk(C1,C2),
	my_subsumes_chkLst(R1,R2).


%----------------------------------------------------------------------------%
% unify(+T1,+T2,-T): Unificador mas general posible, con occur check
%----------------------------------------------------------------------------%

/*
% unificacion con occur check

unify(X,Y):-
	(atom(X);var(X)),(atom(Y);var(Y)),!,X=Y.

unify(X,Y):-
	var(X),!,occurs_check(X,Y),X=Y.

unify(X,Y):-
	var(Y),!,occurs_check(Y,X),X=Y.

unify(X,Y):-
	X=..[N|L1],Y=..[N|L2],L1\==[],L2\==[],unifyList(L1,L2).


unifyList([A],[B]):-
	!,
	unify(A,B).

unifyList([A],[B|R]):-
	!,
	TP=..[B|R],
	unify(A,TP).
	
unifyList([A|R],[B]):-	
	!,
	TP=..[A|R],
	unify(TP,B).

unifyList([A|R1],[B|R2]):-
	unify(A,B),
	unifyList(R1,R2).

*/
    

%----------------------------------------------------------------------------%
% unify_env: unifica los tipos de una lista de variables en dos entornos
% unifica dos entornos y deja el resultado en el tercer argumento. Este 
% argumento es necesario cuando se produce un error (no son unificables)
% Si se produce error en esta unificacion dejamos variable el tipo de la funcion
% afectada.
%----------------------------------------------------------------------------%

unify_env([],[],[],_):-!.

unify_env([X:T|L],[X:T1|L1],[X:TX|RL],LF):-
	(my_unify_with_occurs_check(T,T1),!,TX=T;errorType(1:[X,T,T1,LF])),
	unify_env(L,L1,RL,LF).



%----------------------------------------------------------------------------%
% unifyLstTypes: Unifica una lista de tipos                               %
% Unifica una lista de tipos. Para ello unificamos el primero con el resto. 
% Vamos llevando el resultado en un acumulador. El nombre de la funcion y el 
% contador solo sirven para informar al usuario del lugar donde se produce el
% error.
%----------------------------------------------------------------------------%

unifyLstTypes(_,[T],T):-!.

unifyLstTypes(F,[TR|RT],TF):-
	unifyTypeLstTypes(F,2,TR,RT,TF).


unifyTypeLstTypes(_,_,TAc,[],TAc):-!.
unifyTypeLstTypes(F,N,TAc,[TR|RT],TF):-
	(my_unify_with_occurs_check(TAc,TR),!,
		N1 is N+1,unifyTypeLstTypes(F,N1,TAc,RT,TF);
	errorType(3:[F/N,TAc,TR])).
% dejamos TT variable como rec de error	



%----------------------------------------------------------------------------%
% occurs_check(+Var,+Term): comprueba si la Var aparece en el Term
%----------------------------------------------------------------------------%

/*
occurs_check(Var,Term):-
	var(Term),
	!,
	Var\==Term.

occurs_check(Var,Term):-
	Term=..[_|Args],
	(Args==[];
	occurs_checkLst(Var,Args)).

occurs_checkLst(_,[]).
occurs_checkLst(Var,[A|R]):-
	occurs_check(Var,A),
	occurs_checkLst(Var,R).

*/



%----------------------------------------------------------------------------%
% includeTypes: Incluye en el entorno variables de tipo como tipo de las 
% funciones a definir 
%----------------------------------------------------------------------------%

% Enrique: modificado para que aserte en la BD los tipos declarados para
% usarlos durante la inferencia, e incluya en el entorno variables de tipo
% solo para aquellas funciones que no tienen tipo declarado

includeTypes([],[]):-!.
includeTypes([F|RF],L):-
   ftype(F,_,T,_),!,
   translateType(T,TF),
   assertfunctiontype(F,TF), 
   %write('asertado '), write(F), write(' : '), write(T),nl,
	includeTypes(RF,L).
includeTypes([F|RF],[F:_|L]):-
   	includeTypes(RF,L).


%----------------------------------------------------------------------------%
% addEnvironment(+LF) Inserta en la base de datos la tabla functiontype(F,TF)  
% aniade  a la BD el tipo inferido para las funciones de un bloque
%----------------------------------------------------------------------------%

addEnvironment([]):-!.
addEnvironment([F:TF|TRF]):-
			assertfunctiontype(F,TF),
			addEnvironment(TRF).



%----------------------------------------------------------------------------%
% errorType(+Num:Params)
%----------------------------------------------------------------------------%

errorType(N:[E|R]):-
	asserttypeError,
	nl,nl,
	write('TYPE ERROR: '),
	describeError(N:[E|R]),
	nl,
	%write('Variable type is assumed for '),
	%write(E),
	write('Variable type is assumed to go on the inference.'),
	nl,nl.
	
errorType(N:[E|R],E1,TR1,E2,TR2):-
	asserttypeError,
	nl,nl,
	write('TYPE ERROR: '),
	describeError(N:[E|R],E1,TR1,E2,TR2),
	nl,
	%write('Variable type is assumed for '),
	%write(E),
	write('Variable type is assumed to go on the inference.'),
	nl,nl.


describeError(1:[X,T,T1,LF]):-
	write('Function '),write(X),write(' has inferred type '),
	writeAtom(T1),
	write(', but it''s used with type '),writeAtom(T),
	write(' in block '),
	write(LF),write('.').


describeError(2:[F,TD,TINF]):-
	write('Contradictory types for function '),write(F),nl,
	write('Declared type: '),writeAtom(TD),nl,
	write('Inferred type: '),writeAtom(TINF),nl,
	write('with no possible conversion.').


describeError(3:[F/N,TAc,TR]):-
	write('Contradictory inferred types in rules for function '),write(F),
	nl,write(F/N),write(': '),
	writeAtom(TR),nl,	
	write('Previous rules: '),writeAtom(TAc).	

describeError(4:[Name/N,TP,TEN1]):-
	write('Impossible to infer type for '),write(Name/N),
	write('.'),nl,
	write('Inferred type for pattern is '),writeAtom(TP),write('.'),nl,
	write('Inferred type for call is '),writeAtom(TEN1),write('.').


describeError(5:[Pos,E1,T1,E2,T2]):-
	write('Wrong type in higher order aplication of '),writeAtom(E1),
	write(' with type "'),writeAtom(T1),
	write('" to '),writeAtom(E2),write(' with type "'),
	writeAtom(T2),write('" in '),write(Pos),write('.'),
	write(' Recursive types are not allowed.').

describeError(6:[Pos,E],E1,TR1,E2,TR2):-
	write('Uncomparable expresions in '),
	write(Pos),write(': '),writeAtom(E),write('.'),
	nl,write('Contradictory types:'),
	nl,writeAtom(E1),write(': '),writeAtom(TR1),
	nl,writeAtom(E2),write(': '),writeAtom(TR2).


describeError(7:[Pos,E,T]):-
	write('Wrong type in '),write(Pos),write('. '),
	write('Expected type '),
	writeAtom(T),write(' in '),writeAtom(E).

describeError(8:[Pos,N,Term,TA,T1]):-
	write('Wrong type calling function or constructor symbol '),
	writeAtom(Term),write(' in '),
	write(Pos),write('. '),write('Argument '),write(N),write(' has type '),
	writeAtom(TA),write(' but '),
	writeAtom(T1),write(' was expected.').

describeError(9:[F,Pos,TF,TLLA]):-
	write('Wrong type calling function "'),write(F),
	write('" in '),write(Pos),write('. '),nl,
	write('Function type: '),writeAtom(TF),nl,
	write('Call     type: '),writeAtom(TLLA). 


describeError(10:[F]):-
	write('Undefined constructor or function symbol '),write(F).
	
describeError(20:[Func/N,T,DT]):-
	write( 'The type ' ), writeAtom( T ), write( ' inferred for the rule '), write( Func/N ), 
	write( ' is not a variant of the declared type for '), write( Func ), 
	write( ' : '), writeAtom( DT ).
	
describeError( 21:[F/N, [X] ]) :-
   write( 'Variable ' ), showDataVars( [X] ), write( ' is critical in rule ' ),
   write( F/N ).
   
describeError( 21:[F/N, [X,Y|R] ] ) :-
   write( 'Variables ' ), showDataVars( [X,Y|R] ), write( ' are critical in rule ' ),
   write( F/N ).
   
describeError( 22:[Name/N,TP,TF] ) :-
   write( 'The type ' ), writeAtom( TP ), write( ' inferred for rule '), write( Name/N ), 
   write( ' does not match the declared type ' ), write(TF), write( ' for function ' ),
   write( Name ).
   
describeError( 23:[Name/N,TP,TF] )  :-
   write( 'The type ' ), writeAtom( TP ), write( ' inferred for rule '), write( Name/N ), 
   write( ' does not match the inferred type ' ), writeAtom(TF), 
   write( ' for previous rules of the function ' ), write( Name ).
   
describeError( 24:[Name/N,[X],Lin,Pat] )  :-
   write( 'Variable ' ), showDataVars( [X] ), write(' appearing in the where binding '), 
   writeAtom(Pat), write(' of the rule '), write( Name/N ), write(' (line '), write( Lin ), write( ') is critical' ).
   
describeError( 24:[Name/N,[X,Y|R] ,Lin,Pat] )  :-
   write( 'Variables ' ), showDataVars( [X,Y|R]  ), write(' oppearing in the where binding '), 
   writeAtom(Pat), write(' of the rule '), write( Name/N ), write(' (line '), write( Lin ), write( ') are critical' ).

   

%----------------------------------------------------------------------------%
% warning_type(Num:Params) 
%----------------------------------------------------------------------------%

warning_type(W):-
	nl,nl,
	write('TYPE WARNING: '),
	describeWarning(W),
	nl,nl.

describeWarning(1:[F,TD,TINF]):-
	write('Inferred type is more general than declared one in function '),
	write(F),
	nl,write('Inferred type: '),writeAtom(TINF),
	nl,write('Declared type: '),writeAtom(TD),
	nl,write('Declared one remains.').




%%%%%%%%%%%%%%% parche indecente para las tuplas; pacol 7-11-00

my_unify_with_occurs_check(T1,T2) :- 
        convert(T1,S1),  % Convertimos las tuplas en listas
        convert(T2,S2),  % Idem 
        \+ \+ unify_with_occurs_check(S1,S2), % Hay que ver que esta unificacion tiene exito
                                              % pero no dejar que tenga efecto. De otro modo
                                              % dejamos tipos "conversos" en los entornos.
        unify_with_occurs_check(T1,T2).       % Esta es la unificacion que vale. Obviamente 
                                              % podriamos programarla directamente y evitar 
                                              % toda la chapuza.
                                    
convert(X,X):- 
        var(X),!.
convert('$$tuple'(T),'$$tuple'(S)):- 
        !,tuple_to_list(T,Ts),
        convert_list(Ts,S).
convert(X,Y):-
        X =..[F|Xs],!, 
        convert_list(Xs,Ys), 
        Y =.. [F|Ys].
convert(X,X). % no creo que haga falta.

convert_list([],[]).
convert_list([X|Xs],[Y|Ys]):- 
        convert(X,Y), 
        convert_list(Xs,Ys).

tuple_to_list(X,[X]):- 
        var(X),!.
tuple_to_list((X,Y),[X|Ys]):- 
        !,tuple_to_list(Y,Ys).
tuple_to_list(X,[X]).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Enrique
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% check_variant( +Type, +Func, +Assump )
% Checks that Type is a variant of the closed type-scheme stored in a type/2 fact 
check_variant( T, Func, Assump ) :-
  %gamma( Func, []/[], NVariant ),
  functiontype( Func, NVariant ),
  % infer returns a new variant of the type of Func, that will be stored in a type/2 fact. 
  % Therefore, the set of assumptions is not needed
  ftv( NVariant, FTVNVar ),
  ftv( T, VT ),
  unify_with_occurs_check( T, NVariant ),
  isVarList( FTVNVar ),% checks if T is a variant of NVariant
  ftv( Assump, FVAssump ),
  ftv( T, VT ), 
  intersect_var( FVAssump, VT, [] ). % check that all the variables in T are fresh wrt. the set of assumptions


% check_variant_list( +List, +Assump )
% Applies check_variant to every tuple (Type,Func) in List
check_variant_list( [], _Assump ).
check_variant_list( [(T,Func/N)|RT], Assump ) :-
  (   check_variant( T, Func, Assump ) -> true
  ;   functiontype( Func, DT ),
      errorType( 20:[Func/N,T,DT] )
  ),
  check_variant_list( RT, Assump ).
/*  check_variant_list( RT, Assump ).
check_variant_list( [(T,Func/N)|_RT], Assump ) :-
  write( 'Assump: '), write( Assump ), nl,
  write(T), write(' is not a variant of the type of '), 
  write(Func), 
  functiontype( Func, Var ),
  write(' : '), write( Var ), nl,
  fail.
*/  
  
% ftv( +TypeScheme, -LVars ) 
% Returns the list of free variables of TypeScheme
ftv( V, [V] ) :-
  var( V ), !.
%ftv( C, [] ) :-
%  atom( C ), !. % type constructor
%ftv( ->(T1,T2), LVar ) :-
%  !, ftv( T1, L1 ),
%  ftv( T2, L2 ),
%  append_nodups( L1, L2, LVar ).
ftv( T, LVar ) :-
   T =.. [_Ctor|L],
   ftv_list(L,[],LVar).
/*ftv( T1 @ T2, LVar ) :-
  ftv( T1, L1 ),
  ftv( T2, L2 ),
  append_nodups( L1, L2, LVar ).
*/
ftv_list([], LVar, LVar).
ftv_list([T|RT], LVar, NLVar ) :-
   ftv( T, LVarT ),
   append_nodups( LVarT, LVar, LVar2),
   ftv_list( RT, LVar2, NLVar ).
  
  
% append_nodups( +L1, +L2, -L3 ) 
% concatenates L1 and L2 erasing duplicates (like set union)
append_nodups( [], L ,L ).
append_nodups( [X|R], L, List ) :-
  member_var( X, L ), !,
  append_nodups( R, L, List ).
append_nodups( [X|R], L, [X|List] ) :-
  append_nodups( R, L, List ).
  
  
% member_var( +X, +LVar )
% Checks if var X occurs in the list of vars LVar
member_var( X, [Y] ) :-
  X == Y.
member_var( X, [Y|_R] ) :-
  X == Y, !.
member_var( X, [_Y|R] ) :-
  member_var( X, R ).
% member_var( +X, +LVar )
% Checks if var X do NOT occurs in the list of vars LVar
nonmember_var( _X, [] ).
nonmember_var( X, [Y|R] ) :-
  X \== Y,
  nonmember_var( X, R ).

  
% isVarList( +L )
% Checks if the list only contains variables  
isVarList( [] ).
isVarList( [X|R] ) :-
  var( X ),
  isVarList( R ).
  
  
% intersect_var( +L1, +L2, -Int )
% Calculates the intersection of the sets of variables L1 and L2
intersect_var( [], _L, [] ).
intersect_var( [X|R], L, [X|NR] ) :-
  member_var( X, L ), !,
  intersect_var( R, L, NR ).
intersect_var( [X|R], L, NR ) :-
  nonmember_var( X, L ),
  intersect_var( R, L, NR ).
  
  
% fv( +Expr, -EVars )
% Returns the list of variables of the expression Expr
fv( '$var'(X), ['$var'(X)]) :- !.
fv( '$int'(_A), [] ) :- !.
fv( '$float'(_A), [] ) :- !.
fv( '$char'(_A), [] ) :- !.
fv( '$apply'(E1,E2), EVars ) :-
   !, fv( E1, FV1 ),
   fv( E2, FV2 ),
   append_nodups( FV1, FV2, EVars ).
fv( E, EVars ) :-
   E =.. [Name|Args],
   fv_list( Args, EVars ).
% Falta el do y las listas intensionales

fv_list( [], [] ).
fv_list( [E|RE], FVars ) :-
   fv( E, EVars ),
   fv_list( RE, REVars ),
   append_nodups( EVars, REVars, FVars ).
   
   
   
% check_critical_vars( +EN, +Args, +Body, +Where, +F/N )
% Check if there are critical variables in the patterns (Args) or in the where 
% bindings (Where) of rule F/N, producing an error
%check_critical_vars( _EN, [], _Body, _Where, _F/_N ) :- !.
check_critical_vars( EN, Args, Body, Where, F/N ) :-
   fv( Body, FVBody ),
   check_critical_vars2( EN, Args, FVBody, F/N ),
   check_critical_vars_where( EN, Where, FVBody, F/N ).
   
% check_critical_vars_where( +EN, +Where, +FVBody, +F/N )
% Check if there are critical variables in where bindings (Where) of rule F/N, 
% producing an error. It accepts the free variables of the body of the rule
% (FVBody) to check the occurrence of opaque variables.
% Notice that it also checks if opaque variables in bindings appear in the 
% right-hand side of some other binding, since it also makes them critical
check_critical_vars_where( EN, Where, FVBody, F/N ) :-
  fv_where( Where, FVWhere ),
  append_nodups( FVBody, FVWhere, FV ), 
  % FV collects all the variables in the body and the rhs of the where bindings
  check_critical_vars_where2( EN, Where, FV, F/N ).  
   
% check_critical_vars_where2( +EN, +Where, +FV, +F/N )
% Check if there are critical variables in where bindings (Where) of rule F/N, 
% taking FV as the set of free variables in the body of the rule and in the rhs
% of its where bindings. When finding critical variables, it produces an error
check_critical_vars_where2( _EN, [], _FV, F/N ) :- !.
check_critical_vars_where2( EN, ['='(Pat,Expr,Lin) | R], FV, F/N ) :- 
  opaqueVars( EN, Pat, OVars ),
  intersect_var( OVars, FV, CritVar ),
  (  CritVar == [] -> true
   ;  errorType( 24:[F/N,CritVar,Lin,Pat] )
   ),
   check_critical_vars_where2( EN, R, FV, F/N ).
   
% fv_where( +Where, -FV)
% FV collects the free variables in the rhs of the where bindings (Where)
fv_where( [], [] ) :- !.
fv_where( ['='(_Pat,Expr,_Lin) | R],  FV ) :-
  fv( Expr, FVExpr ),
  fv_where( R, FVWhere ),
  append_nodups( FVExpr, FVWhere, FV ).


% check_critical_vars2( EN, Args, FVBody, F/N)
% Checks if any variable in the patterns of rule F/N (Args) appears in the body
% (FV), i.e., it there are critical variables
check_critical_vars2( _EN, [], _FVBody, _F/_N ) :- !.
check_critical_vars2( EN, [Pat|RPat], FVBody, F/N ) :-
   opaqueVars( EN, Pat, OVars ),
   intersect_var( OVars, FVBody, CritVar ),
   (  CritVar == [] -> true
   ;  errorType( 21:[F/N,CritVar] )   
   ),
   check_critical_vars2( EN, RPat, FVBody, F/N ).
   % Al no haber lets ni lambdas en el lado derecho, no hay que mirarlo
   
% opaqueVars( +Assump, +Pat, -OVars )
% Returns the list of opaque variables of a pattern.
opaqueVars( EN, P, OVars ) :-
  fv( P, PVars ),
  %fresh_assump( PVars, AssumpVars ),
  %append( AssumpVars, Assump, NAssump ),
  expressionType( P, _, EN/EN1, PType ),
  ftv( PType, PTypeVars ),
  filter_opaque_vars( PVars, EN1, PTypeVars, OVars ).
  


% filter_opaque_vars( +PVars, +Assump, +PTypeVars, -OVars )
% Given a list of data variables (PVars) in a pattern, a set of assumptions (Assump) containing that variables
% and a set of type variables (PTypeVars) appearing in the type of the pattern, returns those data variables
% such that are opaque, i.e., whose assumptions contains type variables not appearing in PTypeVars.
filter_opaque_vars( [], _Assump, _PTypeVars, [] ).
filter_opaque_vars( [X|R], EN, PTypeVars, NR ) :-
  gamma( X, EN/EN, Type ),
  ftv( Type, TypeVars ),
  subset_var( TypeVars, PTypeVars ), !,
  filter_opaque_vars( R, EN, PTypeVars, NR ).
filter_opaque_vars( [X|R], EN, PTypeVars, [X|NR] ) :-
  gamma( X, EN/EN, Type ),
  ftv( Type, TypeVars ),
  \+ subset_var( TypeVars, PTypeVars ),
  filter_opaque_vars( R, EN, PTypeVars, NR ).
  
% subset_var( +L1, +L2 ).
% Checks that the set of variables L1 is a subset of the set of variables L2
subset_var( [], _L ).
subset_var( [X|R], L ) :-
  member_var( X, L ),
  subset_var( R, L ).

% showDataVars( +VarList )
% pretty printer of a list of variables  
showDataVars( [] ) :- !.
showDataVars( ['$var'(X)] ) :-
   !, write( X ).
showDataVars( ['$var'(X), V | RV] ) :-
   write( X ), write( ', ' ), 
   showDataVars( [V | RV] ).

  


