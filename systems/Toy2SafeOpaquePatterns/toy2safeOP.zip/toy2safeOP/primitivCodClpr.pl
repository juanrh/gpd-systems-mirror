%----------------------------------------------------------------------------%
% primitivesClpr.pl
%----------------------------------------------------------------------------%
/*
- Autor: Jaime
- Descripcion: Este modulo es el equivalente a primitives.pl solo que se usa 
cuando se esta trabajando con restricciones sobre reales. Este modulo es igual 
que el primitives.pl solo que este se usa cuando esta el resolutor activado, 
por lo tanto al definir las funciones, hay que resolver las ecuaciones.
En la version en la que se han separado las restricciones sobre reales, este
modulo se ha eliminado porque no se usa.
- Modulos que le llaman: inferrer, plgenerated, compil, process.
- Modulos a los que llama:
    > toycomm.pl (with 'hnf' and 'unifyHnfs'). 
- Ultimas modificaciones: 
    30/09/99 mercedes (se han comentado los predicados)
    26/10/99 mercedes (modularizacion).
        03/11/99 mercedes (He cambiado cada aparicion de num que hay en el 
                   codigo y la he sustituido por '$num'. Esto es 
               porque num era una palabra reservada y podia 
               colisionar con nombres de usuario. Por ejemplo:
               programa: data chungo = num real
               objetivo: num 3 == X
               resultado: X == real
               Eso era lo que pasaba antes de cambiarlo).
    05/11/99 mercedes (Se ha quitado la declaracion primInfix(',',right,12),
               porque las tuplas se tratan explicitamente en 
               la gramatica y por tanto no hacen falta declaraciones
               "infix").
    12/01/00 mercedes (Se ha llevado el codigo de flip a basic.pl porque
               aqui hacia que se necesitara importar el $$apply de 
               basic y eso genera efectos indeseables al activar y  
               desactivar /cflpr cuando estamos en la version con 
               restricciones sobre reales. Para esto los cambios
               que se han necesitado hacer son:
               - quitar el codigo de $flip de primitives.pl y de
               primitivesClpr.pl y llevarlo a basic.pl
               - quitar $flip de la lista de exportaciones de
               primitives.pl y primitivesClpr.pl y ponerlo como
               exportacion del basic.pl.
               - Poner el codigo de $flip al final del plgenerado. 
               Esto se hace en process.pl cuando estamos generando 
               el plgenerado, al final se pone a capon el codigo
               de $flip.
               - Poner en la lista de exportaciones del plgenerado
               el $flip/6.).

     11/12/06 Sonia: Intercambio el orden entre enviar una restricci�n al resolutor
            de reales {...} y comprobar si alg�n distinto almacenado en Herbrand
            est� afectado por alguna variable de dicha restricci�n "toSolver"
     



*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(primitivCod,['$if_then_else'/6,
          '$if_then'/5,
          % '$flip'/6,
%%::B
          '$evalfd'/5,
%%::E
          '$uminus'/4,'$abs'/4,'$sqrt'/4,'$ln'/4,'$exp'/4,
          '$sin'/4,'$cos'/4,'$tan'/4,'$cot'/4,'$asin'/4,'$acos'/4,'$atan'/4,
          '$acot'/4,'$sinh'/4,'$cosh'/4,'$tanh'/4,'$coth'/4,'$asinh'/4,'$acosh'/4,
          '$atanh'/4,'$acoth'/4,$+ /5,$- /5,$* /5,'$min'/5,'$max'/5,$/ /5,'$**'/5,
          '$log'/5,$^ /5,'$div'/5,'$mod'/5,'$gcd'/5,'$round'/4,'$trunc'/4,
          '$floor'/4,'$ceiling'/4,'$toReal'/4,$< /5,$> /5,$<= /5,$>= /5,
%%::B Optimization. 16/06/2006 Fernando        
          '$minimize'/4,'$maximize'/4,'$bb_minimize'/5,'$bb_maximize'/5,
%%::E          
          '$ord'/4,'$chr'/4,
          '$putChar'/4,'$done'/3,'$getChar'/3,'$return'/4,$>> /5,$>>= /5,
          '$putStr'/4,'$putStrLn'/4,'$getLine'/3,'$cont1'/4,'$cont2'/5,
          '$writeFile'/5,'$readFile'/4,'$readFileContents'/4,
          '$trans'/3,'$control_open'/3,'$add_control'/5,'$remove_control'/3,
%% ::B Rafa           
          '$dValToString'/4,'$dVal'/4,'$selectWhereVariableXi'/7,
          '$getConstraintStore'/4,
%% ::E

% FALLO FINITO Y CORTE 
% pacol 17-03-05
           '$fails'/4, '$once'/4, '$collect'/4, '$collectN'/5
           ]).


:- load_files(toycomm,[if(changed)]). %,imports([hnf/4,unifyHnfs/4,toSolver/3])]).

% :- load_files(basic,[if(changed),imports(['$$apply'/5])]).
/*              
Lo que se hace es cargar inicialmente el fichero basic.pl que contiene el modulo
plgenerado inicial, pero cuando se genere un fichero.pl y se cargue (en el modulo
procesa), como lo generamos como modulo plgenerado, se borra el modulo 
plgenerado antiguo y se carga este nuevo.
*/

%%::R 05-05-2004
:- load_files(pVal,[if(changed),imports([atomToPVal/3,atomToString/3,exprToTerm/2,dValProlog/2,variableName/2])]). % rafa 09/08/01
%%::E


% 11/05/00 mercedes
% Estos modulos se necesitan para la parte de entrada/salida

:- load_files(tools,[if(changed),imports([append/3,member/2])]).

:- load_files(codfun,[if(changed),imports([introduceSusp/3])]).

%% B Sonia
%:- load_files(dyn,[if(changed),imports([assertfile/3,retractfile/3,file/3,debugando/0])]).
:- load_files(dyn,[if(changed),imports([assertfile/3,retractfile/3,file/3,debugando/0,proj_active/0])]).
:- dyn:cflpfd_active, !, load_files(cooperation,[if(changed)]).
%% E Sonia

:- load_files(errortoy,[if(changed),imports([treat_error/2])]).



:- use_module(library(clpr)).

%%  B :: Sonia
:- use_module(library(clpfd)).
%%  E :: Sonia


/*
    This module contains the code for primitives. This functions haves a
direct tranlation into Prolog. Before the Prolog
operation the hnf predicate must be called for each one argument.


Types for aritmethic functions are defined in a quite ad-hoc way here
in order to allow (a very limited) overloading of arithmetic operations.
The idea is the following: we represent the types 'int' and 'real'
by the terms 'num(int)' and 'num(real)', and we use 'num(A)' for
achieving overloading, when desired. 

Nota: Los tipos de las primitivas se toman de aqui (no del standard) para 
poder forzar el tipo de algunas funciones como / o sqrt y siempre devuelvan 
real (num(float))

P.e. el + respeta la declaracion + :: num(A) -> num(A) -> num(A), lo que quiere
 decir que si los dos argumentos son int el resultado es int y si alguno de los
dos es float el resultado es float.
En / tenemos / :: num(A) -> num(

*/


/***************     CODE PRIMITIVE FUNCTIONS     ***************/


% Las funciones de aridad 1 tienen el siguiente modo de uso:
% funcion(+X,-H,+Cin,-Cout) don de X es al argumento al que se aplica la funcion,
% H es el resultado de aplicar la funcion a X, y Cin y Cout son los almacenes
% de restricciones.
% Las funciones de aridad 2 tienen el siguiente modo de uso:
% funcion(+X,+Y,-H,+Cin,-Cout) donde X e Y son los argumentos a los que se 
% aplica la funcion, H es el resultado de aplicar la funcion a X e Y, y Cin y
% Cout son los almacenes de restricciones.
% Las funciones de aridad 3 tienen el siguiente modo de uso:
% funcion(+X,+Y,+Z,-H,+Cin,-Cout) donde X, Y y Z son los argumentos a los que se 
% aplica la funcion, H es el resultado de aplicar la funcion a X, Y y Z, y Cin y
% Cout son los almacenes de restricciones.


'$if_then_else'(B, E1, E2, H, Cin, Cout):-
        hnf(B, HB, Cin, Cout1),
        '$if_then_else_1'(HB, E1, E2, H, Cout1, Cout).

'$if_then_else_1'(B, E1, _E2, H, Cin, Cout):-
        unifyHnfs(B, true, Cin, Cout1),
        hnf(E1, H, Cout1, Cout).

'$if_then_else_1'(B, _E1, E2, H, Cin, Cout):-
        unifyHnfs(B, false, Cin, Cout1),
        hnf(E2, H, Cout1, Cout).


'$if_then'(B, E, H, Cin, Cout):-
        hnf(B, true, Cin, Cout1),
        hnf(E, H, Cout1, Cout).

        
        
% '$flip'(F, A1, A2, H, Cin, Cout):-
%        '$$apply'('$$susp'( '$$apply',  [ F, A2 ], _G, _H ), A1, H, Cin, Cout).
% Este codigo se ha llevado a basic.pl porque aqui hacia que se necesitara
% importar el $$apply de basic y eso genera efectos indeseables al activar y  
% desactivar /cflpr cuando estamos en la version con restricciones sobre reales




% Funciones unarias para enteros y reales 

%B:: Sonia
% '$uminus'(X,H,Cin,Cout):-
%     hnf(X,HX,Cin,Cout1),
%     {H = -HX},
%     toSolver(HX,Cout1,Cout2),
%     toSolver(H,Cout2,Cout).

'$uminus'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    (number(HX) -> H is -HX;
                   (toSolver(HX,Cout1,Cout2),
                    toSolver(H,Cout2,Cout),
                    {H = -HX}
                    )).

%E:: Sonia

'$abs'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = abs(HX)}.



% Funciones reales unarias

'$sqrt'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = pow(HX,1/2)}.

'$ln'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = exp(E,H)}.

'$exp'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = exp(E,HX)}.

'$sin'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = sin(HX)}.

'$cos'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = cos(HX)}.

'$tan'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = tan(HX)}.

'$cot'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = 1/tan(HX)}.

'$asin'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = sin(H)}.

'$acos'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = cos(H)}.

'$atan'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = tan(H)}.

'$acot'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = 1/tan(H)}.

'$sinh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = (exp(E,HX)-exp(E,-HX))/2}.

'$cosh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = (exp(E,HX)+exp(E,-HX))/2}.

'$tanh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = (exp(E,HX)-exp(E,-HX))/(exp(E,HX)+exp(E,-HX))}.

'$coth'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {H = (exp(E,HX)+exp(E,-HX))/(exp(E,HX)-exp(E,-HX))}.

'$asinh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = (exp(E,H)-exp(E,-H))/2}.

'$acosh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = (exp(E,H)+exp(E,-H))/2}.

'$atanh'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = (exp(E,H)-exp(E,-H))/(exp(E,H)+exp(E,-H))}.

'$acoth'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    E is exp(1.0),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    {HX = (exp(E,H)+exp(E,-H))/(exp(E,H)-exp(E,-H))}.


% operadores y funciones aritmeticos binarias para enteros y reales

$+(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
%%  B :: Sonia
%    toSolver(H,Cout4,Cout).
    toSolver(H,Cout4,Cout5),
    {H = HX + HY},
    (proj_active -> 
    (
        searchVarsFD(HX,Cout5,Out1,HXFD),
        searchVarsFD(HY,Cout5,Out2,HYFD),
        ( ( Out1 == true, Out2 == true ) -> 
        (
            $#==(HFD, H, true, Cout5, Cout),
            HFD #= HXFD + HYFD
        )
        ;Cout = Cout5 %,! 
         )
     );Cout = Cout5
    ).
%%  E :: Sonia


$-(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
%%  B :: Sonia
%    toSolver(H,Cout4,Cout).
    toSolver(H,Cout4,Cout5),
    {H = HX - HY},
    (proj_active -> 
    (
        searchVarsFD(HX,Cout5,Out1,HXFD),    
        searchVarsFD(HY,Cout5,Out2,HYFD),    
        ( ( Out1 == true, Out2 == true ) -> 
        (
            $#==(HFD, H, true, Cout5, Cout),
            HFD #= HXFD - HYFD
        )
        ;Cout = Cout5 %,! 
         )
     );Cout = Cout5
    ).
%%  E :: Sonia


$*(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
%%  B :: Sonia
%    toSolver(H,Cout4,Cout).
    toSolver(H,Cout4,Cout5),
    {H = HX * HY},
    (proj_active -> 
    (
        searchVarsFD(HX,Cout5,Out1,HXFD),
        searchVarsFD(HY,Cout5,Out2,HYFD),
        ( (Out1 == true, Out2 == true ) ->  
        (
            $#==(HFD, H, true, Cout5, Cout),
            HFD #= HXFD * HYFD
        )
          ;Cout = Cout5 %,! 
         )
     );Cout = Cout5
    ).
%%   E :: Sonia


'$min'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
    {H = min(HX,HY)}.

'$max'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
    {H = max(HX,HY)}.


% funciones reales binarias

$/(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
%%  B :: Sonia
    toSolver(H,Cout4,Cout), 
%    {H = HX / HY},
    {H * HY = HX},
    (proj_active -> 
       (
        searchVarsFD(HX,Cout,Out1,HXFD),
        searchVarsFD(HY,Cout,Out2,HYFD),
        searchVarsFD(H,Cout,Out3,HFD),
        ((Out1 == true, Out2 == true, Out3 == true ) ->  HFD * HYFD #= HXFD ; true),!
       ); true
    ).

%%  E :: Sonia

'$**'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
    {H = exp(HX,HY)}.


'$log'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
    {HY = exp(HX,H)}.



% potencia con exponente natural

$^(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
    {HY >= 0}, % En otro caso, se podria sacar mensaje, e incluso abortar
    {H = exp(HX,HY)}.

'$div'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    number(HX),number(HY),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
%F20070207
%    H is float(HX // HY).
    H is HX // HY.

'$mod'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    number(HX),number(HY),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
%F20070207
%    H is float(HX mod HY).
    H is HX mod HY.

'$gcd'(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    number(HX),number(HY),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
    toSolver(H,Cout4,Cout),
%F20070207
%    H is float(gcd(HX,HY)).
    H is gcd(HX,HY).

'$round'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    number(HX),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
%F20070207
%    H is round(HX).
    H is integer(round(HX)).

'$trunc'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    number(HX),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
%F20070207
%    H is float(integer(HX)).
    H is integer(HX).

'$floor'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    number(HX),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
%F20070207
%    H is floor(HX).
    H is integer(floor(HX)).

'$ceiling'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    number(HX),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
%F20070207
%    H is ceiling(HX).
    H is integer(ceiling(HX)).


%Conversion de enteros a reales

'$toReal'(X,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    number(HX),
    toSolver(HX,Cout1,Cout2),
    toSolver(H,Cout2,Cout),
    H=HX.


% Operadores relacionales.

$<(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
% Sonia %% B
%    toSolver(H,Cout4,Cout).
    toSolver(H,Cout4,Cout),
    (H=true,{HX<HY};H=false,{HX>=HY}),
    (proj_active -> 
    (
        searchVarsFD(HX,Cout,Out1,HXFD), 
        searchVarsFD(HY,Cout,Out2,HYFD),
        'proj_<'(Out1,Out2,H, HXFD, HYFD)
%          (   
%          (Out1 == true, Out2 == true, H == true,!, HXFD #< HYFD);
%          (Out1 == true, Out2 == true, H == false,!, HXFD #>= HYFD);
%          (Out1 == true, Out2 == false, H == true,!, HXFD #=< HYFD);
%          (Out1 == true, Out2 == false, H == false,!, HXFD #> HYFD);
%          (Out1 == false, Out2 == true, H == true,!, HXFD #< HYFD);
%          (Out1 == false, Out2 == true, H == false,!, HXFD #>= HYFD);
%          !
%           )
     )  
    ;true).

'proj_<'(true,true,true, HXFD, HYFD) :- !,HXFD #< HYFD.
'proj_<'(true,true,false, HXFD, HYFD) :- !,HXFD #>= HYFD.
'proj_<'(true,false,true, HXFD, HYFD) :- !,HXFD #=< HYFD.
'proj_<'(true,false,false, HXFD, HYFD) :- !,HXFD #> HYFD.
'proj_<'(false,true,true, HXFD, HYFD) :- !,HXFD #< HYFD.
'proj_<'(false,true,false, HXFD, HYFD) :- !,HXFD #>= HYFD.
'proj_<'(_,_,_,_,_) :- !,true.

% Sonia %% E


$>(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
% Sonia %% B
%    toSolver(H,Cout4,Cout).
    toSolver(H,Cout4,Cout),
    (H=true,{HX>HY};H=false,{HX=<HY}),
    (proj_active -> 
    (
        searchVarsFD(HX,Cout,Out1,HXFD), 
        searchVarsFD(HY,Cout,Out2,HYFD),
        'proj_>'(Out1,Out2,H, HXFD, HYFD)
%          (
%          (Out1 == true, Out2 == true, H == true,!, HXFD #> HYFD);
%          (Out1 == true, Out2 == true, H == false,!, HXFD #=< HYFD);
%          (Out1 == true, Out2 == false, H == true,!, HXFD #> HYFD);
%          (Out1 == true, Out2 == false, H == false,!, HXFD #=< HYFD);
%          (Out1 == false, Out2 == true, H == true,!, HXFD #>= HYFD);
%          (Out1 == false, Out2 == true, H == false,!, HXFD #< HYFD);
%          !
%           )
     )  
    ;true).

'proj_>'( true, true, true, HXFD, HYFD) :- !, HXFD #> HYFD.
'proj_>'( true, true, false, HXFD, HYFD) :- !, HXFD #=< HYFD.
'proj_>'( true, false, true, HXFD, HYFD) :- !, HXFD #> HYFD.
'proj_>'( true, false, false, HXFD, HYFD) :- !, HXFD #=< HYFD.
'proj_>'( false, true, true, HXFD, HYFD) :- !, HXFD #>= HYFD.
'proj_>'( false, true, false, HXFD, HYFD) :- !, HXFD #< HYFD.
'proj_>'(_,_,_,_,_) :- !, true.


% Sonia %% E


$<=(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
% Sonia %% B
%    toSolver(H,Cout4,Cout).
    toSolver(H,Cout4,Cout),
    (H=true,{HX=<HY};H=false,{HX>HY}),
    (proj_active -> 
    (
        searchVarsFD(HX,Cout,Out1,HXFD), 
        searchVarsFD(HY,Cout,Out2,HYFD),
        'proj_<='(Out1,Out2,H, HXFD, HYFD)
%          (
%          (Out1 == true, Out2 == true, H == true,!, HXFD #=< HYFD);
%          (Out1 == true, Out2 == true, H == false,!, HXFD #> HYFD);
%          (Out1 == true, Out2 == false, H == true,!, HXFD #=< HYFD);
%          (Out1 == true, Out2 == false, H == false,!, HXFD #> HYFD);
%          (Out1 == false, Out2 == true, H == true,!, HXFD #=< HYFD);
%          (Out1 == false, Out2 == true, H == false,!, HXFD #>= HYFD);
%          !
%           )
     )  
    ;true).

'proj_<='(true,true,true, HXFD, HYFD) :- !, HXFD #=< HYFD.
'proj_<='(true,true,false, HXFD, HYFD) :- !, HXFD #> HYFD.
'proj_<='(true,false,true, HXFD, HYFD) :- !, HXFD #=< HYFD.
'proj_<='(true,false,false, HXFD, HYFD) :- !, HXFD #> HYFD.
'proj_<='(false,true,true, HXFD, HYFD) :- !, HXFD #=< HYFD.
'proj_<='(false,true,false, HXFD, HYFD) :- !, HXFD #>= HYFD.
'proj_<='(_,_,_,_,_) :- !, true.

% Sonia %% E


$>=(X,Y,H,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    hnf(Y,HY,Cout1,Cout2),
    toSolver(HX,Cout2,Cout3),
    toSolver(HY,Cout3,Cout4),
% Sonia %% B
%    toSolver(H,Cout4,Cout).
    toSolver(H,Cout4,Cout),
    (H=true,{HX>=HY};H=false,{HX<HY}),
    (proj_active -> 
    (
        searchVarsFD(HX,Cout,Out1,HXFD), 
        searchVarsFD(HY,Cout,Out2,HYFD),
        'proj_>='(Out1,Out2,H, HXFD, HYFD)
%          (
%          (Out1 == true, Out2 == true, H == true,!, HXFD #>= HYFD);
%          (Out1 == true, Out2 == true, H == false,!, HXFD #< HYFD);
%          (Out1 == true, Out2 == false, H == true,!, HXFD #> HYFD);
%          (Out1 == true, Out2 == false, H == false,!, HXFD #=< HYFD);
%          (Out1 == false, Out2 == true, H == true,!, HXFD #>= HYFD);
%          (Out1 == false, Out2 == true, H == false,!, HXFD #< HYFD);
%          !
%           )
     )  
    ;true).

'proj_>='(true,true,true, HXFD, HYFD) :- !, HXFD #>= HYFD.
'proj_>='(true,true,false, HXFD, HYFD) :- !, HXFD #< HYFD.
'proj_>='(true,false,true, HXFD, HYFD) :- !, HXFD #> HYFD.
'proj_>='(true,false,false, HXFD, HYFD) :- !, HXFD #=< HYFD.
'proj_>='(false,true,true, HXFD, HYFD) :- !, HXFD #>= HYFD.
'proj_>='(false,true,false, HXFD, HYFD) :- !, HXFD #< HYFD.
'proj_>='(_,_,_,_,_) :- !, true.

% Sonia %% E


%%::B 16/06/2006 Fernando. Optimization
'$minimize'(X,I,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    (inf(HX,I) ->
     toSolver(HX,Cout1,Cout) ;
     raise_exception(system_error('Non-linear constraints or unbounded problem.'))).

'$maximize'(X,I,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    (sup(HX,I) ->
     toSolver(HX,Cout1,Cout) ;
     raise_exception(system_error('Non-linear constraints or unbounded problem.'))).

'$bb_minimize'(X,Is,I,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    nf(Is,HIs,Cout1,Cout2),
    toyListToPrologList(HIs,PHIs),
    (bb_inf(PHIs,HX,I,PHIs,0.001) ->
     (toSolver(HX,Cout2,Cout3),
      toSolver(HIs,Cout3,Cout)) ;
     raise_exception(system_error('Unbounded problem.'))).

'$bb_maximize'(X,Is,I,Cin,Cout):-
    hnf(X,HX,Cin,Cout1),
    nf(Is,HIs,Cout1,Cout2),
    toyListToPrologList(HIs,PHIs),
    (bb_inf(PHIs,-HX,-I,PHIs,0.001) ->
     (toSolver(HX,Cout2,Cout3),
      toSolver(HIs,Cout3,Cout)) ;
     raise_exception(system_error('Unbounded problem.'))).
%%::E 16/06/2006 Fernando. Optimization



% 10/07/00 mercedes (se necesitan para la libreria de tcltk y son utiles para
% muchas otras cosas)
'$ord'(C,H,Cin,Cout):-
    hnf(C,'$char'(H),Cin,Cout).
    
'$chr'(N,H,Cin,Cout):-
    hnf(N,HN1,Cin,Cout1),
    HN is integer(HN1),
    hnf(H,'$char'(HN),Cin,Cout).
    



/*****************************   E/S    *************************************/
% 26/04/00 mercedes

% operaciones basicas

'$putChar'(A,'$io'(unit),Cin,Cout):-
    hnf(A,'$char'(HA),Cin,Cout),
    %unifyHnfs(A,'$char'(HA),Cin,Cout),
    put(HA),
    flush_output.
    

'$done'('$io'(unit),Cin,Cin).



'$getChar'('$io'('$char'(C)),Cin,Cin):- get0(C).


'$return'(V,'$io'(V),Cin,Cin).


% secuencializadores

$>>(A,B,H,Cin,Cout):-
    hnf(A,HA,Cin,Cout1),
    hnf(B,H,Cout1,Cout).
    
    
$>>=(A,B,H,Cin,Cout):-
    hnf(A,'$io'(L),Cin,Cout1),
    '$aplica'(B,L,H,Cout1,Cout).
    
'$aplica'(A,B,H,Cin,Cout):- 
    B\==unit,!,
    A=..[F|Args],
    %Args=[Args1],
    append(Args,[B],NArgs),
    A1=..[F|NArgs],
    introduceSusp(A1,H1,execution),
    hnf(H1,H,Cin,Cout).
    
'$aplica'(A,B,H,Cin,Cout):- hnf(A,H,Cin,Cout).


% operaciones adicionales

'$putStr'(Cs,H,Cin,Cout):- 
    hnf(Cs,HCs,Cin,Cout1),
    '$putStr_1'(HCs,H,Cout1,Cout).
    

'$putStr_1'([],'$io'(unit),Cin,Cin).

'$putStr_1'(C:Cs,H,Cin,Cout):-
    introduceSusp(putChar(C),H1,execution),
    introduceSusp(putStr(Cs),H2,execution),
    $>>(H1,H2,H,Cin,Cout).
    
    
'$putStrLn'(Cs,H,Cin,Cout):-
    introduceSusp(putStr(Cs),H1,execution),
    introduceSusp(putChar('$char'(10)),H2,execution),  % 10 = '\n'
    $>>=(H1,H2,H,Cin,Cout).

    
'$getLine'(H,Cin,Cout):-
    introduceSusp(getChar,H1,execution),
    %introduceSusp(cont1,H2,execution),  
    $>>=(H1,cont1,H,Cin,Cout).

'$cont1'(C,'$io'([]),Cin,Cin):- C=='$char'(10),!.  % 10 = '\n'

'$cont1'(C,H,Cin,Cout):-
    introduceSusp(getLine,H1,execution),
    %introduceSusp(cont2(C),H2,execution),  
    $>>=(H1,cont2(C),H,Cin,Cout).

'$cont2'(C,Cs,'$io'(':'(C,Cs)),Cin,Cin).


% operaciones de ficheros

'$writeFile'(NF,Str,H,Cin,Cout):-
    nf(NF,Name_File1,Cin,Cout1),!,
    '$trans'(Name_File1,[],Name_File),
    name(Name,Name_File),
    '$control_open'(Name,Cout1,Cout2),
    open(Name,write,FD),
    '$add_control'(Name,write,FD,Cout2,Cout3),
    hnf(Str,HStr,Cout3,Cout4),!,
    '$write_in_file'(HStr,FD,H,Cout4,Cout).
    
'$trans'([],X,X):-!.
'$trans'('$char'(A):R,I,O):- 
    append(I,[A],I1),
    '$trans'(R,I1,O).


    
'$write_in_file'([],FD,'$io'(unit),Cin,Cout):- close(FD),'$remove_control'(FD,Cin,Cout).

'$write_in_file'(':'(C,Cs),FD,H,Cin,Cout):-
    hnf(C,'$char'(HC),Cin,Cout1),!,
    put(FD,HC),
    hnf(Cs,HCs,Cout1,Cout2),
    '$write_in_file'(HCs,FD,H,Cout2,Cout).
    
'$control_open'(Name,Cin,Cin):- file(Name,_,_),!,treat_error(36,Name),fail.
'$control_open'(Name,Cin,Cin).

'$add_control'(Name,Mode,Handle,Cin,Cin):- assertfile(Name,Mode,Handle).
    
'$remove_control'(Handle,Cin,Cin):- retractfile(N,M,Handle).


'$readFile'(NF,'$io'(readFileContents(FD)),Cin,Cout):-
    nf(NF,Str1,Cin,Cout1),!,
    '$trans'(Str1,[],Str),
    name(Name,Str),
    '$control_open'(Name,Cout1,Cout2),
    open(Name,read,FD),
    '$add_control'(Name,read,FD,Cout2,Cout).


'$readFileContents'(FD,L,Cin,Cout):-
    get0(FD,C),
    (
     C== -1,!,
     L=[], 
     close(FD),
     '$remove_control'(FD,Cin,Cout)
    ;
     '$readFileContents'(FD,L1,Cin,Cout),
     L=':'('$char'(C),L1)
    ).


/*****************************************************************************/



/* PROBAR ESTAS DEFINICIONES ALTERNATIVAS DE LOS OPERADORES RELACIONALES !!!!

primitiveFunct(<, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
$<(X,Y,H):-
    H==true,
    !,
    {HX<HY},
    hnf(X,HX),
    hnf(Y,HY).

$<(X,Y,H):-
    H==false,
    !,
    {HX>=HY},
    hnf(X,HX),
    hnf(Y,HY).

$<(X,Y,H):-
    hnf(X,HX),
    hnf(Y,HY),
    (H=true,{HX<HY};H=false,{HX=>HY}).




primitiveFunct(>, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
$>(X,Y,H):-
    H==true,
    !,
    {HX>HY},
    hnf(X,HX),
    hnf(Y,HY).

$>(X,Y,H):-
    H==false,
    !,
    {HX=<HY},
    hnf(X,HX),
    hnf(Y,HY).

$>(X,Y,H):-
    hnf(X,HX),
    hnf(Y,HY),
    (H=true,{HX>HY};H=false,{HX=<HY}).



primitiveFunct(=<, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
$=<(X,Y,H):-
    H==true,
    !,
    {HX=<HY},
    hnf(X,HX),
    hnf(Y,HY).

$=<(X,Y,H):-
    H==false,
    !,
    {HX>HY},
    hnf(X,HX),
    hnf(Y,HY).

$=<(X,Y,H):-
    hnf(X,HX),
    hnf(Y,HY),
    (H=true,{HX=<HY};H=false,{HX>HY}).



primitiveFunct(>=, 2, 2, ('$num'(A) -> ('$num'(A) -> bool)), bool).
$>=(X,Y,H):-
    H==true,
    !,
    {HX>=HY},
    hnf(X,HX),
    hnf(Y,HY).

$>=(X,Y,H):-
    H==false,
    !,
    {HX<HY},
    hnf(X,HX),
    hnf(Y,HY).

$>=(X,Y,H):-
    hnf(X,HX),
    hnf(Y,HY),
    (H=true,{HX>=HY};H=false,{HX<HY}).





*/


% rafa 24-11-03
% primitivas para where y para depuraci�n

/*****************************************************************************/


% Depu 10/10/00 mercedes
% 09/08/01 rafa cambiado el nombre a dVal

'$dValToString'(A,C,Cin,Cin):-atomToString(varToString,A,C).

% 22-09-03 Ahora dVal funciona de diferente manera seg�n si estamos usando el dep. topdown o DDT
% 17-12-03 Vuelve a funcionar igual en ambos casos
'$dVal'(A,C,Cin,Cin):- %(ddtFlag,
                    !,
                    dValProlog(A,C).
                    %;
                    %atomToPVal(varToString,A,C)
                    %).

%-----------------------------------------------------------------------------------------------------------
% '$getConstraintStore'(+[A],-Constraint,+Cin,-COut)
% returns in Constraint the constrain Store as a Toy value of type "constraint"
% the list [A] contains pairs of the form (NameVar, PrologVar) with the names 
% of the variables which must be kept 
'$getConstraintStore'(ListVars,constraint(List),Cin,Cin) :-
            % unify the format
          formatConstraint(Cin,[],Cin2),
          eliminateRepetitions(Cin2,Cin3),
          separateReals(Cin3,Reals,Cin4),
          getNames(Reals,RealNames),
          dump(Reals,RealNames,RealConstraints),
          generateAtomicConstraints(Cin4,List1),
          generateRealConstraints(RealConstraints,List1,List).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
separateReals([],[],[]) :- 
    !.
separateReals([real(A)|As],[A|Reals],Rest) :- 
    var(A),
    !,
    separateReals(As,Reals,Rest).
separateReals([real(A)|As],[Reals],Rest) :- 
    !,
    separateReals(As,Reals,Rest).
separateReals([A|As],[Reals],[A|Rest]) :- 
    !,
    separateReals(As,Reals,Rest).

% genrate a name of atom for each variable
getNames([],[]).
getNames([X|Xs],[Y|Ys]) :-
  !,
  variableName(X,NY),
  name(Y,NY),
  getNames(Xs,Ys).

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eliminateRepetitions([],[]).
eliminateRepetitions([X|Xs],Ys) :- 
    member(X,Xs),
    !,
    eliminateRepetitions(Xs,Ys).
eliminateRepetitions([X|Xs],[X|Ys]) :- 
    !,
    eliminateRepetitions(Xs,Ys).


% formatConstraint
formatConstraint([],Ac,Ac).
formatConstraint([A|R],Ac,Res) :-
  addConstraints(A,Ac,Ac2),
  formatConstraint(R,Ac2,Res).

addConstraints(A:[],Ac,Ac).
addConstraints(A:[B|C],Ac,[neq(A,B)|R1]) :-
   !,
   addConstraints(A:C,Ac,R1).
addConstraints(A,Ac,[A|Ac]) :-
   !.

% generateAtomicConstraints(+L,-C)
% Given L = [t1,...,tn] stores in C the list
% ':'(atomicConstraint "seq" [Var, t1'] ->false,':'(...,':'(atomicConstraint "seq" [Var tn'] -> false,[])...)
% where t1',...,tn' are the pVal representations of t1
generateAtomicConstraints([],[]).
generateAtomicConstraints([neq(V,Term)|RestTerms],':'(AC,RC)):-
 !,
  atomToPVal(varToString,V,Var),
  atomToPVal(varToString,Term,PValTerm),
  AC=atomicConstraint(:('$char'(115), :('$char'(101), :('$char'(113), []))), % seq
                                          :(Var,:(PValTerm, [])),  % [Var,PValTerm]
                       pValApp(:('$char'(102), :('$char'(97), :('$char'(108), :('$char'(115), :('$char'(101), []))))), []) %false
                    ),
 generateAtomicConstraints(RestTerms,RC).

generateAtomicConstraints([tot(V)|RestTerms],':'(AC,RC)):-
 !,
 atomToPVal(varToString,V,Var),
 AC=atomicConstraint(:('$char'(116), :('$char'(111), :('$char'(116), []))), % tot
                                          :(Var, []),  % [Var]
                       pValApp(:('$char'(116), :('$char'(114), :('$char'(117),  :('$char'(101), [])))), []) %true
                    ),
 generateAtomicConstraints(RestTerms,RC).



generateRealConstraints([],L,L).
generateRealConstraints([X|Xs],LI,L) :-
    transformRealConstraint(X,Y),
    generateRealConstraints(Xs,':'(Y,LI),L).    

/*
transformRealConstraint(C,atomicConstraint(F,':'(Var,Args),T)) :-
        T =  pValApp(:('$char'(116), :('$char'(114), :('$char'(117),  :('$char'(101), [])))), []),
        C =.. [FName,FVar|FArgs],
        atomToPVal(varToString,FName,pValApp(F,[])),
        atomToPVal(varToString,FVar,pValApp(Var,[])),
        atomToPVal(varToString,FArgs,Args).
*/        
transformRealConstraint(C,atomicConstraint(F,_,T)) :-
        T =  pValApp(:('$char'(116), :('$char'(114), :('$char'(117),  :('$char'(101), [])))), []),
        name(NameFile,"const.txt"),
        open(NameFile,write,H), % abrimos para escritura el fichero
        write(H,C),
        close(H),
        open(NameFile,read,H), % abrimos para escritura el fichero
        read_line(H,F).


% Rafa: 01/02/06 selectwherevariable no estaba en el fichero
% Depu 16/11/00 mercedes
'$selectWhereVariableXi'(Name,IFloat,NFloat,X,Xi,Cin,Cout) :-
    % El num. de arg. (IFloat) y el total de argumentos (NFloat) nos
    % llegan como float con decimal .0. Los convertimos a enteros para
    % que funcionen functor, args,...
    I is integer(IFloat),
    N is integer(NFloat),
    functor(Pattern,Name,N),
    % transformar el patron si es una tupla
    transformTup(Pattern,Pattern1),
        hnf(X,Pattern1,Cin,Cout1),  
     arg(I,Pattern,Result), 
     hnf(Result,Xi,Cout1,Cout).
    

% transforma los patrones de tipo tupla
% si el patron no es una tupla no lo cambia 
transformTup(Pattern,PatternOut) :-
    Pattern =.. ['$$tup'|Args],
    !,
    argsToTup(Args,ArgsOut),
    PatternOut =.. ['$$tup'|[ArgsOut]].

transformTup(Pattern,Pattern) :- 
    !.
    

argsToTup([Arg],Arg) :-
    !.

argsToTup([HArg|RArgs],(HArg,TRArgs)) :-
    !,
    argsToTup(RArgs,TRArgs).

    


% Fin Depu


/*** %{paco} 28-11-96
%{paco}  22-11-96
% chapuzilla para escribir alguna cosilla
primitiveFunct(write,1,1,(A -> bool),bool).
'$write'(true,Cin,Cout,X) :-
        hnf(X,HX,Cin,Cout),
        write(HX).
primitiveFunct(nl,0,0,bool,bool).
'$nl'(true,Cin,Cin) :- nl.
 primitiveFunct(put,1,1,('$num'(int) -> bool),bool).
'$put'(true,Cin,Cout,X) :-
        hnf(X,HX,Cin,Cout),
        put(HX).
****/



/**********************  FALLO FINITO Y CORTE ********************************/
% jaime 24-01-2006
'$fails'(X,H,Cin,Cin):-
     \+ hnf(X,_,Cin,Cout) -> H=true ; H=false.

'$once'(X,H,Cin,Cout):-
     hnf(X,H,Cin,Cout),!.



'$collect'(X,L2,Cin,Cin):-
    findall(H,nf(X,H,Cin,_),L1),    % jaime 23-1-2004
        convert(L1,L2).


'$collectN'(N,X,L2,Cin,Cout):-
        hnf(N, HN, Cin, Cout),
    findN(HN,X,nf(X,H,Cin,_),L1),   % jaime 23-1-2004
        convert(L1,L2).



% convierte lista prolog a lista toy (constructor '.' a constructor ':')
convert([],[]).
convert([X|Xs],:(X,Xs1)):- convert(Xs,Xs1).


% pereza??.... no es trivial -> mirar eficiencia
findN(N,X,G,L):-
        (
          N==0,!,L=[]
        ;
          retractall(res(_)), retractall(cont(_)), 
          assert(cont(0)), !,       
          (findNAux(N,X,G),!; true),
          findall(Y,res(Y),L)
        ).


findNAux(N,X,G):-
        call(G), cont(C),
        C1 is C+1, (C1>N,!; retractall(cont(_)), assert(cont(C1)), assert(res(X)), fail).

/**********************  FIN FALLO FINITO Y CORTE ****************************/


/* LISTS */
% 16062006 Fernando
%% Translates a Toy list (such as 1:2:3:[]) into a Prolog list ([1, 2, 3])
toyListToPrologList(Ts, Ps) :- (var(Ts), var(Ps) -> true; toyNonVarListToPrologList(Ts, Ps)).

toyNonVarListToPrologList([], []) :- !.
toyNonVarListToPrologList(A:R, [A|RR]) :- toyNonVarListToPrologList(R, RR).
