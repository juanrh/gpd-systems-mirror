%----------------------------------------------------------------------------%
% goals.pl
%----------------------------------------------------------------------------%
/*
- Author: Jaime
- Fecha: 30/05/97
- Description: Este modulo contiene todo el proceso de muestra de respuestas 
  (i.e., dar las soluciones de los objetivos). 
- Modules which import it: initToy
- Imported modules:
    > tools (with 'smooth', 'member').
    > dyn
    > writing (with 'writeAtom/3', 'searchInsertVar').
    
- Modified: 30/09/99 mercedes (Se han comentado los predicados).
                  06/10/99 mercedes (Separacion de las restricciones sobre
                                         reales del nucleo).
                      26/10/99 mercedes (modularizacion).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




:-
module(goals,[writeFail/0,writeSolution/3,askIfMore/4,eliminateSweepings/1, writeStatistics/11, writeStatistics/0]).


%B Sonia
:- load_files(tools,[if(changed),imports([member/2])]).
:- load_files(tools,[if(changed),imports([insertLst/3])]).
%E Sonia


:- load_files(toycomm, [if(changed),imports([cleanTotCtrStore/2,testEq/2]) ]).

:- load_files(dyn,[if(changed)]).

:- load_files(writing,[if(changed),imports([writeAtom/3,searchInsertVar/3])]).

:- load_files(transdebug,[if(changed),imports([startDebuggingProcess/4])]).

% :- load_files(initToy,[if(changed),imports([throwConstraints/1])]).

:- load_files(errortoy,[if(changed),imports([name_of_variable/2])]).

:- use_module(library(terms)). % term_variables

:- use_module(library(clpr)).
   
:- use_module(library(lists)).
   
%%::B
:- use_module(library(clpfd)).
%%::E



%-----------------------------------------------------------------------------%
% askIfMore(+Goal,+Vars,+FileStr,+Cout)
% Depu 02/11/00 mercedes
% ahora se introducen el Goal, el Vars  y el FileStr que se necesitan para
% la depuracion.
% Depu 30/05/05 a�ado Cout para la depuraci�n
% Fin Depu
% Pregunta al usuario si quiere que le muestre mas soluciones del objetivo,
% o si quiere que entre en modo depuracion.
%-----------------------------------------------------------------------------%

askIfMore(Goal,Vars,FileStr,Cout):-
%    nl,
% F:19/02/2006
    getNAnswer(N),
    (N==1 -> (retract(allAnswers); true); true),
    write('sol.'), write(N), write(', '),
    write('more solutions (y/n/d/a) [y]? '),
    ((N>0, retract(allAnswers)) ->
     (  nl,
        assert(allAnswers),
        eliminateSweepings(10),
        createRunTimeStatistics,
        !,
        fail)
    ;
    (
%FSP 21/06/2007 flush_output added for ACIDE    
    flush_output,get0(Op),
    (
        (Op==121;Op==10),   % 10 = intro, 121= 'y'
        eliminateSweepings(Op),
        createRunTimeStatistics,
        !,
        fail
    ;
        Op==97,   % 97 = 'a' All answers
        eliminateSweepings(Op),
        createRunTimeStatistics,
        assert(allAnswers),
        !,
        fail
    ;
        % Depu 03/11/00 mercedes
        Op==100,   % 100='d'
        eliminateSweepings(Op),
        % tenemos que buscar el objetivo, junto con su respuesta
        startDebuggingProcess(Goal,Vars,FileStr,Cout)
        % Fin Depu
    ;
        eliminateSweepings(Op)
    )
    )
    ).      



    
        
%-----------------------------------------------------------------------------%
% Muestra por pantalla que ha habido error en la resolucion del objetivo.
%-----------------------------------------------------------------------------%

writeFail:-
%    nl,
    tab(6),write('no'),nl,
%    nl,
    writeStatistics.


%-----------------------------------------------------------------------------%
% writeSolution(+Vars,+Cout,+Residue): muestra por pantalla una solucion del
% objetivo.
%-----------------------------------------------------------------------------%

writeSolution(Vars,Cout,Residue):-
         finalRunTimeStatistics(Runtime,Hnfs,GlobalStack,LocalStack,
                                    Trails,Choices,Memory,Program,StackShifts,Atoms,Walltime),

    showAnswer(Vars,Cout,Residue),
%    nl,
        writeStatistics(Runtime,Hnfs,GlobalStack,LocalStack,
                                    Trails,Choices,Memory,Program,StackShifts,Atoms,Walltime).

writeStatistics :-
    !,
         finalRunTimeStatistics(Runtime,Hnfs,GlobalStack,LocalStack,
                                    Trails,Choices,Memory,Program,StackShifts,Atoms,Walltime),
        writeStatistics(Runtime,Hnfs,GlobalStack,LocalStack,
                                    Trails,Choices,Memory,Program,StackShifts,Atoms,Walltime).

writeStatistics(_Runtime,_Hnfs,_GlobalStack,_LocalStack,
                                    _Trails,_Choices,_Memory,_Program,_StackShifts,_Atoms,_Walltime) :-
                          getRunTimeStatisticsLevel(0),
                          !.

writeStatistics(Runtime,_Hnfs,_GlobalStack,_LocalStack,
                                    _Trails,_Choices,_Memory,_Program,_StackShifts,_Atoms,_Walltime) :-
                         getRunTimeStatisticsLevel(1),
                          !,
              writeTime(Runtime),nl.

writeStatistics(Runtime,Hnfs,GlobalStack,LocalStack,
                                    Trails,Choices,Memory,Program,StackShifts,Atoms,Walltime) :-
                           getRunTimeStatisticsLevel(2),
                          !,
              tab(6),write('Elapsed time: '),write(Runtime),write(' ms.'),nl,nl,
              tab(6),write(Hnfs),write(' hnfs computed.'),nl,nl.

writeStatistics(Runtime,Hnfs,GlobalStack,LocalStack,
                                    Trails,Choices,Memory,Program,StackShifts,Atoms,Walltime) :-
                           getRunTimeStatisticsLevel(3),
                          !,
              tab(6),write('Elapsed time: '),write(Runtime),write(' ms.'),nl,nl,
              tab(6),write(Hnfs),write(' hnfs computed.'),nl,
              tab(6),write('Maximun global stack used: '),write(GlobalStack),write(' bytes.'),nl,
            % tab(6),write('Maximun local stack used: '),write(GlobalStack),write(' bytes.'),nl,
            %  tab(6),write('Maximun number of atoms: '),write(Atoms),write('.'),nl,
              tab(6),write('Maximun number of Prolog choice points: '),write(Choices),write('.'),nl,
             % tab(6),write('Maximun number of trails: '),write(Trails),write('.'),nl,
             % tab(6),write('Maximun number of stack-shifts: '),write(StackShifts),write('.'),nl,
              tab(6),write('Maximun program memory required: '),write(Program),write(' bytes.'),nl,nl.
             % tab(6),write('Maximun Prolog memory required: '),write(Memory),write(' bytes.'),nl,
              % tab(6),write('Total time: '),write(Walltime),write(' ms.'),nl,nl.


writeTime(Runtime) :-
                    tab(6),write('Elapsed time: '),write(Runtime),write(' ms.')
%,nl.
.

%-----------------------------------------------------------------------------%
% eliminateSweepings(+Op)
% eliminateSweepings se encarga de tirar todos los caracteres que haya podido 
% meter el usuario cuando le preguntamos si quiere mas soluciones. Una vez 
% reconocida la respuesta despreciamos todo lo que aparece hasta el retorno de 
% carro.
% Esto es necesario porque si no estos caracteres podrian llegarle a Rafa o
% a mi mismo despues.
%-----------------------------------------------------------------------------%

eliminateSweepings(10):-!.
eliminateSweepings(_):-
    get0(Swe),
    eliminateSweepings(Swe).




/*****************************************************************************/
/*                  SALIDA DE SOLUCIONES                     */
/*****************************************************************************/

/* La salida de la solucion se hace asi (se intenta minimizar, esto es no 
introducir nuevas variables que no sean estrictamente necesarias para dar la 
respuesta): primero mostramos todas las igualdades entre variables del objetivo,
respetando los nombres que les dio el usuario. Luego sacamos en pantalla las 
igualdades entre las vars del objetivo los terminos construidos a los que se han 
ligado. Notese que una variable no puede ligarse simultaneamente a otra variable
y a un termino construido, por lo que los dos casos anteriores son disjuntos. 
Si una variable no se ha ligado durante la ejecucion del objetivo a otra 
variable del objetivo ni a un termino construido de momento no hemos sacado 
ninguna informacion sobre ella. 
Por ultimo sacamos las restricciones de desigualdad.
Para ello primero extraemos las variables relevantes: las que aparecen en el 
objetivo mas las que aparecen en restricciones no lineales sobre los reales. */


%-----------------------------------------------------------------------------%
% showAnswer(+Vars,+Cout,+Residue)
% En vars esta la lista de variables del objetivo con los nombres de usuario y
% en Residue esta todo el residuo que ha quedado tras la computacion:
% desigualdades entre variables y restricciones sobre los reales.
%-----------------------------------------------------------------------------%


%B Sonia  Hacemos el cierre transitivo de las restricciones con respecto
%  a las variables del objetivo


showAnswer(Vars,Cout,Residue):-
%   !,
    term_variables(Vars,ListVarsGoal),
    divideResidue(Residue,[]/Residue1,[]/Residue2,[]/Residue3),
    transitiveClosure(Vars,ListVarsGoal,Cout,Residue1,Residue2,Residue3).   

transitiveClosure(Vars,ListVarsGoal,Cout,Residue1,Residue2,Residue3):-
%   !,
    closure(ListVarsGoal/Vars1,Cout),
    closure(Vars1/Vars2,Residue1),
    closure(Vars2/Vars3,Residue2),
    closure(Vars3/Vars4,Residue3),    % Var4 contiene todas las var del cierre transitivo
    (same_length(ListVarsGoal,Vars4)-> 
       (
        removeConstraints(Vars4,Cout,[]/Cout1),
        removeConstraints(Vars4,Residue1,[]/Residue11),
        removeConstraints(Vars4,Residue2,[]/Residue22),
        removeConstraints(Vars4,Residue3,[]/Residue33),
        showAnswer1(Vars,Cout1,Residue11,clpr(Residue22),Residue33)
       );
        transitiveClosure(Vars,Vars4,Cout,Residue1,Residue2,Residue3)       
    ).


%showAnswer(Vars,Cout,Residue):-

showAnswer1(Vars,Cout,Residue1,Residue2,Residue3):-
%E Sonia
    current_output(Handle),     % necesitamos el handle de la salida
                    % donde queremos escribir porque escribe
                    % atomo funciona asi.

    % igualdades entre vars del objetivo. En L llevamos cuenta de las vars
    % aparecidas hasta el momento con sus nombres para posteriores 
    % apariciones
%    nl,
    showVars(Vars,[]/Terms,[]/L,0/N1),
    %nl,
    % igualdades entre vars y terminos
    showTerms(Handle,Terms,L/L1,N1/N2),
    (N2==0 ; write(' } '),nl),
    % residuo
%SONIA 271005::B 
%    showConstraints(Handle,Vars,Cout,Residue,L1/L2,0/N3),

%nl, write('Residue1: '), write(Residue1),
%nl, write('Residue2: '), write(Residue2),
%nl, write('Residue3: '), write(Residue3), nl,
       showBridge(Cout,L1/L2,0/N3),
       showConstraints(Handle,Vars,Cout,Residue2,L2/L3,N3/N31), 
       showConstraintsFD(Residue1,Cout,L3/L4,N31/N32),
       showIntervalsIfNeeded(Residue3,Cout,L4/L5,N32/N4),

%SONIA 271005::E

      (N4==0; write(' }'),nl),
      (N2==0,N3==0,N4==0,tab(6),write('yes'),nl; true).




% B Sonia

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  closure(Vars/Vars1,L) Vars1 el la clausura transitiva de las variables 
%  de la lista Vars1 teniendo en cuenta las restricciones que existen en L
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


   closure(Vars/Vars1,L):-
    closure1(Vars,L,Vars1).

   closure1(ListVarsGoal,L,Vars2):-
    closure2(ListVarsGoal,L,Vars1),
    (same_length(ListVarsGoal,Vars1)-> Vars2=Vars1;
                closure1(Vars1,L,Vars2)
    ).

   closure2(L,[],L).

   closure2(ListVarsGoal,clpr(R),L):-
       closure2(ListVarsGoal,R,L).

   closure2(ListVarsGoal,[H|R],L):-
    term_variables(H,ListVarsConst),
    containVars(ListVarsConst,ListVarsGoal,Out),
    ((Out == true, insertAllVar(ListVarsConst,ListVarsGoal/L2),closure2(L2,R,L));
      closure2(ListVarsGoal,R,L)
    ).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  removeConstraints(ListVars,L,L1) L1 contiene todas las restricciones de L
%  que tienen alguna variable el Vars 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    removeConstraints(ListVars,[],L/L).

    removeConstraints(ListVars,clpr(H),L1/L2):-
        removeConstraints(ListVars,H,L1/L2).

    removeConstraints(ListVars,[H|R],L1/L2):-
    term_variables(H,ListVarsConst),
    containVars(ListVarsConst,ListVars,Out),
    ( (Out == true,removeConstraints(ListVars,R,[H|L1]/L2) )
      ; removeConstraints(ListVars,R,L1/L2) 
    ).
        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  insertAllVar(L,L1/L2) L2 es el resultado de a�adir a L1 todas las var de L
%  evitando repeticiones
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   insertAllVar([],L2/L2).

   insertAllVar([H1|R1],L1/L2):-
    insertLst(H1,L1,Laux),
    insertAllVar(R1,Laux/L2).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   containVars(L1,L2,Out) si alguna variable de L1 est� en L2 entonces Out es true
%   y si no Out es false 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   containVars([],L2,Out):-
    Out=false.

   containVars([H1|R1],L2,Out):-
    member(H1,L2),
    Out=true.

   containVars([H1|R1],L2,Out):-
    containVars(R1,L2,Out).

% E Sonia


%%%%%%%%%%%%%%%%% SALIDA DE IGUALDADES ENTRE VARIABLES %%%%%%%%%%%%%%%%%%

%-----------------------------------------------------------------------------%
% showVars([(Nombre,VarProlog).....],[(Nombre,TermConstruido)],Lin/Lout,Nin/Nout).
% Inicialmente Lin es []. Cuando aparece una variable simplemente la metemos 
% junto con su nombre en Lout. Cuando aparece otra variable (con otro nombre) 
% pero que es la misma variable prolog, sacamos una igualdad entre los nombres
% Ademas vamos construyendo una lista de variables ligadas a terminos para 
% sacarlas luego.
%-----------------------------------------------------------------------------%
showVars([],Terms/Terms,L/L,N/N).   
showVars([(Name,Val)|R],Terms/Terms1,L/L2,NI/NO):-
    var(Val),
    !,
    (
        isIn(Val,L,Name1),!,L1=L,showEqualityVars(Name1,Name,NI), NO1 is NI+1
        ;
    L1=[(Val,Name)|L], NO1 = NI
        ),
    showVars(R,Terms/Terms1,L1/L2,NO1/NO).

showVars([T|R],Terms/[T|Terms1],L/L1,NI/NO):-
    showVars(R,Terms/Terms1,L/L1,NI/NO).
    

%-----------------------------------------------------------------------------%
% isIn(+X,+Vars,-Name).
% Vars es una lista con elementos de la forma (Z,Name).
% isIn lo que hace es buscar (X,Name) en la lista Vars y devolver Name
%-----------------------------------------------------------------------------%

isIn(X,[(Y,Name)|R],Name1):-
    (X==Y,!,Name1=Name;
    isIn(X,R,Name1)).


%-----------------------------------------------------------------------------%
% showEqualityVars(+X,+Y): muestra por pantalla: X == Y
%-----------------------------------------------------------------------------%

showEqualityVars(X,Y,N):-
        ( N==0,  tab(6), write('{ ')
      ;
         write(','),  nl,tab(6), write('  ')
        ),
    write(Y),write(' -> '),write(X).



%%%%%%%%%%%%%%%% SALIDA DE IGUALDADES DE VARIABLES Y TERMINOS %%%%%%%%%%%%%%%%%


%-----------------------------------------------------------------------------%
% showTerms(+Handle,+Terms,+L/-L1,NI/NO)
% Salida de variables ligadas a terminos
%-----------------------------------------------------------------------------%

showTerms(_,[],L/L,N/N).
showTerms(Handle,[(Name,Val)|R],L/L2,NI/NO):-
       (NI==0, tab(6),write('{ ')
    ;
        write(', '), nl,tab(6), write('  ')
       ),
       write(Name),write(' -> '),
       writeAtom(Handle,L/L1,Val),
       NO1 is NI+1,
       showTerms(Handle,R,L1/L2,NO1/NO).




%-----------------------------------------------------------------------------%
% showConstraints(+Handle,+Vars,+Cout,+Residue,+L/-M,Nin/Nout)
% Las restricciones que hay que sacar son las desigualdades entre variables, 
% luego si estamos trabajando con el resolutor sacamos las restricciones sobre
% reales.
%-----------------------------------------------------------------------------%

showConstraints(Handle,Vars,Cout,noclpr,L/M,Nin/Nout):-
    term_variables(Vars,Rel),
    !,
    (
     getTot(on) -> showTot(Handle,Vars,Cout,Nin/Nout1)
    ; 
     Nout1 = Nin
    ), 
    showInequality(Handle,Rel,Cout,[],_,L/M,Nout1/Nout).


% esta clausula solo es util trabajando con el resolutor
showConstraints(Handle,Vars,Cout,clpr(Residue),L/M,Nin/Nout):-
    !,
    extractRelVarsClpr(Vars,Residue,Rel),
    eliminateSuperfluities(Cout,Cout1),
    (
     getTot(on) -> showTot(Handle,Vars,Cout,Nin/Nout1)
    ; 
     Nout1 = Nin
    ), 
    showInequality(Handle,Rel,Cout1,[],_,L/M1,Nout1/Nout2),
    showConstraClpr(Rel,Residue,M1/M,Nout2/Nout).
       



%%%%%%%%%%%%%%%%%%% SALIDA DE DESIGUALDADES SINTACTICAS %%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------------------------------%
% showInequality(+Handle,+Rel,+R,+Rin,-Rout,+L/-M,I/O)
% Rel es una lista de variables relevantes
% R es una lista con elementos de la forma X:CX donde X es una variable y CX es
% una lista con las desigualdades asociadas a X
% Rin es la lista de desigualdades que llevo hasta ahora, con elementos de la
% forma (X,Y) (hay una desigualdad entre X e Y)
% Rout es la nueva lista de desigualdades que se forma al sacar las desigualdades
% de cada elemento de R.
%-----------------------------------------------------------------------------%

showInequality(_,_,[],_,_,L/L,I/I).
showInequality(Handle,Rel,[X:CX|R],Rin,Rout,L/M,Nin/Nout):-
    (
        %var(X),
        isRelevant(X,Rel),
        !,
        showInequalityVar(Handle,Rel,X,CX,Rin,Rout1,L/M1,Nin/Nout1),
        showInequality(Handle,Rel,R,Rout1,Rout,M1/M,Nout1/Nout)
    ;
        showInequality(Handle,Rel,R,Rin,Rout,L/M,Nin/Nout)
    ).
showInequality(Handle,Rel,[Other|R],Rin,Rout,L/M,Nin/Nout):-
    !,
    showInequality(Handle,Rel,R,Rin,Rout,L/M,Nin/Nout).


%-----------------------------------------------------------------------------%
% showInequalityVar(+Handle,+Rel,+X,+CX,+Rin,-Rout,+L/-M,Nin/Nout)
% saca las desigualdades de la variable X, siendo CX la lista de desigualdades
% asociadas a X.
% Muestra por pantalla las desigualdades asociadas a la variable X
% Nin
%-----------------------------------------------------------------------------%

showInequalityVar(_,_,_,[],Rin,Rin,L/L,Nin/Nin).
showInequalityVar(Handle,Rel,X,[T|R],Rin,Rout,L/M,Nin/Nout):-
    (
        isRelevant(T,Rel),
        insertIneq(X,T,Rin,Rout1),
        !,
                % depende de si es la primera o no
                ( Nin==0, tab(6), write('{ ')
             ;
                 write(','),nl,tab(6), write('  ')
                ),
%        write(' '),
        writeAtom(Handle,L/M1,T),
        write(' /= '),
        writeAtom(Handle,M1/M2,X),
        Nout1 is Nin+1,
        showInequalityVar(Handle,Rel,X,R,Rout1,Rout,M2/M,Nout1/Nout)
    ;
        showInequalityVar(Handle,Rel,X,R,Rin,Rout,L/M,Nin/Nout)
    ).


%-----------------------------------------------------------------------------%
% insertIneq(+X,+T,+Rin,-Rout): inserta en la lista Rin, un par de la forma
% (X,T) o (T,X) segun sea X@<T o X@>T. Si ese par ya estaba en Rin, no hace
% nada.
%-----------------------------------------------------------------------------%

insertIneq(X,T,Rin,Rout):-
    X@<T,!,insertIneq1(X,T,Rin,Rout)
    ;
    insertIneq1(T,X,Rin,Rout).


%-----------------------------------------------------------------------------%
% insertIneq1(+X,+Y,+Rin,-Rout): inserta en la lista Rin, un par de la forma
% (X,Y) si es que este par no estaba ya en la lista. En otro caso, no hace nada
%-----------------------------------------------------------------------------%

insertIneq1(X,Y,[],[(X,Y)]).
insertIneq1(X,Y,[(A,B)|R],[(A,B)|R1]):-
    (A\==X;B\==Y),insertIneq1(X,Y,R,R1).



/****************************************************************************/
/*                     TOT CONSTRAINTS
/****************************************************************************/
showTot(H,Vars,C,Nin/Nout) :- 
     !,
     cleanTotCtrStore(C,C2),
     showAllCtr(H,Vars,C2,Nin,Nout),
     (Nin>0 %, nl(H)
      ;
     true).

showAllCtr(H,Vars,[],N,N) :- 
     !.
showAllCtr(H,Vars,[tot(X)|Rest],NI,NO) :-
     !,
     showAllCtrVar(H,X, Vars,NI,NO1),
     showAllCtr(H,Vars,Rest,NO1,NO).

showAllCtr(H,Vars,[_|Rest],NI,NO) :-
     showAllCtr(H,Vars,Rest,NI,NO).


showAllCtrVar(H,X,L,NI,NO) :-
    firstOccurrence(X,L,Name),
    !,
    writeTot(H,Name,NI),
    NO is NI+1.
 
writeTot(H,Name,0) :-
    !,
   tab(6),write('{ '),
%    nl(H),tab(H,6),
    writeTot2(H,Name).

writeTot(H,Name,_N) :-
   write(H,','), nl,tab(6), write('  '),
   writeTot2(H,Name).

writeTot2(H,Name) :-
    write(H,' tot('),
    write(H,Name),
    write(H,')').


% look for the first ocurrence of X in the list
firstOccurrence(X,[(Name,Y)|R],Name)  :-
     X==Y,
     !.

% if X is not Y we continue searching
firstOccurrence(X,[(Name,Y)|R],NameOut) :-
    !,
    firstOccurrence(X,R,NameOut).

    

/*****************************************************************************/
/*                  SALIDA DE RESTRICCIONES SOBRE LOS REALES             */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% Aqui hay un pequenio truco para sacar las restricciones asociadas a los reales
% Nosotros queremos que el sistema haga la proyeccion, que se hace con el dump
% pero en este momento no funcionaria directamente hacer un dump porque ya no
% hay objetivos suspendidos y el "almacen de restricciones" esta vacio. Lo que
% hacemos es relanzar al sistema el conjunto de restricciones sobre reales y
% hacer entonces el dump. Ademas, como queremos dejar el sistema limpio, este
% relanzamiento lo hacemos por medio de un call_residue.
%-----------------------------------------------------------------------------%


showConstraClpr(Relevants,Residue,L/M,Nin/Nout):-
% Sonia :: B
%    call_residue(throwResidueAgain(Relevants,Residue,L/M,Nin/Nout),_).
     showClpr(Residue,L/M,Nin/Nout).

     showClpr([],L/L,N/N).

     showClpr([{A}|R],L/M,NI/NO):-
    (NI==0, tab(6), write('{ ')
    ;   
    write(','), nl, tab(6), write('  ')),
    NO1 is NI+1,  %increment the counter of constraints displayed
      nameVarsTerm(A,VA,L/M),
    show(VA),
      showClpr(R,M/_,NO1/NO).

% Las restricciones de desigualdad que vienen del resolutor de reales tienen cambiado =/= 
% por \=, pero \= es un functor, para mostrarlo infijo lo tratamos expl�citamente

    show('/='(X,Y)):-
       write(X),write(' /= '), write(Y).
    show(VA):-
       write(VA).

% Sonia :: E



throwResidueAgain(Relevants,Residue,L/L2,Nin/Nout):-
    % relanzamos el residuo

    %080199
    % A PARTIR DE LA VERSION 3#6 DE SICTUS LOS RESIDUOS YA NO CONTIENEN ELEMENTOS 
    % EXTRANIOS Y SE PUEDE HACER UN CALL NORMAL DEL RESIDUO
    %map_call(Residue),
    
    throwConstraintsAgain(Residue),
    
    % hacemos una lista con los nombres asociados a las vars relevantes para
    % el propio dump de nombre a dichas variables
    doListNamesVarsRel(Relevants,NameRel,L/L1),
 

    %080199
    % A PARTIR DE LA VERSION 3#6 DE SICSTUS EL DUMP VIENE INCORPORADO A LA 
    % LIBRERIA CLPR POR LO QUE NO ES NECESARIO CARGARLO EXPRESAMENTE
    % linear:dump(Relevants,NameRel,ConstraClpr),
    
    dump(Relevants,NameRel,ConstraClpr),
    % aqui insertamos la escritura de las restricciones
    writeConstraintsClpr(ConstraClpr,L1/L2,Nin/Nout).

%080199
% ESTE CODIGO ES NUEVO Y ES EL QUE SE USA PARA RELANZAR LAS RESTRICCIONES
throwConstraintsAgain([]).
throwConstraintsAgain([_-(clpr:R)|Rs]):-
    !,
    call(R),
    throwConstraintsAgain(Rs).
throwConstraintsAgain([_-R|Rs]):-
    call(R),
    throwConstraintsAgain(Rs).


writeConstraintsClpr([],L/L,Nin/Nin).
writeConstraintsClpr([C|R],L/L2,Nin/Nout):-
    nameVarsTerm(C,C1,L/L1),
        ( Nin==0, tab(6), write('{ ')
      ;
          write(', '), nl,tab(6), write('  ') % no es la primera, se separa de la anterior por , + nl    
         ),
    write(C1),
        Nout1 is Nin+1,
    writeConstraintsClpr(R,L1/L2,Nout1/Nout).



doListNamesVarsRel([],[],L/L).
doListNamesVarsRel([Var|R],[Name|RName],L/L2):-
    searchInsertVar(Var,L/L1,Name),
    doListNamesVarsRel(R,RName,L1/L2).



/*****************************************************************************/
/*      NOMINACION DE VARIABLES DE UN TERMINO                */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% nameVarsTerm(+X,-Name,+L/-L1)
% Este predicado da nombre a todas las variables que aparecen en un termino. 
% Si la variable ha aparecido anteriormente ya tendra un nombre que es el que se 
% le dara y si no, se le da uno nuevo y se almacena para posteriores apariciones. 
% Las variables junto con sus nombres se almacenan en una lista, que se va pasando
% de una clausula a otra y se va completando. 
% searchInsertVar se ocupa de ver si la variable tiene nombre (ya ha aparecido), 
% que es el que devolvera. Si no ha aparecido le da un nombre nuevo y la almacena 
% junto con este en la lista que se le pasa
%-----------------------------------------------------------------------------%


nameVarsTerm(X,Name,L/L1):-
    var(X),
    !,
    searchInsertVar(X,L/L1,Name).

nameVarsTerm(T,T1,L/L1):-
    T=..[Name|Args],
    (
% Sonia B
%        Name=='=\=',!,Name1='/='
        Name=='=\\=',!,Name1='/='
% Sonia E

    ;
        Name=='=',!,Name1='=='
    ;
        Name1=Name),
    nameVarsListTerms(Args,Args1,L/L1),
    T1=..[Name1|Args1].


%-----------------------------------------------------------------------------%
% nameVarsListTerms(+ListaTerms,-Listanominada,+L/-L1)
% Da nombre a todas las variables que aparecen en cada termino de ListaTerms
%-----------------------------------------------------------------------------%

nameVarsListTerms([],[],L/L).
nameVarsListTerms([T|R],[T1|R1],L/L2):-
    nameVarsTerm(T,T1,L/L1),
    nameVarsListTerms(R,R1,L1/L2).

%%::B AE


%****************************************************************************
%                  SALIDA INTERVALOS DE DOMINIOS FINITOS                    
%
% como intervalos se entiende todo lo que no est� marcado 
% por 'prolog', 'clpfd', 'clpr'. tamcopo se muestran los intervalos 'inf..sup'
%*****************************************************************************

%SONIA ::B
% Comento el bloque completo porque al cambiar Handle por Residue
% hay muchos cambios.


/*

showIntervalsIfNeeded(Handle, L/_Ls,N1/N2) :-
      cflpfd_active,
      !,
      reverse(L, LR),
      showIntervals(Handle, LR, _Ls, N1, N2).
showIntervalsIfNeeded(Handle, L1/L2,N/N).

showIntervals(Handle, [], [], N, N).
showIntervals(Handle, [(Val,Nom)|Xs], Ls,NI,NO) :-
      fd_var(Val), !,
      (NI==0, tab(6), write('{ ')      % if this is the first interval, write '{'
        ; 
       write(', '), nl,tab(6), write('  ')), 
       NO1 is NI+1, % increment the counter of constraints displayed
       write(Nom), write(' in '), fd_dom(Val,Range), write(Range),
      showIntervals(Handle, Xs, Ls,NO1,NO).
showIntervals(Handle, [X|Xs], [X|Ls],NI,NO) :-
      showIntervals(Handle, Xs, Ls,NI,NO).

*/

%::Rafa 25/06/2005 Los dos argumentos al final representan la entrada y la salida de un contador
%   de restricciones mostradas

 
    showIntervalsIfNeeded(Residue,Cout, L/Ls,N1/N2) :- 
        cflpfd_active,
        !,
    showIntervals(Residue,Cout,L/Ls,N1/N2).

    showIntervalsIfNeeded(Residue,Cout, L/L,N/N). 


    showIntervals([],Cout,L/L,N/N).

    showIntervals([[C]-(Intervalo)|R],Cout,L1/L2,NI/NO):-
    isIn(C,L1,Name) ->
    (
        (NI==0, tab(6), write('{ ') % if this is the first interval, write '{'
        ;   
        write(','), nl, tab(6), write('  ')),
        NO1 is NI+1,  %increment the counter of constraints displayed
        nameVarsTerm([Intervalo],[Intervalo1],L1/Laux),
        write(Intervalo1)
    ),
    showIntervals(R,Cout, Laux/L2,NO1/NO).

    showIntervals([H|R],Cout,L1/L2,NI/NO):- showIntervals(R,Cout,L1/L2,NI/NO).


%**************************************************************************
%               Restricciones de la forma X #==Y como respuesta     
%
%   Estas restricciones estan en el Cout
%**************************************************************************

  showBridge([],L/L,N/N).

  showBridge([#==(A,B)|R],L/LO,NI/NO):-
    number(A),
    showBridge(R,L/LO,NI/NO). 
    
  showBridge([#==(A,B)|R],L/LO,NI/NO):-
    (NI==0, tab(6), write('{ ') % if this is the first interval, write '{'
    ;   
    write(','), nl, tab(6), write('  ')),
    NO1 is NI+1,  %increment the counter of constraints displayed
    nameVarsTerm(A,VA,L/L1), write(VA), 
    write(' #== '), 
    nameVarsTerm(B,VB,L1/L2), write(VB),
    showBridge(R,L2/LO,NO1/NO). 
     
  showBridge([#/==(A,B)|R],L/LO,NI/NO):-
    number(A),
    showBridge(R,L/LO,NI/NO). 
    
  showBridge([#/==(A,B)|R],L/LO,NI/NO):-
    (NI==0, tab(6), write('{ ')
    ;   
    write(','), nl, tab(6), write('  ')),
    NO1 is NI+1,  %increment the counter of constraints displayed
    nameVarsTerm(A,VA,L/L1), write(VA), 
    write(' #/== '), 
    nameVarsTerm(B,VB,L1/L2), write(VB),
    showBridge(R,L2/LO,NO1/NO). 
     
  showBridge([H|R],L/LO,NI/NO):-
    showBridge(R,L/LO,NI/NO). 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   divideResidue(residue,Lin1/Lout1,Lin2/Lout2,Lin3/Lout3)  separa las respuestas. 
%%   Las respuestas de los puentes se sacan del almacen por ello aqu� no se tratan 
%%   No se muestran las variables de dominio finito cuyo dominio es todo el rango (inf..sup)
%%   Lout1 almacena las restricciones de dominio finito
%%   Lout2 almacena las restricciones reales 
%%   Lout3 almacena los intervalos de las variables de DF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
   divideResidue(clpr(Residue),Lin1/Lout1,Lin2/clpr(Lout2),Lin3/Lout3):-
%nl,write(Residue),
    divideResidue1(Residue,Lin1/Lout1,Lin2/Lout2,Lin3/Lout3).

   divideResidue1([],L1/L1,L2/L2,L3/L3).

   divideResidue1([[_]-(prolog:Const)|R],Lin1/Lout1,Lin2/Lout2,Lin3/Lout3):-
      divideResidue1(R,Lin1/Lout1,Lin2/Lout2,Lin3/Lout3).

   divideResidue1([[C]-(C in inf..sup)|R],Lin1/Lout1,Lin2/Lout2,Lin3/Lout3):-
      divideResidue1(R,Lin1/Lout1,Lin2/Lout2,Lin3/Lout3).

   divideResidue1([[_|R1]-(clpfd:Const)|R],Lin1/Lout1,Lin2/Lout2,Lin3/Lout3):-
    append([Const],Lin1,Laux1),
      divideResidue1(R,Laux1/Lout1,Lin2/Lout2,Lin3/Lout3).

% The following is for the (non-built-in) constraints defined in cflpfdfile.pl in terms of indexicals
   divideResidue1([[_|R1]-(plgenerated:Const)|R],Lin1/Lout1,Lin2/Lout2,Lin3/Lout3):-
    append([Const],Lin1,Laux1),
      divideResidue1(R,Laux1/Lout1,Lin2/Lout2,Lin3/Lout3).

   divideResidue1([[H|R1]-(clpr:Const)|R],Lin1/Lout1,Lin2/Lout2,Lin3/Lout3):-
    append([Const],Lin2,Laux2),
      divideResidue1(R,Lin1/Lout1,Laux2/Lout2,Lin3/Lout3).

   divideResidue1([H|R],Lin1/Lout1,Lin2/Lout2,Lin3/Lout3):-
    append([H],Lin3,Laux3),
      divideResidue1(R,Lin1/Lout1,Lin2/Lout2,Laux3/Lout3).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%       Restricciones de dominio finito como respuesta 'showConstraintsFD'   
%%%%%%%%%    Estas restricciones vienen marcadas con clpfd.
%%%%%%%%%    Para que la respuesta mostrada sea mas legible cuando se tiene una variable
%%%%%%%%%    igual a un t�rmino se sustituye ese t�rmino en el resto de las restricciones
%%%%%%%%%    esto se hace con 'buildExp' pero antes es necesario hacer:
%%%%%%%%%    - se buscan las variables que son iguales a un t�rmino con 'findEq'
%%%%%%%%%    - se agegura que est� en la parte derecha del igual con 'varToRight'.
%%%%%%%%%    - se sustituyen seg�n la prioriodad de sus operadores 
%%%%%%%%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    showConstraintsFD(Residue,Cout,L/L4,N1/N2):-
    nameVars(Residue,Lout1,L),
    findEq(Lout1,[],Lconectores,[],Lnoconectores), 
    varToRight(Lconectores,[],Lo),
    arrangeSubexp(Lo,[]/L1,[]/L2,[]/L3),
    append(L1,L2,Laux),
    append(Laux,L3,Laux2),
    append(Laux2,Lnoconectores,Lpreparada),
    buildExp(L/L4,Lpreparada,N1/N2).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%    'buildExp' tiene una lista de restricciones ordenadas:
%%%%%%%%%    - primero las restricciones que posiblemente se pueden sustituir en el resto, 
%%%%%%%%%      (Lconect no es []). Se intenta sustituir esta restricci�n en el resto, pero 
%%%%%%%%%      si no se han sustituido (R == LconectSust) se muestra para no perder informaci�n
%%%%%%%%%    - Luego est�n las restricciones que no se pueden sustituir (Lconect == []), se muestran   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    buildExp(L/L,[],N/N).

    buildExp(L/L2,[H|R],N1/N2):-
    findEq([H],[],Lconect,[],Lnoconect), 
    ( (Lconect == []) ->         
        ( 
            nameVarsTerm(H,LH,L/L1),
            (N1==0, tab(6), write('{ ')
            ;   
            write(','), nl, tab(6), write('  ')),
            NO1 is N1+1,                   %increment the counter of constraints displayed
            showCFD(LH),
            buildExp(L1/L2,R,NO1/N2)
        )
        ;
        ( buildExp1(L,[H],R,LconectSust),
          (R == LconectSust  ->         % si no se ha sustituido se saca por pantalla
            ( (N1==0, tab(6), write('{ ')
              ; 
              write(','), nl, tab(6), write('  ')),
              NO1 is N1+1,                   %increment the counter of constraints displayed
              nameVarsTerm(H,LH,L/L1),
              showCFD(LH),
              buildExp(L1/L2,R,NO1/N2)
            );
            (
              varToRight(LconectSust,[],LconectSustO),
              buildExp(L/L2,LconectSustO,N1/N2)
            )
          )
        )
    ).


    buildExp1(L,LO,[],[]).

    buildExp1(L,['t=u IND'(T,U)|R],Lnoconectores,LO):-
    ( T == U, LO = Lnoconectores
      ;
      var(U) -> change(U,T,Lnoconectores,LO) 
    ).

    buildExp1(L,['x+y=t'(X,Y,T)|R],Lnoconectores,LO):-
    append([X],[' #+ '],R1),
    append(R1,[Y], R2),
    !,
    (
      var(T) -> change(T,R2,Lnoconectores,LO) 
    ).

    buildExp1(L,['ax+y=t'(A,X,Y,T)|R],Lnoconectores,LO):-
    append([A],[X],R1),
    append(R1,[' #+ '],R2),
    append(R2,[Y],R3),
    !,
    (
      var(T) -> change(T,R3,Lnoconectores,LO) 
    ).

    buildExp1(L,['x+by=t'(X,B,Y,T)|R],Lnoconectores,LO):-
    append([X],[' #+ '],R1),
    append(R1,[B],R2),
    append(R2,[Y],R3),
    !,
    (
      var(T) -> change(T,R3,Lnoconectores,LO) 
    ).

    buildExp1(L,['ax+by=t'(A,X,B,Y,T)|R],Lnoconectores,LO):-
    append([A],[X],R1),
    append(R1,[' #+ '],R2),
    append(R2,[B],R3),
    append(R3,[Y],R4),
    !,
    (
      var(T) -> change(T,R4,Lnoconectores,LO) 
    ).

    buildExp1(L,['x*y=z'(X,Y,T)|R],Lnoconectores,LO):-
    append([X],[' #* '],R1),
    append(R1,[Y], R2),
    !,
    (
      var(T) -> change(T,R2,Lnoconectores,LO) 
    ).

    buildExp1(L,['x/k=z'(X,Y,T)|R],Lnoconectores,LO):-
    append([X],[' #/ '],R1),
    append(R1,[Y], R2),
    !,
    (
      var(T) -> change(T,R2,Lnoconectores,LO) 
    ).

    buildExp1(L,['x/y=z'(X,Y,T)|R],Lnoconectores,LO):-
    append([X],[' #/ '],R1),
    append(R1,[Y], R2),
    !,
    (
      var(T) -> change(T,R2,Lnoconectores,LO) 
    ).

    buildExp1(L,['ax=t'(A,X,T)|R],Lnoconectores,LO):-
    append([A],[' #* '],R1),
    append(R1,[X],R2),
    !,
    (
      var(T) -> change(T,R2,Lnoconectores,LO) 
    ).

    buildExp1(L,[H|R],Lnoconectores,LO):-
%nl, write(H),
    buildExp1(L,R,Lnoconectores,LO).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    change(+U,+T,+LI,-LO)  
%   LO es la lista resultante de cambiar U por T en la lista LI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



   change(U,T,X,LO):-
    var(X) -> (
            (X == U) -> LO = T;
                    LO = X
           )
    ;
    (
        X=..[Name|Args],
        (Name == U -> Name1 = T; Name1 = Name),
        changeList(U,T,Args,Args1),
        LO=..[Name1|Args1]
    ).
    
   changeList(U,T,[],[]).
   changeList(U,T,[H|R],[H1|R1]):-
    change(U,T,H,H1),
    changeList(U,T,R,R1).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%    'showCFD' da formato a la respuesta  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    showCFD('x mod y=z'(U,V,W)):-
    write(U), 
    write(' mod '),
    write(V),
    write(' = '),
    write(W).

    showCFD('t=u IND'(T,U)):-
    (is_list(T) -> showList(T);write(T)), 
    write(' #= '), 
    (is_list(U) -> showList(U);write(U)).

    showCFD('x\\=y IND'(X,Y)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' \/= '), 
    (is_list(Y) -> showList(Y);write(Y)). 

    showCFD('t\\=u+c'(T,U,-1)):-                    
    (is_list(T) -> showList(T);write(T)), 
    write(' \/= '), 
    (is_list(U) -> showList(U);write(U)), 
    write(' #- 1').

    showCFD('t\\=u+c'(T,U,C)):-
    (C == -1)->
    (
       (is_list(T) -> showList(T);write(T)), 
       write(' \/= '), 
       (is_list(U) -> showList(U);write(U)), 
       write(' #+ '), 
       (is_list(C) -> showList(C);write(C))
    ).

    showCFD('x=<y IND'(X,Y)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #=< '), 
    (is_list(Y) -> showList(Y);write(Y)). 

    showCFD('t=<u+c'(X,Y,-1)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #< '), 
    (is_list(Y) -> showList(Y);write(Y)).

    showCFD('t=<u+c'(X,Y,T)):-
    ( T == -1)->
    (
       (is_list(X) -> showList(X);write(X)), 
       write(' #=< '), 
       (is_list(Y) -> showList(Y);write(Y)), 
       write(' #+ '), 
       (is_list(T) -> showList(T);write(T))
    ).

    showCFD('t>=u+c'(X,Y,1)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #> '), 
    (is_list(Y) -> showList(Y);write(Y)).

    showCFD('t>=u+c'(X,Y,T)):-
    ( T == 1)->
    (
       (is_list(X) -> showList(X);write(X)), 
       write(' #>= '), 
       (is_list(Y) -> showList(Y);write(Y)), 
       write(' #+ '), 
       (is_list(T) -> showList(T);write(T))
    ).

    showCFD('t=u+c'(X,Y,T)):-
       (is_list(X) -> showList(X);write(X)), 
       write(' #= '), 
       (is_list(Y) -> showList(Y);write(Y)), 
       write(' #+ '), 
       (is_list(T) -> showList(T);write(T)).

    showCFD('t+u=c'(X,Y,T)):-
       (is_list(X) -> showList(X);write(X)), 
       write(' #+ '), 
       (is_list(Y) -> showList(Y);write(Y)), 
       write(' #= '), 
       (is_list(T) -> showList(T);write(T)).

    showCFD('x+y=t'(X,Y,T)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #+ '), 
    (is_list(Y) -> showList(Y);write(Y)), 
    write(' #= '), 
    (is_list(T) -> showList(T);write(T)).

    showCFD('ax+y=t'(A,X,Y,T)):-
    write(A),
    (is_list(X) -> showList(X);write(X)), 
    write(' #+ '), 
    (is_list(Y) -> showList(Y);write(Y)), 
    write(' #= '), 
    (is_list(T) -> showList(T);write(T)).

    showCFD('x+by=t'(A,X,Y,T)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #+ '), 
    write(B),
    (is_list(Y) -> showList(Y);write(Y)), 
    write(' #= '), 
    (is_list(T) -> showList(T);write(T)).

    showCFD('ax+by=t'(A,X,Y,T)):-
    write(A),
    (is_list(X) -> showList(X);write(X)), 
    write(' #+ '), 
    write(B),
    (is_list(Y) -> showList(Y);write(Y)), 
    write(' #= '), 
    (is_list(T) -> showList(T);write(T)).

    showCFD('x+y=u+c'(X,Y,U,C)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #+ '), 
    (is_list(Y) -> showList(Y);write(Y)), 
    write(' #= '), 
    (is_list(U) -> showList(U);write(U)), 
    write(' #+ '), 
    (is_list(C) -> showList(C);write(C)).

    showCFD('x*y=z'(X,Y,T)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #* '), 
    (is_list(Y) -> showList(Y);write(Y)), 
    write(' #= '), 
    (is_list(T) -> showList(T);write(T)).

    showCFD('x/k=z'(X,K,Z)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #/ '), 
    (is_list(K) -> showList(K);write(K)), 
    write(' #= '), 
    (is_list(Z) -> showList(Z);write(Z)).

    showCFD('x/y=z'(X,K,Z)):-
    (is_list(X) -> showList(X);write(X)), 
    write(' #/ '), 
    (is_list(K) -> showList(K);write(K)), 
    write(' #= '), 
    (is_list(Z) -> showList(Z);write(Z)).

    showCFD('ax=t'(A,X,T)):-
    (is_list(A) -> showList(A);write(A)), 
    (is_list(X) -> showList(X);write(X)), 
    write(' #= '), 
    (is_list(T) -> showList(T);write(T)).

    showCFD('scalar_product'(A,B,OP,N)):-
    writeProductList(A,B,1),
    write(' '),
    write(OP),
    write(' '),
    write(N).

    showCFD('all_different'(A,B)):-
    write('all_different '),
    write(A),
    write(' '),
    write(B).

    showCFD('all_different'''(A)):-
    write('all_different'' '),
    write(A).

    showCFD('assignment'(X,Y)):-
    write('assignment '),
    write(X),
    write(' '),
    write(Y).

    showCFD('circuit'(X)):-
    write('circuit '),
    write(X).

    showCFD('circuit'(X,Y)):-
    write('circuit'' '),
    write(X),
    write(' '),
    write(Y).

    showCFD('serialized'(X,Y)):-
    write('serialized '),
    write(X),
    write(' '),
    write(Y).

    showCFD('serialized'(X,Y,Z)):-
    write('serialized'' '),
    write(X),
    write(' '),
    write(Y),
    write(' '),
    write(Z).

    showCFD('cumulative'(X,Y,Z,T)):-
    write('cumulative '),
    write(X),
    write(' '),
    write(Y),
    write(' '),
    write(Z),
    write(' '),
    write(T).

    showCFD('cumulative'(X,Y,Z,T,U)):-
    write('cumulative'' '),
    write(X),
    write(' '),
    write(Y),
    write(' '),
    write(Z),
    write(' '),
    write(T),
    write(' '),
    write(U).

    showCFD('sum'(X,Y,Z)):-
    write('sum '),
    write(X),
    write(' '),
    write(Y),
    write(' '),
    write(Z).

    showCFD('count'(X,Y,Z,T)):-
    write('count '),
    write(X),
    write(' '),
    write(Y),
    write(' '),
    write(Z),
    write(' '),
    write(T).

    showCFD('setcomplement'(X,Y)):-
    write('not subset '),
    write(X),
    write(' '),
    write(Y).

    showCFD('subset'(X,Y)):-
    write('subset '),
    write(X),
    write(' '),
    write(Y).

    showCFD(Other):-
    write(Other). 


    
    writeProductList([],[],N).

    writeProductList([HA|RA],[HB|RB],N):-
    ((HA == 0);                           % si es cero no se hace nada
     (HB == 0);
     (HA == -1, write('#-'), write(HB));
     (HA == 1, N == 1, write(HB));
     (HA == 1, N \== 1, write('#+'), write(HB));

     (HB == -1, write('#-'), write(HA));
     (HB == 1, N == 1, write(HA));
     (HB == 1, N \== 1, write('#+'), write(HA));
     (write('#+'), write(HA), write('#*'), write(HB))
    ),
        N1 is N+1,
    writeProductList(RA,RB,N1).




    showList([]).
    showList([H|R]):-
    (is_list(H) -> showList(H); write(H)),
    showList(R).

    showList2([]).

    showList2([H]):-
    write(H).
    showList2([H|R]):-
    write(H),
    write(','),
    showList2(R).




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%    para evitar reiteradas comprobaciones 'varToRight' deja en la parte derecha
%%%%%%%%%   del igual la variable
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    varToRight([],Li,Li).

    varToRight(['t=u IND'(X,Y)|R],Li,Lo):-
    ( var(Y) -> append(Li,['t=u IND'(X,Y)],Laux)  
        ;
        append(Li,['t=u IND'(Y,X)],Laux)  
    ),
    varToRight(R,Laux,Lo).

    varToRight([L|R],Li,Lo):-
        append(Li,[L],Laux),
            varToRight(R,Laux,Lo).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%  findEq(+L,+Lconectores,-LconectoresO,+Lnoconectores,-LnoconectoresO)  
%%%%%%%%%  Deja en LconectoresO todas las restricciones de L con formato: t=u IND, x+y=t, ax+y=t, 
%%%%%%%%%   x+by=t, ax+by=t, x*y=z, x/k=z y ax=t.
%%%%%%%%%  El resto de restricciones de L las deja en LnoconectoresO 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



    findEq([],Lconectores,Lconectores,Lnoconectores,Lnoconectores).

    findEq(['t=u IND'(X,Y)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(Y) -> (
                append(['t=u IND'(X,Y)],Lconectores, Laux2 ), 
                findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
        (
          var(X) -> 
              (  
                append(['t=u IND'(Y,X)],Lconectores, Laux2 ), 
                findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (  
                append(['t=u IND'(X,Y)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              )
        ).

    findEq(['x+y=t'(X,Y,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                append(['x+y=t'(X,Y,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['x+y=t'(X,Y,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).
        
    findEq(['ax+y=t'(A,X,Y,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                    append(['ax+y=t'(A,X,Y,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['ax+y=t'(A,X,Y,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).

    findEq(['x+by=t'(X,B,Y,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                    append(['x+by=t'(X,B,Y,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['x+by=t'(X,B,Y,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).

    findEq(['ax+by=t'(A,X,B,Y,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                    append(['ax+by=t'(A,X,B,Y,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['ax+by=t'(A,X,B,Y,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).

    findEq(['x*y=z'(X,Y,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                append(['x*y=z'(X,Y,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['x*y=z'(X,Y,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).
        
    findEq(['x/k=z'(X,Y,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                append(['x/k=z'(X,Y,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['x/k=z'(X,Y,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).
        
    findEq(['x/y=z'(X,Y,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                append(['x/y=z'(X,Y,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['x/y=z'(X,Y,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).
        
    findEq(['ax=t'(A,X,T)|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
        var(T) -> (
                    append(['ax=t'(A,X,T)],Lconectores, Laux2 ), 
                    findEq(R,Laux2,LconectoresO,Lnoconectores,LnoconectoresO)   
              );
              (
                append(['ax=t'(A,X,T)],Lnoconectores, Laux1 ),
                findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO) 
              ).        
        
    findEq([H|R],Lconectores,LconectoresO,Lnoconectores,LnoconectoresO):-
    append([H],Lnoconectores, Laux1 ),
    findEq(R,Lconectores,LconectoresO,Laux1,LnoconectoresO).
        



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%  arrangeSubexp([+L,+L1I/-L1O,+L2I/-L2O,+L3I/-L3O)  
%%%%  Deja en L1O las restricciones con formato: t=u IND
%%%%  Deja en L2O las restricciones con formato: x/k=z, ax=t, x*y=z
%%%%  Deja en L3O las restricciones con formato: x+y=t, ax+y=t, x+by=t, ax+by=t 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    arrangeSubexp([],L1/L1,L2/L2,L3/L3).

    arrangeSubexp(['t=u IND'(T,U)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['t=u IND'(T,U)],L1I,Laux),
        arrangeSubexp(R,Laux/L1O,L2I/L2O,L3I/L3O).
    
    arrangeSubexp(['x/k=z'(X,Y,T)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['x/k=z'(X,Y,T)],L2I,Laux),
        arrangeSubexp(R,L1I/L1O,Laux/L2O,L3I/L3O).

    arrangeSubexp(['ax=t'(A,X,T)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['ax=t'(A,X,T)],L2I,Laux),
        arrangeSubexp(R,L1I/L1O,Laux/L2O,L3I/L3O).

    arrangeSubexp(['x*y=z'(X,Y,T)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['x*y=z'(X,Y,T)],L2I,Laux),
        arrangeSubexp(R,L1I/L1O,Laux/L2O,L3I/L3O).

    arrangeSubexp(['x+y=t'(X,Y,T)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['x+y=t'(X,Y,T)],L3I,Laux),
        arrangeSubexp(R,L1I/L1O,L2I/L2O,Laux/L3O).

    arrangeSubexp(['ax+y=t'(A,X,Y,T)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['ax+y=t'(A,X,Y,T)],L3I,Laux),
        arrangeSubexp(R,L1I/L1O,L2I/L2O,Laux/L3O).

    arrangeSubexp(['x+by=t'(X,B,Y,T)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['x+by=t'(X,B,Y,T)],L3I,Laux),
        arrangeSubexp(R,L1I/L1O,L2I/L2O,Laux/L3O).

    arrangeSubexp(['ax+by=t'(A,X,B,Y,T)|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    append(['ax+by=t'(A,X,B,Y,T)],L3I,Laux),
        arrangeSubexp(R,L1I/L1O,L2I/L2O,Laux/L3O).


    arrangeSubexp([H|R],L1I/L1O,L2I/L2O,L3I/L3O):-
    arrangeSubexp(R,L1I/L1O,L2I/L2O,L3I/L3O).



%-----------------------------------------------------------------------------%
% nameVars(+X,-Name,+L)
% Este predicado cambia las var que aparecen en el t�rmino X por sus 
% correspondientes nombres de la lista L
%-----------------------------------------------------------------------------%

nameVars(X,Name,L):-
    var(X),
    !,
    (isIn(X,L,Name);
    Name = X
    ).

nameVars(T,T1,L):-
    T=..[Name|Args],
    (
        Name=='=\\=',!,Name1='/='
    ;
        Name=='=',!,Name1='=='
    ;
        Name1=Name),
    nameVarsList(Args,Args1,L),
    T1=..[Name1|Args1].


%-----------------------------------------------------------------------------%
% nameVarsList(+ListaTerms,-Listanominada,+L)
% Da nombre a todas las variables que aparecen en cada termino de ListaTerms
%-----------------------------------------------------------------------------%

nameVarsList([],[],L).
nameVarsList([T|R],[T1|R1],L):-
    nameVars(T,T1,L),
    nameVarsList(R,R1,L).


%SONIA ::E





/*****************************************************************************/
/*           EXTRACCION DE VARIABLES RELEVANTES DE LA RESPUESTA          */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% extractRelVarsClpr(Vars,Residue,Rel). 
%   - Vars es la lista de variables del objetivo y viene de la forma 
%   [(Nombre,Term) ...], donde Nombre es el nombre de la variable y Term el 
%   termino al que se ha ligado una vez que se ha resuelto el objetivo. 
%   - Residue es la lista de objetivos suspendidos que resulta de la 
%   ejecucion. Para la extraccion de vars relevantes solo nos interesan los 
%   residuos no lineales
%   - Rel es lo que devuelve el predicado y es una lista de variables (las 
%   relevantes).
%   
%   Una variable es relevante si aparece en un termino que se ha ligado a 
%   una variable del objetivo (el termino puede ser una variable prolog) o 
%   bien, si aparece en una restriccion no lineal. De la primera parte se 
%   encarga extraeVarsRelObj y de la segunda extraeVarsResiduo 
%-----------------------------------------------------------------------------%

extractRelVarsClpr(Vars,Residue,Rel):-
    extractConstraNonLin(Residue,NonLin),
    term_variables((Vars,NonLin),Rel).



extractConstraNonLin([],[]).

/*
extractConstraNonLin([(_-(nonlin:C))|R],[nonlin:C|R1]):-
    !,
    extractConstraNonLin(R,R1).


% 26/11/99 mercedes: en la version 3.7.1 de Sicstus Prolog el formato ha 
% cambiado y en vez de nonlin es clpr
extractConstraNonLin([(_-(clpr:C))|R],[nonlin:C|R1]):-
    !,
    extractConstraNonLin(R,R1).

*/
extractConstraNonLin([_|R],R1):-
    extractConstraNonLin(R,R1).



/*****************************************************************************/
/*           TERMINOS RELEVANTES                     */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% isRelevant(+Term,+L): indica si Term es un termino relevante.
% En L llevo la lista de variables relevantes, por tanto una variable sera
% relevante si pertenece a esa lista, y un termino sera relevante si sus 
% argumentos son relevantes.
%-----------------------------------------------------------------------------%

isRelevant(Term,L):-var(Term),!,member(Term,L).
isRelevant(Term,L):-
    Term=..[_|Args],
    isRelevantLst(Args,L).


%-----------------------------------------------------------------------------%
% isRelevantLst(+Listaterminos,+L): indica si los elementos de Listaterminos
% son relevantes.
%-----------------------------------------------------------------------------%

isRelevantLst([],_).
isRelevantLst([Term|R],L):-
    isRelevant(Term,L),
    isRelevantLst(R,L).



% Estos predicados sirven para depurar un poco la salida. Lo que hacen es quitar
% repeticiones de restricciones repetidas. Es decir, en L llevo una lista con
% elementos de la forma V:C donde V es una variable y C es una lista de 
% desigualdades asociadas a V, pero en C puede haber repeticiones, y estas no
% queremos que se muestren por pantalla, por eso lo que se hace es eliminar las
% repeticiones de C.

%-----------------------------------------------------------------------------%
% eliminateSuperfluities(+L,-R), donde L es una lista de listas de la forma V:C y
% R es el resultado de eliminar las repeticiones en C
%-----------------------------------------------------------------------------%

eliminateSuperfluities([],[]).
eliminateSuperfluities([V:C|R],[V:C1|R1]):-
    !,
    eliminateSuperfluitiesList(C,C1),
    eliminateSuperfluities(R,R1).
    
% Rafa: other constraints different from disequality are skipped
eliminateSuperfluities([A|R],[A,R1]) :-
    !,
    eliminateSuperfluities(R,R1).

% eliminateSuperfluitiesList(+L,-R) donde L es una lista de elementos y R es el
% resultado de eliminar las repeticiones de L.
eliminateSuperfluitiesList([],[]).
eliminateSuperfluitiesList([L|R],R1):-
%FSP 19-02-2007 ::B
% Cambio este predicado para eliminar las desigualdades con n�meros equivalentes (e.g., X/=0 y X/=0.0)
%    member(L,R),
    miembro(L,R),
%::E
    !,
    eliminateSuperfluitiesList(R,R1).

eliminateSuperfluitiesList([L|R],[L|R1]):-
    eliminateSuperfluitiesList(R,R1).

%FSP 19-02-2007 ::B
miembro(X,[Y]):-!,testEq(X,Y).
miembro(X,[L|R]):-(testEq(X,L),!;miembro(X,R)).
%::E
