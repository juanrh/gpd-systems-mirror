%----------------------------------------------------------------------------%
% cooperation.pl
%----------------------------------------------------------------------------%
/*
- Autores: Sonia, Fernando y Antonio.
- Descripcion: Este m�ulo contiene las funciones necesarias para la
cooperaci�. Debe ser cargado cuando las librerias de dominios finitos y reales 
est� cargadas al mismo tiempo.
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(cooperation,['$#=='/5,'$#/=='/5,searchVarsR/4,searchVarsFD/4,cleanBridgeStore/2]).

:- tools:complete_root_filename(toycomm,F),load_files(F,[if(changed),imports([hnf/4])]).
:- tools:complete_root_filename(dyn,F),load_files(F,[if(changed),imports([ tolerance_active/1 ])]).


:- use_module(library(clpr)).
:- use_module(library(clpfd)).


%%%%%%%%%%%%%% FD+R COMMUNICATION CONSTRAINT %%%%%%%%%%%%%%%%%%%%

$#==(L, R, Out, Cin, Cout):-
        hnf(L, HL, Cin, Cout1),
        hnf(R, HRaux, Cout1, Cout2),
        (number(HRaux) -> HR is HRaux*1.0; HR = HRaux),
        tolerance_active(Epsilon),
        ((Out=true,
%               freeze(HL, HR is float(HL)), 
                freeze(HL, {HL - Epsilon =< HR, HR =< HL + Epsilon} ), 
%               freeze(HR, HL is integer(HR)));
                freeze(HR, (HL is integer(round(HR))) ),  
                Cout3 = ['#=='(HL,HR)|Cout2]  
        );
         (Out=false, Cout3 = ['#/=='(HL,HR)|Cout2],
                freeze(HL, (F is float(HL), {HR =\= F})), 
                freeze(HR, (0.0 is float_fractional_part(HR) -> 
                                 (I is integer(HR), HL #\= I); 
                                 true))
         )
        ),cleanBridgeStore(Cout3,Cout).

$#/==(L, R, Out, Cin, Cout):-
        hnf(L, HL, Cin, Cout1),
        hnf(R, HRaux, Cout1, Cout2),
        (number(HRaux) -> HR is HRaux*1.0; HR = HRaux),
        (tolerance_active(E) -> Epsilon is E ; Epsilon is 0.0),
        (
         (Out=true, Cout3 = ['#/=='(HL,HR)|Cout2],
               freeze(HL, (F is float(HL), {HR =\= F})), 
               freeze(HR, (0.0 is float_fractional_part(HR) -> 
                                 (I is integer(HR), HL #\= I); 
                                 true))
         )
         ;
         (Out=false,
%               freeze(HL, HR is float(HL)), 
                freeze(HL, {HL - Epsilon =< HR, HR =< HL + Epsilon} ), 
%                freeze(HR, HL is integer(HR))
                freeze(HR, (HLaux is round(HR),HL is integer(HLaux))),  
                Cout3 = ['#=='(HL,HR)|Cout2]
         )
        ),cleanBridgeStore(Cout3,Cout).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Sonia. searchVarsR, recibe por par�etro una variable o un nmero (HL), 
%%%  - Si es un nmero entero se devuelve su correspondiente real en HLR
%%%  - Si es una variable se busca en la lista de entrada con la informaci�, 
%%%    -  en el caso de encontrarla se devuelve su correspondiente variable entera en HLR  
%%%    -  en el caso de no encontrarla se le asigna una nueva variable y se guarda en el almac� de salida, 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


searchVarsR(HL,Cin,Cout,HLR):-
   integer(HL),
   !,
   Cout=Cin,
   HLR is float(HL).

searchVarsR(HL,[],Cout,HLR):-
   !,
   $#==(HL,HLR,true,[],Cout).

searchVarsR(HL,[#==(L,R)|Rest],Cout,HLR):-
   var(HL), HL==L,
   !,
   HLR=R, 
   Cout=[#==(L,R)|Rest].
   
searchVarsR(HL,[H|Rest],[H|Out],HLR):-   
    searchVarsR(HL,Rest,Out,HLR).



%%%%% Sonia: searchVarsFD, recibe por el par�etro X una variable o un nmero, 
%%%%%  - Si es un nmero real de valor entero se devuelve su correspondiente entero en XFD y true en Out
%%%%%  - Si es un nmero real de valor NO entero se devuelve su correspondiente entero en XFD y false en Out
%%%%%  - Si es una variable se busca en el Cin, 
%%%%%    -  en el caso de encontrarla se devuelve su correspondiente variable entera en XFD y true en Out 
%%%%%    -  en el caso de no encontrarla no se asigna nada en Out 

searchVarsFD(X,[],Out,XFD).
  
searchVarsFD(X,[#==(L,R)|Rest],Out,XFD):-
   !,
   (number(X) ->   (Xaux is floor(X), X2 is X*1.0,
              ( Xaux == X2 ->  ( Out=true,XFD is integer(X)); 
                        ( Out=false, (X >= 0 -> XFD is integer(X);XFD is integer(X-1)))
              )  
            )
                ;
           ( X==R -> (Out=true,XFD=L)
                ;   
                    searchVarsFD(X,Rest,Out,XFD)
           )
    ).

searchVarsFD(X,[_|Rest],Out,XFD):-
    searchVarsFD(X,Rest,Out,XFD).



% cleanBridgeStore(+Cin,-Cout) al unificar variables es posible que estas variables esten
% puenteadas, de ser as�se deben unificar tambi� las correspondientes variables
% que se encuentran al otro extremo de los puente 
% Por ejemplo el objetivo Y #== RY, X #==RX, X == Y nos dar� como
% respuesta { X -> Y } { Y #== RY, Y #== RX }, con cleanBridgeStore la respuesta es
% { X -> Y, RX -> RY } 

% mayo 2005, al incorporar la tolerancia, podemos tener un caso m�s en 
% el almac�n de puentes, el caso (num #== var)
% almacenado puede estar 
% (num #== num) eliminarlo del almac�n
% (num #/== num) eliminarlo del almac�n
% (num #== var) la variable toma el valor num�rico y se elimninan del almac�n 
% (var #== var) comprobar si existen dos puentes con dos extremos unificados, en este caso
% unificar los otros dos extremos. Tambi�n se eliminan las repeticiones de los puentes.



cleanBridgeStore([],[]).

cleanBridgeStore([#==(X,RX)|R1],R2):-
     number(X),number(RX),!, cleanBridgeStore(R1,R2).
     
cleanBridgeStore([#/==(X,RX)|R1],R2):-
     number(X),number(RX),!, cleanBridgeStore(R1,R2).
     
cleanBridgeStore([#==(X,RX)|R1],R2):-
     number(X), var(RX),!, RX is float(X),
     cleanBridgeStore(R1,R2).   

cleanBridgeStore([#==(X,RX)|R1],[#==(X,RX)|R2]):-
     !,
     removeBridge(#==(X,RX),R1,RAux),
     cleanBridgeStore(RAux,R2).
   
cleanBridgeStore([Other|Rest],[Other|Rest2]) :-
   !,
   cleanBridgeStore(Rest,Rest2).

 

% removeBridge(+T,+Lin,-Lout)
removeBridge(T,[],[]).

removeBridge(#==(X,RX),[#==(Y,RY)|B],B2) :-
   ((X==Y,RX==RY),!,removeBridge(#==(X,RX),B,B2))
  ;(X==Y,!,RX=RY,removeBridge(#==(X,RX),B,B2))
  ;(RX==RY,!,X=Y,removeBridge(#==(X,RX),B,B2)).

removeBridge(T,[A|B],[A|B2]) :-
   !,
   removeBridge(T,B,B2).


