%-----------------------------------------------------------------------------%
% entailment.pl
%-----------------------------------------------------------------------------%
/*
- Author: Rafa

- Description:  Entailment between basic facts

- Modified:
	18/01/02 mercedes (modules).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(entailment,[entails/2,basicFactEntailment/2, entails/3, totalTerm/1]).

:- load_files(navigating,[if(changed),imports([rootBasicFact/2,whoAreMyChildren/2])]).

:- load_files(tools,[if(changed),imports([concatLsts/2])]).



% entailment algorithm. The second parameter is used to produce
% new variables accoding to rule R6
entails([],_N).

% R1
entails( [ (X,Y)|Rest],N) :-
        var(X),
	var(Y),
	X==Y,
	!,
	entails(Rest,N).

% R2
entails([ (Term, pValBottom) | Rest],N) :-
	!,
	entails(Rest,N).

% R3 a: groud total terms --> thy must be equal
entails([ (Term1, Term2) | Rest],N) :-
	\+ var(Term1),
	\+ var(Term2),
        ground(Term1),
        ground(Term2),
	totalTerm(Term1),
	totalTerm(Term2),
	!,
	Term1 == Term2,
	entails(Rest,N).

% R3 b
entails([ (Term1, Term2) | Rest],N) :-
	\+ var(Term1),
	\+ var(Term2),
	!,
	Term1 =.. [F|Args],
	Term2 =.. [F|Args2],
	lengthList(Args,N1), lengthList(Args2,N2),
	N1 = N2,
	zip(Args,Args2,NewArgs),
	concatLsts([NewArgs,Rest],NewRest),
	entails(NewRest,N).

% R4
entails([ (S,X) | Rest],N) :-
	\+ var(S),
	var(X),
	!,
	totalTerm(S),
	X = S,
	entails(Rest,N).


% R5
entails([ (X,Y) | Rest],N) :-
	var(X),
	var(Y),
	\+ (X==Y),
	!,
	X = Y,
	entails(Rest,N).

% R6
entails([ (X, Term) | Rest],N) :-
	var(X),
	Term =.. [F|Args],
	!,
	lengthList(Args,M),
	produceVariables(M,N,L),
	zip(L,Args,New),
	N2 is N +M,
	X =.. [F|L],
	concatLsts([New,NewRest],NewRest2),
	entails(NewRest2,N2).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Check which basic facts of the lists are entailed by  the basic fact (F,Args,Result,Ground,Total)
entails((F,Args,Result,Ground,Total),[],[]).
entails((F,Args,Result,Ground,Total),[(F2,Args2,Result2,Ground2,Total2)|L],R) :-
	!,
	entails((F,Args,Result,Ground,Total),L,R1),
	(
		F == F2,
               % write( (F,Args,Result,Ground,Total)),
               % write('--->'),
               % write( (F2,Args2,Result2,Ground2,Total2)),nl,

		entailedArrow((F2,Args2,Result2,Ground2,Total2),(F,Args,Result,Ground,Total)),
		R = [(F2,Args2,Result2)|R1]
                % write('yes!' ),nl
	;
		R = R1
	),
	!.


%


% If both basic facts are total and ground the entailment is the equality
entailedArrow((F,Args,Result,yes,yes),(F,Args2,Result2,yes,yes)) :-
    !,
    Args == Args2, Result==Result2.

% The entaiment suceeds trivially when the two arrows are the same basic fact
entailedArrow((F,Args,Result,Ground,Total),(F,Args2,Result2,Ground2,Total2)) :-
    Args == Args2, Result==Result2, !.
	

% first check if there is a entalement between the results to improve the efficiency
/*
entailedArrow((F,Args,Result,Ground,Total),(F,Args2,Result2,Ground2,Total2)) :-
	!,
	Eq = [(Result2,Result)],
	% the variables occur as strings, we must replace them for real variables
	entails([(Result2,Result)],0),
        % then check everything
        entailedArrow2((F,Args,Result,Ground,Total),(F,Args2,Result2,Ground2,Total2)).
*/
entailedArrow((F,Args,Result,Ground,Total),(F,Args2,Result2,Ground2,Total2)) :-
	!,
	zip(Args,Args2,L),
	Eq = [(Result2,Result)|L],
	entails(Eq,0).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Auxiliary predicates

% zipping of a Prolog list
zip([ ],[ ], [ ]).
zip([X|Xs], [Y|Ys], [(X,Y)|Z]) :-
	zip(Xs,Ys,Z).

% length of a Toy list
lengthList([],0).
lengthList([X|Xs], N) :-
	lengthList(Xs,N2),
	N is N2+1.

% a term is total when it dos not contain any bottom
totalTerm(Term) :- \+ occurs(pValBottom, Term).

% check for the occurrecnce of the first parameter in the second one
occurs(A,B) :- A == B, !.
occurs(A,B) :- var(B), !, fail.
occurs(A, Term) :-
	!,
	Term =.. [F|Args],
	occursAny(A,Args).

% check for the occurrence of the first parameter in any of the components
% of the list
occursAny(A,[X|Xs]) :-
	occurs(A,X),
	!.
occursAny(A,[X|Xs]) :-
	!,
	occursAny(A,Xs).


% produceVariables(+M,+N,-L)
% L  are M new variables produced using the integer N as seed.
produceVariables(0,N,[]) :- !.
produceVariables(M,N,[X| R]) :-
	!,
	M2 is M-1,
	N2 is N+1,
	produceVariables(M2,N2,R).

%%%%%%%%%%%%%%%%%%%%%%%%%%%

