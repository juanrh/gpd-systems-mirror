

funct(openFile, 2, 2, ->(:(char, []), ->(ioMode, io(handle))), io(handle)).
funct(closeFile, 1, 1, ->(handle, io(unit)), io(unit)).
funct(end_of_file, 1, 1, ->(handle, io(bool)), io(bool)).
funct(getCharFile, 1, 1, ->(handle, io(char)), io(char)).
funct(putCharFile, 2, 2, ->(handle, ->(char, io(unit))), io(unit)).
funct(putStrFile, 2, 2, ->(handle, ->(:(char, []), io(unit))), io(unit)).
funct(putStrLnFile, 2, 2, ->(handle, ->(:(char, []), io(unit))), io(unit)).
funct(getLineFile, 1, 1, ->(handle, io(:(char, []))), io(:(char, []))).
funct(contin1, 2, 2, ->(handle, ->(char, io(:(char, [])))), io(:(char, []))).
funct(contin2, 2, 2, ->(char, ->(:(char, []), io(:(char, [])))), io(:(char, []))).

hnf_susp('$openFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$openFile'(_A, _B, _C, _D, _E).
hnf_susp('$closeFile', '.'(_A, []), _B, _C, _D):-
        '$closeFile'(_A, _B, _C, _D).
hnf_susp('$end_of_file', '.'(_A, []), _B, _C, _D):-
        '$end_of_file'(_A, _B, _C, _D).
hnf_susp('$getCharFile', '.'(_A, []), _B, _C, _D):-
        '$getCharFile'(_A, _B, _C, _D).
hnf_susp('$putCharFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$putCharFile'(_A, _B, _C, _D, _E).
hnf_susp('$putStrFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$putStrFile'(_A, _B, _C, _D, _E).
hnf_susp('$putStrLnFile', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$putStrLnFile'(_A, _B, _C, _D, _E).
hnf_susp('$getLineFile', '.'(_A, []), _B, _C, _D):-
        '$getLineFile'(_A, _B, _C, _D).
hnf_susp('$contin1', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$contin1'(_A, _B, _C, _D, _E).
hnf_susp('$contin2', '.'(_A, '.'(_B, [])), _C, _D, _E):-
        '$contin2'(_A, _B, _C, _D, _E).


'$$apply_1'(openFile, _A, openFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, openFile(_B), _C, _D):-
        unifyHnfs(_A, openFile, _C, _D).

'$$apply_1'(putCharFile, _A, putCharFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, putCharFile(_B), _C, _D):-
        unifyHnfs(_A, putCharFile, _C, _D).

'$$apply_1'(putStrFile, _A, putStrFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, putStrFile(_B), _C, _D):-
        unifyHnfs(_A, putStrFile, _C, _D).

'$$apply_1'(putStrLnFile, _A, putStrLnFile(_A), _B, _B).
'$$apply_1_var'(_A, _B, putStrLnFile(_B), _C, _D):-
        unifyHnfs(_A, putStrLnFile, _C, _D).

'$$apply_1'(contin1, _A, contin1(_A), _B, _B).
'$$apply_1_var'(_A, _B, contin1(_B), _C, _D):-
        unifyHnfs(_A, contin1, _C, _D).

'$$apply_1'(contin2, _A, contin2(_A), _B, _B).
'$$apply_1_var'(_A, _B, contin2(_B), _C, _D):-
        unifyHnfs(_A, contin2, _C, _D).



'$$apply_1'(openFile(_A), _B, _C, _D, _E):-
        '$openFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, openFile(_F), _D, _G),
        '$openFile'(_F, _B, _C, _G, _E).

'$$apply_1'(closeFile, _A, _B, _C, _D):-
        '$closeFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, closeFile, _D, _F),
        '$closeFile'(_B, _C, _F, _E).

'$$apply_1'(end_of_file, _A, _B, _C, _D):-
        '$end_of_file'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, end_of_file, _D, _F),
        '$end_of_file'(_B, _C, _F, _E).

'$$apply_1'(getCharFile, _A, _B, _C, _D):-
        '$getCharFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getCharFile, _D, _F),
        '$getCharFile'(_B, _C, _F, _E).

'$$apply_1'(putCharFile(_A), _B, _C, _D, _E):-
        '$putCharFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putCharFile(_F), _D, _G),
        '$putCharFile'(_F, _B, _C, _G, _E).

'$$apply_1'(putStrFile(_A), _B, _C, _D, _E):-
        '$putStrFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrFile(_F), _D, _G),
        '$putStrFile'(_F, _B, _C, _G, _E).

'$$apply_1'(putStrLnFile(_A), _B, _C, _D, _E):-
        '$putStrLnFile'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, putStrLnFile(_F), _D, _G),
        '$putStrLnFile'(_F, _B, _C, _G, _E).

'$$apply_1'(getLineFile, _A, _B, _C, _D):-
        '$getLineFile'(_A, _B, _C, _D).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, getLineFile, _D, _F),
        '$getLineFile'(_B, _C, _F, _E).

'$$apply_1'(contin1(_A), _B, _C, _D, _E):-
        '$contin1'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, contin1(_F), _D, _G),
        '$contin1'(_F, _B, _C, _G, _E).

'$$apply_1'(contin2(_A), _B, _C, _D, _E):-
        '$contin2'(_A, _B, _C, _D, _E).
'$$apply_1_var'(_A, _B, _C, _D, _E):-
        unifyHnfs(_A, contin2(_F), _D, _G),
        '$contin2'(_F, _B, _C, _G, _E).




