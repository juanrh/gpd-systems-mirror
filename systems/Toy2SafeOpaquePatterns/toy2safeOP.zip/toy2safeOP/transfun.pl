%----------------------------------------------------------------------------%
% transfun.pl
%----------------------------------------------------------------------------%
/*
- Author: Jaime
- Description: Devuelve el codigo asociado a una funcion, a partir del nombre de 
  la funcion.
- Modules which import it: process, initToy.
- Imported modules:
	> dds (con 'tree'): para generar el codigo asociado a una funcion, 
	  se hace a partir del arbol dds asociado a esa funcion.
	> codfun (con 'generateFinalCode'): para devolver el codigo asociado 
	  a una funcion, se llama a generateFinalCode).
	> tools (con 'append', y 'searchVar').
	> outgenerated (con 'fun').

- Modified: 30/09/99 mercedes (Se han comentado los predicados)
	    26/10/99 mercedes (modularizacion).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(transfun,[processFunction/2,extractDestinationType/2,
	  processFunctionCut/2, % Yoli YGR inicio 25/01/2006
	  traslateCheckRules/3,transCheckConstra/4,transCheckExp/4,
	  transCheckWhere/4,change_wheres/4]).
          

:- load_files(dds,[if(changed),imports([tree/3])]).

:- load_files(codfun,[if(changed),imports([generateFinalCode/3])]).

:- load_files(tools,[if(changed),imports([append/3,searchVar/3,tupToArgs/2])]).

:- load_files(newout,[if(changed),imports([fun/4])]).

/* Lo que se hace es cargar inicialmente el fichero newout.pl que contiene el
modulo outgenerated inicial con las exportaciones de los predicados que se van 
a necesitar. Cuando se genere un fichero.out y se cargue (en el modulo compil),
como lo generamos como modulo outgenerated, se borra el modulo outgenerated 
antiguo y se carga este nuevo.
*/

:- load_files(errortoy,[if(changed),imports([isVariable/1])]).

/**************************************************************************
LLAMADA AL MODULO:
	processFunction(
	        +Name: Le pasamos el nombre de la funcion
		-Code:	 Devuelve el codigo asociado a la misma	)

	Este modulo llama a los modulos dds y codfun. Hace el chequeo de la
linealidad de los lados izdos de las reglas y traduce las expresiones de la 
forma '$var'('X') a X, como variable Prolog.


	Ademas incorpora el predicado translateType
		+Tipo de la forma '->'('$var'('A'),'$var'('B'))
		-Tipo de la forma '->'(A,B).

	Las restricciones de la forma R == T se traducen por Rt == Tt que son 
	las expresiones traducidas correspondientes (idem con /=). Los 
	operadores == y /= cuando aparecen en otro contexto se traducen 
	como las funciones eqFun y notEqFun, respectivamente.

**************************************************************************/



/****************************************************************************/
/*			PROCESAMIENTO DE FUNCIONES			    */
/****************************************************************************/


%----------------------------------------------------------------------------%
% processFunction(+Name,-Code): devuelve el codigo de la funcion Name
%----------------------------------------------------------------------------%

processFunction(Name,Code):-
	fun(Name,ArP,Rules,Line),		% buscamos en la BD.
	traslateCheckRules(Rules,RulesT,Warnings),
	trataWarnings(Warnings),
	!,	
	tree(fun(Name,ArP,RulesT,Line),_Pattern,Tree),
	!,	
	name(Name,NameFunS),
	name(NameFun,[36|NameFunS]),   % meto $ delante del nombre de la funcion
	generateFinalCode(Tree,NameFun,Code).

% Yoli YGR 05/12/05 INICIO
% parto de processsFunction 
processFunctionCut(Name,(Name,Tree)):-
	fun(Name,ArP,Rules,Line),		% buscamos en la BD.
	traslateCheckRules(Rules,RulesT,Warnings),
	trataWarnings(Warnings),
	!,	
	tree(fun(Name,ArP,RulesT,Line),_Pattern,Tree),
	!.
%	name(Name,NameFunS),
%	name(NameFun,[36|NameFunS]).   % meto $ delante del nombre de la funcion
% YGR 05/12/05 FIN

	
%----------------------------------------------------------------------------%
% traslateCheckRules(+Rules,-Rulesnuevas,-Warnings)
% Hacemos una traduccion de la entrada para transformar los terminos 
% de la forma '$var'('X') a forma _0F10. Ademas chequea la linealidad
% de las cabezas de las reglas y otros posibles "warnings"
%----------------------------------------------------------------------------%

traslateCheckRules([],[],[]).
traslateCheckRules([Rule|R],[RuleC|Rc],[Warnings1|Warnings2]):-
	translateCheckRule(Rule,RuleC,Warnings1),
	traslateCheckRules(R,Rc,Warnings2).

%----------------------------------------------------------------------------%
% translateCheckRule(+Rule,-Rulenueva,-Warnings)
%----------------------------------------------------------------------------%


translateCheckRule(rule(Head,Body,Constra,Where,Line),
		rule(HeadT,BodyT,ConstraT,WhereT,Line),(Line,L/R)):-

	% inicialmente el Ac de vars esta vacio. En ConstraLin devolvemos las 
	% restricciones anyadidas para conseguir la linealidad
	transCheckHead(Head,ConstraLin,[]/Ac,HeadT,L/L1),
 
	transCheckExp(Body,Ac/Ac1,BodyT,L1/L2),	     	  % Body = expresion
	transCheckConstra(Constra,Ac1/Ac2,ConstraT1,L2/L3),  % Constra = Lista Constras
	append(ConstraLin,ConstraT1,ConstraT),


	% Depu 21/11/00 mercedes
	% Hacemos cambios en el where: cada aparicion de c X1...Xn = e se
	% cambia por X = e	(con X variable nueva)
	%	     X1 = sel(c,1,n,X)
	%	     ....
	%	     Xn = sel(c,n,n,X)
	change_wheres(Where,Where1,1,_ContOut),
	% Fin Depu
	
	
	% Depu 04/10/00 mercedes
	% el where tambien existe
	transCheckWhere(Where1,Ac2/_,WhereT,L3/R).
	% Fin Depu





% Depu 16/11/00 mercedes
% Hacemos cambios en el where: cada aparicion de c X1...Xn = e se
% cambia por X = e	(con X variable nueva)
%	     X1 = sel(c,1,n,X)
%	     ....
%	     Xn = sel(c,n,n,X)

change_wheres([],[],Cont,Cont) :-	
	!.
	
change_wheres([Where|RestWhere],WhereOut,Cont,ContOut) :-
	!,
	change_where(Where,Cont,Cont1,WhereOut1),
	change_wheres(RestWhere,RestWhereOut,Cont1,ContOut),
	append(WhereOut1,RestWhereOut,WhereOut).
	

change_where('='(Lhs,Expr,Line),Cont,Cont,['='(Lhs,Expr,Line)]) :-
	isVariable(Lhs),
	!.
	

change_where('='('$$tup'(Tup),Expr,Line),Cont,ContOut,['='('$var'(Var),Expr,0)|WhereOut]) :-
	!,
	tupToArgs(Tup,Args),
	Lhs=..['$$tup'|Args],
	% nueva variable
	new_where_variable(Cont,Var),
	ContOut is Cont+1,
	functor(Lhs,Name,Arity),
	generateWhereXis(Lhs,Name,Var,1,Arity,WhereOut).


	
change_where('='(Lhs,Expr,Line),Cont,ContOut,['='('$var'(Var),Expr,0)|WhereOut]) :-
	!,
	% nueva variable
	new_where_variable(Cont,Var),
	ContOut is Cont+1,
	functor(Lhs,Name,Arity),
	generateWhereXis(Lhs,Name,Var,1,Arity,WhereOut).




generateWhereXis(_Lhs,_Name,_Var,I,Arity,[]) :-
	I>Arity,
	!.

generateWhereXis(Lhs,Name,Var,I,Arity,
                 ['='(Xi,selectWhereVariableXi(Name,'$int'(I),'$int'(Arity),'$var'(Var))
                                  ,0)|WhereOut]):-
	!,
	arg(I,Lhs,Xi),
	I2 is I+1,
	generateWhereXis(Lhs,Name,Var,I2,Arity,WhereOut).





new_where_variable(Cont,Var) :-
	!,
	name(Cont,ContString),
	append("$NewVarForWhere",ContString,VarString),
	name(Var,VarString).


% Fin Depu


%----------------------------------------------------------------------------%
% transCheckHead(+Head,-ConstraLin,+Ac/-Ac1,-HeadT,+L1/-L2)
% En ConstraLin llevamos la lista de restricciones a�adidas para solventar la
% posible no-linealidad de la cabeza.
% en Ac1 llevamos la lista de pares de las variables simbolicas aparecidas
% con sus correspondientes variables reales asociadas.
% HeadT lleva la traduccion de Head.
% L2 lleva la lista de warnings.
%----------------------------------------------------------------------------%

transCheckHead(Head,ConstraLin,Ac/Ac1,HeadT,L/R):-
	Head=..[Name|Args],
	transCheckArgs(Args,[],ConstraLin,Ac/Ac1,ArgsT,L/R),
	HeadT=..[Name|ArgsT].


%----------------------------------------------------------------------------%
% transCheckArgs(+Args,+ConstraLinIn,-ConstraLinOut,+Ac/-Ac1,-ArgsT,+L/-R)
%----------------------------------------------------------------------------%

transCheckArgs([],ConstraLin,ConstraLin,Ac/Ac,[],L/L).
transCheckArgs([Ar|Rest],ConstraLin,ConstraLin2,Ac/Ac2,[ArT|RestT],L/R):-
	transCheckArg(Ar,ConstraLin,ConstraLin1,Ac/Ac1,ArT,L/L1),
	transCheckArgs(Rest,ConstraLin1,ConstraLin2,Ac1/Ac2,RestT,L1/R).


%----------------------------------------------------------------------------%
% transCheckArg(+Ar,+ConstraLinIn,-ConstraLinOut,+Ac/-Ac1,-ArT,+L/-R)
%----------------------------------------------------------------------------%

transCheckArg('$var'(Name),Constra,Constra1,Ac/Ac1,V,L/R):-
	!,
	searchVar(Name,Ac/Ac1,Var), % En V tenemos la variable encontrada 
				  % o anyadida 
	( 
		var(Var),
		!,
		Constra1=[Var==V|Constra],	% si esta a�adimos una nueva restriccion
	  	L=[(1,Name)|R]
	;
		Var=is_not(V),		% si no estaba no se 
		Constra1=Constra,		% modifican las restricciones (la ha 
	  	L=R                     % metido searchVar) 
	).


% los enteros y los reales se traducen directamente a su valor

% &clpr

%%Antonio (15 Enero,2002) 
%%   Principio
%%Evita la conversion del tipo entero a real!!!!
%%      pues requerimos que los dominios sean distintos para el tratamiento
%%        de las restricciones de dominio finito y las de los reales
%%
%%transCheckArg('$int'(N),Constra,Constra,Ac/Ac,N1,L/L):-!,N1 is float(N).

transCheckArg('$int'(N),Constra,Constra,Ac/Ac,N,L/L):-!.

%%Antonio (15 Enero,2002) 
%%  Fin

%%

transCheckArg('$float'(N),Constra,Constra,Ac/Ac,N,L/L):-!.

	 

transCheckArg(Arg,Constra,Constra1,Ac/Ac1,ArT,L/R):-
	Arg=..[Name|Args],
	transCheckArgs(Args,Constra,Constra1,Ac/Ac1,ArgsT,L/R),
	ArT=..[Name|ArgsT].
		


%----------------------------------------------------------------------------%
% transCheckExp(+Body,+Ac/-Ac1,-BodyT,+L/-R)
% traduccion del cuerpo 
%----------------------------------------------------------------------------%

% los numeros tal cual

%%Antonio (15 Enero,2002) 
%%   Principio
%%Evita la conversion del tipo entero a real!!!!
%%      pues requerimos que los dominios sean distintos para el tratamiento
%%        de las restricciones de dominio finito y las de los reales
%%
%%transCheckExp('$int'(N),Ac/Ac,N1,L/L):-!,N1 is float(N).

transCheckExp('$int'(N),Ac/Ac,N,L/L):-!.

%%Antonio (15 Enero,2002) 
%%  Fin

transCheckExp('$float'(N),Ac/Ac,N,L/L):-!.

%char
transCheckExp('$char'(C),Ac/Ac,'$char'(C),L/L):-!.


transCheckExp('$var'(Name),Ac/Ac1,V,L/R):-
	!,
	searchVar(Name,Ac/Ac1,Var),
	(
		var(Var),
		!,
		V=Var,
		L=R
	;
		Var=is_not(V),
		L=[(2,Name)|R]
	).


transCheckExp(Exp,Ac/Ac1,ExpT,L/R):-
	Exp=..[Name|ArgsExp],
	(	
		Name= '==',
		Name1= '$eqFun'
	;
		Name= '/=',
		Name1= '$notEqFun'
	;
		Name1=Name
	),
	transCheckListExps(ArgsExp,Ac/Ac1,ArgsExpT,L/R),
	ExpT=..[Name1|ArgsExpT].


%----------------------------------------------------------------------------%
% transCheckListExps(+ArgsExp,+Ac/-Ac1,-ArgsExpT,+L/-R)
%----------------------------------------------------------------------------%

transCheckListExps([],A/A,[],L/L).
transCheckListExps([ArgExp|Rest],Ac/Ac2,[ArgExpT|Rr],L/R):-
	transCheckExp(ArgExp,Ac/Ac1,ArgExpT,L/L1),
	transCheckListExps(Rest,Ac1/Ac2,Rr,L1/R).


%----------------------------------------------------------------------------%
% transCheckConstra(+Constra,+AC/-Ac1,-ConstraT,+L/-R)
%----------------------------------------------------------------------------%

transCheckConstra([],Ac/Ac,[],L/L):-!.
transCheckConstra([Exp1 == Exp2 |Rest],Ac/Ac3,[Exp1T == Exp2T|RestT],L/R):-
	!,
	transCheckExp(Exp1,Ac/Ac1,Exp1T,_),
	transCheckExp(Exp2,Ac1/Ac2,Exp2T,_),
	transCheckConstra(Rest,Ac2/Ac3,RestT,L/R).	

transCheckConstra(['/='(Exp1,Exp2)|Rest],Ac/Ac3,['/='(Exp1T,Exp2T)|RestT],L/R):-
	!,
	transCheckExp(Exp1,Ac/Ac1,Exp1T,_),
	transCheckExp(Exp2,Ac1/Ac2,Exp2T,_),
	transCheckConstra(Rest,Ac2/Ac3,RestT,L/R).	


transCheckConstra([Exp|Rest],Ac/Ac2,[ExpT==true|RestT],[(3,Exp)|L]/R):-
	transCheckExp(Exp,Ac/Ac1,ExpT,_),
	transCheckConstra(Rest,Ac1/Ac2,RestT,L/R).


% Depu 04/10/00 mercedes
% Traduccion de los where 
%----------------------------------------------------------------------------%
% transCheckWhere(+Where,+AC/-Ac1,-ConstraT,+L/-R)
%----------------------------------------------------------------------------%

transCheckWhere([],Ac/Ac,[],L/L):-!.
transCheckWhere(['='(Pat,Exp,Lin)|Rest],Ac/Ac3,
                ['='(Pat1,Exp1,Lin) |RestT],L/R):-
	!,
	transCheckExp(Pat,Ac/Ac1,Pat1,_),
	transCheckExp(Exp,Ac1/Ac2,Exp1,_),
	transCheckWhere(Rest,Ac2/Ac3,RestT,L/R).	
% Fin Depu

	
%----------------------------------------------------------------------------%
% extractDestinationType(+Type,-DestinationType)
%----------------------------------------------------------------------------%

extractDestinationType(A,A):-var(A),!.
extractDestinationType('->'(_,B),TD):-
	!,
	extractDestinationType(B,TD).


%----------------------------------------------------------------------------%
%extractDestinationType(num(A),num(A)):-var(A),!,A=float.
%----------------------------------------------------------------------------%

extractDestinationType(A,A).



/****************************************************************************/
/*		      TRATAMIENTO DE LOS WARNINGS			    */
/****************************************************************************/

trataWarnings(_).



/* Esto esta porque antes cuando metian una funcion que no era lineal (tenia 
una variable repetida en el lado izq. de la igualdad), se hacia la traduccion
a una funcion lineal, de esta forma:
f X X = true   se convertia en  f X Y = true <= X==Y
y ademas, se informaba de ello.
Pero ahora, ya no se informa, por eso esto ya no funciona.


trataWarnings([]):-!.
trataWarnings([(Line,L/R)|Rest]):-trataWarnings(Line,L/R),
                                    trataWarnings(Rest).

trataWarnings(_,[]/[]):-!.
trataWarnings(Line,[(1,Name)|L]/R):-
	!,
	nl,
	write('    '),
	write('Warning: Line '),
	write(Line),
	write('. Head not linear in var '),
	writeAtom(Name),
	write('...'),
	trataWarnings(Line,L/R).
	
trataWarnings(Line,[(2,Name)|L]/R):-
	!,
	nl,
	write('    '),
	write('Warning: Line '),
	write(Line),
	write('. Var '),
	writeAtom(Name),
	write(' in the body does not appear in the head of the rule...'),
	trataWarnings(Line,L/R).

%trataWarnings(Line,[(3,Name)|L]/R):-
%	trataWarnings(Line,L/R).



trataWarnings(Line,[(3,Name)|L]/R):-
	!,
	nl,
	write('    '),
	write('Warning: Line '),
	write(Line),
	write('. Incomplete constraint '),
	writeAtom(Name),
	write(' ('),
	writeAtom(Name),
	write(' == true)'),
	write(' in rule...'),
	trataWarnings(Line,L/R).
*/



