%----------------------------------------------------------------------------%
% transtrees.pl
%----------------------------------------------------------------------------%
/* 
- Author: Yoli
- Description: Analiza el �rbol definicional y genera un �rbol nuevo indicando
  d�nde se escribe el corte
- Modules that import it: transfun, initToy.
- Imported modules: 
    > tools (with 'insertLst', 'append' and 'insertAtTheEnd')
    > plgenerated (with 'constr' and 'funct')
    > outgenerated (with 'cdata', 'fun', 'primitive' and 'ftype').

- Modified:
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
:- module(transtrees,[checkCut/6]).

:- load_files(tools,[if(changed),imports([insertLst/3,insertAtTheEnd/3,append/3,member/2])]).
:- load_files(basic,[if(changed),imports([constr/4,funct/5])]).
:- load_files(newout,[if(changed),imports([cdata/4,fun/4,primitive/3,depends/2,   %yoli
          ftype/4])]).
:- load_files(primFunct,[if(changed),imports([primitiveFunct/5])]).

:- use_module(library(terms)).
:- use_module(library(lists)).    %YGR

/************************************************************************
LLAMADA AL MODULO:   (YGR)
    checkCut(
        +LstTrees          % Lista de �rboles generados con el modulo dds.pl
        +lstdepend         % Lista de funciones dependientes
        +LstAnnotates      % Lista de funciones deterministas indicadas por 
                           %     el usuario
        -LstTreetransform  % Lista de �rboles transformados. Se indica el 
                           %     corte en el caso de que sea determinista
        -LstAnnotProg      % Lista de funciones deterministas despu�s de
                           % analizar los �rboles
        -LstFunIndet   )    % Lista de funciones no deterministas
/******************************************************************************/
checkCut(LstTrees,LstDepends,LstAnnot,LstTreesTransform,LstAnnotatesProg, LstFunIndet):-
        transformTrees(LstTrees,LstTreesTransform,LstAnnot,LstFunDetProg,LstFunIndetInicial),
        funNotDeterministic( LstDepends, LstAnnot, LstFunIndetInicial , LstFunIndet),
        generarLstAnnotatesProg(LstFunDetProg,LstFunIndet,LstAnnotatesProg).
        
/************************************************************************/
/* transformTrees(+LstTrees,-LstTreesTransform,+LstAnnot,-LstAnnotatesProg,-LstFunIndetInicial).
   Este predicado se recorre la lista de todos los �rboles definicionales y para cada �rbol realiza
   varias tar�as:
   1� Crea un nuevo �rbol, indicando el lugar de corte si es que se puede introducir corte.
   2� Al analizar el �rbol, ya se puede saber si la funci�n asociada al �rbol es determinista. Esta
      informaci�n la guardamos en la lista 'LstAnnotatesProg' para luego imprimirla en el fichero.pl.
   3� Si al analizar el �rbol, la funci�n resulta no determinista, guardamos esa informaci�n en la lista
      LstFunIndetInicial. En �sta lista, no est�n todas las no deterministas, solo las que resultan del 
      an�lisis del �rbol. Si resulta no determinista, pero el usuario la ha marcado como 
      determinista, se generar� corte, siempre y cuando sea posible.
*/
% la variable Det nos indica si la funci�n es determinista o no en la evaluaci�n mediante programa
transformTrees([],[], _, [], []).
transformTrees([(NameFun,Tree)|Resto],[(NameFun,Det,TreeTrans)|RestoTrans],LstAnnot,
                                               LstAnnotatesProg,LstNoDeterministas):-
        cuttingtree(Tree,ListaRespuestas,TreeTrans,Det), 
        (   member(NameFun,LstAnnot),
            !,
                FunDet = [],
                LstNoDeter1 = []
            ;
               (  Det == false,   % solo si he a unificado a valor false
                  !,
                    FunDet = [],
                    LstNoDeter1 = [NameFun]
                  ; 
                    FunDet = [NameFun],
                    LstNoDeter1 = []
               )
        ),        
        transformTrees(Resto,RestoTrans, LstAnnot, LstDetMan, LstNoDeter2),
        append(FunDet, LstDetMan, LstAnnotatesProg),
        append(LstNoDeter1,LstNoDeter2,LstNoDeterministas)
        .

/**************************************************
  funNotDeterministic(
     +LstDepends: Lista de dependencias
     +LstAnnotates: Lista de funciones deterministas indicadas por el usuario
     +InicialNoDeterministas: Lista de funciones indeterministas. Estas se han obtenido al 
                    analizar el �rbol definicional
     -FinalNodeterministas: Listas de todas las funciones no deterministas. 
        Por ejemplo:
            Si f es una funci�n no determinista y tenemos: g X = f X
            como la funci�n g depende de f, entonces, g es no determinista.
    ).
  Este predicado acumula en FinalNodeterministas todas las funciones no deterministas

******************************************************/
funNotDeterministic(LstDepends,LstAnnotates, InicialNoDeterministas, FinalNodeterministas):-
     
     calcularTodasNDet( LstDepends,LstAnnotates, InicialNoDeterministas, FinalNoD),
     (  same_length(InicialNoDeterministas, FinalNoD), 
           % si tienen la misma longuitud, ya no hay m�s funciones indeterministas
        !,
             FinalNodeterministas = FinalNoD
        ;
             funNotDeterministic(LstDepends,LstAnnotates, FinalNoD, Fin),
             FinalNodeterministas = Fin
     ).


% calcularTodasNDet( +LstDepends,+LstDeterministas, +InicialNoDeterministas, -FinalNodeterministas).
calcularTodasNDet( [],LstAnnotates, InicialNoDeterministas, InicialNoDeterministas).
calcularTodasNDet( LstDepends,LstAnnotates, [], []).
calcularTodasNDet( LstDepends,Annotates, [G|RestoND], FinalNodeterministas):-
    buscarTodasdepends(LstDepends, G, NoDetaux),
    calcularTodasNDet( LstDepends,LstAnnotates, RestoND, NoDet2),
    append(NoDetaux, NoDet2, NoDet3),
    remove_duplicates(NoDet3, FinalNodeterministas).
    
   
%BuscarTodasdepends(+LstDepends, +G, -NoDet1).
buscarTodasdepends([], G, [G]).
buscarTodasdepends([depends(F,H)|RestoDepends] , G, Total):-
    (H==G, 
     !,
          ListaTodas1 = [F]   
     ;
          ListaTodas1 = []
    ),
    buscarTodasdepends(RestoDepends,  G, RestoNoDet),
    append(ListaTodas1, RestoNoDet, Total).

% Es posible que algunas de las funciones determnistas, no lo sea 
% porque depende de otra que es indeterminista.
generarLstAnnotatesProg([],LstFunIndet,[]).
generarLstAnnotatesProg([F|RestoDetProg],LstFunIndet,LstAnnotatesProg):-
    generarLstAnnotatesProg(RestoDetProg,LstFunIndet,RestoAnnotatesProg),
    (member(F,LstFunIndet),
     !,
        LstAnnotatesProg = RestoAnnotatesProg
     ;
        L = [F],
        append(L,RestoAnnotatesProg,LstAnnotatesProg)
     ).
     


% YGR 05/12/05
/******************************************************************************/
%   RAMAS OR Yoli tocado para indicar el corte
/******************************************************************************/
  cuttingtree(or([]),[],[],_):-!. 
  cuttingtree(or([Tree|R]), ListaRespuestas, Arboltransformado, Det):-
      cutListaOr( [Tree|R], [LrTree|LrR], [Ttree|Rt], Det, Corte),
      isListtrys([Tree|R], Valor),
      ListaRespuestas=[LrTree|LrR], 
 
      ( Valor = true,   % Tenemos una lista de Trys
       !, 
          equalVal(ListaRespuestas, Eq),
          (Eq = true, % Todas las alternativas tienen el mismo valor  
             !
          ;
               Det = false     % si no tienen el mismo valor, la funci�n no es determinista
          )
        ;
            true
      ),

      ( Corte = true,      %Los or solo se cortan si la segunda rama 
                                  %tiene respuestas contenidas en la primera rama
       !,
         Arboltransformado = orCut([Ttree|Rt])
       ;
         Arboltransformado = or([Ttree|Rt]) %   Si el Or no corta, el arbol se queda igual.
      )
      .
        
  cutListaOr( [], [], [], _, _):-!.
  cutListaOr( [Tree|R], ListaRespuestas, [Ttree|Rt], Det, Corte):-
        cuttingtree(Tree, LrTree, Ttree, Det1),
        cutListaOr( R, LrR, Rt, Det2, _),
        append(LrTree, LrR, ListaRespuestas),
        (Det1 == false; Det2 == false,
         !,
             Det = false 
         ;
             true 
        ),
        ( content(LrR,LrTree), 
          !,
            Corte = true
          ;
            Corte = false
        )
        .

/***************************************************
%content(+L1,+L2).
%Comprueba que la lista L1 est� contenida en L2,

****************************************************/
content([], L).
content([X|Xs], L):-
     member(X,L),
     content(Xs, L).


/******************************************************************************/
%   RAMAS CASE tocado corte
/******************************************************************************/
cuttingtree(case(Pos,Patron,ListCases),ListaRespuestas, case(Pos,Patron,ListCasesT), Det):-  
                
        !,  % por si las moscas
        cuttingtreeCases(ListCases,ListaRespuestas,ListCasesT, Det)  
        . 

%-----------------------------------------------------------------------------%
% generateCodeCases(+Listacasos,+NameFun,+Pos,-Cod,-Sh)
% Hacemos un recorrido por la lista de casos y devolvemos en una lista el 
% codigo que genera cada uno de ellos
% tocado corte
%-----------------------------------------------------------------------------%
cuttingtreeCases([], [], [], _).
cuttingtreeCases([(V,Tree)|R],ListaRespuestas,[(V,Treetransf)|RT], Det):-
        cuttingtree(Tree,ListaRespuestas1,Treetransf, Det1 ),
        cuttingtreeCases(R, ListaRespuestas2,RT , Det2),
        append(ListaRespuestas1,ListaRespuestas2,ListaRespuestas),
        (Det1 == false; Det2 == false,
         !,
            Det = false
         ;
            true 
         )
        .
          
/******************************************************************************/
%   RAMAS TRY
/******************************************************************************/
cuttingtree(try(Patron,Alts),ListaRespuestas, TryTr, Det):-
         
         cuttingtreeAlts(Patron,Alts,AltsTr ),   %Try yoli
         Alts=[Alt1|RestoAlts],   % realmente, �sto sobra, 
                        % porque no vamos a tener m�s de una alternativa
                        % en un Try.
         siValoresAltIguales(Alts, ListaRespuestas, ValEq),   % si ValEq = true -> cortamos
         (RestoAlts=[], 
           !,
           % si solo hay una alternativa, no escribo c�digo de corte   
           TryTr = try(Patron,AltsTr)  %Try yoli 
           ;
           % Tenemos varias alternativas, miramos si tienen el mismo valor.
           % Si tienen el mismo valor, cortamos06/10/2005
             (ValEq =true,
              !,
                TryTr = tryCorte(Patron,AltsTr)     %Cortamos
              ;  
                TryTr = try(Patron,AltsTr),   %Try yoli no cortamos
                Det = false                    % La funci�n es no determinista
              )
          ).

%generateCodeAlts(+Patron,+Alts,-AltsTransf)
cuttingtreeAlts(_,[],[]).   %Try yoli


cuttingtreeAlts(Patron,[si(Constr,Val,Where)|RestoAlts],[AltTr|Rt]):-
      cuttingtreeAlt(Patron,si(Constr,Val,Where),AltTr),
      cuttingtreeAlts(Patron,RestoAlts,Rt)                                 %Try yoli
    .   


cuttingtreeAlt(Patron,si(Constr,Val,Where),AltTr):-
      % Miramos si hay variables existenciales en las condiciones
      % Si es as�, introducimos c�digo asociado al corte.
      % En Le introducimos las variables de Args + las de e (sin repetici�n)

      variablesExistenciales(Patron,si(Constr,Val,Where),Le,Lex),
      % Si hay variables existenciales se introduce c�digo de corte
      (Lex=[],
       !,
           AltTr = si(Constr,Val,Where)  %no hay variables existenciales, luego no hay corte
       ;
           AltTr = siCut(Constr,Val,Where)
       )
    .

%-----------------------------------------------------------------------------%
% substituteArgList(+Lst,+Pos,+ArgNew,-Arg,-LstNew)
% Reemplaza en una lista de terminos, la posicion Pos, que contiene una 
% termino Arg por un nuevo ArgNew. La nueva lista se devuelve en LstNew.
%-----------------------------------------------------------------------------%

substituteArgList([V|Rar],[1],NV,V,[NV|Rar]):-!.  

substituteArgList([Ar|Rar],[1|Rpos],NV,V,[Nar|Rar]):-
    !,
    Ar=..[Name|Args],
    substituteArgList(Args,Rpos,NV,V,Args1),
    Nar=..[Name|Args1].

substituteArgList([Ar|Rar],[N|Rpos],NV,V,[Ar|Rar1]):-
    N1 is N-1,
    substituteArgList(Rar,[N1|Rpos],NV,V,Rar1).

%-----------------------------------------------------------------------------%
% variablesTerm(+Term,+Vin/-Vout)
% saca la lista de variables distintas de un termino ordenadas por orden de 
% aparicion en dicho termino
%-----------------------------------------------------------------------------%

variablesTerm(T,Vin/Vout):-
    var(T),
    !,
    insertVar(T,Vin/Vout).
variablesTerm(T,Vin/Vout):-
    T=..[_|Args],
    variablesList(Args,Vin/Vout).
    
%-----------------------------------------------------------------------------%
% variablesList(+List,+Vin/-Vout)
% saca la lista de variables distintas de la lista Lista ordenadas por orden de 
% aparicion en dicha lista.
%-----------------------------------------------------------------------------%

variablesList([],Vin/Vin).
variablesList([H|R],Vin/Vout):-
    variablesTerm(H,Vin/Vout1),
    variablesList(R,Vout1/Vout).

%-----------------------------------------------------------------------------%
% insertVar(+Var,+Listin/-Listout)
% inserta en la lista la variable Var si esa variable no aparecia en la lista.
% Si ya aparecia, deja la lista igual.
%-----------------------------------------------------------------------------%

insertVar(V,[]/[V]).
insertVar(V,[H|R]/[H|R]):-
    V==H,!.
insertVar(V,[H|R]/[H|R1]):-
    insertVar(V,R/R1).







% Depu 05/10/00 mercedes
extract_left_hand_side_Where([],Args,Args) :- 
    !.

extract_left_hand_side_Where(['='(Var,_Expr,_Lin)|R],Args,[Var|LOut]) :-
    !,
    extract_left_hand_side_Where(R,Args,LOut).

% Fin Depu


  

        
/**********************************************************************************/

 %   variablesExistenciales(+Patron,+si(Constr,Val,Where),-Le,-LExistenciales):-
     variablesExistenciales(Patron,si(Constr,Val,Where),Le,Lexist):-
 
      % f(s)=e <= C

      Patron=..[_|Args],

      variablesTerm(Args,[]/LstVarsF),                 %variables de la cabeza f(s),
      variablesTerm(Constr,[]/LstVarsC),               %variables de las Condiciones,
      variablesTerm(Val,[]/LstVarsVal),                %variables del cuerpo e
      existenciales(LstVarsF,LstVarsC,LstVarsVal,Lexist),
      append(LstVarsF,LstVarsVal,Le1),
      remove_duplicates(Le1,Le).

    
%----------------------------------------------------------------------%
%     yoli Comprueba si hay vriables existenciales
%..--------------------------------------------------------------------%
      existenciales(Lf,[],Lv,[]).
      existenciales(Lf,[X|Xs],Lv,[X|Ys]):-
             non_member(X,Lf), 
             non_member(X,Lv),
             existenciales(Lf,Xs,Lv,Ys).
      existenciales(Lf,[X|Xs],Lv,Le):-
             existenciales(Lf,Xs,Lv,Le).
%------------------------------------------------------------------------------%
%------------------------------------------------------------------------------%
%------------------------------------------------------------------------------%
%------------------------------------------------------------------------------%
%------------------------------------------------------------------------------%
/*************************************************************************************/
 %siValoresAltIguales(+Alts, -LSinDup, -ValEq):-
  siValoresAltIguales(Alts,LSinDup,ValEq):-
         valAlternativas(Alts,LValores),
         remove_duplicates(LValores,LSinDup),
         LSinDup = [X|Xs],
         (Xs=[],
           !,
            ValEq = true        %Solo hay un valor para las alternativas, cortamos
           ;
            ValEq = false    %no cortamos
         ).

 equalVal(LVal, ValEq):-
    remove_duplicates(LVal,LSinDup),
         LSinDup = [X|Xs],
         (Xs=[],
           !,
            ValEq = true        %Solo hay un valor para las alternativas, cortamos
           ;
            ValEq = false    %no cortamos
         ).

           


%predicado de devuelve una lista con todos los valores de las alternativas
  valAlternativas([],[]).
  valAlternativas([si(Constr,Val,Where)|RestoAlt], [Val|Vr]):-
     valAlternativas(RestoAlt,Vr).




doListFundepend([],LstDepends,[]).
doListFundepend([(NameFun,Tree)|Resto],LstDepends,[(NameFun,LDep)|RestoFunDepends]):-
      listaDependientes(NameFun,LDep), 
    doListFundepend(Resto,LstDepends,RestoFunDepends).

listaDependientes(NameFun,L):- setof(Y,depend(NameFun,Y),L).


isListtrys([], true).

isListtrys([try(Patron,Alts)|R], Valor):- 
         !,
         isListtrys(R, Valor).
         
isListtrys([Tree|R], false):- !.



