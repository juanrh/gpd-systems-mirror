
%----------------------------------------------------------------------------%
% gramma_dcg.pl
%----------------------------------------------------------------------------%
/*
- Author: Rafa Caballero
- Fecha: 05-04-1996 
- Description: Gramatica del lenguaje, incluyendo comprobationes semanticas y 
  salida de codigo intermedio.
  Las tablas de simbolos estan ocultas, pero se pasan de produccion en 
  produccion y pueden referenciarse por el nombre 'Tablescomp'. Toda referencia 
  a clausulas Prolog en la gramatica se hace mediate la clausula 'comprobation'.
- Fecha de actualizacion: 29-11-99
- Modified:
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% --------------------------------------------------------------------------
%                            S E C C I O N E S
% --------------------------------------------------------------------------
% el componente b�sico es la secci�n
section(Rep)           --> separator("{"),topdecls(Rep).

% posibles declaraciones de 'primer nivel'. Al menos una
topdecls([One|Rest])  --> !, topdecl(One), resttopdecls(Rest).
resttopdecls([One|R]) --> separator(";"),!,topdecl(One),resttopdecls(R).
resttopdecls([])      --> !,separator("}").

% una declaraci�n simple de primer nivel puede ser:

% una secci�n data
topdecl(data(Data,List,L)) -->
                           reserved(data,L), !, typeLhs(Data),
                           separator("="), constrs(List).
% una declaraci�n de tipo
topdecl(type(Type,List,L)) -->
                           reserved(type,L), !, typeLhs(Type),
                           separator("="), type(List).

% una declaraci�n de prioridades y asociatividad de operatores
topdecl(S)             --> operdecl(S),!.

% una declaraci�n de primitiva
topdecl(primitive(Prims,Type,L)) -->
                           reserved(primitive,L), !, prims(Prims),
                           separator("::"), type(Type).

% una declaraci�n cualquiera
topdecl(S)             --> decls(S),!.

% un subtipo ???????
% topdecl(subtypes)      --> reserved(subtypes),!.

% un include
topdecl(include(Chain))  --> reserved(include),!,chain(Chain).

%%::B AF
% un includecflpfd
topdecl(includecflpfd(Chain))  --> reserved(includecflpfd),!,chain(Chain).
%%::E

% una seccion
topdecl(S)		--> section(S).

% ----- Declaraciones auxiliares

% prims es una o m�s prim
prims([One|R])         --> prim(One),!,restprims(R).
restprims([One|R])    --> separator(","),!,prim(One),restprims(R).
restprims([])         --> !,[].

% un prim es una funci�n seguida de una cadena
% prim(S)                --> fun(Fun),!,chain(Chain),{ S=..(Fun,Chain)}.
% 23/07/96 Se elimina la cadena detras del nombre de funcion
prim(S)                --> fun(S),!.

%decls es una lista de una o m�s declaraciones
decls([One|R])         --> decl(One),!,restdecls(R).
restdecls([One|R])    --> separator(";"),!,decl(One),restdecls(R).
restdecls([])         --> !,[].

% una declaraci�n es:
decl(S)                --> typedecl(S),!.
decl(S)                --> funrule(S),!.
decl(S)                --> clause(S),!.

% 29-11-99 No sabemos paque vale esto, pero molesta: 
% se traga (si quitamos el comentario) X : Y = 0 (!!!)
% decl(S)                --> patbinding(S),!.

% delaraci�n de prioridad y asociatividad para un conjunto de operatores
operdecl(infix(ListOp,Asoc,Pri,L) ) -->
                           infixdecl(ListOp,Asoc,Pri,L),!.

% declaraci�n de operator infijo
infixdecl(O,noasoc,P,L)--> reserved(infix,L), !, integer(P), listops(O).
infixdecl(O,left,P,L)  --> reserved(infixl,L),!, integer(P), listops(O).
infixdecl(O,right,P,L) --> reserved(infixr,L),!, integer(P), listops(O).

% una lista de operatores, al menos uno
listops([One|R])      --> op(One),!,restlistops(R).
restlistops([One|R]) --> separator(","),!,op(One),restlistops(R).
restlistops([])      --> !, [].

% --------------------------------------------------------------------------
%                                T I P O S
% --------------------------------------------------------------------------

% parte izquierda de una declaraci�n de tipos (tras el "data")
typeLhs(S)             --> !, typesym(Const),listvarsym(List),
                           {S=..[Const|List]}.

% parte de la derecha de una declaraci�n de tipos. Lista de construcciones
constrs([One|R])       --> !, constr(One),restconstrs(R).

% una construcci�n simple, bien con constructora infija o prefija
constr(S)              --> type(T1), conop(Const),!, type(T2),
                          { S =.. [Const,T1,T2] }.

constr(S)              --> !,con(Const), listtypesimp(List), %%% AQUI AQUI
                          { S =.. [Const|List] }.

type(S)                --> ctype(T1),separator("->"),!,type(T2),
                          {S =.. ['->',T1,T2] }.

type(S)                --> !, ctype(S).



% un tipo sencillo
% paco 14/11/96
% ctype(S)               --> typesym(Const), !, listctype(List), 
% rafa 22/06/1998 Creo que los `argumentos' de dtras de un nombre de
% tipo deben devolverse separadamente. Ej. par A B debe ser par(A,B) y
% no par(A(B))

ctype(S)               --> typesym(Const), !, listtypesimp(List), 
                           {S=..[Const|List]}.

ctype(S)               --> !,atype(S).


%% AQUI AQUI % paco 14/11/96
% un tipo simple
typesimp(Const)        --> typesym(Const),!.
typesimp(S)               --> !,atype(S).


%% AQUI AQUI % paco 14/11/96
%listtypesimp: 0 o mas types simples sin separatores
listtypesimp([One|R])     --> typesimp(One),!,listtypesimp(R).
listtypesimp([])          --> !,[].
 
 
%% AQUI AQUI % paco 14/11/96
%listctype: 0 o mas ctypes sin separatores
listctype([One|R])     --> ctype(One),!,listctype(R).
listctype([])          --> !,[].
 


% el tipo, sin m�s
atype(S)               --> varsym(S),!.

% rafa 10/07/97. The name of the type is '$unit' but it was wrotten 'unit' here
%atype('$unit')        --> separator("("),separator(")"),!.

atype((S))             --> separator("("),type(S),separator(")"),!.
% tipo lista
atype(':'(S,[]))       --> separator("["),type(S),separator("]"),!.

% tuple : two or more elements of whatever types
atype('$$tuple'((E1,S)))  --> separator("("),
			   type(E1), separator(","),type(E2),!,
			   resttupleatype(E2,S).



% ------ declaraciones auxiliares

% listvarsym = 0 o m�s varsym. sin "," entre medias
listvarsym([One|R])   --> varsym(One),!, listvarsym(R).
listvarsym([])        --> !,[].

% restconstr: Leer una lista de 0 o m�s construcciones, cada una precedida de |
restconstrs([One|R])  --> separator("|"),!,constr(One),restconstrs(R).
restconstrs([])       --> !,[].

% listtype: 0 o mas types sin separatores
listtype([One|R])     --> type(One),!,listtype(R).
listtype([])          --> !,[].

% listatype: 0 o mas atypes sin separatores
listatype([One|R])    --> atype(One),!,listatype(R).
listatype([])         --> !,[].

% the remainder of the tuple. At least the  ")".
resttupleatype(E,(E,S)) --> separator(","), !, type(E2),resttupleatype(E2,S).
resttupleatype(E,E)     --> separator(")"),!.



% --------------------------------------------------------------------------
%  D E C L A R A C I O N   D E   F U N C I O N E S   Y   P R E D I C A D O S
% --------------------------------------------------------------------------

% declaraci�n del tipo de una funci�n
typedecl(ftype([U|R],T,L))--> !, fun(U), restlistfun(R),
                              separator("::",L), type(T).

% declaraci�n de una regla de funci�n
funrule(rule(Head,Body,Cond,Whe,HeadSep,Lin))-->
                           ruleLhs(Head), endHead(HeadSep,Lin),!, exp(Body),
                           conditionrule(Cond), where(Whe).

%--------------------------------------------
% 03-01-00
% separador entre la cabeza y el cuerpo de la regla:
% hasta ahora solo el =. A partir de ahora ademas se puede usar -->
endHead("=",Lin)          -->  separator("=",Lin),!.
endHead("-->",Lin)        -->  separator("-->",Lin),!.


%---------------------------------------------
% parte izquierda de la declaraci�n de funci�n

% declaraci�n infija con '
ruleLhs(S)             --> apat(One),funop(Ope),apat(Two),{S=..[Ope,One,Two]},!.

% nombre de funci�n seguido de argumentos
ruleLhs(S)             --> fun(Fun), !, succapat(List), {S=..[Fun|List]}.

% 23-11-99: Mercedes, Rafa, Paco: Quitamos la declaracion de secciones.
% La culpa es de Paco.
% declaraciones estilo secci�n
% ruleLhs('$sect_left'(U,V)) --> separator("("), pat(V),funop(U),separator(")") ,!.
% ruleLhs('$sect_right'(U,V)) --> separator("("),funop(U),pat(V),separator(")") ,!.


% declaraci�n infija con patrones detras (para poder declarar el '.')

% 30-11-99 mercedes & rafa. 
% Ponia: pat(One), funop(Ope),pat(Two)
% DEBE PONER: apat(One), funop(Ope),apat(Two)
%
ruleLhs(S)             --> separator("("), 
			   apat(One), funop(Ope),apat(Two),
			    separator(")"), succapat(List),
			   {S=..[Ope,One,Two|List]},!.

%---------------------------------------------

% condici�n
conditionrule(S)       --> separator("<=="),!,condition(S).
conditionrule([])      --> !, [].       % condici�n vacia


% cla�sula where
where(S)               --> reserved(where), !,
                           separator("{"),declsWhere(S),separator("}").
where([])              --> !,[].

% Depu 03/10/00 mercedes
declsWhere([H|R])      -->  patbinding(H), !, restdeclsWhere(R).

restdeclsWhere(R)      --> separator(";"), !, declsWhere(R).
restdeclsWhere([])     --> !, [].   

% Fin Depu

%  la condici�n no es otra cosa que una expresi�n.
atom(S)                --> !,exp(S).

% cla�sulas tipo Prolog
clause(clause(Head,Cond,Whe,Lin)) -->
                           ruleLhs(Head),separator(":-",Lin), !,
                           condition(Cond), where(Whe).

patbinding('='(U,V,Lin)) -->
                        pat(U), separator("=",Lin), !, exp(V).

% ----- definiciones auxiliares

% condici�n en general
condition([One|R])     --> !, atom(One),restlistatom(R).


% Depu 27/10/00 mercedotas
% Para permitir leer del usuario objetivos con where
conditionWhere(where([One|R],Whe)) --> !, atom(One),restlistatom(R), where(Whe).

% Fin Depu


% restlistfun: 0 o m�s funciones, cada una precedida de una ","
restlistfun([One|R]) --> separator(","), !, fun(One), restlistfun(R).
restlistfun([])      --> !, [].


% restlistatom: 0 o m�s atomos, cada una precedida de una ","
restlistatom([One|R])--> separator(","), !, atom(One), restlistatom(R).
restlistatom([])     --> !, [].


% succapat: Sucesi�n de 0 o m�s apat, no separados por nada
succapat([One|R])      --> apat(One), succapat(R).
succapat([])           --> !,[].



% --------------------------------------------------------------------------
%   F U N C I O N E S,  C O N S T R U C T O R A S   Y  O P E R A D O R E S
% --------------------------------------------------------------------------

% nombre de una funci�n, prefija o infija
fun(S)                 --> funsym(S),!
                         | separator("("),funopsym(S),separator(")"),!.


% nombre de una constructora: prefija o infija
con(S)                 --> consym(S),!
                         | separator("("),conopsym(S),separator(")"),!.


% para los casos en los que puewde aparecer una funcion o una constructora
% si el primer token es un identifier no sabemos cual de las dos es,
% y 'confunsym' se encarga de anotar que puede ser cualquiera de las dos
cons_or_func(S)         -->  confunsym(S), !
                          | fun(S), !
                          | con(S), !.

% operatores �nfijos: tipo funci�n o constructora
op(S)                  -->( funop(S)
                         |  conop(S) ),!.

% un operator infijo de funci�n es un operator o una funci�n entre ``
funop(S)               --> funopsym(S),!
                         | separator("`"),funsym(S),separator("`"),!.

% una constructora infija es un operator de construcci�n o una construc entre ``
conop(S)               --> conopsym(S),!
                         | separator("`"),consym(S),separator("`"),!.



% --------------------------------------------------------------------------
%                            E X P R E S I O N E S
% --------------------------------------------------------------------------

% LET
exp(S)            --> reserved(let), !,
                      separator("{"), decls(U), separator("}"),
                      reserved(in), exp(V),
                      { S =.. [let,U,V]}.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DO %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 01/06/00 mercedes       
exp(do(V,P))	--> reserved(do),!,
                    separator("{"),
                    declsDo(D), 
                    separator("}"),
                    {unzip(D,V,P),
                     all_distint(V)}.  
                                      
declsDo([One|R]) --> declDo(One),!,restdeclsDo(R).

restdeclsDo([One|R]) --> separator(";"), !, declDo(One), restdeclsDo(R).
restdeclsDo([])      --> !,[].

declDo((V,P))        --> varsym(V),!, separator("<-"), exp(P).
declDo(('$var'(_),P))   --> !,exp(P).


% unzip(+L,+E,-L1,-L2)
% Convierte la lista de pares L=[(Vi,Pi)] en dos listas L1 = [Vi] y L2=[Pi] 
% Ademas  R aparece al final de L2

unzip( [(V,R)], [], [R]):-!.
unzip( [(V,P) | Ls], [V|Vs],[P|Ps]) :- !, unzip(Ls,Vs,Ps).


all_distint([]):- !.
all_distint([V|R]):- \+ member(V,R),all_distint(R).



% member(G,[F|L]):-(G==F,!;member(G,L)).


/*           
exp(do(V,P))	--> reserved(do),!,
                    separator("{"),
                    declsDo(D), 
                    exp(R),
                    separator("}"),
                    {unzip(D,R,V,P)}.  
                                      
declsDo([One|R]) --> declDo(One),!,restdeclsDo(R).

restdeclsDo([One|R]) --> separator(";"), !, declDo(One), restdeclsDo(R).
restdeclsDo([])      --> !,[].

declDo((V,P))        --> !, varsym(V), separator("<-"), exp(P).


% unzip(+L,+E,-L1,-L2)
% Convierte la lista de pares L=[(Vi,Pi)] en dos listas L1 = [Vi] y L2=[Pi] 
% Ademas  R aparece al final de L2

unzip( [], R, [], [R]):-!.
unzip( [(V,P) | Ls], R, [V|Vs],[P|Ps]) :- !, unzip(Ls,R,Vs,Ps).
*/



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% IF
% OJO: si alguna vez se quiere pone el if_then_else como predef.
% cambiar '$apply'(if_then_else, , ,) por if_then_else( , , )
exp('$apply'(if_then_else,[Condition,Then,Else]))
			--> reserved(if),   exp(Condition),
                            reserved(then), exp(Then),
                            reserved(else), exp(Else),
% como no esta predefinida, lo apuntamos como una referencia a una funcion
                            {comprobation(Tablescomp,ref,func(if_then_else))},
                            !.

exp('$apply'(if_then,[Condition,Then]))
			 --> reserved(if),   exp(Condition),
                             reserved(then), exp(Then),
% como no esta predefinida, lo apuntamos como una referencia a una funcion
                            {comprobation(Tablescomp,ref,func(if_then))},
                            !.

% expresiones con operatores
exp(S)                 --> opExp(U),!,after_exp(U,S).

% expresiones con tipo expl�cito
after_exp(U,exp_typed(U,V))   --> separator("::"),!,opExp(V).

% en otro caso no hab�a tipo expl�cito
after_exp(U,U)          --> !.

% expresiones infijas
opExp(Rep)             --> !,opExp(-1,Rep).
opExp(Op,Rep)          --> pfxExp(V),!,subterm(Op,V,Rep).
subterm(Op,Left,Rep) --> op(Op2),
                           % hay que asegurarse de que la nueva prioridad es >
                          {comprobation(Tablescomp,smaller_priority,(Op,Op2,E))},
                           % si hay error de prioridades obligar a fallar
                           {(E=true,!,fail; true)},
                           !,
                           opExp(Op2,Right),
                           % construimos el nuevo t�rmino izquierdo
			   % de la forma '$apply'(Op2,Left,Right)
 %                          { functor(NewLeft,Op2,2),
                           { functor(NewLeft,'$apply',2),
                            arg(1,NewLeft,Op2),
                            arg(2,NewLeft,[Left,Right])},
                            subterm(Op,NewLeft,Rep).
subterm(_,Term,Term)--> !.

% aqu� est�n las definiciones de 'expresiones prefijas'
pfxExp(uminus(V))     --> op(-),!,appExp(V).
pfxExp(V)             --> !,appExp(V).

% apply. debe ir antes de la segunda cla�sula
appExp(S)             --> atomic(U),atomic(V),restappExp(List),
                          !,{S =.. ['$apply',U,[V|List]]}.
% sin apply
appExp(S)             --> atomic(S),!.

% resto de apply que queda por tratar. Asociamos a la izquierda
restappExp([U|Rest])--> atomic(U),!,restappExp(Rest).
restappExp([])       --> !.

% definimos lo que consideramos �tomos
% �tomos simples
atomic(V)             -->( varsym(V)
                        |  fun(V)
                        |  con(V)
                        |  integer(V)
                        |  decimal(V)
                        |  character(V)
                        |  chain(V) ),!.

% expresiones con ()
atomic('$unit')       --> separator("("), separator(")"),!.
atomic(V)             --> separator("("), exp(V), separator(")"),!.

% secciones
% OJO: A partir de ahora las secciones tienen una primera traduccion aqui mismo
/*
atomic('$sect_left'(U,V)) --> separator("("),atomic(V), op(U), separator(")") ,!.
atomic('$sect_right'(U,V)) --> separator("("),op(U), atomic(V), separator(")") ,!.
*/

% (3 *) se traduce a '$apply'(*,[3])
atomic('$apply'(U,[V]))		--> separator("("),
				    atomic(V), op(U), 
				    separator(")") ,!.

% (* 3) se traduce a '$apply'(flip,[*,3])
atomic('$apply'(flip,[U,V])) 	--> separator("("),
				    op(U), atomic(V),
				    separator(")") ,!.


% tuplas
atomic('$$tup'((E1,S))) --> separator("("),exp(E1),separator(","), !,
                       		exp(E2),resttuple(E2,S).
% listas
atomic([])            --> separator("["),separator("]"),!.
atomic(S)             --> separator("["),exp(One),restlist(1,[One],S),!.


% ------ declaraciones auxiliares
% componentes que faltan por leer de una tupla. Al menos falta el ")"
resttuple(E,(E,S))  --> separator(","),!,exp(E2),resttuple(E2,S).
resttuple(E,E)       --> separator(")"),!.

% leer el interior de una lista. S�lo se ha le�do "[" y un elemento de la lista
% secuencias
restlist(1,[U],S)  --> separator(".."),separator("]"),!,{ S =..['$secu1',U] }.
restlist(1,[U],S)  --> separator(".."),exp(Lim),separator("]"),!,
                         { S =.. ['$secu1lim',U,Lim] }.
                         
                         
% 08/06/00 mercedes: introduccion de las listas intensionales en TOY

%%%%%%%%%%%%%%%%%%%%%%%% LISTAS INTENSIONALES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% listas intensionales
restlist(1,[U],intensional(U,Q))  --> separator("||"),!, quals(Q,LV),
				      {all_distint(LV)}.
				      

% parte derecha de una lista intensional. One lista con al menos un elemento
quals([One|R],[V|RV])       --> qual(One,[V]) ,!, restoquals(R,RV).

restoquals([One|R],[V|RV])  --> separator(","),qual(One,[V]),!, restoquals(R,RV).
restoquals([],[])       --> separator("]"), !.


% cada elemento de los que pueden aparecer a la derecha de una lista 'guardada'
qual('<-'(U,V),[U])      --> varsym(U), separator("<-"), !, exp(V).
                         
qual('=='(U,V),['$var'(_)])       --> pat(U), separator("=="), !, exp(V).
                         
qual(S,['$var'(_)])              --> !,exp(S).



/* Esto es lo que habia hecho rafa para las listas intensionales
% listas intensionales
restlist(1,[U],S)  --> separator("||"),!, quals(Q),{S=..['$intensional',U,Q]}.

% parte derecha de una lista intensional. One lista con al menos un elemento
quals([One|S])       --> qual(One) ,!, restoquals(S).
restoquals([Other|S]) --> separator(","),qual(Other),!, restoquals(S).
restoquals([])       --> separator("]"), !.

% cada elemento de los que pueden aparecer a la derecha de una lista 'guardada'
qual(S)              --> pat(U), separator("<-"), !, exp(V),
                         { S =.. ['<-',U,V] }.
qual(S)              --> pat(U), separator("="), !, exp(V),
                         { S =.. ['=',U,V] }.
qual(S)              --> !,exp(S).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% se encuentra otro elemento de la lista. Pasamos a restlist(2
restlist(1,[U],S)  --> separator(","),exp(V),restlist(2,[U,V],S),!.

% en otro caso 'saltamos' a las listas normales
restlist(1,L,S)    --> !, normal_list(L,S).

% ya van dos elementos leidos de la lista (algo de la forma [U,V
restlist(2,[U,V],S)--> separator(".."),separator("]"),!,{S =.. ['$secu2',U,V]}.
restlist(2,[U,V],S)--> separator(".."),exp(Lim),separator("]"),!,
                         { S =.. ['$secu2lim',U,V,Lim] }.

% paso el peligro, a partir del segundo elemento seguro que es una lista normal
restlist(2,L,S)    --> !,normal_list(L,S).


% tratamiento de una lista normal

% si ya viene de haber leido un elemento
normal_list([One],':'(One,L)) --> !,normal_list(L).

% si viene tras haber leido dos elementos
normal_list([One,Two],':'(One,':'(Two,L)) ) --> !,normal_list(L).
normal_list(':'(Other,S))--> separator(","),!,exp(Other),normal_list(S).
normal_list(List)   --> separator("|"),!,exp(List),separator("]").
normal_list([])      --> separator("]"),!.



% --------------------------------------------------------------------------
%                            P A T R O N E S
% --------------------------------------------------------------------------
% con constructoras y patrones (n+k)
pat('$n+k'(Var,Ent))  --> varsym(Var),op(+),integer(Ent),!.

% 23-11-99
% Rafa, Paco, Mercedes
% Un patron (n+k) debe ser 'Var + integer'. El restpat sobra y  lo comentamos: 
%                         restpat(+(Var,Ent),S).

pat(S)               --> exp(S),!.

/* 29-11-99 mercedes: a partir de ahora consideramos que los pat son exp y
luego el analisis de patrones se realiza en compil, i.e., cuando se compilen
las expresiones, en la segunda pasada se comprueba si la exp es un patron o no.

 pat(S)               --> !,appPat(U),restpat(U,S).

%{paco} 21-11-96
% Mercedes, Rafa, Paco: Incluimos la posibilidad de operatores infijos en los patrones
% OJO: Aqui no se comprueba que relamente son patrones (pueden ser exp. evaluables)
restpat(U,S)        --> op(Constr),!,pat(Pat),{S=..[Constr,U,Pat]}.

restpat(U,S)        --> conop(Constr),!,pat(Pat),{S=..[Constr,U,Pat]}.

restpat(S,S)        --> !,[].
% Lista de uno o m�s patrones simples. Los devuelvo con apply
% A no ser que sea s�lo uno
appPat(U)            --> apat(U),restappPat(S),{S==[]},!. % s�lo un apat.
appPat(S)            --> !,apat(U), apat(V),restappPat(List),
                         {S =.. ['$apply',U,[V|List]]}.

% lista de 0 o m�s apat sin separatores enmedio
restappPat([U|S])   --> apat(U),!,restappPat(S).
restappPat([])      --> !,[].

*/

%--------------------------------------------------

% 09/1997 patrones as
apat('$as'(V,P))    --> varsym(V),separator("@"),!,apat(P).




 
% patrones simples
% ojo 8-07-1996: Cambio la posilibilidad de 'con' o 'fun' por la posibilidad
% conjunta 'con_o_fun'. La diferencia es que esta ultima guarda como referencia
% 'cons_or_func' en lugar de 'cons' que era lo que guardaba hasta ahora

apat(S)              --> (varsym(S)
%                       |  con(S)
%                       |  fun(S)
                       |  cons_or_func(S)
                       |  integer(S)
		       |  decimal(S)
                       |  character(S)
                       |  chain(S) ),!.

% secciones, tuplas y listas
% apat('$unit')          --> separator("("), separator(")"),!.


apat(V)                --> separator("("), pat(V), separator(")") ,!.

% tuplas
apat('$$tup'((E1,S)))   --> separator("("),pat(E1),separator(","),pat(E2),
                               resttupleapat(E2,S),!.


% 23-11-99: Mercedes, Paco, Rafa
% cambiamos la traduccion dce las secciones izq. y der. para hacerlas
% compatibles con el caso de las expr. (es decir, ya no se usa $sect_left,
% $sect_right sino que se traduce directamente)

% (3 *) se traduce a '$apply'(*,[3])
apat('$apply'(U,[V])) --> separator("("), pat(V), op(U), separator(")") ,!.

% (* 3) se traduce a '$apply'(flip,[*,3])
apat('$apply'(flip,[U,V])) --> separator("("),op(U), pat(V), separator(")") ,!.


% listas
apat([])               --> separator("["),separator("]"),!.
apat(':'(One,S))       --> separator("["),pat(One),restlistapat(S),!.



% ----- declaraciones auxiliares
% componentes que faltan por leer de una tupla. Al menos falta el ")"
resttupleapat(E,(E,S))--> separator(","), !, pat(E2),
                           resttupleapat(E2,S).
resttupleapat(E,E)    --> separator(")"),!.

% componentes que faltan por leer de la lista de apat. Al menos el ]
restlistapat(':'(One,S))--> separator(","),!,pat(One),restlistapat(S).
restlistapat(List)  --> separator("|"),!,apat(List),separator("]").
restlistapat([])     --> separator("]"),!.


% --------------------------------------------------------------------------
%                 V A R I A B L E S   Y   O P E R A D O R E S
% --------------------------------------------------------------------------
% variables y operatores
varsym(V)             --> variable(V).

typesym(V)	      --> reservated_type(V).

% en las dem�s, indicar que se est� haciendo una referencia a un objeto
typesym(V)            --> identifier(V), !,
                          {comprobation(Tablescomp,ref,type(V))}.

consym(V)             --> identifier(V), !,
                          {comprobation(Tablescomp,ref,cons(V))}.

conopsym(V)           --> constructor(V) , !,
                          {comprobation(Tablescomp,ref,cons(V))}.

confunsym(V)          --> identifier(V) , !,
                          {comprobation(Tablescomp,ref,cons_or_func(V))}.

funsym(V)             --> identifier(V), !,
                          {comprobation(Tablescomp,ref,func(V))}.

funopsym(V)           --> operator(V),      !,
                          {comprobation(Tablescomp,ref,func(V))}.



% paso directo de terminales a tokens
number(V)             --> integer(V) | decimal(V).

%integer('$int'(V))     --> [int(V,_)].
integer('$int'(V))     --> [int(V,_)], {nl, write(V), nl}.

%decimal('$float'(V))  --> [float(V,_)].
decimal('$float'(V))  --> [float(RV,_)], {RV is V*1.0, nl, write(V), nl, write(RV), nl}.

variable('$var'(V))   --> [var(V,_)].

% 20/12/99 Se ha quitado porque no se usa en ningun sitio
% variable('$var(V)',L) --> [var(V,L)].
 
identifier(V)      --> [id(V,_)].

chain(S)  	      --> separator("["),rest_chain(S).

character('$char'(V))  --> [chr(V,_)].

separator(X)          --> [sep(X,_)].
separator(X,L)        --> [sep(X,L)].

constructor(X)       --> [constr(X,_)].

%operator(X)          --> [op(X,_)] | [op_res(X,_)].
operator(X)           --> [op(X,_)].

reserved(X)          --> [res(X,_)].
reserved(X,L)        --> [res(X,L)].

reservated_type(X)    --> [tres(X,_L)]. % 08/07/97

%reservated_op(X)      --> [op_res(X,_)].

% falta por leer algun caracter y el "]"
rest_chain([])        --> separator("]").
rest_chain(':'(V,[])) --> character(V),separator("]"),!.
rest_chain(':'(U,R))  --> character(U),separator(","),!,rest_chain(R).


% --------------------------------------------------------------------------
%                 C L A U S U L A S   P R O L O G
% --------------------------------------------------------------------------
% Cla�sulas Prolog 'embebidas' en la gram�tica.
% Todas se pueden utilizar de dos formas: Pas�ndoles las tablas como argumento
% o dejando que las capturen de la B.D. (las funciones para �sto �ltimo est�n
% en 'compil.ari').


%----------------------------------------------------------------------------%
% comprobation(+Tables,+Command,?Parametros)
% Tables    : Tupla con las tablas o bien
%             la palabra modif_tables_of_db que fuerza a utilizar las tablas
%             que se suponen almacenadas en la B.D., guard�ndolas de nuevo
%             tras llevar a cabo la acci�n, o bien
%             la palabra consul_tables_of_db que cogen las tablas para
%             realizar comprobationes, pero no las modifican.
% Command   : Acci�n a realizar
% Parametros: Tupla con los par�metros necesarios, tanto de entrada como de
%             salida.
% las cla�sulas auxiliares para el manejo de tablas est�n en 'compil.ari'
%----------------------------------------------------------------------------%

comprobation(order,Com,Param) :-
        order == modif_tables_of_db,
        !,
        % cogemos las tablas, al tiempo que las eliminamos de la B.D.
        deleteTablesOfCompilation(Tables),
        comprobation(Tables,Com,Param),
        modifyTablesOfCompilation(Tables). % guardamos la nueva

comprobation(order,Com,Param) :-
        order == consul_tables_of_db,
        !,
        % cogemos las tablas, pero sin borrarlas
        returnTablesOfCompilation(Tables),
        comprobation(Tables,Com,Param).

% a partir de aqu� se supone que ya se dispone de las tablas.
% actuar seg�n el comando

% comprobaci�n de prioridades
% ---------------------------
% falla si prioridad(Op) >= prioridad(Op2)
% en el caso de Op = Op2 y Op no asociativo, obliga a la exp. a fallar
comprobation(_, smaller_priority,(-1,_,false)) :- !. % esto siempre.
comprobation(Tab, smaller_priority,(Op,Op2,Error)) :-
        !,
        % obtenemos los datos de los 2 operatores
        priorityOperator(Tab,Op,Asoc1,Pri1),
        priorityOperator(Tab,Op2,_,Pri2),
        (
          % si es el mismo operator s�lo es menor si asocia por la izquierda
          Op = Op2, (  Asoc1=left,  Error=false, fail
                     ; Asoc1=right, Error=false
                     ; Asoc1=noasoc,Error=true)
        ;
          % operatores distintos. Ver si la prioridad es menor
          Op \== Op2, (  Pri1 < Pri2, Error=false
                        % a igual prioridad agrupamos por la izquierda
                      ; Pri1 = Pri2, Error=false,fail
                      ; Pri1 > Pri2, Error=false,fail )
        ).

% comprobaci�n de referencias externas
% ------------------------------------
% Se anota la referencia a un objeto. Al final de la traducci�n se mirar� a ver
% si hay objetos referenciados y no declarados
comprobation(Tab, ref,Goal) :-
        !,
        % lo guardamos en la tabla de referencias, si es que es nuevo
        extractTable(references,Tab,T),
        lookandput(Goal,true,_,T).


%----------------------------------------------------------------------------%
%                lista de palabras,operatores y tipos reservados             %
%----------------------------------------------------------------------------%
% palabras reserveds
res("where").
res("let").
res("data").
res("type").
res("infixl").
res("infixr").
res("infix").
res("primitive").
res("if").
res("then").
res("else").
res("in").
res("subtypes").
res("include").
%%::B AF
res("includecflpfd").
%%::E
% 01/06/00
res("do").



% separatores con forma de operatores
sep_res("<==").
sep_res(":-").
sep_res("<-").
sep_res("->").
sep_res("=").
sep_res("||").
sep_res("|").
sep_res("..").
sep_res("::").
sep_res("@"). % 09/97
sep_res("-->"). % 03-01-00: We introduce a new operator: --> para las funciones
	      % no deterministas
% separatores normalitos
sep("(").
sep(")").
sep("{").
sep("}").
sep(",").
sep("[").
sep("]").
sep(";").
% tipos reservados
tip_res("int").
tip_res("real").
tip_res("char").
tip_res("bool").

% 29/04/00 mercedes
tip_res("io").



% operatores reservados
/*
op_res(<).
op_res(>).
op_res(<=).
op_res(>=).
op_res(==).
op_res(/=).
op_res(+).
op_res(*).
op_res(/).
op_res(-).

03-01-00: We introduce a new operator: -->
op_res(-->).
*/
