%----------------------------------------------------------------------------%
% newout.pl
%----------------------------------------------------------------------------%
/* 
- Author: Mercedes
- Description: this module contains the exportations of the predicates which
  outgenerated needs to import.
  Este modulo se carga 
  inicialmente y cuando se genere un fichero.out y se cargue (en el modulo 
  compil), como lo generamos como modulo outgenerated, se borra el modulo 
  outgenerated antiguo y se carga este nuevo.
- Modules which they import it: codfun, connected, dds, writing, gramma_toy, inferrer,
  initToy, process, transfun.
- Modules imported into it: not one.
- Modified:
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

 
:- module(outgenerated,[cdata/4,infix/4,ftype/4,fun/4,depends/2,primitive/3,
annotate/1]).   % Yoli YGR  5/12/05

:- dynamic cdata/4,infix/4,ftype/4,fun/4,depends/2,primitive/3,
annotate/1. % Yoli YGR  5/12/05
% This predicates are declared dynamics because there aren't clauses which 
% define it.
