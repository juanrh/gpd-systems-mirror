%----------------------------------------------------------------------------%
% errortoy.pl
%----------------------------------------------------------------------------%
/*
- Fecha: 06-04-1996  
- Author: Rafa Caballero
- Description: Modulo que se usa para el tratamiento de los errores durante la
  compilacion.
- Modules which import it: compil, transob, gramma_toy.
- Imported modules: 
	> tools ('append', 'islist', 'concatenation', 'member_relax', 'writeText',
	         'lookandput','member').
	> dyn.
- Actualizacion: 01-04-1997
- Modified: 30/09/99 mercedes (se han comentado los predicados)
			  26/10/99 mercedes (modularizacion).

*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


:- module(errortoy,[treatLexiconError/1, treatSintacticError/1, 
          treatError/3, treatError/2, variablesRepeated/5, 
          errorIfNotContained/4, patterns_as_nk/10, changeArity/5,terminal/7,
          isVariable/1,errorFaultDeclaration/2,treatError1/3, 
          treatError/4,treat_error/2,name_of_variable/2]).
          
:- load_files(tools,[if(changed),imports([append/3,islist/1,concatenation/2,
             member_relax/2, writeText/1,lookandput/4,member/2])]).
             
:- load_files(dyn,[if(changed)]).



%-----------------------------------------------------------------------------%
% terminal(+Token,+ListToken,-ListToken,+TablesComp,+CI,-CO,+M) donde:
% +Token: token que tengo que reconocer
% +ListToken: lista de tokens que tengo
% -ListToken: lista resultante de eliminar en +ListToken el token que tengo
%              que reconocer.
% +TablesComp: tupla con las tablas de compilacion
% +CI: numero de terminales leidos hasta ahora
% -CO: numero de terminales leidos tras la produccion
% +M: indica si es esta analizando (true) o se esta buscando el error mas
%     profundo (false)
%-----------------------------------------------------------------------------%

% clausulas para el tratamiento de errores y la comprobaci�n de tokens
% s�lo se las llamar� cuando realmente se est� analizando un programa

% 1.- Cuando la diferencia de listas es el token buscado (�xito)

% 1.a  si el token a comprobar es [], la lista de entrada y la de salida ser�n
%      la misma. No considero el 'modo error', porque la lista vacia como
%      token siempre debe tener una alternativa. Se dar� error en la alternativa.

terminal([],Ini,Ini,_,CI,CI,_).


% 1.b .- El caso normal: �xito durante la ejecuci�n (no 'modo error')

terminal([T],[T|R],R,_,_,_,true).


% 1.c .- si el token a comprobar no es [], y se cumple, en caso de 'modo error'
%        indicar que se ha reconocido un token m�s satisfactoriamente.

terminal([T],[T|R],R,_,CI,CO,false)  :- !, CO is CI + 1.


% 2. Cuando la diferencia no es el token buscado (fallo).
%    S�lo se ofreecen posibilidades para 'modo error'.Si no, fallar es correcto

% 2.a si lo que ocurre es que faltan caracteres en la entrada

terminal(T,[],I,_O,CI,_CO,false)     :- ( T \== []
                                        ; nonvar(I) , I \== []) ,
                                        error_terminal(CI,T,[]).

% en otro caso se pasa la longitud de lo que queda por tratar

terminal([T],[K|_R],_S,_,CI,_CO,false) :- T \== K ,!, error_terminal(CI,T,K).



%-----------------------------------------------------------------------------%
% error_terminal(+Depth,+Exp,+Find) donde:
% +Depth: numero de terminales leidos, i.e., la profundidad del error
% +Exp: token esperado
% +Find: token encontrado
% error_terminal comprueba si este error ha sido el error mas profundo hasta
% ahora. Si es asi, sustituimos en la base de datos el antiguo error mas profundo
% por este. Ademas provocamos fallo pq debe seguir buscando errores para ver si
% hay otro error mas profundo.
%
% biggest_sintactic_error(Depth,Exp,Find) donde:
% Depth: profundidad del error, i.e., numero de terminales leidos
% Exp: token esperado
% Find: token encontrado
%-----------------------------------------------------------------------------%


error_terminal(Depth,Exp,Find)         :-
         (clause(biggest_sintactic_error(L,_,_),_)
         ;
         L = -1
         ),
         !,
         % si queda menos entrada por tratar
         Depth >= L,
         % sustituimos el antiguo por el nuevo
         functor(Exp,Type,_),
         arg(1,Exp,Token),
         (
          Depth == L , Repe = true
         ;
          Repe = false
         ),
         Exp2 =.. [Type,Token,Repe],
         deleteError,
         assertbiggest_sintactic_error(Depth,Find,Exp2),
         % de todas formas ha habido error
         fail.

%-----------------------------------------------------------------------------%
% deleteError: borra de la base de datos la informacion del antiguo error mas
% profundo.
%-----------------------------------------------------------------------------%
 
deleteError :- retractbiggest_sintactic_error(_,_,_),!,deleteError.
deleteError :- !.


%-----------------------------------------------------------------------------%
% mensajes de error asociados a cada c�digo
%-----------------------------------------------------------------------------%

error_message(1,"Unexpected end of file in comment.").
error_message(2,"Unexpected end of file in string.").
error_message(3,"Unexpected end of line in string.").
error_message(4,"Invalid identifier.").
error_message(5,"Character too long.").
error_message(6,"Invalid character.").
% 7 --> Unexpected token
% 8 --> missing
error_message(9,"Incomplete statement.").
error_message(10,"Unbalanced parentheses.").
% 11 --> error in expresion
error_message(12,"Incorrect layout.").
error_message(13,"Precedence redefinition.").
error_message(14,"Data redefinition").
error_message(15,"Syntax error.").
error_message(16,"Type redefinition").
error_message(17,"Function redefinition").
error_message(18,"Invalid number of parameters.").
% 19 undeclared type
error_message(20,"Variable repetition not allowed.").
error_message(21,"Invalid number of parameters.").
error_message(22,"Symbol not defined.").
error_message(23,"Invalid operator declaration. Parenthesis expected.").
% 24 : Invalid number of arguments in left-side
error_message(25,"Invalid expresion"). %  P.Ej: 4 mod 5 == X
error_message(26,"Right hand side must not contain new variables"). 

error_message(27,"Bad formated type. Incorrect number of parameters").
error_message(28,"Missing } at end of section").
error_message(29,"Unexpected end of section symbol (})").
error_message(30,"Repetions of variable in as-pattern not allowed").
% 31 Symbol ____ not allowed as function name (reserved symbol)
% 32 Symbol ____ not allowed as constructor name (reserved symbol)
% 33 Symbol ____ defined as a type alias name and a data name 
% 34 Symbol ____ defined as a constructor name and a function name 
error_message(35,
          "Symbols = and --> cannot be mixed in the same function declaration").



% 11/05/00 mercedes
% Existe un nuevo posible error debido a la introduccion de la entrada/salida
% 36 _____ se intenta abrir un fichero antes de haberlo cerrado previamente

% 23/06/00 mercedes
% Variables producidas repetidas en una lista intensional
error_message(37,
              "Produced variables cannot be repeated in an intensional list.").


% Depu 03/10/00 mercedes
% patron where no plano
error_message(38,
               "Left-hand sides of where declarations must be plane patterns.").
% Fin Depu

% 05/09/00 mercedes
% 39 _____ se intenta usar un fichero que no existe

% 07/09/00 mercedes
% Las generadoras de una lista intensional deben aparecer siempre antes que
% las condiciones booleanas en las que aparecen
error_message(40,
	      "Produced variables must appear before the boolean conditions  in which this variables appear.").

% Depu 03/10/00 mercedes
error_message(41,
	      "Variable in pattern multiply defined").

%Fin Depu


% este debe ser el �ltimo y no debiera salir nunca.
% Si alguna vez aparece, darle la enhorabuena a qui�n corresponda
error_message(X,"Unknown error") :- X>401.



% 11/05/00 mercedes
% Este predicado es el que trata el error nuevo de la entrada/salida
treat_error(36,Name):-
	!,
	nl,
        writeText("Error "),write(36),write(:),put(32),
        writeText("Invalid name of file."),nl,
        writeText("          The file "),
        write(Name),
        writeText(" was opened previously and it wasn't closed."),nl,
        retractfile(_,_,_).  % 31/05/00 mercedes: para que cuando se produzca
        		     % un error por no cerrar un fichero, se quede
        		     % todo cerrado para poder continuar.


% 05/09/00 mercedes
% Este predicado es el que trata el error cuando se intenta hacer algo con un
% fichero que no existe
treat_error(39,Name):-
	!,
	nl,
	writeText("Error "),write(39),write(:),put(32),
        writeText("Invalid name of file."),nl,
        writeText("          The file "),
        write(Name),
        writeText(" doesn't exist."),nl.


%-----------------------------------------------------------------------------%
% treatError(+Cod) donde +Cod: codigo del error
%-----------------------------------------------------------------------------%

% caso raro, dar un mensaje de error solo a partir de su codigo
treatError(Cod) :-
	!,
	error_message(Cod,Mes),
	treatError(Cod,[],Mes).


%-----------------------------------------------------------------------------%
%  treatError(+Cod,+Line)
%  Cod    = c�digo del error
%  Line  = L�nea en la que ha ocurrido
%  Saca por pantalla el error correspondiente
%  treatError/2
% tratamiento de errores. Se le pasa el c�digo de error, as� como la l�nea
% en la que ha ocurrido.
%-----------------------------------------------------------------------------%

treatError(Cod,Line) :-
        !,
        error_message(Cod,Mes),
        treatError(Cod,Line,Mes).


%-----------------------------------------------------------------------------%
% treatError(+Cod,+Line,+Text).
% Tratamiento de errores. Se le pasa el c�digo de error, as� como la l�nea
% en la que ha ocurrido y el texto a escribir, es decir:
% El resultado es escribir por pantalla el mensaje de error asociado a ese
% codigo de error, indicando en que linea se ha producido.
%-----------------------------------------------------------------------------%

% si no nos pasan el numero de linea pues no ponemos numero de linea
treatError(Cod,[],Text) :-
        !,
        nl,
        writeText("Error "),write(Cod),write(:),put(32),
        writeText(Text),nl.

treatError(Cod,Line,Text) :-
        !,
        nl,
        writeText("Line "),
        write(Line),writeText(". Error "),write(Cod),write(:),put(32),
        writeText(Text),nl.


treatError1(Cod,Line,(Name,Arity)) :-
        !,
        error_message(Cod,Msg),
        treatError(Cod,Line,Msg,(Name,Arity)).

treatError1(Cod,Line,(Head,_)) :-
        !,
        error_message(Cod,Msg),
        treatError(Cod,Line,Msg,Head).
        
treatError1(Cod,Line,Base) :-
        !,
        error_message(Cod,Msg),
        treatError(Cod,Line,Msg,Base).


treatError(Cod,[],Text,(Name,Arity)) :-
        !,
        nl,
        writeText("Error "),write(Cod),write(:),put(32),
        writeText(Text), write(:), write(Name),write(/),write(Arity),nl.

treatError(Cod,Line,Text,(Name,Arity)) :-
        !,
        nl,
        writeText("Line "),
        write(Line),writeText(". Error "),write(Cod),write(:),put(32),
        writeText(Text),write(:), write(Name),write(/),write(Arity),nl.

treatError(Cod,[],Text,Elem) :-
        !,
        nl,
        writeText("Error "),write(Cod),write(:),put(32),
        writeText(Text), write(:), write(Elem),nl.


treatError(Cod,Line,Text,Elem) :-
        !,
        nl,
        writeText("Line "),
        write(Line),writeText(". Error "),write(Cod),write(:),put(32),
        writeText(Text),write(:), write(Elem),nl.




/*****************************************************************************/
/*                     L E X I C O G R A F I C O			     */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% treatLexiconError(-Error)
% muestra los posibles errores l�xicos que se han producido,
% quit�ndolos de la pila para que no aparezcan la vez siguiente
% si hay al menos un error pone el par�metro a true. Si no, no le hace nada.
%-----------------------------------------------------------------------------%

treatLexiconError(true) :-
        retractlexicon_error(Code,Line),
        !,
        treatError(Code,Line),
        % puede haber m�s de uno? ... por si acaso.
        treatLexiconError(true).

treatLexiconError(_) :- !.





/*****************************************************************************/
/*                      S I N T A C T I C O				     */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% treatSintacticError(-Error)
% Muestra por pantalla todos los errores sint�cticos ocurridos
% y los elimina para que no vuelvan a aparecer.
% Si hay al menos un error Error=true. En otro caso no se toca
%-----------------------------------------------------------------------------%

treatSintacticError(true) :-
        retractbiggest_sintactic_error(_Depth,B,C),
        (
          B =.. [Type, Token,Line]
         ;
          % no se ha encontrado nada
          Type=sep,Token=')',Line=[]
         ),
         (
           C =.. [Type2,Token2,Repe]
          ;
           Type2=[], Token2=[],Repe=true
         ),
        extractSintacticError(Type,Token,Line,Type2,Token2,Repe),
        !,
        treatSintacticError(true).
treatSintacticError(_) :- !.


%-----------------------------------------------------------------------------%
% extractSintacticError(+TypeFinded,+TokenFinded,+Line,
%                       +TypeExpected,  +TokenExpected,  +Repe).
% Repe indica si ha habido varios errores de la misma profundidad
%-----------------------------------------------------------------------------%

% este primero mira a ver si el token reclamado es el �ltimo de los
% atomos. En este caso hay un error en una expresi�n
extractSintacticError(TypeFinded,TokenFinded,Line,sep,"[",_) :-
        !,
        prepare_data_token(TypeFinded,Type,TokenFinded,Token),
        concatenation(["Error in expresion. Unexpected ",Type," ",Token,"."],
                  Text),
        treatError(11,Line,Text).

% fin de secci�n encontrado antes de lo esperado
extractSintacticError(sep,"}",Line, _,_,_) :-
        !,
        treatError(9,Line).


% falta fin de secci�n
extractSintacticError(TypeFinded,TokenFinded,Line, sep,"}",false) :-
         !,
         extractSintacticError(TypeFinded,TokenFinded,Line,sep,"}",true).
%         treatError(15,Line).


extractSintacticError(_TypeFinded,_TokenFinded,Line,
                      sep,  ")",false):-
        !,
        treatError(10,Line).



% si lo esperado era la �ltima palabra clave es que empieza por algo raro
extractSintacticError(TypeFinded,TokenFinded,Line,
                      res,subtypes,_):-
        !,
        extractSintacticError(TypeFinded,TokenFinded,Line,
                              res,subtypes,true).

extractSintacticError(op,_,Line,res,include,_) :-
	!,
	treatError(23,Line).

extractSintacticError(_TypeFinded,_TokenFinded,Line,
                      TypeExpected,TokenExpected,_):-
        prepare_data_token(TypeExpected,_Type,TokenExpected,Token),
	Token=":-",TypeExpected=str,
	!,
        concatenation(["Missing string in include."],Text),
        treatError(8,Line,Text).


extractSintacticError(_TypeFinded,_TokenFinded,Line,
                      TypeExpected,TokenExpected,_):-
        prepare_data_token(TypeExpected,Type,TokenExpected,Token),
	Token=":-",
	!,
        concatenation(["Missing ",Type," ","= in rule ."],Text),
        treatError(8,Line,Text).


extractSintacticError(_TypeFinded,_TokenFinded,Line,
                      TypeExpected,TokenExpected,_):-
	% si no se esperaba nada, no es que falte, sino que sobra
	TokenExpected \== [], TokenExpected \== [125],
        !,
        prepare_data_token(TypeExpected,Type,TokenExpected,Token),
        concatenation(["Missing ",Type," ",Token,"."],Text),
        treatError(8,Line,Text).


% fin de secci�n encontrado antes de lo esperado
extractSintacticError(sep,V,Line, _,_,true) :-
        (V=")" ; V="("),
        !,
        treatError(10,Line).

extractSintacticError(TypeFinded,')',Line,
                      _TypeExpected,  _TokenExpected,true):-
        !,
        prepare_data_token(TypeFinded,Type,_TokenFinded,_Token),
        concatenation(["Unexpected ",Type,"."],Text),
        treatError(7,Line,Text).


extractSintacticError(TypeFinded,TokenFinded,Line,
                      _TypeExpected,  _TokenExpected,true):-
        !,
        prepare_data_token(TypeFinded,Type,TokenFinded,Token),
        concatenation(["Unexpected ",Type," '",Token,"'."],Text),
        treatError(7,Line,Text).

% en otro caso damos error de sintaxis
extractSintacticError(_TypeFinded,_TokenFinded,Line,
                      sep,  _TokenExpected,_):-
        !,
        treatError(15,Line).



% transforma el tipo y nombre del token que se le pasa en cadenas aptas para
% mostrarse por pantalla
prepare_data_token(TypeIn,TypeOut,TokenIn,TokenOut) :-
        !,
        nameType(TypeIn,TypeOut),
        ( TypeIn = sep, TokenOut = TokenIn
         ;
         ( atom(TokenIn)
           ;
           number(TokenIn)
         ) ,
           name(TokenIn,TokenOut)
        ;
          TokenOut = TokenIn
        ).


nameType(id,"identifier"):-!.
nameType(var,"variable"):-!.
nameType(int,"integer"):-!.
nameType(sep,"punctuation mark"):-!.
nameType(op,"operator"):-!.
nameType(chr,"character"):-!.
nameType(res,"keyword"):-!.
nameType(tres,"basic type"):-!.
nameType(unknown,"unknown symbol"):-!.
nameType(X,Y):-
        !,
        (atom(X), name(X,Y)
         ;
         Y=X
        ).



/*****************************************************************************/
/*                           S E M A N T I C O				     */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% changeArity(+Was,+Arity,+Arity2,Line,?Error) donde:
% +Was: indica si la funcion ya habia aparecido
% +Arity: aridad con la que la funcion aparece ahora
% +Arity2: aridad con la que la funcion habia aparecido
% Line: linea donde aparece la funcion
% ?Error: devuelve el error semantico de distinta aridad 
% Si la funci�n ya hab�a aparecido, pero con otra aridad, dar error
%-----------------------------------------------------------------------------%

changeArity(true,A1,A2,Line,true) :-
        \+ (A1 = A2),
        !,
        treatError(18,Line).
changeArity(_,_,_,_,_) :- !.


%-----------------------------------------------------------------------------%
% variablesRepeated(+GiveError,+Struct,?Tab,+Line,?Error) donde:
% +GiveError: si GiveError esta a yes, entonces da mensaje de error en caso de
%            que haya variables repetidas. Si esta a no, entonces solo mira si
%            hay variables repetidas, pero no da mensaje de error.
% +Struct: estructura donde queremos mirar si hay variables repetidas
% ?Tab: Tabla con hueco donde se va acumulando las variables que sean
%       argumentos de la estructura que se le pasa.Si hay alguna repetida dar� 
%       error.
% +Line: linea donde ha aparecido la variable que tengo que mirar si esta
%         repetida
% ?Error: indica si hay error anterior. Si lo hay, Error esta a true. Si no lo
%         hay, Error esta sin instanciar.
% variablesRepeated es un predicado que tiene dos modos de uso: recolectar 
% las variables de la estructura en Tab y dar mensaje de error cuando hay 
% variables repetidas en la estructura. Solamente se dara mensaje de error cuando
% GiveError este a si, e.o.c. solo se recolectan las variables.
%-----------------------------------------------------------------------------%
% si hay error anterior, no hacemos nada
variablesRepeated(_GiveError,_Struct,_Tab,_Line,Error) :- 
	Error == true,
	!.

% si es una lista, mirar en la cabeza y en el resto
variablesRepeated(GiveError,[A|List],Tab,Line,Error) :-
        !,
        variablesRepeated(GiveError,A,Tab,Line,Error),
        variablesRepeated(GiveError,List,Tab,Line,Error).

% la lista vacia no tiene variables repetidas
variablesRepeated(_GiveError,[],_,_,_):-!.

% intentamos ver si es una variable
variablesRepeated(GiveError,V,Tab,Line,Error) :-
        isVariable(V),
        !,
        % incluirla si no estaba
        lookandput(V,true,Was,Tab),
        (Was=true, GiveError=si, treatError(20,Line), Error=true
         ;
         true).



% si es una estructura, la pasamos a lista
variablesRepeated(GiveError,Str,Tab,Line,Error) :-
        Str =.. [_Functor|List],
        !,
        variablesRepeated(GiveError,List,Tab,Line,Error).

% cualquier otra cosa vale
variablesRepeated(_,_,_,_,_) :- !.


%-----------------------------------------------------------------------------%
% isVariable(V) : tiene �xito si V es una variable
%-----------------------------------------------------------------------------%

isVariable( '$var'(_V) ):-!.


%-----------------------------------------------------------------------------%
% name_of_variable(Var,NameVar): devuelve el nombre de la variable Var
%-----------------------------------------------------------------------------%

name_of_variable('$var'(V),V):- !.


%-----------------------------------------------------------------------------%
% patterns_as_nk(+Head,+Body,+Condition,+Where,+Line
%	      -Head,-Body,-Condition,-Where,?Error)
%
% Elimina los patrones as si los hay, devolviendo la regla modificada
% Puede haber error en el caso de que se utilice la misma variable como 'as'
% de dos patrones
%-----------------------------------------------------------------------------%

% si hay error anterior no hacemos nada
patterns_as_nk(Head,Body,Condition,Where,_Line,
		    Head,Body,Condition,Where,Error) :- Error==true,!.


patterns_as_nk(Head,Body,Condition,Where,Line,
		HeadO,BodyO,ConditionO,WhereO,Error) :-
	!,
	% first get the list of pairs of the form (Var,Pattern)
	get_as_nk_patterns(Head,[], [], HeadO1,ListAs, ListNk,Line,Error),
	patterns_as(HeadO1,  Body,  Condition,  Where, ListAs,  
                    HeadO2, BodyO1, ConditionO1, WhereO1),
	patterns_nk(HeadO2, BodyO1,ConditionO1,WhereO1,ListNk,
	            HeadO,BodyO,ConditionO,WhereO).	     


%-----------------------------------------------------------------------------%
% patterns_as(+Head, +Body, +Condition,+Where, +ListAs,
%             -HeadO, -BodyO,-ConditionO,-WhereO)
% tratamiento de los patrones as. En ListAs llevamos una lista de elementos de
% la forma (V,Pat) y lo que se hace es cambiar cada aparicion de V por Pat en el
% cuerpo y en las condiciones.
%-----------------------------------------------------------------------------%

patterns_as(Head,  Body,  Condition,  Where, ListAs,  
            HeadO, BodyO, ConditionO, WhereO) :-
	% modify all the parts of the rule, if the is any pattern
	(
	 ListAs==[], 
	 HeadO    = Head, 
	 BodyO    = Body, 
	 ConditionO = Condition,
	 WhereO     = Where
	;
	 ListAs  \== [],
	 change_as_patterns(ListAs,[HeadO1,Body,Condition,Where],
				[HeadO,BodyO,ConditionO,WhereO])
	).



%-----------------------------------------------------------------------------%
% patterns_nk(+Head, +Body, +Condition,+Where, +ListNk,
%             -HeadO, -BodyO,-ConditionO,-WhereO)
% tratamiento de los patrones n+k. En ListNk llevamos una lista de elementos de
% la forma (VN,V,Ent) donde VN es el nombre nuevo de la variable V, y lo que se 
% hace es anyadir condiciones de la forma:
% V = VN - Ent, V >= 0
%-----------------------------------------------------------------------------%

patterns_nk(Head,  Body,  Condition,  Where, ListNk,  
            HeadO, BodyO, ConditionO, WhereO) :-
 	%  only the  condition will be modified
         HeadO    = Head, 
	 BodyO    = Body, 
	 WhereO     = Where,
	(
	 ListNk==[], 
	 ConditionO = Condition
	;
	 ListNk  \== [], 
	 change_nk_patterns(ListNk,Condition,ConditionO)
	).


	
%-----------------------------------------------------------------------------%
% get_as_nk_patterns(+Head, +ListI_as, +ListI_nk,
%                 -HeadO,-ListO_as, -ListO_nk, +Line,-Error)
% +Head    : Head which might has 'as' patterns
% +ListI_as: List of 'as' patterns found at the moment
% +ListI_nk: List of (n+k) patterns found at the moment
% -HeadO: Output head, it has removed all the right side of the 'as' patterns
%         (i.e. X@pat has been replaced by X)
% -ListO_as: Output list of as patterns
% -ListO_nk: Output list of (n+k) patterns 
% +Line : Line number of the rule
% -Error: true if there were any errors
%-----------------------------------------------------------------------------%

% first assure that there are no errors
get_as_nk_patterns(_Head, _ListI_as,_ListI_nk,
                   _HeadO,_ListO_as,_ListO_nk,_Line, Error) :- Error==true,!.

% empty lists
get_as_nk_patterns([],ListI_as, ListI_nk,[],ListI_as, ListI_nk,_Line, _Error) :- !.

% non-empty list
get_as_nk_patterns([H|T],  ListI_as, ListI_nk,
                   [H2|T2],ListO_as, ListO_nk,Line,Error) :- 
	!,
	get_as_nk_patterns(H, ListI_as,  ListI_nk,
                           H2,ListO_as1, ListO_nk1,Line, Error),
	get_as_nk_patterns(T, ListO_as1, ListO_nk1, 
                           T2,ListO_as,  ListO_nk,Line, Error).

% an as pattern: if the as pattern  appeared before, error
get_as_nk_patterns('$as'(V,Pat),ListI_as, ListI_nk,
                    Pat,        ListI_as, ListI_nk, Line,true) :-
	member_relax((V,_Pat),ListI_as),
	!,
	treatError(30,Line).

get_as_nk_patterns('$as'(V,Pat),ListI_as,           ListI_nk,
                    Pat,        [(V,Pat)|ListI_as], ListI_nk,_Line,_Error) :-
	!.

% n+k patterns
get_as_nk_patterns('$n+k'(Var,Ent),ListI_as, ListI_nk,
                    VarN, ListI_as, [(VarN, Var, Ent)|ListI_nk],_Line,_Error) :-
                 !,
		 name_of_variable(Var,NameVar),
		 append("$n+k",NameVar, NameVar1),
		 name_of_variable(VarN,NameVar1).

% toy vars
get_as_nk_patterns(Head,ListI_as, ListI_nk ,
                   Head,ListI_as, ListI_nk, _Line,_Error) :-
	isVariable(Head),
	!.


% atoms
get_as_nk_patterns(Head,ListI_as, ListI_nk ,
                   Head,ListI_as, ListI_nk, _Line,_Error) :-
	atom(Head),
	!.

% general estructure
get_as_nk_patterns(Struct, ListI_as, ListI_nk,
                   StructO,ListO_as, ListO_nk, Line,Error) :-
        Struct =.. [H|T], % the functor cannot be an as-pattern
	!,
	get_as_nk_patterns(T,       ListI_as, ListI_nk, 
                           StructO1,ListO_as, ListO_nk, Line,Error),
	StructO =.. [H|StructO1].




%-----------------------------------------------------------------------------%
% change_as_patterns(+List,+TermI,-TermO)
%
%  List: List of pairs of the form (Variable,Pattern)
%  TermI: Prolog term, might has some variables of the List
%  TermO: The previous term with the variables in the list replaced by its pat.
%-----------------------------------------------------------------------------%

% empty list
change_as_patterns(_list,[],[]) :-
	!. 

% non-empty list
change_as_patterns(List,[HI|TI],[HO|TO]) :-
	!,
	change_as_patterns(List,HI,HO),
	change_as_patterns(List,TI,TO).

% variable which is in the list
change_as_patterns(List,L,Pattern) :-
	isVariable(L),
	member_relax((L,Pattern),List),
	!.

% variable which is not in the list
change_as_patterns(_List,L,L) :-
	isVariable(L),
	!.

% atoms
change_as_patterns(_List,SI,SI):-
	atom(SI),
	!.

% structs
change_as_patterns(List,SI,SO) :-
	SI =.. [H|T], % the functor cannot be a variable
	!,
	change_as_patterns(List,T,TO),
	SO =.. [H|TO].


%-----------------------------------------------------------------------------%
% change_nk_patterns(+List,+CondI,-CondO)
%
%  List: List of pairs of the form (VariableN, Variable, Integer)
%  CondI: List of Toy conditions
%  CondO: The previous list augmented with the new constraints 
%         Variable = VariableN - Integer, Variable >=0
%-----------------------------------------------------------------------------%

% empty list
change_nk_patterns([],CondI,CondI) :-
	!. 

% non-empty list
change_nk_patterns([(VN,V,I)|L],CondI,['$apply'(==,[V,'$apply'(-,[VN,I])]),
                   '$apply'(>=,[V,'$int'(0)])|CondI]) :- !.



	

/*****************************************************************************/
/*                               T I P O S				     */
/*****************************************************************************/

%-----------------------------------------------------------------------------%
% errorFaultDeclaration(+Type,+V)
% errorFaultDeclaration: se ha encontrado un objeto no declarado. Se escribe
% por pantalla el error correspondiente.
%-----------------------------------------------------------------------------%

errorFaultDeclaration(Type,V) :-
        !,
        nl,
        name(V,Name),
        concatenation(["Error 19: Undeclared ",Type," ",Name,"."],Text),
        writeText(Text),nl.


%-----------------------------------------------------------------------------%
% errorIfNotContained(+A,+B,+Line,?Error): Da error si no se verifica (A incluido
% en B), siendo A y B listas
%-----------------------------------------------------------------------------%

% si ya ha habido error no hago nada
errorIfNotContained(_A,_B,_Line,Error) :- 
	Error == true, !.

% la lista vacia esta incluida en todas las listas. Caso base
errorIfNotContained([],_B,_Line,_Error) :- !.

% si la cabeza de A no pertenece a B, A no puede estar incluida en B
errorIfNotContained([X|_RestList],B,Line,true) :-
	\+ member(X,B), 
	!,
	treatError(26,Line).

% si llega hasta aqui es porque la cabeza de A pertenece a B. 
% En este caso A esta contenida en B si la cola de A esta contenida en B. 
errorIfNotContained([_X|RestList],B,Line,Error) :- 
	!,
	errorIfNotContained(RestList,B,Line,Error).

	
%-----------------------------------------------------------------------------%
% possible_error(?Error,+Cod,+Line) donde:
% ?Error: si Error esta a true es que ha habido error, por tando hay
%              que tratarlo. Si esta sin instanciar, es que no lo ha habido, y no
%              se hace nada.
% +Cod: codigo del error 
% +Line: linea donde se ha producido el error
%-----------------------------------------------------------------------------%

possible_error(Error,Cod,Line) :-
        Error == true,
        !,
        treatError(Cod,Line).

%en otro caso no se hace nada. Falsa alarma
possible_error(_Error,_Cod,_Line).



