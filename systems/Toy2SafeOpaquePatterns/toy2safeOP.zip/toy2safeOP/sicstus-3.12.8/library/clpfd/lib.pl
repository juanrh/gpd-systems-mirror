/* Copyright(C) 1997, Swedish Institute of Computer Science */

%%% Target library for arithmetic expressions:
%%%	'x+y=t'/3
%%%	'ax=t'/3
%%%	'ax+y=t'/4
%%%	'ax+by=t'/5
%%%	't=c'/2	
%%%	't=<c'/2
%%%	't\\=c'/2
%%%	't>=c'/2
%%%	't=u+c'/3
%%%	't=<u+c'/3
%%%	't\\=u+c'/3
%%%	't>=u+c'/3
%%%	't+u=c'/3
%%%	't+u=<c'/3
%%%	't+u\\=c'/3
%%%	't+u>=c'/3
%%%	't=x+y+c'/4
%%%	'x+y=u+c'/4
%%%	'x+y+z=c'/4

/***
't=c'(T,C) +:
	T in {C}.

't=<c'(T,C) +:
	T in inf..C.

't>=c'(T,C) +:
	T in C..sup.

't\\=c'(T,C) +:
	T in \{C}.

Type checking done at compile time.
***/

't=c'(T,C) :-
	check_arguments_error(1, T#=C),
	propagate_interval(T, C, C).

't=<c'(T,C) :- 
	check_arguments_error(1, T#=<C),
	propagate_interval(T, inf, C).

't>=c'(T,C) :- 
	check_arguments_error(1, T#>=C),
	propagate_interval(T, C, sup).

't\\=c'(T,C) :-
	check_arguments_error(1, T#\=C),
	'$fd_range'(C, C, R, 1),
	'$fd_dom_complement'(R, R1),
	prune_and_propagate(T, R1).

%%% indexicals for arithmetic

'ax=t'(A,X,T) +:
	X in   min(T) /> A..max(T) /< A,
	T in !(min(X) *  A..max(X) *  A).

'x+y=t'(X,Y,T) +:
	X in !(min(T) - max(Y)..max(T) - min(Y)),
	Y in !(min(T) - max(X)..max(T) - min(X)),
	T in !(min(X) + min(Y)..max(X) + max(Y)).

% Now domain consistent!
't+u=c'(T,U,C) +:
	T in !(C - dom(U)),
	U in !(C - dom(T)).

% Now domain consistent!
'x+c=y'(X,C,Y) +:
	X in !(dom(Y) - C),
	Y in !(dom(X) + C).

% Now domain consistent!
't=u+c'(T,U,C) +:
	T in !(dom(U) + C),
	U in !(dom(T) - C).

't=<u+c'(T,U,C) +:
	T in inf..max(U)+C,
	U in min(T) - C..sup.

't\\=u+c'(T,U,C) +:
	T in \{U + C},
	U in \{T - C}.

't>=u+c'(T,U,C) +:
	T in min(U) + C..sup,
	U in inf..max(T) - C.

'ax+c=t'(A,X,C,Y) +:
	X in  (min(Y) - C) /> A..(max(Y) - C) /< A,
	Y in !(min(X)*A + C    .. max(X)*A + C).

'ax+y=t'(A,X,Y,Z) +:
	X in  (min(Z) - max(Y)) /> A..(max(Z) - min(Y)) /< A,
	Y in !(min(Z) - max(X)*A    .. max(Z) - min(X)*A),
	Z in !(min(X)*A + min(Y)    .. max(X)*A + max(Y)).

't+u=<c'(T,U,C) +:
	T in inf..C - min(U),
	U in inf..C - min(T).

't+u\\=c'(T,U,C) +:
	T in \{C - U},
	U in \{C - T}.

't+u>=c'(T,U,C) +:
	T in C - max(U)..sup,
	U in C - max(T)..sup.

% obsolete, backward compatibility?
'ax+by=t'(A,X,B,Y,Z) +:
	X in  (min(Z) - max(Y)*B) /> A.. (max(Z) - min(Y)*B) /< A,
	Y in  (min(Z) - max(X)*A) /> B.. (max(Z) - min(X)*A) /< B,
	Z in !(min(X)*A + min(Y)*B    ..  max(X)*A + max(Y)*B).

'x+y=u+c'(X,Y,U,C) +:
	X in !(min(U) - max(Y) + C..max(U) - min(Y) + C),
	Y in !(min(U) - max(X) + C..max(U) - min(X) + C),
	U in !(min(X) + min(Y) - C..max(X) + max(Y) - C).

't=x+y+c'(T,X,Y,C) :-
	'x+y+c=z'(X,Y,C,T).

'x+y+c=z'(X,Y,C,Z) +:
	X in !(min(Z) - max(Y) - C..max(Z) - min(Y) - C),
	Y in !(min(Z) - max(X) - C..max(Z) - min(X) - C),
	Z in !(min(X) + min(Y) + C..max(X) + max(Y) + C).

'ax+y+c=z'(A,X,Y,C,Z) +:
	X in  (min(Z) -	  max(Y) - C)/>A.. (max(Z) -   min(Y) - C)/<A,
	Y in !(min(Z) -   max(X)*A - C	..  max(Z) -   min(X)*A - C),
	Z in !(min(X)*A + min(Y) + C	..  max(X)*A + max(Y) + C).

'x+y+z=t'(X,Y,Z,T) +:
	X in !(min(T) - max(Y) - max(Z)..max(T) - min(Y) - min(Z)),
	Y in !(min(T) - max(X) - max(Z)..max(T) - min(X) - min(Z)),
	Z in !(min(T) - max(X) - max(Y)..max(T) - min(X) - min(Y)),
	T in !(min(X) + min(Y) + min(Z)..max(X) + max(Y) + max(Z)).

'x+y+z=c'(X,Y,Z,C) +:
	X in !(C - max(Y) - max(Z)..C - min(Y) - min(Z)),
	Y in !(C - max(X) - max(Z)..C - min(X) - min(Z)),
	Z in !(C - max(X) - max(Y)..C - min(X) - min(Y)).

'ax+y+z=t'(A,X,Y,Z,T) +:
	X in  (min(T) -	  max(Y) - max(Z)) /> A..
	      (max(T) -	  min(Y) - min(Z)) /< A,

	Y in !(min(T) - max(X)*A - max(Z).. 
	       max(T) - min(X)*A - min(Z)),

	Z in !(min(T) - max(X)*A - max(Y)..
	       max(T) - min(X)*A - min(Y)),

	T in !(min(X)*A + min(Y) + min(Z)..
	       max(X)*A + max(Y) + max(Z)).


%%% Utilities for globals.

arg_attribute(X, Attr, _, _) :-
	'$fd_arg_attribute'(X, 0, Attr), !.
arg_attribute(X, _, Goal, ArgNo) :-
	fd_argument_error(Goal, ArgNo, X).

finite_arg_attribute(X, Attr, _, _) :-
	'$fd_arg_attribute'(X, 1, Attr), !.
finite_arg_attribute(X, _, Goal, ArgNo) :-
	var(X), !,
	fd_illarg(var, Goal, ArgNo, X).
finite_arg_attribute(X, _, Goal, ArgNo) :-
	fd_argument_error(Goal, ArgNo, X).

must_be_dvar_list(List, _, _) :-
	'$fd_dvar_list'(List, 0), !.
must_be_dvar_list(List, Goal, ArgNo) :-
	not_dvar_list(List, Goal, ArgNo).

not_dvar_list(List, Goal, ArgNo) :- var(List), !,
	fd_illarg(var, Goal, ArgNo, List).
not_dvar_list([Arg|List], Goal, ArgNo) :- !,
	arg_attribute(Arg, _, Goal, ArgNo),
	not_dvar_list(List, Goal, ArgNo).
not_dvar_list(List, Goal, ArgNo) :-
	fd_illarg(domain(term,list), Goal, ArgNo, List).

must_be_list_of_finite_dvar(List, _, _) :-
	'$fd_dvar_list'(List, 1), !.
must_be_list_of_finite_dvar(List, Goal, ArgNo) :-
	not_list_of_finite_dvar(List, Goal, ArgNo).

not_list_of_finite_dvar(L, Goal, ArgNo) :- var(L), !,
	fd_illarg(var, Goal, ArgNo, L).
not_list_of_finite_dvar([X|L], Goal, ArgNo) :- !,
	finite_arg_attribute(X, _, Goal, ArgNo),
	not_list_of_finite_dvar(L, Goal, ArgNo).
not_list_of_finite_dvar(L, Goal, ArgNo) :-
	fd_illarg(domain(term,list), Goal, ArgNo, L).

/****************************************************************/
/* new all_different/[1,2], all_distinct/[1,2]                  */
/****************************************************************/

all_different(Xs) :-
	all_different(Xs, [], opt(value,local,[],false), all_different(Xs)).

all_different(Xs, Opt) :-
	all_different(Xs, Opt, opt(value,local,[],false), all_different(Xs,Opt)).

all_distinct(Xs) :-
	all_different(Xs, [], opt(domain,global,[],false), all_distinct(Xs)).

all_distinct(Xs, Opt) :-
	all_different(Xs, Opt, opt(domain,global,[],false), all_distinct(Xs,Opt)).

all_different(Xs, Options, Opt0, Goal) :-
	all_diff_options(Options, Opt0, Opt, Goal, 2),
	must_be_list_of_finite_dvar(Xs, Goal, 1),
	Opt = opt(On,Cons,_,_),
	all_diff_init(Xs, Vec, On, Goal, 1, Susp, []),
	(   Cons==global
	->  (   On==value -> SuspVal = Susp
	    ;   on_val(Xs, SuspVal, [])
	    ),
	    fd_global_internal(all_different(Xs), state(Vec,0,_Handle1,0), SuspVal,
			       _, true, 4), % non-idempotent
	    fd_global_internal(all_distinct(Xs), f(Vec,0,0,_Handle2,0), Susp,
			       _, clpfd:Goal, 0)
	;   Cons==bound
        ->  fd_global_internal(bc_alldiff(Xs), f(Vec,0,_Handle2,0), Susp,
			       _, clpfd:Goal, 0)
	; /*Cons==local ->*/
	    fd_global_internal(all_different(Xs), state(Vec,0,_Handle2,0), Susp,
			       _, clpfd:Goal, 4) % non-idempotent
	).

all_diff_init([], [], _On, _Goal, _ArgNo) --> [].
all_diff_init([X|Xs], [X-M|Vec], On, Goal, ArgNo) -->
	on(On, X),
	{arg_attribute(X, M, Goal, ArgNo)},
	all_diff_init(Xs, Vec, On, Goal, ArgNo).

on(_, X) --> {nonvar(X)}, !.
on(dom, X) --> [dom(X)].
on(min, X) --> [min(X)].
on(max, X) --> [max(X)].
on(minmax, X) --> [minmax(X)].
on(val, X) --> [val(X)].
on(none, X) --> [none(X)].
% the following are deprecated
on(domain, X) --> [dom(X)].
on(range, X) --> [minmax(X)].
on(value, X) --> [val(X)].

all_diff_options(L, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
all_diff_options([], Opt, Opt, _, _) :- !.
all_diff_options([X|L], Opt0, Opt, Goal, ArgNo) :- !,
	(   all_diff_option(X, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,all_diff_option), Goal, ArgNo, X)
        ),
	all_diff_options(L, Opt1, Opt, Goal, ArgNo).
all_diff_options(L, _, _, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Goal, ArgNo, L).

all_diff_option(on(On), opt(_,Cons,Cost,Circ), opt(On,Cons,Cost,Circ)) :-
	on(On, _, _, _).
all_diff_option(complete(Arg), opt(On,_,Cost,Circ), opt(On,Cons,Cost,Circ)) :-
	aux_option(complete, Arg, Cons).
all_diff_option(consistency(Arg), opt(On,_,Cost,Circ), opt(On,Cons,Cost,Circ)) :-
	aux_option(consistency, Arg, Cons).
all_diff_option(cost(V,Mat), opt(On,Cons,_,Circ), opt(On,Cons,cost(V,VM,Mat),Circ)) :-
	arg_attribute(V, VM, 0, 3).
all_diff_option(circuit(Circ), opt(On,Cons,Cost,_), opt(On,Cons,Cost,Circ)) :-
	bool_option(Circ, _).

/****************************************************************/
/* element/3							*/
/****************************************************************/
% 
% A generalized version of element(X,L,Y):
% nonground L -> constructive disjunction style
% Propagator in C
% interval consistent in Y and L, domain consistent in X

element(X, L, Y) :-
	Goal = element(X,L,Y),
	must_be_dvar_list(L, Goal, 2),
	length(L, N),
	X in 1..N,
	arg_attribute(X, XM, Goal, 1),
	arg_attribute(Y, YM, Goal, 3),
	on_minmax(L, Susp, []),
	fd_global(Goal, elt(X-XM,L,Y-YM,0,0,_Handle,0), [dom(Y)|Susp]).

% /****************************************************************/
% /* circuit/[1,2]						*/
% /****************************************************************/
% 
% circuit(Xs) :-
% 	circuit(Xs, _, circuit(Xs)).
% 
% circuit(Xs, Ys) :-
% 	circuit(Xs, Ys, circuit(Xs,Ys)).
% 
% circuit(Xs, Ys, Goal) :-
% 	must_be_dvar_list(Xs, Goal, 1),
% 	length(Xs, N),
% 	length(Ys, N),
% 	must_be_dvar_list(Ys, Goal, 2),
% 	(   N=:=1 -> Xs = [1], Ys = [1]
% 	;   N>1,
% 	    '$fd_range'(1, N, Set, 1),
% 	    domain(Xs, Set),
% 	    domain(Ys, Set),
% 	    not_self(Xs, 0),
% 	    not_self(Ys, 0),
% 	    assignment_state(Xs, Ys, 0, XVec, YVec, domain, Goal, Susp, []),
% 	    fd_global(circuit(Xs,Ys), f(XVec,YVec,0,0,_Handle,0), Susp)
% 	).

not_self([], _).
not_self([Y|Ys], I) :-
	J is I+1,
	't\\=c'(Y, J),
	not_self(Ys, J).

/****************************************************************/
/* relation/3							*/
/****************************************************************/

%
% piggy-back on case/3, new version as of 3.12
% 
relation(X, L0, Y) :-
	rel_table(L0, L1, []),	% Xsing-Yset list
	keysort(L1, L1s),
	keyclumps(L1s, L2),
	clumps_to_inv_pairs(L2, L3), % Yset-Xsing list
	keysort(L3, L4),
	keyclumps(L4, L5),
	clumps_to_inv_pairs(L5, Rs),	% Xset-Yset list
	keys_and_values(Rs, Xs, Ys),
	rel_as_case_dag(Xs, Ys, B, Succs1, 1, Dag, []),
	keysort(Succs1, Succs2),
	fast_case([A-B], [[X-Y]], [node(0,A,Succs2)|Dag]).

rel_table([]) --> [].
rel_table([Xr-Yr|L]) -->
	{int_or_range_to_fdset(Xr, Xs)},
	{fdset_to_list(Xs, Xl)},
	{int_or_range_to_fdset(Yr, Ys)},
	rel_table_part(Xl, Ys),
	rel_table(L).

rel_table_part([], _) --> [].
rel_table_part([X|Xs], Ys) --> [[[X|X]]-Ys],
	rel_table_part(Xs, Ys).

clumps_to_inv_pairs([], []).
clumps_to_inv_pairs([C|Cs], [Fd-Key|Ps]) :-
	keys_and_values(C, [Key|_], Vals),
	fdset_union(Vals, Fd),
	clumps_to_inv_pairs(Cs, Ps).

rel_as_case_dag([], [], _, [], _) --> [].
rel_as_case_dag([X1|Xs], [Y1|Ys], Var, Succs1, M) --> [node(M,Var,Y2)],
	{rel_succs(X1, M, Succs1, Succs2)},
	{rel_nosuccs(Y1, Y2, [])},
	{N is M+1},
	rel_as_case_dag(Xs, Ys, Var, Succs2, N).

rel_succs([], _) --> [].
rel_succs([[A|B]|X1], M) --> [(A..B)-M],
        rel_succs(X1, M).

rel_nosuccs([]) --> [].
rel_nosuccs([[A|B]|X1]) --> [(A..B)],
        rel_nosuccs(X1).

int_or_range_to_fdset(R, L) :- integer(R), !,
	L = [[R|R]].
int_or_range_to_fdset(R, L) :-
	range_to_fdset(R, L).

fast_case([A-B], Tuples, Dag1) :-
	Goal = case([A-B],Tuples,Dag1,[]),
	length(Dag1, NbNodes),
	fast_case_convert_x(Dag1, Dag2, 0, NbChildren),
	clpfd:case_post(Tuples, [A-B], [A,B], 2, NbNodes, NbChildren, Dag2,
			[dom,dom], [dom,dom], 0, Goal).

fast_case_convert_x([node(ID,_,Map)|Dag1], [dagnode(ID,0,[[0|1]],Map,Map)|Dag2], Nb1, Nb3) :-
	length(Map, Inc),
	Nb2 is Nb1+Inc,
	fast_case_convert_y(Dag1, Dag2, Nb2, Nb3).

fast_case_convert_y([], [], Nb, Nb).
fast_case_convert_y([node(ID,_,Map1)|Dag1], [dagnode(ID,1,[[1|1]],Map2,Map1)|Dag2], Nb1, Nb3) :-
	fast_case_convert_map(Map1, Map2),
	length(Map1, Inc),
	Nb2 is Nb1+Inc,
	fast_case_convert_y(Dag1, Dag2, Nb2, Nb3).

fast_case_convert_map([], []).
fast_case_convert_map([X|Xs], [X-[]|Ys]) :-
	fast_case_convert_map(Xs, Ys).

/****************************************************************/
/* assignment/[2,3]						*/
/****************************************************************/

% assignment(X1...Xn, Y1...Yn) is true if 
% all Xi,Yi in 1..n and Xi=j iff Yj=i

assignment(Xs, Ys) :-
	assignment(Xs, Ys, [], opt(domain,global,[],false), assignment(Xs,Ys)).

assignment(Xs, Ys, Options) :-
	assignment(Xs, Ys, Options, opt(domain,global,[],false), assignment(Xs,Ys,Options)).

circuit(Xs) :-
	assignment(Xs, _, [], opt(domain,global,[],true), circuit(Xs)).

circuit(Xs, Ys) :-
	assignment(Xs, Ys, [], opt(domain,global,[],true), circuit(Xs,Ys)).

circuit(Xs, Ys, Options) :-
	assignment(Xs, Ys, Options, opt(domain,global,[],true), circuit(Xs,Ys,Options)).

assignment(Xs, Ys, Options, Opt0, Goal) :-
	all_diff_options(Options, Opt0, Opt, Goal, 3),
	must_be_dvar_list(Xs, Goal, 1),
	length(Xs, N),
	length(Ys, N),
	must_be_dvar_list(Ys, Goal, 2),
	'$fd_range'(1, N, Set, 1),
	domain(Xs, Set),
	domain(Ys, Set),
	Opt = opt(On,Cons,Cost,Circuit),
	assignment_state(Xs, Ys, 0, XVec, YVec, On, Goal, Susp, Susp1),
	(   Cost==[] -> Susp1 = [], Flag0 = 0
	;   Cost = cost(C,_,_), Susp1 = [dom(C)], Flag0 = 2
	),
	on_val(Xs, SuspVal, Susp2),
	on_val(Ys, Susp2, []),
	fd_global_internal(pairing(Xs,Ys), state(XVec,YVec,0,_Handle1,0), SuspVal,
			   _, clpfd:Goal, 4), % non-idempotent
	(   Circuit==true
	->  Flag is Flag0+1,
	    not_self(Xs, 0),
	    not_self(Ys, 0),
	    fd_global_internal(circuit(Xs), state(XVec,0,_Handle2,0), SuspVal,
			       _, true, 4), % non-idempotent
	    fd_global_internal(circuit(Ys), state(YVec,0,_Handle3,0), SuspVal,
			       _, true, 4) % non-idempotent
	;   Flag = Flag0
	),
	(   Flag>=2
	->  fd_global_internal(assignment(Xs,Ys),
			       f(XVec,YVec,0,Flag,Cost,0/*cost so far*/,_Handle4,0), Susp,
			       Global, true, 0),
	    Global = global(StateM,_,_,_,_),
	    assignment_helpers(Xs, C, 0, StateM)
	;   Cons==local -> true
	;   fd_global_internal(assignment(Xs,Ys), f(XVec,YVec,0,Flag,Cost,0/*cost so far*/,_Handle4,0), Susp,
			       _, true, 0)
	).

assignment_helpers([], _, _, _).
assignment_helpers([X|Xs], C, I, StateM) :-
	fd_global_internal(assignment_helper(X,C), f(I,X,StateM), [val(X)],
			   _, true, 0),
	J is I+1,
	assignment_helpers(Xs, C, J, StateM).

assignment_state([], [], _, [], [], _On, _Goal) --> [].
assignment_state([X|Xs], [Y|Ys], I, [X-XM|XVec], [Y-YM|YVec], On, Goal) -->
	on(On, X),
	on(On, Y),
	{arg_attribute(X, XM, Goal, 1),
	 arg_attribute(Y, YM, Goal, 2),
	 J is I+1},
	assignment_state(Xs, Ys, J, XVec, YVec, On, Goal).

/****************************************************************/
/* serialized/2, cumulative/4 and friends			*/
/****************************************************************/

serialized(Ss, Ds) :-
	serialized(Ss, Ds, []).

serialized(Ss, Ds, Options) :-
	Goal = serialized(Ss,Ds,Options),
	serialized_options(Options, opt(_,[],0), opt(R,Ps,Flags), Goal, 3),
	must_be_list_of_finite_dvar(Ss, Goal, 1),
	must_be_list_of_finite_dvar(Ds, Goal, 2),
	R = resource(Tasks,Diffs,Global),
	ones(Ss, Rs),
	cumulative(Ss, Ds, Rs, Ps, Tasks, Diffs, 1, Flags, Global, Goal).


cumulative(Ss, Ds, Rs, Limit) :-
	cumulative(Ss, Ds, Rs, Limit, []).

cumulative(Ss, Ds, Rs, Limit, Options) :-
	Goal = cumulative(Ss,Ds,Rs,Limit,Options),
	serialized_options(Options, opt(_,[],0), opt(R,Ps,Flags0), Goal, 5),
	(   Flags0/\1 =:= 1 -> Flags is Flags0\/16
	;   Flags = Flags0
	),
	must_be_list_of_finite_dvar(Ss, Goal, 1),
	must_be_list_of_finite_dvar(Ds, Goal, 2),
	must_be_list_of_finite_dvar(Rs, Goal, 3),
	R = resource(Tasks,Diffs,Global),
	cumulative(Ss, Ds, Rs, Ps, Tasks, Diffs, Limit, Flags, Global, Goal).


serialized_options(L, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
serialized_options([], Opt, Opt, _, _) :- !.
serialized_options([X|L], Opt0, Opt, Goal, ArgNo) :- !,
	(   serialized_option(X, Goal, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,serialized_option), Goal, ArgNo, X)
        ),
	serialized_options(L, Opt1, Opt, Goal, ArgNo).
serialized_options(L, _, _, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Goal, ArgNo, L).

% opt(Resource,Precedences,2'EDCBA) where
% A = path_consistency
% B = static_sets
% C = edge_finder
% D = decomposition
% E = Dij vars must be used
serialized_option(-, _, _, _) :- !, fail.
serialized_option(precedences(Ps), _, opt(R,_,Flags0), opt(R,Ps,Flags)) :-
	Flags is (Flags0 /\ -17) \/ 16.
serialized_option(resource(R), _, opt(_,Ps,Flags0), opt(R,Ps,Flags)) :-
	Flags is (Flags0 /\ -17) \/ 16.
serialized_option(path_consistency(B), _, opt(R,Ps,Flags0), opt(R,Ps,Flags)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -2) \/ Value.
serialized_option(static_sets(B), _, opt(R,Ps,Flags0), opt(R,Ps,Flags)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -3) \/ (Value<<1).
serialized_option(edge_finder(B), _, opt(R,Ps,Flags0), opt(R,Ps,Flags)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -5) \/ (Value<<2).
serialized_option(decomposition(B), _, opt(R,Ps,Flags0), opt(R,Ps,Flags)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -9) \/ (Value<<3).
serialized_option(bounds_only(B), _, opt(R,Ps,Flags0), opt(R,Ps,Flags)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -33) \/ ((1-Value)<<5).

/*
serialized_resource(Ss, Ds, resource(Tasks,Diffs,Global)) :-
	serialized(Ss, Ds, [], Tasks, Diffs, Global,
	           serialized_resource(Ss,Ds,resource(Tasks,Diffs,Global))).

serialized(Ss, Ds) :-
	serialized(Ss, Ds, [], _Tasks, _Diffs, _Global, serialized(Ss,Ds)).

serialized_precedence_resource(Ss, Ds, Ps, resource(Tasks,Diffs,Global)) :-
	serialized(Ss, Ds, Ps, Tasks, Diffs, Global,
	           serialized_precedence_resource(Ss,Ds,Ps,resource(Tasks,Diffs,Global))).

serialized_precedence(Ss, Ds, Ps) :-
	serialized(Ss, Ds, Ps, _Tasks, _Diffs, _Global,
		   serialized_precedence(Ss,Ds,Ps)).
*/

% guts

cumulative([], [], _Rs, _Ps, [], [], _, _, global, _Goal) :- !.
cumulative(Ss, Ds, Rs, Ps, Tasks, Diffs, Limit, Flags, Global, Goal) :-
	% inf_sup(Set1),
	% zero_sup(Set2),
	% must_be_dvar_list(Ss, Set1, Goal, 1),
	% must_be_dvar_list(Ds, Set2, Goal, 2),
	mktasks(Ss, Ds, Rs, Tasks, 1, Goal), % 1-based numbering
	empty_assoc(H0),
	(   Flags/\16 =:= 0 -> Diffs = []
	;   ti_delta_holes(Ps, H0, H),
	    fd_max(Limit, LimitUB),
	    ti_deltas(Tasks, 1, H, LimitUB, Goal, Diffs, []) % 1-based numbering
	),
	task_order(Tasks, Diffs, Limit, Flags, Global, Goal).

mktasks([], _, _, [], _NT, _).
mktasks([S|Ss], [D|Ds], [R|Rs], [task(S,SM,D,DM,R,RM,I,_/*Precedences*/)|Ts], I, Goal) :-
	finite_arg_attribute(S, SM, Goal, 1),
	finite_arg_attribute(D, DM, Goal, 2),
	finite_arg_attribute(R, RM, Goal, 3),
	J is I+1,
	mktasks(Ss, Ds, Rs, Ts, J, Goal).

ti_delta_holes([], H, H).
ti_delta_holes([d(I,J,D)|Ds], H0, H) :-	!, % Si before Sj implies Si+D =< Sj
	(   I<J ->
	    ti_one_less_pos(D, X),
	    ti_delta_hole(I-J, 1, X, H0, H1)
	;   ti_one_less_neg(D, X),
	    ti_delta_hole(J-I, X, -1, H0, H1)
	),
	ti_delta_holes(Ds, H1, H).
ti_delta_holes([J-I in R|Ds], H0, H) :-
	set_expression(R, S),	% TODO: error handling
	(   I<J -> ti_delta_set(I-J, S, H0, H1)
	;   '$fd_negate'(S, 0, S1),
	    ti_delta_set(J-I, S1, H0, H1)
	),
	ti_delta_holes(Ds, H1, H).

ti_delta_set(Key, S, H0, H) :-
	get_assoc(Key, H0, Hole0, H, Hole), !,
	'$fd_dom_subtract'(Hole0, S, Hole).
ti_delta_set(Key, S, H0, H) :-
	'$fd_dom_complement'(S, Hole),
	put_assoc(Key, H0, Hole, H).

ti_delta_hole(_  , LB, UB, H0, H) :-
	integer(LB),
	integer(UB),
	LB > UB, !,
	H = H0.
ti_delta_hole(Key, LB, UB, H0, H) :-
	get_assoc(Key, H0, Hole0, H, Hole), !,
	fdset_parts(Part, LB, UB, []),
	'$fd_dom_union'(Hole0, Part, Hole).
ti_delta_hole(Key, LB, UB, H0, H) :-
	put_assoc(Key, H0, Hole, H),
	fdset_parts(Hole, LB, UB, []).

ti_one_less_pos(P, X) :- integer(P), !, X is P-1.
ti_one_less_pos(sup, sup).

ti_one_less_neg(P, X) :- integer(P), !, X is 1-P.
ti_one_less_neg(sup, inf).

ti_deltas([_], _, _H, _, _Goal) --> !.
ti_deltas([Taski|Tasks], I, H, Limit, Goal) -->
	{Taski = task(_,SM,_,DM,_,RM,_,_),
	 get_mutable_rec(SD, SM),
	 SD = dom(_,Mini,Maxi,_),
	 get_mutable_rec(DD, DM),
	 DD = dom(_,Duri,_,_),
	 get_mutable_rec(RD, RM),
	 RD = dom(_,Resi,_,_),
	 MaxRes is Limit-Resi,
	 J is I+1},
	ti_deltas(Tasks, I, J, H, Mini, Maxi, Duri, MaxRes, Goal),
	ti_deltas(Tasks, J, H, Limit, Goal).

ti_deltas([], _, _, _H, _, _, _, _, _Goal) --> [].
ti_deltas([Taskj|Tasks], I, J, H, Mini, Maxi, Duri, MaxRes, Goal) -->
	[d(I,J,Mij)],
	{Taskj = task(_,SM,_,DM,_,RM,_,_),
	 get_mutable_rec(SD, SM),
	 SD = dom(_,Minj,Maxj,_),
	 get_mutable_rec(DD, DM),
	 DD = dom(_,Durj,_,_),
	 get_mutable_rec(RD, RM),
	 RD = dom(_,Resj,_,_),
	 A is Minj-Maxi,
	 D is Maxj-Mini,
	 fdset_parts(Set0, A, D, []),
	 (   Resj>MaxRes ->
	     ti_constrain_dur(Duri, Durj, Set0, Set1)
	 ;   Set1 = Set0
	 ),
	 ti_constrain_precedence(I, J, H, Set1, Set),
	 Set \== [],
	 create_mutable(Set, Mij),
	 K is J+1},
	ti_deltas(Tasks, I, K, H, Mini, Maxi, Duri, MaxRes, Goal).

% For now, any task can be pre-empted by a zero-duration task.
ti_constrain_dur(0, _, Set, Set) :- !.
ti_constrain_dur(_, 0, Set, Set) :- !.
ti_constrain_dur(Duri, Durj, Set0, Set) :-
	Subl is 1-Durj,
	Subu is Duri-1,
	fdset_parts(Sub, Subl, Subu, []),
	'$fd_dom_subtract'(Set0, Sub, Set).

ti_constrain_precedence(I, J, H, Set0, Set) :-
	get_assoc(I-J, H, Hole), !,
	'$fd_dom_subtract'(Set0, Hole, Set).
ti_constrain_precedence(_, _, _, Set, Set).

task_order(Tasks, Diffs, Limit, Flags, Global, Goal) :-
	task_order_susp1(Tasks, Tasks2, Susp, [max(Limit)]),
	length(Tasks, N),
	functor(Goal, _, A),
	arg(A, Goal, Options),
	fd_global_internal(task_order(Tasks2,Limit,Options),
			   f(N,Tasks,Diffs,Limit,Flags,N,0,_Handle,0),
			   Susp, Global, clpfd:Goal, 0).

task_order_susp1([], []) --> [].
task_order_susp1([task(S,_,D,_,R,_,_,_)|L1], [task(S,D,R)|L2]) -->
	[minmax(S),min(D),min(R)],
	task_order_susp1(L1, L2).

/****************************************************************/
/* count/4							*/
/****************************************************************/

count(Value, Xs, Rel, Card) :-
	fdset_singleton(Set, Value),
	count_aux(Xs, Set, Bs),
	sum(Bs, Rel, Card).

count_aux([], _, []).
count_aux([X|Xs], Set, [B|Bs]) :-
	in_set_iff_rt(X, Set, B),
	count_aux(Xs, Set, Bs).


/****************************************************************/
/* sum/3, scalar_product/4					*/
/****************************************************************/

sum(Xs, Rel, S) :-
	ones(Xs, Cs),
	scalar_product(Cs, Xs, Rel, S).

ones([], []).
ones([_|L1], [1|L2]) :- ones(L1, L2).

scalar_product(Cs, Xs, Rel, S) :-
	Goal = scalar_product(Cs,Xs,Rel,S),
	must_be_dvar_list(Xs, Goal, 2),
	must_be_dvar_list([S], Goal, 4),
	scalar_state(Cs, Xs, none, S, Vec, Sum, Susp, Goal),
	(   Rel==(#=),
	    \+'$fd_coref'(Susp)
	->  length(Vec, N),
	    sp_strength_reduce(N, Vec, Sum, Goal, Susp)
	;   scalar_op(Rel, Op, Sum, RHS),
	    fd_global(Goal,
		      state(Vec,Op,RHS,0/*Nground*/,_,0),
		      Susp)
	).

scalar_op(#=<, 1, Sum, Sum).
scalar_op(#<,  1, Sum, Sum1) :- Sum1 is Sum-1.
scalar_op(#>=, 2, Sum, Sum).
scalar_op(#>,  2, Sum, Sum1) :- Sum1 is Sum+1.
scalar_op(#=,  3, Sum, Sum).
scalar_op(#\=, 4, Sum, Sum).

%%% This is not an exhaustive list.

sp_strength_reduce(0, [], S, _Goal, _Susp) :- !, S = 0.
sp_strength_reduce(1, [f(C1,X1,_M1)], S, _Goal, _Susp) :- !,
	S mod C1 =:= 0,
	S1 is S//C1,
	't=c'(X1, S1).
sp_strength_reduce(2, [f(C1,X1,M1),f(C2,X2,M2)], S, Goal, Susp) :-
	'$fd_debug'(off,off,1), !,
	sp_strength_reduce_2(C1, X1, M1, C2, X2, M2, S, Goal, Susp).
sp_strength_reduce(3, [f(C1,X1,M1),f(C2,X2,M2),f(C3,X3,M3)], S, Goal, Susp) :-
	'$fd_debug'(off,off,1), !,
	sp_strength_reduce_3(C1, X1, M1, C2, X2, M2, C3, X3, M3, S, Goal, Susp).
sp_strength_reduce(_, Vec, Sum, Goal, Susp) :-
	fd_global(Goal, state(Vec,3,Sum/*RHS*/,0/*Nground*/,_,0), Susp).


sp_strength_reduce_2(1, X1, _M1, 1, X2, _M2, S, _Goal, _Susp) :- !,
	't+u=c'(X1, X2, S).
sp_strength_reduce_2(-1, X1, _M1, 1, X2, _M2, S, _Goal, _Susp) :- !,
	't=u+c'(X2, X1, S).
sp_strength_reduce_2(1, X1, _M1, -1, X2, _M2, S, _Goal, _Susp) :- !,
	't=u+c'(X1, X2, S).
sp_strength_reduce_2(-1, X1, _M1, -1, X2, _M2, S, _Goal, _Susp) :- !,
	S1 is -S, 
	't+u=c'(X1, X2, S1).
sp_strength_reduce_2(1, X1, _M1, C2, X2, _M2, S, _Goal, _Susp) :- C2>0, !,
	'ax+y=t'(C2, X2, X1, S).
sp_strength_reduce_2(1, X1, _M1, C2, X2, _M2, S, _Goal, _Susp) :- C2<0, !,
	C3 is -C2,
	'ax+y=t'(C3, X2, S, X1).
sp_strength_reduce_2(C1, X1, _M1, 1, X2, _M2, S, _Goal, _Susp) :- C1>0, !,
	'ax+y=t'(C1, X1, X2, S).
sp_strength_reduce_2(C1, X1, _M1, 1, X2, _M2, S, _Goal, _Susp) :- C1<0, !,
	C3 is -C1,
	'ax+y=t'(C3, X1, S, X2).
% sp_strength_reduce_2(C1, X1, _M1, C2, X2, _M2, S, _Goal, _Susp) :- C1>0, C2>0, !,
% 	S mod gcd(C1,C2) =:= 0,
% 	'ax+by=t'(C1, X1, C2, X2, S).
% sp_strength_reduce_2(C1, X1, _M1, C2, X2, _M2, S, _Goal, _Susp) :- C1<0, C2<0, !,
% 	C3 is -C1, C4 is -C2, S1 is -S,
% 	S mod gcd(C3,C4) =:= 0,
% 	'ax+by=t'(C3, X1, C4, X2, S1).
sp_strength_reduce_2(C1, X1, M1, C2, X2, M2, Sum, Goal, Susp) :-
	fd_global(Goal, state([f(C1,X1,M1),f(C2,X2,M2)],3,Sum/*RHS*/,0/*Nground*/,_,0), Susp).

sp_strength_reduce_3(1, X1, _M1, 1, X2, _M2, 1, X3, _M3, S, _Goal, _Susp) :- !,
	'x+y+z=c'(X1, X2, X3, S).
sp_strength_reduce_3(-1, X1, _M1, 1, X2, _M2, 1, X3, _M3, S, _Goal, _Susp) :- !,
	'x+y=u+c'(X2, X3, X1, S).
sp_strength_reduce_3(1, X1, _M1, -1, X2, _M2, 1, X3, _M3, S, _Goal, _Susp) :- !,
	'x+y=u+c'(X1, X3, X2, S).
sp_strength_reduce_3(-1, X1, _M1, -1, X2, _M2, 1, X3, _M3, S, _Goal, _Susp) :- !,
	't=x+y+c'(X3, X1, X2, S).
sp_strength_reduce_3(1, X1, _M1, 1, X2, _M2, -1, X3, _M3, S, _Goal, _Susp) :- !,
	'x+y=u+c'(X1, X2, X3, S).
sp_strength_reduce_3(-1, X1, _M1, 1, X2, _M2, -1, X3, _M3, S, _Goal, _Susp) :- !,
	't=x+y+c'(X2, X3, X1, S).
sp_strength_reduce_3(1, X1, _M1, -1, X2, _M2, -1, X3, _M3, S, _Goal, _Susp) :- !,
	't=x+y+c'(X1, X3, X2, S).
sp_strength_reduce_3(-1, X1, _M1, -1, X2, _M2, -1, X3, _M3, S, _Goal, _Susp) :- !,
	S1 is -S,
	'x+y+z=c'(X1, X2, X3, S1).
sp_strength_reduce_3(C1, X1, M1, C2, X2, M2, C3, X3, M3, Sum, Goal, Susp) :-
	fd_global(Goal, state([f(C1,X1,M1),f(C2,X2,M2),f(C3,X3,M3)],3,Sum/*RHS*/,0/*Nground*/,_,0), Susp).


scalar_state(Cs, Xs, Rel, S, Vec, Sum, Susp, Goal) :-
	integer(S), !,
	scalar_vector(Cs, Xs, Rel, S, Vec, Sum, Susp, Goal).
scalar_state(Cs, Xs, Rel, S, Vec, Sum, Susp, Goal) :-
	scalar_vector([-1|Cs], [S|Xs], Rel, 0, Vec, Sum, Susp, Goal).

/* Now done at compile time only.
scalar_vector(Cs, Xs, Rel, S, Vec, Sum, Susp, Goal) :-
	keys_values_pairs(Xs, Cs, L1),
	keysort(L1, L2),
	keyfuse(L2, L3),
	scalar_vector(L3, Rel, S, Vec, Sum, Susp, Goal).
*/

scalar_vector([], [], _, Sum, [], Sum, [], _Goal).
scalar_vector([C|Cs], [X|Xs], Rel, S0, Vec, S, Susp, Goal) :-
	integer(X), !,
	S1 is S0-C*X,
	scalar_vector(Cs, Xs, Rel, S1, Vec, S, Susp, Goal).
scalar_vector([C|Cs], [X|Xs], Rel, S0, [f(C,X,M)|Vec], S, [Sus|Susp], Goal) :- 
	C=\=0, !,
	arg_attribute(X, M, Goal, 2),
	susp_type(Rel, C, X, Sus),
	scalar_vector(Cs, Xs, Rel, S0, Vec, S, Susp, Goal).
scalar_vector([_|Cs], [_|Xs], Rel, S0, Vec, S, Susp, Goal) :-
	scalar_vector(Cs, Xs, Rel, S0, Vec, S, Susp, Goal).

susp_type(#<, C, X, Type) :- susp_type(#=<, C, X, Type).
susp_type(#=<, C, X, Type) :- C>0 -> Type = min(X); Type = max(X).
susp_type(#>, C, X, Type) :- susp_type(#>=, C, X, Type).
susp_type(#>=, C, X, Type) :- C>0 -> Type = max(X); Type = min(X).
susp_type(#=, _, X, minmax(X)).
susp_type(#\=, _, X, val(X)).
susp_type(dom, _, X, dom(X)).
susp_type(none, _, X, none(X)).

/****************************************************************/
/* knapsack/3           					*/
/****************************************************************/

knapsack(Cs, Xs, S) :-
	Goal = knapsack(Cs,Xs,S),
	must_be_list_of_finite_dvar(Xs, Goal, 2),
	finite_arg_attribute(S, SD, Goal, 3),
	keys_values_pairs(Xs, Cs, L1),
	keysort(L1, L2),
	keyfuse(L2, L3),
	keys_and_values(L3, Xs2, Cs2),
	scalar_state(Cs2, Xs2, none, S, Vec1, Sum1, Susp1, Goal),
	fd_global_internal(scalar_product(Cs2,Xs2,#=,S),
			   state(Vec1,3,Sum1/*RHS*/,0/*Nground*/,_,0),
			   Susp1,
			   _, true/*hide from call_residue*/, 0),
	scalar_state(Cs2, Xs2, dom, 0, Vec, Sum, Susp2, Goal),
	nonnegative_vector(Vec),
	fd_global(Goal, state(Vec,S-SD,Sum/*RHS*/,0/*Nground*/,_,0), [minmax(S)|Susp2]).

nonnegative_vector([]).
nonnegative_vector([f(C,X,_)|Vec]) :-
	C >= 0,
	't>=c'(X, 0),
	nonnegative_vector(Vec).

/****************************************************************/
/* 'x*x=y'/2							*/
/****************************************************************/

'x*x=y'(X, Y) :-
	integer(X), !,
	Y is X*X.
'x*x=y'(X, Y) :-
	integer(Y), !,
	(   Y =:= 0 -> '$fd_range'(0, 0, R, 1)
	;   Y >= 0,
	    X1 is integer(sqrt(Y)),
	    X1*X1 =:= Y,
	    X0 is -X1,
	    '$fd_range'(X0, X0, R0, 1),
	    '$fd_dom_insert'(R0, X1, R)
	),
	prune_and_propagate_chk(X, R).
'x*x=y'(X, Y) :-
	Goal = 'x*x=y'(X,Y),
	arg_attribute(X, XM, Goal, 1),
	arg_attribute(Y, YM, Goal, 2),
	Y in 0..sup,
	on_minmax([X,Y], Susp, []),
	fd_global_internal(Goal, state(X,XM,Y,YM), Susp, _, clpfd:Goal, 4).

/****************************************************************/
/* 'x*y=z'/3							*/
/****************************************************************/

'x*y=z'(X, Y, Z) :-
	Goal = 'x*y=z'(X,Y,Z),
	arg_attribute(X, XM, Goal, 1),
	arg_attribute(Y, YM, Goal, 2),
	arg_attribute(Z, ZM, Goal, 3),
	on_minmax([X,Y,Z], Susp, []),
	fd_global_internal(Goal, state(X,XM,Y,YM,Z,ZM), Susp, _, clpfd:Goal, 4).

% for compatibility with formulas saved prior to 3.11.2:
'-ax=t'(A,X,T) +:
	X in   -max(T) /< A .. -min(T) /> A,
	T in !(-max(X) *  A .. -min(X) *  A).

/****************************************************************/
/* 'x/y=z'/3							*/
/****************************************************************/

'x/y=z'(X, Y, Z) :-
	Goal = 'x/y=z'(X,Y,Z),
	't\\=c'(Y, 0),
	arg_attribute(X, XM, Goal, 1),
	arg_attribute(Y, YM, Goal, 2),
	arg_attribute(Z, ZM, Goal, 3),
	on_minmax([X,Y,Z], Susp, []),
	fd_global_internal(Goal, state(X,XM,Y,YM,Z,ZM), Susp, _, clpfd:Goal, 4). 

/****************************************************************/
/* 'x mod y=z'/3						*/
/****************************************************************/

'x mod y=z'(X, Y, Z) :-
	Goal = 'x mod y=z'(X,Y,Z),
	't\\=c'(Y, 0),
	arg_attribute(X, XM, Goal, 1),
	arg_attribute(Y, YM, Goal, 2),
	arg_attribute(Z, ZM, Goal, 3),
	on_minmax([X,Y,Z], Susp, []),
	fd_global_internal(Goal, state(X,XM,Y,YM,Z,ZM), Susp, _, clpfd:Goal, 4).

/****************************************************************/
/* min/3, max/3 etc						*/
/****************************************************************/

'min(x,y)=z'(X, Y, Z) :-
	X #>= Z,
	Y #>= Z,
	'oneof(x,y)=z'(X, Y, Z).

'max(x,y)=z'(X, Y, Z) :-
	X #=< Z,
	Y #=< Z,
	'oneof(x,y)=z'(X, Y, Z).

'oneof(x,y)=z'(X, Y, Z) :-
	'$fd_debug'(on,on,1), !,
	oneof(X, Y, Z).
'oneof(x,y)=z'(X, Y, Z) :-
	'oneof(x,y)=z IND'(X, Y, Z).

'oneof(x,y)=z IND'(X, Y, Z) +:
	X in !(((dom(Y)/\dom(Z)) ? (inf..sup)) \/ dom(Z)),
	Y in !(((dom(X)/\dom(Z)) ? (inf..sup)) \/ dom(Z)),
	Z in !((dom(X)\/dom(Y))).

'|x|=y'(X,Y) :-
	'$fd_debug'(on,on,1), !,
	abs(X, Y).
'|x|=y'(X,Y) :-
	't>=c'(Y, 0),				% do this outside the loop
	'|x|=y 1'(X,Y).

'|x|=y 1'(X,Y) +:
	X in !(dom(Y) \/ (0-dom(Y))),
	Y in !(dom(X) \/ (0-dom(X))).

%%% Support for reified constraints (domain reasoning for now)

% optimized for common cases
'x=y'(X, Y) :- integer(Y), !,
	't=c'(X, Y).
'x=y'(X, Y) :- integer(X), !,
	't=c'(Y, X).
'x=y'(X, Y) :-
	't=u'(X, Y).


% Now domain consistent!
't=u'(T, U) :-
	'$fd_debug'(on,on,1), !,
	T = U.
't=u'(U, U). % [MC] 3.11.3
%	't=u IND'(T, U).

't=u IND'(X,Y) +:
	X in !(dom(Y)),
	Y in !(dom(X)).
't=u IND'(X,Y) -:
	X in \{Y},
	Y in \{X}.
% 't=u IND'(X,Y) +?				% covered by next rule
%	X in {Y}.
't=u IND'(X,Y) -?
	X in \dom(Y).

% Now domain consistent!
% just the negation of the above
'x\\=y'(T, U) :-
	'$fd_debug'(on,on,1), !,
	eq_iff(T, U, 0).
'x\\=y'(T, U) :-
	'x\\=y IND'(T, U).

'x\\=y IND'(X,Y) -:
	X in !(dom(Y)),
	Y in !(dom(X)).
'x\\=y IND'(X,Y) +:
	X in \{Y},
	Y in \{X}.
% 'x\\=y IND'(X,Y) -?			% covered by next rule
%	X in {Y}.
'x\\=y IND'(X,Y) +?
	X in \dom(Y).

'x=<y'(T, U) :-
	'$fd_debug'(on,on,1), !,
	le_iff(T, U, 1).
'x=<y'(T, U) :-
	'x=<y IND'(T, U).

'x=<y IND'(X,Y) +:
	X in inf..max(Y),
	Y in min(X)..sup.
'x=<y IND'(X,Y) -:
	X in (min(Y)+1)..sup,
	Y in inf..(max(X)-1).
'x=<y IND'(X,Y) +?
	X in inf..min(Y).
'x=<y IND'(X,Y) -?				% NOT covered by prev rule
	X in (max(Y)+1)..sup.

in_aux_rt(X, Expr) :-
	ground(Expr),
	set_expression_check(Expr, Set, X in Expr, 2),
	prune_and_propagate_chk(X, Set).

in_aux_rt(X, Expr, B) :-
	ground(Expr),
	set_expression_check(Expr, Set, X in Expr #<=> B, 1),
	in_set_iff_rt(X, Set, B).


in_set_aux_rt(X, Set) :-
	'$fd_size'(Set, _, 1), !,
	'$fd_dom_union'(Set, [], Copy),	% Set could occur multiple times
	prune_and_propagate_chk(X, Copy).
in_set_aux_rt(X, Set) :-
	ill_formed_constraint(X in_set Set, Goal), call(Goal).

in_set_aux_rt(X, Set, Bool) :-
	'$fd_size'(Set, _, 1), !,
	'$fd_dom_union'(Set, [], Copy),	% Set could occur multiple times
	in_set_iff_rt(X, Copy, Bool).
in_set_aux_rt(X, Set, B) :-
	ill_formed_constraint(X in_set Set #<=> B, Goal), call(Goal).

in_set_iff_rt(X, Set, B) :-
	'$fd_debug'(off,off,1), !,
	Constraint = in_set_ix(X,Set),
	'$fd_find_definition'(Constraint, clpfd, DefPtr),
	arg_attribute(X, A, Constraint, 1),
	Attv =  in_set_ix(A,Set),
	iff_aux(DefPtr, Constraint, Attv, B).
in_set_iff_rt(X, Set, B) :-
	in_set_iff(X, Set, B).

in_set_ix(X, Set) +:
	X in set(Set).
in_set_ix(X, Set) -:
	X in \set(Set).
in_set_ix(X, Set) +?
	X in set(Set).

%% fdbg support

in_set_iff(X, Set, B) :-
	Goal = in_set_iff(X,Set,B),
	arg_attribute(X, XMut, Goal, 1),
	arg_attribute(B, BMut, Goal, 3),
	propagate_interval(B, 0, 1),
	fd_global(Goal, state(X,XMut,Set,B,BMut,_handle), [dom(X),dom(B)]).

eq_iff(X, Y, B) :-
	Goal = eq_iff(X,Y,B),
	arg_attribute(X, XMut, Goal, 1),
	arg_attribute(Y, YMut, Goal, 2),
	arg_attribute(B, BMut, Goal, 3),
	propagate_interval(B, 0, 1),
	(   B==1 -> X = Y
	;   B==0
	->  fd_global(Goal, state(X,XMut,Y,YMut,B,BMut), [val(X),val(Y),dom(B)])
	;   fd_global(Goal, state(X,XMut,Y,YMut,B,BMut), [dom(X),dom(Y),dom(B)])
	).

le_iff(X, Y, B) :-
	Goal = le_iff(X,Y,B),
	arg_attribute(X, XMut, Goal, 1),
	arg_attribute(Y, YMut, Goal, 2),
	arg_attribute(B, BMut, Goal, 3),
	propagate_interval(B, 0, 1),
	fd_global(Goal, state(X,XMut,Y,YMut,B,BMut), [minmax(X),minmax(Y),dom(B)]).

oneof(X, Y, Z) :-
	Goal = oneof(X,Y,Z),
	arg_attribute(X, XMut, Goal, 1),
	arg_attribute(Y, YMut, Goal, 2),
	arg_attribute(Z, ZMut, Goal, 3),
	fd_global(Goal, state(X,XMut,Y,YMut,Z,ZMut), [dom(X),dom(Y),dom(Z)]).

abs(X, Y) :-
	Goal = abs(X,Y),
	arg_attribute(X, XMut, Goal, 1),
	arg_attribute(Y, YMut, Goal, 2),
	fd_global(Goal, state(X,XMut,Y,YMut), [dom(X),dom(Y)]).

%% end fdbg support

/****************************************************************/
/* bool/4							*/
/****************************************************************/

bool(Fun, X, Y, Z) :-
	Goal = bool(Fun,X,Y,Z),
	arg_attribute(X, XMut, Goal, 1),
	arg_attribute(Y, YMut, Goal, 2),
	arg_attribute(Z, ZMut, Goal, 3),
	propagate_interval(X, 0, 1),
	propagate_interval(Y, 0, 1),
	propagate_interval(Z, 0, 1),
	on_dom([X,Y,Z], Susp, []),
	fd_global(Goal, state(X,XMut,Y,YMut,Z,ZMut,Fun), Susp).

% FOR BACKWARD COMPATIBILITY!

'\\p'(P, B) :- bool(6, P, B, 1).

'p/\\q'(P, Q, B) :- bool(0, P, Q, B).

'p\\q'(P, Q, B) :- bool(6, P, Q, B).

'p\\/q'(P, Q, B) :- bool(3, P, Q, B).

'p=>q'(P, Q, B) :- bool(4, Q, P, B).

'p<=>q'(P, Q, B) :- bool(7, P, Q, B).

/****************************************************************/
/* domain/3							*/
/****************************************************************/

domain(Vars, Min, Max) :-
	Goal = domain(Vars,Min,Max),
	must_be_dvar_list(Vars, Goal, 1),
	set_expression_check(Min..Max, Set, Goal, 0),
	domain(Vars, Set).

% FDBG puts advice on this!
domain([], _Set) :- !.
domain(Vars, Set) :-
	Set = [[A|B]], !,
	domain1(Vars, A, B, 1),
	'$fd_evaluate_indexical'(RC, Global),
	evaluate(RC, Global).
domain(Vars, Set) :-
	domain2(Vars, Set, 1),
	'$fd_evaluate_indexical'(RC, Global),
	evaluate(RC, Global).

% interval
domain1([], _, _, _).
domain1([X|Xs], A, B, Init) :-
	'$fd_in_interval'(X, A, B, Init),
	domain1(Xs, A, B, 0).

% set --- must maintain copies if multiple occs
domain2([], _, _).
domain2([X|Xs], Set, 1) :- !,
	'$fd_in_set'(X, Set, 1),
	domain2(Xs, Set, 0).
domain2([X|Xs], Set, 0) :-
	'$fd_dom_union'(Set, [], Copy),	% Set could occur multiple times
	'$fd_in_set'(X, Copy, 0),
	domain2(Xs, Set, 0).

%%% predicates corresponding to macro-expanded constraints

X in Expr :-
	in_aux_rt(X, Expr).

X in_set Set :-
	in_set_aux_rt(X, Set).

X #= Y :-
	fd_goal_expansion(X #= Y, clpfd, Goal),
	Goal.

X #\= Y :-
	fd_goal_expansion(X #\= Y, clpfd, Goal),
	Goal.

X #< Y :-
	fd_goal_expansion(X #< Y, clpfd, Goal),
	Goal.

X #=< Y :-
	fd_goal_expansion(X #=< Y, clpfd, Goal),
	Goal.

X #> Y :-
	fd_goal_expansion(X #> Y, clpfd, Goal),
	Goal.

X #>= Y :-
	fd_goal_expansion(X #>= Y, clpfd, Goal),
	Goal.

:- meta_predicate #\(:).
#\ Q :-
	fd_goal_expansion(#\ Q, clpfd, Goal),
	Goal.

:- meta_predicate #/\(:,:).
P #/\ Q :-
	fd_goal_expansion(P #/\ Q, clpfd, Goal),
	Goal.

:- meta_predicate #\(:,:).
P #\ Q :-
	fd_goal_expansion(P #\ Q, clpfd, Goal),
	Goal.

:- meta_predicate #\/(:,:).
P #\/ Q :-
	fd_goal_expansion(P #\/ Q, clpfd, Goal),
	Goal.

:- meta_predicate #=>(:,:).
P #=> Q :-
	fd_goal_expansion(P #=> Q, clpfd, Goal),
	Goal.

:- meta_predicate #<=(:,:).
P #<= Q :-
	fd_goal_expansion(P #<= Q, clpfd, Goal),
	Goal.

:- meta_predicate #<=>(:,:).
P #<=> Q :-
	fd_goal_expansion(P #<=> Q, clpfd, Goal),
	Goal.

/****************************************************************/
/* disjoint1/[1,2]                          			*/
/****************************************************************/

disjoint1(Items) :-
	disjoint1(Items, []).

disjoint1(Items, Options) :-
	Goal = disjoint1(Items,Options),
	disjoint1_options(Options, opt(0,inf,sup,[]), Opt, Goal, 2),
	(   Opt = opt(Flags,Min,B,_),
	    Flags /\ 2 =:= 2
	->  Max is B-1
	;   Min = inf, Max = sup
	),
	mkitems(Items, Items2, Min, Max, Goal, Susp, []),
	length(Items2, N),
	fd_global(Goal, f(N,Opt,Items2,N,0,_Handle,0), Susp).


disjoint1_options(L, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
disjoint1_options([], Opt, Opt, _, _) :- !.
disjoint1_options([X|L], Opt0, Opt, Goal, ArgNo) :- !,
	(   disjoint1_option(X, Goal, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,disjoint1_option), Goal, ArgNo, X)
        ),
	disjoint1_options(L, Opt1, Opt, Goal, ArgNo).
disjoint1_options(L, _, _, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Goal, ArgNo, L).

% opt(2'AMXD,Min,Max,Margins) where
% A = global
% M = Margins \== []
% X = wrap-around
% D = decomposition
% Min..Max is the interval subject to wrap-around
% Margins = list of margin(Type1,Type2,Diff) = list of extra margins
disjoint1_option(-, _, _, _) :- !, fail.
disjoint1_option(decomposition(B), _, opt(Flags0,Min,Max,Ms), opt(Flags,Min,Max,Ms)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -2) \/ Value.
disjoint1_option(global(B), _, opt(Flags0,Min,Max,Ms), opt(Flags,Min,Max,Ms)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -9) \/ (Value<<3).
disjoint1_option(wrap(Min,Max), _, opt(Flags0,_,_,Ms), opt(Flags,Min,Max,Ms)) :-
	(   Min==inf, Max==sup -> Flags is Flags0 /\ -3
	;   integer(Min),
	    integer(Max),
	    Min < Max,
	    Flags is (Flags0 /\ -3) \/ 2
	).
disjoint1_option(margin(T1,T2,D), _, opt(Flags0,Min,Max,Tail), opt(Flags,Min,Max,[margin(T1,T2,D)|Tail])) :-
	Flags is (Flags0 /\ -5) \/ 4.
disjoint1_option(lean(B), _, opt(Flags0,Min,Max,Ms), opt(Flags,Min,Max,Ms)) :-
	bool_option(B, Value),	% optimize for the incremental case
	Flags is (Flags0 /\ -33) \/ (Value<<5).


mkitems([], [], _, _, _) --> [].
mkitems([X|Xs], [item(S,SM,D,DM,Type)|Items], Min, Max, Goal) -->
	[minmax(S),min(D)],
	{arg(1,X,S), arg(2,X,D)},
	{arg(3,X,Type) -> true; Type=0},
	{finite_arg_attribute(S, SM, Goal, 1)},
	{finite_arg_attribute(D, DM, Goal, 1)},
	{propagate_interval(S, Min, Max)},
	mkitems(Xs, Items, Min, Max, Goal).

/****************************************************************/
/* disjoint2/[1,2]                          			*/
/****************************************************************/

disjoint2(Items) :-
	disjoint2(Items, []).

disjoint2(Items, Options) :-
	Goal = disjoint2(Items,Options),
	disjoint2_options(Options, opt(0,inf,sup,inf,sup,[]), Opt, Goal, 2),
	Opt = opt(Flags,Min1,B1,Min2,B2,_),
	(   Flags /\ 2 =:= 2
	->  Max1 is B1-1
	;   Min1 = inf, Max1 = sup
	),
	(   Flags /\ 4 =:= 4
	->  Max2 is B2-1
	;   Min2 = inf, Max2 = sup
	),
	mkitems(Items, Items2, Min1, Max1, Min2, Max2, Goal, Susp, []),
	length(Items2, N),
	fd_global(Goal, f(N,Opt,Items2,N,0,_Handle,0), Susp).


disjoint2_options(L, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
disjoint2_options([], Opt, Opt, _, _) :- !.
disjoint2_options([X|L], Opt0, Opt, Goal, ArgNo) :- !,
	(   disjoint2_option(X, Goal, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,disjoint2_option), Goal, ArgNo, X)
        ),
	disjoint2_options(L, Opt1, Opt, Goal, ArgNo).
disjoint2_options(L, _, _, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Goal, ArgNo, L).

% opt(2'AMYXD,Min1,Max1,Min2,Max2,Margins) where
% A = global
% M = Margins \== []
% Y = wrap-around in Y dim
% X = wrap-around in X dim
% D = decomposition
% Min..Max is the interval subject to wrap-around
% Margins = list of margin(Type1,Type2,Diff1,Diff2) = list of extra margins
disjoint2_option(-, _, _, _) :- !, fail.
disjoint2_option(decomposition(B), _, 
		 opt(Flags0,Min1,Max1,Min2,Max2,Ms), 
		 opt(Flags,Min1,Max1,Min2,Max2,Ms)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -2) \/ Value.
disjoint2_option(global(B), _, 
		 opt(Flags0,Min1,Max1,Min2,Max2,Ms), 
		 opt(Flags,Min1,Max1,Min2,Max2,Ms)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -17) \/ (Value<<4).
disjoint2_option(wrap(Min1,Max1,Min2,Max2), _, 
		 opt(Flags0,_,_,_,_,Ms), 
		 opt(Flags,Min1,Max1,Min2,Max2,Ms)) :-
	(   Min1==inf, Max1==sup -> Flags1 is (Flags0 /\ -3)
	;   integer(Min1),
	    integer(Max1),
	    Min1 < Max1,
	    Flags1 is (Flags0 /\ -3) \/ 2
	),
	(   Min2==inf, Max2==sup -> Flags is (Flags1 /\ -5)
	;   integer(Min2),
	    integer(Max2),
	    Min2 < Max2,
	    Flags is (Flags1 /\ -5) \/ 4
	).
disjoint2_option(margin(T1,T2,D1,D2), _, 
		 opt(Flags0,Min1,Max1,Min2,Max2,Tail), 
		 opt(Flags,Min1,Max1,Min2,Max2,[margin(T1,T2,D1,D2)|Tail])) :-
	Flags is (Flags0 /\ -9) \/ 8.
disjoint2_option(lean(B), _, 
		 opt(Flags0,Min1,Max1,Min2,Max2,Ms), 
		 opt(Flags,Min1,Max1,Min2,Max2,Ms)) :-
	bool_option(B, Value),	% optimize for the incremental case
	Flags is (Flags0 /\ -33) \/ (Value<<5).
disjoint2_option(synchronization(B), _, 
		 opt(Flags0,Min1,Max1,Min2,Max2,Ms), 
		 opt(Flags,Min1,Max1,Min2,Max2,Ms)) :-
	bool_option(B, Value),
	Flags is (Flags0 /\ -65) \/ (Value<<6).


% S1,S2 - start variables
% SM1,SM2 - start domain mutables
% D1,D2 - durations
% Type - type of object (optional)
mkitems([], [], _, _, _, _, _) --> [].
mkitems([X|Xs], [item(S1,SM1,D1,DM1,S2,SM2,D2,DM2,Type)|Items],
	Min1, Max1, Min2, Max2, Goal) -->
	[minmax(S1),min(D1),minmax(S2),min(D2)],
	{arg(1,X,S1), arg(2,X,D1), arg(3,X,S2), arg(4,X,D2)},
	{arg(5,X,Type) -> true; Type=0},
	{finite_arg_attribute(S1, SM1, Goal, 1)},
	{finite_arg_attribute(D1, DM1, Goal, 1)},
	{finite_arg_attribute(S2, SM2, Goal, 1)},
	{finite_arg_attribute(D2, DM2, Goal, 1)},
	{propagate_interval(S1, Min1, Max1)},
	{propagate_interval(S2, Min2, Max2)},
	mkitems(Xs, Items, Min1, Max1, Min2, Max2, Goal).

/****************************************************************/
/* case/[3,4]							*/
/****************************************************************/

% Consistency rules:
% VARS(DAG) = VARS(Template)
% VARS(OnSpec) \subseteq VARS(Template)
% VARS(PruneSpec) \subseteq VARS(Template)
% VARS(Tuples) \disjoint VARS(Template)
% every ID integer and unique
% all paths complete
case(Template, Tuples, Dag) :-
	case(Template, Tuples, Dag, []).

case(Template, Tuples, Dag, Options) :-
	Goal = case(Template,Tuples,Dag,Options),
	(   select(leaves(TLeaf,Leaves), Options, Options1)
	->  UseLeaf = 1,
	    Template1 = Template-TLeaf,
	    keys_values_pairs(Tuples, Leaves, Tuples1)
	;   Options1 = Options,
	    UseLeaf = 0,
	    TLeaf = [],
	    Leaves = [],
	    Template1 = Template,
	    Tuples1 = Tuples
	),
	prolog:'$term_variables'(Template1, Vars), % TLeaf must be last!
	sort(Vars, TemplateVars),
	prolog:term_variables(Dag-TLeaf, DagVars),
	prolog:term_variables(Options1, OptionsVars),
	prolog:term_variables(Tuples1, TuplesVars),
	(   DagVars==TemplateVars -> true
	;   fd_illarg(consistency(Template,Dag,''), Goal, 3)
	),
	(   ord_subset(OptionsVars, TemplateVars) -> true
	;   fd_illarg(consistency(Template,Options,''), Goal, 4)
	),
	(   ord_disjoint(TuplesVars, TemplateVars) -> true
	;   fd_illarg(consistency(Template,Tuples,''), Goal, 2)
	),
	length(Vars, NVars),
	doms(NVars, Doms),
	case_options(Options1, opt(Doms,Doms), opt(On,Prune), Vars, Goal, 4),
	length(Dag, NNodes),
	case_compile(Dag, Vars, Dag1, NChildren, IDs, Goal),
	(   UseLeaf=:=0 -> LeafSet = []
	;   LeafSet = [N],
	    var_nth(TLeaf, Vars, 0, N)
	),
	(   case_check_dag(Dag1, LeafSet, ID2Set, NVars)
	->  case_descendants(Dag1, ID2Set)
	;   fd_illarg(consistency(Template,Dag,inconsistent_paths), Goal, 3)
	),
	list_to_fdset(IDs, IDset),
	domain(Leaves, IDset),
	case_post(Tuples1, Template1, Vars,
		  NVars, NNodes, NChildren, Dag1, On, Prune, UseLeaf, Goal).

doms(0, []) :- !.
doms(I, [dom|L]) :- J is I-1, doms(J, L).

case_options(L, _, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
case_options([], Opt, Opt, _, _, _) :- !.
case_options([X|L], Opt0, Opt, Vars, Goal, ArgNo) :- !,
	(   case_option(X, Vars, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,case_option), Goal, ArgNo, X)
        ),
	case_options(L, Opt1, Opt, Vars, Goal, ArgNo).
case_options(L, _, _, Vars, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Vars, Goal, ArgNo, L).

case_option(-, _, _, _) :- !, fail.
case_option(on(Spec), Vars, opt(On0,Prune), opt(On,Prune)) :-
	case_spec(Spec, F, Var),
	var_nth(Var, Vars, 0, N),
	replace_nth(N, On0, F, On).
case_option(prune(Spec), Vars, opt(On,Prune0), opt(On,Prune)) :-
	case_spec(Spec, F, Var),
	var_nth(Var, Vars, 0, N),
	replace_nth(N, Prune0, F, Prune).

case_spec(dom(X), dom, X).
case_spec(min(X), min, X).
case_spec(max(X), max, X).
case_spec(minmax(X), minmax, X).
case_spec(val(X), val, X).
case_spec(none(X), none, X).

replace_nth(0, [_|L], F, [F|L]) :- !.
replace_nth(I, [X|L1], F, [X|L2]) :-
	J is I-1,
	replace_nth(J, L1, F, L2).

case_post([], _, _, _, _, _, _, _, _, _, _).
case_post([Tuple|Tuples], Template, Vars,
	  NVars, NNodes, NChildren, Dag1, On, Prune, UseLeaf, Goal) :-
	copy_term(Template-Vars, Tuple-TVars),
	case_susp(TVars, TPairs, On, Susp, Goal),
	fd_global(Goal, state(f(NVars,NNodes,NChildren,TPairs,Dag1,Prune,UseLeaf),_Handle,0), Susp),
	case_post(Tuples, Template, Vars,
		  NVars, NNodes, NChildren, Dag1, On, Prune, UseLeaf, Goal).

case_susp([], [], [], [], _).
case_susp([X|Xs], [X-XM|Ys], [none|On], Zs, Goal) :- !,
	arg_attribute(X, XM, Goal, 2),
	case_susp(Xs, Ys, On, Zs, Goal).
case_susp([X|Xs], [X-XM|Ys], [F|On], [FX|Zs], Goal) :-
	FX =.. [F,X],
	case_spec(FX, F, X),
	arg_attribute(X, XM, Goal, 2),
	case_susp(Xs, Ys, On, Zs, Goal).

case_compile(Dag, Vars, Dag1, NChildren, IDs, Goal) :-
	empty_assoc(ID2Index0),
	case_map(Dag, 0, Dag1, ID2Index0, ID2Index, IDs0, Goal),
	sort(IDs0, IDs),
	(   same_length(IDs0, IDs) -> true
	;   fd_illarg(consistency(Dag,Dag,''), Goal, 3)
	),
	case_compile_dag(Dag, Vars, Dag1, 0, NChildren, ID2Index, Goal).

case_compile_dag([], _, [], NC, NC, _, _).
case_compile_dag([Node|Nodes], Vars, [Node1|Nodes1], NC0, NC, ID2Index, Goal) :-
	Node = node(ID,Var,Children),
	Node1 = dagnode(ID,N,_,Children3,Children),
	var_nth(Var, Vars, 0, N),
	case_children(Children, ID2Index, Children0, Children1),
	keysort(Children1, Children2),
	append(Children0, Children2, Children3),
	(   \+(Children0 = [_,_|_]),
	    case_disjoint_descendants(Children3) -> true
	;   fd_illarg(consistency(Children,Children,''), Goal, 3)
	),
	length(Children3, Len3),
	NC1 is NC0+Len3,
	case_compile_dag(Nodes, Vars, Nodes1, NC1, NC, ID2Index, Goal).

case_children([], _, [], []).
case_children([inf..Max|L1], ID2Index, [(inf..Max)-[]|Ch0], Ch2) :- !,
	case_children(L1, ID2Index, Ch0, Ch2).
case_children([(inf..Max)-ID|L1], ID2Index, [(inf..Max)-Index|Ch0], Ch2) :- !,
	(   integer(ID), get_assoc(ID, ID2Index, Index) -> true
	;   Index = []
	),
	case_children(L1, ID2Index, Ch0, Ch2).
case_children([Min..Max|L1], ID2Index, Ch0, [(Min..Max)-[]|Ch2]) :- !,
	case_children(L1, ID2Index, Ch0, Ch2).
case_children([(Min..Max)-ID|L1], ID2Index, Ch0, [(Min..Max)-Index|Ch2]) :-
	(   integer(ID), get_assoc(ID, ID2Index, Index) -> true
	;   Index = []
	),
	case_children(L1, ID2Index, Ch0, Ch2).

case_disjoint_descendants([]).
case_disjoint_descendants([(Min..Max)-_|Children]) :-
	le(Min, Max),
	case_disjoint_descendants(Children, Max).

case_disjoint_descendants([], _).
case_disjoint_descendants([(Min..Max)-_|Children], Pred) :-
	Pred\==Min,
	le(Pred, Min),
	le(Min, Max),
	case_disjoint_descendants(Children, Max).

le(inf, _) :- !.
le(_, sup) :- !.
le(A, B) :- integer(A), integer(B), A=<B.

case_map([], _, [], A, A, [], _).
case_map([node(ID,_,Children)|Nodes], I, [_|Nodes1], A0, A, IDs0, Goal) :-
	prolog:must_be(ID, integer, Goal, 3),
	case_leaf(Children, ID, IDs0, IDs),
	put_assoc(ID, A0, I, A1),
	J is I+1,
	case_map(Nodes, J, Nodes1, A1, A, IDs, Goal).

case_leaf([_.._|_], ID) --> !, [ID].
case_leaf(_, _) --> [].

case_check_dag(DagNodes, Set0, A, NVars) :-
	dag_vertices_edges(DagNodes, Vertices, Edges),
	vertices_edges_to_ugraph(Vertices, Edges, Graph),
	top_sort(Graph, IDs0),
	reverse(IDs0, IDs),
	ord_list_to_assoc([[]-Set0], A0),
	check_paths(IDs, DagNodes, A0, A),
	DagNodes = [dagnode(RootID,_,_,_,_)|_],
	get_assoc(RootID, A, RootSet),
	length(RootSet, NVars).

dag_vertices_edges([], [], []).
dag_vertices_edges([dagnode(ID,_,_,_,Children)|Dag], [ID|IDs], Edges0) :-
	children_edges(Children, ID, Edges0, Edges),
	dag_vertices_edges(Dag, IDs, Edges).

children_edges([], _ID) --> [].
children_edges([_-X|Children], ID) --> {integer(X)}, !, [ID-X],
	children_edges(Children, ID).
children_edges([_|Children], ID) -->
	children_edges(Children, ID).

check_paths([], _, A, A).
check_paths([ID|IDs], DagNodes, A0, A) :-
	select(dagnode(ID,Var,_,_,Children), DagNodes, DagNodes1), !,
	children_set(Children, A0, Set),
	ord_add_element(Set, Var, Set1),
	Set\==Set1,
	put_assoc(ID, A0, Set1, A1),
	check_paths(IDs, DagNodes1, A1, A).

children_set([Child|Children], A, Set) :-
	child_parts(Child, _, ID),
	get_assoc(ID, A, Set0),
	children_set(Children, A, Set0, Set).
	
children_set([], _, Set, Set).
children_set([Child|Children], A, Set0, Set) :-
	child_parts(Child, _, ID),
	get_assoc(ID, A, Set1),
	Set0==Set1,
	children_set(Children, A, Set0, Set).

child_parts(R-ID, R, ID) :- !.
child_parts(R, R, []).

case_descendants([], _).
case_descendants([dagnode(ID,_,FDSet,_,_)|DagNodes], ID2Set) :-
	get_assoc(ID, ID2Set, Set),
	list_to_fdset(Set, FDSet),
	case_descendants(DagNodes, ID2Set).

/****************************************************************/
/* cumulatives/[2,3]  						*/
/****************************************************************/

cumulatives(Tasks0, Machines) :-
	cumulatives(Tasks0, Machines, []).
		
cumulatives(Tasks, Machines1, Options) :-
	Goal = cumulatives(Tasks, Machines1, Options),
	cumulatives_options(Options, 0, Opt, Goal, 3),
	cum_minmax_tasks(Tasks, Susp, []),
	cum_minmax_fields(Tasks, L1, L2, L3, L4, L5),
	must_be_list_of_finite_dvar(L1, Goal, 1),
	must_be_list_of_finite_dvar(L2, Goal, 1),
	must_be_list_of_finite_dvar(L3, Goal, 1),
	must_be_list_of_finite_dvar(L4, Goal, 1),
	must_be_list_of_finite_dvar(L5, Goal, 1),
	length(Tasks, NT),
	length(Machines1, NM),
	sort(Machines1, Machines2),
	fd_global(Goal, f(NT,NM,Opt,Tasks,Machines2,NT,0,_Handle,0), Susp).

cumulatives_options(L, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
cumulatives_options([], Opt, Opt, _, _) :- !.
cumulatives_options([X|L], Opt0, Opt, Goal, ArgNo) :- !,
	(   cumulatives_option(X, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,cumulatives_option), Goal, ArgNo, X)
        ),
	cumulatives_options(L, Opt1, Opt, Goal, ArgNo).
cumulatives_options(L, _, _, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Goal, ArgNo, L).

%%% Valid options:
%%% bound(lower|upper)   ==> 0x0|0x1
%%% generalization(Bool) ==> 0x0|0x2
%%% task_intervals(Bool) ==> 0x0|0x4
%%% prune(all|next)      ==> 0x0|0x8

cumulatives_option(-, _, _) :- !, fail.
cumulatives_option(bound(B), Opt0, Opt) :-
	aux_option(bound, B, Value),
	Opt is (Opt0 /\ -2) \/ Value.
cumulatives_option(generalization(B), Opt0, Opt) :-
	bool_option(B, Value),
	Opt is (Opt0 /\ -3) \/ (Value<<1).
cumulatives_option(task_intervals(B), Opt0, Opt) :-
	bool_option(B, Value),
	Opt is (Opt0 /\ -9) \/ (Value<<2).
cumulatives_option(prune(B), Opt0, Opt) :-
	aux_option(prune, B, Value),
	Opt is (Opt0 /\ -17) \/ (Value<<3).

cum_minmax_tasks([]) --> [].
cum_minmax_tasks([task(Org,Dur,End,Height,Machine)|Tasks]) -->
	on_minmax([Org,Dur,End,Height]),
	on_dom([Machine]),
	cum_minmax_tasks(Tasks).

cum_minmax_fields([], [], [], [], [], []).
cum_minmax_fields([task(A,B,C,D,E)|Tasks],
		  [A|As], [B|Bs], [C|Cs], [D|Ds], [E|Es]) :-
	cum_minmax_fields(Tasks, As, Bs, Cs, Ds, Es).

/****************************************************************/
/* global_cardinality/[2,3]					*/
/****************************************************************/

global_cardinality(Xs, Ys) :-
	global_cardinality(Xs, Ys, []).

global_cardinality(Xs, Ys, Opt) :-
	global_cardinality(Xs, Ys, Opt, opt(0,[]), global_cardinality(Xs,Ys,Opt)).

global_cardinality(Vars, Vals, Options, Opt0, Goal) :-
	gcc_options(Options, Opt0, Opt, Goal, 3),
	Opt = opt(Flag,Cost),	% [] or cost(UB,Matrix)
	must_be_dvar_list(Vars, Goal, 1),
	length(Vars, N),
	val_keys(Vals, Goal, 2, DomList, Counts),
	list_to_fdset(DomList, DomSet),
	length(DomList, M),
	'$fd_size'(DomSet, M, 1), !, % no duplicates
	keysort(Vals, SVals),
	domain(Vars, DomSet),
	domain(Counts, 0, N),
	on_dom(Vars, Susp, Susp1),
	on_minmax(Counts, Susp1, Susp2),
	(   Flag=:=0 -> Susp2 = []
	;   Cost=cost(C,_,_), Susp2 = [dom(C)]
	),
	fd_global_internal(Goal,
			   f(N,M,Vars,SVals,Flag,Cost,0/*cost so far*/,_Handle,0),
			   Susp, Global, clpfd:Goal, 0),
	Global = global(StateM,_,_,_,_),
	(   Flag=:=0 -> true
	;   global_cardinality_helpers(Vars, C, 0, StateM)
	).
global_cardinality(_Vars, _Vals, _Options, _Opt0, Goal) :-
	fd_illarg(domain(list(callable),global_cardinality_value_list),
		  Goal, 2).

global_cardinality_helpers([], _, _, _).
global_cardinality_helpers([X|Xs], C, I, StateM) :-
	fd_global_internal(global_cardinality_helper(X,C), f(I,X,StateM), [val(X)],
			   _, true, 0),
	J is I+1,
	global_cardinality_helpers(Xs, C, J, StateM).

val_keys(V, _Goal, _ArgNo, _, _) :- var(V), !, fail.
val_keys([], _Goal, _ArgNo, [], []).
val_keys([Val|Vals], Goal, ArgNo, [K|Ks], [Count|Counts]) :-
	nonvar(Val), Val = K-Count,
	arg_attribute(Count, _, Goal, ArgNo),
	val_keys(Vals, Goal, ArgNo, Ks, Counts).

gcc_options(L, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
gcc_options([], Opt, Opt, _, _) :- !.
gcc_options([X|L], Opt0, Opt, Goal, ArgNo) :- !,
	(   gcc_option(X, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,global_cardinality_option), Goal, ArgNo, X)
        ),
	gcc_options(L, Opt1, Opt, Goal, ArgNo).
gcc_options(L, _, _, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Goal, ArgNo, L).

gcc_option(cost(V,Mat), opt(_,_), opt(1,cost(V,VM,Mat))) :-
	arg_attribute(V, VM, 0, 3).


/****************************************************************/
/* sorting/3							*/
/****************************************************************/

sorting(Xs, Ps, Ys) :-
	Goal = sorting(Xs,Ps,Ys),
	must_be_dvar_list(Xs, Goal, 1),
	must_be_dvar_list(Ps, Goal, 2),
	must_be_dvar_list(Ys, Goal, 3),
	length(Xs, N),
	length(Ps, N),
	length(Ys, N),
	'$fd_range'(1, N, Set, 1),
	domain(Ps, Set),
	all_diff_init(Xs, XVec, minmax, Goal, 1, Susp , Susp1),
	all_diff_init(Ps, PVec, minmax, Goal, 2, Susp1, Susp2),
	all_diff_init(Ys, YVec, minmax, Goal, 3, Susp2, []),
	fd_global(Goal, f(XVec,PVec,YVec,N,
			  0/*NShaved*/,0/*YOffset*/,_Handle,0), Susp).

/****************************************************************/
/* lex_chain/[2,3]						*/
/****************************************************************/

lex_chain(Tuples) :-
	lex_chain(Tuples, []).

lex_chain(Tuples, Options) :-
	Goal = lex_chain(Tuples, Options),
	lex_chain_options(Options, opt(0,[]), Opt, Goal, 2),
	length(Tuples, NT),
	length(EntFlags, NT),	% keep track of entailed pairs
	each_must_be_list_of_finite_dvar(Tuples, NV, Goal, 1),
	each_all_diff_init(Tuples, Matrix, dom, Goal, 1, _Susp, []),
	Opt = opt(Flag,Among),
	(   Flag/\2 =:= 0 -> true
	;   Among = among(L,U,Vals),
	    Vals\==[], L=<U -> true
	;   fd_illarg(consistency(Options,Options,''), Goal, 2)
	),
	fd_global(Goal, state(Matrix,NT,NV,Flag,Among,EntFlags,_/*handle*/,0/*stamp*/), []/*Susp*/).

lex_chain_options(L, _, _, Goal, ArgNo) :- 
	var(L), !,
	fd_illarg(var, Goal, ArgNo).
lex_chain_options([], Opt, Opt, _, _) :- !.
lex_chain_options([X|L], Opt0, Opt, Goal, ArgNo) :- !,
	(   lex_chain_option(X, Opt0, Opt1) -> true
        ;   fd_illarg(domain(term,lex_chain_option), Goal, ArgNo, X)
        ),
	lex_chain_options(L, Opt1, Opt, Goal, ArgNo).
lex_chain_options(L, _, _, Goal, ArgNo) :- 
	fd_illarg(domain(term,list), Goal, ArgNo, L).

lex_chain_option(op(#=<), opt(F0,A), opt(F,A)) :- !,
	F is (F0/\2).
lex_chain_option(op(#<), opt(F0,A), opt(F,A)) :- !,
	F is (F0/\2)\/1.
lex_chain_option(among(L,U,Vals0), opt(F0,_), opt(F,among(L,U,Vals))) :- !,
	F is (F0/\1)\/2,
	list_to_fdset(Vals0, Vals).

each_must_be_list_of_finite_dvar([], _, _, _).
each_must_be_list_of_finite_dvar([T|Ts], NV, Goal, ArgNo) :-
	length(T, NV),
	must_be_list_of_finite_dvar(T, Goal, ArgNo),
	each_must_be_list_of_finite_dvar(Ts, NV, Goal, ArgNo).

each_all_diff_init([], [], _, _, _) --> [].
each_all_diff_init([T|Ts], [R|Rs], What, Goal, ArgNo) -->
	all_diff_init(T, R, What, Goal, ArgNo),
	each_all_diff_init(Ts, Rs, What, Goal, ArgNo).

on_dom([]) --> [].
on_dom([X|Xs]) --> [dom(X)], on_dom(Xs).

on_minmax([]) --> [].
on_minmax([X|Xs]) --> [minmax(X)], on_minmax(Xs).

on_val([]) --> [].
on_val([X|Xs]) --> [val(X)], on_val(Xs).

%%% Option parsing

bool_option(-, _) :- !, fail.
bool_option(false, 0).
bool_option(true, 1).

aux_option(_, -, _) :- !, fail.
aux_option(bound, lower, 0) :- !.
aux_option(bound, upper, 1).
aux_option(prune, all, 0) :- !.
aux_option(prune, next, 1).
aux_option(consistency, local, local).
aux_option(consistency, bound, bound).
aux_option(consistency, bounds, bound).
aux_option(consistency, global, global).
% deprecated:
aux_option(complete, false, local).
aux_option(complete, true, local).

keys_values_pairs([], [], []).
keys_values_pairs([X|Xs], [C|Cs], [X-C|XCs]) :-
	keys_values_pairs(Xs, Cs, XCs).

%%%% To go into library(lists)

keys_and_values([], [], []).
keys_and_values([Key-Value|Pairs], [Key|Keys], [Value|Values]) :-
	keys_and_values(Pairs, Keys, Values).

keyclumps([], []).
keyclumps([Pair|Pairs], [Clump|Clumps]) :-
	keyclumps(Pairs, Pair, Clump, Clumps).

keyclumps([], Prev, [Prev], []).
keyclumps([Pair|Pairs], Prev, [Prev|Clump], Clumps) :-
	keycompare(O, Prev, Pair),
	keyclumps(O, Pair, Clump, Clumps, Pairs).

keyclumps(=, Pair, Clump, Clumps, Pairs) :-
	keyclumps(Pairs, Pair, Clump, Clumps).
keyclumps(<, Pair, [], [Clump|Clumps], Pairs) :-
	keyclumps(Pairs, Pair, Clump, Clumps).
keyclumps(>, Pair, [], [Clump|Clumps], Pairs) :-
	keyclumps(Pairs, Pair, Clump, Clumps).

keycompare(O, K1-_, K2-_) :-
	compare(O, K1, K2).

