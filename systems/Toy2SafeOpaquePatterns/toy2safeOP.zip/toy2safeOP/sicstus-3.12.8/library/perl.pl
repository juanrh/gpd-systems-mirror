%%% --------------------------------------------------------------------------------
%%% Filename:	    /home1/jojo/sicstus3/library/src/perl.pl
%%% Author:         Jesper Eskilson <jojo@sics.se>
%%% Created:	    Thu Feb 18 18:35:37 1999
%%% Description:    library(perl), calling Perl from Prolog.
%%% Last-Update:    Time-stamp: <1999-02-19 2058 jojo>
%%% --------------------------------------------------------------------------------

:- module(perl, []).

:- load_foreign_resource(perl).

foreign_resource(perl, [
			init(perl_init),
			deinit(perl_deinit)
		       ]).

