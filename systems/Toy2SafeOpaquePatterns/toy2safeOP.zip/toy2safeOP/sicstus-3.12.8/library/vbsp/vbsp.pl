%%% -*- Mode: Prolog; Module: vbsp; -*-

:- module(vbsp, []).

open_query(StreamCode, Goal, Vars) :-
	stream_code(Stream, StreamCode),
	read_term(Stream, Goal, [variable_names(Vars)]).

query_cut_fail(StreamCode) :-
	stream_code(Stream, StreamCode),
	read(Stream, Goal),
	call(user:Goal).

vbsp_write_term(StreamCode, Term) :-
	stream_code(Stream, StreamCode),
	write(Stream, Term).

vbsp_write_term_quoted(StreamCode, Term) :-
	stream_code(Stream, StreamCode),
	writeq(Stream, Term).

vbsp_write_excp(StreamCode, Term) :-
	stream_code(Stream, StreamCode),
	write_term(Stream, Term, [quoted(true),max_depth(10)]).

set_paths(VBSPPath, AppPath) :-
	assert(user:file_search_path(vbsp,VBSPPath)),
        %% [PM] 3.9.2 We could use assert(user:file_search_path(app,'$SP_APP_PATH'))
        %%      Especially since Excel VBA does not have App.Path
        %%      object (it is called Application.Path). (SPRM 3888)
        %%      However, it may be useful in some applications to
        %%      modify vbsp.bas so that some other path than App.Path
        %%      is used. For instance, it would be useful if we could
        %%      use the location of the VB project instead of the VB
        %%      development system when not running as a standalone VB
        %%      executable.
	assert(user:file_search_path(app,AppPath)).

